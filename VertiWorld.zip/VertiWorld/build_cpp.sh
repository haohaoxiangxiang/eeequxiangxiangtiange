#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "=== 深入世界 VertiWorld C++ 服务端一键构建 ==="

if ! command -v g++ >/dev/null 2>&1; then
    echo "[错误] 找不到 g++。请在 Termux 运行: pkg install clang"
    exit 1
fi

mkdir -p cpp-libs

# 下载 httplib.h (带备用国内加速源)
if [ ! -s "cpp-libs/httplib.h" ] || [ $(stat -c%s "cpp-libs/httplib.h" 2>/dev/null || echo 0) -lt 10000 ]; then
    echo "[下载] httplib.h ..."
    if command -v curl >/dev/null 2>&1; then
        curl -L --retry 3 --connect-timeout 10 -o "cpp-libs/httplib.h" "https://ghproxy.net/https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h" || true
    else
        wget -O "cpp-libs/httplib.h" "https://ghproxy.net/https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h" || true
    fi
fi

# 如果下载失败，提示手动下载
if [ ! -s "cpp-libs/httplib.h" ] || [ $(stat -c%s "cpp-libs/httplib.h" 2>/dev/null || echo 0) -lt 10000 ]; then
    echo "✘ httplib.h 下载失败！请用浏览器下载后放入 cpp-libs/ 目录。"
    echo "  链接: https://mirror.ghproxy.com/https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h"
    exit 1
fi

# 检查 nlohmann/json 是否存在
if [ ! -f "$PREFIX/include/nlohmann/json.hpp" ] && [ ! -f "cpp-libs/json.hpp" ]; then
    echo "[提示] 缺少 json 库，尝试 pkg install nlohmann-json ..."
    pkg install nlohmann-json -y || true
fi

# miniz：内置 zip 读写，避免依赖 Termux 的 zip / unzip 命令
if [ ! -s "cpp-libs/miniz.c" ] || [ ! -s "cpp-libs/miniz.h" ]; then
    echo "[下载] miniz (内置 zip) ..."
    curl -L --retry 3 --connect-timeout 10 -o "cpp-libs/miniz.c" "https://raw.githubusercontent.com/richgel999/miniz/master/miniz.c" || true
    curl -L --retry 3 --connect-timeout 10 -o "cpp-libs/miniz.h" "https://raw.githubusercontent.com/richgel999/miniz/master/miniz.h" || true
fi
if [ ! -s "cpp-libs/miniz.c" ] || [ ! -s "cpp-libs/miniz.h" ]; then
    echo "✘ miniz 下载失败！请手动下载 miniz.c / miniz.h 放入 cpp-libs/ 目录。"
    exit 1
fi

# miniz 是 C 代码，用 C 编译器单独编译成 .o，避免 g++ 按 C++ 解析
CC_BIN=""
for c in cc gcc clang; do
    if command -v "$c" >/dev/null 2>&1; then CC_BIN="$c"; break; fi
done
if [ -z "$CC_BIN" ]; then
    echo "[错误] 找不到 C 编译器（cc / gcc / clang）"
    exit 1
fi
mkdir -p "$DIR/.tmp"
echo "[编译] miniz.o ($CC_BIN) ..."
$CC_BIN -O2 -D_FILE_OFFSET_BITS=64 -c "$DIR/cpp-libs/miniz.c" -o "$DIR/.tmp/miniz.o" || exit 1

echo "[编译] 正在编译 server.cpp ..."
# ★ 关键修复：输出到 $HOME 目录，绕过 /storage/emulated/0 的 noexec 限制
OUT="$HOME/3dmc_server_cpp"
# 包含本地 libs 和 Termux 系统头文件
INC="-I $DIR/cpp-libs"
if [ -n "$PREFIX" ]; then INC="$INC -I $PREFIX/include"; fi

g++ -std=c++17 -O2 $INC server.cpp "$DIR/.tmp/miniz.o" -o "$OUT" -lpthread

if [ $? -eq 0 ]; then
    echo "✔ 编译成功！"
    echo "  输出位置: $OUT"
    chmod +x "$OUT"
else
    echo "✘ 编译失败，请检查上方错误信息。"
fi