/* ============================================================
   coremods/stoneworld_drops —— 化石矿掉落替换
   ------------------------------------------------------------
   问题：石头世界的「化石矿石」要求挖掉后掉肉，但原版掉落表
   （main.js 的 DROP_OVERRIDE）是模块私有常量，mod 拿不到，
   也没有注册方块掉落的 API。

   做法：用 RETURN 注入拦截 src/main.js 的 dropIdFor()，把返回的
   「要掉的物品 id」换掉：
     sw_fossil_ore  →  sw_meat_raw（生肉）
   其它方块原样放行。

   注意：
     · 只改返回值，不动函数本身逻辑，影响面最小。
     · 方块 id 在运行时从 window.__GAME__.B 取 —— 寄存器在进世界时
       才注册方块，那时候 __GAME__ 一定已经就绪；这个回调本身
       只在玩家挖方块时才被调用。
     · 本 mod 没启用时 G.B.sw_fossil_ore 是 undefined，直接放行，
       对普通世界零影响。
   ============================================================ */

(function(){
  var TARGET = 'src/main.js#dropIdFor';

  function hook(ret){
    try {
      var G = window.__GAME__;
      if (!G || !G.B) return ret;

      var fossil = G.B.sw_fossil_ore;
      if (!fossil) return ret;                 /* 石头世界没启用 */
      if (ret !== fossil.id) return ret;       /* 不是化石矿，放行 */

      var meat = G.B.sw_meat_raw;
      if (meat && typeof meat.id === 'number') return meat.id;
      return ret;
    } catch (e){
      return ret;                              /* 任何异常都放行 */
    }
  }

  if (window.__MIXIN__ && typeof window.__MIXIN__.register === 'function'){
    window.__MIXIN__.register(TARGET, 'RETURN', hook);
  } else {
    /* 极端情况：注入运行时还没建好（理论上不会），等 load 再试一次 */
    window.addEventListener('load', function(){
      if (window.__MIXIN__ && typeof window.__MIXIN__.register === 'function'){
        window.__MIXIN__.register(TARGET, 'RETURN', hook);
      }
    });
  }
})();
