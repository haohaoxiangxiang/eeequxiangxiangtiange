# 深入世界 · VertiWorld（V0.0.0）

浏览器里跑的体素沙盒游戏。纯 Three.js，无构建步骤，`mods/` 目录自带一套 mod 系统。
设计目标是**在手机上也能跑满帧**——所以几乎所有优化参数都是运行时测出来的，而不是写死的。

- 地图：16×16 区块、默认 446 层高（`Y_MIN=-46` ~ `CHH=400`）、16 个群系、75 种可放置方块（含空气与占位方块共 77 个定义）
- 渲染：Three.js r187（vendored，不走 CDN）、贪心网格 + AO + 群系染色、打包顶点格式
- 代码量：`src/` 45 个模块 ≈ 37.8k 行（不含 vendored Three.js），`mods/` 22 个 mod / 25 个模块 ≈ 11.8k 行

---

## 目录

- [快速开始](#快速开始) · 怎么跑起来、服务器做什么
- [玩法与内容](#玩法与内容) · 世界、方块、系统、设置项
- [架构](#架构) · 模块分层、区块管线、Worker
- [性能](#性能) · 实测基线、四条优化原则、性能探针
- [Mod 系统](#mod-系统) · 怎么写 mod、mod 提供世界类型、文档链接
- [已知问题](#已知问题) · 已验证的真实缺陷
- [文档索引](#文档索引) · 四份文档各管什么
- [**游戏目录**](游戏目录.md) · 源码文件地图（每个文件一行说明）

---

## 快速开始

```bash
bash start.sh            # 默认 8080（菜单选 1/2/3 启动，选 4 停止，选 0 退出）
bash start.sh node 3000  # 直接指定服务端和端口
bash stop.sh             # 端口被占用 / 有残留进程时用它
```

`start.sh` 按菜单或参数直接启动选定的服务端（`node` / `python` / `cpp`），并打印局域网地址；不会在某个服务端缺失时自动退化到别的实现。

> **必须用 HTTP 打开，不能双击 `index.html`。**
> 游戏用的是 ES module + `fetch()`，`file://` 协议下模块和存档请求都会被浏览器拦掉。

手机和电脑在同一个 Wi-Fi 下时，直接访问脚本打印的 `http://<局域网IP>:8080` 即可。

### 关掉服务器 / 端口还被占用

如果 Ctrl+C 之后 `8080` 还被占，或者 `ps` 里躺着好几个 `node server.js`，
用 `bash stop.sh` 一把清掉（`bash stop.sh --list` 只查看不杀）。

服务器本身已经内置了这些自愈机制，正常情况下不用管：

- **信号处理**：`SIGINT`/`SIGTERM`/`SIGHUP` → 强杀所有 keep-alive socket 后立刻退出，端口马上可用。
- **父进程看门狗**：用 `bash start.sh` 启动的服务器，一旦终端会话没了（ppid 变 1），3 秒内自己退出。
  所以「关掉 Termux 之后端口一直被占」这个问题不会再出现。
- **启动自愈**：启动时发现上次没退干净的 `server.js` / `server.py` / `server_cpp`，自动结束它再监听。
- **`IDLE_EXIT_MIN`**：可选，孤儿进程空闲 N 分钟后自杀（默认关）。

> 服务器代码里**没有任何守护进程/自启逻辑**。残留进程的真正原因是 Termux 会话被系统回收，
> 进程被 reparent 到 pid 1 后继续跑。详见 [`游戏目录.md`](游戏目录.md) 第六节。

---

### 服务器做什么

`server.js` 是零依赖的（只用 Node 内置 `http`/`fs`/`zlib`）：

| 路径 | 用途 |
|---|---|
| `/` | 静态文件。gzip/brotli 协商 + ETag → 304（首屏 2.03MB 压到 0.49MB，重复访问 27KB） |
| `/api/mods` | 扫描 `mods/*/manifest.json`，返回 mod 列表（含 mod 声明的世界类型） |
| `/api/saves/...` | 存档文件读写（玩家/背包/方块改动/实体/熔炉/箱子/区块 bundle） |
| `/api/gen-chunk` | 主线程生成兜底 |
| `/api/log/`、`/api/diag/` | 客户端日志与诊断采样落盘 |
| `/api/atlas-config` | 按 mod 需求的贴图数量估算 atlas 尺寸 |

---

## 玩法与内容

- **世界类型**：超平坦 / 普通（`真实地形` 目前是隐藏状态）
- **群系**：海洋、沙滩、平原、森林、樱花林、白桦林、沼泽、针叶林、雪原、沙漠、稀树草原、丛林、荒地、红树林、蘑菇岛、河流
- **系统**：挖掘/放置（含连锁挖断）、合成、熔炉烧炼、**箱子（27 格，每箱独立存档文件）**、流体（MC 式寻路 + 无限水 + 模拟距离）、动物 AI（距离分级 tick）、掉落物、饥饿/氧气/血量、昼夜循环与云、多维度
- **移动端**：虚拟摇杆、触屏手势、动作按钮、全屏；手势默认按准星判定（短按放置/交互，准星指着实体则攻击，长按挖方块，拖动转身），可在「设置 → 操作 → 触屏瞄准」切换为按手指落点判定
- **分发**：地图 / 整合包一键导出导入（zip），见下文「地图与整合包」

### 地图与整合包

四个入口（不在世界列表里了，按用途分散在各自该在的地方）：

| 按钮 | 在哪 | 干什么 | 包里装的东西 |
|---|---|---|---|
| 📂 导入地图 | **世界类型选择** 对话框底部 | 选一个 `.zip` → 变成**新存档**（不覆盖本地同名存档） | `saves/<id>/...` + 它依赖的 `mods/<id>/...` |
| 🧩 导入整合包 | **创建世界 → 选择 Mod…** 右边 | 选一个 `.zip` → 安装里面的 mod，并自动勾选 | `mods/<id>/...` + `modpack.json` |
| 📦 导出地图 | **世界设置 → 地图 / 整合包** | 把选中世界打包下载（自动带上它勾选的 mod） | 同"导入地图" |
| 🧩 导出整合包 | **世界设置 → 地图 / 整合包** | 把这个世界用到的 mod 打包下载 | `mods/<id>/...` |

要点：

- **地图包 = 存档 + mod**，别人拿到包就能还原你的世界（同样的方块 id、同样的 mod）。
- 导入地图永远生成新的存档 id，同一个包可以反复导入出多个副本。
- 导入整合包会**整体替换**同名 mod 目录（本地改过的版本会被覆盖）。
- 包大小上限 / 细节格式 / 接口见 [`mod开发3.md`](mod开发3.md) 第 4 节。
- **C++ 服务端同样支持导入导出**（内置 miniz，不依赖系统 zip 命令；需用 `build_cpp.sh` 重新编译）。

### 设置面板

渲染距离 · 模拟距离 · 阴影距离 · 阴影质量 · 云质量 · 亮度 · 灵敏度 · 清晰度（分辨率缩放 0.4~3.0）· UI 大小 · 摇杆/按钮大小 · 落叶 · 叶子透明度 · 视锥剔除距离 · 区块加载并发 · 写盘并发与队列 · Mesh Worker

**所有性能相关参数都在设置里，代码里没有任何"针对某台手机"的写死值**——预算全部来自设置项、设备画像、实测帧余量，见下文「优化原则」。

---

## 架构

> **2026-10 整理**：`src/` 从 82 个碎片文件（含几十个 1~6KB 的）合并为 **34 个模块**（新增 `items/item-visuals.js` 后为 35 个），
> 删掉 5 个死文件 + 73 个历史 `.bak`。单个文件控制在 15~60KB，模块头部都注明"合并自哪几个文件"。


```
index.html
 └─ src/main.js ───────────── 主循环 / UI 装配 / Mod 宿主
     ├─ core/      基础设施（常量、日志、诊断、Mod 内核与门面）
     ├─ world/     世界数据（terrain 存储 / chunk 调度 / 地形生成 / 流体）
     │   └─ core/  纯计算内核（可整体塞进 Worker）
     ├─ render/    渲染（renderer / materials / sky）
     ├─ player/    玩家与输入
     ├─ entities/  动物与实体注册表
     ├─ items/     背包、合成、熔炉、箱子、掉落物
     ├─ ui/        菜单、设置、游戏内 HUD、Mod 面板
     ├─ save/      存档读写 + mod 加载器
     ├─ worker/    Worker 池 + 地形/网格双工 Worker
     └─ audio/     程序化音效
```

**完整文件地图见 [`游戏目录.md`](游戏目录.md)**（`src/` 35 个模块，每个一行说明 + 体积）。

### 区块管线

```
genChunkData(cx,cz)  →  blocks/fluid/topY + 染色表
   →  buildChunkGeometry()   贪心网格 + AO + 群系染色（31 级量化合并）
   →  _installGroups()       打包交织顶点 → InterleavedBuffer → Mesh
   →  chunk-db.js            攒批 gzip 写盘
```

顶点格式是**交织打包**的：stride 15×float32 = 60 B/顶点
（position 3 / normal 3 / color 3 / uv 2 / uvRect 4），索引 Uint32。
一块平坦 16×16 顶面约 44 个顶点——这是贪心网格的意义。

### Worker

`terrain-worker.js` 同时承担**生成**和**建网格**两件事，SAB 可用时零拷贝。
`pool.js` 是带优先级的 Worker 池。所有路径都有主线程兜底（拿不到 Worker 也能跑，只是慢）。

---

## 性能

当前实测基线（中端 Android，渲染距离 5、阴影/云/落叶全关、分辨率缩放 0.4）：

| 场景 | 帧时间 | FPS | p99 |
|---|---|---|---|
| 站着不动 | 16.7 ms | 60（锁满） | 21.3 ms |
| 移动中 | 17.0 ms | 59 | 31.8 ms |

- 游戏自身每帧只花 **8.1 ms**（渲染提交 6.9 + 区块流式 0.7 + 逻辑 0.3），其余是等垂直同步的空闲时间
- **GPU 排空延迟 0.1 ms** —— 显卡基本闲着，瓶颈不在渲染负载
- 剩下的问题是**偶发尖峰**（23~52 ms，移动时更多），已排除 GPU 与游戏逻辑

优化原则（很重要，改代码前请遵守）：

1. **不写死设备参数**。所有预算来自设置项、设备画像、学到的刷新间隔、实测帧余量。
   - `main.js` 的 `_learnFrameTarget()` 学真实刷新间隔（60/90/120Hz 自动识别）
   - `_pickChunkBudget()` 用「目标帧时间 − 本帧已花」得到的余量分档
   - `chunk.js` 的 `updateChunks(..., frameHeadroomMs)` 按余量决定这一帧装多少
2. **不要给游戏内可见元素加 `backdrop-filter`**。它会让浏览器每帧做一次全屏模糊，
   实测把「帧间空档」从 3.5ms 抬到 9.0ms（60fps → 43fps）。菜单和弹窗可以用。
3. **每帧都要执行的东西不要分配对象**。UI 更新一律先比对再写 DOM（脏检查）。
4. **测量要能自我校验**：`渲 + 块 + 逻 ≈ body`，`body + 空档 = frameTime`。
   对不上就说明探针本身错了——这个项目里已经栽过三次。

### 性能探针

游戏内按 **F9** 打开 `perf-monitor` 面板，点「测 1 分钟」录一份报告，包含：
帧时间分布（站/走分开）、逻辑细分、实测三段、长帧归因、**GC 验证**（几何缓冲周转 vs 掉帧的百分点差对照）、GPU 排空延迟、最差 10 帧逐帧明细。

技术细节见 [`mods/perf-monitor/main.js`](mods/perf-monitor/main.js) 顶部注释。

---

## Mod 系统

一个 mod 就是一个目录：

```
mods/my_mod/
├── manifest.json
└── main.js
```

```json
{
  "id": "my_mod",
  "name": "我的 Mod",
  "version": "1.0.0",
  "apiVersion": 4,
  "entry": "main.js",
  "dependencies": []
}
```

```js
export default {
  async onEnable(saveId, meta, G){
    G.registerBlock('my_block', '我的方块', { opaque: true, solid: true, hardness: 2 });
    G.on('game.tick', (dt) => { /* 每帧 */ });
  },
  async onDisable(saveId){ /* 清理 */ }
};
```

- mod **按存档启用**（`world.json` 的 `plugins`），切换存档会自动卸载上一个存档的 mod
- 宿主门面是 `G`：注册内容（方块/配方/熔炼/生物/群系/生成器/维度/音效）、事件总线、函数 Hook、世界读写、玩家与背包、`G.storage` 私有存储、场景与 Three.js

### 世界类型可以由 mod 提供

mod 可以在 manifest 里声明新的世界类型：

```json
"worldTypes": [{
  "id": "raft_ocean",
  "label": "无尽之海", "icon": "🌊", "desc": "陆地约占 4% 的开阔海面",
  "options": [
    { "key": "height",  "kind": "height" },
    { "key": "islands", "kind": "toggle", "label": "生成岛屿", "def": true }
  ],
  "heightLimits": { "def": 256, "max": 400 }
}]
```

创建世界界面会列出它（带 `MOD` 标记），选中时自动勾选该 mod 与它的依赖，
勾选的值通过 `G.getWorldOptions()` 交给 mod。
**没声明 `options` 的类型自动沿用普通模式的选项，声明成 `[]` 表示这个模式没有可调项**（超平坦就是这样去掉高度滑条的）。

### 文档

| 文档 | 内容 |
|---|---|
| [`mod开发1.md`](mod开发1.md) / [`mod开发2.md`](mod开发2.md) / [`mod开发3.md`](mod开发3.md) | **Mod 开发文档三卷**：卷一 入门与核心 API / 卷二 内容注册与玩法 / 卷三 兼容、扩展与 Coremod |
| [`一些mod开发者的话.txt`](一些mod开发者的话.txt) | 三份外部 mod 作者的反馈合集（CC 终端 / 海上漂流 / 机械动力），第三方视角的 API 缺口 |
| [`游戏目录.md`](游戏目录.md) | 源码文件地图 |

### 自带的 13 个 mod

`raftcore` `raftworld` `raftbuild` `raftvoyage` `rafttech` `raftstory` `raftcompat`（筏海整合包）·
`create_lite`（机械传动）· `magicraft`（魔法与维度）· `cc_voxel`（游戏内终端）·
`perf-monitor`（性能探针）· `debug-tools`（调试）· `spectator`（旁观）

---

## 已知问题

按「会不会咬到人」排序。以下全部是**对照源码逐条核实过**的：

1. **自定义生成器不生效**。`world-gen.js` 的 `createWorldGen()` 从不读 `activeGenId`，
   全代码里 `getGenerator()` 只有两处调用（Worker 兼容性判断 + `hidden` 检查）。
   所以 mod 注册的 `heightAt`/`biomeAt`/`onChunkGen`/`onDecorate` 在任何路径上都不会被调用。
   目前土地方案是 mod 自己在 `chunk.decorate` 里就地矫正地形（`raftworld` 的 `enforceOcean()`）。
2. **`mods.manifest.dependencies` 不排序、不校验、无环检测**。加载顺序就是玩家勾选顺序；
   依赖缺失时没有提示。`raftcompat` 用「运行时惰性取用」绕过了这个问题。
3. **`initCrashGuard()` 从未被调用**，崩溃守卫实际是死代码。
4. **`device-profile.js` 的 Mali 正则漏两位型号**（`/mali-g7[0-9]{2}/` 匹配不到 G52/G72……），
   这些 GPU 会落到 `unknown-conservative` 档。
5. **整合包/地图包是整包一次性读进内存解压的**，默认上限 64MB（`server.js` / `server.cpp` / `server.py` 一致）。
   超过 64MB 的整合包需要拆包，或自行调高服务端上限。
6. ~~5 个死代码文件~~ —— **已删除**（`world/priority.js`、`world/cave.js`、`world/core/cave-carver.js`、
   `world/landform-real.js`、`render/IRenderer.js`），详见 [`游戏目录.md`](游戏目录.md) 第七节。

---

## 文档索引

- 想改游戏 → [`游戏目录.md`](游戏目录.md) 找文件
- 想写 mod → [`mod开发1.md`](mod开发1.md) / [`mod开发2.md`](mod开发2.md) / [`mod开发3.md`](mod开发3.md)（地图/整合包格式见卷三第 4 节）
- 想了解 API 争议 → [`一些mod开发者的话.txt`](一些mod开发者的话.txt)
- 历史性能原始数据 → [`报告.txt`](报告.txt)（旧版测试输出，仅作对照）

---

## 许可证

本项目为个人项目。vendored 的 Three.js 遵循其 MIT 许可（见 `src/vendor/three.module.js` 与 `src/vendor/three.core.js` 头部）。

> ★ 从 r167 起 three 的官方构建拆成两个文件：`three.module.js`（渲染器）通过
> `import ... from './three.core.js'` 相对引用 `three.core.js`（核心类）。
> 升级 three 时必须**两个文件一起替换**，只换 `three.module.js` 会直接白屏。
> 旧版单文件备份在 `src/vendor/three.module.js.r157.bak`。
