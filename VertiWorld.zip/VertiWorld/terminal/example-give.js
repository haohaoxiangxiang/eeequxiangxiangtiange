export async function run(ctx){
  const G = window.__GAME__;
  const [name, cnt] = ctx.args;
  if (!name) throw new Error('用法: /run example-give <物品名> [数量]');
  const n = Math.max(1, Math.min(9999, parseInt(cnt, 10) || 1));
  if (!G.give(name, n)) throw new Error('未知物品: ' + name);
  return `已给予 ${n} 个 ${name}`;
}
