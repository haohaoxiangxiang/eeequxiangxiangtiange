export async function run(ctx){
  const G = window.__GAME__;
  if (!G) throw new Error('需要先进入世界');
  ctx.log('参数:', ctx.args);
  ctx.log('坐标:', G.getPos());
  G.give('diamond_gem', 10);
  return '给 10 个钻石';
}
