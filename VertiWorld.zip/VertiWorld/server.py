#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""server.py — Python 版服务端（功能对齐 server.js，零第三方依赖）"""

import os, sys, json, gzip, zipfile, shutil, re, hashlib, time, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, unquote, quote
from pathlib import Path

PORT = int(os.environ.get('PORT', 8080))
ROOT = Path(__file__).parent.resolve()
SAVES_DIR    = ROOT / 'saves'
MODS_DIR     = ROOT / 'mods'
COREMODS_DIR = ROOT / 'coremods'
TEXTURES_DIR = ROOT / 'textures'
TMP_DIR      = ROOT / '.tmp'

for d in (SAVES_DIR, MODS_DIR, COREMODS_DIR, TEXTURES_DIR, TMP_DIR):
    d.mkdir(exist_ok=True)

SAVE_ID_RE   = re.compile(r'^[a-zA-Z0-9_-]{1,64}$')
MOD_ID_RE    = re.compile(r'^[a-zA-Z0-9_-]{1,64}$')
FILE_NAME_RE = re.compile(r'^[a-zA-Z0-9_.\-]{1,128}$')

MIME = {
    '.html': 'text/html; charset=utf-8',
    '.js':   'text/javascript; charset=utf-8',
    '.mjs':  'text/javascript; charset=utf-8',
    '.css':  'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png':  'image/png',
    '.jpg':  'image/jpeg',
    '.svg':  'image/svg+xml',
    '.ico':  'image/x-icon',
    '.wasm': 'application/wasm',
    '.ogg':  'audio/ogg',
    '.mp3':  'audio/mpeg',
    '.wav':  'audio/wav',
    '.txt':  'text/plain; charset=utf-8',
    '.md':   'text/markdown; charset=utf-8',
}

# ============================================================
# 工具
# ============================================================
def send_json(h, code, obj):
    body = json.dumps(obj).encode('utf-8')
    h.send_response(code)
    h.send_header('Content-Type', 'application/json; charset=utf-8')
    h.send_header('Content-Length', str(len(body)))
    h.send_header('Cache-Control', 'no-store')
    h.end_headers()
    h.wfile.write(body)

def read_body(h):
    length = int(h.headers.get('Content-Length', 0) or 0)
    if length > 64 * 1024 * 1024:
        raise ValueError('body too big')
    return h.rfile.read(length) if length else b''

def safe_join(base, *parts):
    p = base.joinpath(*parts).resolve()
    try:
        p.relative_to(base.resolve())
        return p
    except ValueError:
        return None

# ============================================================
# 扫描 mod / coremod / 材质
# ============================================================
def list_mods():
    out = []
    for d in MODS_DIR.iterdir() if MODS_DIR.exists() else []:
        if not d.is_dir() or d.name.startswith('.') or not MOD_ID_RE.match(d.name): continue
        mf = d / 'manifest.json'
        if not mf.exists(): continue
        try: m = json.loads(mf.read_text(encoding='utf-8'))
        except Exception: continue
        if not isinstance(m, dict): continue
        # ★ 只有【声明了 id 且与目录名不符】才跳过；没写 id 时用目录名（与 server.js 对齐）
        if m.get('id') and m.get('id') != d.name: continue
        out.append({
            'id': d.name,
            'name': m.get('name') or d.name,
            'version': m.get('version', '0.0.0'),
            'author': m.get('author', ''),
            'description': m.get('description', ''),
            'entry': m.get('entry') or 'main.js',
            'apiVersion': int(m.get('apiVersion', 1)),
            'permissions': m.get('permissions') if isinstance(m.get('permissions'), list) else [],
            'dependencies': m.get('dependencies') if isinstance(m.get('dependencies'), list) else [],
            'worldTypes': m.get('worldTypes') or [],
            'shortcuts': m.get('shortcuts') or [],
            'contents': m.get('contents'),
        })
    out.sort(key=lambda x: x['id'])
    return out

def list_coremods():
    out = []
    for d in COREMODS_DIR.iterdir() if COREMODS_DIR.exists() else []:
        if not d.is_dir() or d.name.startswith('.') or not MOD_ID_RE.match(d.name): continue
        mf = d / 'manifest.json'
        if not mf.exists(): continue
        try: m = json.loads(mf.read_text(encoding='utf-8'))
        except Exception: continue
        if not isinstance(m, dict) or m.get('id') != d.name: continue
        out.append({
            'id': m.get('id'),
            'name': m.get('name') or d.name,
            'version': m.get('version', '0.0.0'),
            'apiVersion': int(m.get('apiVersion', 4)),
            'stability': m.get('stability', 'experimental'),
            'entry': m.get('entry') or 'inject.js',
            'injections': m.get('injections') or [],
        })
    return out

def scan_hooks():
    hooks, events = [], []
    for p in (ROOT / 'src').rglob('*.js'):
        if 'vendor' in p.parts: continue
        try: text = p.read_text(encoding='utf-8')
        except Exception: continue
        rel = str(p.relative_to(ROOT)).replace('\\', '/')
        for i, line in enumerate(text.split('\n'), 1):
            m = re.search(r"defineHook\(\s*['\"]([^'\"]+)['\"]", line)
            if m: hooks.append({'name': m.group(1), 'file': rel, 'line': i})
            m = re.search(r"emit\(\s*['\"]([^'\"]+)['\"]", line)
            if m: events.append({'name': m.group(1), 'file': rel, 'line': i})
    return {'hooks': hooks, 'events': events}

# ============================================================
# JS 注入（Mixin）
# ============================================================
def inject_js(source, rel_path):
    if not rel_path.startswith('src/'): return source
    cms = list_coremods()
    if not cms: return source
    for cm in cms:
        for inj in cm['injections']:
            target = inj.get('target', '')
            if '#' not in target: continue
            t_file, t_fn = target.split('#', 1)
            if t_file != rel_path: continue

            t_str = json.dumps(target)
            pattern = re.compile(
                rf'((?:async\s+)?function\s+{re.escape(t_fn)}\s*\(([^)]*)\)\s*\{{)'
            )
            m = pattern.search(source)
            if not m: continue

            args = m.group(2).strip()
            head_code = f"\n  if (globalThis.__MIXIN__) __MIXIN__.run({t_str}, 'HEAD'{', ' + args if args else ''});"

            open_idx = m.end() - 1
            # 找到闭合大括号（简易状态机，避开字符串和注释）
            depth = 0; close_idx = -1
            in_str = None; in_lc = False; in_bc = False; i = open_idx
            while i < len(source):
                c = source[i]; nxt = source[i+1] if i+1 < len(source) else ''
                if in_lc:
                    if c == '\n': in_lc = False
                elif in_bc:
                    if c == '*' and nxt == '/': in_bc = False; i += 1
                elif in_str:
                    if c == '\\': i += 1
                    elif c == in_str: in_str = None
                elif c == '/' and nxt == '/': in_lc = True; i += 1
                elif c == '/' and nxt == '*': in_bc = True; i += 1
                elif c in '"\'':
                    in_str = c
                elif c == '{': depth += 1
                elif c == '}':
                    depth -= 1
                    if depth == 0: close_idx = i; break
                i += 1
            if close_idx < 0: continue

            at = inj.get('at', 'HEAD')
            if at == 'HEAD':
                source = source[:open_idx+1] + head_code + source[open_idx+1:]
                close_idx += len(head_code)
            if at == 'TAIL':
                tail = f"\n  if (globalThis.__MIXIN__) __MIXIN__.run({t_str}, 'TAIL');\n"
                source = source[:close_idx] + tail + source[close_idx:]
    return source

# ============================================================
# 注入 index.html
# ============================================================
def serve_index(h):
    idx_path = ROOT / 'index.html'
    if not idx_path.exists():
        return send_json(h, 404, {'error': 'index.html missing'})
    html = idx_path.read_text(encoding='utf-8')

    # atlas 配置
    try:
        BUILTIN_TILES = 220
        AVG_TILES = 1.5
        SAFETY = 1.3
        mods = list_mods()
        need_mod = sum((m.get('contents') or {}).get('blocks', 0) +
                       (m.get('contents') or {}).get('items', 0) +
                       3 * (m.get('contents') or {}).get('entities', 0)
                       for m in mods)
        need = int((BUILTIN_TILES + need_mod * AVG_TILES) * SAFETY)
        if   need <= 1024:  cols = 32
        elif need <= 4096:  cols = 64
        elif need <= 16384: cols = 128
        else:               cols = 256
        atlas_cfg = {'cols': cols, 'tiles': cols*cols, 'need': need, 'modNeeds': need_mod}
        html = html.replace('</head>', f'<script>window.__ATLAS_CONFIG__={json.dumps(atlas_cfg)};</script></head>')
    except Exception as e:
        print('[atlas] 注入失败:', e)

    # coremods
    try:
        cms = list_coremods()
        if cms:
            html = html.replace('</head>', f'<script>window.__COREMODS__={json.dumps(cms)};</script></head>')
            body_inject = ''.join(
                f'<script src="/coremods/{cm["id"]}/{cm["entry"]}"></script>\n'
                for cm in cms if cm.get('entry')
            )
            if body_inject:
                html = html.replace('</body>', body_inject + '</body>')
    except Exception as e:
        print('[coremods] 注入失败:', e)

    # 自定义材质
    try:
        tex_file = TEXTURES_DIR / 'custom.json'
        if tex_file.exists():
            custom = json.loads(tex_file.read_text(encoding='utf-8'))
            if custom:
                html = html.replace('</head>', f'<script>window.__CUSTOM_TEXTURES__={json.dumps(custom)};</script></head>')
    except Exception as e:
        print('[textures] 注入失败:', e)

    body = html.encode('utf-8')
    accept = h.headers.get('Accept-Encoding', '')
    if 'gzip' in accept and len(body) > 1024:
        body = gzip.compress(body, 6)
        h.send_response(200)
        h.send_header('Content-Type', 'text/html; charset=utf-8')
        h.send_header('Content-Encoding', 'gzip')
        h.send_header('Content-Length', str(len(body)))
        h.send_header('Cache-Control', 'no-store')
        h.end_headers()
        h.wfile.write(body)
        return

    h.send_response(200)
    h.send_header('Content-Type', 'text/html; charset=utf-8')
    h.send_header('Content-Length', str(len(body)))
    h.send_header('Cache-Control', 'no-store')
    h.end_headers()
    h.wfile.write(body)

# ============================================================
# 静态文件
# ============================================================
def serve_static(h, file_path):
    if not file_path.is_file():
        h.send_response(404)
        h.send_header("Content-Length", "0")
        h.send_header("Connection", "close")
        h.end_headers()
        return
    ext = file_path.suffix.lower()
    mime = MIME.get(ext, 'application/octet-stream')
    is_js_src = file_path.suffix == '.js' and '/src/' in str(file_path) and 'vendor' not in str(file_path)

    data = file_path.read_bytes()
    if is_js_src:
        try:
            rel = str(file_path.relative_to(ROOT)).replace('\\', '/')
            new = inject_js(data.decode('utf-8'), rel)
            if new != data.decode('utf-8'):
                data = new.encode('utf-8')
        except Exception as e:
            print('[inject]', e)

    accept = h.headers.get('Accept-Encoding', '')
    send_gz = ext in ('.js', '.css', '.json', '.html', '.svg', '.txt', '.md') and len(data) > 1024 and 'gzip' in accept
    if send_gz:
        data = gzip.compress(data, 6)

    h.send_response(200)
    h.send_header('Content-Type', mime)
    if send_gz: h.send_header('Content-Encoding', 'gzip')
    h.send_header('Content-Length', str(len(data)))
    cc = 'public, max-age=604800' if 'vendor' in str(file_path) else 'no-cache'
    h.send_header('Cache-Control', cc)
    h.end_headers()
    h.wfile.write(data)

# ============================================================
# 请求处理器
# ============================================================
class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass  # 安静模式

    def do_GET(self):    self.route('GET')
    def do_POST(self):   self.route('POST')
    def do_PUT(self):    self.route('PUT')
    def do_DELETE(self): self.route('DELETE')

    def route(self, method):
        path = unquote(urlparse(self.path).path)
        try:
            self.dispatch(method, path)
        except Exception as e:
            print(f'[error] {method} {path}:', e)
            try: send_json(self, 500, {'error': str(e)})
            except Exception: pass

    def dispatch(self, method, path):
        # ---- API ----
        if path == '/api/mods' and method == 'GET':
            return send_json(self, 200, list_mods())
        if path == '/api/hooks' and method == 'GET':
            return send_json(self, 200, scan_hooks())
        if path == '/api/coremods' and method == 'GET':
            return send_json(self, 200, list_coremods())
        if path == '/api/coremods/validate' and method == 'GET':
            missing = []
            for cm in list_coremods():
                for inj in cm['injections']:
                    tgt = inj.get('target', '')
                    if '#' not in tgt: continue
                    f, fn = tgt.split('#', 1)
                    fp = ROOT / f
                    if not fp.exists():
                        missing.append({'coremod': cm['id'], 'target': tgt, 'reason': 'file_not_found'})
                    else:
                        text = fp.read_text(encoding='utf-8', errors='replace')
                        if not re.search(rf'(function\s+{re.escape(fn)}\b|const\s+{re.escape(fn)}\s*=)', text):
                            missing.append({'coremod': cm['id'], 'target': tgt, 'reason': 'function_not_found'})
            return send_json(self, 200, {'valid': len(missing) == 0, 'missing': missing})

        if path == '/api/atlas-config' and method == 'GET':
            return send_json(self, 200, {'cols': 32, 'tiles': 1024, 'need': 220, 'modNeeds': 0})

        if path == '/api/textures' and method == 'POST':
            body = json.loads(read_body(self).decode('utf-8') or '{}')
            tex_file = TEXTURES_DIR / 'custom.json'
            custom = {}
            if tex_file.exists():
                try: custom = json.loads(tex_file.read_text(encoding='utf-8'))
                except Exception: pass
            for k, v in body.items():
                if v is None: custom.pop(k, None)
                else: custom[k] = v
            tex_file.write_text(json.dumps(custom, indent=2, ensure_ascii=False), encoding='utf-8')
            return send_json(self, 200, {'ok': True})

        # ---- 导入/导出 Modpack ----
        if path == '/api/import-modpack' and method == 'POST':
            return self._import_zip(read_body(self), pack=True)
        if path == '/api/export-modpack' and method == 'POST':
            return self._export_modpack()
        if path == '/api/import-map' and method == 'POST':
            return self._import_zip(read_body(self), pack=False)
        if path == '/api/export-map' and method == 'POST':
            return self._export_map()

        # ---- 存档 ----
        if path == '/api/saves':
            if method == 'GET':
                out = []
                for d in SAVES_DIR.iterdir():
                    wj = d / 'world.json'
                    if wj.exists():
                        try: out.append(json.loads(wj.read_text(encoding='utf-8')))
                        except Exception: pass
                return send_json(self, 200, out)
            if method == 'POST':
                body = json.loads(read_body(self).decode('utf-8'))
                sid = body.get('id')
                if not SAVE_ID_RE.match(sid or ''): return send_json(self, 400, {'error': 'bad id'})
                d = SAVES_DIR / sid
                if d.exists(): return send_json(self, 409, {'error': 'exists'})
                for sub in ('lod', 'data', 'chunks', 'logs'):
                    (d / sub).mkdir(parents=True)
                meta = body.get('meta') or {'id': sid}
                meta['id'] = sid
                (d / 'world.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
                return send_json(self, 200, {'id': sid})

        m = re.match(r'^/api/saves/([^/]+)$', path)
        if m and method == 'DELETE':
            sid = m.group(1)
            if SAVE_ID_RE.match(sid):
                shutil.rmtree(SAVES_DIR / sid, ignore_errors=True)
            return send_json(self, 200, {'ok': True})

        # ---- Bundle 上传 ----
        m = re.match(r'^/api/saves/([^/]+)/chunks/bundle$', path)
        if m and method == 'PUT':
            return self._handle_bundle(m.group(1), read_body(self))

        # ---- 日志 / 诊断 ----
        m = re.match(r'^/api/log/([^/]+)$', path)
        if m and method == 'POST':
            sid = m.group(1)
            if not SAVE_ID_RE.match(sid): return send_json(self, 400, {'error': 'bad'})
            d = SAVES_DIR / sid / 'logs'
            d.mkdir(parents=True, exist_ok=True)
            body = read_body(self).decode('utf-8', errors='replace')
            stamp = time.strftime('%Y%m%d-%H%M%S')
            (d / f'log-{stamp}-{int(time.time()*1000)%1000}.txt').write_text(body, encoding='utf-8')
            return send_json(self, 200, {'ok': True})

        m = re.match(r'^/api/diag/([^/]+)$', path)
        if m and method == 'POST':
            sid = m.group(1)
            d = SAVES_DIR / sid / 'logs'
            d.mkdir(parents=True, exist_ok=True)
            body = read_body(self).decode('utf-8', errors='replace').strip()
            with open(d / 'diag.txt', 'a', encoding='utf-8') as f:
                f.write(time.strftime('%Y-%m-%d %H:%M:%S  ') + body + '\n')
            return send_json(self, 200, {'ok': True})

        # ---- 存档内文件读写 ----
        m = re.match(r'^/api/saves/([^/]+)/(.+)$', path)
        if m:
            return self._handle_save_file(method, m.group(1), m.group(2))

        # ---- coremods 静态文件 ----
        if path.startswith('/coremods/'):
            rel = path[len('/coremods/'):].split('/')
            fp = safe_join(COREMODS_DIR, *rel)
            if fp is None: return send_json(self, 403, {'error': 'forbidden'})
            return serve_static(self, fp)

        # ---- mods 静态文件 ----
        if path.startswith('/mods/'):
            rel = path[len('/mods/'):].split('/')
            fp = safe_join(MODS_DIR, *rel)
            if fp is None: return send_json(self, 403, {'error': 'forbidden'})
            return serve_static(self, fp)

        # ---- index.html ----
        if path == '/' or path == '/index.html':
            return serve_index(self)

        # ---- 静态文件 ----
        fp = safe_join(ROOT, *path.strip('/').split('/'))
        if fp is None: return send_json(self, 403, {'error': 'forbidden'})
        if str(fp).startswith(str(SAVES_DIR)) or str(fp).startswith(str(MODS_DIR)):
            return send_json(self, 403, {'error': 'forbidden'})
        return serve_static(self, fp)

    # ---- 具体处理函数 ----
    def _handle_save_file(self, method, sid, rel):
        if not SAVE_ID_RE.match(sid): return send_json(self, 400, {'error': 'bad'})
        segs = rel.split('/')
        for s in segs:
            if not s or s in ('.', '..') or s.startswith('.') or not FILE_NAME_RE.match(s):
                return send_json(self, 400, {'error': 'bad path'})
        base = SAVES_DIR / sid
        if not base.exists(): return send_json(self, 404, {'error': 'no save'})
        fp = safe_join(base, *segs)
        if fp is None: return send_json(self, 403, {'error': 'forbidden'})

        if method == 'GET':
            if not fp.exists(): return send_json(self, 404, {'error': 'not found'})
            return serve_static(self, fp)
        if method == 'PUT':
            fp.parent.mkdir(parents=True, exist_ok=True)
            fp.write_bytes(read_body(self))
            return send_json(self, 200, {'ok': True})
        if method == 'DELETE':
            if fp.is_file(): fp.unlink()
            return send_json(self, 200, {'ok': True})

    def _handle_bundle(self, sid, buf):
        if not SAVE_ID_RE.match(sid): return send_json(self, 400, {'error': 'bad'})
        if len(buf) < 8 or buf[:4] != b'3DM2':
            return send_json(self, 400, {'error': 'bad magic'})
        count = int.from_bytes(buf[6:8], 'little')
        off = 8
        for _ in range(count):
            cx = int.from_bytes(buf[off:off+4], 'little', signed=True); off += 4
            cz = int.from_bytes(buf[off:off+4], 'little', signed=True); off += 4
            dl = buf[off]; off += 1
            dim = buf[off:off+dl].decode('utf-8'); off += dl
            dlen = int.from_bytes(buf[off:off+4], 'little'); off += 4
            data = buf[off:off+dlen]; off += dlen
            if not re.match(r'^[a-zA-Z0-9_-]{1,64}$', dim): continue
            sub = 'chunks' if dim == 'overworld' else f'dims/{dim}/chunks'
            d = SAVES_DIR / sid / sub
            d.mkdir(parents=True, exist_ok=True)
            (d / f'{cx}_{cz}.bin.gz').write_bytes(data)
        return send_json(self, 200, {'ok': True, 'count': count})

    def _import_zip(self, buf, pack):
        tmp = TMP_DIR / f'tmp_{int(time.time()*1000)}'
        tmp.mkdir(parents=True)
        try:
            zp = tmp / 'pack.zip'
            zp.write_bytes(buf)
            with zipfile.ZipFile(zp) as zf:
                zf.extractall(tmp)
            imported_mods = []
            mods_src = tmp / 'mods'
            if mods_src.exists():
                for d in mods_src.iterdir():
                    if not d.is_dir(): continue
                    dst = MODS_DIR / d.name
                    if dst.exists(): shutil.rmtree(dst)
                    shutil.copytree(d, dst)
                    imported_mods.append(d.name)
            if pack:
                meta = {'name': 'imported_pack'}
                mf = tmp / 'modpack.json'
                if mf.exists():
                    try: meta = json.loads(mf.read_text(encoding='utf-8'))
                    except Exception: pass
                return send_json(self, 200, {'ok': True, 'meta': meta, 'mods': imported_mods})
            else:
                saves_src = tmp / 'saves'
                if not saves_src.exists():
                    return send_json(self, 400, {'error': 'no saves dir'})
                subs = [d for d in saves_src.iterdir() if d.is_dir()]
                if not subs: return send_json(self, 400, {'error': 'empty saves'})
                old = subs[0]
                new_id = 'w' + format(int(time.time()*1000), 'x')
                wj = old / 'world.json'
                if wj.exists():
                    try:
                        meta = json.loads(wj.read_text(encoding='utf-8'))
                        meta['id'] = new_id
                        wj.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
                    except Exception: pass
                shutil.copytree(old, SAVES_DIR / new_id)
                return send_json(self, 200, {'ok': True, 'saveId': new_id, 'mods': imported_mods})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _export_modpack(self):
        body = json.loads(read_body(self).decode('utf-8') or '{}')
        mods = body.get('mods', [])
        name = body.get('name', 'MyModpack')
        tmp = TMP_DIR / f'exp_{int(time.time()*1000)}'
        tmp.mkdir(parents=True)
        try:
            (tmp / 'modpack.json').write_text(json.dumps({'name': name, 'mods': mods}, indent=2, ensure_ascii=False), encoding='utf-8')
            dest_mods = tmp / 'mods'
            dest_mods.mkdir()
            for m in mods:
                src = MODS_DIR / m
                if src.exists(): shutil.copytree(src, dest_mods / m)
            zp = tmp / f'{name}.zip'
            with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as zf:
                for p in tmp.rglob('*'):
                    if p.is_file() and p != zp:
                        zf.write(p, p.relative_to(tmp))
            data = zp.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="{quote(name)}.zip"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _export_map(self):
        body = json.loads(read_body(self).decode('utf-8') or '{}')
        sid = body.get('saveId')
        if not SAVE_ID_RE.match(sid or ''): return send_json(self, 400, {'error': 'bad'})
        src = SAVES_DIR / sid
        if not src.exists(): return send_json(self, 404, {'error': 'no save'})
        wj = src / 'world.json'
        try: meta = json.loads(wj.read_text(encoding='utf-8'))
        except Exception: meta = {'name': sid}
        name = meta.get('name', sid)
        plugins = meta.get('plugins', [])
        tmp = TMP_DIR / f'expmap_{int(time.time()*1000)}'
        tmp.mkdir(parents=True)
        try:
            (tmp / 'saves').mkdir()
            shutil.copytree(src, tmp / 'saves' / sid)
            if plugins:
                (tmp / 'mods').mkdir()
                for m in plugins:
                    mp = MODS_DIR / m
                    if mp.exists(): shutil.copytree(mp, tmp / 'mods' / m)
            zp = tmp / f'{name}.zip'
            with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as zf:
                for p in tmp.rglob('*'):
                    if p.is_file() and p != zp:
                        zf.write(p, p.relative_to(tmp))
            data = zp.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="{quote(name)}.zip"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

# ============================================================
# ★ 进程生命周期（解决「关了服务器端口还被占用」）
# ============================================================
PID_FILE = ROOT / '.server.pid'

def _read_ppid():
    try:
        with open('/proc/self/stat', 'r') as f:
            st = f.read()
        return int(st[st.rindex(')') + 2:].split(' ')[1])
    except Exception:
        return 0

def _list_server_procs():
    """列出 3dmc 服务器进程。
    ★ 不用 /proc/net/tcp —— Android 非 root 下读不到（Permission denied），
      同 uid 的 /proc/<pid>/cmdline 才是可靠来源。"""
    out = []
    try:
        pids = [d for d in os.listdir('/proc') if d.isdigit()]
    except Exception:
        return out
    pat = re.compile(r'(?:^|[/\\])(?:server\.js|server\.py|server_cpp|3dmc_server_cpp)$')
    for pid in pids:
        try:
            raw = open('/proc/%s/cmdline' % pid, 'rb').read()
        except Exception:
            continue
        if not raw:
            continue
        argv = [a for a in raw.decode('utf-8', 'replace').split('\0') if a]
        if not argv:
            continue
        if any(pat.search(a) for a in argv):
            out.append((int(pid), ' '.join(argv)))
    return out

def _remove_pid_file():
    try:
        PID_FILE.unlink()
    except Exception:
        pass

if __name__ == '__main__':
    import signal
    print(f'  ✔ Python 服务器启动: http://0.0.0.0:{PORT}')
    print(f'    saves : {SAVES_DIR}')
    print(f'    mods  : {MODS_DIR}')
    print(f'    coremods: {COREMODS_DIR}')

    # 启动前先清理自己上次的残留（Android 上这是唯一能救回端口的手段）
    if os.environ.get('NO_AUTO_KILL') != '1':
        for pid, cmd in _list_server_procs():
            if pid == os.getpid():
                continue
            print(f'  ⚠ 发现上次没退干净的服务器 pid={pid}「{cmd}」，自动结束它…')
            try:
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
        if _list_server_procs():
            time.sleep(0.5)

    try:
        httpd = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    except OSError as e:
        print(f'\n  ✘ 端口 {PORT} 已被占用（{e}）')
        left = [(p, c) for p, c in _list_server_procs() if p != os.getpid()]
        if left:
            for pid, cmd in left:
                print(f'     残留服务器: pid={pid}  {cmd}')
            print('     结束它: kill -9 ' + ' '.join(str(p) for p, _ in left))
        else:
            print('     没找到 3dmc 服务器进程 —— 可能是别的程序占着')
        print(f'     一键清端口: bash stop.sh {PORT}')
        print(f'     换端口:     PORT=8081 bash start.sh python')
        sys.exit(1)

    try:
        PID_FILE.write_text(str(os.getpid()))
    except Exception:
        pass

    def _on_signal(signum, frame):
        print(f'\n[server] 收到信号 {signum}，正在关闭…')
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    for sig in (signal.SIGINT, signal.SIGTERM, getattr(signal, 'SIGHUP', None)):
        if sig is None:
            continue
        try:
            signal.signal(sig, _on_signal)
        except Exception:
            pass

    # 孤儿自动回收：父进程没了就自己退出
    start_ppid = _read_ppid()
    def _parent_watch():
        while True:
            time.sleep(3)
            p = _read_ppid()
            if p and start_ppid > 1 and p != start_ppid:
                print('[server] 父进程已消失，自动退出以释放端口')
                try:
                    httpd.shutdown()
                except Exception:
                    pass
                return
    if start_ppid > 1 and os.environ.get('NO_PARENT_WATCH') != '1':
        threading.Thread(target=_parent_watch, daemon=True).start()

    try:
        httpd.serve_forever()
    finally:
        _remove_pid_file()
        print('已停止')