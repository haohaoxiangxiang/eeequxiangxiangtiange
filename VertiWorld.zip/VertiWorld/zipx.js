'use strict';
/* ============================================================
   zipx.js —— 零依赖 ZIP 读写（Node 内置 zlib 实现）
   ------------------------------------------------------------
   为什么自己写：
     Node 没有内置 zip，原来 server.js 靠 execSync('zip' / 'unzip')，
     而 Termux / 精简环境经常没装 zip（本机就只有 unzip），
     于是"导出地图"和"整合包导入"会直接失败。
   支持：
     · 存储 (method 0) 与 deflate (method 8)
     · 中央目录读取（UTF-8 文件名，bit 11）
     · 打包时自动选 deflate / store（压缩后更大就存储）
   不支持（用不到）：
     · ZIP64、加密、多分卷、zip 内 zip 注释
   ============================================================ */

const zlib = require('zlib');

/* ---------------- CRC32 ---------------- */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++){
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf){
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

/* ---------------- 读 ---------------- */
function findEOCD(buf){
  const min = Math.max(0, buf.length - 65557);
  for (let i = buf.length - 22; i >= min; i--){
    if (buf.readUInt32LE(i) === 0x06054b50) return i;
  }
  return -1;
}

/**
 * 解压 zip（Buffer）→ [{ name, data, isDir }]
 */
function unzipSync(buf){
  if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
  const eocd = findEOCD(buf);
  if (eocd < 0) throw new Error('不是有效的 zip（找不到中央目录）');

  const total = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const out = [];

  for (let i = 0; i < total; i++){
    if (off + 46 > buf.length) break;
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('中央目录损坏');

    const flags   = buf.readUInt16LE(off + 8);
    const method  = buf.readUInt16LE(off + 10);
    const crc     = buf.readUInt32LE(off + 16);
    const csize   = buf.readUInt32LE(off + 20);
    const usize   = buf.readUInt32LE(off + 24);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const cmtLen  = buf.readUInt16LE(off + 32);
    const lho     = buf.readUInt32LE(off + 42);

    const name = buf.toString(flags & 0x800 ? 'utf8' : 'latin1', off + 46, off + 46 + nameLen);
    off += 46 + nameLen + extraLen + cmtLen;

    if (name.endsWith('/')){ out.push({ name, data: Buffer.alloc(0), isDir: true }); continue; }
    if (method !== 0 && method !== 8) continue;   /* 不支持的就跳过，别炸整个包 */

    if (lho + 30 > buf.length) continue;
    if (buf.readUInt32LE(lho) !== 0x04034b50) continue;
    const lNameLen = buf.readUInt16LE(lho + 26);
    const lExtraLen = buf.readUInt16LE(lho + 28);
    const start = lho + 30 + lNameLen + lExtraLen;
    const raw = buf.subarray(start, start + csize);

    let data;
    if (method === 0) data = Buffer.from(raw);
    else {
      data = zlib.inflateRawSync(raw);
      if (data.length !== usize){
        /* 个别打包器把 usize 写 0，按实际解压结果走 */
      }
    }
    if (usize && data.length === usize && crc32(data) !== crc){
      // CRC 不符就当作损坏，坏文件不写进游戏目录
      continue;
    }
    out.push({ name, data, isDir: false });
  }
  return out;
}

/* ---------------- 写 ---------------- */
function dosDateTime(d){
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  return { date: date & 0xFFFF, time: time & 0xFFFF };
}

/**
 * 打包成 zip。
 * @param {Array<{name:string,data:Buffer|string}>} entries
 * @returns {Buffer}
 */
function zipSync(entries){
  const now = dosDateTime(new Date());
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const e of entries){
    if (!e || typeof e.name !== 'string' || !e.name) continue;
    const nameBuf = Buffer.from(e.name, 'utf8');
    const data = Buffer.isBuffer(e.data) ? e.data : Buffer.from(e.data == null ? '' : String(e.data), 'utf8');
    const crc = crc32(data);

    let method = 8;
    let packed = zlib.deflateRawSync(data, { level: 6 });
    if (packed.length >= data.length){ method = 0; packed = data; }

    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);              /* version needed */
    lh.writeUInt16LE(0x800, 6);           /* flags: UTF-8 文件名 */
    lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(now.time, 10);
    lh.writeUInt16LE(now.date, 12);
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(packed.length, 18);
    lh.writeUInt32LE(data.length, 22);
    lh.writeUInt16LE(nameBuf.length, 26);
    lh.writeUInt16LE(0, 28);

    locals.push(lh, nameBuf, packed);

    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(20, 4);              /* version made by */
    ch.writeUInt16LE(20, 6);              /* version needed */
    ch.writeUInt16LE(0x800, 8);
    ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(now.time, 12);
    ch.writeUInt16LE(now.date, 14);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(packed.length, 20);
    ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(nameBuf.length, 28);
    ch.writeUInt16LE(0, 30);              /* extra */
    ch.writeUInt16LE(0, 32);              /* comment */
    ch.writeUInt16LE(0, 34);              /* disk */
    ch.writeUInt16LE(0, 36);              /* internal attr */
    ch.writeUInt32LE(0, 38);              /* external attr */
    ch.writeUInt32LE(offset, 42);         /* local header offset */

    centrals.push(ch, nameBuf);
    offset += lh.length + nameBuf.length + packed.length;
  }

  const centralBuf = Buffer.concat(centrals);
  const localBuf = Buffer.concat(locals);

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  const n = centrals.length / 2;
  eocd.writeUInt16LE(n, 8);
  eocd.writeUInt16LE(n, 10);
  eocd.writeUInt32LE(centralBuf.length, 12);
  eocd.writeUInt32LE(localBuf.length, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([localBuf, centralBuf, eocd]);
}

module.exports = { zipSync, unzipSync, crc32 };
