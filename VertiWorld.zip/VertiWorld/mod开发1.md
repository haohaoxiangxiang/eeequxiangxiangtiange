# 深入世界 VertiWorld Mod 开发 · 卷一：入门与核心 API

> 适用宿主 **API v4**。本套文档把原来的 `MOD开发文档.md`、`mod开发补充.md`、
> `coremods开发.txt` 合并重排，并按当前源码重新核对了一遍。
>
> | 卷 | 内容 |
> |---|---|
> | **卷一（本文）** | 快速开始、manifest、生命周期、`G` 总览、世界读写、事件、Hook、输入独占、性能、限制 |
> | [卷二](mod开发2.md) | 内容注册：方块/配方/群系/生成器/维度/实体/音效/移动/液体/状态、世界类型、实体分级、存档、示例、API 速查 |
> | [卷三](mod开发3.md) | 版本兼容变化、扩展 API（B 类）、三份反馈对照、整合包与地图、Coremod |
>
> 最近核对：2026-11-05。以本套三卷为准；旧文档里的过时说法已在卷三「兼容与版本变化」逐条修正。

## 本卷目录

1. [快速开始](#1-快速开始)
2. [目录结构与 manifest](#2-目录结构与-manifest)
3. [生命周期](#3-生命周期)
4. [宿主 API `G` 总览](#4-宿主-api-g-总览)
5. [世界读写与方块变化](#5-世界读写与方块变化)
6. [事件表](#6-事件表)
7. [Hook](#7-hook)
8. [输入独占](#8-输入独占)
9. [性能须知](#9-性能须知)
10. [常见问题与调试](#10-常见问题与调试)
11. [已知限制](#11-已知限制)

---

## 1. 快速开始

```
mods/hello/
├── manifest.json
└── main.js
```

`manifest.json`：

```json
{
  "id": "hello",
  "name": "Hello Mod",
  "version": "1.0.0",
  "apiVersion": 4,
  "entry": "main.js"
}
```

`main.js`：

```js
export default {
  onEnable(saveId, meta, G){
    G.log.info('Hello from', saveId);

    const un = G.on('block.break', (x, y, z, id) => {
      G.log.info('玩家挖了方块', id, '在', x, y, z);
    });

    this._unsubs = [un];
  },
  onDisable(saveId){
    for (const un of this._unsubs) un();
  }
};
```

**验证**：把 `mods/hello/` 放进项目根目录，进任意世界，挖一块方块，控制台应出现日志。

---

## 2. 目录结构与 manifest

```
mods/
└── <mod id>/
    ├── manifest.json     ← 必须
    ├── main.js           ← 入口（可在 manifest.entry 改）
    ├── worldgen.js       ← 可选：给 Worker 用的生成器（见卷二 1.8）
    ├── icon.png          ← 可选：列表页图标
    ├── sounds/           ← 可选：音效文件
    └── …其他文件
```

**mod id 规则**：`^[a-zA-Z0-9_-]{1,64}$`，且**目录名必须等于 `manifest.id`**（不一致会被服务器忽略）。

### manifest.json 全字段

```jsonc
{
  // ===== 必需 =====
  "id": "my_mod",              // 唯一标识，等于目录名
  "name": "我的 Mod",           // 显示名
  "version": "1.0.0",          // 语义化版本（依赖约束会读它）
  "apiVersion": 4,             // 你用到的最低宿主 API 版本
  "entry": "main.js",          // 入口文件（相对 mod 目录）

  // ===== 推荐 =====
  "author": "你的名字",
  "description": "一句话简介（列表页显示）",

  // ===== 详情页可选 =====
  "icon": "icon.png",
  "longDescription": "支持简单 Markdown",
  "changelog": "1.0.0  首次发布",
  "license": "MIT",
  "homepage": "https://…",

  // ===== 功能元数据 =====
  "permissions": ["player.pos.read"],   // 预留，暂不强制
  "dependencies": ["other_mod_id"],     // 依赖，见下方「加载器 v2」
  "shortcuts": [{ "key": "T", "action": "切换维度" }],
  "contents": { "blocks": 12, "entities": 3, "dimensions": 1 },  // UI 统计
  "worldTypes": [ /* 见卷二第 2 节 */ ]
}
```

### apiVersion 用 `>=` 判断

| 宿主 | 你的 apiVersion | 结果 |
|---|---|---|
| 4 | 1 | ✅ 加载（老 mod 兼容） |
| 4 | 4 | ✅ 加载 |
| 4 | 5 | ❌ 拒绝（宿主太老） |

```js
if (G.apiVersion < 4) throw new Error('需要 API v4+');
```

**不要写 `G.apiVersion === 4`** —— API 只会往上加。

### 加载器 v2：依赖版本与级联跳过

`dependencies` 支持两种写法，可以混用：

```json
{
  "dependencies": [
    "raftcore",
    { "id": "raftworld", "version": ">=0.2.0" },
    { "id": "create_lite", "optional": true }
  ]
}
```

| 字段 | 类型 | 含义 |
|---|---|---|
| `id` | string | 依赖的 mod id |
| `version` | string | 版本约束 |
| `optional` / `soft` | bool | 可选依赖：缺失时不报 warning，缺失也不阻止加载 |

版本运算符：

| 运算符 | 实际行为 |
|---|---|
| `>=` `<=` `>` `<` `=` | 正常比较 |
| `^` `~` | **当前实现只做 `>=`**，不锁上界 |

> 注意：`^1.2.3` 和 `~1.2.3` 在本宿主里都等价于 `>=1.2.3`，
> 不是 npm 的"major/minor 不变"语义。要限制上界请用 `<=`。

加载器行为：

- **拓扑排序**：先加载依赖，再加载依赖它的 mod；同层级按 `world.json` 里 `plugins` 的原顺序。
- **缺失依赖**：写进 warnings（`optional` 不报），**不会自动帮你启用依赖**。
- **依赖版本不满足**：该 mod 加载失败（`reason: "dep_version"`）。
- **级联跳过**：A 依赖 B，B 加载失败/被跳过 → A 也跳过（`reason: "dependency_failed"`）。
- **依赖环**：只记录 warning（`kind: "cycle"`），环内 mod **仍然会加载**，不会自动跳过。

运行日志示例：

```
[loader] ⚠ 依赖环: mod_a → mod_b → mod_a
[loader] "my_mod" 跳过: 依赖 "raftcore" 加载失败
[loader] 加载完成: 10 成功 / 1 失败 / 2 跳过 / 1 警告
```

**Mod 状态面板**（暂停菜单 → Mod 状态）会分四色显示：

| 颜色 | 图标 | 含义 |
|---|---|---|
| 绿 | ✓ | 加载成功 |
| 黄 | ⚠ | 警告（依赖环 / 缺失依赖 / 未知 hook） |
| 紫 | ⏸ | 跳过（依赖失败被级联） |
| 红 | ✗ | 加载失败（有具体错误） |

---

## 3. 生命周期

宿主调用 `export default { … }` 里的方法。

### `onEnable(saveId, meta, G)`

加载 mod 时调用，宿主会 `await`，所以可以写成 `async`。

- `saveId` 当前存档 id
- `meta` 你的 manifest（含 `worldOptions`，见卷二第 2 节）
- `G` 宿主门面（也等于 `window.__GAME__`）

**所有副作用必须放这里，不能放模块顶层** —— 浏览器 ESM 会缓存模块，切存档时顶层代码不会重跑：

```js
// ❌ 错：切存档后不会重新执行
scene.add(myMesh);
G.on('game.tick', fn);

// ✅ 对
export default {
  onEnable(saveId, meta, G){
    this._scene = G.scene;
    this._mesh = buildMesh();           // 先建 mesh
    this._scene.add(this._mesh);
    this._un = G.on('game.tick', fn);
  },
  onDisable(){ this._un(); this._scene.remove(this._mesh); }
};
```

### `onDisable(saveId)`

切存档 / 回主菜单时调用。清理事件订阅、DOM、3D 对象、定时器、Hook。

### 旧式回调（不要使用）

`onBlockBreak(x, y, z, blockId)` / `onBlockPlace(x, y, z, blockId)` 是旧版宿主的写法。
**当前加载器不会再调用它们**，也不能 `return true` 取消。
请一律用 `G.on('block.break' / 'block.place')`（见第 6 节）。

### 错误隔离

一个 mod 抛错不影响其他 mod，也不影响游戏本体。宿主会 `catch` 并记录到「暂停菜单 → Mod 状态」。

---

## 4. 宿主 API `G` 总览

### 版本与信息

```js
G.apiVersion     // 数字
G.version        // 游戏版本字符串
G.info           // { apiVersion, gameVersion, blockCount, hookCount, eventCount,
                 //   generatorCount, biomeCount, entityCount, dimensionCount,
                 //   disabledEntityAi, installedAt }
```

`G.info.disabledEntityAi` 是**因连续异常被停用 AI 的实体类型**列表（见卷二 4.4）。

### 引擎与数据

```js
G.THREE    G.BLOCKS    G.B    G.scene    G.camera    G.renderer
```

### 游戏对象

```js
G.player    G.inventory    G.input
```

`G.inventory` 就是长度 36 的数组（`0~8` 是快捷栏），直接读写成 `{ id, count, durability?, meta? }`。
**改完要 `G.notifyInventory()`**，否则 UI 不会刷新。

`G.player`（直接引用，改了就生效，但**别替换整个对象**）：

| 字段 | 类型 | 说明 |
|---|---|---|
| `pos` | `{x,y,z}` | 脚底坐标。改完注意区块加载/碰撞 |
| `vel` | `{x,y,z}` | 速度，单位 格/秒 |
| `yaw` `pitch` | 弧度 | 朝向（pitch 正数是抬头） |
| `mode` | `'survival'` \| `'creative'` | 游戏模式 |
| `flying` `onGround` `inWater` `wasInWater` `inLava` | bool | 状态位 |
| `health` `maxHealth` | 数字 | 血量（默认 20） |
| `hunger` `maxHunger` | 数字 | 饱食度（默认 20） |
| `breath` `maxBreath` | 数字 | 氧气 |
| `takeDamage(n)` `heal(n)` | 方法 | **实际不存在**；扣血/回血请用 `G.damagePlayer(n)` / `G.heal(n)` |
| `eatFood(food, sat)` | 方法 | 加饱食度 |
| `serialize()` `deserialize(o)` | 方法 | **实际不存在**；存档由宿主直接读写对象字段 |

> 想让伤害**可以被 mod 改**，用 `G.hook('player.damage')`（见第 7 节），别直接改 `health`。
> 想读/改别人东西优先用 `G.getPlayer()` / `G.damagePlayer()` / `G.heal()` / `G.teleport()`。

`G.input`（只读为主，**写它会直接改变玩家这一帧的输入**；抢输入请用第 8 节的输入独占）：

| 字段 | 说明 |
|---|---|
| `joyX` `joyY` | 摇杆方向 −1~1 |
| `yawDelta` `pitchDelta` | 视角增量（鼠标/触屏拖动写入，宿主每帧清零） |
| `mouseLeft` `mouseRight` | 鼠标左右键状态（宿主每帧写回） |
| `jump` `sneak` `sprintToggle` | 跳跃/潜行/疾跑开关状态 |
| `mine` `place` | 挖掘 / 放置（持续按住；也可来自 `uiMine`/`uiUse` 屏幕按钮） |
| `uiMine` `uiUse` | 屏幕上「左键 / 右键」按钮状态 |
| `tap` `tapScreen` `mineScreen` | 触屏短按 / 触点落点（宿主消费后清零，一般只读） |
| `bowHold` `bowRelease` `bowEquipped` | 蓄力弓状态 |
| `doubleJump` `toggleFly` `toggleInv` `resetPos` | 动作触发标志 |
| `selectSlot` | 选中的快捷栏槽位，−1 表示无 |
| `keys` `actions` | 键盘原始状态对象 / 绑定动作的按下状态 |
| `consume(name)` | 输入独占（见第 8 节） |

### 准星与手持

```js
const t = G.getLookTarget(6);
// → { pos:{x,y,z}, face:'top'|'bottom'|'north'|'south'|'east'|'west',
//     normal:{x,y,z}, blockId } | null
const slot = G.getHeldSlot();       // 0~8
const held = G.inventory[slot];
```

`G.getLookTarget()` 从**摄像机**沿视线打体素射线；没有目标返回 `null`。
比 `G.raycast()` 多了 `face`/`normal`，做"按玩家看的哪一面放置"很方便。

### UI 扩展：往原版面板里塞 DOM

```js
G.ui.addInventoryWidget('<div class="tip">我的说明</div>');  // 背包面板底部
G.ui.addChestWidget(html);                                    // 箱子面板底部
G.ui.addFurnaceWidget(html);                                  // 熔炉面板底部
```

三个都是 `insertAdjacentHTML('beforeend')`。容器在**每次打开面板时被清空**
（同时发 `ui.inventory.open` / `ui.chest.open` / `ui.furnace.open`），
所以正确姿势是**监听事件再注入**，而不是 `onEnable` 时塞一次：

```js
G.on('ui.inventory.open', () => G.ui.addInventoryWidget('<b>我的按钮</b>'));
```

> `html` 是字符串，注意转义玩家可控的数据（mod 存储里的名字之类）。

### UI 安全区：别和自己的浮动按钮打架

```js
const areas = G.ui.getSafeAreas();
// {
//   joystick, sideButtons, hotbar, topBar, hearts, hunger,   // 各为矩形或 null
//   viewport: { left:0, top:0, right, bottom, w, h },
// }
```

每个矩形是 `{ left, top, right, bottom, w, h }`（视口像素）。元素不存在（桌面端/关触屏）时是 `null`。
用于把 mod 自己的悬浮面板放到不挡摇杆/快捷栏的位置。

### 3D 对象绑定（方块实体的"看得见的那部分"）

```js
G.attachVisual(x, y, z, obj3d);   // 把 THREE.Object3D 挂到方块坐标（自动居中 + 加到 scene）
G.detachVisual(x, y, z);          // 摘掉并 dispose
```

同一个坐标重复 `attachVisual` 会先摘掉旧的。方块被破坏时宿主**不会**自动帮你摘——
在 `block.break` / `world.blockChanged` 里调 `G.detachVisual`。

### 方块实体数据（每个坐标一份 JSON）

```js
G.setBlockData(x, y, z, obj);     // 存（obj 必须可 JSON 序列化）
G.getBlockData(x, y, z);          // 读，没有返回 null
G.removeBlockData(x, y, z);       // 删
```

坐标会自动取整。数据跟着存档走（存进 `saves/<id>/data/`），**和方块本身不绑定**：
方块被拆掉后数据还在，需要自己 `removeBlockData`。

### 常量（动态读，不要缓存）

```js
G.CS          // 16
G.CHH         // 世界顶部 y
G.Y_MIN       // 世界底部 y
G.SEA_LEVEL   // 海平面（46）
G.INV_SIZE    // 36
G.STACK_MAX   // 64
```

### 分类速查

| 分组 | 成员 |
|---|---|
| 读世界 | `getBlock` `getBlockEx` `getBlockName` `heightAt` `biomeAt` `getChunkStats` `worldApi` |
| 写世界 | `setBlock` `setBlockByName` `fillBox` `batch` |
| 物品 | `give` `addItem` `takeFromSlot` `spawnDrop` `drops` `notifyInventory` |
| 玩家 | `getPos` `getHeldSlot` `getLookTarget` `teleport` `heal` `damagePlayer` `setMode` `getPlayer` |
| 事件 | `on` `off` `once` `emit` `listenerCount` `listEvents` |
| Hook | `hook` `listHooks` `isHooked` |
| 存档 | `saveId` `storage` `getWorldOptions` `getSeed` `getSaveType` |
| 注册 | `registerBlock` `registerRecipe` `registerSmelt` `removeSmelt` `setFuel` `registerSound` `unregisterSound` `registerBiome` `registerGenerator` `setActiveGenerator` `registerDimension` `registerEntity` |
| 实体 | `spawnEntity` `removeEntity` `setEntityLoot` `damageEntity` `getEntityAt` `listEntityTypes` `getAllEntityTypes` `getEntityType` `hasEntityType` `getSpawnableTypes` `getEntityTypeCount` `getAnimalCount` |
| 实体上限/分级 | `setEntityCap` `getEntityCap` `listEntityCaps` `getEntityCounts` `getEntityCountByType` `getTypesByCategory` `setTickDistances` `getTickDistances` |
| 维度 | `switchDimension` `getActiveDimensionId` `getActiveDimension` `listDimensions` `hasDimension` `getDimension` `getDimensionCount` |
| 生成器 | `getGenerator` `listGenerators` `getActiveGenerator` `getActiveGeneratorId` `getGeneratorHeightLimit` |
| 群系 | `getBiome` `getBiomeByName` `listBiomes` |
| 天空 | `setSkyPreset` `getSkyPreset` `setBiomeFog` |
| 音效 | `registerSound` `unregisterSound` `loadSound` `playSound` `playSoundAt` `stopAllSounds` |
| 创造面板分类 | `registerCreativeCategory` `listCreativeCategories` `getCreativeCategory` |
| 查询 | `listRecipes` `listSmelts` `getAtlasUsage` |
| 世界查询 | `getTerrainHeight` `isSolidAt` `isWaterAt` `isLavaAt` `isLoadedAt` `raycast` |
| 流体 | `getFluidLevel` `setFluidLevel` `getFluidSource` `createFluidSource` `removeFluidSource` `setFluidConfig` `getFluidConfig` `resetFluidConfig` `wakeFluid` |
| 批量写 | `batch` `setBlockData` `getBlockData` `removeBlockData` |
| 方块 tick | `scheduleBlockTick` `cancelBlockTick` `cancelBlockTicksAt` `getBlockTickCount` |
| 可视化 | `attachVisual` `detachVisual` `setWaterRenderMode` |
| UI 扩展 | `ui.addInventoryWidget` `ui.addChestWidget` `ui.addFurnaceWidget` `ui.getSafeAreas` |
| 日志 | `G.log.info/warn/error` |

### 日志

```js
G.log.info(...)    // [mod] 蓝字
G.log.warn(...)    // 黄字
G.log.error(...)   // 红字
```

---

## 5. 世界读写与方块变化

### 读

```js
G.getBlock(x, y, z)        // → 数字 id（0 = 空气）
G.getBlockName(x, y, z)    // → 名字字符串
G.heightAt(x, z)           // → 该列地表高度
G.biomeAt(x, z, h)         // → 群系 id
```

> ⚠️ **未加载的区块 `getBlock` 返回 0**，和「空气」无法区分。
> 用 `G.isLoadedAt(x,y,z)` 或 `G.getBlockEx(x,y,z)` 区分。

```js
const r = G.getBlockEx(x, y, z);
// { id: 0, loaded: false }  → 未加载（id 无意义）
// { id: 0, loaded: true }   → 真的空气
// { id: 3, loaded: true }   → 石头
```

### 环境查询 `G.worldApi`

一个轻量对象，专门给"判断某个位置是什么"用（实体 AI 内部也用同一个）：

```js
G.worldApi.isSolid(x, y, z)        // 是否实心（碰撞）
G.worldApi.getBlock(x, y, z)       // → id
G.worldApi.blockAt(x, y, z)        // → block 对象
G.worldApi.isWaterAt(x, y, z)      // 是否水
G.worldApi.isLiquidAt(x, y, z)     // 是否任何液体
G.worldApi.heightAt(x, z)          // 地表高度
G.worldApi.collideAnimalAt(x, y, z, w, h)   // AABB 是否碰撞
G.worldApi.moveWithCollision(entity, dt)    // 带碰撞的位移（实体 AI 用）
G.worldApi.SEA_LEVEL  G.worldApi.Y_MIN
G.worldApi.gravity    G.worldApi.stepJump
```

### 写

```js
G.setBlock(x, y, z, id)                       // 直接写
G.setBlock(x, y, z, id, { noRecord: true })   // 不写进存档编辑表（派生状态）
G.setBlock(x, y, z, id, { silent: true })     // 不发 world.blockChanged
G.setBlockByName(x, y, z, 'stone')            // 按名字写，返回 bool
G.fillBox(x1,y1,z1, x2,y2,z2, id)             // 填盒子，上限 262144 格
```

| opts | 作用 |
|---|---|
| `noRecord` | 只改当前内存区块，不落进存档编辑表。适合积雪这类"可由种子/温度重新推导"的状态；玩家建筑、mod 机器状态**不要**用，否则下次加载会消失 |
| `silent` | 不触发 `world.blockChanged`（也不会调用内部 `onBlockChanged` 回调）。用于自己的连锁写入避免递归 |

### 查询辅助

| API | 返回 | 说明 |
|---|---|---|
| `G.heightAt(x, z)` | 数字 | **生成器**给出的地表高度。纯函数：不需要区块加载，也**不反映**玩家挖填 |
| `G.getTerrainHeight(x, z)` | 数字 | 已加载区块里记录的**顶面 y**（`chunk.topY`，随区块数据更新）；**区块没加载时返回 `-1`** |
| `G.isSolidAt(x, y, z)` | bool | 方块存在且 `solid` |
| `G.isWaterAt(x, y, z)` | bool | 是水（`liquid` 且名字 `water`） |
| `G.isLavaAt(x, y, z)` | bool | 是岩浆 |
| `G.isLoadedAt(x, y, z)` | bool | 这个坐标所在区块**已经加载** |
| `G.getBlockEx(x, y, z)` | `{id, loaded}` | 同时给出 id 与加载状态 |
| `G.raycast(maxDist)` | `{ x, y, z, id, nx, ny, nz }` \| null | 从**摄像机**沿视线打一条体素射线（默认 6 格） |
| `G.getLookTarget(maxDist)` | `{ pos, face, normal, blockId }` \| null | 同上，但带命中面/法线 |
| `G.getChunkStats()` | 对象 | 区块加载/网格队列统计 |

> 都有坐标取整，传小数不会炸。

### 批量写：`G.batch(fn)`

```js
G.batch(() => {
  for (let x = 0; x < 32; x++)
    for (let z = 0; z < 32; z++)
      G.setBlock(x, 70, z, G.B.stone.id);
});
```

包在里面的 `setBlock` **只结算一次网格重建**，几千次写入也只触发一轮。
实现上靠 `chunk.batch:start` / `chunk.batch:end` 两个事件标记区间（可嵌套）。
一次性造建筑/大规模挖空务必用它，否则会卡成幻灯片。

### 水体渲染模式

```js
G.setWaterRenderMode('vanilla' | 'none');
```

`'none'` 会跳过水面网格（看不到水但数据/碰撞仍在）；默认 `'vanilla'`，其他值等同 vanilla。

### 流体：液位与源头

```js
G.getFluidLevel(x, y, z)          // 液位 0~8
G.setFluidLevel(x, y, z, lv)      // 写液位
G.getFluidSource(x, y, z)         // 源头标记 0/1
G.createFluidSource(x, y, z, id)  // 创建源头（水/岩浆的 block id）
G.removeFluidSource(x, y, z)      // 移除源头
```

做"水泵、潮汐、波浪海面"需要读真实液位时用这组接口。
注意：改液位只是改数据，是否继续流动由流体模拟器决定；要让某格重新排队用 `G.wakeFluid`。

### 什么操作会发什么事件

| 操作 | 触发 |
|---|---|
| `G.setBlock` / `fillBox` / 连锁挖断 / 流体 | `world.setBlock` hook、**`world.blockChanged`** |
| 玩家主动挖掘 | `block.break`（含创造模式） |
| 玩家主动放置 | `block.place` |

> **`G.setBlock` 不会发 `block.place` / `block.break`**（这两个事件只代表"玩家操作"）。
> 想监听**任何来源**的方块变化，用 `world.blockChanged`。

### `world.blockChanged`

```js
G.on('world.blockChanged', (x, y, z, oldId, newId) => { … });
```

挂在**所有方块写入的唯一入口**上，任何来源都会经过：

| 场景 | 判定 |
|---|---|
| 方块被移除 | `newId === 0` |
| 方块被替换 | `oldId !== newId` |
| 同值重写 | **不触发** |

⚠️ 在监听器里再调 `G.setBlock` 会重入，注意加保护避免无限递归（或用 `{ silent: true }`）。

**典型用途**：方块没了就清理自己绑定的 3D 对象 / 状态。

```js
G.on('world.blockChanged', (x, y, z, oldId, newId) => {
  if (newId !== 0 && newId === G.B.my_block.id) return;
  const key = x + ',' + y + ',' + z;
  const obj = myVisuals.get(key);
  if (obj){ G.scene.remove(obj); myVisuals.delete(key); }
});
```

### 方块计划 tick（`scheduleBlockTick`）

给某个坐标安排一个"到点执行"的回调，类似 MC 的 scheduled tick。
适合作物生长、机器周期、传送门预热、方块融化等需要**按时间推进**的逻辑。

```js
// 20 tick = 1 秒；返回 tickId
const id = G.scheduleBlockTick(x, y, z, 20, (ctx) => {
  // ctx = { x, y, z, blockId, dimension, tick, id }
  G.log.info('1 秒到了，这里是', ctx.blockId);
  // return true → 按原间隔继续；不 return / return false → 结束
});

G.cancelBlockTick(id);                 // → bool
G.cancelBlockTicksAt(x, y, z);         // 取消该坐标全部 tick，→ 数量
G.getBlockTickCount();                 // 当前待执行数量
```

| 规则 | 说明 |
|---|---|
| 时间单位 | tick（20 TPS，与帧率无关）；最小 1，最大 12000（10 分钟） |
| 执行条件 | 只在该坐标所在**区块已加载**时执行；未加载会冻结，区块回来立刻补跑 |
| 重复 | 回调 `return true` 就按原间隔继续调度 |
| 维度 | 默认调度时所在维度；`opts.dimension` 可指定 |
| 异常 | 回调抛错会被捕获并**自动取消该 tick** |
| 上限 | 单 tick 最多执行 256 个回调；卡顿帧最多追 5 tick |

```js
// 例：注册方块后，让它每 2 秒检查一次附近有没有水
G.on('block.place', (x, y, z, id) => {
  if (id !== G.B.my_machine.id) return;
  G.scheduleBlockTick(x, y, z, 40, (ctx) => {
    if (G.getBlock(ctx.x, ctx.y, ctx.z) !== G.B.my_machine.id) return false;
    if (G.isWaterAt(ctx.x, ctx.y + 1, ctx.z)) G.log.info('机器进水了');
    return true;
  });
});
```

> 方块被拆掉后 tick 不会自动取消，回调里请自己判断 `ctx.blockId`，
> 或者在 `block.break` 里调 `G.cancelBlockTicksAt`。

---

## 6. 事件表

用 `G.on(名称, handler)` 订阅，参数按顺序传入。以下**全部对照源码核过**。

### 主循环

| 事件 | 参数 | 时机 |
|---|---|---|
| `game.tick` | `(dt)` | **每帧**，早于玩家更新。慎用，**别在里面 log** |

> `game.tick` 在 `updatePlayer()` **之前**。想在玩家更新之后修正位置，用 `G.hook('player.update').after(...)`。

### 世界

| 事件 | 参数 |
|---|---|
| `world.load` | `(save, isNew)` |
| `world.enter` | `(save)` |
| `world.create` | `(meta)` |
| `world.save` | `(saveId, save)` |
| `world.leave` | `(saveId)` |
| `chunk.decorate` | `(chunk, api)` |
| `world.blockChanged` | `(x, y, z, oldId, newId)` |
| `chunk.batch:start` / `chunk.batch:end` | `()` |
| `chunk.update:done` | `(loadedChunkCount)` |
| `chunk.mesh:build` | `(chunk)` |
| `chunk.mesh:install` | `(chunk, groups, meshBuilder)` |
| `chunk.mesh:unload` | `(chunk)` |
| `generator.activeChanged` | `(id)` |
| `bubble` | `(x, y, z, count, info)` |

### `chunk.decorate` 的 api

区块生成完、建网格之前触发。**写入不记存档 edits、不发事件**，适合放结构/植被。

```js
G.on('chunk.decorate', (chunk, api) => {
  api.cx, api.cz                 // 区块坐标
  api.get(lx, ly, lz)            // → id（局部坐标 0~15）
  api.set(lx, ly, lz, id)        // 写，返回 bool
  api.setName(lx, ly, lz, 'sand')
  api.setWorld(wx, wy, wz, id)   // 世界坐标写，可跨区块（未加载会排队）
  api.setWorldName(wx, wy, wz, 'sand')
  api.topY(lx, lz)               // 该列地表高度
  api.getSeed()                  // 世界种子
});
```

本区块内用 `api.set/setName`。跨区块（树冠、建筑）用 `api.setWorld/setWorldName`：
目标区块已加载会直接写入并标脏；还没加载会排队，等它首次生成时再落地，不会丢。
这些写入同样**不记存档 edits**，但随着区块一起保存。

### 方块

| 事件 | 参数 |
|---|---|
| `block.break` | `(x, y, z, id, willDrop)` —— **可取消**（`return true` 阻止破坏） |
| `block.place` | `(x, y, z, id, facing)` —— **可取消**（`return true` 阻止放置；水面/水草路径可能没有 `facing`） |
| `block.registered` | `(block)` |
| `fluid.tick:before` | `(x, y, z, blockId)` —— **可取消**，跳过该格这次流动 |
| `fluid.spread:before` | `(nx, ny, nz, fluidId, spreadLevel)` —— **可取消**，阻止流向该格 |

### 玩家

| 事件 | 参数 |
|---|---|
| `player.jump` | `(x, y, z)` |
| `player.land` | `(x, y, z, fallSpeed)` |
| `player.damage` | `(amount, health, prevHealth)` |
| `player.death` | `(respawnX, respawnZ)` |
| `player.enterWater` / `player.exitWater` | `(x, y, z)` |
| `player.modeChange` | `(mode)` |
| `player.eat` | `(blockId, label)` |
| `player.damage:before` | `(amount, health)` —— 结算**前**，用于观察/记录 |
| `player.update:head` | `(dt, input)` |
| `player.update:gravity` | `(dt, vel)` |
| `player.update:collision` | `(dt, pos, vel)` |
| `player.update:tail` | `(dt, player)` |
| `status.apply` | `(id, inst)` |
| `status.remove` | `(id, reason, inst)` —— `reason` 为 `expire` / `manual` / `clear` / `world.load` / `reset` |

### 物品

| 事件 | 参数 |
|---|---|
| `item.pickup` | `(id, count, x, y, z, meta)` —— 成功进背包后 |
| `item.canPickup` | `(id, count, x, y, z, meta)` —— **可取消**，`return true` 让掉落物继续留在地上 |
| `item.drop` | `(id, count, x, y, z, meta)` |
| `item.craft` | `(id, count)` —— 合成成功后 |
| `item.craft:before` | `(resultId, count, craftSize)` —— **可取消** |
| `item.smelt` | `(fromId, toId, x, y, z)` |
| `ui.inventory.open` | `(extEl)` |
| `ui.chest.open` | `(extEl, x, y, z)` |
| `ui.furnace.open` | `(extEl, x, y, z)` |

### 实体

| 事件 | 参数 |
|---|---|
| `entity.registered` | `(id, type)` |
| `entity.spawned` | `(entity)` |
| `animal.spawn` | `(entity)` |
| `animal.damage` | `(entity, amount, source)` —— 实际扣血后 |
| `entity.damage:before` | `(entity, amount, source)` —— **可取消** |
| `animal.death` | `(entity)` |
| `entity.update:before` | `(animal, dt)` |
| `entity.update:after` | `(animal, dt)` |

### 熔炉

| 事件 | 参数 |
|---|---|
| `furnace.ignite` | `(x, y, z, fuelId, seconds)` |
| `furnace.removed` | `(x, y, z, state)` |

### 箱子

| 事件 | 参数 | 说明 |
|---|---|---|
| `chest.open` | `(x, y, z, dimId)` | 玩家打开箱子界面（**文件已读完**才发） |
| `chest.close` | `(x, y, z, dimId)` | 关闭界面，此时内容已写盘 |

> 箱子是**内置方块实体**：27 格，每箱一个存档文件
> `saves/<saveId>/chests/<dimId>/<x>_<y>_<z>.json`。
> mod 可以直接整箱读写（异步）：
>
> ```js
> const slots = await G.getChestItems(x, y, z, dimId);
> // → 长度 27 的数组，空槽 null，其余 { id, count, durability? }
>
> await G.setChestItems(x, y, z, [
>   { name: 'stone', count: 16 },
>   { id: G.B.diamond.id, count: 1 },
> ], dimId, { merge: false });   // 第 5 位是维度，第 6 位才是 opts
> // merge:true = 追加（按堆叠规则合并），默认清空后按顺序填槽
> ```

### 系统

| 事件 | 参数 |
|---|---|
| `host.ready` | `(G)` |
| `atlas.changed` | `(usage)` |
| `mod.loaded` / `mod.unloaded` / `mod.reloaded` | `(id, meta, instance)` |
| `mod.load_failed` | `(id, meta, error)` |
| `generator.registered` | `(id, gen)` |
| `biome.registered` | `(name, biome)` |
| `dimension.registered` | `(id, dim)` |
| `dimension.change` | `(fromId, toId)` |
| `sky.presetChanged` | `(preset)` |

> 事件名没有白名单，`G.emit('my.event', …)` 可以自定义。
> 想知道当前有哪些事件在活跃：

```js
G.listEvents()      // → 有监听者的事件名数组
G.listenerCount('player.jump')   // → 这个事件有几个监听者
```

### 可取消事件（返回值能拦住原版行为）

绝大多数事件是"通知"，返回值没人看。**只有这一类例外**：宿主用
`emitCancellable()` 派发，监听函数 **`return true` 就会拦下原版动作**。

| 事件 | 参数 | `return true` 的效果 |
|---|---|---|
| `block.break` | `(x, y, z, id, willDrop)` | **取消这次破坏**：方块保留、不扣耐久、不掉落 |
| `block.place` | `(x, y, z, id, facing)` | **取消这次放置**：不写世界、不扣物品、不发音效 |
| `block.interact` | `(x, y, z, hitBlockId, nx, ny, nz)` | **取消这次放置**（排在开箱子/熔炉/工作台之后） |
| `entity.damage:before` | `(entity, amount, source)` | **取消这次实体伤害** |
| `item.canPickup` | `(itemId, count, x, y, z, meta)` | **取消这次拾取**：物品继续留在地上 |
| `item.craft:before` | `(resultId, count, craftSize)` | **取消这次合成**：材料不消耗、结果不进背包 |
| `fluid.tick:before` | `(x, y, z, blockId)` | 跳过该格这次流动（不自动重试） |
| `fluid.spread:before` | `(nx, ny, nz, fluidId, spreadLevel)` | 阻止流向该格 |

### `block.break` / `block.place` 的拦截时机

| 事件 | 触发时机 | 说明 |
|---|---|---|
| `block.break` | 硬度检查通过后、取熔炉/箱子内容与连锁清除**之前** | 创造模式 `willDrop` 固定是 `false`；生存模式是实际掉落语义 |
| `block.place` | 所有朝向/支撑/碰撞/重叠检查通过后、`setBlockWorld` **之前** | 水草、水面、双层草、普通方块、液体等所有放置路径都会触发 |

```js
// 例：保护区里禁止挖掘和放置
G.on('block.break', (x, y, z, id, willDrop) => {
  if (isProtected(x, z)){
    G.log.info('这里不能破坏');
    return true;              // ← 方块原地保留
  }
});

G.on('block.place', (x, y, z, id) => {
  if (isProtected(x, z)){
    G.log.info('这里不能建造');
    return true;              // ← 不放下这块
  }
});
```

`block.interact` 的触发点在 `tryPlace()` 里，而且**排在原版交互之后**：

```
玩家点"放置"
 ├─ 目标是工作台  → 开合成面板，return（不触发本事件）
 ├─ 目标是熔炉    → 开熔炉，  return
 ├─ 目标是祭坛    → 存取魔法水晶，return
 ├─ 目标是箱子/拉杆/按钮/门/铁门 → 走内置交互，return
 └─ 其它方块      → emitCancellable('block.interact', ...) → 被拦下就不放
```

所以它拦的是**"把这个方块放下去"**，不是"打开箱子"。

注意三件事：

1. 只有返回**严格 `true`** 才算拦下（返回真值对象不算）。
2. 所有监听都会跑完，不会因为前一个拦了就中断。
3. mod 侧**没有** `G.emitCancellable`，只能监听、不能自己派发可取消事件。

---

## 7. Hook

```js
const h = G.hook('world.setBlock');

h.before((args) => { if (…) return false; });   // 返回 false = 拦截，函数体不执行
h.after((ret, args, e, ctx) => { … });          // 观察；可用 ctx.setReturn(v) 改返回值
h.replace((x, y, z, id) => { … }, 1000);        // 替换实现，第二参为优先级（默认 1000）
h.remove(fn);                                   // 精确注销自己的一条回调
h.restore();                                    // 只回滚【本句柄】注册的东西
```

### 内置 hook

| Hook | 参数 |
|---|---|
| `world.setBlock` | `[x, y, z, id]` |
| `player.update` | `[dt, input]` |
| `player.damage` | `[amount]` |

### 句柄语义（v4 起已修正）

- **`G.hook(name)` 每次返回一个独立句柄**，句柄只拥有自己注册的 before/after。
- `restore()` **只摘掉自己的回调**，不会影响别的 mod。
- `replace()` 按 `priority` 维护替换栈（默认 1000，越大越先执行）：`restore()` 后回退到下一个替换实现，没有则回原实现；同优先级冲突会打警告，后注册的覆盖先注册的。
- 只摘一条用 `h.remove(fn)`，不必整个句柄回滚。
- `h.beforeCount` / `h.afterCount` 是**全局**条数，`h.ownBeforeCount` / `h.ownAfterCount` 是本句柄的。

### 注意

`before` 里**改 `args` 会影响原调用**，`after` 拿到的是原始参数引用（同一个数组）。返回值默认只读，但 `after` 的第四参 `ctx.setReturn(v)` 可以改，后续 after 会拿到新值。

---

## 8. 输入独占

老办法（自己 `G.input.keys[k]=false`）不牢：`mouseLeft` / `mouseRight` 每帧会被宿主写回，mod 置 false 会被覆盖。现在有两个正式入口。

### `G.input.consume(name)`

```js
G.on('game.tick', () => {
  if (!G.input.mouseRight) return;
  const hit = G.getLookTarget(6);
  if (hit && G.BLOCKS[hit.blockId]?.name === 'my_block'){
    G.input.consume('mouseRight');        // 本次右键归我，原版不再放方块
    openMyUI();
  }
});
```

可消费项：`mouseLeft` `mouseRight` `jump` `mine` `place` `sneak`

- **按住期间要每帧调用**（标记是每帧清空的）
- `game.tick` 早于输入写回，所以**同一帧就生效**
- 返回 `true` 表示消费成功，`false` 表示名字不在列表里

### `G.input.suspend()` / `G.input.resume()`

打开自己的全屏 UI 时彻底停掉玩家输入（键盘、鼠标、摇杆、动作键全压住），关闭时恢复。

```js
G.input.suspend();
// …玩家在 UI 里操作…
G.input.resume();
```

`G.input.isSuspended()` 查状态。

> suspend 期间 `G.input.keys` 仍会在 `game.tick` 里读得到（你的 UI 还能用键盘），
> 但宿主在 `updatePlayer` 之前会把它们清掉，所以角色不会动。

---

## 8.5 可改键动作 / `G.keybinds`

mod 可以注册自己的动作，玩家会像原版动作一样，在 **设置 → 操作 → 按键绑定** 里看到并改键。

```js
const skill = G.keybinds.register({
  id: 'mymod.skill',          // 全局唯一，建议带 mod 前缀
  label: '我的技能',           // 设置里显示的名字
  defaultKey: 'KeyK',         // 可省略 → 默认未绑定
  onPress(){ /* 按下 */ },
  onRelease(){ /* 松开 */ },
});

skill.key;            // 当前绑定的键（如 'KeyK' / 'pad:A' / 'mouseRight'）
skill.setKey('KeyJ'); // 改键（玩家在设置里改也一样）
skill.unregister();   // mod 卸载/关闭时移除
```

常用接口：

| 调用 | 说明 |
|---|---|
| `G.keybinds.list()` | 所有动作：`{ id, label, key, defaultKey, mod, conflict }` |
| `G.keybinds.getKey(id)` / `setKey(id, code)` | 读 / 写单个动作的键 |
| `G.keybinds.reset()` | 恢复默认（含 mod 动作） |
| `G.keybinds.conflictsForCode(code, exceptId)` | 查这个键还被哪些动作占用 |
| `G.keybinds.actionsForCode(code)` | 这个键当前会触发哪些动作 |
| `G.keybinds.isDown(id)` | 动作当前是否按住（等价于 `G.input.actions[id]`） |
| `G.keybinds.label(code)` | 键码转显示名（`'Space'` → `'空格'`、`'pad:A'` → `'手柄 A'`） |

**冲突规则和 MC 一样**：同一个键可以绑多个动作，设置里会标红并提示「冲突：xxx」，
按下时这些动作**全部触发**（宿主不会偷偷清掉另一个动作的绑定）。
mod 想自己处理冲突可以先用 `conflictsForCode` 判断。

动作状态变化也会发事件：

```js
G.on('keybind.action', (id, down) => {
  if (id === 'mymod.skill' && down) castSkill();
});
```

键位保存在 `localStorage` 的 `3dmc_keybinds_v1` 里。mod 每次启动重新
`register` 时，玩家改过的键会保留；只有第一次注册（或恢复默认）才使用 `defaultKey`。

---

## 9. 性能须知

1. **`game.tick` 是每帧路径**。别 `console.log`，别分配对象，别 `await`。
2. **不要每帧播音效**，会叠加成噪音。用节流。
3. **不要定时全场景扫描**找"我的方块还在不在"。用 `world.blockChanged`（O(1) 通知）。
4. **批量改方块**用 `G.batch` 或 `G.fillBox`。网格重建是每帧统一做的，不会逐块重建。
5. **UI 更新先比对再写 DOM**。每帧重写 `innerHTML` 会强制样式重算。
6. **不要给游戏内可见元素加 `backdrop-filter`**。实测每帧吃掉约 5ms。
7. **大量同类方块**目前只能各建 Mesh，没有 InstancedMesh 批量接口。
8. **高频写 `G.storage` 会打服务器**。内存变量 + 定时落盘（见卷二第 5 节）。

---

## 10. 常见问题与调试

### 顶层代码为什么不能写副作用？
浏览器 ESM 缓存模块，同一个 `main.js` 全局只 eval 一次。切存档不会重跑。副作用必须放 `onEnable`。

### 想访问游戏内部模块怎么办？
**只用 `G` 门面**。`import('/src/xxx.js')` 不保证稳定。

### mod 抛错会影响游戏吗？
不会。单个 mod 挂掉不影响其他 mod 和游戏本体。

### 注册的方块在远处出现透明接缝？
atlas mipmap 问题，宿主会自动重建。如果出现了先确认不是旧版本。

### 大农场想放 200 只鸡？
```js
G.setEntityCap('land_herbivore', 200);
```
同屏 200 只靠距离分级，主线程负载 ≈ 60 只。多等一会儿（每 2.5 秒最多刷 4 只）或直接循环 `G.spawnEntity`。

### 跑图后动物消失？
超过模拟距离会休眠（不渲染、不跑 AI，位置保留），超过 256 格会被清理。回去会重新生成。

### 远处动物"卡顿"正常吗？
正常，那是距离分级 tick。48~96 格每 16 帧更新一次 AI。

### atlas 满了怎么办？
多个方块共用贴图（`tex: { all: 'shared' }`），用 `G.getAtlasUsage()` 查占用。

### 音效只有第一次能听到？
没 `preload`。用 `{ preload: true }` 或 `await G.loadSound(name)`。

### 怎么调试？
PC：F12。移动端：页面底部的 Eruda 图标。

```js
const G = window.__GAME__;
G.info            // { apiVersion, blockCount, disabledEntityAi, … }
G.listHooks()     G.listEvents()     G.listGenerators()
G.listBiomes()    G.listDimensions() G.listEntityTypes()
G.getAtlasUsage() G.getEntityCounts() G.listEntityCaps()
```

### mod 加载失败怎么看？
暂停菜单 → **Mod 状态**，或控制台 `[loader] ✘ 加载 mod "xxx" 失败: …`。
紫色行 = 依赖失败被级联跳过；红色行 = 自身加载失败。

---

## 11. 已知限制

以下都是**对照源码验证过**的现状：

1. **自定义生成器钩子的边界。**
   `heightAt` / `biomeAt` / `onGenerate` / `onChunkGen` / `onDecorate` 均已接入主线程路径。
   给了 `worldgenUrl` 时 Worker 走模块的 `generate(chunk, blockIds, cfg)`，主线程钩子不参与；
   非内置 id 且没给 `worldgenUrl` 时自动降级到主线程。
   `biomeAt` 目前只影响植被/树木选择与查询，不改变地表方块与染色。
   替代方案：在 `chunk.decorate` 里就地矫正地形（参考 `mods/raftworld`）。

2. **依赖不会自动启用。** 加载器会拓扑排序、检查版本、级联跳过失败依赖，
   但**只会加载玩家已经勾选的 mod**；缺失依赖只记 warning，不会自动补勾。
   依赖环只记 warning，环内 mod 仍会加载。

3. **`chunk.load` 事件不存在。** 老文档里写过，但代码里没有 emit。用 `chunk.decorate` 或 `world.blockChanged`。

4. **`G.setBlock` 不发 `block.place` / `block.break`。** 见第 5 节。

5. **`interactive` 内置只认一组固定值。** 会被原版分支识别的值：`'furnace'` `'chest'` `'pedestal'` `'lever'` `'button'` `'door'` `'iron_door'`
   （`crafting_table` 是按方块名特判；`pedestal` 只认魔法水晶类物品）。注册 `interactive: 'computer'` 之类不会自动打开 UI；
   用 `block.interact` 可取消事件 + `G.input.consume` 自己实现右键交互（见卷三 2.9）。

6. **方块实体数据需要自己管理生命周期。** 方块拆掉后数据不会自动删，需要在 `world.blockChanged` / `block.break` 里清理。

7. **`scheduleBlockTick` 不写存档。** 计划 tick 只在内存里，切存档或重进世界会清空。
   跨存档的周期逻辑请自己用 `G.storage` 记录时间戳，在 `world.enter` 里重建。

8. **没有物理引擎 / 实体不能承载玩家。** 玩家碰撞只查方块；载具类只能每帧改 `player.pos` 模拟。

9. **没有 InstancedMesh / 合批接口。** 大批量同类方块用独立 Mesh，数量大时会掉帧。

10. **状态效果不进存档。** `world.load` 会清空运行中的状态；需要跨存档保留的 buff 要自己写 `G.storage` 并在进入世界后重新 `applyStatus`。

11. **`setMovementConfig` / `setFluidConfig` 是进程级全局配置。** 没有"按世界/按实体"的配置；切换存档不会自动恢复默认。

12. **`fluid.tick:before` 取消后不会自动重试。** 要延迟后再流必须自己调用 `G.wakeFluid`。

13. **`spawnHint` 目前没有接到 `registerGenerator`。** 源码里存档加载会检查 `gen.spawnHint`，
    但运行时注册器不会保存这个字段；因此 mod **无法**通过它接管出生点（会走内置出生点逻辑）。

14. **`reloadMod` 是内部函数，没有暴露给 mod / UI。** 热重载请重新进世界或刷新页面。
