/* 最小 Three.js 桩：够 mod 构建实体模型用 */
class Vector3 {
  constructor(x=0,y=0,z=0){ this.x=x; this.y=y; this.z=z; }
  set(x,y,z){ this.x=x; this.y=y; this.z=z; return this; }
  copy(v){ this.x=v.x; this.y=v.y; this.z=v.z; return this; }
  clone(){ return new Vector3(this.x,this.y,this.z); }
}

class Object3D {
  constructor(){
    this.children = [];
    this.position = new Vector3();
    this.rotation = { x:0, y:0, z:0 };
    this.scale = new Vector3(1,1,1);
    this.userData = {};
    this.visible = true;
    this.name = '';
    this.parent = null;
  }
  add(o){ if(o){ this.children.push(o); o.parent = this; } return this; }
  remove(o){ const i = this.children.indexOf(o); if(i>=0) this.children.splice(i,1); return this; }
  traverse(fn){ fn(this); for(const c of this.children) c.traverse && c.traverse(fn); }
  updateMatrix(){}
  updateMatrixWorld(){}
}

class Group extends Object3D {}

class Mesh extends Object3D {
  constructor(geo, mat){
    super();
    this.geometry = geo;
    this.material = mat;
    this.castShadow = false;
    this.receiveShadow = false;
  }
}

class BoxGeometry {
  constructor(w=1,h=1,d=1){ this.width=w; this.height=h; this.depth=d; }
  dispose(){}
}

class Material {
  constructor(opts){ Object.assign(this, opts || {}); }
  dispose(){}
}
class MeshLambertMaterial extends Material {}
class MeshBasicMaterial extends Material {}
class MeshStandardMaterial extends Material {}

class Scene extends Object3D {
  constructor(){ super(); this.background = null; this.fog = null; }
}

class Color {
  constructor(c){ this.hex = c; }
  set(c){ this.hex = c; return this; }
}

const MathUtils = {
  clamp: (v,a,b) => Math.max(a, Math.min(b, v)),
  lerp: (a,b,t) => a + (b-a)*t,
  degToRad: d => d * Math.PI / 180,
};

export {
  Vector3, Object3D, Group, Mesh, BoxGeometry, Scene, Color, MathUtils,
  MeshLambertMaterial, MeshBasicMaterial, MeshStandardMaterial,
};
