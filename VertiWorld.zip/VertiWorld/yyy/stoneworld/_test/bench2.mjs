const CS=16, CHH=300, Y_MIN=-46;
const B={}; const BLOCKS=[];
function reg(n,o={}){ B[n]={id:BLOCKS.length,name:n,solid:o.solid!==false,...o}; BLOCKS.push(B[n]); }
['air','stone','bedrock','deepslate','tuff','cobble','gravel','water','lava','obsidian','stone_bricks','oak_log','glowstone','chest','crafting_table','sw_deepslate','sw_tuff','sw_basalt','sw_cracked_stone','sw_glow_mushroom','sw_glow_vine','sw_stone_moss','sw_stone_root_log','sw_stone_root_leaves','sw_ruin_brick','sw_rune_brick','sw_altar','sw_spawner','sw_stone_lamp','sw_meat_raw','sw_meat_cooked','sw_bone','sw_coal_ore','sw_iron_ore','sw_gold_ore','sw_diamond_ore','sw_redstone_ore','sw_lapis_ore','sw_emerald_ore','sw_crystal_ore','sw_fossil_ore'].forEach(n=>reg(n));
const G={B,BLOCKS,CS,CHH,Y_MIN,getBlock(){return 0;},setBlock(){},log:{info(){},warn(){},error(){}}};
const { CFG, cacheBlockIds, setHost: sw, generateChunk } = await import('../world.js');
const { placeStructures, setHost: ss } = await import('../structures.js');
sw(G); CFG.top=CHH; CFG.bottom=Y_MIN; CFG.seed=12345; CFG.caveDensity=1; CFG.oreDensity=1; CFG.trees=true;
sw(G); ss(G, cacheBlockIds());

function mkChunk(cx,cz){
  return { cx,cz, blocks:new Uint8Array((CHH-Y_MIN)*CS*CS), fluid:new Uint8Array((CHH-Y_MIN)*CS*CS),
           topY:new Int16Array(CS*CS).fill(Y_MIN), minY:Y_MIN, maxY:Y_MIN, dirty:false, decorated:false };
}
function apiOf(c){
  return { cx:c.cx, cz:c.cz,
    get(lx,ly,lz){ if(ly<Y_MIN||ly>=CHH) return -1; return c.blocks[(((ly-Y_MIN)*CS)+lz)*CS+lx]; },
    set(lx,ly,lz,id){ if(ly<Y_MIN||ly>=CHH) return false; c.blocks[(((ly-Y_MIN)*CS)+lz)*CS+lx]=id; return true; },
    setName(){return true;}, topY(lx,lz){ return c.topY[lz*CS+lx]; }, getSeed(){return CFG.seed;},
  };
}

// 预热
for (let i=0;i<3;i++){ const c=mkChunk(i,0); generateChunk(c, apiOf(c)); }

const N=25;
const times=[];
for (let i=0;i<N;i++){
  const c = mkChunk(100+i, 100);
  const api = apiOf(c);
  const t0=process.hrtime.bigint();
  generateChunk(c, api);
  placeStructures(api, c.cx, c.cz, CFG.seed);
  const t1=process.hrtime.bigint();
  times.push(Number(t1-t0)/1e6);
}
times.sort((a,b)=>a-b);
const avg = times.reduce((a,b)=>a+b,0)/times.length;
console.log(`单区块 generateChunk + placeStructures：平均 ${avg.toFixed(1)}ms · 中位 ${times[N>>1].toFixed(1)}ms · p95 ${times[Math.floor(N*0.95)].toFixed(1)}ms`);

// 校验产物
const c = mkChunk(500,500);
generateChunk(c, apiOf(c));
let air=0, solid=0, minS=CHH, maxS=Y_MIN;
for (let i=0;i<c.blocks.length;i++){ if(c.blocks[i]===0) air++; else { solid++; } }
for (let lz=0;lz<CS;lz++)for(let lx=0;lx<CS;lx++)for(let y=Y_MIN;y<CHH;y++){
  if (c.blocks[(((y-Y_MIN)*CS)+lz)*CS+lx]!==0){ if(y<minS)minS=y; if(y>maxS)maxS=y; }
}
console.log(`实心 ${(solid/(air+solid)*100).toFixed(1)}% · minY(实际)=${minS} maxY(实际)=${maxS} · chunk.minY=${c.minY} chunk.maxY=${c.maxY}`);
console.log(`minY/maxY 覆盖正确: ${c.minY <= minS && c.maxY >= maxS}`);
