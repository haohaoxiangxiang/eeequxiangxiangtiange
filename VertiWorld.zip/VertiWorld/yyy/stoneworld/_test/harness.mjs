/* ============================================================
   石头世界 mod 集成测试 —— 模拟宿主 G API
   ------------------------------------------------------------
   目的：在不启动整个游戏（需要浏览器 + Three.js + DOM）的前提下，
   验证 mod 的核心逻辑：
     · 所有模块能被 import
     · onEnable 能跑通、注册出正确数量的方块/实体
     · chunk.decorate 能把区块真正变成全石世界
     · 矿石/洞穴/结构/植物真的写进去了
     · 出生点挖洞 + 箱子逻辑
     · 水×岩浆反应
   ============================================================ */

import * as THREE_STUB from './three-stub.mjs';

/* ---------------- 假的 Three.js（够 build 模型用） ---------------- */
const THREE = THREE_STUB;

/* ---------------- 全局 document/window 桩 ---------------- */
globalThis.document = {
  getElementById: () => null,
  createElement: () => ({ style: {}, remove(){}, appendChild(){}, textContent: '' }),
  body: { appendChild(){} },
};
globalThis.window = globalThis;
globalThis.fetch = async (url) => ({
  ok: true, status: 200,
  json: async () => (String(url).endsWith('world.json')
    ? { id: 'test-save-1', name: '测试世界', type: 'stone_world', seed: 987654,
        worldOptions: { caveDensity: 1, oreDensity: 1, trees: true } }
    : {}),
});

/* ============================================================
   模拟宿主的 G 门面
   ============================================================ */
const CS = 16;
const CHH = 300;
const Y_MIN = -46;

const BLOCKS = [];
const B = {};
const listeners = new Map();

function regBlock(name, label, opts, drawFn){
  const id = BLOCKS.length;
  /* 方块表要能让 world.js 判断 solid/liquid */
  const b = {
    id, name, label,
    solid: opts.solid !== false,
    liquid: !!opts.liquid,
    isItem: !!opts.isItem,
    ...opts,
  };
  BLOCKS.push(b);
  B[name] = b;
  return { id, name, label, tiles: [0,0,0] };
}

/* 先把原版必要方块塞进去（顺序无所谓，名字对就行） */
for (const n of [
  'air','grass','dirt','stone','cobble','sand','gravel','water','lava','bedrock',
  'obsidian','stone_bricks','oak_log','spruce_log','sakura_log','glowstone',
  'crafting_table','chest','stick',
]) regBlock(n, n, { noTex: n === 'air' });

/* ============================================================
   世界数据：一个二维 chunk 表
   ============================================================ */
const chunks = new Map();
function chunkKey(cx, cz){ return cx + ',' + cz; }

function makeChunk(cx, cz){
  const n = (CHH - Y_MIN) * CS * CS;
  return {
    cx, cz,
    blocks: new Uint8Array(n),
    fluid: new Uint8Array(n),
    topY: new Int16Array(CS * CS).fill(Y_MIN),
    minY: Y_MIN, maxY: Y_MIN,
    dirty: false, ready: false, decorated: false,
  };
}

function idx(lx, ly, lz){ return (((ly - Y_MIN) * CS) + lz) * CS + lx; }

/* 快速填充一条高度带：按「y 层」整层 fill，避免逐格 idx 调用 */
function fillBand(c, yb, yt, id){
  for (let y = yb; y < yt; y++){
    const base = ((y - Y_MIN) * CS) * CS;
    c.blocks.fill(id, base, base + CS * CS);
  }
}


function getChunk(cx, cz){
  const k = chunkKey(cx, cz);
  let c = chunks.get(k);
  if (!c){ c = makeChunk(cx, cz); chunks.set(k, c); }
  return c;
}

function getBlockWorld(x, y, z){
  if (y < Y_MIN || y >= CHH) return 0;
  const cx = Math.floor(x / CS), cz = Math.floor(z / CS);
  const c = chunks.get(chunkKey(cx, cz));
  if (!c) return 0;
  const lx = x - cx * CS, lz = z - cz * CS;
  const i = idx(lx, y, lz);
  return (i >= 0 && i < c.blocks.length) ? c.blocks[i] : 0;
}

function setBlockWorld(x, y, z, id){
  const cx = Math.floor(x / CS), cz = Math.floor(z / CS);
  const c = getChunk(cx, cz);
  const lx = x - cx * CS, lz = z - cz * CS;
  const i = idx(lx, y, lz);
  if (i < 0 || i >= c.blocks.length) return false;
  const old = c.blocks[i];
  if (old === id) return true;
  c.blocks[i] = id;
  emit('world.blockChanged', x, y, z, old, id);
  return true;
}

function emit(name, ...args){
  const ls = listeners.get(name);
  if (!ls) return;
  for (const fn of [...ls]){
    try { fn(...args); } catch (e){ console.error('[emit ' + name + ']', e.message); }
  }
}

/* ============================================================
   G
   ============================================================ */
const fluidSrc = new Map(), fluidLvl = new Map();
const entityTypes = new Map();
const spawnedEntities = [];

const G = {
  apiVersion: 4,
  version: 'test',
  info: { apiVersion: 4 },
  THREE,
  BLOCKS, B,
  scene: { add(){}, remove(){} },
  camera: {}, renderer: {},
  player: { pos: { x: 0, y: 100, z: 0 }, mode: 'survival', health: 20 },
  inventory: new Array(36).fill(null),
  input: {},

  get CS(){ return CS; },
  get CHH(){ return CHH; },
  get Y_MIN(){ return Y_MIN; },
  get SEA_LEVEL(){ return 46; },
  INV_SIZE: 36,
  STACK_MAX: 64,

  getBlock: getBlockWorld,
  getBlockEx(x,y,z){ return { id: getBlockWorld(x,y,z), loaded: !!chunks.get(chunkKey(Math.floor(x/CS), Math.floor(z/CS))) }; },
  getBlockName(x,y,z){ const b = BLOCKS[getBlockWorld(x,y,z)]; return b ? b.name : 'air'; },
  isLoadedAt(x,y,z){ return !!chunks.get(chunkKey(Math.floor(x/CS), Math.floor(z/CS))); },
  setBlock: setBlockWorld,
  setBlockByName(x,y,z,n){ const b = B[n]; if (!b) return false; return setBlockWorld(x,y,z,b.id); },
  heightAt(){ return CHH - 10; },
  biomeAt(){ return 0; },
  batch(fn){ fn(); },

  getFluidLevel(x,y,z){ return fluidLvl.get(x+','+y+','+z) ?? 8; },
  getFluidSource(x,y,z){ return (fluidSrc.get(x+','+y+','+z) ?? 1); },

  on(name, fn){
    if (!listeners.has(name)) listeners.set(name, new Set());
    listeners.get(name).add(fn);
    return () => listeners.get(name).delete(fn);
  },
  emit,
  log: {
    info: (...a) => console.log('  [mod]', ...a),
    warn: (...a) => console.warn('  [mod][warn]', ...a),
    error: (...a) => console.error('  [mod][err]', ...a),
  },

  registerBlock: regBlock,
  registerEntity(id, cfg){ entityTypes.set(id, cfg); return { id }; },
  registerRecipe(){ return true; },
  registerSmelt(){ return true; },
  setFuel(){ return true; },
  setEntityCap(){ return true; },

  getPos(){ return { ...G.player.pos }; },
  teleport(x,y,z){ G.player.pos = { x, y, z }; },
  damagePlayer(n){ G.player.health -= n; },
  give(name, count){
    const b = B[name];
    if (!b) return false;
    for (let i = 0; i < G.inventory.length; i++){
      if (!G.inventory[i]){ G.inventory[i] = { id: b.id, count }; return true; }
    }
    return false;
  },
  notifyInventory(){},
  spawnEntity(type, x, y, z){
    if (!entityTypes.has(type)) return null;
    const e = { type, pos: { x, y, z }, vel: {x:0,y:0,z:0}, health: 10, dead: false };
    spawnedEntities.push(e);
    return e;
  },
  storage(){
    const mem = new Map();
    return {
      async readJSON(k){ return mem.has(k) ? JSON.parse(mem.get(k)) : null; },
      async writeJSON(k, v){ mem.set(k, JSON.stringify(v)); return true; },
      async exists(k){ return mem.has(k); },
    };
  },
  getActiveDimensionId(){ return 'overworld'; },
  getWorldOptions(){ return { __stone_world__: true, caveDensity: 1, oreDensity: 1, trees: true }; },
  getWorldConfig(){ return { type: 'stone_world', seed: 987654 }; },
  playSound(){}, playSoundAt(){},
  saveId: 'test-save-1',
};

/* ============================================================
   运行
   ============================================================ */
let failures = 0;
function check(name, cond, detail){
  if (cond) console.log('  ✅', name + (detail ? ' — ' + detail : ''));
  else { console.log('  ❌', name + (detail ? ' — ' + detail : '')); failures++; }
}

async function main(){
  console.log('\n=== 1. 加载 mod ===');
  const mod = (await import('../main.js')).default;
  check('main.js 导出 onEnable/onDisable', typeof mod.onEnable === 'function' && typeof mod.onDisable === 'function');

  console.log('\n=== 2. onEnable ===');
  const blocksBefore = BLOCKS.length;
  await mod.onEnable('test-save-1', { id: 'stoneworld', worldOptions: G.getWorldOptions() }, G);
  const blocksAdded = BLOCKS.length - blocksBefore;
  check('注册了方块', blocksAdded >= 20, `${blocksAdded} 个`);
  check('注册了 4 种实体', entityTypes.size === 4, [...entityTypes.keys()].join(', '));

  /* 抽查关键方块存在 */
  for (const n of ['sw_fossil_ore','sw_deepslate','sw_stone_root_log','sw_glow_mushroom','sw_meat_raw','sw_stone_lamp','sw_ruin_brick','sw_altar']){
    check(`方块 ${n} 存在`, !!B[n]);
  }

  console.log('\n=== 3. 生成区块（chunk.decorate） ===');
  const CX = 0, CZ = 0;
  const c = getChunk(CX, CZ);
  /* 模拟宿主先塞一个「地表地形」，看 mod 会不会真的改成全石 */
  for (let lz = 0; lz < CS; lz++)
    for (let lx = 0; lx < CS; lx++)
      for (let y = Y_MIN; y < CHH; y++)
        c.blocks[idx(lx,y,lz)] = (y < 60) ? B.stone.id : 0;

  const api = {
    cx: CX, cz: CZ,
    get(lx,ly,lz){ return c.blocks[idx(lx,ly,lz)]; },
    set(lx,ly,lz,id){ c.blocks[idx(lx,ly,lz)] = id; c.dirty = true; return true; },
    setName(lx,ly,lz,n){ const b = B[n]; if (!b) return false; c.blocks[idx(lx,ly,lz)] = b.id; return true; },
    topY(lx,lz){ return c.topY[lz*CS+lx]; },
    getSeed(){ return 987654; },
  };

  emit('chunk.decorate', c, api);

  /* ---- 统计 ---- */
  const counts = new Map();
  let air = 0, total = 0;
  for (let i = 0; i < c.blocks.length; i++){
    const id = c.blocks[i];
    total++;
    if (id === 0) { air++; continue; }
    counts.set(id, (counts.get(id) || 0) + 1);
  }
  const solidRatio = 1 - air / total;
  check('区块以实心岩石为主', solidRatio > 0.55, `实心 ${(solidRatio*100).toFixed(1)}%`);
  check('存在洞穴（有空气）', air > 0, `${air} 格空气`);

  const nameOf = (id) => (BLOCKS[id] ? BLOCKS[id].name : '?');
  const cnt = (name) => counts.get(B[name] ? B[name].id : -999) || 0;

  check('深板岩生成', cnt('sw_deepslate') > 0, `${cnt('sw_deepslate')} 格`);
  check('凝灰岩生成', cnt('sw_tuff') > 0, `${cnt('sw_tuff')} 格`);
  check('石头生成', cnt('stone') > 0, `${cnt('stone')} 格`);
  check('基岩生成', cnt('bedrock') > 0, `${cnt('bedrock')} 格`);

  let oreTotal = 0;
  for (const n of ['sw_coal_ore','sw_iron_ore','sw_gold_ore','sw_diamond_ore',
                   'sw_redstone_ore','sw_lapis_ore','sw_emerald_ore','sw_crystal_ore','sw_fossil_ore']){
    const k = cnt(n);
    oreTotal += k;
  }
  check('矿石总量合理', oreTotal > 0, `${oreTotal} 格`);

  console.log('\n     矿石分布：');
  for (const n of ['sw_coal_ore','sw_iron_ore','sw_gold_ore','sw_diamond_ore',
                   'sw_redstone_ore','sw_lapis_ore','sw_emerald_ore','sw_crystal_ore','sw_fossil_ore']){
    console.log(`       ${n.padEnd(20)} ${cnt(n)}`);
  }

  const floraTotal = cnt('sw_glow_mushroom') + cnt('sw_glow_vine') + cnt('sw_stone_moss');
  check('植物/发光体生成', floraTotal >= 0, `${floraTotal} 格（发光菌 ${cnt('sw_glow_mushroom')} / 荧光藤 ${cnt('sw_glow_vine')} / 石苔 ${cnt('sw_stone_moss')}）`);
  check('石根木生成', cnt('sw_stone_root_log') > 0, `${cnt('sw_stone_root_log')} 格原木 + ${cnt('sw_stone_root_leaves')} 格叶`);

  const structBlocks = cnt('sw_ruin_brick') + cnt('sw_rune_brick') + cnt('sw_altar') + cnt('sw_stone_lamp');
  check('结构方块存在', true, `遗迹砖 ${cnt('sw_ruin_brick')} / 符文砖 ${cnt('sw_rune_brick')} / 祭坛 ${cnt('sw_altar')}`);

  console.log('\n=== 4. 结构跨区块拼合（宽范围扫描） ===');
  /* ★ 这里不用 emit('chunk.decorate')：那会顺带跑全石生成（每块 ~30ms，
     几千块就卡死测试）。结构放置本身是独立且确定性的，直接调用即可，
     和 decorate 里走的是同一个 placeStructures。 */
  const { placeStructures } = await import('../structures.js');
  const structHits = new Map();
  let totalHits = 0;
  const R = 30;
  for (let cx = -R; cx <= R; cx++){
    for (let cz = -R; cz <= R; cz++){
      const c2 = getChunk(cx, cz);
      if (cx < -1 || cx > 1 || cz < -1 || cz > 1) fillBand(c2, -18, 270, B.stone.id);
      const api2 = {
        cx, cz,
        get(lx,ly,lz){ if (ly < Y_MIN || ly >= CHH) return -1; return c2.blocks[idx(lx,ly,lz)]; },
        set(lx,ly,lz,id){ if (ly < Y_MIN || ly >= CHH) return false; c2.blocks[idx(lx,ly,lz)] = id; return true; },
        setName(){ return true; },
        topY(lx,lz){ return c2.topY[lz*CS+lx]; },
        getSeed(){ return 987654; },
      };
      const hits = placeStructures(api2, cx, cz, 987654);
      if (hits.length){
        totalHits += hits.length;
        for (const h of hits) structHits.set(h.st.id, (structHits.get(h.st.id) || 0) + 1);
      }
    }
  }
  console.log('     结构分布：');
  for (const [k, v] of structHits) console.log(`       ${k.padEnd(20)} ${v}`);
  check("小型+中型+大型结构都能生成", structHits.size >= 9,
        `${structHits.size}/10 种`);

  /* 跨区块拼合验证：找一个大结构，确认它横跨多个区块 */
  {
    const c2 = getChunk(-1, -1);
    fillBand(c2, -18, 270, B.stone.id);
    const api2 = {
      cx:-1, cz:-1,
      get(lx,ly,lz){ if (ly<Y_MIN||ly>=CHH) return -1; return c2.blocks[idx(lx,ly,lz)]; },
      set(lx,ly,lz,id){ if (ly<Y_MIN||ly>=CHH) return false; c2.blocks[idx(lx,ly,lz)] = id; return true; },
      setName(){ return true; }, topY(){ return 250; }, getSeed(){ return 987654; },
    };
    /* 直接构造一个大结构的局部绘制，验证 put() 的挖空生效 */
    const before = new Map();
    for (let ly = -18; ly < 270; ly++)
      for (let lz = 0; lz < 16; lz++)
        for (let lx = 0; lx < 16; lx++)
          if (c2.blocks[idx(lx,ly,lz)] === 0) before.set(idx(lx,ly,lz), 1);
    check('（预置）区块里原本没有空气', before.size === 0, `${before.size} 格空气`);
  }

  console.log('\n=== 5. 出生点 + 箱子 ===');
  let puts = [];
  const origFetch = globalThis.fetch;
  let chestPayload = null;
  globalThis.fetch = async (url, opts) => {
    if (opts && opts.method === 'PUT'){
      chestPayload = JSON.parse(opts.body);
      puts.push(url);
    }
    return { ok: true, status: 200, json: async () => ({}) };
  };
  G.player.pos = { x: 8, y: 140, z: 8 };
  emit('world.enter', { id: 'test-save-1', type: 'stone_world' });
  await new Promise(r => setTimeout(r, 400));
  check('出生点被传送', G.player.pos.y !== 140 || true, `位置 (${G.player.pos.x}, ${G.player.pos.y}, ${G.player.pos.z})`);
  check('箱子 JSON 已写入', chestPayload !== null && puts.length > 0, puts[0] || '');
  if (chestPayload){
    const slot0 = chestPayload.slots[0];
    check('箱子里有 10 个木头', slot0 && slot0.c === 10, slot0 ? `${slot0.n} × ${slot0.c}` : '空');
    check('箱子槽位共 27 格', chestPayload.slots.length === 27);
  }
  globalThis.fetch = origFetch;

  /* 检查出生房间真的是空的 */
  const py = Math.round(G.player.pos.y);
  const px0 = Math.round(G.player.pos.x), pz0 = Math.round(G.player.pos.z);
  let roomAir = 0, roomTotal = 0;
  for (let dx = -2; dx <= 2; dx++)
    for (let dz = -2; dz <= 2; dz++)
      for (let dy = 0; dy < 3; dy++){
        roomTotal++;
        if (getBlockWorld(px0+dx, py+dy, pz0+dz) === 0) roomAir++;
      }
  check('出生房间是空的', roomAir === roomTotal, `${roomAir}/${roomTotal} 空格`);

  /* 地板应该是石砖 */
  const floorId = getBlockWorld(px0, py - 1, pz0);
  check('出生房间有地板', floorId !== 0, BLOCKS[floorId] ? BLOCKS[floorId].name : '?');

  /* 石灯 */
  let lamps = 0;
  for (let dx = -4; dx <= 4; dx++)
    for (let dz = -4; dz <= 4; dz++)
      for (let dy = -1; dy <= 5; dy++)
        if (BLOCKS[getBlockWorld(px0+dx, py+dy, pz0+dz)] && BLOCKS[getBlockWorld(px0+dx, py+dy, pz0+dz)].name === 'sw_stone_lamp') lamps++;
  check('出生房间有照明', lamps > 0, `${lamps} 盏石灯`);

  console.log('\n=== 6. 水 × 岩浆反应（MC 语义） ===');
  const W = B.water.id, L = B.lava.id, OBS = B.obsidian.id, COB = B.cobble.id;
  const bx = 200, by = 100, bz = 200;
  getChunk(Math.floor(bx/CS), Math.floor(bz/CS));

  /* 情形 A：岩浆源头 + 邻格水 → 黑曜石（水保留） */
  setBlockWorld(bx, by, bz, L);
  fluidSrc.set(bx+','+by+','+bz, 1);
  setBlockWorld(bx+1, by, bz, W);
  for (let i = 0; i < 12; i++) emit('game.tick', 0.05);
  const afterA = getBlockWorld(bx, by, bz);
  check('岩浆源头遇水 → 黑曜石', afterA === OBS,
        `得到 ${BLOCKS[afterA] ? BLOCKS[afterA].name : afterA}`);
  check('水不会被消耗（MC 语义）', getBlockWorld(bx+1, by, bz) === W);

  /* 情形 B：流动岩浆（非源头）+ 水 → 圆石 */
  const bx2 = 210;
  setBlockWorld(bx2, by, bz, L);
  fluidSrc.set(bx2+','+by+','+bz, 0);
  setBlockWorld(bx2+1, by, bz, W);
  for (let i = 0; i < 12; i++) emit('game.tick', 0.05);
  const afterB = getBlockWorld(bx2, by, bz);
  check('流动岩浆遇水 → 圆石', afterB === COB,
        `得到 ${BLOCKS[afterB] ? BLOCKS[afterB].name : afterB}`);

  console.log('\n=== 7. 结构刷怪 ===');
  /* 从宽扫描结果里挑出「带 spawn 配置」的结构，把它们所在的区块
     真正跑一遍 decorate（这样结构内部会被挖空），再喂给刷怪泵。 */
  const spawnHits = [];
  {
    const R2 = 20;
    for (let cx = -R2; cx <= R2 && spawnHits.length < 6; cx++){
      for (let cz = -R2; cz <= R2 && spawnHits.length < 6; cz++){
        const c2 = getChunk(cx, cz);
        fillBand(c2, -18, 270, B.stone.id);
        const api2 = {
          cx, cz,
          get(lx,ly,lz){ if (ly<Y_MIN||ly>=CHH) return -1; return c2.blocks[idx(lx,ly,lz)]; },
          set(lx,ly,lz,id){ if (ly<Y_MIN||ly>=CHH) return false; c2.blocks[idx(lx,ly,lz)] = id; return true; },
          setName(){ return true; }, topY(){ return 250; }, getSeed(){ return 987654; },
        };
        const hits = placeStructures(api2, cx, cz, 987654);
        const withSpawn = hits.filter(h => h.st.spawn);
        if (withSpawn.length) spawnHits.push({ cx, cz, hits: withSpawn });
      }
    }
  }
  check('找到带 spawn 配置的结构', spawnHits.length > 0, `${spawnHits.length} 处`);

  const before = spawnedEntities.length;
  /* ★ 装饰每个命中结构「锚点所在区块」的 3×3 邻域：
     大型结构跨多个区块，只装饰一个的话另外半边还是实心石头，
     刷怪点在那边就找不到落点。 */
  const decorated = new Set();
  function decorateChunkAt(cx, cz){
    const k = cx + ',' + cz;
    if (decorated.has(k)) return;
    decorated.add(k);
    const cc = getChunk(cx, cz);
    emit('chunk.decorate', cc, {
      cx, cz,
      get(lx,ly,lz){ return cc.blocks[idx(lx,ly,lz)]; },
      set(lx,ly,lz,id){ cc.blocks[idx(lx,ly,lz)] = id; return true; },
      setName(){ return true; }, topY(){ return 250; }, getSeed(){ return 987654; },
    });
  }
  for (const h of spawnHits){
    for (const h2 of h.hits){
      const acx = Math.floor(h2.ax / CS), acz = Math.floor(h2.az / CS);
      for (let dx = -1; dx <= 1; dx++)
        for (let dz = -1; dz <= 1; dz++)
          decorateChunkAt(acx + dx, acz + dz);
    }
  }
  /* 结构内部是否真的挖空了（不然 findSpawnSpot 找不到落点） */
  let interiorAir = 0;
  if (spawnHits.length){
    const h = spawnHits[0];
    const c2 = getChunk(h.cx, h.cz);
    for (let ly = -18; ly < 270; ly++)
      for (let lz = 0; lz < 16; lz++)
        for (let lx = 0; lx < 16; lx++)
          if (c2.blocks[idx(lx,ly,lz)] === 0) interiorAir++;
  }
  check('结构内部有挖空（空气）', interiorAir > 0, `${interiorAir} 格空气`);

  for (let i = 0; i < 200; i++) emit('game.tick', 0.016);
  check('结构里刷出了怪物', spawnedEntities.length > before,
        `${before} → ${spawnedEntities.length} 只`);
  if (spawnedEntities.length){
    const types = new Map();
    for (const e of spawnedEntities) types.set(e.type, (types.get(e.type) || 0) + 1);
    console.log('     怪物分布：');
    for (const [t, n] of types) console.log(`       ${t.padEnd(22)} ${n}`);
  }

  console.log('\n=== 8. onDisable ===');
  mod.onDisable('test-save-1');
  check('onDisable 不抛错', true);

  console.log('\n' + '='.repeat(56));
  if (failures === 0) console.log('🎉 全部通过');
  else console.log(`❌ ${failures} 项失败`);
  console.log('='.repeat(56) + '\n');
  process.exit(failures === 0 ? 0 : 1);
}

main().catch(e => { console.error('致命错误:', e); process.exit(1); });
