/* ============================================================
   stoneworld/entities.js —— 地下怪物 + 刷怪逻辑
   ------------------------------------------------------------
   石头世界没有阳光，所以怪不分「白天黑夜」——它们守在结构里。
   四个类型（都归 land_predator 分类，共享 20 只上限）：

     cave_crawler    洞穴爬虫   结构刷 2~4 只，速度快、血少
     skeleton_miner  矿工骸骨   小型结构里，慢、血中
     stone_wraith    石之幽魂   祭坛/神殿守卫，飘、血厚
     obsidian_golem  黑曜石魔像 要塞 Boss，极慢、血极厚

   ⚠ 关键：host 的自动刷怪（spawnAnimalsAround）只认 LAND_SURFACE
   （grass/dirt/sand/snow），石头世界一个都没有，所以原版动物根本不会
   刷出来 —— 正是我们要的。怪全部由本模块在结构里手动 spawnEntity。
   ============================================================ */

let G = null;
let THREE = null;
let _unsubs = [];
/* 已经刷过怪的结构锚点，避免重复刷 */
const _spawned = new Set();
const SPAWNED_CAP = 2000;

/* 材质缓存（懒建，避免在顶层碰 THREE） */
let MAT = null;

export function setHost(host){
  G = host;
  THREE = host.THREE;
}

/* ============================================================
   材质
   ============================================================ */
function ensureMat(){
  if (MAT) return MAT;
  const T = THREE;
  MAT = {
    crawlerBody: new T.MeshLambertMaterial({ color: 0x4a5a52 }),
    crawlerShell: new T.MeshLambertMaterial({ color: 0x2e3a36 }),
    crawlerEye:  new T.MeshLambertMaterial({ color: 0xff5522, emissive: 0x882200 }),

    boneBody:  new T.MeshLambertMaterial({ color: 0xd8d4c0 }),
    boneDark:  new T.MeshLambertMaterial({ color: 0xa8a494 }),
    boneEye:   new T.MeshLambertMaterial({ color: 0x44ddff, emissive: 0x1188aa }),
    bonePick:  new T.MeshLambertMaterial({ color: 0x8a7a5a }),

    wraithBody: new T.MeshLambertMaterial({ color: 0x6a5a9a, transparent: true, opacity: 0.82 }),
    wraithCore: new T.MeshLambertMaterial({ color: 0xd0b0ff, emissive: 0x6a3acc }),
    wraithEye:  new T.MeshLambertMaterial({ color: 0xf0e0ff, emissive: 0xa070ff }),

    golemBody:  new T.MeshLambertMaterial({ color: 0x2a2430 }),
    golemGlow:  new T.MeshLambertMaterial({ color: 0xff7733, emissive: 0xaa3300 }),
    golemCrack: new T.MeshLambertMaterial({ color: 0xff9944, emissive: 0xdd5511 }),
  };
  return MAT;
}

/* 方块网格复用（和内置实体一致，用单位立方体 + scale） */
let BOX = null;
function box(){
  if (!BOX) BOX = new THREE.BoxGeometry(1, 1, 1);
  return BOX;
}

function part(mat, w, h, d, x, y, z, shadow){
  const m = new THREE.Mesh(box(), mat);
  m.scale.set(w, h, d);
  m.position.set(x, y, z);
  if (shadow) m.castShadow = true;
  return m;
}

function makeLeg(mat, w, h, d, x, y, z, swing){
  const pivot = new THREE.Group();
  pivot.position.set(x, y, z);
  pivot.userData.swing = swing;
  pivot.add(part(mat, w, h, d, 0, -h / 2, 0, false));
  return pivot;
}

/* ============================================================
   模型
   ============================================================ */

/* ---------- 洞穴爬虫：低矮四足，带甲壳 ---------- */
function buildCrawler(){
  const M = ensureMat();
  const g = new THREE.Group();

  const body = part(M.crawlerBody, 0.62, 0.34, 0.86, 0, 0.34, 0, true);
  g.add(body);
  /* 甲壳 */
  g.add(part(M.crawlerShell, 0.68, 0.12, 0.9, 0, 0.52, 0, false));
  /* 背棘 */
  for (let i = -1; i <= 1; i++){
    g.add(part(M.crawlerShell, 0.08, 0.16, 0.08, 0, 0.64, i * 0.24, false));
  }

  const head = new THREE.Group();
  head.position.set(0, 0.4, -0.5);
  head.add(part(M.crawlerBody, 0.34, 0.28, 0.3, 0, 0, 0, true));
  head.add(part(M.crawlerEye, 0.09, 0.07, 0.05, -0.09, 0.06, -0.16, false));
  head.add(part(M.crawlerEye, 0.09, 0.07, 0.05,  0.09, 0.06, -0.16, false));
  /* 下颚 */
  head.add(part(M.crawlerShell, 0.1, 0.06, 0.18, -0.06, -0.12, -0.2, false));
  head.add(part(M.crawlerShell, 0.1, 0.06, 0.18,  0.06, -0.12, -0.2, false));
  g.add(head);

  const legs = [
    makeLeg(M.crawlerShell, 0.1, 0.34, 0.1, -0.32, 0.34, -0.28,  1),
    makeLeg(M.crawlerShell, 0.1, 0.34, 0.1,  0.32, 0.34, -0.28, -1),
    makeLeg(M.crawlerShell, 0.1, 0.34, 0.1, -0.32, 0.34,  0.28, -1),
    makeLeg(M.crawlerShell, 0.1, 0.34, 0.1,  0.32, 0.34,  0.28,  1),
  ];
  for (const l of legs) g.add(l);

  return { group: g, parts: { legs, head, body, tail: null } };
}

/* ---------- 矿工骸骨：人形，拿镐 ---------- */
function buildSkeletonMiner(){
  const M = ensureMat();
  const g = new THREE.Group();

  /* 躯干 */
  const body = part(M.boneBody, 0.42, 0.62, 0.26, 0, 1.0, 0, true);
  g.add(body);
  /* 肋骨 */
  for (let i = 0; i < 3; i++){
    g.add(part(M.boneDark, 0.46, 0.05, 0.3, 0, 0.86 + i * 0.16, 0, false));
  }

  const head = new THREE.Group();
  head.position.set(0, 1.46, 0);
  head.add(part(M.boneBody, 0.34, 0.34, 0.32, 0, 0, 0, true));
  head.add(part(M.boneEye, 0.07, 0.07, 0.04, -0.08, 0.03, -0.16, false));
  head.add(part(M.boneEye, 0.07, 0.07, 0.04,  0.08, 0.03, -0.16, false));
  g.add(head);

  /* 双臂 */
  const arms = [
    makeLeg(M.boneBody, 0.12, 0.56, 0.12, -0.28, 1.26, 0, 1),
    makeLeg(M.boneBody, 0.12, 0.56, 0.12,  0.28, 1.26, 0, -1),
  ];
  for (const a of arms) g.add(a);

  /* 右手的镐 */
  const pick = new THREE.Group();
  pick.position.set(0.28, 0.76, 0);
  pick.add(part(M.bonePick, 0.06, 0.72, 0.06, 0, -0.16, 0, false));
  pick.add(part(M.boneDark, 0.34, 0.08, 0.08, 0, 0.16, 0, false));
  g.add(pick);

  const legs = [
    makeLeg(M.boneBody, 0.14, 0.68, 0.14, -0.13, 0.70, 0,  1),
    makeLeg(M.boneBody, 0.14, 0.68, 0.14,  0.13, 0.70, 0, -1),
  ];
  for (const l of legs) g.add(l);

  return { group: g, parts: { legs, head, body, tail: null, arms, pick } };
}

/* ---------- 石之幽魂：漂浮，半透明，兜帽 ---------- */
function buildStoneWraith(){
  const M = ensureMat();
  const g = new THREE.Group();

  /* 飘浮的下摆（圆锥状，用几个递减的方块近似） */
  for (let i = 0; i < 4; i++){
    const w = 0.62 - i * 0.1;
    g.add(part(M.wraithBody, w, 0.22, w, 0, 0.72 + i * 0.2, 0, false));
  }

  const body = part(M.wraithBody, 0.5, 0.5, 0.4, 0, 1.55, 0, true);
  g.add(body);

  /* 核心（发光） */
  g.add(part(M.wraithCore, 0.2, 0.2, 0.2, 0, 1.55, -0.18, false));

  const head = new THREE.Group();
  head.position.set(0, 1.98, 0);
  head.add(part(M.wraithBody, 0.4, 0.4, 0.36, 0, 0, 0, true));
  /* 兜帽尖 */
  head.add(part(M.wraithBody, 0.24, 0.18, 0.24, 0, 0.24, 0.02, false));
  /* 双眼 */
  head.add(part(M.wraithEye, 0.08, 0.05, 0.04, -0.1, 0.02, -0.18, false));
  head.add(part(M.wraithEye, 0.08, 0.05, 0.04,  0.1, 0.02, -0.18, false));
  g.add(head);

  /* 双臂：飘带 */
  const arms = [
    makeLeg(M.wraithBody, 0.14, 0.5, 0.14, -0.3, 1.75, 0, 1),
    makeLeg(M.wraithBody, 0.14, 0.5, 0.14,  0.3, 1.75, 0, -1),
  ];
  for (const a of arms) g.add(a);

  return { group: g, parts: { legs: [], head, body, tail: null, arms } };
}

/* ---------- 黑曜石魔像：巨型方块堆叠 ---------- */
function buildObsidianGolem(){
  const M = ensureMat();
  const g = new THREE.Group();

  /* 躯干 */
  const body = part(M.golemBody, 1.3, 1.5, 0.9, 0, 2.1, 0, true);
  g.add(body);

  /* 胸口熔岩裂纹 */
  g.add(part(M.golemCrack, 0.28, 0.7, 0.08, 0, 2.2, -0.47, false));
  g.add(part(M.golemCrack, 0.7, 0.16, 0.08, 0, 1.9, -0.47, false));

  const head = new THREE.Group();
  head.position.set(0, 3.1, 0);
  head.add(part(M.golemBody, 0.7, 0.62, 0.62, 0, 0, 0, true));
  head.add(part(M.golemGlow, 0.16, 0.1, 0.06, -0.16, 0.06, -0.32, false));
  head.add(part(M.golemGlow, 0.16, 0.1, 0.06,  0.16, 0.06, -0.32, false));
  g.add(head);

  /* 粗壮双臂 */
  const arms = [
    makeLeg(M.golemBody, 0.42, 1.3, 0.42, -0.88, 2.6, 0, 1),
    makeLeg(M.golemBody, 0.42, 1.3, 0.42,  0.88, 2.6, 0, -1),
  ];
  for (const a of arms) g.add(a);

  /* 双臂末端发光的拳 */
  g.add(part(M.golemGlow, 0.44, 0.2, 0.44, -0.88, 1.35, 0, false));
  g.add(part(M.golemGlow, 0.44, 0.2, 0.44,  0.88, 1.35, 0, false));

  const legs = [
    makeLeg(M.golemBody, 0.44, 1.35, 0.44, -0.36, 1.35, 0,  1),
    makeLeg(M.golemBody, 0.44, 1.35, 0.44,  0.36, 1.35, 0, -1),
  ];
  for (const l of legs) g.add(l);

  return { group: g, parts: { legs, head, body, tail: null, arms } };
}

/* ============================================================
   AI
   ------------------------------------------------------------
   全部「守家型」：玩家进入侦测半径就追，离开就回巢。
   用 world.moveWithCollision 做位移，和内置动物一致。
   ============================================================ */

/* 朝目标移动的通用逻辑 */
function chase(a, dt, playerPos, speed, stopDist){
  const dx = playerPos.x - a.pos.x;
  const dz = playerPos.z - a.pos.z;
  const dist = Math.hypot(dx, dz);

  if (dist > stopDist && dist > 0.001){
    const fx = dx / dist, fz = dz / dist;
    const k = Math.min(1, 6 * dt);
    a.vel.x += (fx * speed - a.vel.x) * k;
    a.vel.z += (fz * speed - a.vel.z) * k;
    /* 朝向玩家 */
    a.yaw = Math.atan2(-fx, -fz);
  } else {
    a.vel.x *= (1 - Math.min(1, 8 * dt));
    a.vel.z *= (1 - Math.min(1, 8 * dt));
  }
}

/* 找路：卡住就侧移（简单的绕障） */
function unstickIfNeeded(a, dt){
  if (a.hitWall && a.onGround){
    a._stuck = (a._stuck || 0) + dt;
    if (a._stuck > 0.35){
      a._stuck = 0;
      /* 随机侧移一段 */
      const side = Math.random() < 0.5 ? 1 : -1;
      a.yaw += side * Math.PI * 0.5;
      a.vel.x += Math.cos(a.yaw) * 2.2;
      a.vel.z += Math.sin(a.yaw) * 2.2;
    }
  } else {
    a._stuck = 0;
  }
}

/* 重力 + 位移（怪物通用） */
function physics(a, dt, world){
  a.inWater = world.isLiquidAt(a.pos.x, a.pos.y + a.height * 0.4, a.pos.z);
  if (a.inWater){
    a.vel.y += 26 * dt;
    if (a.vel.y > 2.0) a.vel.y = 2.0;
    a.vel.x *= (1 - Math.min(1, 1.8 * dt));
    a.vel.z *= (1 - Math.min(1, 1.8 * dt));
  } else {
    a.vel.y -= world.gravity * dt;
  }
  a.vel.y = Math.max(a.vel.y, -50);
  world.moveWithCollision(a, dt);
  /* 掉出世界就移除 */
  if (a.pos.y < world.Y_MIN - 2){
    try { world.removeAnimal && world.removeAnimal(a); } catch(e){}
    a.dead = true;
  }
}

/* ---------- 洞穴爬虫 AI ---------- */
function updateCrawler(a, dt, playerPos, world){
  const speed = 2.5;
  const detect = 14;
  const dx = playerPos.x - a.pos.x, dz = playerPos.z - a.pos.z;
  const d2 = dx * dx + dz * dz;

  if (d2 < detect * detect){
    a.state = 'chase';
    chase(a, dt, playerPos, speed, 1.3);
  } else {
    a.state = 'idle';
    /* 回巢 / 原地乱晃 */
    a.timer = (a.timer || 0) - dt;
    if (a.timer <= 0){
      a.timer = 1.5 + Math.random() * 2.5;
      a.yaw = Math.random() * Math.PI * 2;
    }
    const k = Math.min(1, 4 * dt);
    a.vel.x += (-Math.sin(a.yaw) * 0.6 - a.vel.x) * k;
    a.vel.z += (-Math.cos(a.yaw) * 0.6 - a.vel.z) * k;
  }

  /* 攻击：贴近就咬 */
  if (d2 < 2.2 * 2.2 && a.attackCd <= 0){
    a.attackCd = 1.1;
    try { G.damagePlayer(3); } catch(e){}
  }
  a.attackCd = (a.attackCd || 0) - dt;

  unstickIfNeeded(a, dt);
  physics(a, dt, world);
}

/* ---------- 矿工骸骨 AI ---------- */
function updateSkeletonMiner(a, dt, playerPos, world){
  const speed = 1.9;
  const detect = 16;
  const dx = playerPos.x - a.pos.x, dz = playerPos.z - a.pos.z;
  const d2 = dx * dx + dz * dz;

  if (d2 < detect * detect){
    a.state = 'chase';
    chase(a, dt, playerPos, speed, 1.6);
  } else {
    a.state = 'idle';
    a.vel.x *= (1 - Math.min(1, 6 * dt));
    a.vel.z *= (1 - Math.min(1, 6 * dt));
  }

  if (d2 < 2.6 * 2.6 && a.attackCd <= 0){
    a.attackCd = 1.5;
    try { G.damagePlayer(4); } catch(e){}
  }
  a.attackCd = (a.attackCd || 0) - dt;

  unstickIfNeeded(a, dt);
  physics(a, dt, world);
}

/* ---------- 石之幽魂 AI：漂浮，无视地形 ---------- */
function updateStoneWraith(a, dt, playerPos, world){
  const speed = 2.1;
  const detect = 20;
  const dx = playerPos.x - a.pos.x, dz = playerPos.z - a.pos.z;
  const dy = (playerPos.y + 1) - a.pos.y;
  const d2 = dx * dx + dz * dz;

  /* 幽魂没有腿，直接飞 */
  a.floatPhase = (a.floatPhase || 0) + dt * 1.6;

  if (d2 < detect * detect){
    a.state = 'chase';
    const dist = Math.sqrt(d2) || 1;
    const fx = dx / dist, fz = dz / dist;
    const k = Math.min(1, 3.5 * dt);
    /* 保持离地 1~2 格追人 */
    const targetY = playerPos.y + 1.2;
    a.vel.x += (fx * speed - a.vel.x) * k;
    a.vel.z += (fz * speed - a.vel.z) * k;
    a.vel.y += ((targetY - a.pos.y) * 1.6 - a.vel.y) * Math.min(1, 3 * dt);
    a.yaw = Math.atan2(-fx, -fz);
  } else {
    a.state = 'idle';
    /* 回到巢穴（出生点）上方悬浮 */
    const hx = (a._home ? a._home.x : a.pos.x) - a.pos.x;
    const hz = (a._home ? a._home.z : a.pos.z) - a.pos.z;
    const hd = Math.hypot(hx, hz);
    if (hd > 2){
      const k = Math.min(1, 2 * dt);
      a.vel.x += (hx / hd * 0.8 - a.vel.x) * k;
      a.vel.z += (hz / hd * 0.8 - a.vel.z) * k;
    } else {
      a.vel.x *= (1 - Math.min(1, 4 * dt));
      a.vel.z *= (1 - Math.min(1, 4 * dt));
    }
    /* 上下浮动 */
    const baseY = (a._home ? a._home.y : a.pos.y);
    a.vel.y += ((baseY + Math.sin(a.floatPhase) * 0.7) - a.pos.y) * 1.4 * dt;
  }

  /* 幽魂穿墙：自己的位移不做碰撞，但要防止掉出世界 */
  a.pos.x += a.vel.x * dt;
  a.pos.y += a.vel.y * dt;
  a.pos.z += a.vel.z * dt;
  if (a.pos.y < world.Y_MIN + 2) a.pos.y = world.Y_MIN + 2;

  if (d2 < 2.8 * 2.8 && a.attackCd <= 0){
    a.attackCd = 1.8;
    try { G.damagePlayer(5); } catch(e){}
  }
  a.attackCd = (a.attackCd || 0) - dt;
}

/* ---------- 黑曜石魔像 AI：慢、猛 ---------- */
function updateObsidianGolem(a, dt, playerPos, world){
  const speed = 1.25;
  const detect = 22;
  const dx = playerPos.x - a.pos.x, dz = playerPos.z - a.pos.z;
  const d2 = dx * dx + dz * dz;

  if (d2 < detect * detect){
    a.state = 'chase';
    chase(a, dt, playerPos, speed, 2.2);
  } else {
    a.state = 'idle';
    a.vel.x *= (1 - Math.min(1, 3 * dt));
    a.vel.z *= (1 - Math.min(1, 3 * dt));
  }

  if (d2 < 3.4 * 3.4 && a.attackCd <= 0){
    a.attackCd = 2.2;
    try { G.damagePlayer(9); } catch(e){}
  }
  a.attackCd = (a.attackCd || 0) - dt;

  unstickIfNeeded(a, dt);
  physics(a, dt, world);
}

/* ============================================================
   注册
   ============================================================ */
export function registerEntities(){
  ensureMat();

  G.registerEntity('sw_cave_crawler', {
    label: '洞穴爬虫',
    health: 12,
    width: 0.7, height: 0.7, depth: 0.9,
    speed: 2.5,
    category: 'land_predator',
    spawnKind: null,
    build: buildCrawler,
    update: updateCrawler,
    loot(){ return [{ name: 'sw_meat_raw', min: 1, max: 2 }]; },
  });

  G.registerEntity('sw_skeleton_miner', {
    label: '矿工骸骨',
    health: 20,
    width: 0.6, height: 1.8, depth: 0.6,
    speed: 1.9,
    category: 'land_predator',
    spawnKind: null,
    build: buildSkeletonMiner,
    update: updateSkeletonMiner,
    loot(){
      return [
        { name: 'sw_bone', min: 1, max: 2 },
        { name: 'sw_meat_raw', min: 0, max: 1 },
      ];
    },
  });

  G.registerEntity('sw_stone_wraith', {
    label: '石之幽魂',
    health: 30,
    width: 0.7, height: 2.1, depth: 0.7,
    speed: 2.1,
    flying: true,
    category: 'land_predator',
    spawnKind: null,
    build: buildStoneWraith,
    update: updateStoneWraith,
    loot(){
      return [
        { name: 'sw_bone', min: 0, max: 2 },
        { name: 'magic_dust', min: 1, max: 2 },
      ];
    },
  });

  G.registerEntity('sw_obsidian_golem', {
    label: '黑曜石魔像',
    health: 90,
    width: 1.4, height: 3.4, depth: 1.4,
    speed: 1.25,
    category: 'land_predator',
    spawnKind: null,
    build: buildObsidianGolem,
    update: updateObsidianGolem,
    loot(){
      return [
        { name: 'obsidian', min: 2, max: 5 },
        { name: 'sw_crystal_ore', min: 1, max: 3 },
        { name: 'sw_meat_raw', min: 1, max: 3 },
      ];
    },
  });

  /* 提高肉食上限，否则要塞里进不去怪 */
  try { G.setEntityCap('land_predator', 40); } catch(e){}

}

/* ============================================================
   结构刷怪
   ------------------------------------------------------------
   structures.js 返回本区块落下的结构列表，这里对每个结构
   按其 spawn 配置刷怪。用「锚点 key」去重，避免重复刷。
   ============================================================ */
export function spawnForStructures(hits){
  if (!hits || !hits.length) return 0;
  let spawned = 0;

  for (const h of hits){
    const st = h.st;
    if (!st.spawn) continue;

    const key = st.id + '@' + h.ax + ',' + h.ay + ',' + h.az;
    if (_spawned.has(key)) continue;

    /* ★ 注意：这里**不**用「锚点区块是否已加载」来过滤。
       大型结构横跨好几个区块，锚点可能在 40 格外的区块里（那边还没加载），
       而可刷怪的房间就在当前区块里。所以直接尝试找落点：
       找不到就跳过（不记标记），等邻居区块装饰时同一条命中再来一次。
       早期版本是「先记标记再刷」，导致第一次失败后这个结构永远刷不出怪。 */
    const cfg = st.spawn;
    const n = cfg.count || 1;
    const r = cfg.radius || 4;
    let got = 0;

    for (let i = 0; i < n; i++){
      const spot = findSpawnSpot(h.ax, h.ay, h.az, r);
      if (!spot) continue;

      let e = null;
      try {
        e = G.spawnEntity(cfg.type, spot.x, spot.y, spot.z);
      } catch (err){
        continue;
      }
      if (e){
        e._home = { x: h.ax + 0.5, y: h.ay + 1, z: h.az + 0.5 };
        got++;
      }
    }

    /* 只有真刷出来了才登记，否则等下次命中重试 */
    if (got > 0){
      if (_spawned.size > SPAWNED_CAP) _spawned.clear();
      _spawned.add(key);
      spawned += got;
    }
  }
  return spawned;
}

/* 在 (ax,ay,az) 周围半径 r 内找一个「脚下实心、身体位置空」的点 */
function findSpawnSpot(ax, ay, az, r){
  for (let attempt = 0; attempt < 24; attempt++){
    const ang = Math.random() * Math.PI * 2;
    const rad = Math.random() * r;
    const x = Math.floor(ax + Math.cos(ang) * rad);
    const z = Math.floor(az + Math.sin(ang) * rad);

    /* 从结构高度往上下各找 8 格 */
    for (let dy = -8; dy <= 8; dy++){
      const y = ay + dy;
      if (y < G.Y_MIN + 2 || y > G.CHH - 2) continue;
      /* 区块没加载时 getBlock 返回 0，会被误判成空气，显式跳过 */
      if (G.isLoadedAt && !G.isLoadedAt(x, y, z)) continue;
      const below = G.getBlock(x, y - 1, z);
      const here = G.getBlock(x, y, z);
      const above = G.getBlock(x, y + 1, z);
      if (below !== 0 && here === 0 && above === 0){
        return { x: x + 0.5, y: y, z: z + 0.5 };
      }
    }
  }
  return null;
}

/* 清理（切存档） */
export function resetEntityCache(){
  _spawned.clear();
}
