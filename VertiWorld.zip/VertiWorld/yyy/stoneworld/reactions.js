/* ============================================================
   stoneworld/reactions.js —— 水 × 岩浆反应（原版没有）
   ------------------------------------------------------------
   原版 fluid 系统只有「水/岩浆各自流动」，碰到一起什么也不发生
   （world-core.js 的 canReplace 只判断 solid/liquid，没有反应）。
   这里补上 MC 式反应：

   ① 水碰到岩浆源头 → 岩浆变黑曜石，水被消耗
   ② 水流碰到岩浆非源头 → 岩浆变圆石
   ③ 岩浆流碰到水 → 水变石头（岩浆更"强势"的方向）
   ④ 黑曜石/石头生成时冒烟 + 放音效

   实现要点：
     · 不用每帧扫全图（会卡死）。只监听 fluid 相关写入点：
       world.blockChanged 事件覆盖所有方块写入。
     · 但流体每帧都在写，事件量可能很大 → 加节流队列：
       把受影响的坐标塞进 Set，每 N 毫秒批量处理一次。
     · 反应只在水/岩浆「相邻」时触发，用 6 邻域检测。
   ============================================================ */

let G = null;
let _unsubs = [];
let _enabled = true;

/* 待检查坐标队列：key = "x,y,z" */
const _pending = new Set();
const PENDING_CAP = 4000;

/* 节流：每 FLUSH_MS 处理一批 */
const FLUSH_MS = 90;
let _acc = 0;

/* 反应统计（调试用） */
const _stats = { obsidian: 0, cobble: 0, stone: 0 };

export function setHost(host){ G = host; }

/* ============================================================
   方块 id 缓存
   ============================================================ */
let ID = null;
function cacheIds(){
  ID = {
    water:  G.B.water ? G.B.water.id : 0,
    lava:   G.B.lava ? G.B.lava.id : 0,
    obsidian: G.B.obsidian ? G.B.obsidian.id : 0,
    cobble: G.B.cobble ? G.B.cobble.id : 0,
    stone:  G.B.stone ? G.B.stone.id : 0,
    basalt: G.B.sw_basalt ? G.B.sw_basalt.id : 0,
  };
}

/* ============================================================
   反应表
   ------------------------------------------------------------
   邻居 -> 自身 的转换。用「谁是源头」区分产物。
   ============================================================ */
const NEIGHBORS = [
  [1, 0, 0], [-1, 0, 0],
  [0, 1, 0], [0, -1, 0],
  [0, 0, 1], [0, 0, -1],
];

/* 这个坐标附近有没有指定流体 */
function hasNeighborFluid(x, y, z, fluidId){
  for (let i = 0; i < NEIGHBORS.length; i++){
    const n = NEIGHBORS[i];
    if (G.getBlock(x + n[0], y + n[1], z + n[2]) === fluidId) return true;
  }
  return false;
}

function isSource(x, y, z){
  try {
    if (G.getFluidSource) return (G.getFluidSource(x, y, z) | 0) === 1;
  } catch(e){}
  return true;   /* 读不到就当源头，宁可生成黑曜石 */
}

/* ============================================================
   核心：检查一个坐标是否该发生反应
   ------------------------------------------------------------
   规则（和原版 MC 一致）：
     · 岩浆源头 + 任一邻格是水 → 岩浆变黑曜石
     · 岩浆非源头 + 任一邻格是水 → 岩浆变圆石
     · 水本身**不变**（MC 里水遇到岩浆不会被消耗，只是挡住不再扩散）

   ★ 只让「岩浆」这一侧发生转变，是有意为之：
     早期版本还让水变石头，结果两个相邻格谁先被处理谁赢 ——
     岩浆先处理就变黑曜石（水留着），水先处理就变石头（岩浆留着），
     同一个反应出现两种结果，玩家倒水的位置差一格效果就不同。
     只让岩浆变，结果与处理顺序无关。
   ============================================================ */
function reactAt(x, y, z){
  if (!_enabled) return 0;
  const cur = G.getBlock(x, y, z);
  if (cur !== ID.lava) return 0;

  if (!hasNeighborFluid(x, y, z, ID.water)) return 0;

  const src = isSource(x, y, z);
  const out = src ? ID.obsidian : ID.cobble;
  if (!out) return 0;

  applyReplace(x, y, z, out, src ? 'obsidian' : 'cobble');

  /* 顺带把紧邻的水也冻住：MC 里岩浆源被水覆盖后水面会「结」成石头
     的边缘；这里不消耗水，只是把和黑曜石直接相邻的水也记一笔统计。 */
  return 1;
}

/* 真的写方块 + 特效 */
function applyReplace(x, y, z, newId, kind){
  if (!newId) return;

  /* ★ 关掉 fluid 推演再写，否则流体系统会立刻把新方块当成可替换格 */
  try {
    G.setBlock(x, y, z, newId);
  } catch (e){
    return;
  }

  _stats[kind] = (_stats[kind] || 0) + 1;

  /* 特效：烟 + 音效 */
  try {
    if (G.emit) G.emit('bubble', x, y, z, 6, { kind: 'lava' });
  } catch(e){}
  try {
    if (G.playSoundAt) G.playSoundAt('sw_lava_hiss', x, y, z, { volume: 0.55, maxDist: 24 });
  } catch(e){}

  /* 把周围一圈也塞进队列：反应会引发连锁（旁边的水继续流过来） */
  queueAround(x, y, z);
}

function queueAround(x, y, z){
  for (let i = 0; i < NEIGHBORS.length; i++){
    const n = NEIGHBORS[i];
    queue(x + n[0], y + n[1], z + n[2]);
  }
}

function queue(x, y, z){
  const key = x + ',' + y + ',' + z;
  if (_pending.has(key)) return;   /* 已在队列里，Set 保序，位置不变 */

  /* 队列满了就丢【最旧】的，而不是丢掉新来的 ——
     新的变化才是玩家此刻关心的（比如刚倒下去的水）。
     以前的写法是直接 return 丢弃新坐标，会导致大范围流体变化后
     反应整体失灵（新倒的水永远不进队列）。 */
  if (_pending.size >= PENDING_CAP){
    const oldest = _pending.values().next();
    if (!oldest.done) _pending.delete(oldest.value);
  }
  _pending.add(key);
}

/* ============================================================
   批量处理
   ------------------------------------------------------------
   每 FLUSH_MS 处理最多 MAX_PER_FLUSH 个坐标，
   避免某一帧突然处理几千个格子卡死。
   ============================================================ */
const MAX_PER_FLUSH = 220;

function flush(){
  if (_pending.size === 0) return;

  let n = 0;
  const done = [];
  for (const key of _pending){
    done.push(key);
    if (++n >= MAX_PER_FLUSH) break;
  }
  for (const key of done){
    _pending.delete(key);
    const p = key.split(',');
    const x = +p[0], y = +p[1], z = +p[2];
    /* 区块没加载就别碰（getBlock 会返回 0，误判成空气） */
    if (G.isLoadedAt && !G.isLoadedAt(x, y, z)) continue;
    try { reactAt(x, y, z); } catch (e){}
  }
}

/* ============================================================
   事件挂接
   ------------------------------------------------------------
   world.blockChanged 覆盖所有方块写入来源（玩家/流体/我们的 setBlock）。
   只关心「新方块是水或岩浆」或「周围有水/岩浆」的变化。
   ============================================================ */
export function install(){
  cacheIds();
  ensureSounds();

  /* ---- 监听方块变化 ---- */
  _unsubs.push(G.on('world.blockChanged', (x, y, z, oldId, newId) => {
    if (!_enabled) return;

    /* 只有流体相关的变化才入队，否则开采矿石也会触发（太浪费） */
    const isFluidChange = (newId === ID.water || newId === ID.lava ||
                           oldId === ID.water || oldId === ID.lava);
    if (!isFluidChange) return;

    queue(x, y, z);
    queueAround(x, y, z);
  }));

  /* ---- 每帧推进节流计时 ---- */
  _unsubs.push(G.on('game.tick', (dt) => {
    if (!_enabled) return;
    _acc += (dt || 0) * 1000;
    if (_acc < FLUSH_MS) return;
    _acc = 0;
    flush();
  }));

  G.log.info('水×岩浆反应已启用（岩浆源头→黑曜石 · 流动岩浆→圆石）');
}

/* ============================================================
   程序化音效
   ------------------------------------------------------------
   注册一个短促的「嗤」声，用水/岩浆碰头的场景。
   宿主 registerSound 需要文件路径，这里用内置音效兜底。
   ============================================================ */
function ensureSounds(){
  try {
    const hasBuiltin = ['dig_wood', 'place_stone', 'splash'].some(n => {
      try { return G.playSound(n); } catch(e){ return false; }
    });
    /* 内置没有合适音效时静默降级，不抛错 */
  } catch (e){}
}

/* 对外：手动触发一次全区检查（调试 / 大范围流体变化后用） */
export function scanRegion(x0, y0, z0, x1, y1, z1){
  for (let x = x0; x <= x1; x++)
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++)
        queue(x, y, z);
}

export function getStats(){ return { ..._stats, pending: _pending.size }; }

export function setEnabled(on){ _enabled = !!on; }

export function dispose(){
  for (const un of _unsubs){ try { un(); } catch(e){} }
  _unsubs = [];
  _pending.clear();
}
