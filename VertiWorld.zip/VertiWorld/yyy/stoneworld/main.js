/* ============================================================
   stoneworld —— 石头世界（Rock World）
   ------------------------------------------------------------
   一个「整颗星球都是石头、没有天空没有海」的地下生存 mod。

   ┌── 玩法一览 ────────────────────────────────────────────────┐
   │ · 世界 100% 是岩石，分 4 层：基岩/深板岩/凝灰岩/石头        │
   │ · 出生点被挖成一个石室，旁边箱子有 10 个木头                │
   │ · 三维洞穴网络（大空腔 + 蠕虫隧道），靠石灯/发光菌照明        │
   │ · 9 种矿石（煤铁金钻红石青金翡翠晶簇）+ 化石矿（挖掉掉肉）    │
   │ · 洞穴里长「石根木」，洞穴顶部挂「荧光藤」                  │
   │ · 小型结构：石柱遗迹/矿工小屋/化石坑/菌丛/废弃矿道          │
   │ · 中型结构：祭坛厅/地下营地                               │
   │ · 大型结构：巨石神殿/地下要塞/巨型矿洞（会跨区块拼合）       │
   │ · 结构里刷 4 种怪：爬虫/骸骨/幽魂/魔像                    │
   │ · 补上原版缺失的「水×岩浆」反应：黑曜石/圆石（MC 语义）      │
   └───────────────────────────────────────────────────────────┘

   ⚠ 架构要点（都对着宿主源码验证过，不是猜的）
   ------------------------------------------------------------
   1. 宿主**不会**调用 mod 生成器的 heightAt / onChunkGen / onDecorate
      （MOD开发文档 第 9.5 节「已知限制」1）。唯一可行路径是监听
      `chunk.decorate`，在区块建网格之前改写 chunk.blocks。
   2. `chunk.decorate` 的 api.set() 直接落 c.blocks，不记存档 edits、
      不发事件 —— 正是生成期该有的语义。
   3. 两条生成路径的 applyEdits 时机不同（Worker 路径在 decorate 前，
      主线程路径在 decorate 后），所以本 mod 自己跟踪玩家改动、
      生成时还原，避免 Worker 路径重生成时抹掉建筑。
   4. 出生箱子是独立存档文件（chests/<dim>/x_y_z.json），mod 不能调
      items-core，所以用 /api/saves 的 PUT 接口写；服务端不支持时
      降级成「木头直接进背包」。
   5. 化石矿「挖掉掉肉」需要改原版掉落表（DROP_OVERRIDE 是 main.js
      的模块私有常量，mod 拿不到），因此配套 coremod：
      coremods/stoneworld_drops/ 用 RETURN 注入拦截 dropIdFor。
      没装 coremod 时本 mod 用 block.break 事件兜底补发肉。
   ============================================================ */

import {
  CFG, setHost as setWorldHost, cacheBlockIds, generateChunk,
  resetWorldCache, setPreserveMap,
} from './world.js';
import { registerBlocks, registerRecipes } from './blocks.js';
import { placeStructures, setHost as setStructHost } from './structures.js';
import {
  registerEntities, spawnForStructures, setHost as setEntityHost, resetEntityCache,
} from './entities.js';
import {
  install as installReactions, dispose as disposeReactions, setHost as setReactHost,
} from './reactions.js';
import { ensureSpawn, setHost as setSpawnHost, resetSpawnCache } from './spawn.js';

const VERSION = '1.0.0';
const GEN_ID = 'stone_world';
const COREMOD_ID = 'stoneworld_drops';

let G = null;
let _unsubs = [];
let _enabled = false;
let _active = false;

/* 存档元数据（onEnable 时从 world.json 拉的，比 G.getWorldOptions 全） */
let _saveMeta = { seed: 0, type: '', worldOptions: {} };

const _stats = { chunks: 0, structures: 0, spawns: 0 };

/* ============================================================
   玩家改动追踪
   ------------------------------------------------------------
   目的：区块重生成（磁盘缓存被关/失效）时，别把玩家挖的洞和盖的房子
   一起填回石头。宿主内部有 edits 表但不暴露给 mod，所以这里用
   world.blockChanged 自己记一份：
     Map<"cx,cz", Map<localIdx, blockId>>
   localIdx 与宿主一致：((y - Y_MIN) * 16 + z) * 16 + x

   流体变化不算「玩家改动」（水流动会不停发事件），过滤掉。
   ============================================================ */
const _edits = new Map();          // chunkKey -> Map(idx -> id)
let _editCount = 0;
const EDIT_CAP = 120000;           // 总条数上限，超了就停止记录
let _editsDirty = false;
let _editStore = null;

function _chunkKeyOf(x, z){
  return (Math.floor(x / 16)) + ',' + (Math.floor(z / 16));
}
function _localIdx(x, y, z){
  const cx = Math.floor(x / 16), cz = Math.floor(z / 16);
  const lx = x - cx * 16, lz = z - cz * 16;
  return (((y - G.Y_MIN) * 16) + lz) * 16 + lx;
}

function _isFluidId(id){
  return id === _fluidId(1) || id === _fluidId(0);   // water / lava
}
let _waterId = 0, _lavaId = 0;
function _fluidId(k){ return k ? _waterId : _lavaId; }

function _markEdit(x, y, z, id){
  if (_editCount >= EDIT_CAP) return;
  if (y < G.Y_MIN || y >= G.CHH) return;

  const key = _chunkKeyOf(x, z);
  let m = _edits.get(key);
  if (!m){ m = new Map(); _edits.set(key, m); }
  const i = _localIdx(x, y, z);
  if (!m.has(i)) _editCount++;
  m.set(i, id);
  _editsDirty = true;
}

/* 加载/保存（存成 {"cx,cz": [[idx,id],...]}，紧凑） */
async function _loadEdits(){
  if (!_editStore) return;
  try {
    const d = await _editStore.readJSON('edited.json');
    if (!d || !d.chunks) return;
    for (const [key, rows] of Object.entries(d.chunks)){
      const m = new Map();
      for (const row of rows){
        if (!Array.isArray(row) || row.length < 2) continue;
        m.set(row[0] | 0, row[1] | 0);
      }
      if (m.size){ _edits.set(key, m); _editCount += m.size; }
    }
    setPreserveMap(_edits);
    G.log.info(`已载入 ${_editCount} 条玩家改动记录（重生成时会保留）`);
  } catch (e){}
}

async function _saveEdits(){
  if (!_editStore || !_editsDirty) return;
  _editsDirty = false;
  const out = {};
  for (const [key, m] of _edits){
    const rows = [];
    for (const [i, id] of m) rows.push([i, id]);
    out[key] = rows;
  }
  try { await _editStore.writeJSON('edited.json', { v: 1, chunks: out }); }
  catch (e){ }
}

/* ============================================================
   存档元数据
   ============================================================ */
async function _fetchSaveMeta(saveId){
  if (!saveId) return null;
  try {
    const r = await fetch('/api/saves/' + encodeURIComponent(saveId) + '/world.json',
                          { cache: 'no-store' });
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || typeof j !== 'object') return null;
    return {
      seed: (typeof j.seed === 'number') ? j.seed : 0,
      type: j.type || '',
      worldOptions: (j.worldOptions && typeof j.worldOptions === 'object') ? j.worldOptions : {},
    };
  } catch (e){
    return null;
  }
}

/* ============================================================
   是否应用「石头世界」
   ------------------------------------------------------------
   玩家可能只在整合包里勾了这个 mod，却在普通世界玩 —— 那种情况
   只注册内容，不改地形（否则会把别人的世界填成石头）。
   ============================================================ */
function resolveActive(){
  /* ① 存档类型：最权威 */
  if (_saveMeta.type === GEN_ID) return true;

  /* ② 世界选项：石头世界类型会带这几个 key（创建界面填的默认值） */
  const wo = _saveMeta.worldOptions;
  if (wo && (('caveDensity' in wo) || ('oreDensity' in wo))) return true;

  /* ③ 再退一步，问宿主 */
  try {
    const g = G.getWorldOptions ? (G.getWorldOptions() || {}) : {};
    if (('caveDensity' in g) || ('oreDensity' in g)) return true;
  } catch (e){}

  return false;
}

function applyWorldOptions(){
  CFG.top = G.CHH;
  CFG.bottom = G.Y_MIN;

  const wo = _saveMeta.worldOptions || {};
  if (typeof wo.caveDensity === 'number') CFG.caveDensity = Math.max(0, Math.min(2, wo.caveDensity));
  if (typeof wo.oreDensity === 'number')  CFG.oreDensity  = Math.max(0, Math.min(3, wo.oreDensity));
  if (typeof wo.trees === 'boolean')      CFG.trees       = wo.trees;

  if (_saveMeta.seed) CFG.seed = _saveMeta.seed | 0;
  if (!CFG.seed) CFG.seed = 12345;
}

/* ============================================================
   区块装饰
   ============================================================ */
function onDecorate(chunk, api){
  if (!_active || !_enabled) return;
  if (!chunk || !chunk.blocks) return;

  /* ① 地形（全石 + 洞穴 + 矿脉 + 植物 + 液体 + 还原玩家改动） */
  let changed = false;
  try {
    changed = generateChunk(chunk, api);
  } catch (e){
    console.error('[stoneworld] 地形生成出错:', e);
    return;
  }
  if (changed) _stats.chunks++;

  /* ② 结构（放在地形之后，才有岩石可挖） */
  let hits = [];
  try {
    hits = placeStructures(api, chunk.cx | 0, chunk.cz | 0, CFG.seed | 0);
  } catch (e){
    console.error('[stoneworld] 结构生成出错:', e);
  }

  if (hits && hits.length){
    _stats.structures += hits.length;
    pendingSpawns.push(hits);
  }
}

/* ============================================================
   结构刷怪泵
   ------------------------------------------------------------
   区块刚 decorate 完就刷怪的话，getBlock 可能还没反映最新数据，
   而且一次性刷太多会卡。所以排队，每帧最多处理几批。
   ============================================================ */
const pendingSpawns = [];
const MAX_SPAWN_BATCH = 3;

function pumpSpawns(){
  if (pendingSpawns.length === 0) return;
  let n = 0;
  while (pendingSpawns.length && n < MAX_SPAWN_BATCH){
    const hits = pendingSpawns.shift();
    n++;
    try {
      const got = spawnForStructures(hits);
      if (got) _stats.spawns += got;
    } catch (e){}
  }
  /* 玩家跑图太快时别攒着 */
  if (pendingSpawns.length > 80) pendingSpawns.length = 0;
}

/* ============================================================
   世界进入
   ============================================================ */
async function onWorldEnter(){
  if (!_active){
    G.log.info(`石头世界 v${VERSION} 已加载（本世界不是石头世界，仅注册内容）`);
    return;
  }

  G.log.info(`石头世界 v${VERSION} 已启用 · 种子 ${CFG.seed} · ` +
             `洞穴 ${CFG.caveDensity} · 矿脉 ${CFG.oreDensity}`);
  try { await ensureSpawn(); } catch (e){ G.log.error('出生点生成失败：', e); }

  setTimeout(() => {
    try { showIntroToast(); runSelfCheck(); } catch (e){}
  }, 1200);
}

/* 提示条（自己画，不依赖宿主有没有 toast） */
function showIntroToast(){
  const id = 'sw-intro-toast';
  if (document.getElementById(id)) return;

  const el = document.createElement('div');
  el.id = id;
  el.textContent = '🪨 石头世界：你被埋在岩石深处，先找到旁边的箱子。';
  el.style.cssText = [
    'position:fixed', 'left:50%', 'transform:translateX(-50%)',
    'top:72px', 'z-index:9999',
    'padding:10px 16px', 'border-radius:10px',
    'background:rgba(26,22,32,0.92)', 'color:#e8e0f8',
    'font:500 14px/1.5 system-ui,sans-serif',
    'border:1px solid rgba(168,140,220,0.45)',
    'box-shadow:0 4px 18px rgba(0,0,0,0.45)',
    'pointer-events:none', 'transition:opacity .6s',
  ].join(';');
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; }, 5200);
  setTimeout(() => { el.remove(); }, 6000);
}

/* 自检：确认地形真的被改造成了石头世界 */
function runSelfCheck(){
  const p = G.getPos();
  let solid = 0, total = 0;
  for (let i = 0; i < 40; i++){
    const a = (i / 40) * Math.PI * 2;
    for (const r of [16, 48, 96]){
      const x = Math.round(p.x + Math.cos(a) * r);
      const z = Math.round(p.z + Math.sin(a) * r);
      const r2 = G.getBlockEx
        ? G.getBlockEx(x, Math.round(p.y), z)
        : { id: G.getBlock(x, Math.round(p.y), z), loaded: true };
      if (!r2.loaded) continue;
      total++;
      if (r2.id !== 0) solid++;
    }
  }
  const ratio = total ? solid / total : 0;
  if (total > 0 && ratio < 0.35){
    G.log.warn(
      `【石头世界自检】玩家高度上只有 ${(ratio * 100).toFixed(0)}% 是实心方块 —— ` +
      `地形可能没有正确替换（预期 >85%）。请确认世界类型选的是「石头世界」。`
    );
  } else {
    G.log.info(`【石头世界自检】实心占比 ${(ratio * 100).toFixed(0)}% · 洞穴与结构正常`);
  }
}

/* ============================================================
   化石矿 → 肉
   ------------------------------------------------------------
   主路径是 coremod（coremods/stoneworld_drops 拦截 dropIdFor）。
   没装 coremod 时用 block.break 补发一份肉，不能让化石矿白挖。
   ============================================================ */
function coremodActive(){
  try {
    const list = window.__COREMODS__;
    if (Array.isArray(list)) return list.some(m => m && m.id === COREMOD_ID);
  } catch (e){}
  return false;
}

function installFossilFallback(){
  const fossil = G.B.sw_fossil_ore;
  const meat = G.B.sw_meat_raw;
  const bone = G.B.sw_bone;
  if (!fossil || !meat) return;

  let warned = false;
  _unsubs.push(G.on('block.break', (x, y, z, id, willDrop) => {
    if (id !== fossil.id) return;
    if (!willDrop) return;                 /* 镐子不对/创造模式：不掉 */

    /* 有 coremod：掉落已经被换成肉了，这里只补骨头 */
    if (!coremodActive()){
      if (!warned){
        warned = true;
        G.log.warn('未检测到 coremod「stoneworld_drops」，化石矿用事件兜底掉肉（' +
                   '会和化石矿方块一起掉）。装上 coremods/stoneworld_drops 更干净。');
      }
      try { G.spawnDrop(x + 0.5, y + 0.55, z + 0.5, meat.id, 1); } catch (e){}
    }

    /* 骨头：50% 概率 */
    if (bone && Math.random() < 0.5){
      try { G.spawnDrop(x + 0.5, y + 0.55, z + 0.5, bone.id, 1); } catch (e){}
    }
  }));
}

/* ============================================================
   生命周期
   ============================================================ */
export default {
  async onEnable(saveId, meta, host){
    G = host;
    _enabled = true;
    _unsubs = [];

    /* ---- 拉存档元数据（种子 / 类型 / 世界选项） ---- */
    const sm = await _fetchSaveMeta(saveId);
    if (sm) _saveMeta = sm;

    _waterId = G.B.water ? G.B.water.id : 0;
    _lavaId  = G.B.lava ? G.B.lava.id : 0;

    _active = resolveActive();
    applyWorldOptions();

    /* ---- 注册方块 / 配方 ---- */
    try {
      registerBlocks(G);
      registerRecipes();
    } catch (e){
      G.log.error('方块注册失败：', e);
      return;
    }

    /* ---- 先接宿主，再缓存 id（cacheBlockIds 要读 G.B） ---- */
    setWorldHost(G);
    setEntityHost(G);
    setReactHost(G);
    setSpawnHost(G);

    const ID = cacheBlockIds();
    setStructHost(G, ID);

    /* ---- 实体 ---- */
    try { registerEntities(); }
    catch (e){ G.log.error('实体注册失败：', e); }

    /* ---- 水×岩浆反应（与是否石头世界无关，都装上） ---- */
    try { installReactions(); }
    catch (e){ G.log.warn('水岩浆反应启动失败：', e && e.message); }

    /* ---- 化石掉肉兜底 ---- */
    try { installFossilFallback(); } catch (e){}

    /* ---- 玩家改动追踪 ---- */
    _editStore = G.storage ? G.storage('stoneworld') : null;
    _unsubs.push(G.on('world.blockChanged', (x, y, z, oldId, newId) => {
      if (!_active) return;
      if (oldId === newId) return;
      /* 流体流动不算玩家改动 */
      if (_isFluidId(newId) || _isFluidId(oldId)) return;
      _markEdit(x, y, z, newId);
    }));
    _unsubs.push(G.on('world.enter', () => { _loadEdits().catch(() => {}); }));
    _unsubs.push(G.on('world.leave', () => { _saveEdits().catch(() => {}); }));
    _unsubs.push(G.on('world.save', () => { _saveEdits().catch(() => {}); }));

    /* ---- 区块装饰 ---- */
    _unsubs.push(G.on('chunk.decorate', (chunk, api) => {
      try { onDecorate(chunk, api); } catch (e){}
    }));

    /* ---- 刷怪泵 ---- */
    _unsubs.push(G.on('game.tick', () => {
      if (!_active) return;
      pumpSpawns();
    }));

    /* ---- 世界进入 ---- */
    _unsubs.push(G.on('world.enter', () => {
      onWorldEnter().catch(e => G.log.error('进入世界处理失败：', e));
    }));

    /* ---- 自定义提示 ---- */
    _unsubs.push(G.on('sw.notify', (msg) => {
      try { showNotifyToast(msg); } catch (e){}
    }));

    G.log.info(`石头世界 v${VERSION} · ${_active ? '全石世界已激活' : '仅内容模式'} · ` +
               `高度 ${G.Y_MIN}~${G.CHH} · 种子 ${CFG.seed}`);
  },

  onDisable(saveId){
    for (const un of _unsubs){ try { un(); } catch (e){} }
    _unsubs = [];
    pendingSpawns.length = 0;
    try { disposeReactions(); } catch (e){}
    try { _saveEdits(); } catch (e){}
    _edits.clear();
    _editCount = 0;
    setPreserveMap(null);
    resetWorldCache();
    resetEntityCache();
    resetSpawnCache();
    _enabled = false;
    _active = false;
    G = null;
  },

  /* 调试：控制台里 __stoneworld_debug() 查状态 */
  debug(){
    return {
      version: VERSION,
      active: _active,
      seed: CFG.seed,
      cfg: { ...CFG },
      saveMeta: { ..._saveMeta },
      stats: { ..._stats, edits: _editCount },
    };
  },
};

/* 通知条 */
function showNotifyToast(msg){
  const id = 'sw-notify-toast';
  const old = document.getElementById(id);
  if (old) old.remove();

  const el = document.createElement('div');
  el.id = id;
  el.textContent = msg;
  el.style.cssText = [
    'position:fixed', 'left:50%', 'transform:translateX(-50%)',
    'top:112px', 'z-index:9999', 'max-width:80vw',
    'padding:10px 16px', 'border-radius:10px',
    'background:rgba(32,26,42,0.94)', 'color:#f0e8ff',
    'font:500 14px/1.5 system-ui,sans-serif',
    'border:1px solid rgba(168,140,220,0.5)',
    'box-shadow:0 4px 18px rgba(0,0,0,0.5)',
    'pointer-events:none', 'text-align:center',
    'transition:opacity .6s',
  ].join(';');
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; }, 6000);
  setTimeout(() => { el.remove(); }, 6800);
}

