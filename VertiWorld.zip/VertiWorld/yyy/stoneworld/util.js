/* ============================================================
   stoneworld/util.js —— 确定性随机 + 噪声 + 小工具
   ------------------------------------------------------------
   所有地形、结构、矿脉的随机都由「坐标 + 世界种子」哈希出来，
   不用 Math.random()。原因：
     · 区块可能被卸载后重新生成，用 Math.random() 会得到不同结果
     · Worker 与主线程两条生成路径必须得到一模一样的区块
   ============================================================ */

export const CS = 16;

/* ---------------- 32 位整型哈希 ---------------- */
export function hash2i(x, y, seed){
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041);
  h = (h ^ (h >>> 13)) | 0;
  h = Math.imul(h, 1274126177) | 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/* 3 维哈希，用于矿脉三轴定位 */
export function hash3i(x, y, z, seed){
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263)
        + Math.imul(z | 0, 2246822519) + Math.imul(seed | 0, 1442695041);
  h = (h ^ (h >>> 13)) | 0;
  h = Math.imul(h, 1274126177) | 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/* ---------------- 可复现的 PRNG ---------------- */
export function mulberry32(a){
  let s = a | 0;
  return function(){
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* 由坐标 + 种子造一个 PRNG */
export function rngAt(x, z, seed, salt){
  const h = (Math.imul(x | 0, 73856093) ^ Math.imul(z | 0, 19349663)
           ^ Math.imul(seed | 0, 83492791) ^ Math.imul(salt | 0, 2654435761)) >>> 0;
  return mulberry32(h);
}

/* ---------------- 值噪声 ---------------- */
export function vnoise2(x, y, seed){
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2i(xi, yi, seed),     b = hash2i(xi + 1, yi, seed);
  const c = hash2i(xi, yi + 1, seed), d = hash2i(xi + 1, yi + 1, seed);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
}

export function vnoise3(x, y, z, seed){
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const w = zf * zf * (3 - 2 * zf);

  const c000 = hash3i(xi,     yi,     zi,     seed);
  const c100 = hash3i(xi + 1, yi,     zi,     seed);
  const c010 = hash3i(xi,     yi + 1, zi,     seed);
  const c110 = hash3i(xi + 1, yi + 1, zi,     seed);
  const c001 = hash3i(xi,     yi,     zi + 1, seed);
  const c101 = hash3i(xi + 1, yi,     zi + 1, seed);
  const c011 = hash3i(xi,     yi + 1, zi + 1, seed);
  const c111 = hash3i(xi + 1, yi + 1, zi + 1, seed);

  const x00 = c000 * (1 - u) + c100 * u;
  const x10 = c010 * (1 - u) + c110 * u;
  const x01 = c001 * (1 - u) + c101 * u;
  const x11 = c011 * (1 - u) + c111 * u;

  const y0 = x00 * (1 - v) + x10 * v;
  const y1 = x01 * (1 - v) + x11 * v;

  return y0 * (1 - w) + y1 * w;
}

export function fbm2(x, y, oct, seed){
  let s = 0, amp = 0.5, f = 1, norm = 0;
  for (let i = 0; i < oct; i++){
    s += vnoise2(x * f, y * f, seed + i * 1013) * amp;
    norm += amp; amp *= 0.5; f *= 2;
  }
  return s / norm;
}

export function fbm3(x, y, z, oct, seed){
  let s = 0, amp = 0.5, f = 1, norm = 0;
  for (let i = 0; i < oct; i++){
    s += vnoise3(x * f, y * f, z * f, seed + i * 1013) * amp;
    norm += amp; amp *= 0.5; f *= 2;
  }
  return s / norm;
}

/* ---------------- 通用 ---------------- */
export function clamp(v, lo, hi){ return v < lo ? lo : (v > hi ? hi : v); }

export function dist2(ax, az, bx, bz){
  const dx = ax - bx, dz = az - bz;
  return dx * dx + dz * dz;
}

/* 在 [a,b] 闭区间取整 */
export function randInt(rnd, a, b){ return a + Math.floor(rnd() * (b - a + 1)); }

export function pick(rnd, arr){ return arr[Math.floor(rnd() * arr.length)]; }
