/* ============================================================
   stoneworld/structures.js —— 结构生成（大型 + 小型）
   ------------------------------------------------------------
   结构分两档：
     小型（单区块内完成，密度高）
       · 石柱遗迹 / 矿工小屋 / 化石坑 / 荧光菌丛 / 废弃矿道（短）
     中型（单区块内完成，密度低）
       · 地下村落（几间房）/ 祭坛 / 沉没神殿
     大型（跨区块，用格点定位 + 分区裁剪）
       · 巨石神殿 / 地下要塞 / 巨型矿洞

   ★ 跨区块的关键手法（没有跨区块写权限）：
     结构用「格点法」定位：每 STRUCT_CELL 格有一个结构锚点，
     锚点由哈希决定存在与否 + 随机偏移。生成某个区块时，
     遍历附近 3×3 个格点，把落在本区块范围内的部分画出来。
     这样每块区块各自画自己那部分，拼起来就是完整结构，
     既不需要跨区块写，也能保证两边算出来一模一样。
   ============================================================ */

import {
  CS, hash2i, rngAt, mulberry32, fbm2, fbm3, randInt, clamp, pick,
} from './util.js';
import { CFG, isPreserved } from './world.js';

let G = null;
let ID = null;

export function setHost(host, idTable){ G = host; ID = idTable; }

/* ============================================================
   工具：把世界坐标的方块写到可能不在本区块的 api
   ------------------------------------------------------------
   只有区块内坐标（0~15）能写，超出就丢弃 —— 那部分由
   相邻区块自己画。这是跨区块结构能拼合的根本原因。
   ============================================================ */
function put(api, wx, wy, wz, id, cx, cz, force){
  const lx = wx - cx * CS, lz = wz - cz * CS;
  if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return;
  if (wy <= CFG.bottom + 2 || wy >= CFG.top - 2) return;

  /* ★ 玩家改过的方块不覆盖（重生成时保护建筑） */
  if (isPreserved(wx, wy, wz)) return;

  /* ★ id === 0 表示「挖空」：这条以前被 `if (!id) return` 挡掉了，
     导致所有结构内部都没挖开 —— 石头世界里结构就是一堆实心砖，
     怪也刷不出来（刷怪点要求脚下实心、身体位置是空气）。 */
  if (id === 0){
    api.set(lx, wy, lz, 0);
    return;
  }

  if (!force){
    const cur = api.get(lx, wy, lz);
    /* 不覆盖矿石/植物等，只允许覆盖普通岩石 */
    if (cur !== 0 && cur !== ID.stone && cur !== ID.deepslate && cur !== ID.tuff) return;
  }
  api.set(lx, wy, lz, id);
}

/* 读（越界返回 -1，区别于空气 0） */
function get(api, wx, wy, wz, cx, cz){
  const lx = wx - cx * CS, lz = wz - cz * CS;
  if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return -1;
  if (wy <= CFG.bottom || wy >= CFG.top) return -1;
  return api.get(lx, wy, lz);
}

/* ============================================================
   结构登记表
   ------------------------------------------------------------
   每个结构：
     id       唯一名
     kind     'small' | 'mid' | 'large'
     cell     格点边长（世界格）—— 越大结构越稀疏
     chance   格点命中概率
     yLo/yHi  相对高度区间（0=底 1=顶）
     build(ctx) 见下方 ctx 定义
     spawn    刷怪配置（可选）
   ============================================================ */
export const STRUCTURES = [
  /* ---------------- 小型 ---------------- */
  {
    id: 'pillar_ruin', kind: 'small', cell: 96, chance: 0.30,
    yLo: 0.30, yHi: 0.90,   /* 0.90 由 chance 控制 */
    build: buildPillarRuin,
  },
  {
    id: 'miner_hut', kind: 'small', cell: 128, chance: 0.24,
    yLo: 0.32, yHi: 0.85,
    build: buildMinerHut,
    spawn: { type: 'sw_skeleton_miner', count: 1, radius: 3 },
  },
  {
    id: 'fossil_pit', kind: 'small', cell: 112, chance: 0.26,
    yLo: 0.20, yHi: 0.70,
    build: buildFossilPit,
  },
  {
    id: 'glow_grove', kind: 'small', cell: 80, chance: 0.34,
    yLo: 0.25, yHi: 0.85,
    build: buildGlowGrove,
  },
  {
    id: 'mine_shaft', kind: 'small', cell: 144, chance: 0.20,
    yLo: 0.15, yHi: 0.75,
    build: buildMineShaft,
    spawn: { type: 'sw_cave_crawler', count: 2, radius: 5 },
  },

  /* ---------------- 中型 ---------------- */
  {
    id: 'altar_chamber', kind: 'mid', cell: 208, chance: 0.22,
    yLo: 0.18, yHi: 0.62,
    build: buildAltarChamber,
    spawn: { type: 'sw_stone_wraith', count: 1, radius: 4 },
  },
  {
    id: 'underground_camp', kind: 'mid', cell: 176, chance: 0.26,
    yLo: 0.30, yHi: 0.80,
    build: buildUndergroundCamp,
    spawn: { type: 'sw_cave_crawler', count: 2, radius: 6 },
  },

  /* ---------------- 大型 ---------------- */
  {
    id: 'stone_temple', kind: 'large', cell: 352, chance: 0.30,
    yLo: 0.26, yHi: 0.72,
    build: buildStoneTemple,
    spawn: { type: 'sw_stone_wraith', count: 3, radius: 8 },
  },
  {
    id: 'deep_fortress', kind: 'large', cell: 448, chance: 0.26,
    /* 要塞要在「深处」但不能埋进基岩层（t<0.04 是基岩），
       所以下限抬到 0.10，让 h=7 的要塞整体落在深板岩带里。 */
    yLo: 0.10, yHi: 0.34,
    build: buildDeepFortress,
    spawn: { type: 'sw_obsidian_golem', count: 1, radius: 6 },
  },
  {
    id: 'great_cavern', kind: 'large', cell: 384, chance: 0.30,
    yLo: 0.12, yHi: 0.55,
    build: buildGreatCavern,
    spawn: { type: 'sw_cave_crawler', count: 4, radius: 10 },
  },
];

/* ============================================================
   各结构的具体实现
   ------------------------------------------------------------
   ctx = {
     api, cx, cz,                区块坐标
     wx0, wz0,                   区块世界坐标原点点
     ax, az, ay,                 结构锚点（世界坐标）
     rnd,                        结构专用 PRNG
     seed,                       世界种子
   }
   ============================================================ */

/* ---------- 石柱遗迹：一圈断柱 + 中央台 ---------- */
function buildPillarRuin(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 4 + (rnd() * 3 | 0);
  const n = 5 + (rnd() * 4 | 0);

  /* 清出一块空间 */
  carveBox(ctx, ax - r, ay - 1, az - r, ax + r, ay + 4, az + r);

  /* 中央台 */
  for (let dx = -1; dx <= 1; dx++)
    for (let dz = -1; dz <= 1; dz++)
      put(api, ax + dx, ay - 1, az + dz, ID.ruinBrick, cx, cz, true);

  /* 一圈柱子，高低不一 */
  const phase = rnd() * Math.PI * 2;
  for (let i = 0; i < n; i++){
    const a = phase + (i / n) * Math.PI * 2;
    const px = Math.round(ax + Math.cos(a) * r);
    const pz = Math.round(az + Math.sin(a) * r);
    const h = 1 + (rnd() * 4 | 0);
    for (let k = 0; k < h; k++){
      put(api, px, ay - 1 + k, pz, ID.ruinBrick, cx, cz, true);
    }
    /* 顶部偶尔有石灯 */
    if (h >= 3 && rnd() < 0.4) put(api, px, ay - 1 + h, pz, ID.lamp, cx, cz, true);
  }
}

/* ---------- 矿工小屋：小房间 + 箱子位置 + 石灯 ---------- */
function buildMinerHut(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const w = 3 + (rnd() * 2 | 0);
  const d = 3 + (rnd() * 2 | 0);
  const h = 3;

  carveBox(ctx, ax - w, ay - 1, az - d, ax + w, ay + h, az + d);

  /* 地板 */
  for (let x = -w; x <= w; x++)
    for (let z = -d; z <= d; z++)
      put(api, ax + x, ay - 1, az + z, ID.ruinBrick, cx, cz, true);

  /* 墙：四面，留门 */
  const doorSide = rnd() < 0.5 ? 'x' : 'z';
  const doorAt = (rnd() < 0.5 ? -1 : 1) * (doorSide === 'x' ? 0 : 0);
  for (let y = 0; y <= h; y++){
    for (let x = -w; x <= w; x++){
      for (let z = -d; z <= d; z++){
        const onX = (x === -w || x === w);
        const onZ = (z === -d || z === d);
        if (!onX && !onZ) continue;
        /* 门口留空 */
        const isDoor = (doorSide === 'x')
          ? (x === w && z >= -1 && z <= 1 && y <= 2)
          : (z === d && x >= -1 && x <= 1 && y <= 2);
        if (isDoor) continue;
        put(api, ax + x, ay + y, az + z, ID.ruinBrick, cx, cz, true);
      }
    }
  }

  /* 天花板 */
  for (let x = -w; x <= w; x++)
    for (let z = -d; z <= d; z++)
      put(api, ax + x, ay + h + 1, az + z, ID.ruinBrick, cx, cz, true);

  /* 屋内：工作台 + 石灯 + 矿道入口 */
  put(api, ax - w + 1, ay, az - d + 1, ID.lamp, cx, cz, true);
  if (G && G.B.crafting_table) put(api, ax + w - 1, ay, az - d + 1, G.B.crafting_table.id, cx, cz, true);
}

/* ---------- 化石坑：一堆化石矿 + 骨头装饰 ---------- */
function buildFossilPit(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 3 + (rnd() * 2 | 0);

  carveBox(ctx, ax - r, ay, az - r, ax + r, ay + 3, az + r);

  /* 坑壁布满化石 */
  for (let dx = -r; dx <= r; dx++){
    for (let dz = -r; dz <= r; dz++){
      for (let dy = 0; dy <= 3; dy++){
        const d2 = dx * dx + dz * dz;
        if (d2 > r * r) continue;
        if (d2 > (r - 1) * (r - 1) && rnd() < 0.55){
          put(api, ax + dx, ay - 1 + dy, az + dz, ID.fossil, cx, cz, true);
        }
      }
    }
  }
  /* 中央多放几个 */
  for (let i = 0; i < 5; i++){
    const dx = (rnd() * (r * 2 + 1) | 0) - r;
    const dz = (rnd() * (r * 2 + 1) | 0) - r;
    put(api, ax + dx, ay - 1, az + dz, ID.fossil, cx, cz, true);
  }
}

/* ---------- 荧光菌丛：一大片发光菌 + 石苔 ---------- */
function buildGlowGrove(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 5 + (rnd() * 3 | 0);

  carveBox(ctx, ax - r, ay - 1, az - r, ax + r, ay + 3, az + r);

  for (let dx = -r; dx <= r; dx++){
    for (let dz = -r; dz <= r; dz++){
      const d2 = dx * dx + dz * dz;
      if (d2 > r * r) continue;
      /* 地板 */
      const cur = get(api, ax + dx, ay - 1, az + dz, cx, cz);
      if (cur >= 0 && cur === 0) {
        put(api, ax + dx, ay - 1, az + dz, ID.cracked, cx, cz, true);
      }
      /* 菌 */
      if (rnd() < 0.30) put(api, ax + dx, ay, az + dz, ID.glowShroom, cx, cz, true);
      else if (rnd() < 0.16) put(api, ax + dx, ay, az + dz, ID.moss, cx, cz, true);
      /* 靠外的挂荧光藤 */
      if (d2 > (r - 2) * (r - 2) && rnd() < 0.22){
        for (let k = 0; k < randInt(rnd, 1, 3); k++){
          put(api, ax + dx, ay + 3 - k, az + dz, ID.glowVine, cx, cz, true);
        }
      }
    }
  }
}

/* ---------- 废弃矿道：一条横向坑道 + 木支撑 ---------- */
function buildMineShaft(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const len = 8 + (rnd() * 8 | 0);
  const dirX = rnd() < 0.5;
  const sign = rnd() < 0.5 ? 1 : -1;

  for (let i = 0; i < len; i++){
    const x = dirX ? ax + i * sign : ax;
    const z = dirX ? az : az + i * sign;
    /* 挖 2 高 2 宽的坑道 */
    for (let dx = 0; dx <= 1; dx++){
      for (let dy = 0; dy <= 1; dy++){
        put(api, x + (dirX ? 0 : dx), ay + dy, z + (dirX ? dx : 0), 0, cx, cz, true);
      }
    }
    /* 每 3 格一个木支撑 */
    if (i % 3 === 0){
      const sx = x + (dirX ? 0 : 0), sz = z + (dirX ? 0 : 0);
      const px = dirX ? sx : sx - 1;
      const pz = dirX ? sz - 1 : sz;
      if (ID.rootLog){
        put(api, px, ay, pz, ID.rootLog, cx, cz, true);
        put(api, px, ay + 1, pz, ID.rootLog, cx, cz, true);
        /* 横向梁 */
        if (dirX) put(api, px, ay + 2, pz + 1, ID.rootLog, cx, cz, true);
        else put(api, px + 1, ay + 2, pz, ID.rootLog, cx, cz, true);
      }
    }
    /* 偶尔有石灯照明 */
    if (i % 6 === 3 && rnd() < 0.6){
      put(api, x, ay + 2, z, ID.lamp, cx, cz, true);
    }
  }
}

/* ---------- 祭坛厅：圆形大厅 + 符文砖 + 中央祭坛 ---------- */
function buildAltarChamber(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 7 + (rnd() * 3 | 0);
  const h = 5;

  /* 圆形挖空 */
  for (let dx = -r; dx <= r; dx++){
    for (let dz = -r; dz <= r; dz++){
      const d2 = dx * dx + dz * dz;
      if (d2 > r * r) continue;
      /* 地板 */
      put(api, ax + dx, ay - 1, az + dz, d2 > (r - 2) * (r - 2) ? ID.runeBrick : ID.ruinBrick, cx, cz, true);
      /* 内部空气 */
      for (let dy = 0; dy < h; dy++) put(api, ax + dx, ay + dy, az + dz, 0, cx, cz, true);
      /* 天花板 */
      put(api, ax + dx, ay + h, az + dz, ID.runeBrick, cx, cz, true);
    }
  }

  /* 中央祭坛，2 层台 + 祭坛方块 */
  for (let dx = -2; dx <= 2; dx++)
    for (let dz = -2; dz <= 2; dz++){
      if (Math.abs(dx) + Math.abs(dz) > 3) continue;
      put(api, ax + dx, ay, az + dz, ID.ruinBrick, cx, cz, true);
    }
  put(api, ax, ay + 1, az, ID.altar, cx, cz, true);

  /* 四角石灯 */
  for (const [sx, sz] of [[-1,-1],[1,-1],[-1,1],[1,1]]){
    const px = ax + sx * (r - 1), pz = az + sz * (r - 1);
    put(api, px, ay, pz, ID.lamp, cx, cz, true);
  }
}

/* ---------- 地下营地：几间房 + 火把 + 箱子位置 ---------- */
function buildUndergroundCamp(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const rooms = 3;

  for (let i = 0; i < rooms; i++){
    const ox = (rnd() * 10 | 0) - 5;
    const oz = (rnd() * 10 | 0) - 5;
    const w = 2 + (rnd() * 2 | 0);
    const d = 2 + (rnd() * 2 | 0);
    const h = 3;

    carveBox(ctx, ax + ox - w, ay - 1, az + oz - d, ax + ox + w, ay + h, az + oz + d);

    /* 地板 + 三层墙，留一个门 */
    for (let x = -w; x <= w; x++){
      for (let z = -d; z <= d; z++){
        put(api, ax + ox + x, ay - 1, az + oz + z, ID.ruinBrick, cx, cz, true);
        const edge = (x === -w || x === w || z === -d || z === d);
        if (!edge) continue;
        const door = (x === w && z >= -1 && z <= 0);
        for (let y = 0; y <= h; y++){
          if (door && y <= 1) continue;
          put(api, ax + ox + x, ay + y, az + oz + z, ID.ruinBrick, cx, cz, true);
        }
      }
    }
    /* 天花板 */
    for (let x = -w; x <= w; x++)
      for (let z = -d; z <= d; z++)
        put(api, ax + ox + x, ay + h + 1, az + oz + z, ID.ruinBrick, cx, cz, true);

    /* 灯 */
    put(api, ax + ox, ay + h, az + oz, ID.lamp, cx, cz, true);
  }
}

/* ---------- 巨石神殿：大型，圆柱大厅 + 多重祭坛 + 符文墙 ---------- */
function buildStoneTemple(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 13 + (rnd() * 4 | 0);
  const h = 9;

  /* 主体：圆柱形大厅挖空，边缘一圈符文砖 */
  for (let dx = -r; dx <= r; dx++){
    for (let dz = -r; dz <= r; dz++){
      const d2 = dx * dx + dz * dz;
      if (d2 > r * r) continue;

      /* 地板：中央遗迹砖，外圈符文砖 */
      const d = Math.sqrt(d2);
      put(api, ax + dx, ay - 1, az + dz, d > r - 3 ? ID.runeBrick : ID.ruinBrick, cx, cz, true);

      /* 挖空内部 */
      for (let dy = 0; dy < h; dy++) put(api, ax + dx, ay + dy, az + dz, 0, cx, cz, true);

      /* 天花板 */
      put(api, ax + dx, ay + h, az + dz, d > r - 3 ? ID.runeBrick : ID.ruinBrick, cx, cz, true);

      /* 外圈柱子 */
      if (d > r - 2.5 && d < r - 0.5){
        const ang = Math.atan2(dz, dx);
        const sector = Math.round(ang / (Math.PI / 4));
        const sa = sector * (Math.PI / 4);
        if (Math.abs(ang - sa) < 0.12){
          for (let dy = 0; dy < h; dy++) put(api, ax + dx, ay + dy, az + dz, ID.ruinBrick, cx, cz, true);
        }
      }
    }
  }

  /* 中央三层祭坛 */
  for (let dy = 0; dy < 3; dy++){
    const rr = 3 - dy;
    for (let dx = -rr; dx <= rr; dx++)
      for (let dz = -rr; dz <= rr; dz++){
        if (Math.abs(dx) + Math.abs(dz) > rr + 1) continue;
        put(api, ax + dx, ay + dy, az + dz, ID.ruinBrick, cx, cz, true);
      }
  }
  put(api, ax, ay + 3, az, ID.altar, cx, cz, true);

  /* 四个方向的石灯 + 符文柱 */
  for (let i = 0; i < 4; i++){
    const a = i * Math.PI / 2;
    const px = Math.round(ax + Math.cos(a) * (r - 4));
    const pz = Math.round(az + Math.sin(a) * (r - 4));
    for (let dy = 0; dy < 4; dy++) put(api, px, ay + dy, pz, ID.runeBrick, cx, cz, true);
    put(api, px, ay + 4, pz, ID.lamp, cx, cz, true);
  }

  /* 入口通道 */
  const dirIdx = rnd() * 4 | 0;
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  const [dxs, dzs] = dirs[dirIdx];
  for (let i = r; i < r + 8; i++){
    const px = ax + dxs * i, pz = az + dzs * i;
    for (let w = -1; w <= 1; w++){
      for (let dy = 0; dy < 4; dy++){
        const ox = dxs === 0 ? w : 0;
        const oz = dzs === 0 ? w : 0;
        put(api, px + ox, ay + dy, pz + oz, 0, cx, cz, true);
      }
      put(api, px + (dxs === 0 ? w : 0), ay - 1, pz + (dzs === 0 ? w : 0), ID.ruinBrick, cx, cz, true);
    }
  }
}

/* ---------- 地下要塞：大型，规整方块房间群 + 走廊 ---------- */
function buildDeepFortress(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const w = 12 + (rnd() * 4 | 0);
  const d = 12 + (rnd() * 4 | 0);
  const h = 7;

  /* 整体挖空 */
  carveBox(ctx, ax - w, ay - 1, az - d, ax + w, ay + h, az + d);

  /* 地板 + 天花板（玄武岩） */
  for (let x = -w; x <= w; x++){
    for (let z = -d; z <= d; z++){
      put(api, ax + x, ay - 1, az + z, ID.basalt, cx, cz, true);
      put(api, ax + x, ay + h, az + z, ID.basalt, cx, cz, true);
    }
  }

  /* 外墙：玄武岩 + 符文砖装饰 */
  for (let y = 0; y < h; y++){
    for (let x = -w; x <= w; x++){
      for (let z = -d; z <= d; z++){
        const edge = (x === -w || x === w || z === -d || z === d);
        if (!edge) continue;
        const wall = (y % 3 === 0) ? ID.runeBrick : ID.basalt;
        put(api, ax + x, ay + y, az + z, wall, cx, cz, true);
      }
    }
  }

  /* 内部隔墙：把大厅分成 2×2 个房间 + 十字走廊 */
  const midX = 0, midZ = 0;
  for (let y = 0; y < h; y++){
    for (let x = -w + 1; x < w; x++){
      for (let z = -d + 1; z < d; z++){
        const onMidX = (x === midX);
        const onMidZ = (z === midZ);
        if (!onMidX && !onMidZ) continue;
        /* 走廊口：十字交叉 + 每面中间留门 */
        if (onMidX && onMidZ) continue;
        if (onMidZ && Math.abs(x - midX) <= 1) continue;
        if (onMidX && Math.abs(z - midZ) <= 1) continue;
        /* 房间中心留门 */
        if (onMidZ && (Math.abs(x) > 4 && Math.abs(x) < 8)) continue;
        if (onMidX && (Math.abs(z) > 4 && Math.abs(z) < 8)) continue;
        put(api, ax + x, ay + y, az + z, ID.basalt, cx, cz, true);
      }
    }
  }

  /* 四个房间各放光源 + 一个祭坛 */
  const roomCenters = [
    [-w / 2 | 0, -d / 2 | 0], [(w / 2) | 0, -d / 2 | 0],
    [-w / 2 | 0, (d / 2) | 0], [(w / 2) | 0, (d / 2) | 0],
  ];
  for (let i = 0; i < roomCenters.length; i++){
    const [rx, rz] = roomCenters[i];
    put(api, ax + rx, ay + h - 1, az + rz, ID.lamp, cx, cz, true);
    if (i === 0) put(api, ax + rx, ay, az + rz, ID.altar, cx, cz, true);
    if (i === 3 && G && G.B.chest) put(api, ax + rx, ay, az + rz + 1, G.B.chest.id, cx, cz, true);
  }
}

/* ---------- 巨型矿洞：超大空腔 + 丰富矿脉 + 石笋林 ---------- */
function buildGreatCavern(ctx){
  const { api, cx, cz, ax, az, ay, rnd } = ctx;
  const r = 16 + (rnd() * 4 | 0);
  const h = 11;

  for (let dx = -r; dx <= r; dx++){
    for (let dz = -r; dz <= r; dz++){
      const d2 = dx * dx + dz * dz;
      if (d2 > r * r) continue;

      /* 用噪声让边缘不规则 */
      const wob = fbm2((ax + dx) * 0.05, (az + dz) * 0.05, 2, 991) * 0.35 + 0.85;
      if (d2 > r * r * wob * wob) continue;

      for (let dy = 0; dy < h; dy++){
        put(api, ax + dx, ay + dy, az + dz, 0, cx, cz, true);
      }
    }
  }

  /* 矿脉：在洞壁上撒矿 */
  for (let i = 0; i < 90; i++){
    const ang = rnd() * Math.PI * 2;
    const rad = (rnd() * 0.9 + 0.1) * r;
    const px = Math.round(ax + Math.cos(ang) * rad);
    const pz = Math.round(az + Math.sin(ang) * rad);
    const py = Math.round(ay + rnd() * h);
    const cur = get(api, px, py, pz, cx, cz);
    if (cur !== ID.stone && cur !== ID.tuff && cur !== ID.deepslate) continue;
    const r2 = rnd();
    const id = r2 < 0.35 ? ID.coal : r2 < 0.6 ? ID.iron : r2 < 0.75 ? ID.gold
             : r2 < 0.86 ? ID.diamond : r2 < 0.94 ? ID.emerald : ID.crystal;
    put(api, px, py, pz, id, cx, cz, true);
  }

  /* 石笋林 + 发光菌 */
  for (let i = 0; i < 60; i++){
    const ang = rnd() * Math.PI * 2;
    const rad = (rnd() * 0.85) * r;
    const px = Math.round(ax + Math.cos(ang) * rad);
    const pz = Math.round(az + Math.sin(ang) * rad);
    /* 找地板 */
    for (let py = ay; py < ay + h; py++){
      const cur = get(api, px, py, pz, cx, cz);
      const below = get(api, px, py - 1, pz, cx, cz);
      if (cur === 0 && below !== 0 && below >= 0){
        if (rnd() < 0.5){
          const len = randInt(rnd, 1, 3);
          for (let k = 0; k < len; k++) put(api, px, py + k, pz, ID.cracked, cx, cz, true);
        } else {
          put(api, px, py, pz, ID.glowShroom, cx, cz, true);
        }
        break;
      }
    }
  }

  /* 中央石灯群 */
  for (let i = 0; i < 6; i++){
    const a = i * Math.PI / 3;
    const px = Math.round(ax + Math.cos(a) * 4);
    const pz = Math.round(az + Math.sin(a) * 4);
    put(api, px, ay, pz, ID.lamp, cx, cz, true);
  }
}

/* ============================================================
   通用：挖一个空间
   ============================================================ */
function carveBox(ctx, x1, y1, z1, x2, y2, z2){
  const { api, cx, cz } = ctx;
  for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x++){
    for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y++){
      for (let z = Math.min(z1, z2); z <= Math.max(z1, z2); z++){
        if (y <= CFG.bottom + 2 || y >= CFG.top - 2) continue;
        put(api, x, y, z, 0, cx, cz, true);
      }
    }
  }
}

/* ============================================================
   主入口：为某个已生成的区块尝试放置结构
   ------------------------------------------------------------
   返回本区块里落下的结构列表（供刷怪逻辑用）
   ============================================================ */
export function placeStructures(api, cx, cz, seed){
  const hits = [];

  for (const st of STRUCTURES){
    /* 该结构覆盖的格点范围 */
    const cell = st.cell;
    const gx0 = Math.floor((cx * CS - 40) / cell);
    const gx1 = Math.floor((cx * CS + CS + 40) / cell);
    const gz0 = Math.floor((cz * CS - 40) / cell);
    const gz1 = Math.floor((cz * CS + CS + 40) / cell);

    for (let gx = gx0; gx <= gx1; gx++){
      for (let gz = gz0; gz <= gz1; gz++){
        /* 格点是否命中 */
        if (hash2i(gx, gz, seed + hashStr(st.id)) > st.chance) continue;

        /* 锚点：格内随机偏移 */
        const rndA = mulberry32((Math.imul(gx, 73856093) ^ Math.imul(gz, 19349663)
                      ^ hashStr(st.id) ^ seed) >>> 0);
        const ax = Math.round((gx + 0.2 + rndA() * 0.6) * cell);
        const az = Math.round((gz + 0.2 + rndA() * 0.6) * cell);
        const span = CFG.top - CFG.bottom;
        const ay = Math.round(CFG.bottom + (st.yLo + rndA() * (st.yHi - st.yLo)) * span);

        /* 结构半径（粗估），不在范围内就跳过 */
        const RAD = st.kind === 'large' ? 40 : st.kind === 'mid' ? 18 : 14;
        const bx0 = cx * CS, bz0 = cz * CS;
        if (ax + RAD < bx0 || ax - RAD > bx0 + CS) continue;
        if (az + RAD < bz0 || az - RAD > bz0 + CS) continue;

        const rnd = mulberry32((Math.imul(ax, 374761393) ^ Math.imul(az, 668265263)
                    ^ Math.imul(ay, 2246822519) ^ hashStr(st.id) ^ seed) >>> 0);

        try {
          st.build({ api, cx, cz, ax, az, ay, rnd, seed, wx0: bx0, wz0: bz0 });
          hits.push({ st, ax, ay, az, rnd: mulberry32(rnd() * 1e9 | 0) });
        } catch (e){
          /* 单个结构出错不影响整个区块 */
        }
      }
    }
  }

  return hits;
}

/* 字符串 → 稳定数字（结构 id 参与哈希） */
function hashStr(s){
  let h = 2166136261;
  for (let i = 0; i < s.length; i++){
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
