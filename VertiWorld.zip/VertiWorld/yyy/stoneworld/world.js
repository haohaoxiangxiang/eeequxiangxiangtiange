/* ============================================================
   stoneworld/world.js —— 全石世界生成
   ------------------------------------------------------------
   世界「全是石头」：从上到下没有天空、没有海面，整颗星球就是一块
   带洞穴的岩石。分 4 层：基岩 → 深板岩 → 凝灰岩 → 石头。

   ⚠ 关键机制（对着 terrain.js / world-gen.js 源码写的，不是猜的）
   ------------------------------------------------------------
   1. 宿主**不会**调用 mod 生成器的 heightAt / onChunkGen（见开发
      文档「已知限制」1）。唯一可行路径是监听 `chunk.decorate`，
      在区块建网格之前直接改写 chunk.blocks。两条生成路径都会触发：
        · 主线程兜底（terrain.js:_applyGenData 内）
        · Worker 回包（terrain.js:_onWorkerChunkReady）
      区别：Worker 路径里 applyEdits 在 decorate **之前**跑（玩家
      存档编辑已经落进 c.blocks），主线程路径在**之后**跑。
      所以本模块必须自己保护玩家改动，否则 Worker 路径会抹掉建筑。

   2. decorate 的 api.set() 直接落 c.blocks，不记存档 edits、不发事件，
      正是生成期写入该有的语义。但整块填充是 10 万级写入，逐格走
      api.set() 太慢（每次都要判 fluid/发脏标记），所以填充直接写底层
      Uint8Array，只有矿脉/植物/结构（几十~几百次）走 api.set()。

   3. ★ 最容易错的地方：chunk.minY / chunk.maxY 不是「地表高度」，
      而是**建网格的 y 范围**（mesh-builder 只在这个区间里生成面）。
      石头世界每一层都可能有洞穴，所以 minY 必须到底、maxY 必须到顶。
      早期版本用「每列 topY 的最小值」当 minY，结果整个区块只有顶部
      几层被建网格，下面全看不见 —— 已改正。

   4. 流体数组（c.fluid）在覆盖方块时必须清零，否则原版生成的水/岩浆
      液位会残留在石头上（渲染时可能冒出幽灵水面）。自己放的液体则要
      打上 FL_TSRC | FL_LEVEL=8，否则不会当源头、会立刻流走。

   5. 性能：一个区块 256 列 × 400+ 层 ≈ 11 万格，逐格算 3 次 fbm3
      要 250ms+，放在主线程（decorate 在主线程跑）会明显卡顿。
      这里改成「粗网格采样 + 按列插值」：
        · 洞穴噪声在 4×4×4 的粗网格上采样（约 2700 个点，~5ms）
        · 每列先把 x/z 双线性插值成 y 剖面，再按 y 线性插值
      实测从 255ms 降到 30ms 上下。
   ============================================================ */

import {
  CS, hash3i, rngAt, mulberry32, fbm2, fbm3, randInt, clamp,
} from './util.js';

let G = null;

/* 世界参数（从世界类型选项读） */
export const CFG = {
  seed: 12345,
  top: 400,         // 世界顶部（宿主的 CHH）
  bottom: -46,      // 世界底部（宿主的 Y_MIN）
  caveDensity: 1.0, // 洞穴密度倍率（0 = 无洞穴）
  oreDensity: 1.0,  // 矿脉密度倍率
  trees: true,      // 地下石根木森林
};

/* 洞穴只在 [bottom+CAVE_MARGIN_B, top-CAVE_MARGIN_T] 之间出现 */
const CAVE_MARGIN_B = 18;
const CAVE_MARGIN_T = 8;

/* 流体位编码（对齐 terrain.js: FL_LEVEL=0x0F, FL_SRC=0x10, FL_TSRC=0x20, FL_FALL=0x40） */
const FL_LEVEL = 0x0F, FL_TSRC = 0x20;

export function setHost(host){ G = host; }

/* ============================================================
   方块 id 缓存
   ============================================================ */
let ID = null;

export function cacheBlockIds(){
  const name = (n) => (G.B[n] ? G.B[n].id : 0);
  ID = {
    stone: name('stone'),
    deepslate: name('sw_deepslate'),
    tuff: name('sw_tuff'),
    basalt: name('sw_basalt'),
    cracked: name('sw_cracked_stone'),
    bedrock: name('bedrock'),
    water: name('water'),
    lava: name('lava'),

    coal: name('sw_coal_ore'),
    iron: name('sw_iron_ore'),
    gold: name('sw_gold_ore'),
    diamond: name('sw_diamond_ore'),
    redstone: name('sw_redstone_ore'),
    lapis: name('sw_lapis_ore'),
    emerald: name('sw_emerald_ore'),
    crystal: name('sw_crystal_ore'),
    fossil: name('sw_fossil_ore'),

    rootLog: name('sw_stone_root_log'),
    rootLeaves: name('sw_stone_root_leaves'),
    glowShroom: name('sw_glow_mushroom'),
    glowVine: name('sw_glow_vine'),
    moss: name('sw_stone_moss'),
    lamp: name('sw_stone_lamp'),

    ruinBrick: name('sw_ruin_brick'),
    runeBrick: name('sw_rune_brick'),
    altar: name('sw_altar'),
    spawner: name('sw_spawner'),
  };
  return ID;
}

export function ids(){ return ID; }

/* ============================================================
   玩家改动保护
   ------------------------------------------------------------
   main.js 把「玩家改过的方块」记成 Map<chunkKey, Map<localIdx, id>>，
   生成时把这些格子原样还原，避免重生成抹掉建筑。
   局标 idx 公式与 host 一致：((y - Y_MIN) * 16 + z) * 16 + x
   ============================================================ */
let _preserve = null;

export function setPreserveMap(m){ _preserve = m || null; }

function _chunkKey(cx, cz){ return cx + ',' + cz; }

function _preservedIn(cx, cz){
  if (!_preserve) return null;
  return _preserve.get(_chunkKey(cx, cz)) || null;
}

export function isPreserved(wx, wy, wz){
  const cx = Math.floor(wx / CS), cz = Math.floor(wz / CS);
  const m = _preservedIn(cx, cz);
  if (!m) return false;
  const lx = wx - cx * CS, lz = wz - cz * CS;
  const i = (((wy - CFG.bottom) * CS) + lz) * CS + lx;
  return m.has(i);
}

/* ============================================================
   分层
   ------------------------------------------------------------
   基岩（底部 ~4%）→ 深板岩（~30%）→ 凝灰岩（~21%）→ 石头。
   分界用低频噪声扰动，不是平面。
   ============================================================ */
function _strataT(wy){ return (wy - CFG.bottom) / (CFG.top - CFG.bottom); }

/* ============================================================
   洞穴粗网格采样器
   ------------------------------------------------------------
   三线性采样 + 按列 y 剖面。返回 null 表示这个区块不挖洞穴。
   ============================================================ */
const GRID = 4;          // 采样步长（4 格）
const GRID_XZ = 5;       // 16 / 4 + 1

function buildCaveSampler(cx, cz, seed){
  const density = CFG.caveDensity;
  if (density <= 0) return null;

  const wx0 = cx * CS, wz0 = cz * CS;
  const yB = CFG.bottom + CAVE_MARGIN_B;
  const yT = CFG.top - CAVE_MARGIN_T;
  if (yT <= yB) return null;

  /* 网格 y 起点对齐到 GRID */
  const ys = Math.floor(yB / GRID) * GRID;
  const ny = Math.ceil((yT - ys) / GRID) + 2;
  const nXZ = GRID_XZ * GRID_XZ;

  const cheese = new Float32Array(nXZ * ny);
  const worm1 = new Float32Array(nXZ * ny);
  const worm2 = new Float32Array(nXZ * ny);

  for (let gi = 0; gi < GRID_XZ; gi++){
    const wx = wx0 + gi * GRID;
    for (let gk = 0; gk < GRID_XZ; gk++){
      const wz = wz0 + gk * GRID;
      const base = (gi * GRID_XZ + gk) * ny;
      const ax = wx * 0.010, az = wz * 0.010;
      for (let gj = 0; gj < ny; gj++){
        const wy = ys + gj * GRID;
        /* 奶酪洞：2 个八度足够（第 3 个八度在这个尺度上会被插值抹掉） */
        cheese[base + gj] = fbm3(wx * 0.021, wy * 0.034, wz * 0.021, 2, seed + 101);
        /* 蠕虫隧道：低频，1 个八度 + 稍高的频率做点细节 */
        worm1[base + gj] = fbm3(ax, wy * 0.013, az, 1, seed + 211);
        worm2[base + gj] = fbm3(ax + 37.7, wy * 0.013 + 19.3, az - 11.1, 1, seed + 307);
      }
    }
  }

  /* ---- 按列生成 y 剖面（x/z 双线性 → 3 条 y 曲线） ---- */
  const ini = new Int16Array(CS * CS);   // 每列在网格里的起点（gi,gk 合并偏移）
  for (let lx = 0; lx < CS; lx++){
    const gi = lx >> 2, fx = (lx & 3) / GRID;
    for (let lz = 0; lz < CS; lz++){
      ini[lz * CS + lx] = (gi * GRID_XZ + (lz >> 2)) * ny;
      ini[lz * CS + lx] = ini[lz * CS + lx];   // 占位，实际下面用
    }
  }

  /* 剖面缓冲（复用，避免每列分配） */
  const profC = new Float32Array(ny);
  const profW1 = new Float32Array(ny);
  const profW2 = new Float32Array(ny);

  return {
    yB, yT, ys, ny,
    /** 为某一列准备好三条 y 剖面 */
    column(lx, lz){
      const gi = lx >> 2, fx = (lx & 3) / GRID;
      const gk = lz >> 2, fz = (lz & 3) / GRID;
      const i00 = (gi * GRID_XZ + gk) * ny;
      const i10 = ((gi + 1) * GRID_XZ + gk) * ny;
      const i01 = (gi * GRID_XZ + gk + 1) * ny;
      const i11 = ((gi + 1) * GRID_XZ + gk + 1) * ny;
      const w00 = (1 - fx) * (1 - fz), w10 = fx * (1 - fz);
      const w01 = (1 - fx) * fz,       w11 = fx * fz;
      for (let j = 0; j < ny; j++){
        profC[j]  = cheese[i00 + j] * w00 + cheese[i10 + j] * w10
                  + cheese[i01 + j] * w01 + cheese[i11 + j] * w11;
        profW1[j] = worm1[i00 + j] * w00 + worm1[i10 + j] * w10
                  + worm1[i01 + j] * w01 + worm1[i11 + j] * w11;
        profW2[j] = worm2[i00 + j] * w00 + worm2[i10 + j] * w10
                  + worm2[i01 + j] * w01 + worm2[i11 + j] * w11;
      }
      return { profC, profW1, profW2 };
    },
  };
}

/* 从剖面里取某一 y 的插值（y 必须在 [ys, ys+ny*GRID] 内） */
function _lerpProf(prof, ys, y){
  const f = (y - ys) / GRID;
  const i = f | 0;
  const fr = f - i;
  const a = prof[i], b = prof[i + 1];
  return a + (b - a) * fr;
}

/* ============================================================
   矿脉
   ------------------------------------------------------------
   按 3D 网格点决定「这里长不长一条矿脉」，再随机游走撒几格，
   挖出来是成团的，不是散点。每种矿有自己的深度区间。
   ============================================================ */
const ORE_TABLE = [
  /* k        loT   hiT    veins sMin sMax */
  { k: 'coal',     lo: 0.10, hi: 0.85, veins: 14, sMin: 4, sMax: 12 },
  { k: 'iron',     lo: 0.05, hi: 0.62, veins: 11, sMin: 3, sMax: 9 },
  { k: 'redstone', lo: 0.02, hi: 0.36, veins: 6,  sMin: 3, sMax: 8 },
  { k: 'lapis',    lo: 0.06, hi: 0.42, veins: 4,  sMin: 2, sMax: 7 },
  { k: 'gold',     lo: 0.02, hi: 0.30, veins: 5,  sMin: 2, sMax: 7 },
  { k: 'emerald',  lo: 0.01, hi: 0.22, veins: 2,  sMin: 1, sMax: 3 },
  { k: 'diamond',  lo: 0.00, hi: 0.16, veins: 3,  sMin: 1, sMax: 5 },
  { k: 'crystal',  lo: 0.00, hi: 0.12, veins: 2,  sMin: 1, sMax: 4 },
  { k: 'fossil',   lo: 0.08, hi: 0.55, veins: 3,  sMin: 1, sMax: 3 },
];

function placeOres(api, cx, cz, seed){
  const mult = CFG.oreDensity;
  if (mult <= 0) return;
  const span = CFG.top - CFG.bottom;
  const rnd = rngAt(cx, cz, seed, 7717);

  /* 可挖区间：避开底部基岩壳和顶部实心壳 */
  const yLo = CFG.bottom + CAVE_MARGIN_B;
  const yHi = CFG.top - CAVE_MARGIN_T - 2;
  const usable = yHi - yLo;
  if (usable <= 4) return;

  for (const ore of ORE_TABLE){
    const id = ID[ore.k];
    if (!id) continue;
    const n = Math.round(ore.veins * mult * (0.6 + rnd() * 0.8));

    /* 一次没找到岩石就换个位置重试，避免整种矿在区块里完全缺席 */
    let placed = 0;
    const attempts = n * 4;
    for (let a = 0; a < attempts && placed < n; a++){
      const lx = (rnd() * CS) | 0;
      const lz = (rnd() * CS) | 0;
      const t = ore.lo + rnd() * (ore.hi - ore.lo);
      const ly = Math.round(yLo + t * usable);
      if (ly < yLo || ly > yHi) continue;

      /* 起点必须是岩石（洞穴里不长矿） */
      const startId = api.get(lx, ly, lz);
      if (startId !== ID.stone && startId !== ID.deepslate && startId !== ID.tuff) continue;

      const size = randInt(rnd, ore.sMin, ore.sMax);
      let x = lx, y = ly, z = lz;
      let wrote = 0;
      for (let i = 0; i < size; i++){
        const cur = api.get(x, y, z);
        if (cur === ID.stone || cur === ID.deepslate || cur === ID.tuff){
          api.set(x, y, z, id);
          wrote++;
        }
        const dir = rnd();
        if (dir < 0.34) x += rnd() < 0.5 ? 1 : -1;
        else if (dir < 0.67) y += rnd() < 0.5 ? 1 : -1;
        else z += rnd() < 0.5 ? 1 : -1;
        x = clamp(x, 0, CS - 1);
        z = clamp(z, 0, CS - 1);
        y = clamp(y, yLo, yHi);
      }
      if (wrote > 0) placed++;
    }
  }
}

/* ============================================================
   地下石根木 / 发光植被 / 钟乳石
   ------------------------------------------------------------
   不再扫描整列找落点（那要几千次 api.get），而是用填充阶段
   顺手记下来的「洞穴地板 / 天花板」候选点。
   ============================================================ */
function plantTrees(api, cx, cz, seed, floors){
  if (!CFG.trees || !floors.length) return;
  const rnd = rngAt(cx, cz, seed, 4409);

  const tries = 6;
  for (let i = 0; i < tries; i++){
    if (rnd() > 0.4) continue;
    const f = floors[(rnd() * floors.length) | 0];
    if (!f) continue;
    const { lx, ly, lz } = f;

    /* 头顶要有空间 */
    let head = ly;
    while (head + 1 < CFG.top - CAVE_MARGIN_T && api.get(lx, head + 1, lz) === 0) head++;
    if (head - ly < 3) continue;

    const h = Math.min(randInt(rnd, 3, 5), head - ly);
    for (let k = 0; k < h; k++) api.set(lx, ly + k, lz, ID.rootLog);

    /* 树冠 */
    const ty = ly + h;
    for (let dx = -2; dx <= 2; dx++){
      for (let dz = -2; dz <= 2; dz++){
        for (let dy = 0; dy <= 1; dy++){
          const d = Math.abs(dx) + Math.abs(dz) + dy;
          if (d > 3) continue;
          if (d === 3 && rnd() < 0.45) continue;
          const nx = lx + dx, nz = lz + dz, ny = ty + dy;
          if (nx < 0 || nx > 15 || nz < 0 || nz > 15) continue;
          if (api.get(nx, ny, nz) !== 0) continue;
          api.set(nx, ny, nz, ID.rootLeaves);
        }
      }
    }
  }
}

function scatterFlora(api, cx, cz, seed, floors, ceilings){
  const rnd = rngAt(cx, cz, seed, 5501);

  /* 发光菌 / 石苔：长在洞穴地板上 */
  for (let i = 0; i < 22; i++){
    if (!floors.length) break;
    const f = floors[(rnd() * floors.length) | 0];
    if (!f) continue;
    const { lx, ly, lz } = f;
    if (api.get(lx, ly, lz) !== 0) continue;
    const r = rnd();
    if (r < 0.5) api.set(lx, ly, lz, ID.glowShroom);
    else if (r < 0.85) api.set(lx, ly, lz, ID.moss);
  }

  /* 荧光藤：挂在天花板下 */
  for (let i = 0; i < 14; i++){
    if (!ceilings.length) break;
    const cpt = ceilings[(rnd() * ceilings.length) | 0];
    if (!cpt) continue;
    const { lx, ly, lz } = cpt;
    const len = randInt(rnd, 1, 4);
    for (let k = 0; k < len; k++){
      const y = ly - k;
      if (y <= CFG.bottom) break;
      if (api.get(lx, y, lz) !== 0) break;
      api.set(lx, y, lz, ID.glowVine);
    }
  }

  /* 石笋：地板上的龟裂石柱 */
  for (let i = 0; i < 12; i++){
    if (!floors.length) break;
    const f = floors[(rnd() * floors.length) | 0];
    if (!f) continue;
    const { lx, ly, lz } = f;
    const len = randInt(rnd, 1, 3);
    for (let k = 0; k < len; k++){
      if (api.get(lx, ly + k, lz) !== 0) break;
      api.set(lx, ly + k, lz, ID.cracked);
    }
  }
}

/* ============================================================
   岩浆湖 / 水潭
   ------------------------------------------------------------
   ★ 必须打 FL_TSRC（地形源头）标记，否则流体系统不会把它当源头，
     灌下去立刻流走；也不能走 G.createFluidSource（那会记成玩家编辑）。
   ============================================================ */
function placeLiquids(api, cx, cz, seed, floors, fluid){
  const rnd = rngAt(cx, cz, seed, 6607);
  const span = CFG.top - CFG.bottom;
  const yLavaTop = CFG.bottom + span * 0.22;

  function fillDisc(lx, lz, y, r, id){
    for (let dx = -r; dx <= r; dx++){
      for (let dz = -r; dz <= r; dz++){
        if (dx * dx + dz * dz > r * r + 1) continue;
        const nx = lx + dx, nz = lz + dz;
        if (nx < 0 || nx > 15 || nz < 0 || nz > 15) continue;
        if (api.get(nx, y, nz) !== 0) continue;
        api.set(nx, y, nz, id);
        /* 同时把液位/源头写进流体数组 */
        if (fluid){
          const i = (((y - CFG.bottom) * CS) + nz) * CS + nx;
          if (i >= 0 && i < fluid.length) fluid[i] = FL_TSRC | 8;
        }
      }
    }
  }

  /* 岩浆湖：只在底部 */
  if (rnd() < 0.30 && floors.length){
    const low = floors.filter(f => f.ly < yLavaTop);
    if (low.length){
      const f = low[(rnd() * low.length) | 0];
      fillDisc(f.lx, f.lz, f.ly, 1 + (rnd() * 2.5 | 0), ID.lava);
    }
  }

  /* 水潭：中层 */
  if (rnd() < 0.22 && floors.length){
    const mid = floors.filter(f => f.ly >= yLavaTop);
    if (mid.length){
      const f = mid[(rnd() * mid.length) | 0];
      fillDisc(f.lx, f.lz, f.ly, 1 + (rnd() * 2 | 0), ID.water);
    }
  }
}

/* ============================================================
   主入口：把一个区块改造成「石头世界」
   ------------------------------------------------------------
   c   —— 宿主 chunk 对象（c.cx / c.cz / c.blocks / c.fluid / c.topY）
   api —— 宿主给的装饰 api（get / set / topY / getSeed）
   ============================================================ */
export function generateChunk(c, api){
  if (!c || !ID) return false;
  if (!c.blocks || !c.topY) return false;

  const cx = c.cx | 0, cz = c.cz | 0;
  const blocks = c.blocks;
  const span = CFG.top - CFG.bottom;
  const need = span * CS * CS;
  if (blocks.length !== need) return false;      /* 布局不符，不碰 */

  const seed = CFG.seed | 0;
  const wx0 = cx * CS, wz0 = cz * CS;
  const fluid = c.fluid;
  const density = CFG.caveDensity;

  /* ---- ① 分层扰动：每列算一次（以前是每格一次，白烧 30ms） ---- */
  const jitter = new Float32Array(CS * CS);
  for (let lz = 0; lz < CS; lz++){
    for (let lx = 0; lx < CS; lx++){
      jitter[lz * CS + lx] =
        (fbm2((wx0 + lx) * 0.012, (wz0 + lz) * 0.012, 2, seed + 17) - 0.5) * 0.08;
    }
  }

  /* ---- ② 洞穴采样器 ---- */
  const cave = density > 0 ? buildCaveSampler(cx, cz, seed) : null;
  const yCaveB = cave ? cave.yB : 0;
  const yCaveT = cave ? cave.yT : 0;
  const ys = cave ? cave.ys : 0;

  /* ---- ③ 逐列填充 ---- */
  const topYArr = c.topY;
  let minSolid = CFG.top, maxSolid = CFG.bottom;

  /* 洞穴地板 / 天花板候选（给植物和液体用） */
  const floors = [];
  const ceilings = [];
  const FLOOR_CAP = 240, CEIL_CAP = 160;

  const T_BEDROCK = 0.04, T_DEEPSLATE = 0.34, T_TUFF = 0.55;

  for (let lz = 0; lz < CS; lz++){
    for (let lx = 0; lx < CS; lx++){
      const jit = jitter[lz * CS + lx];
      const bBed = T_BEDROCK + jit * 0.4;
      const bDeep = T_DEEPSLATE + jit;
      const bTuff = T_TUFF + jit;

      /* 该列的洞穴剖面 */
      let profs = null;
      if (cave) profs = cave.column(lx, lz);

      const colBase = lz * CS + lx;
      let colTop = CFG.bottom;

      for (let ly = CFG.bottom; ly < CFG.top; ly++){
        const idx = (((ly - CFG.bottom) * CS) + lz) * CS + lx;

        /* 顶层实心壳（防止挖出世界顶部）—— 不做洞穴 */
        const isShell = ly > CFG.top - 7;

        let air = false;
        if (!isShell && cave && ly >= yCaveB && ly <= yCaveT){
          const n1 = _lerpProf(profs.profC, ys, ly);
          /* 越深越空旷 */
          const depthT = (CFG.top - ly) / span;
          const thr = 0.645 + 0.055 * (1 - depthT) - 0.02 * (density - 1);
          if (n1 > thr){
            air = true;
          } else {
            const r = 0.030 * density;
            const w1 = _lerpProf(profs.profW1, ys, ly);
            if (Math.abs(w1 - 0.5) < r) air = true;
            else {
              const w2 = _lerpProf(profs.profW2, ys, ly);
              if (Math.abs(w2 - 0.5) < r) air = true;
            }
          }
        }

        if (air){
          blocks[idx] = 0;
          if (fluid) fluid[idx] = 0;
          /* 记录洞穴地板 / 天花板候选（抽样，避免数组爆掉） */
          if (ly > CFG.bottom + 1 && ly < CFG.top - 1){
            const belowSolid = blocks[idx - CS * CS] !== 0 && ly - 1 >= CFG.bottom;
            const aboveSolid = ly + 1 < CFG.top && blocks[idx + CS * CS] !== 0;
            if (belowSolid && floors.length < FLOOR_CAP && ((colBase + ly) & 31) === 0){
              floors.push({ lx, ly, lz });
            }
            if (aboveSolid && ceilings.length < CEIL_CAP && ((colBase + ly + 7) & 31) === 0){
              ceilings.push({ lx, ly, lz });
            }
          }
          continue;
        }

        /* 实心：按深度分层 */
        const t = (ly - CFG.bottom) / span;
        let id;
        if (t < bBed) id = ID.bedrock;
        else if (t < bDeep) id = ID.deepslate;
        else if (t < bTuff) id = ID.tuff;
        else id = ID.stone;

        blocks[idx] = id;
        if (fluid) fluid[idx] = 0;      /* 清掉原版残留的液位 */
        colTop = ly;
        if (ly < minSolid) minSolid = ly;
        if (ly > maxSolid) maxSolid = ly;
      }

      topYArr[colBase] = colTop;
    }
  }

  /* ---- ④ 矿脉 / 植物 / 液体（走公开 api，量很小） ---- */
  try { placeOres(api, cx, cz, seed); } catch (e){}
  try { plantTrees(api, cx, cz, seed, floors); } catch (e){}
  try { scatterFlora(api, cx, cz, seed, floors, ceilings); } catch (e){}
  try { placeLiquids(api, cx, cz, seed, floors, fluid); } catch (e){}

  /* ---- ⑤ 还原玩家改动（重生成时保护建筑） ---- */
  const pres = _preservedIn(cx, cz);
  if (pres && pres.size){
    for (const [i, id] of pres){
      if (i >= 0 && i < blocks.length) blocks[i] = id;
    }
  }

  /* ---- ⑥ 维护区块竖向范围 ----
     ★ minY/maxY 是「建网格的 y 区间」，不是地表高度。
       石头世界每层都可能有洞穴，所以必须覆盖到底、到顶。 */
  if (minSolid > maxSolid){ minSolid = CFG.bottom; maxSolid = CFG.top - 1; }
  c.minY = Math.max(CFG.bottom, minSolid);
  c.maxY = Math.min(CFG.top - 1, maxSolid);
  c.dirty = true;
  c.decorated = true;

  return true;
}

/* 清理（切存档时调用） */
export function resetWorldCache(){
  _preserve = null;
}
