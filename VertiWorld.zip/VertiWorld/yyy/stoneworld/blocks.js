/* ============================================================
   stoneworld/blocks.js —— 石头世界全部方块 / 物品 / 配方
   ------------------------------------------------------------
   分四类：
     ① 地下岩层：深板岩 / 凝灰岩 / 玄武岩 / 石头变体
     ② 矿石：煤 / 铁 / 金 / 钻石 / 红石 / 青金石 / 翡翠 / 化石（掉肉）
     ③ 地下植物：石根木、发光菌、荧光藤
     ④ 结构与建材：遗迹砖、符文砖、祭坛、刷怪笼

   贴图全部用 drawFn 程序化绘制，不依赖外部资源文件。
   ============================================================ */

/* 每个方块注册后存进这里：B.stone_ore 之类 */
export const B = {};
/* 需要给配方引用的「物品」名（不是方块） */
export const ITEMS = {};

let G = null;

/* ============================================================
   贴图绘制小工具
   ------------------------------------------------------------
   所有贴图都是 16×16（或 size×size）像素风，用确定性像素噪点
   铺底 + 特征点，保证同一张图每次画出来一模一样。
   ============================================================ */
function px(ctx, x, y, w, h, color){
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

/* 噪点底：v0 基准亮度，var 波动幅度，hue 决定色调 */
function noiseBase(ctx, S, r, g, b, amp, seed){
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      const n = ((x * 73 + y * 151 + seed * 61) % 101) / 101;   // 确定性伪随机
      const v = (n - 0.5) * 2 * amp;
      ctx.fillStyle = `rgb(${Math.max(0, Math.min(255, r + v | 0))},${Math.max(0, Math.min(255, g + v | 0))},${Math.max(0, Math.min(255, b + v | 0))})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

/* 矿石：石头底 + 若干矿点簇 */
function oreTex(S, oreRGB, seed, dense){
  return (ctx) => {
    noiseBase(ctx, S, 122, 122, 122, 16, seed);          // 石头底
    /* 一点点裂纹，避免看起来像纯色块 */
    ctx.fillStyle = 'rgba(90,90,90,0.55)';
    for (let i = 0; i < 3; i++){
      const y = (seed * 7 + i * 5) % S;
      ctx.fillRect((i * 5) % S, y, S >> 1, 1);
    }
    /* 矿点簇 */
    const n = dense ? 14 : 9;
    const [or, og, ob] = oreRGB;
    for (let i = 0; i < n; i++){
      const x = (Math.imul(i + 1, 41) + seed * 13) % S;
      const y = (Math.imul(i + 3, 67) + seed * 29) % S;
      const s = 1 + ((i * 7 + seed) % 2);
      px(ctx, x, y, s, s, `rgb(${or},${og},${ob})`);
      /* 高光 */
      if (i % 3 === 0) px(ctx, x, y, 1, 1, `rgb(${Math.min(255, or + 60)},${Math.min(255, og + 60)},${Math.min(255, ob + 60)})`);
    }
  };
}

/* ============================================================
   注册入口
   ============================================================ */
export function registerBlocks(host){
  G = host;

  /* ---------- ① 地下岩层 ---------- */
  B.deepslate = G.registerBlock('sw_deepslate', '深板岩', {
    hardness: 3, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone',
    category: 'building',
  }, (ctx, S) => noiseBase(ctx, S, 62, 62, 68, 12, 11));

  B.tuff = G.registerBlock('sw_tuff', '凝灰岩', {
    hardness: 1.5, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone',
    category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 108, 110, 100, 14, 23);
    ctx.fillStyle = 'rgba(78,80,72,0.5)';
    for (let i = 0; i < 10; i++) ctx.fillRect((i * 5 + 2) % S, (i * 7 + 3) % S, 2, 2);
  });

  B.basalt = G.registerBlock('sw_basalt', '玄武岩', {
    hardness: 1.8, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone',
    category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 52, 54, 58, 10, 37);
    ctx.fillStyle = 'rgba(30,32,36,0.6)';
    for (let i = 0; i < S; i += 3) ctx.fillRect(i, 0, 1, S);
  });

  B.cracked_stone = G.registerBlock('sw_cracked_stone', '龟裂石', {
    hardness: 1.4, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone',
    category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 118, 118, 116, 15, 53);
    ctx.strokeStyle = 'rgba(70,70,68,0.8)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++){
      ctx.beginPath();
      ctx.moveTo((i * 6 + 1) % S, 0);
      ctx.lineTo((i * 4 + 9) % S, S >> 1);
      ctx.lineTo((i * 7 + 3) % S, S);
      ctx.stroke();
    }
  });

  /* ---------- ② 矿石 ---------- */
  /* 化石矿石：挖掉掉肉 —— 用 requiresTool 防止徒手白挖 */
  B.fossil_ore = G.registerBlock('sw_fossil_ore', '化石矿石', {
    hardness: 2.4, tool: 'pickaxe', requiresTool: true, minTier: 1,
    tag: 'stone', category: 'nature',
  }, (ctx, S) => {
    noiseBase(ctx, S, 118, 114, 104, 15, 71);
    /* 骨白色「化石骨」形状：两段骨节 */
    const bone = '#e8e4d4';
    px(ctx, S * 0.28 | 0, S * 0.3 | 0, S * 0.16 | 0, S * 0.42 | 0, bone);
    px(ctx, S * 0.52 | 0, S * 0.36 | 0, S * 0.18 | 0, S * 0.34 | 0, bone);
    px(ctx, S * 0.24 | 0, S * 0.26 | 0, S * 0.24 | 0, S * 0.08 | 0, bone);
    px(ctx, S * 0.24 | 0, S * 0.68 | 0, S * 0.24 | 0, S * 0.08 | 0, bone);
    /* 暗影 */
    ctx.fillStyle = 'rgba(60,56,48,0.45)';
    ctx.fillRect(S * 0.26 | 0, S * 0.6 | 0, S * 0.2 | 0, S * 0.04 | 0);
  });

  B.coal_ore_d =   G.registerBlock('sw_coal_ore',    '煤矿石',   { hardness: 2, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone', category: 'nature' }, oreTex(16, [42, 42, 46],    3, false));
  B.iron_ore_d =   G.registerBlock('sw_iron_ore',    '铁矿石',   { hardness: 2.6, tool: 'pickaxe', requiresTool: true, minTier: 2, tag: 'stone', category: 'nature' }, oreTex(16, [198, 154, 116], 5, false));
  B.gold_ore_d =   G.registerBlock('sw_gold_ore',    '金矿石',   { hardness: 3, tool: 'pickaxe', requiresTool: true, minTier: 3, tag: 'stone', category: 'nature' }, oreTex(16, [246, 208, 76],  7, false));
  B.diamond_ore_d = G.registerBlock('sw_diamond_ore', '钻石矿石', { hardness: 3.6, tool: 'pickaxe', requiresTool: true, minTier: 3, tag: 'stone', category: 'nature' }, oreTex(16, [110, 232, 232], 9, false));
  B.redstone_ore_d = G.registerBlock('sw_redstone_ore','红石矿石', { hardness: 3, tool: 'pickaxe', requiresTool: true, minTier: 2, tag: 'stone', category: 'nature' }, oreTex(16, [198, 42, 42],  13, false));
  B.lapis_ore_d =  G.registerBlock('sw_lapis_ore',   '青金石矿石', { hardness: 3, tool: 'pickaxe', requiresTool: true, minTier: 2, tag: 'stone', category: 'nature' }, oreTex(16, [46, 78, 198],  17, false));
  B.emerald_ore_d = G.registerBlock('sw_emerald_ore', '翡翠矿石', { hardness: 3.4, tool: 'pickaxe', requiresTool: true, minTier: 3, tag: 'stone', category: 'nature' }, oreTex(16, [58, 214, 122], 19, false));
  B.crystal_ore =  G.registerBlock('sw_crystal_ore', '晶簇矿石', { hardness: 3.2, tool: 'pickaxe', requiresTool: true, minTier: 2, tag: 'stone', category: 'nature', emissive: 1, light: 6 }, oreTex(16, [190, 130, 255], 23, true));

  /* ---------- ③ 地下植物 ---------- */
  B.stone_root_log = G.registerBlock('sw_stone_root_log', '石根木', {
    hardness: 2, tool: 'axe', tag: 'log', material: 'wood', fuel: 15,
    category: 'nature',
  }, (ctx, S) => {
    /* 木质底但带石头纹理 —— 石中长出的树 */
    for (let y = 0; y < S; y++){
      for (let x = 0; x < S; x++){
        const n = ((x * 61 + y * 137) % 89) / 89;
        const band = (y % 6 === 0);
        ctx.fillStyle = band
          ? `rgb(${96 + n * 18 | 0},${92 + n * 16 | 0},${98 + n * 16 | 0})`
          : `rgb(${132 + n * 26 | 0},${104 + n * 22 | 0},${74 + n * 18 | 0})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    ctx.fillStyle = 'rgba(70,70,76,0.5)';
    for (let i = 1; i < S; i += 6) ctx.fillRect(0, i, S, 1);
  });

  B.stone_root_leaves = G.registerBlock('sw_stone_root_leaves', '石根叶', {
    hardness: 0.3, transparent: true, isLeaves: true, occludes: false, solid: true,
    tool: 'shears', category: 'nature',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    for (let i = 0; i < 46; i++){
      const x = (Math.imul(i + 1, 37) + 5) % S;
      const y = (Math.imul(i + 3, 59) + 11) % S;
      const g = 120 + ((i * 41) % 70);
      ctx.fillStyle = `rgba(${64 + (i % 24)},${g},${72 + (i % 30)},0.94)`;
      ctx.fillRect(x, y, 3, 2);
      ctx.fillRect((x + 4) % S, (y + 3) % S, 2, 2);
    }
  });

  B.glow_mushroom = G.registerBlock('sw_glow_mushroom', '发光菌', {
    hardness: 0.2, cross: true, solid: false, opaque: false, occludes: false,
    emissive: 1, light: 12, category: 'nature',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    /* 菌柄 */
    px(ctx, S * 0.44 | 0, S * 0.45 | 0, S * 0.12 | 0, S * 0.5 | 0, '#d8e8c8');
    /* 菌盖 */
    ctx.fillStyle = '#7ce8ff';
    ctx.beginPath();
    ctx.arc(S * 0.5, S * 0.45, S * 0.32, Math.PI, 0);
    ctx.fill();
    /* 菌盖亮点 */
    ctx.fillStyle = '#d8fbff';
    ctx.fillRect(S * 0.36 | 0, S * 0.3 | 0, 2, 2);
    ctx.fillRect(S * 0.56 | 0, S * 0.34 | 0, 2, 2);
  });

  B.glow_vine = G.registerBlock('sw_glow_vine', '荧光藤', {
    hardness: 0.2, cross: true, solid: false, opaque: false, occludes: false,
    emissive: 1, light: 9, category: 'nature',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    ctx.fillStyle = '#3fa86a';
    for (let y = 0; y < S; y += 2) ctx.fillRect(S * 0.46 | 0, y, 2, 2);
    ctx.fillStyle = '#9affc8';
    for (let y = 1; y < S; y += 5){
      ctx.fillRect(S * 0.3 | 0, y, 2, 2);
      ctx.fillRect(S * 0.62 | 0, (y + 2) % S, 2, 2);
    }
  });

  B.stone_moss = G.registerBlock('sw_stone_moss', '石苔', {
    hardness: 0.2, cross: true, solid: false, opaque: false, occludes: false,
    category: 'nature',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    for (let i = 0; i < 26; i++){
      const x = (Math.imul(i + 7, 29) + 3) % S;
      const y = S - 1 - ((Math.imul(i + 3, 17)) % (S >> 1));
      ctx.fillStyle = `rgba(${60 + (i % 20)},${128 + (i * 13) % 80},${70 + (i % 18)},0.9)`;
      ctx.fillRect(x, y, 2, 2);
    }
  });

  /* ---------- ④ 结构与建材 ---------- */
  B.ruin_brick = G.registerBlock('sw_ruin_brick', '遗迹砖', {
    hardness: 3.2, tool: 'pickaxe', requiresTool: true, minTier: 1, tag: 'stone',
    category: 'building',
  }, (ctx, S) => {
    const h = Math.max(2, S >> 2);
    for (let y = 0; y < S; y += h){
      const off = ((y / h) % 2) ? 0 : (S >> 1);
      for (let x = -S; x < S; x += S >> 1){
        const bx = (x + off + S) % S;
        noiseBase(ctx, 1, 1, 1, 1, 0, 0);   /* no-op，保持风格 */
        ctx.fillStyle = ((x / (S >> 1) + y / h) % 2) ? '#8d8a7c' : '#7d7a6e';
        ctx.fillRect(bx, y, S >> 1, h);
        ctx.fillStyle = '#5d5a52';
        ctx.fillRect(bx, y, 1, h);
        ctx.fillRect(bx, y, S >> 1, 1);
      }
    }
    ctx.fillStyle = 'rgba(80,100,80,0.22)';
    for (let i = 0; i < 9; i++) ctx.fillRect((i * 5 + 1) % S, (i * 3 + 5) % S, 2, 2);
  });

  B.rune_brick = G.registerBlock('sw_rune_brick', '符文砖', {
    hardness: 3.6, tool: 'pickaxe', requiresTool: true, minTier: 2, tag: 'stone',
    emissive: 1, light: 7, category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 58, 52, 74, 12, 89);
    ctx.strokeStyle = '#a878ff';
    ctx.lineWidth = 1;
    ctx.strokeRect(S * 0.2, S * 0.2, S * 0.6, S * 0.6);
    ctx.beginPath();
    ctx.moveTo(S * 0.5, S * 0.25); ctx.lineTo(S * 0.5, S * 0.75);
    ctx.moveTo(S * 0.25, S * 0.5); ctx.lineTo(S * 0.75, S * 0.5);
    ctx.stroke();
    ctx.fillStyle = 'rgba(200,160,255,0.35)';
    ctx.fillRect(0, 0, S, 1);
  });

  B.altar = G.registerBlock('sw_altar', '祭坛', {
    hardness: 4, tool: 'pickaxe', requiresTool: true, minTier: 2,
    emissive: 1, light: 10, solid: true, category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 46, 40, 62, 10, 97);
    ctx.fillStyle = '#2a2440';
    ctx.fillRect(S * 0.12 | 0, S * 0.62 | 0, S * 0.76 | 0, S * 0.26 | 0);
    ctx.fillStyle = '#c8a0ff';
    ctx.fillRect(S * 0.3 | 0, S * 0.22 | 0, S * 0.4 | 0, S * 0.4 | 0);
    ctx.fillStyle = '#f0e0ff';
    ctx.fillRect(S * 0.4 | 0, S * 0.32 | 0, S * 0.2 | 0, S * 0.2 | 0);
  });

  /* 刷怪笼：结构内部的怪源，用 invisible 方块 + tick 逻辑控制 */
  B.spawner = G.registerBlock('sw_spawner', '刷怪笼', {
    hardness: 5, tool: 'pickaxe', requiresTool: true, minTier: 3,
    solid: true, opaque: false, transparent: true,
    hidden: false, category: 'functional',
  }, (ctx, S) => {
    /* 这个 drawFn 画的其实是 icon */
    noiseBase(ctx, S, 30, 32, 44, 8, 101);
    ctx.strokeStyle = '#8a6ad8';
    for (let i = 1; i < 4; i++){
      ctx.beginPath();
      ctx.moveTo(i * S / 4, 0); ctx.lineTo(i * S / 4, S);
      ctx.moveTo(0, i * S / 4); ctx.lineTo(S, i * S / 4);
      ctx.stroke();
    }
    ctx.fillStyle = '#c8a0ff';
    ctx.fillRect(S * 0.38 | 0, S * 0.38 | 0, S * 0.24 | 0, S * 0.24 | 0);
  });

  /* 岩石门 / 石栅栏 —— 结构用的小建材 */
  B.stone_lamp = G.registerBlock('sw_stone_lamp', '石灯', {
    hardness: 2.5, tool: 'pickaxe', requiresTool: true, minTier: 1,
    emissive: 1, light: 15, solid: true, category: 'building',
  }, (ctx, S) => {
    noiseBase(ctx, S, 90, 88, 84, 12, 113);
    ctx.fillStyle = '#ffd98a';
    ctx.fillRect(S * 0.24 | 0, S * 0.24 | 0, S * 0.52 | 0, S * 0.52 | 0);
    ctx.fillStyle = '#fff6d8';
    ctx.fillRect(S * 0.38 | 0, S * 0.38 | 0, S * 0.24 | 0, S * 0.24 | 0);
  });

  /* ---------- ⑤ 物品（化石掉的肉） ---------- */
  B.meat_raw = G.registerBlock('sw_meat_raw', '生肉', {
    isItem: true, maxStack: 64, food: 4, saturation: 2,
    hidden: false, category: 'food',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    /* 肉块主体 */
    ctx.fillStyle = '#c85864';
    ctx.beginPath();
    ctx.ellipse(S * 0.5, S * 0.52, S * 0.34, S * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
    /* 脂肪花纹 */
    ctx.fillStyle = '#f0c8c0';
    ctx.fillRect(S * 0.34 | 0, S * 0.42 | 0, S * 0.32 | 0, S * 0.06 | 0);
    ctx.fillRect(S * 0.42 | 0, S * 0.58 | 0, S * 0.2 | 0, S * 0.04 | 0);
    /* 骨头一端 */
    ctx.fillStyle = '#efeadd';
    ctx.fillRect(S * 0.66 | 0, S * 0.46 | 0, S * 0.16 | 0, S * 0.1 | 0);
  });

  B.meat_cooked = G.registerBlock('sw_meat_cooked', '熟肉', {
    isItem: true, maxStack: 64, food: 8, saturation: 5,
    hidden: false, category: 'food',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    ctx.fillStyle = '#a86438';
    ctx.beginPath();
    ctx.ellipse(S * 0.5, S * 0.52, S * 0.34, S * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#d8a068';
    ctx.fillRect(S * 0.34 | 0, S * 0.42 | 0, S * 0.32 | 0, S * 0.06 | 0);
    ctx.fillStyle = '#efeadd';
    ctx.fillRect(S * 0.66 | 0, S * 0.46 | 0, S * 0.16 | 0, S * 0.1 | 0);
  });

  /* 骨头：化石的副产物 */
  B.bone = G.registerBlock('sw_bone', '骨头', {
    isItem: true, maxStack: 64, category: 'material',
  }, (ctx, S) => {
    ctx.clearRect(0, 0, S, S);
    ctx.strokeStyle = '#efeadd';
    ctx.lineWidth = Math.max(2, S * 0.14);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(S * 0.28, S * 0.72);
    ctx.lineTo(S * 0.72, S * 0.28);
    ctx.stroke();
    ctx.fillStyle = '#efeadd';
    ctx.beginPath(); ctx.arc(S * 0.26, S * 0.74, S * 0.11, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(S * 0.74, S * 0.26, S * 0.11, 0, 7); ctx.fill();
  });

  return B;
}

/* ============================================================
   烧炼与配方
   ============================================================ */
export function registerRecipes(){
  try {
    /* 生肉 → 熟肉 */
    G.registerSmelt('sw_meat_raw', 'sw_meat_cooked', 1, 'stoneworld');
    /* 石根木当燃料 */
    G.setFuel('sw_stone_root_log', 15);
  } catch (e){
    G.log.warn('烧炼/燃料注册失败：', e && e.message);
  }
}
