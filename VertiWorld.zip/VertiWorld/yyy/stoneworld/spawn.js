/* ============================================================
   stoneworld/spawn.js —— 出生点挖掘 + 开局箱子
   ------------------------------------------------------------
   需求：
     · 出生在石头里，没有「陆地/地下」之分
     · 出生位置是一个挖出来的洞（小房间）
     · 房间里放一个箱子，箱子里 10 个木头

   实现：
     ① 世界进入（world.enter）后，检查本存档是否已经做过初始化
        （用 G.storage 存一个 spawn.json 标记，切存档不重复做）
     ② 首次进入：
        - 在出生点周围挖一个 5×4×5 的房间
        - 房间底部铺石砖、四角放石灯（不然全黑看不见）
        - 放一个箱子，写入 10 个原木
        - 把玩家传送到房间中央
     ③ 非首次进入：直接校正玩家位置（防止卡在石头里）
   ============================================================ */

const ROOM = {
  halfX: 3,      // 内部半宽（x 方向 ±3 → 7 格）
  halfZ: 3,
  height: 4,     // 内部高 4 格
};

const START_WOOD = 10;   // 开局木头数量

let G = null;
let _storage = null;
let _done = false;

export function setHost(host){ G = host; }

/* ============================================================
   存档标记
   ------------------------------------------------------------
   不能直接用「箱子是否存在」判断，因为玩家可能把箱子挖了。
   用自己的 storage 记一个布尔值最稳。
   ============================================================ */
const STATE_FILE = 'spawn.json';

async function hasInitialized(){
  if (_done) return true;
  if (!_storage) return false;
  try {
    const d = await _storage.readJSON(STATE_FILE);
    if (d && d.initialized){
      _done = true;
      return true;
    }
  } catch (e){}
  return false;
}

async function markInitialized(info){
  _done = true;
  if (!_storage) return;
  try { await _storage.writeJSON(STATE_FILE, { v: 1, initialized: true, ...info }); }
  catch (e){}
}

/* ============================================================
   找一处「适合出生」的位置
   ------------------------------------------------------------
   因为世界全是石头，出生点理论上哪都行。但为了不生成在
   岩浆湖里，往下找一个周围是普通岩石的高度。
   ============================================================ */
function pickSpawnY(x, z){
  const top = G.CHH, bottom = G.Y_MIN;
  /* 从世界中上部往下找，优先中间偏低的位置（像「地下城」） */
  const candidates = [];
  for (let y = Math.floor(bottom + (top - bottom) * 0.55);
       y > bottom + 24; y -= 4){
    candidates.push(y);
  }

  const lavaId = G.B.lava ? G.B.lava.id : -1;
  const waterId = G.B.water ? G.B.water.id : -1;

  for (const y of candidates){
    let ok = true;
    /* 检查这个高度周围没有岩浆/水，免得刚出生就被淹/被烧 */
    for (let dy = -2; dy <= ROOM.height + 2 && ok; dy++){
      for (let dx = -ROOM.halfX - 2; dx <= ROOM.halfX + 2 && ok; dx++){
        for (let dz = -ROOM.halfZ - 2; dz <= ROOM.halfZ + 2 && ok; dz++){
          const b = G.getBlock(x + dx, y + dy, z + dz);
          if (b === lavaId || b === waterId) ok = false;
        }
      }
    }
    if (ok) return y;
  }
  /* 兜底：世界中段 */
  return Math.floor(bottom + (top - bottom) * 0.45);
}

/* ============================================================
   挖房间
   ------------------------------------------------------------
   房间结构：
     地板 y-1     : 石砖
     内部 y ~ y+H : 空气
     天花板 y+H+1 : 石头（保持实心，不挖穿）
     四周墙       : 石头（本来就是石头，不用动）
     四角         : 石灯（提供光源）
   ============================================================ */
function carveRoom(cx, cy, cz){
  const brickId = G.B.stone_bricks ? G.B.stone_bricks.id : (G.B.stone ? G.B.stone.id : 0);
  const lampId = G.B.sw_stone_lamp ? G.B.sw_stone_lamp.id : 0;
  const torchId = G.B.glowstone ? G.B.glowstone.id : 0;

  G.batch(() => {
    /* 内部挖空 */
    for (let dy = 0; dy < ROOM.height; dy++){
      for (let dx = -ROOM.halfX; dx <= ROOM.halfX; dx++){
        for (let dz = -ROOM.halfZ; dz <= ROOM.halfZ; dz++){
          G.setBlock(cx + dx, cy + dy, cz + dz, 0);
        }
      }
    }

    /* 地板 */
    for (let dx = -ROOM.halfX; dx <= ROOM.halfX; dx++){
      for (let dz = -ROOM.halfZ; dz <= ROOM.halfZ; dz++){
        if (brickId) G.setBlock(cx + dx, cy - 1, cz + dz, brickId);
      }
    }

    /* 四角灯 */
    const lg = lampId || torchId;
    if (lg){
      for (const [sx, sz] of [[-1,-1],[1,-1],[-1,1],[1,1]]){
        const px = cx + sx * ROOM.halfX;
        const pz = cz + sz * ROOM.halfZ;
        /* 灯挂在角落的地板上方一格 */
        G.setBlock(px, cy + ROOM.height - 1, pz, lg);
      }
    }
  });
}

/* ============================================================
   放箱子 + 写入 10 个木头
   ------------------------------------------------------------
   箱子的存档文件是独立 JSON：saves/<id>/chests/<dim>/x_y_z.json
   mod 不能直接调 items-core 的 addToChest，但可以：
     ① 先放箱子方块（走正常放置流程）
     ② 通过 /api/saves/... PUT 直接写那个 JSON
   这样箱子打开时 loadChest() 就能读到内容。

   如果服务器不支持（C++ 服务端），退化成直接把木头塞背包。
   ============================================================ */
async function placeChestWithWood(sx, sy, sz, chestX, chestY, chestZ){
  const chestId = G.B.chest ? G.B.chest.id : 0;
  if (!chestId){
    /* 没有箱子方块，直接给背包 */
    giveWoodToInventory();
    return { ok: false, reason: 'no_chest_block' };
  }

  /* 放箱子 */
  G.setBlock(chestX, chestY, chestZ, chestId);

  /* 木头：优先原木 */
  const woodName = pickWoodName();
  const woodId = G.B[woodName] ? G.B[woodName].id : 0;
  if (!woodId){
    giveWoodToInventory();
    return { ok: false, reason: 'no_wood' };
  }

  /* 写箱子内容 */
  const dim = (G.getActiveDimensionId && G.getActiveDimensionId()) || 'overworld';
  const rel = `chests/${dim}/${chestX}_${chestY}_${chestZ}.json`;

  /* 照着 items-core 的 _snapshot() 格式写 */
  const payload = {
    v: 1,
    x: chestX, y: chestY, z: chestZ,
    dim,
    slotCount: 27,
    savedAt: Date.now(),
    slots: new Array(27).fill(null),
  };
  payload.slots[0] = { n: woodName, c: START_WOOD };

  const saveId = G.saveId;
  if (!saveId) {
    giveWoodToInventory();
    return { ok: false, reason: 'no_save_id' };
  }

  try {
    const res = await fetch(`/api/saves/${encodeURIComponent(saveId)}/${rel}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return { ok: true, chest: { x: chestX, y: chestY, z: chestZ }, wood: woodName, count: START_WOOD };
  } catch (e){
    /* 服务端不支持 → 退化成给背包 */
    G.log.warn('箱子写入失败，改为直接把木头放进背包：', e && e.message);
    giveWoodToInventory();
    return { ok: false, reason: 'fetch_failed', error: String(e) };
  }
}

function pickWoodName(){
  /* 优先橡木，没有就用第一个带 log tag 的 */
  if (G.B.oak_log) return 'oak_log';
  if (G.B.spruce_log) return 'spruce_log';
  const logs = ['oak_log', 'spruce_log', 'sakura_log', 'sw_stone_root_log'];
  for (const n of logs) if (G.B[n]) return n;
  return 'oak_log';
}

function giveWoodToInventory(){
  const name = pickWoodName();
  try {
    const ok = G.give(name, START_WOOD);
    if (ok === false) G.log.warn('背包已满，木头没能给出');
  } catch (e){}
}

/* ============================================================
   主入口
   ============================================================ */
export async function ensureSpawn(){
  _storage = G.storage ? G.storage('stoneworld') : null;

  const initialized = await hasInitialized();

  let px = 0, pz = 0;
  try {
    const pos = G.getPos();
    px = Math.round(pos.x);
    pz = Math.round(pos.z);
  } catch (e){}

  if (initialized){
    /* 已初始化：只校正位置，确保玩家不在石头里 */
    fixPlayerStuck();
    return;
  }

  /* ---- 首次进入：造出生房间 ---- */
  const cy = pickSpawnY(px, pz);
  G.log.info(`生成出生洞穴 @ (${px}, ${cy}, ${pz})`);

  try {
    carveRoom(px, cy, pz);
  } catch (e){
    G.log.error('挖出生洞穴失败：', e);
    return;
  }

  /* 箱子放在房间一角 */
  const chestX = px + ROOM.halfX - 1;
  const chestZ = pz - ROOM.halfZ + 1;
  const chestY = cy;

  const r = await placeChestWithWood(px, cy, pz, chestX, chestY, chestZ);

  /* 把玩家放进房间中央 */
  try {
    G.teleport(px + 0.5, cy, pz + 0.5);
  } catch (e){}

  /* 记录 */
  await markInitialized({
    x: px, y: cy, z: pz,
    chest: { x: chestX, y: chestY, z: chestZ },
    chestWritten: r.ok,
  });

  const msg = r.ok
    ? `你出生在石头深处。旁边的箱子里有 ${START_WOOD} 个${G.B[r.wood] ? G.B[r.wood].label : '木头'}。`
    : `你出生在石头深处。${START_WOOD} 个木头已直接放进背包。`;
  G.log.info(msg);
  try { G.emit('sw.notify', msg); } catch(e){}
}

/* 玩家卡在石头里 → 就地挖一个 1×2 的小空间 */
function fixPlayerStuck(){
  try {
    const pos = G.getPos();
    const x = Math.round(pos.x), y = Math.round(pos.y), z = Math.round(pos.z);
    const solid = (bx, by, bz) => {
      const id = G.getBlock(bx, by, bz);
      if (!id) return false;
      const b = G.BLOCKS[id];
      return !!(b && b.solid);
    };
    if (solid(x, y, z) || solid(x, y + 1, z)){
      G.batch(() => {
        G.setBlock(x, y, z, 0);
        G.setBlock(x, y + 1, z, 0);
      });
      G.teleport(x + 0.5, y, z + 0.5);
    }
  } catch (e){}
}

export function resetSpawnCache(){ _done = false; }
