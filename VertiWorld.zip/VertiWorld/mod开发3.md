# 深入世界 VertiWorld Mod 开发 · 卷三：兼容、扩展与 Coremod

> 适用宿主 **API v4**。本卷收录三类"进阶"内容：
> 2026-10 ~ 11 月这轮大改带来的兼容性变化、B 类反馈补强的扩展 API、
> 以及打包分发和 Coremod 底层注入。
>
> | 卷 | 内容 |
> |---|---|
> | [卷一](mod开发1.md) | 快速开始、manifest、生命周期、`G` 总览、世界读写、事件、Hook、输入独占、性能、限制 |
> | [卷二](mod开发2.md) | 内容注册、世界类型、创造面板、实体分级、存档、示例、API 速查 |
> | **卷三（本文）** | 版本兼容变化、扩展 API、三份反馈对照、整合包与地图、Coremod |

## 本卷目录

1. [兼容与版本变化](#1-兼容与版本变化)
2. [扩展 API（B 类反馈补强）](#2-扩展-api-b-类反馈补强)
3. [三份反馈逐条对照](#3-三份反馈逐条对照)
4. [整合包与地图（打包 / 分发）](#4-整合包与地图打包--分发)
5. [Coremod 开发](#5-coremod-开发)
6. [调试与反馈](#6-调试与反馈)

---

## 1. 兼容与版本变化

> 本节对应旧 `mod开发补充.md` 的 2026-11 增量。
> 旧文档正文仍适用的部分已经并入卷一/卷二；这里只讲**改了什么、你需要注意什么**。

### 1.1 摘要

| 分类 | 变化 | 对 mod 的影响 |
|---|---|---|
| 加载器 | 依赖支持版本约束、可选依赖、级联跳过 | ✅ 向后兼容；新能力可用 |
| 世界生成 | mod 可以真正接管地形生成（`worldgenUrl`） | ✅ 旧 mod 不受影响；新能力大 |
| 创造面板 | 分类 chip 分页（每页 5 个） | ⚠️ 分类超过 5 个时有箭头 |
| 颜色系统 | 顶点色 sRGB → linear 转换 | ⚠️ 自定义贴图颜色会变（更正确） |
| 网格 dirty | 修复"挖太快不重建"的 bug | ✅ mod 的 `setBlock` 现在可靠 |
| UI 元素 | 删了 4 个 HTML 元素、加了 1 个 | ⚠️ 见 1.6 |
| 挖掘节奏 | 破坏后统一冷却 | ⚠️ 事件触发频率略变 |
| 扩展 API | 9 组 B 类接口补齐 | ✅ 见第 2 节 |

**总评**：API 100% 向后兼容；只有几个 UI 元素删除（mod 极少依赖）。

### 1.2 加载器 v2

完整字段与运算符见**卷一第 2 节**。这里只强调 mod 作者最容易误解的几点：

- **依赖版本约束现在真的会检查**：`dependencies` 写成对象并带 `version` 时，不满足会加载失败（`dep_version`）。
- **`^`/`~` 不等于 npm 语义**：当前实现只做 `>=`，不锁上界。
- **依赖不会自动启用**：缺失只记 warning；玩家没勾选的 mod 不会因为"被依赖"而加载。
- **依赖环只警告**：环内 mod 仍会加载，不会自动跳过（旧补充文档说"环内跳过"是不准确的）。
- **级联跳过只发生在依赖失败/被跳过时**：A 依赖 B，B 失败 → A 记 `dependency_failed`。
- 加载器内部结果新增 `skipped` 数组（**没有暴露给 mod**，只在 Mod 状态面板与控制台日志里可见；
  下面列出结构是为了让你看懂面板）：

```js
// 加载器内部：getLastLoadResult()（mod 无法调用）
const r = getLastLoadResult();
// {
//   loaded:   ['raftcore', 'raftworld', ...],
//   failed:   [{ id, reason, message }],
//   skipped:  [{ id, reason, message }],     ← 新增
//   warnings: [{ id, kind, name, message }],
// }
```

| reason | 含义 |
|---|---|
| `not_found` | `mods/` 目录找不到 |
| `api_version` | `apiVersion` 太高 |
| `dep_version` | 依赖版本不满足 |
| `load_error` | `onEnable` 抛出异常 |
| `dependency_failed` | 依赖加载失败被级联跳过 |

### 1.3 世界生成：`worldgenUrl` 真正生效

旧文档曾写"自定义生成器不生效"——现在生效了。两种路径：

- **Worker 路径**（推荐，性能好）：注册时给 `worldgenUrl`，Worker `import()` 后调用模块的
  `generate(chunk, blockIds, cfg)`。**注意签名不是 `generate(cx, cz, cfg)`**（旧文档此处有误）。
- **主线程路径**（降级）：`onGenerate({ cx, cz, chunk, blockIds, cfg, helpers })`。

完整接口约定、可 import 白名单、失败回退行为见**卷二 1.8**。

### 1.4 网格 dirty 修复

**修复的 bug**：快速连挖时视觉网格可能永久过期（挖了但看起来还在）。
原因是 `_drainMeshResults` 无条件清 `chunk.dirty`，吞掉了 meshing 期间的新改动。

**现在的行为**：

- 引入 `chunk.dirtyGen` / `chunk.meshGen` 版本号机制；
- meshing 期间的新改动会保留 dirty，下次重新提交；
- 邻居标记从 4 个扩到 8 个（含对角线）。

对 mod 的影响：`G.setBlock` 现在可靠——无论调用多快，最终都会渲染出来。
批量操作仍然建议用 `G.batch`（见卷一第 5 节）。

### 1.5 颜色系统：sRGB → linear

**变化**：之前顶点色直接把 `0xRRGGBB` 拆成 0~1 传 GPU，被当成 linear；
现在 `0xRRGGBB` 按 sRGB 解释，先转 linear 再传。

**结果**：染色后颜色变深、变饱和（更接近真实颜色）。

对 mod 贴图的影响：通过 `tex: { all: 'my_tex' }` + `tint: 'grass'/'foliage'` 的灰度贴图，
颜色比之前深约 22%。规律：**贴图越接近纯白（255），染色后越接近 tint 原色**。

```js
// 需要染色的方块用 drawFn 画灰度贴图
G.registerBlock('my_grass', '我的草', { tint: 'grass' }, (ctx, S) => {
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      // 之前习惯 200~255；现在推荐 235~255，染色后才接近 tint 原色
      const v = 235 + Math.floor(Math.random() * 20);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
});
```

内置草方块已改成五面全绿（除底面），树叶贴图重新做成"纯色 + 细微细节"（灰度 + 暗点）。
这是内置改动，mod 无需关心。

验证方法：注册一个带 tint 的方块，对比游戏内颜色；偏暗就把灰度调到 235 左右。

### 1.6 UI 元素变化

| 变化 | 元素 id | 影响 |
|---|---|---|
| ❌ 删除 | `#btnSettings` | 顶栏设置按钮已换成 `#btnSettingsTop` / `#btnSettingsTop2` |
| ❌ 删除 | `#bagTitle` | 背包标题不再固定存在 |
| ❌ 删除 | `#bagTip` | 背包底部提示不再固定存在 |
| ❌ 删除 | `#invhead` | 背包表头不再固定存在 |
| ✅ 新增 | `#btnFullscreen3` | 全屏入口 |
| ✅ 新增 | `#btnModStatus` | 暂停菜单里的 Mod 状态入口 |
| ✅ 新增 | `#settingsSidebar` | 设置面板左侧栏 |
| ✅ 新增 | `#perfSubnav` | 性能面板子导航 |
| ✅ 新增 | `#btnUploadLog` | 日志上传按钮 |

> 旧补充文档写"设置按钮改成 `#btnOpenSettings`"只对了一半：
> `#btnOpenSettings` 是**暂停菜单**里的入口，顶栏按钮是 `btnSettingsTop` / `btnSettingsTop2`。

**mod 正确做法**：不要写死"第几个按钮/哪个 id"，用 `G.ui.addInventoryWidget` 等官方入口，
或者用 `G.ui.getSafeAreas()` 定位自己的悬浮层。面板容器每次打开都会清空，监听
`ui.inventory.open` / `ui.chest.open` / `ui.furnace.open` 再注入（见卷一第 4 节）。

### 1.7 挖掘节奏

**现状**（对照源码）：玩家破坏方块成功后统一进入冷却。

| 模式 | 冷却 |
|---|---|
| 创造 | 150 ms |
| 生存 | 50 ms |

- 冷却期间不再触发新的破坏/`block.break`；
- **没有**"连击分级 / 动态冷却表"。旧补充文档里的
  `0.22 / 0.15 / 0.10 / 0.07 …` 递减表是旧方案，已不存在；
- 想做"挖掘越快冷却越短"的工具，请在 `item` 配置里改 `speed`，而不是等宿主分级。

对 mod 的影响：`block.break` 的触发频率在生存模式约为每 50ms 最多一次，
按帧计数的逻辑要按时间而不是按事件次数。

### 1.8 兼容性总结

- `apiVersion` 用 `>=` 判断，旧 mod 不需要改；
- 旧事件、旧 Hook 名称全部保留；
- 旧式 `onBlockBreak/onBlockPlace` **仍然不会被调用**（早已废弃，见卷一第 3 节）；
- 唯一需要主动适配的：UI 元素 id（1.6）、贴图灰度（1.5）、依赖写法（1.2）。

---

## 2. 扩展 API（B 类反馈补强）

> 本节对应的接口全部已在源码中核对存在（2026-11-05）。
> 它们是"补强"，不影响旧 API。

### 2.1 `G.getLookTarget(maxDist?)`

```js
const t = G.getLookTarget(6);
// {
//   pos:    { x, y, z },                  // 命中的方块坐标（整数）
//   face:   'top'|'bottom'|'north'|'south'|'east'|'west',
//   normal: { x, y, z },                  // 命中面的法线
//   blockId: number,
// } | null
```

- 从**摄像机**沿视线打体素射线，默认距离 6；
- 没有命中返回 `null`；
- 比 `G.raycast()` 多了 `face` / `normal`，适合"按玩家看的哪一面放置/交互"。

### 2.2 `G.getHeldSlot()`

```js
G.getHeldSlot()   // → 0~8
G.inventory[G.getHeldSlot()]   // 当前手持物品槽
```

省掉"从 hotbar 数组里自己找选中项"的重复逻辑。

### 2.3 `G.getBlockEx(x, y, z)`

```js
G.getBlockEx(x, y, z)
// → { id: 0, loaded: true }   真的空气
// → { id: 0, loaded: false }  区块未加载，id 无意义
// → { id: 3, loaded: true }   石头
```

解决 `getBlock` 在未加载区块返回 0、与空气无法区分的老问题。
等价写法是 `G.isLoadedAt(x,y,z)` + `G.getBlock(x,y,z)`，但一次调用更省。

### 2.4 流体接口

```js
G.getFluidLevel(x, y, z)          // 0~8
G.setFluidLevel(x, y, z, lv)
G.getFluidSource(x, y, z)         // 0/1
G.createFluidSource(x, y, z, id)  // 水/岩浆的 block id
G.removeFluidSource(x, y, z)
G.wakeFluid(x, y, z, delay?)      // 重新排队流动
```

配合 `setFluidConfig` / `fluid.tick:before` / `fluid.spread:before` 做水泵、潮汐、波浪海面。
注意：`fluid.tick:before` 取消后不会自动重试，必须自己 `wakeFluid`（见卷一第 11 节）。

### 2.5 `G.ui.getSafeAreas()`

```js
const areas = G.ui.getSafeAreas();
// {
//   viewport: { left, top, right, bottom, w, h },
//   joystick, sideButtons, hotbar, topBar, hearts, hunger,  // 矩形或 null
// }
```

每个矩形：`{ left, top, right, bottom, w, h }`（视口像素）。元素不存在时为 `null`。
用于把 mod 自己的 HUD/悬浮按钮放到不挡摇杆、快捷栏、血条的位置。

### 2.6 方块图标：`iconDraw`

```js
G.registerBlock('my_terminal', '终端', {
  tex: { all: 'iron_block' },
  iconDraw(ctx, S){ ... },   // 优先级最高
});
```

优先级：`iconDraw` > `icon` > 顶面 `tiles[2]` > 空白。

透明面贴图的模型方块**必须**给 `icon` 或 `iconDraw`，否则背包/快捷栏/掉落物是空白格子。
完整示例见**卷二 1.2**。

### 2.7 物品 meta：`addItem` / `spawnDrop` / `item.*`

```js
G.addItem(id, count, meta)                    // meta 可选
G.spawnDrop(x, y, z, id, count, meta)         // meta 可选
```

物品堆里也可以带 `meta` 字段（`{ id, count, durability?, meta? }`）。

事件参数带第 6 位 `meta`：

| 事件 | 参数 |
|---|---|
| `item.pickup` | `(id, count, x, y, z, meta)` |
| `item.canPickup` | `(id, count, x, y, z, meta)` —— 可取消 |
| `item.drop` | `(id, count, x, y, z, meta)` |

`meta` 是任意 JSON 可序列化对象，用来存附魔、自定义 NBT、来源标记等。
注意：`G.give(name, n)` 的包装不传 meta；需要 meta 用 `G.addItem`。

### 2.8 方块来源：`blk.source`

```js
G.registerBlock('magic_ore', '魔法矿石', { … });
G.BLOCKS[G.B.magic_ore.id].source   // → 'mod'（内置方块是 'builtin'）
```

可用于遍历 `G.BLOCKS` 时只处理自己加的方块，避免误伤原版。

### 2.9 `block.interact`：通用右键交互

```js
G.on('block.interact', (x, y, z, hitBlockId, nx, ny, nz) => {
  if (hitBlockId !== G.B.my_terminal.id) return false;
  openMyUI(x, y, z);
  return true;   // 取消这次默认放置
});
```

- 触发点：`tryPlace()` 里，**排在原版工作台/熔炉/箱子交互之后**；
- 因此它拦的是"把方块放下去"，不是"打开箱子"；
- 配合 `G.input.consume('mouseRight')` 可以做完整的自定义右键交互（见卷一第 8 节）；
- 只有严格 `return true` 才拦下。

`interactive` 字段只认内置值：`furnace` `chest` `pedestal` `lever` `button` `door` `iron_door`
（`crafting_table` 按方块名特判）；写别的值只是元数据，不会自动打开 UI。

### 2.10 隐形方块：`invisible`

```js
G.registerBlock('magic_crystal_block', '魔法水晶', {
  tex: { all: 'glass' },
  invisible: true,
  solid: false,
  occludes: false,
  opaque: false,
});
G.attachVisual(x, y, z, myThreeObject);
```

- 6 个面全不渲染，邻居面不因为它被剔除；
- 保留碰撞（按 `solid`）、`getBlock`、`block.interact`、`getBlockData`、挖掘掉落、`attachVisual`；
- 适合"完全由 3D 模型表现的机器/水晶/投影"。

### 2.11 `spawnHint` 与 `reloadMod`（重要：目前不可用）

旧补充文档把这两项列为已支持，**实际源码并非如此**：

| 项 | 现状 |
|---|---|
| `spawnHint(seed)` | 存档加载会检查 `gen.spawnHint`，但 `registerGenerator` **不保存**这个字段；运行时注册的生成器无法通过它接管出生点 |
| `reloadMod(id)` | 是内部函数，**没有暴露给 `G` 或 UI**；热重载请重进世界或刷新页面 |

需要自定义出生点，目前只能：在 `world.enter` 里 `G.teleport()`，或监听 `chunk.decorate`
在自己生成的地形附近预先清出安全区。

---

## 3. 三份反馈逐条对照

> 这一节回答"开发者提过的需求，现在到底支持到什么程度"。
> 结论按源码核对，**以本表为准**；旧补充文档里过度乐观的条目已修正。

| # | 需求 | 结论 | 说明 / 用法 |
|---|---|---|---|
| 1 | 方块独立数据存储 | ✅ 已支持 | `G.setBlockData/getBlockData/removeBlockData`，按坐标存 JSON，跟存档走（卷一第 4 节） |
| 2 | 方块脱离整数网格 | ✅ 渲染层已支持 | `G.attachVisual` 可以把 `THREE.Object3D` 绑到方块坐标；逻辑/碰撞仍在整数网格 |
| 3 | 物理引擎 | ❌ 不支持 | 只有 `worldApi.moveWithCollision` 的方块 AABB；载具/坠落方块需 mod 自己实现 |
| 4 | Worker 闭包序列化 | ✅ 部分支持 | 用 `worldgenUrl` + 纯函数 `generate(chunk, blockIds, cfg)`；不能传闭包，需双路降级（卷二 1.8） |
| 5 | 创造模式 `block.break` 不触发 | ✅ 已修复 | 创造模式现在也发 `block.break`，`willDrop = false` |
| 6 | 输入无法消费 | ✅ 已支持 | `G.input.consume(name)` + `G.input.suspend/resume`（卷一第 8 节） |
| 7 | 改方块掉落物 | ✅ 已支持 | `G.setBlockDrop(name, spec)`，支持固定/随机/概率/数组/函数 |
| 8 | 实体掉落 | ✅ 已支持 | `G.setEntityLoot(type, spec)`，对已生成实体也生效 |
| 9 | 结构生成时的机关状态 | ✅ 已支持 | 生成阶段用 `helpers.setBlock`，或 `setBlockData` 存机关状态；`scheduleBlockTick` 做延时 |
| 10 | 箱子物品位置自定义 | ✅ 已支持 | `G.setChestItems(x,y,z,items,{merge})`，按数组顺序填槽，空槽 `null` |
| 11 | 替换原版地表/地下/树 | ✅ 已支持 | `chunk.decorate` 里 `api.set/setWorld` 就地改写；或完全接管 `onGenerate` |
| 12 | 动物 AI | ✅ 已支持 | `registerEntity.update(entity, dt, playerPos, world)`；异常连续 5 次才停用 |
| 13 | 方块强度 | ✅ 已支持 | `hardness` / `tool` / `minTier` / `requiresTool` |
| 14 | 工具能力 | ✅ 已支持 | `toolType` / `material` / `speed` / `tier` / `durability`；工具等级影响掉落 |
| 15 | 移动 / 跳跃 | ✅ 已支持 | `G.setMovementConfig({ walkSpeed, jumpVelocity, gravity, … })` |
| 16 | 水的浮力 | ✅ 已支持 | `waterBuoyancy` / `waterGravity` / `waterDamping` / `waterMaxSpeed` |
| 17 | 液体流动 | ✅ 已支持 | `setFluidConfig` + `fluid.*` 事件 + `wakeFluid` + 液位读写 |
| 18 | 状态给予 | ✅ 已支持 | `registerStatusEffect` / `applyStatus` / `removeStatus` |
| 19 | 自定义扣血 / 回血 | ✅ 已支持 | `G.damagePlayer(n)` / `G.heal(n)` / `G.damageEntity(e,n)`；Hook `player.damage` |
| 20 | 出生点接管 `spawnHint` | ❌ 不可用 | 见 2.11 |
| 21 | 热重载 `reloadMod` | ❌ 未暴露 | 见 2.11 |
| 22 | 读取准星目标 | ✅ 已支持 | `G.getLookTarget()` / `G.raycast()` |
| 23 | 区分空气与未加载 | ✅ 已支持 | `G.getBlockEx()` / `G.isLoadedAt()` |
| 24 | 读取手持槽 | ✅ 已支持 | `G.getHeldSlot()` |
| 25 | UI 安全区 | ✅ 已支持 | `G.ui.getSafeAreas()` |
| 26 | 物品自定义数据 | ✅ 已支持 | `addItem/spawnDrop` 的 `meta` + `item.*` 事件第 6 参数 |
| 27 | 方块来源标记 | ✅ 已支持 | `blk.source`（`'mod'` / `'builtin'`） |
| 28 | 通用右键交互 | ✅ 已支持 | `block.interact` 可取消事件 |
| 29 | 隐形方块 | ✅ 已支持 | `invisible: true` + `attachVisual` |
| 30 | 实体持久化 | ✅ 已支持 | `registerEntity` 的 `persistent: true` |
| 31 | 方块计划 tick | ✅ 已支持 | `scheduleBlockTick`，**不写存档**（卷一第 5 节） |
| 32 | 跨区块结构写入 | ✅ 已支持 | `chunk.decorate` 的 `api.setWorld`，未加载区块排队 |
| 33 | InstancedMesh 合批 | ❌ 不支持 | 大量同类方块仍是独立 Mesh |
| 34 | 按世界/按实体移动配置 | ❌ 不支持 | `setMovementConfig` 是进程级全局 |
| 35 | 状态效果跨存档 | ❌ 不支持 | 状态不进存档，`world.load` 会清空，需自己重建 |
| 36 | mod 可改键动作 / 冲突提示 | ✅ 已支持 | `G.keybinds.register({id,label,defaultKey,onPress,onRelease})`，出现在设置「按键绑定」；同键可多动作并标红提示（卷一 8.5） |

---

## 4. 整合包与地图（打包 / 分发）

游戏里有两组按钮：世界选择界面右下角的 **🧩 导入整合包 / 导出整合包**、
**📂 导入地图 / 导出当前地图**。它们在服务端是四组接口，但**共用同一种 zip 外壳**，
区别只在包里装了什么：

| | 包里必须有 | 通常还带 | 导入后发生什么 |
|---|---|---|---|
| **整合包** modpack | `mods/<modId>/...` | `modpack.json` | 把 mod 覆盖安装进 `mods/`，**不动任何存档** |
| **地图** map | `saves/<saveId>/...` | `mods/<modId>/...`、`modpack.json` | 生成一个**新 saveId** 的存档，并装上它依赖的 mod |

### 4.1 包格式

**整合包**

```
我的整合包.zip
├── modpack.json              ← 可选，元信息
└── mods/
    ├── raftcore/
    │   ├── manifest.json     ← 必需
    │   └── main.js
    └── raftworld/
        ├── manifest.json
        └── main.js
```

```json
// modpack.json
{
  "name": "筏海整合包",
  "mods": ["raftcore", "raftworld", "raftbuild"],
  "importedAt": 1793412182143
}
```

`mods` 和 `importedAt` 是服务端导入时**回填**的，手工打包时只写 `name` 就够了。

**地图**

```
我的地图.zip
├── modpack.json              ← 可选
├── saves/
│   └── wmvvrb6c4vs6/         ← 存档目录名随便叫，导入时会换新 id
│       ├── world.json        ← 必需（存档元信息）
│       ├── chunks/*.bin.gz   ← 区块数据
│       ├── dims/<dim>/chunks/
│       ├── chests/<dim>/<x>_<y>_<z>.json
│       ├── data/<modId>/...  ← mod 自己的存储
│       └── logs/
└── mods/
    └── raftcore/...          ← 地图依赖的 mod，一起打包才能还原
```

打包地图时用的是 `world.json` 里的 `plugins`（这个存档勾选了哪些 mod），
所以**进世界前勾选的 mod 会跟着一起走**。

### 4.2 接口

| 端点 | 方法 | 请求 | 成功响应 |
|---|---|---|---|
| `/api/import-modpack` | POST | 请求体 = 整个 zip 的二进制 | `{ ok, meta:{name,mods,importedAt}, mods:[id...] }` |
| `/api/export-modpack` | POST | `{ name?, mods:[id...]? }`（不传 `mods` = 全导出） | zip 二进制（`Content-Disposition` 附件） |
| `/api/import-map` | POST | 请求体 = 整个 zip 的二进制 | `{ ok, saveId, name, mods:[id...] }` |
| `/api/export-map` | POST | `{ saveId, withModpack?:false }` | zip 二进制 |

错误一律是 `{ error: "..." }` + 对应状态码：

| 状态码 | 场景 |
|---|---|
| 400 | 空包 / 不是 zip / 包里没有 `mods/<id>/`（导入整合包）或 `saves/<id>/`（导入地图）/ saveId 非法 |
| 404 | 导出时存档不存在 |
| 405 | 方法不对 |
| 413 | 包太大 |
| 501 | 旧版 `server_cpp` 未重新编译（新版已支持，见 4.3） |

**大小上限**：整包一次性读进内存再解压，上限默认 **64MB**
（`server.js` 的 `MAX_FILE_BYTES` / `server.cpp` 的 `PACK_MAX_BYTES`）。
C++ 端另外把解压后总量限制在 256MB，防 zip bomb。

### 4.3 三种服务端的支持情况

| 服务端 | 整合包 | 地图 | 实现 |
|---|---|---|---|
| Node.js `server.js` | ✅ | ✅ | 纯 JS zip（`zipx.js`，Node 内置 zlib），不依赖系统的 `zip` / `unzip` |
| Python `server.py` | ✅ | ✅ | 标准库 `zipfile` |
| C++ `server_cpp` | ✅ | ✅ | 内置 [miniz](https://github.com/richgel999/miniz)（`cpp-libs/miniz.c`），不依赖系统 `zip` / `unzip`；需用 `build_cpp.sh` 重新编译 |

> 历史坑：`server.js` 以前写的是 `execSync('zip')` / `execSync('unzip')`。
> Termux 上默认只有 `unzip` 没有 `zip`，所以"导出"一律失败；
> 而 `handleImportModpack/handleExportModpack` 当时**根本没实现**。
> 现在四个接口在三种服务端上都补齐了：Node/Python 用 zlib，C++ 用内置 miniz。

### 4.4 导入语义（重要）

1. **同名 mod 目录整体替换**。整合包里带了 `mods/raftcore/`，本地已有的
   `mods/raftcore/` 会被**删掉再写**（不是合并）。玩家自己改过的 mod 会丢，
   这是"整合包优先"的取舍。
2. **地图永远生成新 saveId**（`w` + 时间戳 + 3 位随机），`world.json` 里的 `id`
   会被改写成新 id，`lastPlayed`/`importedAt` 也会更新 —— 所以**不会覆盖**本地同名存档，
   同一个包可以反复导入出多个副本。
3. **导入地图时包里的 `mods/` 也会被安装**（规则同 1）。地图通常依赖它们，不装会加载失败。
4. **只取第一层 `saves/<id>/`**。一个包里塞多个存档，只有第一个会被导入
   （想分发多张图就打成多个包）。
5. **路径安全**：条目名会做校验，拒绝绝对路径、`..`、隐藏文件（`.` 开头）、
   超长段名；zip 里 CRC 不对的条目直接跳过，不会写出半个坏文件。

### 4.5 客户端行为（四个按钮在哪）

| 动作 | 位置 |
|---|---|
| 📂 **导入地图** | **世界类型选择对话框**（创建世界 → 世界类型 → 展开的「选择世界类型」）底部，和「关闭」并排 |
| 🧩 **导入整合包** | **创建世界 → 选择 Mod…** 那一行右边的「🧩 导入整合包」 |
| 📦 **导出地图** | 世界列表选中世界 → **世界设置** → 「地图 / 整合包」一节 |
| 🧩 **导出整合包** | 同上 |

行为细节：

- **导入**：选本地 `.zip` → 整个文件 POST 上去 → 成功后 `alert` 报出带了几个 mod。
  导入地图会出现在世界列表里（新存档）；导入整合包会把 mod 自动勾进
  "创建世界"的选择列表（`window.__addCreateDialogMod`）。
- **导出**：直接触发浏览器下载，导出完在「世界设置」里显示一行结果提示。
  导出整合包用的是**面板里当前勾选**的 mod（没勾则用 `world.json.plugins`）。
- 四个动作的实现在 `src/ui/ui-panel.js`（原 `src/ui/packs.js` 已并入），三个入口共用，不要各写一份。

### 4.6 手工打一个包

命令行（有 `zip` 的环境）：

```bash
# 整合包
cd /path/to/pack && zip -r 我的整合包.zip modpack.json mods/

# 地图（存档 + 它用的 mod）
cd /path/to/3dmc && zip -r 我的地图.zip saves/wmvvrb6c4vs6 mods/raftcore mods/raftworld
```

Python（任何环境都能跑，和 Python 服务端行为一致）：

```python
import zipfile, json, pathlib
root = pathlib.Path('/path/to/3dmc')
save = 'wmvvrb6c4vs6'
meta = json.loads((root/'saves'/save/'world.json').read_text(encoding='utf-8'))
with zipfile.ZipFile('我的地图.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in (root/'saves'/save).rglob('*'):
        if p.is_file(): z.write(p, p.relative_to(root))
    for mid in meta.get('plugins', []):
        for p in (root/'mods'/mid).rglob('*'):
            if p.is_file(): z.write(p, p.relative_to(root))
    z.writestr('modpack.json', json.dumps({'name': meta.get('name', save),
                                           'mods': meta.get('plugins', [])},
                                          ensure_ascii=False, indent=2))
```

### 4.7 已知限制

- C++ 服务端需要**用源码重新编译**（`bash build_cpp.sh`）后才支持导入导出；
  仓库里旧的 aarch64 预编译二进制如果不替换，仍会回 501。
- 打包是**全量读内存**再压：几百 MB 的存档会吃满内存（64MB 上限挡在前面）。
- 导入只处理**第一个** `saves/<id>`（见 4.4）。
- 不会校验 `manifest.json` 里的 `apiVersion`：包里的 mod 太老照样装进去，
  进世界时才会在"Mod 状态"里标红。
- 地图包不包含 `textures/` 或 mod 的额外资源目录（除了 mod 目录本身）。

---

## 5. Coremod 开发

> **定位**：Coremod 是对标 Minecraft Mixin 的底层代码注入系统。
>
> **警告**：Coremod 会直接修改源码结构，极不稳定。任何对 `src/` 下核心代码的修改
> 都可能导致依赖注入点的 Coremod 失效。若只需扩展功能，**请优先使用应用层 `mods/`**。

### 5.1 目录结构

每个 Coremod 必须放在 `coremods/<mod_id>/` 目录下，必须包含 `manifest.json` 和入口脚本（默认 `inject.js`）。

```text
coremods/
└── my_coremod/
    ├── manifest.json
    └── inject.js     (入口文件，由 manifest 的 entry 指定)
```

### 5.2 manifest.json 规范

```json
{
  "id": "my_coremod",
  "name": "我的底层模块",
  "version": "1.0.0",
  "apiVersion": 4,
  "stability": "experimental",
  "entry": "inject.js",
  "injections": [
    {
      "target": "src/player/player.js#_updatePlayerImpl",
      "at": "HEAD"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | string | 必须与目录名完全一致 |
| `stability` | string | `stable`（稳定）、`experimental`（实验性，UI 显示黄标）、`unstable`（不稳定） |
| `entry` | string | 入口 js 文件，默认 `inject.js` |
| `injections` | array | 声明要篡改哪些文件、什么位置 |
| `injections[].target` | string | 相对于 `src` 的文件路径 `#` 函数名（如 `src/world/chunk.js#buildMesh`） |
| `injections[].at` | string | 注入点：`HEAD`、`TAIL`、`RETURN` |

### 5.3 注入点详解

服务端在拦截到 `/src/*.js` 的请求时，会扫描代码进行动态重写。

#### HEAD（函数入口）

在原函数第一行代码执行前切入。

- 作用：修改传入参数、提前结束函数、执行副作用。
- 运行时接收参数：函数原本接收的所有参数。

#### TAIL（函数末尾）

在原函数最后一行（`}` 前）切入。

- 作用：执行收尾清理、状态同步。
- 注意：如果函数内有提前 `return`，TAIL **不会执行**。
- 运行时接收参数：无（通常通过 `window.__GAME__` 访问全局状态）。

#### RETURN（返回值截胡）

将函数内所有的 `return xxx;` 替换为 `return __MIXIN__.runReturn("target", xxx);`。

- 作用：修改函数的返回值。
- 注意：原函数末尾的隐式 `return undefined` 不会被拦截。
- 运行时接收参数：原函数的返回值。

### 5.4 inject.js 编写指南

入口脚本会在 `<body>` 末尾被加载（早于游戏主逻辑），你只需要调用 `window.__MIXIN__` 注册回调。

```javascript
// 注册 HEAD 拦截器
window.__MIXIN__.register(
  'src/player/player.js#_updatePlayerImpl',
  'HEAD',
  (dt, input) => {
    // 这里写你要插入的逻辑
  }
);

// 注册 RETURN 拦截器
window.__MIXIN__.register(
  'src/world/chunk.js#getEffectiveRenderDist',
  'RETURN',
  (retValue) => {
    // 必须返回新的值来覆盖原返回值
    return retValue + 2;
  }
);
```

**运行时机**：`inject.js` 被加载时，游戏可能尚未初始化完成。如果是全局操作，
建议监听 `world.enter` 事件或使用 `setTimeout` 延迟执行。

```javascript
// 安全的初始化方式
window.addEventListener('load', () => {
  const G = window.__GAME__;
  if (G){
    G.log.info('Coremod', '已绑定到底层事件');
  }
});
```

### 5.5 实战示例

#### 场景 1：让玩家获得 2 倍移动速度

找到 `src/player/player.js` 里的 `_updatePlayerImpl`。

```javascript
window.__MIXIN__.register(
  'src/player/player.js#_updatePlayerImpl',
  'HEAD',
  (dt, input) => {
    // 注入点可以拿到原始 input 对象
    if (input && input.keys){
      // 我们不动 input，直接改全局常量或拦截函数
    }
  }
);

// 更好的做法：拦截 player.js 内部的变量计算（假设有 getWalkSpeed 函数）
// 或者利用 RETURN 拦截：
window.__MIXIN__.register(
  'src/player/player.js#_getWalkSpeed',
  'RETURN',
  (speed) => {
    return speed * 2;
  }
);
```

#### 场景 2：阻止方块被放置

找到 `src/world/terrain.js` 的 `setBlockWorld`。可以在 HEAD 阶段拦截非法操作，
但 **HEAD 无法阻止原函数执行**。

所以应该用应用层 mod 的：

```js
G.hook('world.setBlock').before(([x, y, z, id]) => {
  if (shouldBlock(x, y, z, id)) return false;   // false = 拦截
});
```

**最佳实践**：能用事件总线/Hook 拦截的，优先用 `mods/`。
只有当需要修改返回值（如上面改速度）、或者插入到极深层次的函数内部
（如 mesh-builder 的某个顶点计算里），才动用 Coremod。

### 5.6 调试与诊断

1. **查看注入结果**：
   浏览器直接访问 `http://localhost:8080/src/player/player.js`，搜索 `__MIXIN__.run`。
   如果能看到被插入的代码，说明服务端 AST 引擎工作正常。
2. **看游戏报错**：
   如果 `inject.js` 有语法错误，游戏加载会直接白屏或报错。
   手机端可以打开游戏左上角的「⚠ 有错误」面板，里面会附带当前活跃的 Coremod 列表。
3. **冲突检测**：
   如果多个 Coremod 注入了同一个函数的同一个 `at` 位置，它们会按照在 `manifest.json` 中
   读到的顺序（字典序）依次执行。
4. **如何恢复**：
   如果写错了一个 Coremod 导致游戏打不开，直接去 `coremods/` 目录下删掉那个文件夹，刷新页面即可。

### 5.7 已知限制

1. **不支持 INVOKE**（精确拦截特定函数调用）。目前的引擎是"基于括号匹配的词法扫描"，
   做不到像 Java Mixin 那样的字节码级 INVOKE。
2. 如果原函数是箭头函数（`const fn = () => {}`），目前仅支持
   `const fn = function() {}` 或 `function fn() {}` 的匹配。
3. **缓存极端顽固**：如果服务端重启或代码修改，必须硬刷新（清空浏览器缓存）
   才能拿到新的注入代码。

---

## 6. 调试与反馈

### 6.1 先确认不是"文档过时"

本套三卷按 2026-11-05 源码核对。遇到行为与文档不符时，优先检查：

1. `G.apiVersion` 是否 ≥ 你用到接口的版本；
2. 暂停菜单 → Mod 状态，你的 mod 是绿色还是红/紫色；
3. 控制台 `[loader]` 与 `[terrain-worker]` 的日志；
4. 是不是在用旧文档里的写法（`onBlockBreak`、`generate(cx,cz,cfg)`、依赖环跳过等）。

### 6.2 最小复现

反馈问题时附上：

- 宿主版本 `G.version` / `G.apiVersion`；
- `manifest.json`（可隐去私人信息）；
- 触发步骤（哪个操作、哪个坐标/维度）；
- 控制台完整报错，以及 `G.info.disabledEntityAi` 是否包含你的实体类型；
- 如果是地形问题，说明是否用了 `worldgenUrl`、是否发生 Worker 回退。

### 6.3 能用 mod 层解决的，不要用 Coremod

| 需求 | 推荐做法 |
|---|---|
| 取消方块破坏/放置 | `block.break` / `block.place` 返回 `true` |
| 取消合成/拾取 | `item.craft:before` / `item.canPickup` 返回 `true` |
| 改方块写入 | `G.hook('world.setBlock').before` |
| 改玩家伤害 | `G.hook('player.damage')` |
| 改移动/跳跃/浮力 | `G.setMovementConfig` |
| 改液体流动 | `G.setFluidConfig` + `fluid.*` |
| 自定义右键交互 | `block.interact` + `G.input.consume` |
| 周期性方块逻辑 | `G.scheduleBlockTick` |
| 只有"改返回值"或"函数内部深处"才考虑 Coremod | `RETURN` / `HEAD` 注入 |
