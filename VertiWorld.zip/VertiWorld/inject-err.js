const fs = require('fs');
const p = '/storage/emulated/0/3dmc/index.html';
let html = fs.readFileSync(p, 'utf8');
if (html.includes('__errpanel__')) {
  console.log('已经注入过，跳过');
  process.exit(0);
}
const inject = `
<div id="__errpanel__" style="position:fixed;left:0;right:0;top:0;z-index:2147483647;background:#b00000;color:#fff;font:12px/1.45 monospace;padding:8px;max-height:65vh;overflow:auto;white-space:pre-wrap;display:none;"></div>
<script>
(function(){
  var panel = document.getElementById('__errpanel__');
  function show(msg){
    panel.style.display = 'block';
    panel.textContent += msg + '\\n';
  }
  window.addEventListener('error', function(e){
    show('[ERROR] ' + (e.message || e.error) +
         (e.filename ? '\\n   @ ' + e.filename + ':' + (e.lineno||'')) : ''));
  }, true);
  window.addEventListener('unhandledrejection', function(e){
    var r = e.reason;
    show('[REJECT] ' + (r && (r.stack || r.message) || r));
  });
  window.addEventListener('DOMContentLoaded', function(){
    setTimeout(function(){
      if (!document.querySelector('canvas')){
        show('[WARN] 页面加载 8 秒后仍没有 canvas —— three.js 或 renderer.js 没跑起来');
      }
      if (typeof window.__mainLoaded__ === 'undefined'){
        show('[WARN] main.js 模块顶层未执行完（可能在 import 阶段就断了）');
      }
    }, 8000);
  });
})();
<\/script>
`;
html = html.replace('</body>', inject + '</body>');
fs.writeFileSync(p, html);
console.log('注入完成');
