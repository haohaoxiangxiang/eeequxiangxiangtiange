#!/usr/bin/env bash
# ============================================================
#  stop.sh —— 一键释放 深入世界 VertiWorld 服务器占用的端口
# ------------------------------------------------------------
#  用法（注意：sd 卡上没法加执行位，要用 bash 调用）:
#    bash stop.sh            结束占用 8080 的 VertiWorld 服务器
#    bash stop.sh 8081       指定端口
#    bash stop.sh --list     只看谁在跑/端口有没有被占
#
#  为什么需要它:
#    Termux 被系统回收后，node / python / server_cpp 会变成孤儿进程
#    继续占着端口（看着像“僵尸进程”），再启动就 EADDRINUSE。
#    Android 非 root 下 /proc/net/tcp、ss、lsof 全部 Permission denied，
#    所以这里改成「扫同 uid 的 /proc/<pid>/cmdline」+「TCP 连接探测」。
# ============================================================
set -u
PORT=8080
MODE="kill"
for arg in "$@"; do
  case "$arg" in
    --list) MODE="list" ;;
    ''|*[!0-9]*) ;;
    *) PORT="$arg" ;;
  esac
done

if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else echo "✘ 需要 python3"; exit 1; fi

"$PY" - "$PORT" "$MODE" <<'PYEOF'
import os, sys, re, time, signal, socket

port = int(sys.argv[1]); mode = sys.argv[2]
PAT = re.compile(r'(?:^|[/\\])(?:server\.js|server\.py|server_cpp|3dmc_server_cpp)$')

def server_procs():
    out = []
    try: pids = [d for d in os.listdir('/proc') if d.isdigit()]
    except Exception: return out
    for pid in pids:
        try: raw = open('/proc/%s/cmdline' % pid, 'rb').read()
        except Exception: continue
        if not raw: continue
        argv = [a for a in raw.decode('utf-8','replace').split('\0') if a]
        if argv and any(PAT.search(a) for a in argv):
            out.append((int(pid), ' '.join(argv)))
    return out

def port_busy(p):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.7)
    try:
        s.connect(('127.0.0.1', p)); return True
    except Exception:
        return False
    finally:
        try: s.close()
        except Exception: pass

procs = [(p, c) for p, c in server_procs() if p != os.getpid()]
busy  = port_busy(port)

print('端口 %d: %s' % (port, '被占用' if busy else '空闲'))
if procs:
    print('3dmc 服务器进程:')
    for pid, cmd in procs:
        print('   pid=%-7d %s' % (pid, cmd))
else:
    print('3dmc 服务器进程: 无')

if mode == 'list':
    sys.exit(0 if not procs else 0)

if not procs:
    if busy:
        print('\n端口有响应但没有 3dmc 进程 —— 是别的程序占着（Android 拿不到对方 pid）')
        print('换个端口即可:  PORT=8081 bash start.sh node')
        sys.exit(1)
    print('\n✔ 无需清理')
    sys.exit(0)

for pid, cmd in procs:
    try: os.kill(pid, signal.SIGTERM)
    except Exception: pass
time.sleep(0.6)
for pid, cmd in procs:
    if os.path.exists('/proc/%d' % pid):
        try: os.kill(pid, signal.SIGKILL)
        except Exception: pass
time.sleep(0.5)

left = [(p, c) for p, c in server_procs() if p != os.getpid()]
if left:
    print('\n✘ 仍有进程存在: %s' % ', '.join(str(p) for p, _ in left))
    sys.exit(1)
print('\n✔ 已结束 %d 个进程；端口 %d %s' %
      (len(procs), port, '仍被占用（别的程序）' if port_busy(port) else '已释放'))
PYEOF
