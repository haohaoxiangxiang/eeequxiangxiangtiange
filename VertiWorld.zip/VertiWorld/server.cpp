#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <filesystem>
#include <regex>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <chrono>
#include <random>
#include <csignal>
#include <unistd.h>
#include <algorithm>
#include "httplib.h"
#include <nlohmann/json.hpp>
#include "miniz.h"

using namespace std;
using json = nlohmann::json;
namespace fs = std::filesystem;

const string ROOT = ".";
const string SAVES_DIR = ROOT + "/saves";
const string MODS_DIR = ROOT + "/mods";
const string COREMODS_DIR = ROOT + "/coremods";
const string TEXTURES_DIR = ROOT + "/textures";
const string TMP_DIR = ROOT + "/.tmp";

regex re_save_id("^[a-zA-Z0-9_-]{1,64}$");
regex re_mod_id("^[a-zA-Z0-9_-]{1,64}$");

// ==========================================
// 工具函数
// ==========================================
string read_file(const string& path) {
    ifstream f(path, ios::binary);
    if (!f) return "";
    return string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
}

void write_file(const string& path, const string& data) {
    fs::create_directories(fs::path(path).parent_path());
    ofstream f(path, ios::binary);
    f.write(data.data(), data.size());
}

// 简单的安全检查，防止目录穿越
bool is_safe_path(const string& base, const string& target) {
    string p1 = fs::absolute(base).lexically_normal().string();
    string p2 = fs::absolute(target).lexically_normal().string();
    return p2.find(p1) == 0;
}

// ==========================================
// 整合包 / 地图 zip（miniz 实现，不依赖系统 zip 命令）
// ==========================================
const size_t PACK_MAX_BYTES = 64u * 1024u * 1024u;        /* 与 server.js 的 MAX_FILE_BYTES 对齐 */
const size_t PACK_MAX_UNZIP_BYTES = 256u * 1024u * 1024u;  /* 解压后总量上限，防 zip bomb */

struct PackEntry { string name; string data; };
struct PackFile  { vector<string> segs; string data; };

long long epoch_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

bool ends_with(const string& s, const string& suf) {
    return s.size() >= suf.size() && s.compare(s.size() - suf.size(), suf.size(), suf) == 0;
}

bool is_pack_junk(const string& n) {
    if (n.empty() || n[0] == '.') return true;          /* 隐藏文件 / 目录 */
    string l = n;
    for (auto& c : l) c = (char)std::tolower((unsigned char)c);
    if (l == ".ds_store" || l == "thumbs.db" || l == "desktop.ini") return true;
    if (ends_with(l, "~") || ends_with(l, ".tmp") || ends_with(l, ".swp") || ends_with(l, ".orig")) return true;
    if (ends_with(l, ".bak") || l.find(".bak.") != string::npos) return true;
    return false;
}

/* 只接受 "a/b/c" 相对路径：拒绝绝对路径、..、. 和隐藏段，与 server.js 的 _safeRel 一致 */
bool safe_rel_segments(const string& name, vector<string>& segs) {
    if (name.empty() || name.find('\0') != string::npos) return false;
    string cur;
    segs.clear();
    for (size_t i = 0; i <= name.size(); i++) {
        char c = (i == name.size()) ? '/' : name[i];
        if (c == '\\') c = '/';
        if (c == '/') {
            if (!cur.empty()) {
                if (cur == "." || cur == ".." || cur[0] == '.') return false;
                if (cur.size() > 128) return false;
                segs.push_back(cur);
            }
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }
    return !segs.empty();
}

bool write_entry_file(const string& root, const vector<string>& segs, const string& data) {
    string full = root;
    for (const auto& s : segs) { full += "/"; full += s; }
    if (!is_safe_path(root, full)) return false;
    write_file(full, data);
    return true;
}

/* 递归收集目录，跳过隐藏文件 / 编辑器残留 / 超大文件，与 server.js 导出规则一致 */
void collect_dir(const string& base, const string& prefix, vector<PackEntry>& out) {
    if (!fs::exists(base) || !fs::is_directory(base)) return;
    std::error_code ec;
    fs::recursive_directory_iterator it(base, fs::directory_options::skip_permission_denied, ec), end;
    while (!ec && it != end) {
        const fs::directory_entry& de = *it;
        string n = de.path().filename().string();
        bool skip = is_pack_junk(n);
        bool is_dir = de.is_directory(ec);
        if (is_dir) {
            if (skip) it.disable_recursion_pending();
            it.increment(ec);
            continue;
        }
        if (skip || !de.is_regular_file(ec)) { it.increment(ec); continue; }
        size_t sz = (size_t)de.file_size(ec);
        if (ec || sz > PACK_MAX_BYTES) { it.increment(ec); continue; }
        string rel = fs::relative(de.path(), base, ec).generic_string();
        string data = read_file(de.path().string());
        if (!ec && !rel.empty() && (sz == 0 || data.size() == sz)) {
            out.push_back({prefix + rel, std::move(data)});
        }
        it.increment(ec);
    }
}

bool unpack_zip(const string& buf, vector<PackEntry>& out, string& err) {
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_mem(&zip, buf.data(), buf.size(), 0)) {
        err = "不是有效的 zip 文件";
        return false;
    }
    size_t total = 0;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n; i++) {
        if (mz_zip_reader_is_file_a_directory(&zip, i)) continue;
        mz_zip_archive_file_stat st;
        if (!mz_zip_reader_file_stat(&zip, i, &st)) continue;
        if (st.m_uncomp_size > PACK_MAX_BYTES) {
            err = "包内单个文件超过 64MB";
            mz_zip_reader_end(&zip);
            return false;
        }
        total += (size_t)st.m_uncomp_size;
        if (total > PACK_MAX_UNZIP_BYTES) {
            err = "解压后总大小超过 256MB";
            mz_zip_reader_end(&zip);
            return false;
        }
        if (st.m_uncomp_size == 0) {
            out.push_back({st.m_filename, ""});
            continue;
        }
        string data((size_t)st.m_uncomp_size, '\0');
        if (!mz_zip_reader_extract_to_mem(&zip, i, data.data(), data.size(), 0)) continue;
        out.push_back({st.m_filename, std::move(data)});
    }
    mz_zip_reader_end(&zip);
    return true;
}

bool make_zip(const vector<PackEntry>& entries, string& out, string& err) {
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_writer_init_heap(&zip, 0, 0)) {
        err = "无法创建 zip";
        return false;
    }
    for (const auto& e : entries) {
        if (!mz_zip_writer_add_mem(&zip, e.name.c_str(), e.data.data(), e.data.size(), MZ_DEFAULT_LEVEL)) {
            err = "写入 zip 失败: " + e.name;
            mz_zip_writer_end(&zip);
            return false;
        }
    }
    void* pBuf = nullptr;
    size_t sz = 0;
    if (!mz_zip_writer_finalize_heap_archive(&zip, &pBuf, &sz)) {
        err = "zip 收尾失败";
        mz_zip_writer_end(&zip);
        return false;
    }
    out.assign((const char*)pBuf, sz);
    mz_free(pBuf);
    mz_zip_writer_end(&zip);
    return true;
}

string url_encode(const string& s) {
    string out;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') out.push_back((char)c);
        else {
            char buf[4];
            snprintf(buf, sizeof(buf), "%%%02X", c);
            out += buf;
        }
    }
    return out;
}

string safe_pack_name(const string& in, const string& fallback) {
    string out;
    for (char c : in) {
        if (c == '\\' || c == '/' || c == ':' || c == '*' || c == '?' ||
            c == '"' || c == '<' || c == '>' || c == '|') out.push_back('_');
        else out.push_back(c);
    }
    if (out.size() > 40) out.resize(40);
    return out.empty() ? fallback : out;
}

string base36(long long v) {
    if (v <= 0) return "0";
    string s;
    while (v > 0) {
        int d = (int)(v % 36);
        s.push_back(d < 10 ? (char)('0' + d) : (char)('a' + d - 10));
        v /= 36;
    }
    reverse(s.begin(), s.end());
    return s;
}

string random_b36(int n) {
    static const char* cs = "0123456789abcdefghijklmnopqrstuvwxyz";
    thread_local std::mt19937 rng((unsigned)std::random_device{}());
    std::uniform_int_distribution<int> dist(0, 35);
    string s;
    for (int i = 0; i < n; i++) s.push_back(cs[dist(rng)]);
    return s;
}

json install_mod_groups(map<string, vector<PackFile>>& groups) {
    json installed = json::array();
    for (auto& kv : groups) {
        const string& id = kv.first;
        string dest = MODS_DIR + "/" + id;
        std::error_code ec;
        /* 同名 mod 整目录替换：整合包优先 */
        fs::remove_all(dest, ec);
        fs::create_directories(dest, ec);
        for (auto& f : kv.second) write_entry_file(dest, f.segs, f.data);
        installed.push_back(id);
    }
    return installed;
}

bool check_pack_body(const httplib::Request& req, httplib::Response& res) {
    if (req.body.empty()) {
        res.status = 400;
        res.set_content("{\"error\":\"空文件\"}", "application/json");
        return false;
    }
    if (req.body.size() > PACK_MAX_BYTES) {
        res.status = 413;
        res.set_content("{\"error\":\"包太大\"}", "application/json");
        return false;
    }
    return true;
}

bool split_pack(const string& buf,
                map<string, vector<PackFile>>& modFiles,
                map<string, vector<PackFile>>& saveFiles,
                json& modpackJson, httplib::Response& res) {
    vector<PackEntry> entries;
    string err;
    if (!unpack_zip(buf, entries, err)) {
        res.status = 400;
        res.set_content(json{{"error", "解压失败: " + err}}.dump(), "application/json");
        return false;
    }
    for (auto& e : entries) {
        vector<string> segs;
        if (!safe_rel_segments(e.name, segs)) continue;
        const string& top = segs[0];
        if (top == "modpack.json" && segs.size() == 1) {
            try { modpackJson = json::parse(e.data); } catch (...) {}
            continue;
        }
        if (top == "mods" && segs.size() >= 3) {
            string id = segs[1];
            if (!regex_match(id, re_mod_id)) continue;
            vector<string> sub(segs.begin() + 2, segs.end());
            modFiles[id].push_back({sub, std::move(e.data)});
            continue;
        }
        if (top == "saves" && segs.size() >= 3) {
            string id = segs[1];
            if (!regex_match(id, re_save_id)) continue;
            vector<string> sub(segs.begin() + 2, segs.end());
            saveFiles[id].push_back({sub, std::move(e.data)});
        }
    }
    return true;
}

void send_zip(httplib::Response& res, const string& fileName, vector<PackEntry>& entries) {
    string data, err;
    if (!make_zip(entries, data, err)) {
        res.status = 500;
        res.set_content(json{{"error", err}}.dump(), "application/json");
        return;
    }
    res.set_header("Content-Disposition", "attachment; filename=\"" + url_encode(fileName) + "\"");
    res.set_header("Cache-Control", "no-store");
    res.set_content(std::move(data), "application/zip");
}

// ---- 四个打包接口（与 server.js / server.py 行为对齐） ----
void handle_import_modpack(const httplib::Request& req, httplib::Response& res) {
    if (!check_pack_body(req, res)) return;
    map<string, vector<PackFile>> modFiles, saveFiles;
    json packJson = json::object();
    if (!split_pack(req.body, modFiles, saveFiles, packJson, res)) return;
    if (modFiles.empty()) {
        res.status = 400;
        res.set_content("{\"error\":\"包里没有 mods/<modId>/ 目录\"}", "application/json");
        return;
    }
    json mods = install_mod_groups(modFiles);
    string name = "imported_pack";
    if (packJson.is_object() && packJson.contains("name") &&
        packJson["name"].is_string() && !packJson["name"].get<string>().empty()) {
        name = packJson["name"].get<string>();
    }
    json meta = {{"name", name}, {"mods", mods}, {"importedAt", epoch_ms()}};
    cout << "[modpack] 导入整合包「" << name << "」: " << mods.dump() << endl;
    res.set_content(json{{"ok", true}, {"meta", meta}, {"mods", mods}}.dump(), "application/json");
}

void handle_export_modpack(const httplib::Request& req, httplib::Response& res) {
    json body = json::object();
    try { if (!req.body.empty()) body = json::parse(req.body); } catch (...) { body = json::object(); }
    if (!body.is_object()) body = json::object();

    vector<string> mods;
    if (body.contains("mods") && body["mods"].is_array()) {
        for (auto& m : body["mods"]) {
            if (m.is_string() && regex_match(m.get<string>(), re_mod_id)) mods.push_back(m.get<string>());
        }
    }
    if (mods.empty() && fs::exists(MODS_DIR)) {
        for (const auto& de : fs::directory_iterator(MODS_DIR)) {
            string n = de.path().filename().string();
            if (de.is_directory() && regex_match(n, re_mod_id)) mods.push_back(n);
        }
    }
    if (mods.empty()) {
        res.status = 400;
        res.set_content("{\"error\":\"没有可导出的 mod\"}", "application/json");
        return;
    }

    string rawName = "MyModpack";
    if (body.contains("name") && body["name"].is_string()) rawName = body["name"].get<string>();
    string name = safe_pack_name(rawName, "MyModpack");

    vector<PackEntry> entries;
    entries.push_back({"modpack.json", json{{"name", name}, {"mods", mods}}.dump(2)});
    for (const auto& id : mods) collect_dir(MODS_DIR + "/" + id, "mods/" + id + "/", entries);
    send_zip(res, name + ".zip", entries);
}

void handle_import_map(const httplib::Request& req, httplib::Response& res) {
    if (!check_pack_body(req, res)) return;
    map<string, vector<PackFile>> modFiles, saveFiles;
    json packJson = json::object();
    if (!split_pack(req.body, modFiles, saveFiles, packJson, res)) return;
    if (saveFiles.empty()) {
        res.status = 400;
        res.set_content("{\"error\":\"包里没有 saves/<saveId>/ 目录\"}", "application/json");
        return;
    }

    /* 包里的 mod 一起装上（地图通常依赖它们） */
    json installedMods = modFiles.empty() ? json::array() : install_mod_groups(modFiles);

    /* 新 saveId，绝不覆盖本地同名存档 */
    string newId;
    do {
        newId = "w" + base36(epoch_ms()) + random_b36(3);
    } while (fs::exists(SAVES_DIR + "/" + newId));

    string dest = SAVES_DIR + "/" + newId;
    fs::create_directories(dest);
    const auto& first = *saveFiles.begin();
    for (const auto& f : first.second) write_entry_file(dest, f.segs, f.data);

    /* world.json 里的 id 改成新的，否则客户端会认错存档 */
    json meta = json::object();
    string wj = dest + "/world.json";
    if (fs::exists(wj)) {
        try { meta = json::parse(read_file(wj)); } catch (...) { meta = json::object(); }
    }
    if (!meta.is_object()) meta = json::object();
    string name = "导入的地图";
    if (meta.contains("name") && meta["name"].is_string() && !meta["name"].get<string>().empty()) {
        name = meta["name"].get<string>();
    }
    meta["id"] = newId;
    meta["lastPlayed"] = epoch_ms();
    meta["name"] = name;
    meta["importedAt"] = epoch_ms();
    write_file(wj, meta.dump(2));

    cout << "[map] 导入地图「" << name << "」→ " << newId
         << "（附带 mod: " << installedMods.dump() << "）" << endl;
    res.set_content(json{{"ok", true}, {"saveId", newId}, {"name", name}, {"mods", installedMods}}.dump(),
                    "application/json");
}

void handle_export_map(const httplib::Request& req, httplib::Response& res) {
    json body = json::object();
    try { if (!req.body.empty()) body = json::parse(req.body); } catch (...) { body = json::object(); }
    if (!body.is_object()) body = json::object();

    string saveId;
    if (body.contains("saveId") && body["saveId"].is_string()) saveId = body["saveId"].get<string>();
    if (saveId.empty() || !regex_match(saveId, re_save_id)) {
        res.status = 400;
        res.set_content("{\"error\":\"存档 id 非法\"}", "application/json");
        return;
    }
    string src = SAVES_DIR + "/" + saveId;
    if (!fs::exists(src)) {
        res.status = 404;
        res.set_content("{\"error\":\"存档不存在\"}", "application/json");
        return;
    }

    json meta = json::object();
    string wj = src + "/world.json";
    if (fs::exists(wj)) {
        try { meta = json::parse(read_file(wj)); } catch (...) { meta = json::object(); }
    }
    if (!meta.is_object()) meta = json::object();
    string name = saveId;
    if (meta.contains("name") && meta["name"].is_string() && !meta["name"].get<string>().empty()) {
        name = meta["name"].get<string>();
    }
    name = safe_pack_name(name, saveId);

    vector<PackEntry> entries;
    collect_dir(src, "saves/" + saveId + "/", entries);

    /* 连同它依赖的 mod：world.json.plugins */
    vector<string> packedMods;
    if (meta.contains("plugins") && meta["plugins"].is_array()) {
        for (auto& p : meta["plugins"]) {
            if (!p.is_string()) continue;
            string id = p.get<string>();
            if (!regex_match(id, re_mod_id)) continue;
            string dir = MODS_DIR + "/" + id;
            if (!fs::exists(dir)) continue;
            collect_dir(dir, "mods/" + id + "/", entries);
            packedMods.push_back(id);
        }
    }

    bool withModpack = true;
    if (body.contains("withModpack") && body["withModpack"].is_boolean()) {
        withModpack = body["withModpack"].get<bool>();
    }
    if (withModpack) {
        entries.push_back({"modpack.json",
            json{{"name", name}, {"mods", packedMods}, {"saveId", saveId}}.dump(2)});
    }
    send_zip(res, name + ".zip", entries);
}

// ==========================================
// 核心数据构建
// ==========================================
json list_mods() {
    json out = json::array();
    if (!fs::exists(MODS_DIR)) return out;
    for (const auto& entry : fs::directory_iterator(MODS_DIR)) {
        if (!entry.is_directory()) continue;
        string name = entry.path().filename().string();
        if (name.empty() || name[0] == '.' || !regex_match(name, re_mod_id)) continue;
        
        string mf = entry.path().string() + "/manifest.json";
        if (!fs::exists(mf)) continue;
        
        try {
            json m = json::parse(read_file(mf));
            // ★ 只有【声明了 id 且与目录名不符】才跳过；没写 id 时用目录名（与 server.js 对齐）
            if (m.contains("id") && m["id"].is_string()
                && !m["id"].get<string>().empty() && m["id"].get<string>() != name) continue;
            if (!m.contains("id") || !m["id"].is_string() || m["id"].get<string>().empty()) {
                m["id"] = name;
            }
            m["folderSize"] = 0; // 简化处理
            out.push_back(m);
        } catch (...) {}
    }
    return out;
}

json list_coremods() {
    json out = json::array();
    if (!fs::exists(COREMODS_DIR)) return out;
    for (const auto& entry : fs::directory_iterator(COREMODS_DIR)) {
        if (!entry.is_directory()) continue;
        string mf = entry.path().string() + "/manifest.json";
        if (fs::exists(mf)) {
            try { out.push_back(json::parse(read_file(mf))); } catch(...){}
        }
    }
    return out;
}

json scan_hooks() {
    json hooks = json::array();
    json events = json::array();
    if (!fs::exists("src")) return {{"hooks", hooks}, {"events", events}};
    
    for (const auto& p : fs::recursive_directory_iterator("src")) {
        if (!p.is_regular_file() || p.path().extension() != ".js") continue;
        string path_str = p.path().string();
        if (path_str.find("vendor") != string::npos) continue;
        
        ifstream f(path_str);
        string line;
        int line_num = 1;
        while (getline(f, line)) {
            std::smatch m;
            std::regex re_hook("defineHook\\(\\s*['\"]([^'\"]+)['\"]");
            std::regex re_event("emit\\(\\s*['\"]([^'\"]+)['\"]");
            if (std::regex_search(line, m, re_hook)) {
                hooks.push_back({{"name", m[1].str()}, {"file", path_str}, {"line", line_num}});
            }
            if (std::regex_search(line, m, re_event)) {
                events.push_back({{"name", m[1].str()}, {"file", path_str}, {"line", line_num}});
            }
            line_num++;
        }
    }
    return {{"hooks", hooks}, {"events", events}};
}

// ==========================================
// Mixin JS 注入逻辑
// ==========================================
string inject_js(string source, const string& rel_path) {
    if (rel_path.find("src/") != 0) return source;
    json cms = list_coremods();
    
    for (const auto& cm : cms) {
        if (!cm.contains("injections")) continue;
        for (const auto& inj : cm["injections"]) {
            string target = inj.value("target", "");
            size_t hash_pos = target.find('#');
            if (hash_pos == string::npos) continue;
            
            string t_file = target.substr(0, hash_pos);
            string t_fn = target.substr(hash_pos + 1);
            if (t_file != rel_path) continue;

            // 正则匹配 function 函数名 或 const 函数名 = function
            std::regex fn_re("((?:async\\s+)?function\\s+" + t_fn + "\\s*\\(([^)]*)\\)|(?:const|let|var)\\s+" + t_fn + "\\s*=\\s*(?:async\\s+)?function\\s*\\(([^)]*)\\))\\s*\\{");
            std::smatch match;
            if (!std::regex_search(source, match, fn_re)) continue;

            string args = match[2].matched ? match[2].str() : (match[3].matched ? match[3].str() : "");
            string target_str = "\"" + target + "\"";
            
            // 找到函数开口括号
            size_t open_idx = match.position() + match.length() - 1;
            string at = inj.value("at", "HEAD");
            
            if (at == "HEAD") {
                string head_code = "\n  if (globalThis.__MIXIN__) __MIXIN__.run(" + target_str + ", 'HEAD'" + (args.empty() ? "" : ", " + args) + ");";
                source.insert(open_idx + 1, head_code);
            }
            // 为了代码安全，C++ 端暂不实现 TAIL 的括号闭合匹配，只做 HEAD 注入
        }
    }
    return source;
}

// ---- MIME 类型表 ----
// ★ 关键修复：浏览器对 CSS 和 ES Module 做严格 MIME 校验。
//   以前 /src/ 与 /mods/ 一律回 application/octet-stream：
//     · style.css 被当成二进制 → 浏览器拒绝应用样式表 → 界面只剩裸 HTML 框和文字
//     · mod 的 import('/mods/xxx/main.js') 全部 MIME 校验失败 → 所有 mod 加载不了
string mime_of(const string& path) {
    size_t slash = path.find_last_of("/\\");
    size_t dot = path.find_last_of('.');
    string ext;
    if (dot != string::npos && (slash == string::npos || dot > slash)) ext = path.substr(dot);
    for (auto& c : ext) c = (char)std::tolower((unsigned char)c);

    if (ext == ".html" || ext == ".htm") return "text/html; charset=utf-8";
    if (ext == ".css")   return "text/css; charset=utf-8";
    if (ext == ".js" || ext == ".mjs") return "text/javascript; charset=utf-8";
    if (ext == ".json" || ext == ".map") return "application/json; charset=utf-8";
    if (ext == ".svg")   return "image/svg+xml";
    if (ext == ".png")   return "image/png";
    if (ext == ".jpg" || ext == ".jpeg") return "image/jpeg";
    if (ext == ".gif")   return "image/gif";
    if (ext == ".webp")  return "image/webp";
    if (ext == ".ico")   return "image/x-icon";
    if (ext == ".wasm")  return "application/wasm";
    if (ext == ".woff")  return "font/woff";
    if (ext == ".woff2") return "font/woff2";
    if (ext == ".ttf")   return "font/ttf";
    if (ext == ".mp3")   return "audio/mpeg";
    if (ext == ".ogg")   return "audio/ogg";
    if (ext == ".wav")   return "audio/wav";
    if (ext == ".txt" || ext == ".md") return "text/plain; charset=utf-8";
    return "application/octet-stream";
}

// 注入 HTML
string process_index() {
    string html = read_file("index.html");
    if (html.empty()) return "";

    // 1. 注入 Atlas 配置
    json mods = list_mods();
    int mod_needs = 0;
    for (const auto& m : mods) {
        if (m.contains("contents") && !m["contents"].is_null()) {
            auto c = m["contents"];
            mod_needs += c.value("blocks", 0) + c.value("items", 0) + c.value("entities", 0) * 3;
        }
    }
    int need = (int)((220 + mod_needs * 1.5) * 1.3);
    int cols = 32;
    if (need > 1024) cols = 64;
    if (need > 4096) cols = 128;
    if (need > 16384) cols = 256;
    
    json atlas = {{"cols", cols}, {"tiles", cols * cols}, {"need", need}, {"modNeeds", mod_needs}};
    string head_inject = "<script>window.__ATLAS_CONFIG__ = " + atlas.dump() + ";</script>\n";

    // 2. 注入 Coremods
    json cms = list_coremods();
    string body_inject = "";
    if (!cms.empty()) {
        head_inject += "<script>window.__COREMODS__ = " + cms.dump() + ";</script>\n";
        for (const auto& cm : cms) {
            string entry = cm.value("entry", "inject.js");
            body_inject += "<script src=\"/coremods/" + cm["id"].get<string>() + "/" + entry + "\"></script>\n";
        }
    }

    // 3. 注入材质
    string tex_file = TEXTURES_DIR + "/custom.json";
    if (fs::exists(tex_file)) {
        string custom_tex = read_file(tex_file);
        if (custom_tex != "{}" && !custom_tex.empty()) {
            head_inject += "<script>window.__CUSTOM_TEXTURES__ = " + custom_tex + ";</script>\n";
        }
    }

    // 替换 HTML
    size_t head_pos = html.find("</head>");
    if (head_pos != string::npos) html.insert(head_pos, head_inject);
    
    size_t body_pos = html.find("</body>");
    if (body_pos != string::npos && !body_inject.empty()) html.insert(body_pos, body_inject);

    return html;
}

// ==========================================
// 主服务端
// ==========================================
/* ---- ★ 优雅退出：Ctrl+C / SIGTERM / SIGHUP 都能立刻释放端口 ---- */
static httplib::Server* g_srv = nullptr;
static void _on_term_signal(int sig){
    if (g_srv) g_srv->stop();
    _exit(0);                      /* 信号里不要跑析构，直接退最干净 */
}

int main() {
    fs::create_directories(SAVES_DIR);
    fs::create_directories(MODS_DIR);
    fs::create_directories(COREMODS_DIR);
    fs::create_directories(TEXTURES_DIR);
    fs::create_directories(TMP_DIR);

    httplib::Server svr;

    // ---- 基础 API ----
    svr.Get("/api/mods", [](const auto&, auto& res) {
        res.set_content(list_mods().dump(), "application/json");
    });
    
    svr.Get("/api/coremods", [](const auto&, auto& res) {
        res.set_content(list_coremods().dump(), "application/json");
    });
    
    svr.Get("/api/hooks", [](const auto&, auto& res) {
        res.set_content(scan_hooks().dump(), "application/json");
    });

    // ---- 材质保存 API ----
    svr.Post("/api/textures", [](const httplib::Request& req, httplib::Response& res) {
        try {
            json body = json::parse(req.body);
            string tf = TEXTURES_DIR + "/custom.json";
            json custom = json::object();
            if (fs::exists(tf)) {
                try { custom = json::parse(read_file(tf)); } catch(...){}
            }
            for (auto& [k, v] : body.items()) {
                if (v.is_null()) custom.erase(k);
                else custom[k] = v;
            }
            write_file(tf, custom.dump(2));
            res.set_content("{\"ok\":true}", "application/json");
        } catch (...) {
            res.status = 500; res.set_content("{\"error\":\"bad json\"}", "application/json");
        }
    });

    // ---- 存档列表 ----
    svr.Get("/api/saves", [](const httplib::Request&, httplib::Response& res) {
        json out = json::array();
        if (fs::exists(SAVES_DIR)) {
            for (const auto& entry : fs::directory_iterator(SAVES_DIR)) {
                if (!entry.is_directory()) continue;
                string wj = entry.path().string() + "/world.json";
                if (fs::exists(wj)) {
                    try { out.push_back(json::parse(read_file(wj))); } catch(...){}
                }
            }
        }
        res.set_content(out.dump(), "application/json");
    });

    svr.Post("/api/saves", [](const httplib::Request& req, httplib::Response& res) {
        try {
            json body = json::parse(req.body);
            string sid = body.value("id", "");
            if (!regex_match(sid, re_save_id)) {
                res.status = 400; res.set_content("{\"error\":\"bad id\"}", "application/json"); return;
            }
            string d = SAVES_DIR + "/" + sid;
            if (fs::exists(d)) {
                res.status = 409; res.set_content("{\"error\":\"exists\"}", "application/json"); return;
            }
            fs::create_directories(d + "/lod");
            fs::create_directories(d + "/data");
            fs::create_directories(d + "/chunks");
            fs::create_directories(d + "/logs");
            
            json meta = body.contains("meta") ? body["meta"] : json::object();
            meta["id"] = sid;
            write_file(d + "/world.json", meta.dump(2));
            res.set_content("{\"id\":\"" + sid + "\"}", "application/json");
        } catch (...) {
            res.status = 400;
        }
    });

    // ---- 整合包 / 地图 打包接口 ----
    // ★ 用内置 miniz 读写 zip，不再依赖系统 zip / unzip 命令。
    //   四个接口的包格式与 server.js / server.py 完全一致。
    svr.Post("/api/import-modpack", handle_import_modpack);
    svr.Post("/api/export-modpack", handle_export_modpack);
    svr.Post("/api/import-map", handle_import_map);
    svr.Post("/api/export-map", handle_export_map);

    // ---- 删除存档 ----
    svr.Delete(R"(/api/saves/([^/]+))", [](const httplib::Request& req, httplib::Response& res) {
        string sid = req.matches[1];
        if (regex_match(sid, re_save_id)) fs::remove_all(SAVES_DIR + "/" + sid);
        res.set_content("{\"ok\":true}", "application/json");
    });

    // ---- 删除存档里的单个文件（箱子/熔炉等方块实体的数据）----
    // 没有这条路由时 deleteSavePath 会 404：挖掉箱子后它的 json 还留在磁盘上，
    // 之后在同一个坐标放新箱子就会"复活"旧内容。
    svr.Delete(R"(/api/saves/([^/]+)/(.+))", [](const httplib::Request& req, httplib::Response& res) {
        string sid = req.matches[1], rel = req.matches[2];
        string base = SAVES_DIR + "/" + sid;
        string fp = base + "/" + rel;
        if (!regex_match(sid, re_save_id) || !is_safe_path(base, fp)) {
            res.status = 403;
            res.set_content("{\"error\":\"forbidden\"}", "application/json");
            return;
        }
        std::error_code ec;
        fs::remove(fp, ec);
        res.set_content("{\"ok\":true}", "application/json");
    });

    // ---- 区块 Bundle 上传 (二进制) ----
    svr.Put(R"(/api/saves/([^/]+)/chunks/bundle)", [](const httplib::Request& req, httplib::Response& res) {
        string sid = req.matches[1];
        if (!regex_match(sid, re_save_id)) { res.status = 400; return; }
        const string& buf = req.body;
        if (buf.size() < 8 || buf.substr(0, 4) != "3DM2") { res.status = 400; return; }

        int count = (unsigned char)buf[6] | ((unsigned char)buf[7] << 8);
        size_t off = 8;
        for (int i = 0; i < count && off < buf.size(); i++) {
            int32_t cx = *(int32_t*)&buf[off]; off += 4;
            int32_t cz = *(int32_t*)&buf[off]; off += 4;
            int dl = buf[off]; off += 1;
            string dim = buf.substr(off, dl); off += dl;
            uint32_t dlen = *(uint32_t*)&buf[off]; off += 4;
            
            string sub = (dim == "overworld") ? "chunks" : "dims/" + dim + "/chunks";
            string dpath = SAVES_DIR + "/" + sid + "/" + sub;
            fs::create_directories(dpath);
            
            string filepath = dpath + "/" + to_string(cx) + "_" + to_string(cz) + ".bin.gz";
            ofstream f(filepath, ios::binary);
            f.write(buf.data() + off, dlen);
            off += dlen;
        }
        res.set_content("{\"ok\":true}", "application/json");
    });

    // ---- 存档文件读写 ----
    svr.Get(R"(/api/saves/([^/]+)/(.+))", [](const httplib::Request& req, httplib::Response& res) {
        string sid = req.matches[1], rel = req.matches[2];
        string fp = SAVES_DIR + "/" + sid + "/" + rel;
        if (is_safe_path(SAVES_DIR + "/" + sid, fp) && fs::exists(fp) && !fs::is_directory(fp)) {
            res.set_content(read_file(fp), "application/octet-stream");
        } else {
            res.status = 404;
        }
    });

    svr.Put(R"(/api/saves/([^/]+)/(.+))", [](const httplib::Request& req, httplib::Response& res) {
        string sid = req.matches[1], rel = req.matches[2];
        string fp = SAVES_DIR + "/" + sid + "/" + rel;
        if (is_safe_path(SAVES_DIR + "/" + sid, fp)) {
            write_file(fp, req.body);
            res.set_content("{\"ok\":true}", "application/json");
        } else {
            res.status = 403;
        }
    });

    // ---- 动态核心文件与 Mixin 注入 (src) ----
    svr.Get(R"(/src/(.*))", [](const httplib::Request& req, httplib::Response& res) {
        string rel = "src/" + req.matches[1].str();
        if (fs::exists(rel) && !fs::is_directory(rel)) {
            string content = read_file(rel);
            if (rel.find(".js") != string::npos) {
                content = inject_js(content, rel);
                res.set_content(content, "text/javascript; charset=utf-8");
            } else {
                res.set_content(content, mime_of(rel));   // ★ 按扩展名给正确 MIME（css/svg/png…）
            }
        } else {
            res.status = 404;
        }
    });

    // ---- 静态资源 (coremods / mods / 根目录) ----
    svr.Get(R"(/coremods/(.*))", [](const httplib::Request& req, httplib::Response& res) {
        string fp = COREMODS_DIR + "/" + req.matches[1].str();
        if (fs::exists(fp) && !fs::is_directory(fp)) {
            res.set_content(read_file(fp), mime_of(fp));
        } else res.status = 404;
    });

    svr.Get(R"(/mods/(.*))", [](const httplib::Request& req, httplib::Response& res) {
        string fp = MODS_DIR + "/" + req.matches[1].str();
        if (fs::exists(fp) && !fs::is_directory(fp)) {
            res.set_content(read_file(fp), mime_of(fp));   // ★ .js 必须是 text/javascript，否则 import() 被拒
        } else res.status = 404;
    });

    // ---- index.html 劫持 ----
    svr.Get("/", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(process_index(), "text/html; charset=utf-8");
    });
    svr.Get("/index.html", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(process_index(), "text/html; charset=utf-8");
    });

    // ---- 兜底静态文件 ----
    svr.Get("/(.*)", [](const httplib::Request& req, httplib::Response& res) {
        string rel = req.matches[1].str();
        if (fs::exists(rel) && !fs::is_directory(rel)) {
            res.set_content(read_file(rel), mime_of(rel));
        } else {
            res.status = 404;
        }
    });

    int port = 8080;
    if (const char* env_p = std::getenv("PORT")) port = std::stoi(env_p);
    
    g_srv = &svr;
    std::signal(SIGINT,  _on_term_signal);
    std::signal(SIGTERM, _on_term_signal);
    std::signal(SIGHUP,  _on_term_signal);

    cout << "  ✔ C++ 服务器启动: http://0.0.0.0:" << port << "  (pid " << getpid() << ")" << endl;
    cout << "    saves: " << fs::absolute(SAVES_DIR) << endl;
    cout << "    mods : " << fs::absolute(MODS_DIR) << endl;

    /* ★ httplib 已经设了 SO_REUSEADDR，所以 TIME_WAIT 不会挡路；
       这里 listen 返回 false 只有一个可能：端口被一个活着的进程占着。 */
    if (!svr.listen("0.0.0.0", port)) {
        cerr << "\n  ✘ 端口 " << port << " 已被占用，启动失败" << endl;
        cerr << "     一键清端口:   bash stop.sh " << port << endl;
        cerr << "     换端口:       PORT=8081 bash start.sh cpp" << endl;
        return 1;
    }
    return 0;
}