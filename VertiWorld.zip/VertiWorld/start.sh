#!/usr/bin/env bash

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

LAN_IP=""
if command -v hostname >/dev/null 2>&1; then
  LAN_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
fi
if [ -z "$LAN_IP" ] && command -v ipconfig >/dev/null 2>&1; then
  LAN_IP=$(ipconfig getifaddr en0 2>/dev/null || true)
fi

show_info() {
    local port=$1
    local type=$2
    echo "================================"
    echo "  深入世界 VertiWorld 本地服务器 ($type)"
    echo "================================"
    echo "  端口:    $port"
    echo "  本机:    http://localhost:$port"
    [ -n "$LAN_IP" ] && echo "  局域网:  http://$LAN_IP:$port   ← 手机用这个"
    echo "================================"
    echo ""
}

start_node() {
    local port=${1:-8080}
    if ! command -v node >/dev/null 2>&1; then echo "✘ 未安装 Node.js"; exit 1; fi
    show_info $port "Node.js"
    PORT="$port" exec node "$DIR/server.js"
}

start_python() {
    local port=${1:-8080}
    if ! command -v python3 >/dev/null 2>&1; then echo "✘ 未安装 Python"; exit 1; fi
    show_info $port "Python"
    PORT="$port" exec python3 "$DIR/server.py"
}

start_cpp() {
    local port=${1:-8080}
    local exe="$HOME/3dmc_server_cpp"
    
    # 兼容旧版本直接编译在目录里的情况
    if [ ! -f "$exe" ] && [ -f "$DIR/server_cpp" ]; then
        exe="$DIR/server_cpp"
    fi
    
    if [ ! -f "$exe" ]; then
        echo "✘ 找不到 C++ 程序，请先运行 ./build_cpp.sh 编译"
        exit 1
    fi

    # server.cpp 比二进制新 → 可能是旧版（不支持导入导出）
    if [ "$exe" -ot "$DIR/server.cpp" ]; then
        echo "⚠ server.cpp 已更新，建议先运行 ./build_cpp.sh 重新编译（旧版 C++ 服务端不支持导入导出）"
        sleep 2
    fi

    show_info $port "C++ 原生"
    PORT="$port" exec "$exe"
}

show_menu() {
    echo "================================"
    echo "  深入世界 VertiWorld 服务端启动器"
    echo "================================"
    echo "  1) C++ 原生服务器 (性能最好 · 支持导入导出)"
    echo "  2) Node.js 服务器 (功能最全)"
    echo "  3) Python 服务器 (零依赖)"
    echo "  4) 停止服务器（释放端口 · 清理残留进程）"
    echo "  0) 退出"
    echo "================================"
    read -p "请选择 [0-4]: " choice
    
    if [ "$choice" = "0" ]; then echo "已退出"; exit 0; fi
    if [ "$choice" = "4" ]; then
        read -p "要释放的端口 (直接回车默认 8080): " spport
        bash "$DIR/stop.sh" "${spport:-8080}"
        exit 0
    fi
    if [[ ! "$choice" =~ ^[1-3]$ ]]; then echo "无效选择，请输入 1, 2, 3 或 4"; exit 1; fi
    
    read -p "请输入端口 (直接回车默认 8080): " port
    port=${port:-8080}

    case $choice in
        1) start_cpp $port ;;
        2) start_node $port ;;
        3) start_python $port ;;
    esac
}

# 入口逻辑
if [ $# -eq 0 ]; then
    show_menu
else
    TYPE=$1
    PORT=${2:-8080}
    case $TYPE in
        cpp) start_cpp $PORT ;;
        node) start_node $PORT ;;
        python) start_python $PORT ;;
        stop) bash "$DIR/stop.sh" "$PORT" ;;
        *) echo "未知类型: $TYPE"; echo "用法: bash start.sh [cpp|node|python|stop] [port]"; exit 1 ;;
    esac
fi