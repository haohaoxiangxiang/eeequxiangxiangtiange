/* ============================================================
   cloud-pass.js —— 体积云的离屏渲染 + 时域累积（TAA）
   ------------------------------------------------------------
   单帧 raymarching 的抖动噪点无法靠调参消掉，光影包的做法是
   低分辨率 + 多帧累积。这里实现同一条路子：

     1. 主场景 → mainRT（带 depthTexture）
     2. 云 → cloudRT（半分辨率，用 mainRT 的深度做地形遮挡）
     3. cloudRT + 上一帧历史 → 重投影混合 → 新的历史
     4. mainRT + 历史 → 线性转 sRGB → 屏幕

   云画质不是 ultra 时整条链路完全跳过，零额外开销。
   ============================================================ */

import * as THREE from 'three';

const QUAD_VS = `
  varying vec2 vUv;
  void main(){
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`;

const FS_ACCUM = `
  precision highp float;
  uniform sampler2D uCur, uHist;
  uniform mat4 uInvViewProj, uPrevViewProj;
  uniform vec3 uCamPos;
  uniform float uCloudDist, uBlend;
  uniform vec2 uResolution;
  varying vec2 vUv;

  void main(){
    vec4 cur = texture2D(uCur, vUv);

    /* 用当前帧的逆投影重建视线，取云层中段一点，投到上一帧 */
    vec4 ndc = vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
    vec4 wp = uInvViewProj * ndc;
    wp.xyz /= wp.w;
    vec3 dir = normalize(wp.xyz - uCamPos);
    vec3 p = uCamPos + dir * uCloudDist;

    vec4 pc = uPrevViewProj * vec4(p, 1.0);
    vec2 puv = pc.xy / max(pc.w, 1e-4) * 0.5 + 0.5;

    vec4 hist = cur;
    if (pc.w > 0.0 && puv.x > 0.0 && puv.x < 1.0 && puv.y > 0.0 && puv.y < 1.0){
      hist = texture2D(uHist, puv);
    }

    /* 差异大的地方（云在动、新出现的云）多用当前帧，抑制拖影 */
    float diff = length(cur.rgb - hist.rgb) + abs(cur.a - hist.a);
    float k = clamp(uBlend + diff * 2.0, uBlend, 0.9);

    gl_FragColor = mix(hist, cur, k);
  }
`;

const FS_COMP = `
  precision highp float;
  uniform sampler2D uScene, uCloud;
  varying vec2 vUv;

  vec3 toSRGB(vec3 c){
    vec3 lo = c * 12.92;
    vec3 hi = 1.055 * pow(max(c, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055;
    return mix(hi, lo, step(c, vec3(0.0031308)));
  }

  void main(){
    vec4 base = texture2D(uScene, vUv);
    vec4 cl = texture2D(uCloud, vUv);
    vec3 c = mix(base.rgb, cl.rgb, cl.a);
    gl_FragColor = vec4(toSRGB(c), 1.0);
  }
`;

let inited = false;
let mainRT = null;
let cloudRT = null;
let histRT = [null, null];
let histIdx = 0;
let hasHist = false;
let W = 0, H = 0;

let volClouds = null, volMat = null;
let cloudScene = null;
let accumScene = null, accumMat = null;
let compScene = null, compMat = null;

const quadCam = new THREE.Camera();
const QUAD_GEO = new THREE.PlaneGeometry(2, 2);
const _size = new THREE.Vector2();
const _fwd = new THREE.Vector3();
const _vp = new THREE.Matrix4();
const _inv = new THREE.Matrix4();
const prevVP = new THREE.Matrix4();
let prevValid = false;

const _clearCol = new THREE.Color();

function _makeQuad(fs, uniforms){
  const mat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: QUAD_VS,
    fragmentShader: fs,
    depthTest: false,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(QUAD_GEO, mat);
  mesh.frustumCulled = false;
  const s = new THREE.Scene();
  s.add(mesh);
  return s;
}

export function initCloudPass(clouds, mat){
  volClouds = clouds;
  volMat = mat;

  /* 云从主场景搬到独立场景：主场景不再绘制它 */
  cloudScene = new THREE.Scene();
  cloudScene.add(clouds);

  accumMat = new THREE.ShaderMaterial({
    uniforms: {
      uCur: { value: null },
      uHist: { value: null },
      uInvViewProj: { value: new THREE.Matrix4() },
      uPrevViewProj: { value: new THREE.Matrix4() },
      uCamPos: { value: new THREE.Vector3() },
      uCloudDist: { value: 270 },
      uBlend: { value: 0.15 },
      uResolution: { value: new THREE.Vector2(1, 1) },
    },
    vertexShader: QUAD_VS,
    fragmentShader: FS_ACCUM,
    depthTest: false,
    depthWrite: false,
  });
  accumScene = new THREE.Scene();
  const am = new THREE.Mesh(QUAD_GEO, accumMat);
  am.frustumCulled = false;
  accumScene.add(am);

  compMat = new THREE.ShaderMaterial({
    uniforms: {
      uScene: { value: null },
      uCloud: { value: null },
    },
    vertexShader: QUAD_VS,
    fragmentShader: FS_COMP,
    depthTest: false,
    depthWrite: false,
  });
  compScene = new THREE.Scene();
  const cm = new THREE.Mesh(QUAD_GEO, compMat);
  cm.frustumCulled = false;
  compScene.add(cm);

  inited = true;
}

function _disposeTargets(){
  if (mainRT){ mainRT.depthTexture && mainRT.depthTexture.dispose(); mainRT.dispose(); }
  if (cloudRT) cloudRT.dispose();
  if (histRT[0]) histRT[0].dispose();
  if (histRT[1]) histRT[1].dispose();
  mainRT = cloudRT = histRT[0] = histRT[1] = null;
}

function _rebuild(w, h){
  _disposeTargets();
  W = w;
  H = h;

  const depth = new THREE.DepthTexture(w, h);
  depth.type = THREE.UnsignedIntType;
  mainRT = new THREE.WebGLRenderTarget(w, h, {
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat,
    type: THREE.UnsignedByteType,
    depthTexture: depth,
    depthBuffer: true,
    stencilBuffer: false,
  });

  const hw = Math.max(1, Math.floor(w * 0.5));
  const hh = Math.max(1, Math.floor(h * 0.5));
  const opt = {
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat,
    type: THREE.UnsignedByteType,
    depthBuffer: false,
    stencilBuffer: false,
  };
  cloudRT = new THREE.WebGLRenderTarget(hw, hh, opt);
  histRT[0] = new THREE.WebGLRenderTarget(hw, hh, opt);
  histRT[1] = new THREE.WebGLRenderTarget(hw, hh, opt);

  hasHist = false;
  prevValid = false;
}

/** 是否该走离屏链路 */
export function cloudPassActive(){
  return inited && volClouds && volClouds.visible;
}

/**
 * 每帧渲染入口。云为 ultra 时走「主场景 RT → 云半分辨率 → 时域累积 → 合成」，
 * 否则直接按原样渲染。
 */
export function renderFrame(renderer, scene, camera){
  if (!inited || !volClouds.visible){
    renderer.render(scene, camera);
    return;
  }

  renderer.getDrawingBufferSize(_size);
  const w = Math.max(2, Math.floor(_size.x));
  const h = Math.max(2, Math.floor(_size.y));
  if (!mainRT || w !== W || h !== H) _rebuild(w, h);

  /* ---- 1. 主场景（不含云） ---- */
  renderer.setRenderTarget(mainRT);
  renderer.clear();
  renderer.render(scene, camera);

  /* ---- 2. 云：半分辨率，用主场景深度做遮挡 ---- */
  const u = volMat.uniforms;
  u.uSceneDepth.value = mainRT.depthTexture;
  u.uUseDepth.value = true;
  u.uResolution.value.set(W * 0.5, H * 0.5);
  u.uNear.value = camera.near;
  u.uFar.value = camera.far;
  camera.getWorldDirection(_fwd);
  u.uCamFwd.value.copy(_fwd);

  renderer.getClearColor(_clearCol);
  const prevAlpha = renderer.getClearAlpha();
  renderer.setClearColor(0x000000, 0);
  renderer.setRenderTarget(cloudRT);
  renderer.clear();
  renderer.render(cloudScene, camera);
  renderer.setClearColor(_clearCol, prevAlpha);

  /* ---- 3. 时域累积（重投影到上一帧） ---- */
  _vp.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
  _inv.copy(_vp).invert();

  const dst = histRT[histIdx];
  const src = histRT[1 - histIdx];

  const au = accumMat.uniforms;
  au.uCur.value = cloudRT.texture;
  au.uHist.value = src.texture;
  au.uInvViewProj.value.copy(_inv);
  au.uPrevViewProj.value.copy(prevValid ? prevVP : _vp);
  au.uCamPos.value.copy(camera.position);
  au.uResolution.value.set(W * 0.5, H * 0.5);
  au.uBlend.value = hasHist ? 0.15 : 1.0;

  renderer.setRenderTarget(dst);
  renderer.render(accumScene, quadCam);

  prevVP.copy(_vp);
  prevValid = true;
  hasHist = true;
  histIdx = 1 - histIdx;

  /* ---- 4. 合成到屏幕（线性 → sRGB） ---- */
  compMat.uniforms.uScene.value = mainRT.texture;
  compMat.uniforms.uCloud.value = dst.texture;
  renderer.setRenderTarget(null);
  renderer.render(compScene, quadCam);
}
