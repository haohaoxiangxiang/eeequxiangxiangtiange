/* ============================================================
   chunk-debug.js —— 区块边框可视化
   ============================================================ */

import * as THREE from 'three';
import { scene } from './render-core.js';
import { CS } from './../core/engine-core.js';

let _enabled = false;
let _lastCx = null, _lastCz = null, _lastR = null, _lastY = null;

const _group = new THREE.Group();
_group.name = '__chunk_debug__';
_group.visible = false;
scene.add(_group);

const _matNormal = new THREE.LineBasicMaterial({
  color: 0x60c8ff, transparent: true, opacity: 0.28,
  depthWrite: false, depthTest: true,
});
const _matPlayer = new THREE.LineBasicMaterial({
  color: 0xffff60, transparent: true, opacity: 0.9,
  depthWrite: false, depthTest: true,
});

function _clearGroup(){
  for (let i = _group.children.length - 1; i >= 0; i--){
    const m = _group.children[i];
    _group.remove(m);
    if (m.geometry) m.geometry.dispose();
  }
}

function _boxPoints(cx, cz, y0, y1){
  const x0 = cx * CS, x1 = x0 + CS;
  const z0 = cz * CS, z1 = z0 + CS;
  return [
    x0, y0, z0,  x1, y0, z0,
    x1, y0, z0,  x1, y0, z1,
    x1, y0, z1,  x0, y0, z1,
    x0, y0, z1,  x0, y0, z0,
    x0, y1, z0,  x1, y1, z0,
    x1, y1, z0,  x1, y1, z1,
    x1, y1, z1,  x0, y1, z1,
    x0, y1, z1,  x0, y1, z0,
    x0, y0, z0,  x0, y1, z0,
    x1, y0, z0,  x1, y1, z0,
    x1, y0, z1,  x1, y1, z1,
    x0, y0, z1,  x0, y1, z1,
  ];
}

function _rebuild(playerPos, renderDist){
  _clearGroup();
  if (!playerPos) return;

  const pcx = Math.floor(playerPos.x / CS);
  const pcz = Math.floor(playerPos.z / CS);
  const R = Math.max(1, Math.min(16, renderDist | 0));

  const y0 = Math.max(-20, Math.floor(playerPos.y) - 40);
  const y1 = Math.min(400, Math.floor(playerPos.y) + 60);

  const normalPts = [];
  for (let dx = -R; dx <= R; dx++){
    for (let dz = -R; dz <= R; dz++){
      if (dx === 0 && dz === 0) continue;
      const pts = _boxPoints(pcx + dx, pcz + dz, y0, y1);
      for (let i = 0; i < pts.length; i++) normalPts.push(pts[i]);
    }
  }

  if (normalPts.length > 0){
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(normalPts), 3));
    _group.add(new THREE.LineSegments(geo, _matNormal));
  }

  const playerPts = _boxPoints(pcx, pcz, y0, y1);
  const pgeo = new THREE.BufferGeometry();
  pgeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(playerPts), 3));
  _group.add(new THREE.LineSegments(pgeo, _matPlayer));
}

export function setChunkDebugEnabled(on){
  _enabled = !!on;
  _group.visible = _enabled;
  if (!_enabled){
    _clearGroup();
    _lastCx = null;
    _lastCz = null;
    _lastR = null;
    _lastY = null;
  }
}

export function isChunkDebugEnabled(){ return _enabled; }

export function updateChunkDebug(playerPos, renderDist){
  if (!_enabled || !playerPos) return;

  const pcx = Math.floor(playerPos.x / CS);
  const pcz = Math.floor(playerPos.z / CS);
  const R = Math.max(1, Math.min(16, renderDist | 0));
  const py = Math.floor(playerPos.y);

  if (pcx === _lastCx && pcz === _lastCz && R === _lastR &&
      Math.abs(py - (_lastY || 0)) < 20){
    return;
  }

  _lastCx = pcx;
  _lastCz = pcz;
  _lastR = R;
  _lastY = py;
  _rebuild(playerPos, R);
}
