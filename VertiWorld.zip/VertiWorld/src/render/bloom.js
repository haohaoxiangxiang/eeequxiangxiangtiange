/* ============================================================
   bloom.js —— 屏幕空间泛光（bloom）后处理
   ------------------------------------------------------------
   自包含实现，不依赖 three/examples：
     ① 场景渲染到线性 HDR RT（优先 HalfFloat，不支持则 8bit）
     ② 软阈值提取亮部（只在 1/2 分辨率上做）
     ③ 2~3 级可分离高斯模糊（1/2、1/4、1/8）
     ④ 与原始场景合成，再自己做 sRGB 编码输出到画布

   ★ 只有开启时才创建 RT、才走 RT 路径；关闭时直接
     renderer.render(scene, camera)，零额外开销。
   ★ 渲染到 RT 时 three 会强制线性输出（不做 sRGB 编码），
     所以合成 pass 必须自己做 linear → sRGB；天空穹顶是自定义
     shader，让它按 uLinearize 把「显示值」预转回线性，
     这样开关 bloom 时天空颜色保持一致。
   ============================================================ */

import * as THREE from '../vendor/three.module.js';
import { renderer, scene, camera } from './render-core.js';
import { IS_TOUCH } from '../core/runtime.js';

const KEY = '3dmc_bloom';
const MODES = ['off', 'low', 'high'];

function _readMode(){
  try {
    const v = localStorage.getItem(KEY);
    if (MODES.indexOf(v) >= 0) return v;
  } catch(e){}
  /* 低端触屏默认关，桌面默认低档 */
  return IS_TOUCH ? 'off' : 'low';
}

let mode = _readMode();

export function getBloomMode(){ return mode; }
export function isBloomActive(){ return mode !== 'off' && !_broken; }

/* ============================================================
   ★ 体积云图层（由 sky.js 每帧推过来）
   ------------------------------------------------------------
   以前 ultra 云是在天空穹顶的着色器里合成的，而穹顶只画在
   "没有几何的像素"上 —— 所以云永远在所有东西后面：
   飞到云层以上看山谷、或者一朵云本该挡在山前面时，全都不对。

   现在改成：sky.js 只负责把云渲进半分辨率 RT（+TAA），
   合成交给这个最终 pass，并用场景深度做遮挡判断。
   代价是 bloom 必须开着；bloom 关掉时 sky.js 会自己退回天空穹顶合成。
   ============================================================ */
let _cloudTex = null;
let _cloudOn = false;
let _cloudBottom = 200;
let _cloudTop = 340;

export function setCloudLayer(o){
  if (!o || !o.tex){
    _cloudOn = false;
    _cloudTex = null;
    return;
  }
  _cloudTex = o.tex;
  _cloudOn = true;
  _cloudBottom = o.bottom;
  _cloudTop = o.top;
}

export function setBloomMode(m){
  mode = MODES.indexOf(m) >= 0 ? m : 'off';
  _broken = false;
  try { localStorage.setItem(KEY, mode); } catch(e){}
  _dispose();
}

/* ============================================================
   全屏 pass 基础
   ============================================================ */
const _passScene = new THREE.Scene();
const _passCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const _quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), null);
_quad.frustumCulled = false;
_passScene.add(_quad);

const VERT = `
  varying vec2 vUv;
  void main(){
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }`;

/* ---- 亮部提取（软阈值，参考 UnrealBloomPass 的做法） ---- */
const _brightMat = new THREE.ShaderMaterial({
  uniforms: {
    tDiffuse: { value: null },
    threshold: { value: 0.85 },
    knee: { value: 0.5 },
  },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float threshold;
    uniform float knee;
    varying vec2 vUv;
    void main(){
      vec3 c = texture2D(tDiffuse, vUv).rgb;
      float br = max(c.r, max(c.g, c.b));
      float soft = clamp(br - threshold + knee, 0.0, 2.0 * knee);
      soft = soft * soft / (4.0 * knee + 1e-5);
      float contrib = max(soft, br - threshold) / max(br, 1e-5);
      gl_FragColor = vec4(c * contrib, 1.0);
    }`,
  depthTest: false, depthWrite: false,
});

/* ---- 9-tap 可分离高斯 ---- */
const _blurMat = new THREE.ShaderMaterial({
  uniforms: {
    tDiffuse: { value: null },
    direction: { value: new THREE.Vector2() },
  },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform vec2 direction;
    varying vec2 vUv;
    void main(){
      vec3 c = texture2D(tDiffuse, vUv).rgb * 0.2270270270;
      c += texture2D(tDiffuse, vUv + direction * 1.0).rgb * 0.1945945946;
      c += texture2D(tDiffuse, vUv - direction * 1.0).rgb * 0.1945945946;
      c += texture2D(tDiffuse, vUv + direction * 2.0).rgb * 0.1216216216;
      c += texture2D(tDiffuse, vUv - direction * 2.0).rgb * 0.1216216216;
      c += texture2D(tDiffuse, vUv + direction * 3.0).rgb * 0.0540540541;
      c += texture2D(tDiffuse, vUv - direction * 3.0).rgb * 0.0540540541;
      c += texture2D(tDiffuse, vUv + direction * 4.0).rgb * 0.0162162162;
      c += texture2D(tDiffuse, vUv - direction * 4.0).rgb * 0.0162162162;
      gl_FragColor = vec4(c, 1.0);
    }`,
  depthTest: false, depthWrite: false,
});

/* ---- 降采样拷贝 ---- */
const _copyMat = new THREE.ShaderMaterial({
  uniforms: { tDiffuse: { value: null } },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    varying vec2 vUv;
    void main(){ gl_FragColor = vec4(texture2D(tDiffuse, vUv).rgb, 1.0); }`,
  depthTest: false, depthWrite: false,
});

/* ============================================================
   ★ SSAO（屏幕空间环境光遮蔽，半分辨率）
   ------------------------------------------------------------
   为什么需要它：方块材质的顶点色里烘焙了体素 AO（夹角变暗），
   但**动态光（火把）走的是"未烘焙反照率"那条路** —— 那段代码把
   顶点色按自身最大通道归一化（_tint = vColor / max(vColor)），
   而 AO、面明暗、天光都是同时乘在 RGB 三通道上的标量，会被精确
   约掉。结果是火把照亮的面一片平，墙角缝隙不变暗，没有立体感。
   SSAO 从深度重建法线、在屏幕空间算接触遮蔽，再乘到最终颜色上，
   于是不管光来自太阳、方块光还是火把，墙角都会自然变暗。

   成本控制：
     · 半分辨率 RT（像素数 1/4）
     · 8 次深度采样（内外两圈）+ 3×3 深度感知模糊
     · 只复用已有的场景深度纹理（云遮挡本来就在用它），不需 G-buffer
     · 只在泛光开启时可用：只有那条链路才有场景 RT 和深度纹理
   ============================================================ */
const _ssaoMat = new THREE.ShaderMaterial({
  uniforms: {
    tDepth:   { value: null },
    /* ★ 不用逆投影矩阵重建视空间坐标：每个采样点一次 mat4×vec4 在半分辨率
       下有近千万次乘法。透视相机的视线方向对 uv 是线性的，
       直接给 tan(halfFov) 就能算出来，省掉矩阵乘。 */
    uTan:     { value: new THREE.Vector2(0.7, 0.4) },  /* 半分辨率下的 tanX / tanY */
    uPix:     { value: new THREE.Vector2(1 / 1280, 1 / 720) },  /* 深度图纹素 */
    uNear:    { value: 0.1 },
    uFar:     { value: 1000 },
    uRadius:  { value: 2.0 },                          /* 视空间半径（方块） */
  },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tDepth;
    uniform vec2 uTan;
    uniform vec2 uPix;
    uniform float uNear, uFar, uRadius;
    varying vec2 vUv;

    /* 窗口深度 [0,1] → 视空间 z（负数，朝前） */
    float viewZ(float d){
      return (uNear * uFar) / ((uFar - uNear) * d - uFar);
    }
    /* uv + 窗口深度 → 视空间坐标。
       透视投影下视线方向对 uv 线性：dir = ((uv*2-1)*tan, -1)，
       视空间位置 = dir * t，其中 t = -viewZ。 */
    vec3 viewPosAt(vec2 uv, float d){
      float t = -viewZ(d);
      return vec3((uv * 2.0 - 1.0) * uTan * t, -t);
    }

    void main(){
      float d = texture2D(tDepth, vUv).x;
      /* 天空：天空穹顶 depthWrite:false，这里恒为 1.0 → 不做遮蔽 */
      if (d >= 0.9999){ gl_FragColor = vec4(1.0); return; }

      vec3 p = viewPosAt(vUv, d);

      /* 由深度导数重建法线：没有 G-buffer 也能拿到朝向。
         取相邻两像素的视空间位置做叉乘。 */
      float dxD = texture2D(tDepth, vUv + vec2(uPix.x, 0.0)).x;
      float dyD = texture2D(tDepth, vUv + vec2(0.0, uPix.y)).x;
      vec3 px = viewPosAt(vUv + vec2(uPix.x, 0.0), dxD);
      vec3 py = viewPosAt(vUv + vec2(0.0, uPix.y), dyD);
      vec3 n = cross(px - p, py - p);
      float nl = length(n);
      /* 相邻像素深度跳变（边缘）时叉乘会退化，直接放过 */
      if (nl < 1e-6){ gl_FragColor = vec4(1.0); return; }
      n /= nl;

      /* 把视空间半径换成 UV 半径：视空间 dx 在深度 t 处对应
         ndc.x = dx/(t*tanX)，再 /2 得到 uv。 */
      float t0 = -viewZ(d);
      float radUv = 0.5 * uRadius / (max(t0, 0.1) * uTan.x);
      radUv = clamp(radUv, 0.0, 0.2);

      /* 每个像素随机旋转采样盘，打散条带（IGN 时钟噪点，不需要纹理） */
      float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
      float ang = ign * 6.2831853;

      float occ = 0.0;
      /* ★ 8 个采样点：内圈 4 个 + 外圈 4 个。
         写成循环 + 三角函数而不是常量数组 —— GLSL ES 1.00 不支持
         数组初始化器，three 的 ShaderMaterial 默认按 GLSL1 编译。 */
      for (int i = 0; i < 8; i++){
        float a = (float(i) + 0.5) * 0.7853981634 + ang;
        float rr = (i < 4) ? 0.45 : 0.85;
        vec2 suv = vUv + vec2(cos(a), sin(a)) * (rr * radUv);

        float sd = texture2D(tDepth, suv).x;
        if (sd >= 0.9999) continue;              /* 采样到天空，忽略 */

        vec3 sp = viewPosAt(suv, sd);
        vec3 diff = sp - p;
        float dist = length(diff);
        if (dist < 1e-4 || dist > uRadius) continue;

        /* 邻居比自己更靠前（朝相机侧）才算被挡住 */
        float ndl = max(dot(n, diff / dist), 0.0);
        /* 距离越远越不可信，靠近半径上限时淡出 */
        float rangeCheck = 1.0 - smoothstep(uRadius * 0.55, uRadius, dist);
        occ += ndl * rangeCheck;
      }

      float ao = 1.0 - occ * 0.125;              /* /8 个采样 */
      gl_FragColor = vec4(clamp(ao, 0.0, 1.0));
    }`,
  depthTest: false, depthWrite: false,
});

/* ---- AO 去噪：3×3 模糊，权重按「线性深度差」衰减，
        避免把物体轮廓两侧的 AO 糊到背景上（那会出现黑边） ---- */
const _ssaoBlurMat = new THREE.ShaderMaterial({
  uniforms: {
    tAO:    { value: null },
    tDepth: { value: null },
    uTexel: { value: new THREE.Vector2(1 / 640, 1 / 360) },  /* 1/AO 尺寸 */
    uNear:  { value: 0.1 },
    uFar:   { value: 1000 },
  },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tAO;
    uniform sampler2D tDepth;
    uniform vec2 uTexel;
    uniform float uNear, uFar;
    varying vec2 vUv;

    float linZ(float d){
      return (uNear * uFar) / ((uFar - uNear) * d - uFar);
    }

    void main(){
      float d0 = texture2D(tDepth, vUv).x;
      if (d0 >= 0.9999){ gl_FragColor = vec4(1.0); return; }
      float z0 = linZ(d0);

      float sum = 0.0, wsum = 0.0;
      for (int y = -1; y <= 1; y++){
        for (int x = -1; x <= 1; x++){
          vec2 o = vec2(float(x), float(y)) * uTexel;
          float d = texture2D(tDepth, vUv + o).x;
          float a = texture2D(tAO, vUv + o).r;
          /* 深度差 1 格 → 权重约 0.22；差 3 格以上基本不参与 */
          float w = exp(-abs(linZ(d) - z0) * 1.5);
          if (x == 0 && y == 0) w *= 2.0;
          sum += a * w;
          wsum += w;
        }
      }
      gl_FragColor = vec4(sum / max(wsum, 1e-5));
    }`,
  depthTest: false, depthWrite: false,
});

/* ---- 合成：线性场景 + 各级 bloom + 体积云 → sRGB ---- */
const _compMat = new THREE.ShaderMaterial({
  uniforms: {
    tScene: { value: null },
    tB0: { value: null },
    tB1: { value: null },
    tB2: { value: null },
    tCloud: { value: null },
    tDepth: { value: null },
    /* ★ SSAO：半分辨率 AO 结果 + 开关/强度 */
    tAO:        { value: null },
    uAOOn:      { value: 0 },
    uAOStrength:{ value: 0.8 },
    w0: { value: 0.55 },
    w1: { value: 0.30 },
    w2: { value: 0.15 },
    strength: { value: 1.0 },
    /* 云合成用 */
    uCloudOn:    { value: 0 },
    uCloudBottom:{ value: 200 },
    uCloudTop:   { value: 340 },
    uCamPos:     { value: new THREE.Vector3() },
    uCamDir:     { value: new THREE.Vector3(0, 0, -1) },
    uInvViewProj:{ value: new THREE.Matrix4() },
    uCamNear:    { value: 0.1 },
    uCamFar:     { value: 1000 }
  },
  vertexShader: VERT,
  fragmentShader: `
    uniform sampler2D tScene;
    uniform sampler2D tB0;
    uniform sampler2D tB1;
    uniform sampler2D tB2;
    uniform sampler2D tCloud;
    uniform sampler2D tDepth;
    uniform sampler2D tAO;
    uniform float uAOOn, uAOStrength;
    uniform float w0, w1, w2, strength;
    uniform float uCloudOn, uCloudBottom, uCloudTop, uCamNear, uCamFar;
    uniform vec3 uCamPos, uCamDir;
    uniform mat4 uInvViewProj;
    varying vec2 vUv;

    vec3 linearToSRGB(vec3 c){
      c = max(c, vec3(0.0));
      vec3 lo = c * 12.92;
      vec3 hi = 1.055 * pow(c, vec3(0.416666667)) - 0.055;
      return mix(lo, hi, step(vec3(0.0031308), c));
    }
    /* 云 RT 里存的是「显示值」（和天空穹顶的写法保持一致），要转回线性 */
    vec3 srgbToLinear(vec3 c){
      c = max(c, vec3(0.0));
      vec3 lo = c / 12.92;
      vec3 hi = pow((c + 0.055) / 1.055, vec3(2.4));
      return mix(lo, hi, step(vec3(0.04045), c));
    }

    /* 把体积云按深度合成到线性场景上 */
    vec3 compositeClouds(vec3 base){
      if (uCloudOn < 0.5) return base;

      vec4 cc = texture2D(tCloud, vUv);      /* 预乘 alpha，半分辨率 */
      float a = clamp(cc.a, 0.0, 1.0);
      if (a < 0.002) return base;

      /* 1) 场景在这像素上的距离（沿视线轴，来自深度纹理） */
      float d = texture2D(tDepth, vUv).x;
      float viewZ = (uCamNear * uCamFar) / ((uCamFar - uCamNear) * d - uCamFar);
      float sceneAxis = -viewZ;              /* 正的轴向距离 */

      /* 2) 这条视线进入云层的距离 */
      vec4 wp = uInvViewProj * vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
      wp.xyz /= wp.w;
      vec3 dir = normalize(wp.xyz - uCamPos);
      float cloudDist;
      if (abs(dir.y) < 1e-4){
        /* 完全水平：只有相机本来就在层内才可能相交 */
        cloudDist = (uCamPos.y > uCloudBottom && uCamPos.y < uCloudTop) ? 0.0 : -1.0;
      } else {
        float ta = (uCloudBottom - uCamPos.y) / dir.y;
        float tb = (uCloudTop    - uCamPos.y) / dir.y;
        cloudDist = max(min(ta, tb), 0.0);
      }
      if (cloudDist < 0.0 || cloudDist > uCamFar) return base;

      /* 3) 把场景的轴向距离换成和 cloudDist 同一度量（沿视线的欧氏距离） */
      float cosAxis = max(dot(dir, uCamDir), 1e-4);
      float sceneDist = sceneAxis / cosAxis;

      /* 场景比云更近 → 这像素被地形挡住，云不画 */
      if (sceneDist < cloudDist) return base;

      /* 4) 反预乘 → 转线性 → 重新预乘，再叠上去 */
      vec3 cloudLin = srgbToLinear(cc.rgb / max(a, 1e-4)) * a;
      return base * (1.0 - a) + cloudLin;
    }

    void main(){
      vec3 base = texture2D(tScene, vUv).rgb;
      /* ★ SSAO：只压暗几何表面，天空（深度≈1）不参与。
         乘在「云合成之前、叠加 bloom 之前」：
           · 云是远处天空，本来 AO 就是 1，放前面更安全；
           · bloom 是发光溢出，不该被环境遮蔽压暗。 */
      if (uAOOn > 0.5){
        float dz = texture2D(tDepth, vUv).x;
        if (dz < 0.9999){
          float ao = texture2D(tAO, vUv).r;
          base *= mix(1.0, ao, uAOStrength);
        }
      }
      /* ★ 云先合成（带深度遮挡），再叠加 bloom：
         云本身进不了 bloom 的亮部提取（提取发生在场景 RT 上），
         但会被叠在 bloom 之上，观感上没问题，也省一个 pass。 */
      base = compositeClouds(base);
      vec3 b = texture2D(tB0, vUv).rgb * w0
             + texture2D(tB1, vUv).rgb * w1
             + texture2D(tB2, vUv).rgb * w2;
      vec3 c = clamp(base + b * strength, 0.0, 1.0);
      gl_FragColor = vec4(linearToSRGB(c), 1.0);
    }`,
  depthTest: false, depthWrite: false,
});

/* ============================================================
   RT 管理
   ============================================================ */
let _sceneRT = null;
let _brightRT = null;
let _aoRT = null;
let _aoBlurRT = null;
let _levels = [];          /* [{ a, b, w, h }, ...] */
let _texType = null;
let _rtW = 0, _rtH = 0, _rtMode = '';
let _broken = false;

/* ============================================================
   SSAO 开关 / 强度
   ------------------------------------------------------------
   半分辨率、8 次深度采样，实测开销很小，但低端机仍然可以关掉。
   设置存在 localStorage，和泛光一样跟着存档走。
   ============================================================ */
const SSAO_KEY = '3dmc_ssao';
const SSAO_STRENGTH = { low: 0.65, high: 0.85 };
let _aoOn = (function(){
  try {
    const v = localStorage.getItem(SSAO_KEY);
    if (v === 'off' || v === '0') return false;
    if (v === 'on' || v === '1') return true;
  } catch(e){}
  return true;              /* 默认开：这是火焰光立体感的主要来源 */
})();
let _aoStrength = SSAO_STRENGTH.high;

export function isSSAOEnabled(){ return _aoOn; }
export function getSSAOStrength(){ return _aoStrength; }
export function setSSAOEnabled(on){
  _aoOn = !!on;
  try { localStorage.setItem(SSAO_KEY, _aoOn ? 'on' : 'off'); } catch(e){}
  /* 强制下次重建 RT（关掉时把半分辨率 RT 释放掉省显存） */
  _dispose();
  return _aoOn;
}
export function setSSAOStrength(v){
  const n = Number(v);
  if (!isFinite(n)) return _aoStrength;
  _aoStrength = Math.max(0, Math.min(1.5, n));
  return _aoStrength;
}

function _pickTexType(){
  if (_texType) return _texType;
  _texType = THREE.UnsignedByteType;
  try {
    if (renderer.capabilities.isWebGL2){
      const ext = renderer.extensions;
      if (ext.has('EXT_color_buffer_float') || ext.has('EXT_color_buffer_half_float')){
        _texType = THREE.HalfFloatType;
      }
    }
  } catch(e){}
  return _texType;
}

function _makeRT(w, h, depth){
  const rt = new THREE.WebGLRenderTarget(Math.max(1, w), Math.max(1, h), {
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat,
    type: _pickTexType(),
    depthBuffer: !!depth,
    stencilBuffer: false,
    generateMipmaps: false,
  });
  rt.texture.colorSpace = THREE.NoColorSpace;
  /* ★ 场景 RT 挂一张深度纹理，给云做遮挡判断用：
     云画在天空穹顶里时永远是"背景"，没有深度就不知道这个像素
     后面其实是一座山。挂上深度之后，云可以在最终合成里按
     "场景距离 < 云层距离 → 被挡住"来剔除。 */
  if (depth){
    const dt = new THREE.DepthTexture(Math.max(1, w), Math.max(1, h));
    dt.type = THREE.UnsignedIntType;
    rt.depthTexture = dt;
  }
  return rt;
}

/* SSAO 用的轻量 RT：AO 只有 0~1 单通道信息，
   用 UnsignedByte 就够（半浮点在这尺寸上纯属浪费带宽）。 */
function _makeAORT(w, h){
  const rt = new THREE.WebGLRenderTarget(Math.max(1, w), Math.max(1, h), {
    minFilter: THREE.LinearFilter,   /* 合成时要上采样回全分辨率 */
    magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat,
    type: THREE.UnsignedByteType,
    depthBuffer: false,
    stencilBuffer: false,
    generateMipmaps: false,
  });
  rt.texture.colorSpace = THREE.NoColorSpace;
  return rt;
}

function _dispose(){
  if (_sceneRT){
    if (_sceneRT.depthTexture){ _sceneRT.depthTexture.dispose(); _sceneRT.depthTexture = null; }
    _sceneRT.dispose();
    _sceneRT = null;
  }
  if (_brightRT){ _brightRT.dispose(); _brightRT = null; }
  if (_aoRT){ _aoRT.dispose(); _aoRT = null; }
  if (_aoBlurRT){ _aoBlurRT.dispose(); _aoBlurRT = null; }
  for (let i = 0; i < _levels.length; i++){
    _levels[i].a.dispose();
    _levels[i].b.dispose();
  }
  _levels.length = 0;
  _rtW = _rtH = 0;
  _rtMode = '';
}

function _drawSize(){
  const v = new THREE.Vector2();
  try { renderer.getDrawingBufferSize(v); } catch(e){ v.set(1, 1); }
  return v;
}

function _ensureRTs(){
  const size = _drawSize();
  const w = Math.max(2, Math.floor(size.x));
  const h = Math.max(2, Math.floor(size.y));
  const nLevels = (mode === 'high') ? 3 : 2;

  if (_sceneRT && _rtW === w && _rtH === h && _rtMode === mode && _levels.length === nLevels){
    return;
  }
  _dispose();

  _rtW = w; _rtH = h; _rtMode = mode;
  _sceneRT = _makeRT(w, h, true);
  _brightRT = _makeRT(Math.ceil(w / 2), Math.ceil(h / 2), false);

  /* ★ SSAO 半分辨率 RT（关掉时不分配，省显存） */
  if (_aoOn){
    const aw = Math.max(1, w >> 1);
    const ah = Math.max(1, h >> 1);
    _aoRT = _makeAORT(aw, ah);
    _aoBlurRT = _makeAORT(aw, ah);
  }

  for (let i = 0; i < nLevels; i++){
    const div = 2 << i;   /* 2, 4, 8 */
    const lw = Math.max(1, Math.ceil(w / div));
    const lh = Math.max(1, Math.ceil(h / div));
    _levels.push({ a: _makeRT(lw, lh, false), b: _makeRT(lw, lh, false), w: lw, h: lh });
  }

  /* 低档 / 高档的观感参数 */
  if (mode === 'high'){
    _brightMat.uniforms.threshold.value = 0.60;
    _compMat.uniforms.strength.value = 1.15;
    _aoStrength = SSAO_STRENGTH.high;
  } else {
    _brightMat.uniforms.threshold.value = 0.75;
    _compMat.uniforms.strength.value = 0.90;
    _aoStrength = SSAO_STRENGTH.low;
  }
  /* 级别少于 3 时，缺省的采样点复用第 0 级，权重压到 0 */
  if (nLevels < 3){
    _compMat.uniforms.w0.value = 0.70;
    _compMat.uniforms.w1.value = 0.30;
    _compMat.uniforms.w2.value = 0.0;
  } else {
    _compMat.uniforms.w0.value = 0.55;
    _compMat.uniforms.w1.value = 0.30;
    _compMat.uniforms.w2.value = 0.15;
  }
}

function _blit(mat, target){
  _quad.material = mat;
  renderer.setRenderTarget(target || null);
  renderer.render(_passScene, _passCam);
}

/* 把云合成需要的相机/云层状态喂给合成 pass */
const _camFwd = new THREE.Vector3();
function _updateCloudUniforms(){
  const u = _compMat.uniforms;
  const on = _cloudOn && !!_cloudTex && _sceneRT && _sceneRT.depthTexture;
  u.uCloudOn.value = on ? 1 : 0;
  u.tCloud.value = on ? _cloudTex : null;
  u.tDepth.value = (_sceneRT && _sceneRT.depthTexture) ? _sceneRT.depthTexture : null;
  if (!on) return;

  camera.updateMatrixWorld();
  camera.updateProjectionMatrix();
  _camFwd.set(0, 0, -1).applyQuaternion(camera.quaternion).normalize();
  u.uCamPos.value.copy(camera.position);
  u.uCamDir.value.copy(_camFwd);
  u.uInvViewProj.value
    .multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse)
    .invert();
  u.uCamNear.value = camera.near;
  u.uCamFar.value = camera.far;
  u.uCloudBottom.value = _cloudBottom;
  u.uCloudTop.value = _cloudTop;
}

/* 把 SSAO 需要的相机/深度参数喂给两个 AO pass */
function _updateAOUniforms(){
  if (!_aoRT || !_sceneRT || !_sceneRT.depthTexture) return;
  const s = _ssaoMat.uniforms;
  /* 相机矩阵可能在本帧被移动过，重建前先刷新 */
  camera.updateMatrixWorld();
  camera.updateProjectionMatrix();

  /* tan(halfFov)：proj[1][1] = 1/tanY，proj[0][0] = 1/(aspect*tanY)。
     透视相机下视线方向对 uv 是线性的，有了这两个数就能重建
     视空间坐标，不必做逆投影矩阵乘法。 */
  const m = camera.projectionMatrix.elements;
  const tanY = (m[5] && isFinite(m[5]) && m[5] !== 0) ? 1 / m[5] : 0.4;
  const tanX = (m[0] && isFinite(m[0]) && m[0] !== 0) ? 1 / m[0] : tanY * 1.7;
  s.uTan.value.set(tanX, tanY);
  s.uPix.value.set(1 / Math.max(1, _rtW), 1 / Math.max(1, _rtH));
  s.uNear.value = camera.near;
  s.uFar.value = camera.far;
  s.tDepth.value = _sceneRT.depthTexture;

  const b = _ssaoBlurMat.uniforms;
  b.tDepth.value = _sceneRT.depthTexture;
  b.uTexel.value.set(1 / Math.max(1, _aoRT.width), 1 / Math.max(1, _aoRT.height));
  b.uNear.value = camera.near;
  b.uFar.value = camera.far;
}

/* ============================================================
   渲染入口
   ============================================================ */
export function renderFrame(){
  if (!renderer || !camera || !scene){
    return;
  }
  if (mode === 'off' || _broken){
    renderer.render(scene, camera);
    return;
  }

  try {
    _ensureRTs();

    /* ① 场景 → 线性 RT */
    renderer.setRenderTarget(_sceneRT);
    renderer.clear();
    renderer.render(scene, camera);

    /* ★ 云的合成都放在这个 pass 里做，所以先把相机/云层参数填好 */
    _updateCloudUniforms();

    /* ②' SSAO：半分辨率算遮蔽 → 深度感知模糊。
        必须在场景渲染之后（深度已就绪）、合成之前。 */
    if (_aoOn && _aoRT && _aoBlurRT){
      try {
        _updateAOUniforms();
        _blit(_ssaoMat, _aoRT);
        _ssaoBlurMat.uniforms.tAO.value = _aoRT.texture;
        _blit(_ssaoBlurMat, _aoBlurRT);
        _compMat.uniforms.tAO.value = _aoBlurRT.texture;
        _compMat.uniforms.uAOOn.value = 1;
        _compMat.uniforms.uAOStrength.value = _aoStrength;
      } catch(e){
        /* AO 出问题不能连累整个后处理链：关掉它，画面照常 */
        console.warn('[bloom] SSAO 失败，本次跳过:', e);
        _compMat.uniforms.uAOOn.value = 0;
        _aoOn = false;
      }
    } else {
      _compMat.uniforms.uAOOn.value = 0;
    }

    /* ② 亮部提取（1/2 分辨率） */
    _brightMat.uniforms.tDiffuse.value = _sceneRT.texture;
    _blit(_brightMat, _brightRT);

    /* ③ 逐级模糊 + 降采样 */
    let prev = _brightRT;
    for (let i = 0; i < _levels.length; i++){
      const lv = _levels[i];

      /* 上一级结果（第 0 级是 brightRT）先拷到本级 a */
      if (i === 0){
        _copyMat.uniforms.tDiffuse.value = prev.texture;
        _blit(_copyMat, lv.a);
      } else {
        _copyMat.uniforms.tDiffuse.value = prev.texture;
        _blit(_copyMat, lv.a);
      }

      /* 水平 */
      _blurMat.uniforms.tDiffuse.value = lv.a.texture;
      _blurMat.uniforms.direction.value.set(1 / lv.w, 0);
      _blit(_blurMat, lv.b);

      /* 垂直 */
      _blurMat.uniforms.tDiffuse.value = lv.b.texture;
      _blurMat.uniforms.direction.value.set(0, 1 / lv.h);
      _blit(_blurMat, lv.a);

      prev = lv.a;
    }

    /* ④ 合成到屏幕 */
    const t0 = _levels[0];
    const t1 = _levels[1] || _levels[0];
    const t2 = _levels[2] || _levels[0];
    _compMat.uniforms.tScene.value = _sceneRT.texture;
    _compMat.uniforms.tB0.value = t0.a.texture;
    _compMat.uniforms.tB1.value = t1.a.texture;
    _compMat.uniforms.tB2.value = t2.a.texture;
    _blit(_compMat, null);
  } catch(e){
    console.warn('[bloom] 渲染失败，自动关闭：', e);
    _broken = true;
    try { renderer.setRenderTarget(null); } catch(_){}
    try { renderer.render(scene, camera); } catch(_){}
  }
}
