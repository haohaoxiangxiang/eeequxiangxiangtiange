/* ============================================================
   render-core.js —— 渲染器 + 材质库
   ------------------------------------------------------------
★ 合并自两个小文件（合起来约 7KB）：
     renderer.js    THREE 渲染器 / 相机 / 场景单例
     materials.js   方块材质（实心 / 透明 / 自发光 / 树叶 / 十字草）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from '../vendor/three.module.js';
import { atlasTexture, atlasCanvas } from '../world/textures.js';


/* =================================================================
   renderer.js
   ================================================================= */
/* ============================================================
   renderer.js —— Three.js 渲染器初始化
   ------------------------------------------------------------
   · scene / camera / renderer 三大件
   · 帧缓冲像素上限（保护低端机显存）
   · 分辨率缩放（受 MAX_DRAW_PIXELS 约束）
   ============================================================ */


/* ★ Worker 兼容：Worker 里没有 document，renderer/camera 全部为 null。
   scene 必须保留（world-core.js 里 import { scene } 时不能是 undefined）。 */
const IS_WORKER = (typeof document === 'undefined');

const scene = new THREE.Scene();

let canvas = null;
let renderer = null;
let camera = null;

if (!IS_WORKER){
  /* ---- 游戏主画布 ----
     必须显式设置 id，否则 input.js 的 querySelector('canvas')
     会选到菜单里的 <canvas id="worldPreview">（世界预览图） */
  canvas = document.createElement('canvas');
  canvas.id = 'game-canvas';
  document.body.insertBefore(canvas, document.getElementById('ui'));

  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: !(('ontouchstart' in window) || navigator.maxTouchPoints > 0),
    powerPreference: 'high-performance'
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  /* ---- 真实阴影 ---- */
  renderer.shadowMap.enabled = true;
  /* ★ r187 删掉了 THREE.PCFSoftShadowMap（着色器 chunk 里的
     SHADOWMAP_TYPE_PCF_SOFT 已经不存在）。继续写 PCFSoftShadowMap
     会被 three 在第一次渲染时告警并静默降级成 PCFShadowMap。
     好消息是 r187 的 PCF 被重写过了：sampler2DShadow 硬件比较
     （每次采样自带 4 tap 双线性）+ 5 次 Vogel 盘采样 + IGN 旋转，
     等效 20 tap，而且 shadow.radius 现在真的控制软硬程度。
     所以直接用 PCFShadowMap，软边靠 shadow.radius 调（见 sky.js）。 */
  renderer.shadowMap.type = THREE.PCFShadowMap;
  /* ★ 阴影贴图不要每帧重画。
     默认 autoUpdate=true 意味着每次 renderer.render() 都要用
     「所有 castShadow 的区块网格」再跑一遍完整几何 pass（1024²），
     等于把场景画了两遍 —— 这是手机端性价比最差的一块开销。
     改成按需刷新：由 tickShadow() 每 SHADOW_REFRESH_MS 打一次标记，
     站着不动环顾四周时这一整遍 pass 就省下来了。
     注意：needsUpdate 是「一次性的」—— 任何一个 renderer.render()
     都会把它消费掉（Three 内部 WebGLShadowMap.render 无条件被调用），
     所以标记必须打在主场景 render 之前，见 main.js 的 tickShadow 调用点。 */
  renderer.shadowMap.autoUpdate = false;

  camera = new THREE.PerspectiveCamera(
    72,
    window.innerWidth / window.innerHeight,
    0.08,
    1000
  );
  camera.rotation.order = 'YXZ';
}

/* ============================================================
   ★ three 的 warn / error 接进游戏内的错误面板
   ------------------------------------------------------------
   r187 才有的 THREE.setConsoleFunction(type, message, ...params)，
   type 是 'log' | 'warn' | 'error'。接上以后 three 自己的告警
   （着色器编译失败、纹理尺寸超限、材质参数不合法……）会和普通
   报错一样进 __errs__ → 错误面板 → 日志上传，不用再靠玩家截图
   控制台。
   · 只收 warn / error，three 的 'log' 大多是版本号之类的噪音。
   · 同一条消息只记一次（three 的 warnOnce 覆盖不到全部路径）。
   · 上限 40 条，避免某个每帧告警把面板和 localStorage 刷爆。
   ============================================================ */
if (!IS_WORKER && typeof THREE.setConsoleFunction === 'function'){
  (function(){
    const seen = new Set();
    let count = 0;
    const MAX_RECORDS = 40;
    THREE.setConsoleFunction(function(type, message, ...params){
      if (type !== 'warn' && type !== 'error') return;
      if (count >= MAX_RECORDS) return;
      const key = type + '|' + message;
      if (seen.has(key)) return;
      seen.add(key);
      count++;
      let extra = '';
      try {
        if (params.length){
          extra = ' | ' + params.map(p => {
            if (p && p.message) return p.message;
            if (typeof p === 'string') return p;
            try { return JSON.stringify(p); } catch(_){ return String(p); }
          }).join(' ');
        }
      } catch(_){}
      const tag = type === 'error' ? 'THREE_ERROR' : 'THREE_WARN';
      try {
        const fmt = (typeof window !== 'undefined') ? window.__fmtErr__ : null;
        if (typeof fmt === 'function') fmt(tag, new Error(message + extra));
        else console.warn('[three]', message, ...params);
      } catch(_){}
    });
  })();
}

/* ============================================================
   ★ 阴影贴图按需刷新
   ------------------------------------------------------------
   renderer.shadowMap.autoUpdate 关掉后，靠 needsUpdate 这个一次性
   标记驱动。这里做两件事：

     tickShadow(now)        每帧调一次（在主场景 render 之前），
                            距上次刷新超过 SHADOW_REFRESH_MS 才打标记
     requestShadowUpdate()  强制下一帧刷新（改阴影质量 / 切换树叶材质
                            / 改地图这类"立刻要生效"的场合用）

   为什么是 100ms 而不是"只在玩家或太阳动了才刷"：
   生物、掉落物、箱子这些 castShadow 的东西也在动，只盯相机和太阳
   会让它们的影子冻住。10Hz 对它们完全够，又比每帧省下 ~85% 的
   shadow pass。
   ============================================================ */
const SHADOW_REFRESH_MS = 100;
let _shadowLastAt = -1e9;

function tickShadow(nowMs){
  if (!renderer || !renderer.shadowMap || !renderer.shadowMap.enabled) return;
  const now = (typeof nowMs === 'number' && isFinite(nowMs))
    ? nowMs
    : ((typeof performance !== 'undefined') ? performance.now() : Date.now());
  if (now - _shadowLastAt < SHADOW_REFRESH_MS) return;
  _shadowLastAt = now;
  renderer.shadowMap.needsUpdate = true;
}

function requestShadowUpdate(){
  _shadowLastAt = -1e9;
}

/* ============================================================
   ★ 帧缓冲像素上限
   ------------------------------------------------------------
   手机 dpr 动辄 2.75~3.5，1080x2400 的屏算出 2970x6600 的画布
   = 1960 万像素；颜色 RGBA8 + 深度 24 位 ≈ 150MB。
   所以这里按"总像素数"封顶，而不是只限制 pixelRatio。
   2.2M 像素 ≈ 1080p，手机屏幕上看着几乎没区别。
   ============================================================ */
const MAX_DRAW_PIXELS = 8e6;

let userScale = 1.0;

/**
 * 算出当前该用的 pixelRatio。
 *   设置里的"分辨率"= 在这份像素上限之内缩放。
 *   1.0 → 顶到上限（1080p 手机上约等于原生 1:1，画面最清晰）
 *   0.5 → 线性一半（像素只有 1/4，最省内存、最流畅）
 */
function computePixelRatio(){
  if (!renderer) return 1;
  const w = Math.max(1, window.innerWidth || 1);
  const h = Math.max(1, window.innerHeight || 1);
  const cap = Math.sqrt(MAX_DRAW_PIXELS / (w * h));
  const s = Math.max(0.4, Math.min(1.0, userScale));
  return Math.max(0.4, Math.min(cap * s, 3.0));
}

/** 唯一的改尺寸入口：分辨率设置和 resize 都走这里 */
function applyRenderSize(scale){
  if (typeof scale === 'number' && isFinite(scale) && scale > 0){
    userScale = Math.max(0.4, Math.min(3.0, scale));
  }
  if (!renderer) return userScale;
  const ratio = computePixelRatio();
  renderer.setPixelRatio(ratio);
  renderer.setSize(window.innerWidth, window.innerHeight);
  return ratio;
}

function getUserScale(){ return userScale; }
function getPixelRatioNow(){ return renderer ? renderer.getPixelRatio() : 1; }

/* ---- 初始化尺寸 ---- */
if (!IS_WORKER){
  const PW = window.innerWidth || 1;
  const PH = window.innerHeight || 1;
  camera.aspect = PW / PH;
  camera.updateProjectionMatrix();
  applyRenderSize(1.0);

  window.addEventListener('resize', () => {
    camera.aspect = Math.max(1, window.innerWidth) / Math.max(1, window.innerHeight);
    camera.updateProjectionMatrix();
    applyRenderSize();
    if (typeof window !== 'undefined'){
      window.__resizeCount = (window.__resizeCount || 0) + 1;
    }
  });
}

/* =================================================================
   materials.js
   ================================================================= */
atlasTexture.colorSpace = THREE.SRGBColorSpace;

/* ============================================================
   ★ 可平铺 UV 材质
   ============================================================ */
/* ★ jitter：同一方块面按"方块格子"做极轻微的明暗抖动，
   用于草/泥土/树叶等大量重复的方块，避免整片地面千篇一律。
   抖动按世界坐标取整到方块格子，所以贪心合并后的大面也能逐格变化；
   5 级、默认 ±4.5%，范围小、层次少。 */
function patchTileable(mat, opts){
  const jitter = (opts && opts.jitter) || 0;
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader =
      'attribute vec4 uvRect;\nvarying vec2 vTileUv;\nvarying vec4 vUvRect;\n' +
      (jitter > 0 ? 'varying vec3 vJitterWorld;\n' : '') +
      shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace(
      '#include <uv_vertex>',
      '#include <uv_vertex>\n  vTileUv = uv;\n  vUvRect = uvRect;'
    );

    shader.fragmentShader =
      'varying vec2 vTileUv;\nvarying vec4 vUvRect;\n' +
      (jitter > 0 ? 'uniform float uJitterStrength;\nvarying vec3 vJitterWorld;\n' : '') +
      shader.fragmentShader;

    if (jitter > 0){
      shader.uniforms.uJitterStrength = { value: jitter };
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        '#include <begin_vertex>\n  vJitterWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;'
      );
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `#ifdef USE_MAP
          vec2 tileFrac = fract(vTileUv);
          vec2 atlasUv = vUvRect.xy + tileFrac * vUvRect.zw;
          vec4 sampledDiffuseColor = texture2D(map, atlasUv);
          vec3 cell = floor(vJitterWorld + 0.001);
          float h = fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
          float lv = floor(h * 5.0) / 4.0;
          diffuseColor.rgb *= 1.0 + (lv - 0.5) * uJitterStrength;
          diffuseColor *= sampledDiffuseColor;
        #endif`
      );
    } else {
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `#ifdef USE_MAP
          vec2 tileFrac = fract(vTileUv);
          vec2 atlasUv = vUvRect.xy + tileFrac * vUvRect.zw;
          vec4 sampledDiffuseColor = texture2D(map, atlasUv);
          diffuseColor *= sampledDiffuseColor;
        #endif`
      );
    }
  };
  mat.needsUpdate = true;
}

/* ============================================================
   ★ 方块光自发光补偿
   ------------------------------------------------------------
   天光（sunglight/ambient）会随昼夜变暗，但火把 / 荧石 / 海晶灯
   发出的方块光是局部常量，不该跟着天黑一起暗。
   顶点上的 aBlock 存了面外侧的方块光强度，这里在光照结果上取
   max()：环境够亮时无影响，夜里/洞里自动把光源周围的亮度补回来。
   ============================================================ */
const BLOCK_GLOW_UNIFORM = { value: 0.95 };

/* ============================================================
   ★ 手持 / 掉落光源（动态光）—— 关键：不能乘进烘焙顶点色
   ------------------------------------------------------------
   之前这里靠真正的 THREE.PointLight。但 Lambert 的直射光最后要乘
   diffuseColor，而 diffuseColor 里已经乘过了烘焙好的顶点色
   （天光+方块光，见 mesh-builder 的 _lightBright）。
   洞穴里顶点色 ≈ _lightBright(0) = 0.05，于是点光源的贡献也被
   乘成 5% —— 表现就是"黑暗里点光源照不亮任何东西，有光的地方才看得见"。

   现在改成自己算一份"未烘焙反照率"（贴图色 × 归一化染色）上的光，
   再用 max() 并进 outgoingLight：
     · 亮处：原本光照本来就 ≥ 这个值，max() 不会重复叠加；
     · 暗处：把火把的照亮效果补回来。
   和上面 addBlockGlow 补方块光用的是同一个套路。

   位置用「视空间」：片元侧 vViewPosition 和 normal 都已经是视空间，
   省掉一组世界坐标 varying。矩阵每帧由 setDynamicLightUniforms 更新。
   ============================================================ */
/* ★★ 这里刻意**不用 uniform 数组**。
   之前用的是 vec3[4] / float[4]，实测在真机上整块效果都没生效
   （表现就是"点光源完全没起作用"，只剩 three 自带的 PointLight 在干活）。
   现在改成 2 组独立的标量 uniform：uDynPos0/uDynCol0/uDynRng0 …
   单个 uniform 是 three 最常走、最不容易出问题的路径；
   顺便只保留最近 2 个光源，方材质的片元开销也更小。 */
const DYN_LIGHT_SLOTS = 2;
const DYN_LIGHT_UNIFORMS = {
  uDynPos0: { value: new THREE.Vector3() },
  uDynCol0: { value: new THREE.Vector3() },
  uDynRng0: { value: 0 },
  uDynPos1: { value: new THREE.Vector3() },
  uDynCol1: { value: new THREE.Vector3() },
  uDynRng1: { value: 0 },
  uDynDecay: { value: 0.8 },
  /* 探针：=1 时着色器里把动态光强制成纯白满强度，
     用来一眼判断"这段注入到底有没有生效"（window.__dynProbe = true） */
  uDynProbe: { value: 0 },
  /* ★ 半球绕射（half-Lambert）系数。
     为什么不加不行：手部光源锚点在"脚上 0.8 格"，纯 Lambert 下
     任何比脚高的方块顶面 N·L < 0 → 被 clamp 成 0；洞穴里烘焙光接近 0，
     压不住 → 顶面直接纯黑（玩家反馈的 bug）。
     为什么值是 0.5：MC 的移动光源本质是往 blockLight 里塞一个方块光
     再 BFS 传播，传播结果**完全没有方向性**，所以它照到的地方哪都亮。
     0.5 = 标准 half-Lambert：N·L=0 时给一半亮度，N·L=-1 时才是 0。
     试过"竖向光柱"（把锚点沿世界上方向夹取）——反而把脚下的地板
     打成纯黑（最近点与地面同高 → L 水平 → 顶面 N·L=0），已放弃。 */
  uDynWrap:  { value: 0.5 }
};

const _camInv = new THREE.Matrix4();
const _vTmp = new THREE.Vector3();
let _dynLast = null;   /* 调试快照：最近一次填进去的光源 */

const _DYN_SLOT = [
  { pos: DYN_LIGHT_UNIFORMS.uDynPos0, col: DYN_LIGHT_UNIFORMS.uDynCol0, rng: DYN_LIGHT_UNIFORMS.uDynRng0 },
  { pos: DYN_LIGHT_UNIFORMS.uDynPos1, col: DYN_LIGHT_UNIFORMS.uDynCol1, rng: DYN_LIGHT_UNIFORMS.uDynRng1 }
];

/**
 * 每帧填充动态光 uniform。
 * @param list [{ x, y, z, r, g, b, intensity, range }] 世界坐标 + 线性色
 *             （r/g/b 请从 THREE.Color 取，它已经做过 sRGB→线性）
 * @param decay 衰减指数（和 dynamic-light.js 的 LIGHT_DECAY 保持一致）
 */
function setDynamicLightUniforms(list, decay){
  if (typeof decay === 'number' && isFinite(decay)) DYN_LIGHT_UNIFORMS.uDynDecay.value = decay;
  if (typeof window !== 'undefined'){
    DYN_LIGHT_UNIFORMS.uDynProbe.value = window.__dynProbe ? 1 : 0;
  }

  const n = (list && list.length) ? Math.min(list.length, DYN_LIGHT_SLOTS) : 0;
  /* 必须用这一帧的相机矩阵：three 在 render() 里才更新 matrixWorld，
     而这里是渲染之前跑的，不手动更新就会用上一帧的朝向 ——
     快速转头时光源会在视空间里甩一下。 */
  if (n > 0 && camera){
    camera.updateMatrixWorld();
    _camInv.copy(camera.matrixWorld).invert();
  }
  for (let i = 0; i < DYN_LIGHT_SLOTS; i++){
    const slot = _DYN_SLOT[i];
    if (i >= n){
      /* 熄灭：range=0 时着色器直接跳过这个槽位 */
      slot.rng.value = 0;
      /* ★ 这里必须是 Vector3.set(x,y,z)，不是 Color 的 setRGB ——
         uDynCol* 声明成 new THREE.Vector3()，而 Vector3 在 r187 里
         没有 setRGB 方法。之前写成 setRGB 会每帧抛 TypeError，
         又被外层 try/catch 吞掉，表现就是"动态光完全不生效"，
         而且 rng 的赋值在这行之后，所以永远停在初始值 0。 */
      slot.col.value.set(0, 0, 0);
      continue;
    }
    const l = list[i];
    _vTmp.set(l.x, l.y, l.z).applyMatrix4(_camInv);
    slot.pos.value.copy(_vTmp);
    slot.col.value.set(l.r, l.g, l.b).multiplyScalar(l.intensity);
    slot.rng.value = l.range;
  }
  _dynLast = n ? list.slice(0, n) : null;
}

/** 调试：看动态光到底填了什么（window.__dynStatus()） */
function getDynamicLightUniformsDebug(){
  return {
    probe: DYN_LIGHT_UNIFORMS.uDynProbe.value,
    decay: DYN_LIGHT_UNIFORMS.uDynDecay.value,
    /* 半球绕射系数（0.5 = 标准 half-Lambert，顶面不再纯黑） */
    wrap: DYN_LIGHT_UNIFORMS.uDynWrap.value,
    slots: _DYN_SLOT.map(s => ({
      viewPos: s.pos.value.toArray().map(v => Math.round(v * 100) / 100),
      color:  s.col.value.toArray().map(v => Math.round(v * 1000) / 1000),
      range:  Math.round(s.rng.value * 100) / 100
    })),
    sources: _dynLast
  };
}

/* ★ 暗处最低亮度（等价于 MC 的"亮度"设置档位）
   ------------------------------------------------------------
   洞穴里烘焙顶点色的下限是 _lightBright(0) = 0.05，再乘上夜间的
   环境光强度，实际只剩 ~0.004 —— 就是纯黑。于是火把光晕之外全黑，
   视觉上会觉得"火把只照亮脚下一小片"。
   而同样黑的露天夜晚还有月光底子（顶点色天光=15 → ~0.09），
   整个画面有一层灰，火把的衰减尾巴能融进去，看起来就"更亮、更大"。
   注意：火把项本身在两种环境下是**完全相同**的（2 格 0.457 / 8 格 0.148
   / 12 格 0.099），差的只是这层底线。
   这里给"未烘焙反照率"垫一个下限。★ 别给太大：0.06 时洞穴整体
   被抬到"暗但一眼看全"，手上的火把就失去意义了（实测偏亮）。
     0     = 纯黑，必须靠光源（最压抑，MC 的"昏暗"档）
     0.02  = 默认：只把纯黑抬到"勉强有轮廓"，光源仍然是刚需
     0.06+ = 亮档，会明显削弱照明玩法的必要性
   注意：火把光晕"只照亮脚下一小片"的真正原因是洞穴雾把动态光吃掉，
   已经在 FOG_DYN_PATCH 里单独修掉，不需要靠这个下限去补偿。
   ============================================================ */
const DARK_FLOOR_UNIFORM = { value: 0 };   /* 默认 0 = 纯黑，照明才是刚需 */
function setDarkFloor(v){
  const n = Number(v);
  if (!isFinite(n)) return DARK_FLOOR_UNIFORM.value;
  DARK_FLOOR_UNIFORM.value = Math.max(0, Math.min(0.5, n));
  return DARK_FLOOR_UNIFORM.value;
}
function getDarkFloor(){ return DARK_FLOOR_UNIFORM.value; }

/* ★ 让动态光不被雾吃掉
   ------------------------------------------------------------
   three 的 fog_fragment 是后处理式的：距离越远，整像素越往 fogColor 混。
   洞穴雾（sky.js 里 caveF）会把 fogFar 砍到 45%、颜色压到 0x030407，
   于是一进洞，火把光晕在 10~15 格外就被雾按距离吃光了 ——
   表现就是"一进洞，火把只照亮脚下一小片"，出洞立刻恢复。

   修法：把动态光真正加进去的那一份（_dynExtra）记下来，在雾混合之后
   按 fogFactor 补回去 —— 局部光源不该被距离雾同等对待。
   注意 fogColor 在着色器里是「输出色彩空间」（three 用
   getUnlitUniformColorSpace 转过），而 _dynExtra 是线性空间的，
   所以补回去之前要过一遍 linearToOutputTexel。
   ============================================================ */
const FOG_DYN_PATCH = (function(){
  const src = THREE.ShaderChunk && THREE.ShaderChunk.fog_fragment;
  if (!src) return null;
  const anchor = 'gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );';
  if (src.indexOf(anchor) < 0) return null;   /* 版本变了就跳过，不至于编译失败 */
  return src.replace(anchor,
    anchor + '\n' +
    '\t// ★ 火把 / 掉落光源是局部光源，雾把它们吃掉会变成"只能照亮脚下"\n' +
    '\tgl_FragColor.rgb += linearToOutputTexel( vec4( _dynExtra, 1.0 ) ).rgb * fogFactor;'
  );
})();

/* 诊断计数器：用来判断注入到底有没有跑到（HUD 里显示）
   compiled  : onBeforeCompile 被调用了几次
   octxHit   : '#include <opaque_fragment>' 这个锚点命中了几次
   fogHit    : fog 补偿有没有真的插进去
   uDeclared : 片元里能看到 uDynPos0 声明（证明文本确实拼进去了） */
const DYN_PATCH_STATUS = { compiled: 0, octxHit: 0, fogHit: 0, lastErr: '' };
function getDynPatchStatus(){ return DYN_PATCH_STATUS; }

function addBlockGlow(mat){
  const prev = mat.onBeforeCompile;
  mat.onBeforeCompile = (shader, r) => {
    DYN_PATCH_STATUS.compiled++;
    try { applyBlockGlow(shader, prev, r); }
    catch(e){
      DYN_PATCH_STATUS.lastErr = String((e && e.message) || e).slice(0, 120);
      console.warn('[render-core] addBlockGlow 注入失败:', e);
    }
  };
  /* 着色器内容变了，缓存键必须跟着变，否则会复用旧 program */
  mat.customProgramCacheKey = () => 'blockglow_v6_diag';
}

function applyBlockGlow(shader, prev, r){
  {
    if (prev) prev(shader, r);
    shader.uniforms.uBlockGlow = BLOCK_GLOW_UNIFORM;
    shader.uniforms.uDarkFloor  = DARK_FLOOR_UNIFORM;
    shader.uniforms.uDynPos0    = DYN_LIGHT_UNIFORMS.uDynPos0;
    shader.uniforms.uDynCol0    = DYN_LIGHT_UNIFORMS.uDynCol0;
    shader.uniforms.uDynRng0    = DYN_LIGHT_UNIFORMS.uDynRng0;
    shader.uniforms.uDynPos1    = DYN_LIGHT_UNIFORMS.uDynPos1;
    shader.uniforms.uDynCol1    = DYN_LIGHT_UNIFORMS.uDynCol1;
    shader.uniforms.uDynRng1    = DYN_LIGHT_UNIFORMS.uDynRng1;
    shader.uniforms.uDynDecay   = DYN_LIGHT_UNIFORMS.uDynDecay;
    shader.uniforms.uDynProbe   = DYN_LIGHT_UNIFORMS.uDynProbe;
    shader.uniforms.uDynWrap    = DYN_LIGHT_UNIFORMS.uDynWrap;
    shader.vertexShader =
      'attribute float aBlock;\nvarying float vBlockLight;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace(
      '#include <begin_vertex>',
      '#include <begin_vertex>\n  vBlockLight = aBlock;'
    );
    /* 单个光源的贡献：1/d^decay × 窗口函数 × NdotL。
       写成全局函数（GLSL 不允许函数嵌套），片元里调用两次。 */
    const DYN_GLSL_COMMON =
      'uniform vec3 uDynPos0; uniform vec3 uDynCol0; uniform float uDynRng0;\n' +
      'uniform vec3 uDynPos1; uniform vec3 uDynCol1; uniform float uDynRng1;\n' +
      'uniform float uDynDecay;\n' +
      'uniform float uDynProbe;\n' +
      'uniform float uDynWrap;\n' +
      'vec3 dynLightAt( vec3 nv, vec3 fv, vec3 lp, vec3 lc, float rng ){\n' +
      '  if ( rng <= 0.0 ) return vec3( 0.0 );\n' +
      '  vec3 L = lp - fv;\n' +
      '  float d = length( L );\n' +
      '  if ( d >= rng ) return vec3( 0.0 );\n' +
      '  float att = 1.0 / max( pow( d, uDynDecay ), 1.0 );\n' +
      '  float w = 1.0 - pow( d / rng, 4.0 );\n' +
      '  att *= w * w;\n' +
      '  /* ★ half-Lambert：纯 Lambert 在 N·L <= 0 时直接归零，\n' +
      '     于是比手部光源高的方块顶面全黑（玩家反馈的 bug）。\n' +
      '     MC 的移动光源是方块光 BFS 传播，没有方向性，\n' +
      '     这里用 0.5 的半球绕射去对齐那个手感：N·L=0 仍有一半亮度。 */\n' +
      '  float ndl = dot( nv, L / max( d, 1e-4 ) );\n' +
      '  float nl = clamp( ndl * ( 1.0 - uDynWrap ) + uDynWrap, 0.0, 1.0 );\n' +
      '  return lc * ( att * nl );\n' +
      '}\n';
    shader.fragmentShader =
      'uniform float uBlockGlow;\n' +
      'uniform float uDarkFloor;\n' +
      'varying float vBlockLight;\n' +
      DYN_GLSL_COMMON + shader.fragmentShader;
    /* 用贴图色 × 归一化 tint（去掉顶点色里的天光亮度）做反照率，
       再与环境光结果取 max：够亮时无影响，夜里/洞里自动补亮。 */
    if (shader.fragmentShader.indexOf('#include <opaque_fragment>') >= 0) DYN_PATCH_STATUS.octxHit++;
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <opaque_fragment>',
      `vec3 _dynExtra = vec3(0.0);
      #ifdef USE_MAP
        vec3 _tint = vec3(1.0);
        #ifdef USE_COLOR
          float _cmax = max(max(vColor.r, vColor.g), vColor.b);
          /* ★ vColor 在 three r16x 起统一成了 vec4（r157 时 USE_COLOR 下是 vec3），
             这里必须取 .rgb，否则 vec3 变量接 vec4 会编译失败、整块材质全黑。
             .rgb 对 vec3/vec4 都合法，两种版本都能跑。 */
          if (_cmax > 0.001) _tint = vColor.rgb / _cmax;
        #endif
        vec3 _unlit = sampledDiffuseColor.rgb * _tint;

        /* ---- 暗处最低亮度：让洞穴"暗但看得见"，而不是只剩火把一圈 ---- */
        outgoingLight = max(outgoingLight, _unlit * uDarkFloor);

        /* ---- 方块光（荧石/岩浆这类自发光方块邻域） ---- */
        outgoingLight = max(outgoingLight, _unlit * vBlockLight * uBlockGlow);

        /* ---- 手持 / 掉落 / 已放置光源：完全绕过烘焙光照 ----
           关键点：反照率用 _unlit（贴图色 × 归一化染色），而不是
           diffuseColor —— 后者已经被烘焙的暗光乘成近黑，
           拿它当反照率就等于"拿黑纸去接光"。 */
        {
          vec3 _fv = -vViewPosition;
          vec3 _nv = normal;
          vec3 _dyn = dynLightAt( _nv, _fv, uDynPos0, uDynCol0, uDynRng0 )
                    + dynLightAt( _nv, _fv, uDynPos1, uDynCol1, uDynRng1 );
          if ( uDynProbe > 0.5 ) _dyn = vec3( 1.0 );
          /* 记下"我们到底加进去了多少"，雾后面要按 fogFactor 补回来 */
          vec3 _dynBefore = outgoingLight;
          outgoingLight = max( outgoingLight, _unlit * _dyn * RECIPROCAL_PI );
          _dynExtra = max( outgoingLight - _dynBefore, vec3( 0.0 ) );
        }
      #endif
      #include <opaque_fragment>`
    );
    /* 雾之后再按 fogFactor 把动态光补回来（见 FOG_DYN_PATCH 的注释） */
    if (FOG_DYN_PATCH && shader.fragmentShader.indexOf('#include <fog_fragment>') >= 0){
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <fog_fragment>',
        FOG_DYN_PATCH
      );
      DYN_PATCH_STATUS.fogHit++;
    }
  }
}


/* ============================================================
   主材质
   ============================================================ */

// ★ 极速版：去掉了 alphaTest，恢复 GPU 的 Early-Z 深度提前剔除
const matSolid = new THREE.MeshLambertMaterial({
  map: atlasTexture, vertexColors: true, transparent: false
});
patchTileable(matSolid, { jitter: 0.09 });
addBlockGlow(matSolid);

// ★ 极速版：去掉了 alphaTest，发光方块（如荧石）也是完全不透明的
const matEmissive = new THREE.MeshBasicMaterial({
  map: atlasTexture, vertexColors: true, transparent: false
});
patchTileable(matEmissive);

// 透明材质（水、玻璃）：必须保留 alphaTest 和 transparent
const matTrans = new THREE.MeshLambertMaterial({
  map: atlasTexture, vertexColors: true, transparent: true, alphaTest: 0.02, depthWrite: false
});
patchTileable(matTrans);
addBlockGlow(matTrans);

// 透光树叶：必须保留 alphaTest 来裁掉镂空部分
const matLeavesAlpha = new THREE.MeshLambertMaterial({
  map: atlasTexture, vertexColors: true, transparent: false,
  alphaTest: 0.5,
  side: THREE.FrontSide
});
patchTileable(matLeavesAlpha, { jitter: 0.11 });
addBlockGlow(matLeavesAlpha);

// 实心树叶：保留（保持原样，虽然 alphaTest: 0 等于没设，但不影响）
const matLeavesOpaque = new THREE.MeshLambertMaterial({
  map: atlasTexture, vertexColors: true, transparent: false, alphaTest: 0
});
patchTileable(matLeavesOpaque, { jitter: 0.11 });
addBlockGlow(matLeavesOpaque);

/* ============================================================
   十字花草专用材质：无 mipmap
   ============================================================ */
const atlasTextureNoMip = new THREE.CanvasTexture(atlasCanvas);
atlasTextureNoMip.magFilter = THREE.NearestFilter;
atlasTextureNoMip.minFilter = THREE.NearestFilter;
atlasTextureNoMip.generateMipmaps = false;
atlasTextureNoMip.colorSpace = THREE.SRGBColorSpace;
atlasTextureNoMip.needsUpdate = true;

if (typeof window !== 'undefined'){
  window.__atlasNoMip__ = atlasTextureNoMip;
}

// 花草必须保留 alphaTest 来裁掉十字边缘
const matCross = new THREE.MeshLambertMaterial({
  map: atlasTextureNoMip,
  vertexColors: true,
  transparent: false,
  alphaTest: 0.5,
});
patchTileable(matCross);
addBlockGlow(matCross);

/* ============================================================
   树叶材质切换（透光 / 实心）
   ============================================================ */
let leafAlphaEnabled = true;
function setLeafAlpha(v){ leafAlphaEnabled = v; }
function getLeafAlpha(){ return leafAlphaEnabled; }
function getLeafMaterial(){
  return leafAlphaEnabled ? matLeavesAlpha : matLeavesOpaque;
}

/* =================================================================
   re-export
   ================================================================= */
export {
  scene, renderer, camera, MAX_DRAW_PIXELS, computePixelRatio, applyRenderSize, getUserScale, getPixelRatioNow, matSolid, matEmissive, matTrans, matLeavesAlpha, matLeavesOpaque, atlasTextureNoMip, matCross, setLeafAlpha, getLeafAlpha, getLeafMaterial, tickShadow, requestShadowUpdate, setDynamicLightUniforms, getDynamicLightUniformsDebug, getDynPatchStatus, setDarkFloor, getDarkFloor
};
