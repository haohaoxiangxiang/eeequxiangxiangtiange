/* ============================================================
   sky.js —— 天空穹顶 / 光照 / 云 / 阴影 / 雾
   ------------------------------------------------------------
   · 天空球 (ShaderMaterial)
   · 太阳 / 环境光 / 半球光
   · 阴影：质量 / 距离 / 跟随玩家
   · 云：low / high(方块) / ultra(多层)
   · 支持 setSkyPreset / setBiomeFog 覆盖
   ============================================================ */

import * as THREE from 'three';
import { smoothstep } from './../core/runtime.js';
import { camera, scene, renderer, requestShadowUpdate } from './render-core.js';
import { getBlockWorld, isWaterLike, getSkyLightAt } from '../world/terrain.js';
import { BLOCKS } from '../world/blocks.js';
import { cloudHeight } from './../core/engine-core.js';
import { getWeatherIntensity } from '../world/weather.js';
import { isBloomActive, setCloudLayer } from './bloom.js';

/* ============================================================
   天空穹顶
   ============================================================ */
export const skyUniforms = {
  uTop:      { value: new THREE.Color(0x7ea6d4) },
  uBottom:   { value: new THREE.Color(0xd8e4ec) },
  uSunDir:   { value: new THREE.Vector3(0, 1, 0) },
  uSunColor: { value: new THREE.Color(0xffe0a8) },
  /* ★ 半分辨率体积云合成（ultra）：天空穹顶采样云 RT */
  uCloudTex: { value: null },
  uCloudRes: { value: new THREE.Vector2(1, 1) },
  uCloudOn:  { value: 0 },
  /* ★ bloom 开启时场景先渲染到线性 RT，合成 pass 会统一做 sRGB 编码。
     天空是自定义 shader（平时直接把显示值写到画布），所以这里要先把
     「显示值」转回线性，编码后才能还原成同样的颜色。 */
  uLinearize: { value: 0 }
};

export const skyMesh = new THREE.Mesh(
  new THREE.SphereGeometry(600, 32, 20),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: skyUniforms,
    vertexShader: `
      varying vec3 vDir;
      void main(){
        vDir = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `
      uniform vec3 uTop, uBottom, uSunColor, uSunDir;
      uniform sampler2D uCloudTex;
      uniform vec2 uCloudRes;
      uniform float uCloudOn;
      uniform float uLinearize;
      varying vec3 vDir;

      /* bloom 开启时把「显示用」颜色转回线性，交给合成 pass 统一编码 */
      vec3 srgbToLinear(vec3 c){
        c = max(c, vec3(0.0));
        vec3 lo = c / 12.92;
        vec3 hi = pow((c + 0.055) / 1.055, vec3(2.4));
        return mix(lo, hi, step(vec3(0.04045), c));
      }

      void main(){
        vec3 d = normalize(vDir);
        float h = d.y;
        vec3 col = mix(uBottom, uTop, clamp(h*1.15 + 0.22, 0.0, 1.0));
        float s = max(dot(d, normalize(uSunDir)), 0.0);
        col += uSunColor * pow(s, 96.0) * 2.2;
        col += uSunColor * pow(s, 8.0) * 0.18;
        col += uSunColor * pow(s, 2.0) * 0.05;
        /* 体积云已按预乘 alpha 写进半分辨率 RT，直接叠在天空上 */
        vec4 cc = texture2D(uCloudTex, gl_FragCoord.xy / uCloudRes);
        col = col * (1.0 - cc.a * uCloudOn) + cc.rgb * uCloudOn;
        if (uLinearize > 0.5) col = srgbToLinear(col);
        gl_FragColor = vec4(col, 1.0);
      }`
  })
);
/* 体积云专用场景：ultra 云渲染到半分辨率 RT，再合成到天空穹顶。
   不放进主场景，避免全分辨率再跑一遍 72 步。 */
const cloudScene = new THREE.Scene();
const cloudRT = new THREE.WebGLRenderTarget(1, 1, {
  depthBuffer: false, stencilBuffer: false,
  minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
  generateMipmaps: false
});
let _cloudRTW = 0, _cloudRTH = 0;
const _cloudBufSize = new THREE.Vector2();
const _prevClearCol = new THREE.Color();
skyUniforms.uCloudTex.value = cloudRT.texture;

scene.add(skyMesh);

/* ============================================================
   光照
   ============================================================ */
export const sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
sunLight.castShadow = true;
sunLight.shadow.mapSize.width = 1024;
sunLight.shadow.mapSize.height = 1024;
sunLight.shadow.camera.left = -50;
sunLight.shadow.camera.right = 50;
sunLight.shadow.camera.top = 50;
sunLight.shadow.camera.bottom = -50;
sunLight.shadow.camera.near = 0.5;
sunLight.shadow.camera.far = 300;
sunLight.shadow.bias = -0.0006;
sunLight.shadow.normalBias = 0.03;
/* ★ r187 起 PCFSoftShadowMap 没有了，软边只能靠 shadow.radius（单位=texel）。
   1.0 ≈ 一像素宽的硬边；2.0 大致相当于旧 PCFSoftShadowMap 的柔和度。
   这里给个初值，setShadowQuality 会按画质档位再调。 */
sunLight.shadow.radius = 2.0;
scene.add(sunLight);
scene.add(sunLight.target);

export const ambientLight = new THREE.AmbientLight(0x8899bb, 0.55);
scene.add(ambientLight);

export const hemiLight = new THREE.HemisphereLight(0x9fc6ff, 0x36424f, 0.45);
scene.add(hemiLight);

export const sunDir = new THREE.Vector3(0, 1, 0);
export const fogCol = new THREE.Color(0.76, 0.84, 0.90);

let lightMultiplier = 1.0;
export function setLightMultiplier(v){
  lightMultiplier = Math.max(0.1, Math.min(2.5, v));
}

/* ============================================================
   雾设置（设置 → 画面）
   · fogScale：雾的远近倍率，1 = 默认；越小雾越近
   · fogDepth：洞穴雾的黑度，0 = 不压黑，1 = 默认；越大越快变黑灰
   ============================================================ */
let fogScale = 1.0;
let fogDepth = 1.0;

function _loadFogSettings(){
  try {
    /* 存的是百分比整数（50~160 / 0~100），与设置面板一致 */
    const s = parseFloat(localStorage.getItem('3dmc_fog_scale'));
    if (isFinite(s)) fogScale = Math.max(0.5, Math.min(1.6, s / 100));
    const d = parseFloat(localStorage.getItem('3dmc_fog_depth'));
    if (isFinite(d)) fogDepth = Math.max(0, Math.min(1, d / 100));
  } catch(e){}
}
_loadFogSettings();

export function setFogScale(v){
  const n = Number(v);
  if (!isFinite(n)) return;
  fogScale = Math.max(0.5, Math.min(1.6, n));
  try { localStorage.setItem('3dmc_fog_scale', String(Math.round(fogScale * 100))); } catch(e){}
}
export function setFogDepth(v){
  const n = Number(v);
  if (!isFinite(n)) return;
  fogDepth = Math.max(0, Math.min(1, n));
  try { localStorage.setItem('3dmc_fog_depth', String(Math.round(fogDepth * 100))); } catch(e){}
}
export function getFogSettings(){ return { scale: fogScale, depth: fogDepth }; }
export function getLightMultiplier(){ return lightMultiplier; }

let timeOfDay = 0.28;
const DAY_LENGTH = 420;

/* ============================================================
   时间 / 昼夜的只读接口（玩法层：床、夜间刷怪、阳光烧伤）
   ------------------------------------------------------------
   timeOfDay：0 = 日出，0.25 = 正午，0.5 = 日落，0.75 = 午夜
   ============================================================ */
export function getTimeOfDay(){ return timeOfDay; }

export function setTimeOfDay(t){
  const v = Number(t);
  if (!isFinite(v)) return;
  timeOfDay = ((v % 1) + 1) % 1;
}

/** 太阳高度：1 = 正午，0 = 地平线，-1 = 午夜 */
export function getSunHeight(){
  return Math.cos((timeOfDay - 0.25) * Math.PI * 2);
}

/** 0 = 深夜，1 = 白昼（和 updateSky 内的平滑一致） */
export function getDayFactor(){
  const t = Math.max(0, Math.min(1, (getSunHeight() + 0.18) / 0.43));
  return t * t * (3 - 2 * t);
}

export function isNight(){ return getDayFactor() < 0.3; }


/* ============================================================
   天空预设（mod / 生成器用）
   ============================================================ */
let _skyPreset = null;

/**
 * 设置天空预设。
 * @param {object|null} preset
 *   {
 *     frozen: true,              是否冻结时间（默认 false）
 *     timeOfDay: 0.75,           冻结时的时间 0~1
 *     timeScale: 1.0,            时间流速倍率（默认 1）
 *     topColor: 0x4a2a6a,        天空顶部
 *     bottomColor: 0xff8c42,     天空底部
 *     fogColor: 0x6a3a8a,        雾颜色
 *     fogNear: 20,               雾近（世界单位）
 *     fogFar: 200,               雾远
 *     sunColor: 0xffaa66,        阳光颜色
 *     sunIntensity: 0.6,         阳光强度（0~2）
 *     ambientIntensity: 0.35,    环境光强度
 *     hemiIntensity: 0.4,        半球光强度
 *   }
 */
export function setSkyPreset(preset){
  _skyPreset = preset || null;
}

/** 取当前天空预设（null 表示默认昼夜） */
export function getSkyPreset(){
  return _skyPreset;
}

/* ============================================================
   群系雾效（优先级低于天空预设，高于默认）
   ============================================================ */
let _biomeFog = null;

export function setBiomeFog(fog){
  _biomeFog = fog || null;
}
export function getBiomeFog(){
  return _biomeFog;
}

/* ============================================================
   阴影：质量 + 距离
   ------------------------------------------------------------
   · quality 控制贴图分辨率：off / low(512) / high(2048)
   · rangeBlocks 控制阴影相机覆盖半径（区块数，2~32）
   · 阴影相机每帧跟随玩家，位置量化到 texel 网格
   ============================================================ */
let shadowQuality = 'high';
let _shadowRange   = 4 * 16;
let _shadowMapSize = 2048;

export function setShadowQuality(q, rangeBlocks){
  shadowQuality = ['off', 'low', 'high'].includes(q) ? q : 'high';

  const rb = Math.max(2, Math.min(32, rangeBlocks || 4));
  _shadowRange = rb * 16;

  if (shadowQuality === 'off'){
    sunLight.castShadow = false;
    _shadowMapSize = 512;
  } else {
    sunLight.castShadow = true;
    _shadowMapSize = (shadowQuality === 'low') ? 512 : 2048;
  }

  sunLight.shadow.mapSize.width  = _shadowMapSize;
  sunLight.shadow.mapSize.height = _shadowMapSize;
  /* 软边宽度（texel）。低画质贴图小、texel 大，半径给大一点会糊成一片，
     所以按档位区分：high 2.0 / low 1.5。 */
  sunLight.shadow.radius = (shadowQuality === 'low') ? 1.5 : 2.0;

  const cam = sunLight.shadow.camera;
  cam.left   = -_shadowRange;
  cam.right  =  _shadowRange;
  cam.top    =  _shadowRange;
  cam.bottom = -_shadowRange;
  cam.near   = 0.5;
  cam.far    = Math.max(300, _shadowRange * 6);
  cam.updateProjectionMatrix();

  if (sunLight.shadow.map){
    sunLight.shadow.map.dispose();
    sunLight.shadow.map = null;
  }
  /* 改了分辨率 / 范围 / 开关都要立刻重画一次，否则要等下一次
     tickShadow 的 100ms 节拍，设置界面里会看到"改了没反应"。 */
  requestShadowUpdate();
}

export function getShadowQuality(){ return shadowQuality; }
export function getShadowRange(){ return _shadowRange; }
export function getShadowMapSize(){ return _shadowMapSize; }

/* ============================================================
   云
   ============================================================ */
let cloudQuality = 'high';

function makeCloudTexture(scale, seed, octaves, alpha){
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(S, S);
  const d = img.data;
  /* ★ 无缝平铺：每个八度的频率取整数，并用同周期做 wrap。
     否则贴图在 repeat 边界会直接切断云朵，出现一条条直线接缝。 */
  const base = Math.max(1, Math.round(scale));
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      let v = 0, amp = 1, f = 1, norm = 0;
      for (let o = 0; o < octaves; o++){
        const N = base * f;
        v += amp * tileNoise(x / S * N, y / S * N, seed + o * 131, N);
        norm += amp; amp *= 0.5; f *= 2;
      }
      v /= norm;
      const a = Math.max(0, Math.min(1, (v - 0.48) * 3.4)) * alpha;
      const i = (y * S + x) * 4;
      const shade = 210 + Math.min(45, v * 70);
      d[i] = shade; d[i+1] = shade; d[i+2] = Math.min(255, shade + 10);
      d[i+3] = a * 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function tileNoise(x, y, seed, N = 8){
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const wrap = n => ((n % N) + N) % N;
  const h = (a, b) => {
    let n = Math.imul(wrap(a) + 1, 374761393) ^ Math.imul(wrap(b) + 1, 668265263) ^ Math.imul(seed, 1274126177);
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  };
  const a = h(xi, yi), b = h(xi + 1, yi), c = h(xi, yi + 1), dd = h(xi + 1, yi + 1);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + dd * u) * v;
}

/* ---- 预烘焙云噪声（体积云 LUT）----
   把原来 shader 里每步计算的 2 次 3D 程序化噪声固化成 256² 无缝贴图：
   6 周期低频 + 18 周期高频，权重和原 shader 的 0.72 / 0.28 一致，
   这样 cloudMap 每个步进只剩 1 次纹理采样。 */
function makeCloudNoiseTexture(){
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(S, S);
  const d = img.data;
  function fbmTile(u, v, seed, N, oct){
    let sum = 0, amp = 1, f = 1, norm = 0;
    for (let o = 0; o < oct; o++){
      const NN = N * f;
      sum += amp * tileNoise(u * NN, v * NN, seed + o * 131, NN);
      norm += amp; amp *= 0.5; f *= 2;
    }
    return sum / norm;
  }
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      const u = x / S, v = y / S;
      let n = 0.72 * fbmTile(u, v, 5501, 6, 4)
            + 0.28 * fbmTile(u, v, 5502, 18, 3);
      /* ★ 烘焙时就把阈值算进覆盖度：
         远处 mip 过滤得到的是"柔和的云边"，而不是把噪声平均成 0.5
         再被阈值切成随机孔洞（之前远处云块破碎的原因）。 */
      n = smoothstep(0.525, 0.600, n);
      const g = Math.max(0, Math.min(255, Math.round(n * 255)));
      const i = (y * S + x) * 4;
      d[i] = d[i+1] = d[i+2] = g;
      d[i+3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.colorSpace = THREE.NoColorSpace;
  return t;
}
const cloudNoiseTex = makeCloudNoiseTexture();

const LOW_SPAN = 3600;
const LOW_REP  = 18;
const lowCloudTex = makeCloudTexture(7.0, 7001, 5, 0.95);
lowCloudTex.repeat.set(LOW_REP, LOW_REP);
const lowCloud = new THREE.Mesh(
  new THREE.PlaneGeometry(LOW_SPAN, LOW_SPAN),
  new THREE.MeshBasicMaterial({
    map: lowCloudTex, transparent: true, depthWrite: false,
    fog: false, opacity: 0.85, side: THREE.DoubleSide
  })
);
lowCloud.rotation.x = -Math.PI / 2;
lowCloud.renderOrder = -5;
lowCloud.visible = false;
scene.add(lowCloud);

/* ---- 方块云（Java 版思路：12×4×12 的实体云块，世界坐标固定） ---- */
const HIGH_CELL = 12;      // 每个云格 12 格宽
const CLOUD_THICK = 4;     // 所有云块同一厚度，云层只有一个高度
const HIGH_R    = 40;      // 半径 40 格 ≈ 480 格覆盖
const HIGH_COUNT_MAX = (HIGH_R * 2 + 1) * (HIGH_R * 2 + 1);
const highCloudGeo = new THREE.BoxGeometry(1, 1, 1);
/* 云块不参与场景光照：按面法线预烘一层明暗（顶面最亮、侧面次之、
   底面略暗），这样夜里也不会变成黑灰色。 */
(function bakeCloudShade(){
  const nrm = highCloudGeo.attributes.normal;
  const col = new Float32Array(nrm.count * 3);
  for (let i = 0; i < nrm.count; i++){
    const ny = nrm.getY(i);
    const s = ny > 0.5 ? 1.0 : (ny < -0.5 ? 0.80 : 0.90);
    col[i * 3] = s; col[i * 3 + 1] = s; col[i * 3 + 2] = s;
  }
  highCloudGeo.setAttribute('color', new THREE.BufferAttribute(col, 3));
})();
const highCloudMat = new THREE.MeshBasicMaterial({
  color: 0xf7fafd, vertexColors: true, fog: false
});
const highClouds = new THREE.InstancedMesh(highCloudGeo, highCloudMat, HIGH_COUNT_MAX);
highClouds.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
highClouds.frustumCulled = false;
highClouds.visible = false;
highClouds.count = 0;
scene.add(highClouds);

const _cloudDummy = new THREE.Object3D();
let _highBaseX = NaN, _highBaseZ = NaN;

function _cloudCellValue(ix, iz){
  const a = tileNoise(ix * 0.105, iz * 0.105, 9311, 4096);
  const b = tileNoise(ix * 0.24,  iz * 0.24,  9312, 4096);
  return a * 0.74 + b * 0.26;
}

/* 云格用"风坐标系"索引：实例位置固定为格坐标，整个 InstancedMesh
   每帧平移 wind，因此云是连续漂移的；只有玩家跨过一格才重建。
   每个云格就是 12×4×12 的独立方块（和 Java 版一致），不做合并、
   不加随机厚度 —— 云层严格只有一个高度，轮廓由噪声随机决定，
   连成一片片的像素化云片。 */
function _rebuildHighClouds(force, windX, windZ){
  const bx = Math.floor((camera.position.x - windX) / HIGH_CELL);
  const bz = Math.floor((camera.position.z - windZ) / HIGH_CELL);
  if (!force && bx === _highBaseX && bz === _highBaseZ) return;
  _highBaseX = bx; _highBaseZ = bz;

  let n = 0;
  const thick = Math.max(2, Math.min(16, Math.round(_cloudThickness / 6.5)));
  for (let dz = -HIGH_R; dz <= HIGH_R; dz++){
    const iz = bz + dz;
    for (let dx = -HIGH_R; dx <= HIGH_R; dx++){
      const ix = bx + dx;
      if (_cloudCellValue(ix, iz) < 0.575) continue;
      _cloudDummy.position.set(
        (ix + 0.5) * HIGH_CELL, thick * 0.5, (iz + 0.5) * HIGH_CELL
      );
      _cloudDummy.scale.set(HIGH_CELL, thick, HIGH_CELL);
      _cloudDummy.updateMatrix();
      highClouds.setMatrixAt(n++, _cloudDummy.matrix);
    }
  }
  highClouds.count = n;
  highClouds.instanceMatrix.needsUpdate = true;
}

/* ---- 体积云（ultra）：真正的 raymarching，不是贴图 ----
   一个跟随相机的代理球（BackSide），片元着色器沿视线在云层
   [uBottom, uTop] 这段 slab 里步进，实时采样 3D fbm 密度并做
   朝向太阳的自阴影。没有任何云贴图参与。 */
const VOL_STEPS = 72;
/* ★ 采样预算别浪费在"已经看不见的远距离"上。
   原来 slab 穿越长度上限 420，而云的淡出在 300~420 就完成了，
   等于最后 30% 的步进全打在全透明的空处 —— 纯浪费采样。
   上限收到 360 后，同样 72 步的间距从 5.83 格缩到 5.0 格（密度 +17%），
   代价只是 360 格以外的云更早融进天空雾（本来也快看不见）。 */
const VOL_MAX_DIST = 360;
/* 垂直密度剖面指数。原来 th 连乘 3 次 = th^8，只有云层正中间很薄一层
   有密度；72 步 × 每步 5 格的情况下大量视线会"穿过"这层薄壳采样不到，
   表现就是云体上的孔洞、移动时闪烁。降到 th^4 壳变厚、命中稳定，
   观感更接近 Complementary 的软边（想回旧效果把 4 改成 8）。 */
const VOL_VPROFILE_POW = 4;
/* 低于这个累积不透明度直接 discard，省掉天空区域的混合开销。
   原来 0.02，云边缘会"这块画、那块不画"硬跳变；降到 0.005 过渡连续。 */
const VOL_MIN_ALPHA = 0.005;
/* 云边细节层开关：1 = 多采一次小尺度噪波（边缘有绒毛感，但每次
   密度采样多一次纹理读取）；0 = 只有低频覆盖度（更省，但云边偏"剪出来"）。 */
const VOL_DETAIL = 1;
/* 侧面受光开关（1=开）：让云的朝光侧/背光侧有明暗差，是"立体感"的关键。
   代价：每个命中云的步进多两次基础覆盖度采样。 */
const VOL_SIDELIGHT = 1;
/* 求水平梯度时的采样间距（格）。云块约 12 格，取 2.5 格能得到平滑的法线 */
const _VOL_SIDE_EPS = 2.5;
/* 侧面受光对最终颜色的影响幅度（0=关掉效果，0.18≈明显但不夸张） */
const _VOL_SIDE_GAIN = 0.18;
/* 远处淡出（融进天空色）的起点，随 VOL_MAX_DIST 一起缩放；
   原来是 300/420 ≈ 0.714，这里取 0.8 让地平线附近的云更实一点。 */
const _VOL_FADE_START = (VOL_MAX_DIST * 0.8).toFixed(1);
/* 把 VOL_VPROFILE_POW 展开成连续乘法（只用乘法，pow() 精度和性能都更差） */
const _VOL_VPROFILE_GLSL = (() => {
  const times = Math.max(1, Math.round(Math.log2(VOL_VPROFILE_POW)));
  let s = '';
  for (let i = 0; i < times; i++) s += 'th = th * th; ';
  return s;
})();
/* 云层厚度（格）。ultra 直接作为体积层厚度；high 换算成单块云高度。 */
let _cloudThickness = 26;
export function setCloudThickness(v){
  const n = Number(v);
  if (!isFinite(n)) return _cloudThickness;
  _cloudThickness = Math.max(6, Math.min(60, Math.round(n)));
  _highBaseX = NaN;          /* 方块云按新厚度重建 */
  return _cloudThickness;
}
export function getCloudThickness(){ return _cloudThickness; }
export const volCloudMat = new THREE.ShaderMaterial({
  side: THREE.BackSide, transparent: true, depthWrite: false, fog: false,
  /* ★ 输出的是预乘 alpha（col 已乘过不透明度），要用预乘混合，
     否则 NormalBlending 会再乘一次 alpha，云边发黑。 */
  blending: THREE.CustomBlending,
  blendEquation: THREE.AddEquation,
  blendSrc: THREE.OneFactor,
  blendDst: THREE.OneMinusSrcAlphaFactor,
  blendSrcAlpha: THREE.OneFactor,
  blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
  uniforms: {
    uSunDir: { value: new THREE.Vector3(0, 1, 0) },
    uTime:   { value: 0 },
    uBottom: { value: 200 },
    uTop:    { value: 340 },
    uSunCol: { value: new THREE.Color(0xfff6e2) },
    uSkyCol: { value: new THREE.Color(0x93b2d8) },
    uCloudTint: { value: new THREE.Color(0xf7fafd) },
    uNoiseTex: { value: cloudNoiseTex }
  },
  vertexShader: `
    varying vec3 vWorld;
    void main(){
      vec4 wp = modelMatrix * vec4(position, 1.0);
      vWorld = wp.xyz;
      gl_Position = projectionMatrix * viewMatrix * wp;
    }`,
  fragmentShader: `
    precision highp float;
    #define VOL_DETAIL ${VOL_DETAIL}
    #define VOL_SIDELIGHT ${VOL_SIDELIGHT}
    uniform vec3 uSunDir, uSunCol, uSkyCol, uCloudTint;
    uniform float uTime, uBottom, uTop;
    uniform sampler2D uNoiseTex;
    varying vec3 vWorld;

    /* 抖动：只和像素位置有关，不随时间变化（时间抖动会让噪点变成每帧
       都变的沙粒，看起来就是"糊"）。具体用哪个噪声见 main() 里的 IGN。 */
    /* ---- 圆角格坐标 ----
       把连续 xz 压回格子：格内取整、格边平滑过渡。
       于是 12×12 的方块云在交界处变成圆角 —— 这就是
       "方块形状 + 体积云外观"的来源。 */
    vec2 roundedXZ(vec2 pos, float r){
      vec2 i = floor(pos);
      vec2 f = fract(pos);
      f = smoothstep(0.5 - r, 0.5 + r, f);
      return i + f;
    }
    /* 2D 云图：覆盖度已烘焙进贴图（阈值在生成时应用），这里只查表。
       风漂移 = 与 low/high 云一致的 1.15 / 0.35 格每秒，
       换算到 UV 空间要除以 12×32 格。 */
    /* 基础覆盖度（低频，决定云的大形状） */
    float cloudMap(vec2 xz){
      vec2 g = roundedXZ(xz / 12.0, 0.125);
      vec2 w = vec2(uTime * 0.002995, uTime * 0.000912);
      return texture2D(uNoiseTex, g * 0.03125 + w).r;
    }
    #if VOL_DETAIL > 0
      /* ★ 细节层：只用来"啃"边缘，不参与覆盖度本身。
         两个关键点（上一版踩过的坑）：
           1) 漂移速度必须和基础层**完全相同**。上一版写了 w * 2.3，
              它就以 2.3 倍速度自己飘 —— 看起来就是天上另有一层
              "很淡、还在动"的云，和正常的白云交错，非常乱。
           2) 只能改动阈值，不能混进覆盖度。混进去会让基础覆盖度
              略低于阈值的地方冒出一层半透明薄纱（那些"接近看不见
              的淡云"），也是一层假图案。
         现在它只让同一朵云的边缘变得毛糙。 */
      float cloudDetail(vec2 xz){
        vec2 g = roundedXZ(xz / 12.0, 0.125);
        vec2 w = vec2(uTime * 0.002995, uTime * 0.000912);
        return texture2D(uNoiseTex, g * 0.09375 + w).r;
      }
    #endif
    /* 只查基础覆盖度（不含细节层），给太阳方向的自阴影用：
       阴影只需要大形状，省掉每次采样的额外纹理读取。 */
    float cloudMapBase(vec2 xz){
      vec2 g = roundedXZ(xz / 12.0, 0.125);
      vec2 w = vec2(uTime * 0.002995, uTime * 0.000912);
      return texture2D(uNoiseTex, g * 0.03125 + w).r;
    }
    /* 厚度判定：越靠近云层中段越容易算作云，上下边缘收薄。
       层很薄（10 格）却有体积感，靠的就是这一条。
       edgeW = 边缘过渡宽度：
         · 固定值时，远处的云边投影到屏幕上只剩一两个像素 →
           边缘发硬、锯齿、移动时闪烁（"边边锯齿分明"就是这个）；
         · 所以按到相机的距离放宽，让它屏幕上的视觉厚度大致恒定。 */
    float cloudDensity(vec3 p, float edgeW, out float hgt){
      float halfH = (uTop - uBottom) * 0.5;
      float cy    = (uTop + uBottom) * 0.5;
      hgt = clamp((p.y - uBottom) / (uTop - uBottom), 0.0, 1.0);
      float dy = abs(p.y - cy);
      if (dy > halfH) return 0.0;

      float th = clamp(dy / halfH, 0.001, 0.999);
      ${_VOL_VPROFILE_GLSL}
      /* 垂直方向轻微错位，加厚后不至于变成一根根云柱 */
      vec2 off = vec2(sin(p.y * 0.21), cos(p.y * 0.19)) * 1.8;
      vec2 q = p.xz + off;
      float m = cloudMap(q);
      float edge = th * 0.5 + 0.25;
      #if VOL_DETAIL > 0
        /* 小幅度侵蚀阈值（±0.045，和 edgeW 同量级），边缘毛糙即可 */
        edge += (cloudDetail(q) - 0.5) * 0.09;
      #endif
      return smoothstep(edge - edgeW, edge + edgeW, m);
    }
    /* 自阴影采样：基础覆盖度 + 垂直剖面，不带细节层 */
    float cloudShadowDensity(vec3 p, float edgeW){
      float halfH = (uTop - uBottom) * 0.5;
      float cy    = (uTop + uBottom) * 0.5;
      float dy = abs(p.y - cy);
      if (dy > halfH) return 0.0;
      float th = clamp(dy / halfH, 0.001, 0.999);
      ${_VOL_VPROFILE_GLSL}
      vec2 off = vec2(sin(p.y * 0.21), cos(p.y * 0.19)) * 1.8;
      float m = cloudMapBase(p.xz + off);
      float edge = th * 0.5 + 0.25;
      return smoothstep(edge - edgeW, edge + edgeW, m);
    }
    #if VOL_SIDELIGHT > 0
      /* ★ 侧面受光：用覆盖度在水平方向的梯度当"朝外法线"。
         原来云的颜色只由高度 hgt 决定（shade），所以一朵云的侧面和
         底面颜色完全一样，看上去就是一块被剪出来的平板 ——
         这就是"没有立体感"的直接原因。
         梯度指向覆盖度增长的方向，取反就是云的朝外法线；再和太阳的
         水平方向点乘，朝太阳那侧亮、背光那侧暗，立刻有体积。
         只读基础覆盖度（不含细节层），两次采样。 */
      float cloudSideLight(vec2 xz){
        float c  = cloudMapBase(xz);
        float gx = cloudMapBase(xz + vec2(${_VOL_SIDE_EPS}, 0.0)) - c;
        float gz = cloudMapBase(xz + vec2(0.0, ${_VOL_SIDE_EPS})) - c;
        vec2 n = vec2(-gx, -gz);
        float nl = length(n);
        vec2 sh = uSunDir.xz;
        float sl = length(sh);
        if (nl < 1e-5 || sl < 1e-5) return 0.5;
        return dot(n / nl, sh / sl) * 0.5 + 0.5;
      }
    #endif

    void main(){
      vec3 ro = cameraPosition;
      vec3 rd = normalize(vWorld - ro);

      /* 与水平云层 slab 求交；相机在层内时从 0 开始 */
      float t0, t1;
      if (abs(rd.y) < 1e-5){
        if (ro.y < uBottom || ro.y > uTop) discard;
        t0 = 0.0; t1 = ${VOL_MAX_DIST}.0;
      } else {
        float ta = (uBottom - ro.y) / rd.y;
        float tb = (uTop - ro.y) / rd.y;
        t0 = max(min(ta, tb), 0.0);
        t1 = min(max(ta, tb), ${VOL_MAX_DIST}.0);
      }
      if (t1 <= t0) discard;

      float dt = (t1 - t0) / ${VOL_STEPS}.0;
      /* ★ 抖动起点：消掉分层带（banding）。
         从 4×4 Bayer 换成 interleaved gradient noise —— Bayer 只有 16 个
         离散相位，而且是有规律的方块图案，半分辨率放大后肉眼能看出网点；
         IGN 在空间上分布更均匀、没有方向性，同样的采样的噪点更"细"，
         再叠上 TAA/双线性放大就基本看不出来了。仍然是静止图案，不会闪。 */
      float jitter = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
      float t = t0 + jitter * dt;

      vec3 col = vec3(0.0);
      float hgt = 0.0;
      float acc = 0.0;

      for (int i = 0; i < ${VOL_STEPS}; i++){
        vec3 p = ro + rd * t;
        /* 边缘宽度随距离放宽（见 cloudDensity 的注释）：
           近处 0.055 保持轮廓锐利，300 格外放到 0.13 消掉锯齿。 */
        float edgeW = 0.055 + 0.075 * clamp(t / 300.0, 0.0, 1.0);
        float dens = cloudDensity(p, edgeW, hgt);
        if (dens > 0.02){
          float shade = pow(max(hgt, 0.001), 0.8);

          /* 朝太阳方向采 3 格，看是否被别的云挡住 → 云底发灰。
             2 格太稀，只够分出"有遮挡/没遮挡"，云体内部几乎没有层次，
             看起来就是一坨扁的；3 格能拉开明暗梯度，立体感明显一些。
             阴影采样用不含细节层的覆盖度，省掉每次多读一次纹理。 */
          float od = 0.0;
          vec3 sp = p;
          for (int j = 0; j < 3; j++){
            sp += uSunDir * 3.0;
            od += cloudShadowDensity(sp, 0.07);
          }
          /* 归一化回原来的量级（3 格采样 × 0.37 ≈ 原来 2 格 × 0.55） */
          float light = clamp(1.0 - od * 0.37, 0.0, 1.0);

          vec3 lit = uSkyCol * (0.78 - 0.30 * shade)
                   + uSunCol * 0.62 * (0.10 + 0.90 * shade) * (0.25 + 0.75 * light);
          #if VOL_SIDELIGHT > 0
            /* 侧面明暗：朝太阳的一侧更亮、背光侧更暗。
               只在被太阳照到的地方（light 越大）加，阴影区不加强，
               否则云底会出现不自然的亮边。 */
            float side = cloudSideLight(p.xz);
            lit *= 1.0 + (side - 0.5) * 2.0 * ${_VOL_SIDE_GAIN} * (0.3 + 0.7 * light);
          #endif
          /* 白天/夜晚/雨天统一云色，避免夜里云还是纯白 */
          lit *= uCloudTint;

          /* 远处和天空融合，避免代理球边界出现硬切 */
          float dFade = clamp(t / ${VOL_MAX_DIST}.0, 0.0, 1.0);
          lit = mix(lit, uSkyCol, dFade * 0.75);

          /* ★ 沿光线累积不透明度，而不是"第一次命中就整块上色"：
             稀疏区域和远处淡出区不会因为逐像素命中/未命中不同
             而出现大量孔洞和噪点。 */
          float stepA = 1.0 - exp(-dens * dt * 0.26);
          stepA *= 1.0 - smoothstep(${_VOL_FADE_START}, ${VOL_MAX_DIST}.0, t);
          col += (1.0 - acc) * stepA * lit;
          acc += (1.0 - acc) * stepA;
          if (acc > 0.97) break;
        }
        t += dt;
      }

      if (acc < ${VOL_MIN_ALPHA}) discard;
      gl_FragColor = vec4(col, acc);
    }`
});
export const volClouds = new THREE.Mesh(
  new THREE.SphereGeometry(850, 32, 16),
  volCloudMat
);
volClouds.frustumCulled = false;
volClouds.renderOrder = -4;
volClouds.visible = false;
cloudScene.add(volClouds);

let cloudDrift = 0;
export function setCloudQuality(q){
  cloudQuality = ['off', 'low', 'high', 'ultra'].includes(q) ? q : 'high';
  lowCloud.visible   = cloudQuality === 'low';
  highClouds.visible = cloudQuality === 'high';
  volClouds.visible  = cloudQuality === 'ultra';
  if (cloudQuality === 'high'){
    _rebuildHighClouds(true, cloudDrift * 1.15, cloudDrift * 0.35);
  }
  /* 档位切换后历史帧已经没意义，丢掉避免残影 */
  resetCloudTAA();
}
export function getCloudQuality(){ return cloudQuality; }

/* ============================================================
   体积云离屏渲染（半分辨率）
   ------------------------------------------------------------
   ultra 云不再直接画进主场景，而是渲染到 1/2 分辨率的 RT，
   再由天空穹顶按屏幕 UV 采样合成 —— 像素量直接降到 1/4。
   ============================================================ */
export function renderCloudPass(){
  if (!renderer || cloudQuality !== 'ultra' || !volClouds.visible){
    skyUniforms.uCloudOn.value = 0;
    setCloudLayer(null);       /* 告诉 bloom：这一帧没有云要合成 */
    return;
  }
  renderer.getDrawingBufferSize(_cloudBufSize);
  const w = Math.max(1, Math.floor(_cloudBufSize.x * 0.5));
  const h = Math.max(1, Math.floor(_cloudBufSize.y * 0.5));
  if (w !== _cloudRTW || h !== _cloudRTH){
    cloudRT.setSize(w, h);
    _cloudRTW = w; _cloudRTH = h;
  }
  skyUniforms.uCloudRes.value.set(_cloudBufSize.x, _cloudBufSize.y);
  skyUniforms.uCloudOn.value = 1;

  const prevTarget = renderer.getRenderTarget();
  const prevAlpha = renderer.getClearAlpha();
  renderer.getClearColor(_prevClearCol);

  /* ★ 这次 renderer.render(cloudScene) 必须关掉阴影。
     两个原因：
       1) cloudScene 里没有任何投射阴影的东西，开着等于白算一遍 shadow pass；
       2) 更关键 —— Three 的 WebGLShadowMap.render() 是无条件调用的，
          shadowMap.needsUpdate 会被这次 render 消费掉，主场景那一次
          就再也不会刷新阴影了（阴影会永久冻住）。 */
  const prevShadowEnabled = renderer.shadowMap.enabled;
  renderer.shadowMap.enabled = false;

  renderer.setRenderTarget(cloudRT);
  renderer.setClearColor(0x000000, 0);
  renderer.render(cloudScene, camera);

  renderer.shadowMap.enabled = prevShadowEnabled;

  /* ★ 时域累积（TAA）：单帧 72 步的半分辨率 raymarch 边缘必然带采样噪点，
     帧与帧之间还会抖。把历史帧重投影后混进来，等效采样数翻好几倍，
     边缘明显更顺、噪声收敛。 */
  const accumulated = _accumulateClouds(w, h);

  renderer.setRenderTarget(prevTarget);
  renderer.setClearColor(_prevClearCol, prevAlpha);

  const tex = accumulated || cloudRT.texture;
  skyUniforms.uCloudTex.value = tex;

  /* ★ 谁来合成这层云？
     · bloom 开着 → 交给它的最终 pass，那里有场景深度，云可以被地形遮挡，
       也能在云层以上正确盖住地面（以前做不到，因为天空穹顶只画在没几何的像素上）
     · bloom 关掉 → 退回天空穹顶合成（否则云会直接消失） */
  if (isBloomActive()){
    setCloudLayer({
      tex,
      bottom: volCloudMat.uniforms.uBottom.value,
      top:    volCloudMat.uniforms.uTop.value
    });
    skyUniforms.uCloudOn.value = 0;
  } else {
    setCloudLayer(null);
    skyUniforms.uCloudOn.value = 1;
  }
}

/* ============================================================
   云的时域累积（TAA）
   ------------------------------------------------------------
   思路和 cloud-pass.js 里那份一样，但只保留「累积」这一环，
   因为遮挡合成还挂在天空穹顶上（见文件末尾的说明）。

   · 重投影用「当前视线与云层 slab 的交点」而不是固定距离：
     云都在同一层薄 slab 里，这个交点是解析可得的，比猜一个
     固定距离准确得多，相机转动时不会把云拽偏。
   · 混历史之前先做 3×3 邻域钳制：把历史值压进当前帧邻域的
     min/max 里，云飘走/新出现的地方就不会留拖影。
   · 差异越大越偏向当前帧，进一步压拖影。
   ============================================================ */
const CLOUD_TAA_BLEND = 0.16;     /* 每帧混入当前帧的比例，越小越稳但越钝 */

const _cloudHist = [null, null];
let _histIdx = 0;
let _histW = 0, _histH = 0;
let _histValid = false;

const _prevViewProj = new THREE.Matrix4();
const _curViewProj  = new THREE.Matrix4();
const _invViewProj  = new THREE.Matrix4();
let _prevProjValid = false;

const _taaCam = new THREE.Camera();
const _taaScene = new THREE.Scene();
const _taaMat = new THREE.ShaderMaterial({
  uniforms: {
    uCur:         { value: null },
    uHist:        { value: null },
    uInvViewProj: { value: new THREE.Matrix4() },
    uPrevViewProj:{ value: new THREE.Matrix4() },
    uCamPos:      { value: new THREE.Vector3() },
    uBottom:      { value: 200 },
    uTop:         { value: 340 },
    uBlend:       { value: CLOUD_TAA_BLEND },
    uReset:       { value: 1 },
    uResolution:  { value: new THREE.Vector2(1, 1) }
  },
  vertexShader: `
    varying vec2 vUv;
    void main(){
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }`,
  fragmentShader: `
    uniform sampler2D uCur, uHist;
    uniform mat4 uInvViewProj, uPrevViewProj;
    uniform vec3 uCamPos;
    uniform float uBottom, uTop, uBlend, uReset;
    uniform vec2 uResolution;
    varying vec2 vUv;

    void main(){
      vec4 cur = texture2D(uCur, vUv);

      if (uReset > 0.5){
        gl_FragColor = cur;
        return;
      }

      /* 当前像素的视线方向（世界空间） */
      vec4 ndc = vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
      vec4 wp = uInvViewProj * ndc;
      wp.xyz /= wp.w;
      vec3 dir = normalize(wp.xyz - uCamPos);

      /* 与云层 slab 求交，取中点作为该像素"云所在的位置" */
      float tMid;
      if (abs(dir.y) < 1e-4){
        tMid = 260.0;
      } else {
        float ta = (uBottom - uCamPos.y) / dir.y;
        float tb = (uTop    - uCamPos.y) / dir.y;
        tMid = max((ta + tb) * 0.5, 1.0);
      }
      vec3 P = uCamPos + dir * tMid;

      vec4 pc = uPrevViewProj * vec4(P, 1.0);
      vec2 puv = (pc.w > 1e-4) ? (pc.xy / pc.w * 0.5 + 0.5) : vec2(-1.0);

      bool inView = puv.x > 0.0 && puv.x < 1.0 && puv.y > 0.0 && puv.y < 1.0;
      if (!inView){
        gl_FragColor = cur;
        return;
      }

      /* 3×3 邻域钳制：历史值不能跑出当前帧邻域的范围 */
      vec2 texel = 1.0 / uResolution;
      vec4 mn = cur;
      vec4 mx = cur;
      for (int y = -1; y <= 1; y++){
        for (int x = -1; x <= 1; x++){
          vec4 s = texture2D(uCur, vUv + vec2(float(x), float(y)) * texel);
          mn = min(mn, s);
          mx = max(mx, s);
        }
      }
      vec4 hist = clamp(texture2D(uHist, puv), mn, mx);

      /* 差异越大越信当前帧（云在动 / 新出现的云） */
      float diff = length(cur.rgb - hist.rgb) + abs(cur.a - hist.a);
      float k = clamp(uBlend + diff * 1.5, uBlend, 1.0);
      gl_FragColor = mix(hist, cur, k);
    }`,
  depthTest: false, depthWrite: false
});
{
  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), _taaMat);
  quad.frustumCulled = false;
  _taaScene.add(quad);
}

/** 渲染一帧累积，返回要采样的纹理（失败时返回 null，调用方退回原始 RT） */
function _accumulateClouds(w, h){
  try {
    if (!renderer || w < 2 || h < 2) return null;

    if (w !== _histW || h !== _histH || !_cloudHist[0]){
      if (_cloudHist[0]){ _cloudHist[0].dispose(); _cloudHist[1].dispose(); }
      const mk = () => new THREE.WebGLRenderTarget(w, h, {
        minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
        format: THREE.RGBAFormat, type: THREE.UnsignedByteType,
        depthBuffer: false, stencilBuffer: false, generateMipmaps: false
      });
      _cloudHist[0] = mk();
      _cloudHist[1] = mk();
      _histW = w; _histH = h;
      _histValid = false;
    }

    /* 当前帧的 viewProj / 逆矩阵 */
    camera.updateMatrixWorld();
    _curViewProj.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    _invViewProj.copy(_curViewProj).invert();

    const u = _taaMat.uniforms;
    u.uCur.value = cloudRT.texture;
    u.uHist.value = _cloudHist[_histIdx].texture;
    u.uInvViewProj.value.copy(_invViewProj);
    u.uPrevViewProj.value.copy(_prevProjValid ? _prevViewProj : _curViewProj);
    u.uCamPos.value.copy(camera.position);
    u.uBottom.value = volCloudMat.uniforms.uBottom.value;
    u.uTop.value    = volCloudMat.uniforms.uTop.value;
    u.uResolution.value.set(w, h);
    u.uReset.value  = _histValid ? 0 : 1;

    const dst = _cloudHist[_histIdx ^ 1];
    const prevTarget = renderer.getRenderTarget();
    const prevShadow = renderer.shadowMap.enabled;
    renderer.shadowMap.enabled = false;

    renderer.setRenderTarget(dst);
    renderer.render(_taaScene, _taaCam);

    renderer.shadowMap.enabled = prevShadow;
    renderer.setRenderTarget(prevTarget);

    _histIdx ^= 1;
    _histValid = true;
    _prevViewProj.copy(_curViewProj);
    _prevProjValid = true;
    return dst.texture;
  } catch(e){
    /* TAA 只是锦上添花，出错就退回不累积，绝不能因此让云消失 */
    _histValid = false;
    _prevProjValid = false;
    return null;
  }
}

/** 换档 / 换世界时丢掉历史，避免带上旧场景的残影 */
export function resetCloudTAA(){
  _histValid = false;
  _prevProjValid = false;
}


const _wrap01 = v => ((v % 1) + 1) % 1;

/* ---- 云色：白天亮白、夜晚暗蓝、雨天灰、黄昏偏暖 ----
   三种云（low / high / ultra）共用同一套色调，避免夜里云还是纯白。 */
const _CLOUD_DAY    = new THREE.Color(0xf7fafd);
const _CLOUD_NIGHT  = new THREE.Color(0x202a40);
const _CLOUD_RAIN   = new THREE.Color(0x8d97a6);
const _CLOUD_SUNSET = new THREE.Color(0xffb08a);
const _cloudTint    = new THREE.Color();
const _cloudRainCol = new THREE.Color();

function _cloudTintAt(dayF, sunsetF){
  const rain = Math.max(0, Math.min(1, getWeatherIntensity()));
  _cloudTint.copy(_CLOUD_NIGHT).lerp(_CLOUD_DAY, dayF);
  /* 雨云灰，夜里再压暗，不能比夜空还亮 */
  _cloudRainCol.copy(_CLOUD_RAIN).multiplyScalar(0.30 + 0.70 * dayF);
  _cloudTint.lerp(_cloudRainCol, Math.min(1, rain * 0.85));
  _cloudTint.lerp(_CLOUD_SUNSET, sunsetF * 0.30 * (1 - rain));
  return _cloudTint;
}

function updateClouds(dt, dayF, sunsetF){
  cloudDrift += dt;
  const cy = cloudHeight();
  const rain = Math.max(0, Math.min(1, getWeatherIntensity()));
  const tint = _cloudTintAt(dayF, sunsetF);
  lowCloud.material.color.copy(tint);
  highCloudMat.color.copy(tint);
  volCloudMat.uniforms.uCloudTint.value.copy(tint);
  /* 全局风：云按世界坐标漂移，而不是整片跟着摄像机走 */
  const windX = cloudDrift * 1.15;
  const windZ = cloudDrift * 0.35;
  const cx = camera.position.x;
  const cz = camera.position.z;

  if (cloudQuality === 'low'){
    const tile = LOW_SPAN / LOW_REP;
    lowCloud.position.set(cx, cy, cz);
    /* 阴雨天云层更厚一点，避免灰云看起来太透 */
    lowCloud.material.opacity = 0.85 + 0.10 * rain;
    /* 贴图周期 = 一个 tile；offset 必须抵消摄像机位移，
       否则云会跟着镜头一起动（看起来像"云被区块管着"）。 */
    lowCloudTex.offset.set(_wrap01((cx - windX) / tile), _wrap01((cz - windZ) / tile));
  } else if (cloudQuality === 'high'){
    highClouds.position.set(windX, cy, windZ);
    _rebuildHighClouds(false, windX, windZ);
  } else if (cloudQuality === 'ultra'){
    /* ★ 代理球以相机为中心：原来按云层高度居中，抬头时球的出口距离
       会到 850+174≈1024，超过相机远裁面 1000，天顶那片被裁掉。 */
    volClouds.position.copy(camera.position);
    const u = volCloudMat.uniforms;
    u.uTime.value = cloudDrift;
    u.uBottom.value = cy;
    u.uTop.value = cy + _cloudThickness;
    u.uSunDir.value.copy(sunDir);
    u.uSunCol.value.copy(skyUniforms.uSunColor.value);
    u.uSkyCol.value.copy(fogCol);
  }
}

/* ============================================================
   地下雾
   ------------------------------------------------------------
   眼睛位置的天光值只用来驱动雾，不再缩放 sun / hemi / ambient
   这些全局灯光。
   ★ 旧逻辑按眼睛曝光把全局环境光压到 20%，进洞后又补到 π，
     结果光线跟着玩家走：站洞口洞里黑，走进洞后洞口反而过曝、
     里边也一起变亮，和「洞穴应该更暗」完全相反。
   ★ 洞穴的暗必须由区块顶点烘焙的 skyLight 决定（洞内 skyL=0
     → 顶点色接近 0）。全局灯光与玩家位置无关，这样从洞里看
     洞口的阳光地形也不会被一起压暗。
   ============================================================ */
/* 地下雾过渡因子：0=露天，1=完全封闭的洞穴 */
let _caveFogFactor = 0;

/* 地下雾色：接近纯黑，带一点冷色，避免死黑 */
const CAVE_FOG_COL = new THREE.Color(0x030407);

function _skyExposureAt(wx, wy, wz){
  return getSkyLightAt(wx, wy, wz);
}

/* ============================================================
   每帧天空更新（支持预设覆盖）
   ============================================================ */
export function updateSky(dt, renderDist){
  /* ---- ① 更新 timeOfDay ---- */
  if (_skyPreset && _skyPreset.frozen){
    if (typeof _skyPreset.timeOfDay === 'number'){
      timeOfDay = _skyPreset.timeOfDay;
    }
  } else {
    const scale = (_skyPreset && typeof _skyPreset.timeScale === 'number')
      ? _skyPreset.timeScale : 1.0;
    timeOfDay = (timeOfDay + dt / DAY_LENGTH * scale) % 1;
  }

  const a = (timeOfDay - 0.25) * Math.PI * 2;
  sunDir.set(Math.sin(a) * 0.42, Math.cos(a), Math.sin(a) * 0.88).normalize();

  const sunH = sunDir.y;
  const dayF = smoothstep(-0.18, 0.25, sunH);
  const sunsetF = Math.max(0, 1 - Math.abs(sunH) * 4) * dayF;

  /* ---- 地下雾过渡：只看眼睛处的天光，不改全局灯光 ---- */
  const eyeX = Math.floor(camera.position.x);
  const eyeY = Math.floor(camera.position.y);
  const eyeZ = Math.floor(camera.position.z);
  const exposure = _skyExposureAt(eyeX, eyeY, eyeZ);
  const exposedF = smoothstep(0, 8, exposure);

  const targetCaveFog = 1 - exposedF;
  if (dt > 0) _caveFogFactor += (targetCaveFog - _caveFogFactor) * (1 - Math.exp(-dt * 5));
  else        _caveFogFactor = targetCaveFog;

  /* ---- ② 默认颜色 ---- */
  const sunDay   = new THREE.Color(1.0, 0.96, 0.88);
  const sunSet   = new THREE.Color(1.0, 0.60, 0.28);
  const sunNight = new THREE.Color(0.10, 0.12, 0.24);
  const sc = sunNight.clone().lerp(sunDay, dayF).lerp(sunSet, sunsetF * 0.75);
  const sunStrength = 0.22 + dayF * 1.15;

  const ambDay   = new THREE.Color(0.42, 0.50, 0.62);
  const ambNight = new THREE.Color(0.09, 0.11, 0.20);
  const amb = ambNight.clone().lerp(ambDay, dayF);
  amb.lerp(new THREE.Color(0.58, 0.40, 0.30), sunsetF * 0.35);

  const topNight = new THREE.Color(0x0a1028);
  const topDay   = new THREE.Color(0x7ea6d4);
  const botNight = new THREE.Color(0x141c36);
  const botDay   = new THREE.Color(0xd8e4ec);
  let skyTop = topNight.clone().lerp(topDay, dayF);
  let skyBot = botNight.clone().lerp(botDay, dayF);
  skyBot.lerp(new THREE.Color(0xff9a55), sunsetF * 0.65);

  let fogColorVal = skyBot.clone();
  let sunColorVal = new THREE.Color(1, 0.85 + sunsetF * 0.08, 0.62 + (1 - sunsetF) * 0.30);
  let sunIntensity  = sunStrength;
  let ambIntensity  = 0.55 * (0.4 + dayF * 0.8);
  let hemiIntensity = 0.45 * (0.4 + dayF * 0.8);

  /* ---- ③ 天空预设覆盖 ---- */
  if (_skyPreset){
    if (_skyPreset.topColor !== undefined)
      skyTop = new THREE.Color(_skyPreset.topColor);
    if (_skyPreset.bottomColor !== undefined)
      skyBot = new THREE.Color(_skyPreset.bottomColor);
    if (_skyPreset.fogColor !== undefined)
      fogColorVal = new THREE.Color(_skyPreset.fogColor);
    if (_skyPreset.sunColor !== undefined)
      sunColorVal = new THREE.Color(_skyPreset.sunColor);
    if (typeof _skyPreset.sunIntensity === 'number')
      sunIntensity = _skyPreset.sunIntensity;
    if (typeof _skyPreset.ambientIntensity === 'number')
      ambIntensity = _skyPreset.ambientIntensity;
    if (typeof _skyPreset.hemiIntensity === 'number')
      hemiIntensity = _skyPreset.hemiIntensity;
  }

  /* ---- ④ 写入 uniforms ---- */
  skyUniforms.uTop.value.copy(skyTop);
  skyUniforms.uBottom.value.copy(skyBot);
  skyUniforms.uSunDir.value.copy(sunDir);
  skyUniforms.uSunColor.value.copy(sunColorVal);
  skyUniforms.uLinearize.value = isBloomActive() ? 1 : 0;

  fogCol.copy(fogColorVal);

  /* ---- ⑤ 水下 / 预设 / 群系雾 ---- */
  const headBlock = BLOCKS[getBlockWorld(
    Math.floor(camera.position.x),
    Math.floor(camera.position.y),
    Math.floor(camera.position.z)
  )];
  const underwater = isWaterLike(headBlock);

  const farBase = renderDist * 16;
  let fogNear, fogFar;
  const fColor = fogCol.clone();

  if (underwater){
    fColor.setRGB(0.06, 0.24, 0.42);
    fogNear = 0.5;
    fogFar  = 18;
  } else if (_skyPreset && (_skyPreset.fogNear || _skyPreset.fogFar)){
    fogNear = _skyPreset.fogNear || 30;
    fogFar  = _skyPreset.fogFar   || 200;
  } else if (_biomeFog){
    fColor.set(_biomeFog.color || 0xc8d8e8);
    fogNear = _biomeFog.near || 30;
    fogFar  = _biomeFog.far  || 200;
  } else {
    fogNear = farBase * 0.50;
    fogFar  = farBase * 0.98;
  }

  /* ---- 地下雾：颜色压黑 + 距离拉近，遮住洞内远处漏光 ----
     用眼睛处的天光做过渡，只影响雾；不改全局灯光。
     不按高度判断：坑底、开窗房间、洞口都不会被误判成洞穴。 */
  /* ---- 玩家可调：雾距倍率（水下雾不参与，保持紧凑） ---- */
  if (!underwater){
    fogNear *= fogScale;
    fogFar  *= fogScale;
  }

  const caveF = underwater ? 0 : _caveFogFactor;
  if (caveF > 0.01){
    /* 颜色按 caveF 放大 mix，避免半进洞时只混出白灰，要的是黑灰 */
    const k = Math.min(1, caveF * 1.6 * fogDepth);
    fColor.lerp(CAVE_FOG_COL, k);
    fogNear *= 1 - 0.65 * caveF;
    fogFar  *= 1 - 0.55 * caveF;
  }

  scene.fog = new THREE.Fog(fColor, fogNear, fogFar);

  /* ---- ⑥ 光照 ---- */
  sunLight.color.copy(sc);
  sunLight.intensity = sunIntensity * (underwater ? 0.5 : 1.0) * lightMultiplier;

  /* ---- ⑦ 阴影相机跟随玩家，位置量化到 texel 网格 ---- */
  if (sunLight.castShadow && _shadowRange > 0){
    const texel = (_shadowRange * 2) / Math.max(1, _shadowMapSize);
    const tx = Math.round(camera.position.x / texel) * texel;
    const ty = Math.round(camera.position.y / texel) * texel;
    const tz = Math.round(camera.position.z / texel) * texel;

    sunLight.target.position.set(tx, ty, tz);
    sunLight.position.copy(sunLight.target.position)
             .addScaledVector(sunDir, _shadowRange * 3);
  } else {
    sunLight.position.copy(camera.position).addScaledVector(sunDir, 120);
    sunLight.target.position.copy(camera.position);
  }
  sunLight.target.updateMatrixWorld();

  ambientLight.color.copy(amb);
  ambientLight.intensity = ambIntensity * (underwater ? 0.65 : 1.0) * lightMultiplier;
  hemiLight.intensity = hemiIntensity * (underwater ? 0.45 : 1.0) * lightMultiplier;

  /* ---- ⑧ 云 ---- */
  updateClouds(dt, dayF, sunsetF);
  if (_skyPreset && typeof _skyPreset.cloudOpacity === 'number'){
    if (lowCloud.material) lowCloud.material.opacity = _skyPreset.cloudOpacity;
  }
}