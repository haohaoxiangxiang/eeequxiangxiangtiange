/* ============================================================
   dynamic-light.js —— 移动光源调度器（点光源 / 体素光 双路）
   ------------------------------------------------------------
   我的世界里的「移动光源」有两种做法，各有各的代价：

     ① 点光源（point）：真的往场景里塞 PointLight。
        画面最平滑、会照亮所有材质，但每盏灯都会让所有方块材质的
        片元着色器多跑一次循环 —— 吃 GPU，低端机尤其明显。

     ② 体素光（voxel）：把光源当成一个临时方块，写进 blockLight，
        再让现有光照 BFS 传播、重建受影响的区块网格。
        完全走 CPU，零额外片元开销；画面是方格状的，光会绕墙。
        适合 GPU 弱、CPU 还行的手机。

   玩家设备到底偏 CPU 还是 GPU 我们没法预判，所以这里做成：
     · 设置里四档：关 / 自动 / 体素光 / 点光源
     · 自动：默认点光源（跟手、平滑）；帧时持续超标再自动降级到体素光
       ★ 体素光要重建整列区块网格，实测跟手性差，所以不再作为默认
     · 运行时自适应（点光源减盏 → 转体素光；体素光降亮度 / 加大间隔 → 最终关闭）

   ★ 点光源只在真正需要用的时候才创建；关掉立即从场景移除。
     之前是模块加载就常驻 6 盏灯，导致所有材质按 6 点光源重编译，
     低端手机帧时爆炸、显存耗尽、驱动复位。
   ============================================================ */

import * as THREE from 'three';
import { scene, setDynamicLightUniforms, getDynamicLightUniformsDebug } from './render-core.js';
import { IS_TOUCH, getDeviceProfile } from '../core/runtime.js';
import { getChunksMap, getBlockWorld } from '../world/terrain.js';
import { BLOCKS } from '../world/blocks.js';
import {
  setTempLight, clearTempLight, resetTempLights, getTempLightCount,
} from '../world/light.js';

const KEY = '3dmc_dynamic_light_mode';
const LEGACY_KEY = '3dmc_dynamic_light_v2';
const MODES = ['off', 'auto', 'voxel', 'point'];

/* ============================================================
   模式
   ============================================================ */

function _readMode(){
  try {
    const v = localStorage.getItem(KEY);
    if (MODES.indexOf(v) >= 0) return v;
    /* 兼容旧版只有开/关的存档 */
    if (localStorage.getItem(LEGACY_KEY) === 'on') return 'auto';
  } catch(e){}
  return 'auto';
}

let mode = _readMode();

/** 自动模式的默认路径
 *  ★ 默认优先点光源：体素光要重建整列区块网格，跟手性差（实测延迟明显）；
 *    点光源只多 1~2 盏灯，画面平滑。帧时持续超标时再自动降级到体素光。 */
function _targetPath(){
  if (mode === 'off')   return 'none';
  if (mode === 'point') return 'point';
  if (mode === 'voxel') return 'voxel';
  return 'point';
}

let activePath = _targetPath();

export function getDynamicLightMode(){ return mode; }

export function setDynamicLightMode(m){
  mode = MODES.indexOf(m) >= 0 ? m : 'auto';
  try { localStorage.setItem(KEY, mode); } catch(e){}

  /* 换模式时把自适应状态复位，给新路径一个干净的起点 */
  _badMs = 0;
  pointLimit = 0;
  voxelLevelCap = 14;
  voxelInterval = 0;
  voxelNextAt = 0;

  _clearDynamicLight();
  _resolvePath(true);
}

/** 旧接口：开 = 自动，关 = 关闭。保留给可能存在的旧调用。 */
export function isDynamicLightEnabled(){
  return mode !== 'off' && activePath !== 'none';
}

export function setDynamicLightEnabled(on){
  setDynamicLightMode(on ? 'auto' : 'off');
}

function _resolvePath(force){
  const want = _targetPath();
  if (!force && want === activePath) return;

  if (activePath === 'voxel') _clearVoxelNow();
  if (activePath === 'point') destroyPool();

  activePath = want;
}

/* ============================================================
   ① 点光源路径
   ============================================================ */

/* ------------------------------------------------------------
   ★ 点光源「手感」参数 —— 故意做成非物理的，为了对齐 MC 的 15 级光
   ------------------------------------------------------------
   three 的点光源衰减 = intensity / d^decay，再乘一个在 distance
   处收敛到 0 的窗口函数，最后进 Lambert 还要再除以 π。
   r155 起 useLegacyLights 默认关闭，强度就是物理单位 —— 这就是
   之前"只能照亮自己脚下一小片"的根本原因：

     旧参数 decay=1.5、power=14 → intensity 12.4
       d=2  → 12.4 / 2^1.5  / π = 1.40  （脚下过曝）
       d=6  → 12.4 / 6^1.5  / π = 0.27
       d=10 → 12.4 / 10^1.5 / π = 0.12  （基本看不见了）

   MC 的手持光源是「每走 1 格衰减 1/15，亮度在 14 格内线性铺开」：
       d=2 ≈ 0.80   d=7 ≈ 0.47   d=10 ≈ 0.27

   用 decay=0.8 近似这条曲线（intensity 5.0 时）：
       d=2 ≈ 0.91   d=7 ≈ 0.34   d=10 ≈ 0.25   d=14 ≈ 0.16
   近处不再过曝、10 格外还能看清地面，也就跟 MC 那个手感接近了。
   decay < 1 在物理上是错的（能量没有被距离充分摊薄），这里只为了观感。
   ------------------------------------------------------------ */
const LIGHT_DECAY     = 0.8;
const LIGHT_DIST_BASE = 17;    /* 窗口截止距离 = BASE + power * DIST_PER */
const LIGHT_DIST_PER  = 0.62;  /* power=14 → 25.7 格 */
const LIGHT_IN_BASE   = 1.6;   /* 强度 = BASE + power * IN_PER */
const LIGHT_IN_PER    = 0.24;  /* power=14 → 5.0 */
/* ★ 这里原来是 `pool.length || DYN_LIGHT_MAX`，但 DYN_LIGHT_MAX 全项目
   从未定义过 —— 只要 pool 为空就会抛 ReferenceError，被 main.js 的
   try/catch 吞掉（控制台里看不到，玩家只看到"动态光没反应"）。
   现在给一个真实的上限常量。 */
const DYN_LIGHT_MAX   = 4;

/* 方材质动态光 uniform 的复用缓冲（每帧重建，避免 GC） */
const _dynScratch = [];
const _dynColor = new THREE.Color();

/* ★ 诊断：最近一次「喂进 uniform 的光源到底有几个」
   分三个数，一次读数就能定位是哪一段断了：
     srcN    手持发光物 / 发光掉落物 / 飞行中的豆子和箭 的个数
     placedN 半径 EMITTER_SCAN_R 内扫到的已放置发光方块个数
     listN   最终喂给 uniform 的个数（= srcN + placedN，受 cap 限制）
   HUD 里显示成 N{listN} s{srcN} p{placedN}：
     · s0 p0            → 你身边根本没光源，r0=0 是正常的
     · s>0 但 N0         → _nearest 把它们筛掉了（pos 缺失之类）
     · N>0 但 r0=0       → setDynamicLightUniforms 没写进去（真 bug） */
const _lastFeed = { srcN: 0, placedN: 0, listN: 0, nearestN: 0, writeN: 0, err: '', at: 0 };

/* 每多一盏灯，所有方块材质就多跑一次点光源循环。
   桌面按显卡档位 2~4 盏，手机 1~2 盏；自适应掉帧时还会继续减。 */
function _defaultPointLimit(){
  let tier = 'mid';
  try {
    const p = getDeviceProfile();
    if (p && p.tier) tier = p.tier;
  } catch(e){}
  if (IS_TOUCH) return tier === 'low' ? 1 : 2;
  if (tier === 'high') return 4;
  if (tier === 'mid')  return 3;
  return 2;
}

/* 每多一盏灯，所有方块材质就多跑一次点光源循环。
   ★ 0 = 尚未探测；第一次真正用灯时才去读设备档位，避免模块加载就创建 WebGL 上下文。 */
let pointLimit = 0;
const pool = [];

function _ensurePointLimit(){
  if (pointLimit <= 0) pointLimit = _defaultPointLimit();
  return pointLimit;
}

function ensurePool(){
  const n = _ensurePointLimit();
  while (pool.length < n){
    const l = new THREE.PointLight(0xffffff, 0, LIGHT_DIST_BASE + 14 * LIGHT_DIST_PER, LIGHT_DECAY);
    l.position.set(0, -99999, 0);
    scene.add(l);
    pool.push(l);
  }
  while (pool.length > n){
    const l = pool.pop();
    l.intensity = 0;
    scene.remove(l);
  }
}

function destroyPool(){
  for (let i = 0; i < pool.length; i++){
    pool[i].intensity = 0;
    scene.remove(pool[i]);
  }
  pool.length = 0;
}

/** 方块/物品是否属于“会发光”的东西（决定掉落物发光、手持发光） */
export function isLightSourceBlock(blk){
  if (!blk) return false;
  if ((blk.light | 0) > 0) return true;
  return blk.name === 'magic_bean' || blk.name === 'glow_arrow';
}

function lightColorOfBlock(blk){
  const n = blk ? blk.name : '';
  if (n === 'sea_lantern') return 0x9fe8ff;
  if (n === 'glowstone') return 0xffd88a;
  if (n === 'lava') return 0xff9a4a;
  if (n === 'torch' || n === 'wall_torch') return 0xffb066;
  if (n === 'magic_torch' || n === 'wall_magic_torch') return 0xc4a4ff;
  if (n === 'magic_bean' || n === 'glow_arrow' ||
      n === 'magic_grass' || n === 'glow_sapling' || n === 'glow_light'){
    return 0xa8ffb0;
  }
  return 0xffe0b0;
}

export function lightColorOf(blk){ return lightColorOfBlock(blk); }

/* ============================================================
   ★ 已放置的发光方块（火把 / 荧石 / 海晶灯 …）也要参与动态光
   ------------------------------------------------------------
   以前只有"手持物品 + 发光掉落物 + 飞行中的豆子/箭"会进动态光列表。
   放置的火把只是通过 blockLight BFS 影响**区块网格的烘焙顶点色**，
   而生物、掉落物、箱子这些独立 mesh 拿不到烘焙光 ——
   所以火把旁边放着的猪是黑的。

   这里每隔一小段时间扫一遍玩家周围一定范围内的方块，把发光方块
   也加进光源列表。这样它们既有 PointLight（照实体），也会进
   方材质的 uniform（和烘焙光取 max，不会重复叠加）。

   成本：半径 10 → 21³ ≈ 9.3k 次读取，只在玩家跨格 + 冷却到了才扫，
   实测远低于 1ms，比每帧扫便宜太多。
   ============================================================ */
const EMITTER_SCAN_R = 10;
const EMITTER_SCAN_MS = 400;
const EMITTER_SCAN_MOVE = 2;      /* 玩家移动超过这么多格才重扫 */
let _emitterList = [];            /* [{ pos:{x,y,z}, blk }] */
let _emitterLastAt = 0;
let _emitterLastX = 1e9, _emitterLastY = 1e9, _emitterLastZ = 1e9;

function _scanPlacedEmitters(px, py, pz, now){
  const dx = px - _emitterLastX, dy = py - _emitterLastY, dz = pz - _emitterLastZ;
  if (now - _emitterLastAt < EMITTER_SCAN_MS &&
      dx * dx + dy * dy + dz * dz < EMITTER_SCAN_MOVE * EMITTER_SCAN_MOVE) {
    return _emitterList;
  }
  _emitterLastAt = now;
  _emitterLastX = px; _emitterLastY = py; _emitterLastZ = pz;

  const out = [];
  const bx = Math.floor(px), by = Math.floor(py), bz = Math.floor(pz);
  const R = EMITTER_SCAN_R;
  try {
    for (let y = by - R; y <= by + R; y++){
      for (let z = bz - R; z <= bz + R; z++){
        for (let x = bx - R; x <= bx + R; x++){
          const id = getBlockWorld(x, y, z);
          if (!id) continue;
          const blk = BLOCKS[id];
          if (!blk || !((blk.light | 0) > 0)) continue;
          out.push({ pos: { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, blk });
        }
      }
    }
  } catch(e){
    /* 扫描失败不影响手持光源 */
  }
  /* 岩浆湖之类会把列表撑到几百个，留最近的 24 个就够了 */
  if (out.length > 24){
    out.sort((a, b) => {
      const ax = a.pos.x - px, ay = a.pos.y - py, az = a.pos.z - pz;
      const bx2 = b.pos.x - px, by2 = b.pos.y - py, bz2 = b.pos.z - pz;
      return (ax * ax + ay * ay + az * az) - (bx2 * bx2 + by2 * by2 + bz2 * bz2);
    });
    out.length = 24;
  }
  _emitterList = out;
  return _emitterList;
}


function _emitLevel(blk){
  const v = (blk && blk.light) ? (blk.light | 0) : 14;
  return Math.max(1, Math.min(14, v));
}

/* 按到相机的距离取最近的 N 个光源 */
function _nearest(camPos, sources, limit){
  if (!camPos || !sources || !sources.length) return [];
  const list = [];
  for (let i = 0; i < sources.length; i++){
    const s = sources[i];
    if (!s || !s.pos) continue;
    const dx = s.pos.x - camPos.x;
    const dy = s.pos.y - camPos.y;
    const dz = s.pos.z - camPos.z;
    list.push({ s, d2: dx * dx + dy * dy + dz * dz });
  }
  list.sort((a, b) => a.d2 - b.d2);
  if (list.length > limit) list.length = limit;
  return list;
}

function _updatePoint(camPos, sources){
  if (!pool.length) ensurePool();

  const list = _nearest(camPos, sources, pool.length || DYN_LIGHT_MAX);
  _lastFeed.nearestN = list.length;

  /* ---- ① 真 PointLight：只负责「非方块材质」（生物、掉落物、箱子…）
     方块材质不再依赖它，见下面 ② 和 render-core 的 addBlockGlow 注释。 */
  for (let i = 0; i < pool.length; i++){
    const l = pool[i];
    if (i >= list.length){
      l.intensity = 0;
      continue;
    }
    const s = list[i].s;
    const blk = s.blk;
    const power = _emitLevel(blk);
    l.position.set(s.pos.x, s.pos.y, s.pos.z);
    l.color.setHex(lightColorOfBlock(blk));
    /* 范围/强度：按文件顶部那组 LIGHT_* 常量算，power=14 时
       距离 25.7 格、强度 5.0，衰减指数 0.8 —— 和 MC 手持光源的
       「14 格线性铺开」手感对齐（旧值是距离 21.2 / 强度 12.4 / decay 1.5）。 */
    l.distance = LIGHT_DIST_BASE + power * LIGHT_DIST_PER;
    l.intensity = LIGHT_IN_BASE + power * LIGHT_IN_PER;
  }

  /* ---- ② 方块材质的动态光 uniform ----
     方块材质的顶点色里烘焙了天光+方块光，洞穴里那是 0.05，
     所以点光源乘上去等于没有（"黑暗中点光源照不亮"的根因）。
     这里把同一批光源喂给方块材质着色器，它会在「未烘焙反照率」上
     重新算一遍，再用 max() 并进最终颜色。 */
  _dynScratch.length = 0;
  const cap = Math.min(list.length, 4);
  for (let i = 0; i < cap; i++){
    const s = list[i].s;
    const power = _emitLevel(s.blk);
    _dynColor.setHex(lightColorOfBlock(s.blk));
    _dynScratch.push({
      x: s.pos.x, y: s.pos.y, z: s.pos.z,
      r: _dynColor.r, g: _dynColor.g, b: _dynColor.b,
      intensity: LIGHT_IN_BASE + power * LIGHT_IN_PER,
      range: LIGHT_DIST_BASE + power * LIGHT_DIST_PER,
    });
  }
  _lastFeed.writeN = _dynScratch.length;
  setDynamicLightUniforms(_dynScratch, LIGHT_DECAY);
}

/** 熄灭所有动态光（关掉移动光源 / 切到体素光时必须调，
 *  否则方块材质上的 uniform 会停在上一次的值，火把光"粘"在原地） */
function _clearDynamicLight(){
  if (!_dynScratch.length) return;
  _dynScratch.length = 0;
  setDynamicLightUniforms(_dynScratch, LIGHT_DECAY);
}

/* ============================================================
   ② 体素光路径
   ------------------------------------------------------------
   把光源位置按方块对齐，注入到 blockLight；只有跨方块 / 光源集合
   变化时才重算，避免每帧都触发区块重建。
   ============================================================ */

const voxelCells = new Map();      /* "x,y,z" -> { x, y, z, level } */
/* ★ 默认不做时间节流：靠"目标格有没有变"来判断要不要重算。
   站着不动完全不做事；走一格立刻跟一格，延迟只有 1 帧。
   只有自适应降级时才会加大这个间隔。 */
let voxelInterval = 0;   /* ms */
let voxelNextAt = 0;
let voxelLevelCap = 14;
const voxelMaxSources = IS_TOUCH ? 1 : 2;

function _cellKey(x, y, z){ return x + ',' + y + ',' + z; }

function _markDirty(map, changed){
  if (!changed || !changed.size) return;
  for (const k of changed){
    const c = map.get(k);
    if (!c) continue;
    c.dirty = true;
    c.dirtyGen = (c.dirtyGen || 0) + 1;
  }
}

function _clearVoxelNow(){
  if (!voxelCells.size) return;
  const map = getChunksMap();
  if (map){
    const changed = new Set();
    for (const cell of voxelCells.values()){
      const ch = clearTempLight(map, cell.x, cell.y, cell.z);
      for (const ck of ch) changed.add(ck);
    }
    _markDirty(map, changed);
  }
  voxelCells.clear();
  resetTempLights();
}

function _updateVoxel(camPos, sources){
  const now = (typeof performance !== 'undefined') ? performance.now() : Date.now();
  if (now < voxelNextAt) return;
  voxelNextAt = now + voxelInterval;

  const map = getChunksMap();
  if (!map) return;

  const list = _nearest(camPos, sources, voxelMaxSources);

  /* 目标格：同一格只保留最亮的一档 */
  const target = new Map();
  for (let i = 0; i < list.length; i++){
    const s = list[i].s;
    const x = Math.floor(s.pos.x);
    const y = Math.floor(s.pos.y);
    const z = Math.floor(s.pos.z);
    const key = _cellKey(x, y, z);
    const lv = Math.min(voxelLevelCap, _emitLevel(s.blk));
    const prev = target.get(key);
    if (!prev || prev.level < lv) target.set(key, { x, y, z, level: lv });
  }

  const changed = new Set();

  /* 先撤销不再需要的（走开了 / 关掉了） */
  for (const [key, cell] of voxelCells){
    if (target.has(key)) continue;
    const ch = clearTempLight(map, cell.x, cell.y, cell.z);
    for (const ck of ch) changed.add(ck);
    voxelCells.delete(key);
  }

  /* 再注入 / 更新目标格（同格等级没变就跳过） */
  for (const [key, cell] of target){
    const old = voxelCells.get(key);
    if (old && old.level === cell.level) continue;
    const ch = setTempLight(map, cell.x, cell.y, cell.z, cell.level);
    for (const ck of ch) changed.add(ck);
    voxelCells.set(key, cell);
  }

  _markDirty(map, changed);
}

/* ============================================================
   自适应降级
   ============================================================ */

let _badMs = 0;
let _lastNotifyAt = 0;
let _lastUpdateAt = 0;

/**
 * 每帧把实测帧时喂进来。连续明显超时 1.5s 才降一档，
 * 避免加载/切维度时的临时卡顿误伤。
 * ★ 只有「移动光源真的在跑」时才统计：菜单/加载界面不降级。
 */
export function notifyFrameTime(smoothMs, targetMs){
  if (mode === 'off' || activePath === 'none') return;

  const now = (typeof performance !== 'undefined') ? performance.now() : 0;
  let dt = _lastNotifyAt ? now - _lastNotifyAt : 16;
  _lastNotifyAt = now;
  if (dt < 0) dt = 0;
  if (dt > 120) dt = 120;      /* 后台切回来的一大段不算 */

  /* 500ms 内没真正更新过光源 = 不在游玩中，不统计 */
  if (now - _lastUpdateAt > 500){
    _badMs = 0;
    return;
  }

  if (smoothMs > targetMs * 1.45) _badMs += dt;
  else _badMs = Math.max(0, _badMs - dt * 1.2);

  if (_badMs < 1500) return;
  _badMs = 0;
  _degrade();
}

function _degrade(){
  if (activePath === 'point'){
    /* 4 盏 → 3 → 2 → 1 */
    if (pool.length > 1){
      pointLimit = pool.length - 1;
      ensurePool();
      return;
    }
    /* 自动模式：点光源压到 1 盏仍然卡 → 换零片元开销的体素光 */
    if (mode === 'auto'){
      destroyPool();
      activePath = 'voxel';
      voxelNextAt = 0;
    }
    return;
  }

  if (activePath === 'voxel'){
    if (voxelLevelCap > 9){ voxelLevelCap -= 2; return; }
    if (voxelInterval < 240){ voxelInterval = Math.min(240, voxelInterval + 80); return; }
    /* 自动模式：体素光也压不住了，先关掉，别拖累整局游戏 */
    if (mode === 'auto'){
      _clearVoxelNow();
      activePath = 'none';
    }
  }
}

/* ============================================================
   对外入口
   ============================================================ */

/**
 * 每帧更新。
 * @param camPos 相机世界坐标
 * @param sources [{ pos:{x,y,z}, blk }]，blk 用来取光照强度与颜色
 */
export function updateDynamicLights(camPos, sources){
  if (mode === 'off' || activePath === 'none'){
    /* 关掉/不可用时必须把方材质上的动态光熄掉，否则上一帧的火把光
       会一直"粘"在原地（uniform 不会自己归零） */
    _lastFeed.srcN = 0; _lastFeed.placedN = 0; _lastFeed.listN = 0;
    _clearDynamicLight();
    return;
  }
  const now = (typeof performance !== 'undefined') ? performance.now() : Date.now();
  _lastUpdateAt = now;
  if (activePath === 'voxel'){
    _lastFeed.srcN = (sources && sources.length) || 0;
    _lastFeed.placedN = 0;
    _lastFeed.listN = 0;
    _clearDynamicLight();
    _updateVoxel(camPos, sources);
  } else {
    /* ★ 把附近已放置的发光方块并进光源列表：
       它们原本只通过烘焙顶点色影响区块网格，独立 mesh（生物、掉落物、
       箱子）拿不到，所以火把边上的动物是黑的。 */
    const placed = _scanPlacedEmitters(camPos.x, camPos.y - 0.85, camPos.z, now);
    let all = (placed && placed.length) ? sources.concat(placed) : sources;
    if (!all) all = [];

    /* ★ 自检态：在相机位置合成一个虚拟火把塞进列表。
       它绕开「手上有没有拿发光物」「附近有没有已放置火把」这两个
       不确定因素，单独验证「数据 → uniform → 着色器」这一段通不通。
       开法：点 HUD 的「动态光」那行（手机没有 F12，只能这样）。 */
    if (typeof window !== 'undefined' && window.__dynSelfTest){
      all = all.concat([{
        pos: { x: camPos.x, y: camPos.y - 0.85, z: camPos.z },
        blk: { light: 14, name: 'torch' },
      }]);
    }

    _lastFeed.srcN = (sources && sources.length) || 0;
    _lastFeed.placedN = (placed && placed.length) || 0;
    _lastFeed.listN = all.length;
    _lastFeed.at = now;
    /* ★ 把异常记下来喂给 HUD。
       main.js 外面也有一层 try/catch，但它只往控制台打 ——
       手机玩家按不了 F12，等于异常完全静默。 */
    try {
      _updatePoint(camPos, all);
      _lastFeed.err = '';
    } catch(e){
      _lastFeed.err = String((e && e.message) || e).slice(0, 60);
      console.warn('[dynamic-light] _updatePoint 失败:', e);
    }
  }
}

/** 换世界：旧 chunk 已丢弃，只清记录，不要再回去改光 */
export function resetDynamicLights(){
  voxelCells.clear();
  resetTempLights();
  voxelNextAt = 0;
  for (let i = 0; i < pool.length; i++) pool[i].intensity = 0;
  _clearDynamicLight();
}

/** 调试信息 */
export function getDynamicLightStatus(){
  let uniforms = null;
  try { uniforms = getDynamicLightUniformsDebug(); } catch(e){}
  return {
    mode,
    path: activePath,
    pointLights: pool.length,
    voxelLights: getTempLightCount(),
    voxelInterval,
    voxelLevelCap,
    placedEmitters: _emitterList.length,
    feed: {
      srcN: _lastFeed.srcN, placedN: _lastFeed.placedN, listN: _lastFeed.listN,
      nearestN: _lastFeed.nearestN, writeN: _lastFeed.writeN, err: _lastFeed.err,
    },
    uniforms,
  };
}

/* 诊断入口：
   window.__dynStatus()  → 看动态光到底填了什么（视空间坐标 / 颜色 / 范围）
   window.__dynProbe = 1 → 着色器强制把动态光当满强度白光，
                           用来一眼确认「这段注入有没有生效」
                           如果开了探针画面没变化，就是注入没跑到。 */
if (typeof window !== 'undefined'){
  window.__dynStatus = () => getDynamicLightStatus();
}
