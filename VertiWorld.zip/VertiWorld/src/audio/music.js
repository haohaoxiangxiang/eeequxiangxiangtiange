/* ============================================================
   music.js —— 官方背景音乐（webaudiofont 预渲染 + 智能调度）
   ------------------------------------------------------------
   · 三首场景化乐曲：山行 / 夜寂 / 风吟
   · 首次播放时用 OfflineAudioContext + webaudiofont 渲染成 WAV，
     写入 IndexedDB；之后启动直接解码播放，几乎不占 CPU。
   · 播放逻辑：玩家在同一区块连续停留 60 秒且当前没有音乐时才随机播放
     一首；歌曲一旦开始就完整放完，离开区块也不会中断。
   · 两条路线：
       official —— 官方调度（mod 注册的曲目也遵守这套逻辑）
       mod      —— 关闭官方调度，mod 自行用 playMusicUrl / stopMusicPlayback
                   和 onMusicEnded 控制播放
   ============================================================ */

/* ============================== 内部状态 ============================== */

let ctx = null;
let outGain = null;
let inited = false;

let musicEnabled = true;
let musicPlaying = false;      // 音乐系统是否开启（不是“正在播放”）
let songPlaying = false;       // 是否真的有一首歌在响
let songPending = false;       // 已选好下一首，正在加载/渲染，避免重复触发
let currentTrack = null;
let musicSource = null;
let sourceToken = 0;

let musicVolume = 1;
const SILENT = 0.0001;
/* 预渲染母带已经带压缩，这里再收一点，避免盖过音效 */
const MUSIC_OUT = 0.8;

let musicOwner = 'official';

/* 停留判定 */
const DWELL_MS = 60000;
let dwellKey = null;
let dwellMs = 0;
let lastSongId = null;

/* 缓存 */
const MUSIC_CACHE_VERSION = 2;
const MUSIC_CACHE_DB = `3dmc-music-v${MUSIC_CACHE_VERSION}`;
const MUSIC_CACHE_STORE = 'tracks';
const SONG_SAMPLE_RATE = 32000;
const SONG_TAIL = 3.2;

const _bufferCache = new Map();   // key -> AudioBuffer
const _loading = new Map();       // key -> Promise<AudioBuffer>
const _modTracks = new Map();     // id -> track
const _endedListeners = new Set();
let _dbPromise = null;

/* ============================== 乐器 ============================== */

const INSTRUMENTS = {
  piano:   { file: '0000_GeneralUserGS_sf2_file', gain: 0.75 },
  strings: { file: '0480_GeneralUserGS_sf2_file', gain: 0.50 },
  cello:   { file: '0420_GeneralUserGS_sf2_file', gain: 0.55 },
  harp:    { file: '0460_GeneralUserGS_sf2_file', gain: 0.55 },
  flute:   { file: '0730_GeneralUserGS_sf2_file', gain: 0.50 },
  choir:   { file: '0520_GeneralUserGS_sf2_file', gain: 0.42 },
  horn:    { file: '0600_GeneralUserGS_sf2_file', gain: 0.42 },
  timpani: { file: '0470_GeneralUserGS_sf2_file', gain: 0.50 },
  vibes:   { file: '0110_GeneralUserGS_sf2_file', gain: 0.40 },
};

let _wafPlayer = null;
let _wafReady = null;
const _presets = {};

/* ============================== 三首曲子 ============================== */

/* 和声表：voicing 为中央 C 附近的音高，root 为低音 */
const CH = {
  D:   { n: [62, 66, 69], r: 38 },
  Bm:  { n: [59, 62, 66], r: 35 },
  G:   { n: [55, 59, 62], r: 43 },
  A:   { n: [57, 61, 64], r: 45 },
  'F#m': { n: [54, 57, 61], r: 42 },
  Am:  { n: [57, 60, 64], r: 45 },
  F:   { n: [53, 57, 60], r: 41 },
  C:   { n: [55, 60, 64], r: 36 },
  Gsus:{ n: [55, 60, 62], r: 43 },
  Dm:  { n: [53, 57, 62], r: 38 },
  E:   { n: [52, 56, 59], r: 40 },
  Bb:  { n: [58, 62, 65], r: 46 },
  Fmaj:{ n: [53, 57, 60], r: 41 },
  Cmaj:{ n: [48, 52, 55], r: 36 },
  Gm:  { n: [55, 58, 62], r: 43 },
};

/* ---- 一、山行：走过山脊、山腰与山顶 ---- */
const SONG_MOUNTAIN = {
  id: 'mountain',
  label: '山行',
  bpm: 70,
  bars: 32,
  schedule(add){
    const prog = [
      'D','Bm','G','A','D','Bm','G','A',
      'D','Bm','G','A','G','A','F#m','Bm',
      'D','G','Bm','A','G','A','D','D',
      'D','Bm','G','A','G','A','D','D',
    ];

    for (let bar = 0; bar < prog.length; bar++){
      const ch = CH[prog[bar]];
      const b = bar * 4;

      /* 钢琴分解和弦 */
      const pat = [ch.n[0], ch.n[1], ch.n[2], ch.n[0] + 12,
                   ch.n[2], ch.n[1], ch.n[0] + 12, ch.n[1]];
      const pv = bar < 4 ? 0.20 : (bar >= 24 ? 0.15 : 0.12);
      for (let i = 0; i < pat.length; i++){
        add('piano', pat[i], b + i * 0.5, 0.85, pv);
      }

      /* 弦乐铺底 */
      if (bar >= 4 && bar < 28){
        const sv = (bar >= 16 && bar < 24) ? 0.16 : 0.10;
        for (const m of ch.n) add('strings', m, b, 3.9, sv);
      }

      /* 大提琴低音 */
      if (bar >= 8 && bar % 2 === 0){
        add('cello', ch.r, b, 3.8, 0.20);
      }

      /* 定音鼓：登顶前的步伐 */
      if (bar >= 16 && bar < 24 && bar % 2 === 0){
        add('timpani', ch.r, b, 1.8, 0.24);
      }

      /* 竖琴刮奏：进山与登顶 */
      if (bar === 8 || bar === 24){
        const tones = [ch.n[0] - 12, ch.n[1] - 12, ch.n[2] - 12,
                       ch.n[0], ch.n[1], ch.n[2]];
        for (let i = 0; i < tones.length; i++){
          add('harp', tones[i], b + i * 0.12, 1.9, 0.15);
        }
      }
    }

    /* 长笛主旋律 */
    const mel = [
      [8,0,74,1],[8,1,78,1],[8,2.5,81,1.2],[8,3.75,79,0.8],
      [9,0,78,1],[9,1,74,1],[9,2,71,1],[9,3,74,1],
      [10,0,79,1],[10,1,78,1],[10,2,74,1],[10,3,71,1],
      [11,0,74,1.5],[11,2,76,1],[11,3,78,1],
      [12,0,83,1.2],[12,1.5,81,0.8],[12,2.5,79,0.8],[12,3.25,78,0.9],
      [13,0,76,1],[13,1,78,1],[13,2,81,1.5],[13,3.5,79,0.6],
      [14,0,78,1],[14,1,76,1],[14,2,73,1],[14,3,69,1],
      [15,0,71,1.5],[15,2,74,1],[15,3,78,1.5],
      [16,0,81,2],[16,2,83,1],[16,3,86,1],
      [17,0,83,1.5],[17,2,81,1],[17,3,79,1],
      [18,0,78,2],[18,2,81,1],[18,3,83,1],
      [19,0,81,1.5],[19,2,79,1],[19,3,76,1],
      [20,0,79,1],[20,1,81,1],[20,2,83,1],[20,3,86,1],
      [21,0,84,2],[21,2,81,1],[21,3,79,1],
      [22,0,78,1.5],[22,2,74,1],[22,3,78,1],
      [23,0,81,2],[23,2,86,2],
      [24,0,83,1.5],[24,2,81,1],[24,3,79,1],
      [25,0,78,1],[25,1,74,1],[25,2,71,1],[25,3,74,1],
      [26,0,79,1.5],[26,2,81,1],[26,3,83,1],
      [27,0,86,2],[27,2,83,1],[27,3,79,1],
      [28,0,81,2],[28,2,78,1],[28,3,74,1],
      [29,0,76,1],[29,1,78,1],[29,2,81,1],[29,3,84,1],
      [30,0,86,3],[30,3,83,1],
      [31,0,86,4],
    ];
    for (const [bar, beat, midi, beats] of mel){
      const v = (bar >= 16 && bar < 24) ? 0.17 : 0.13;
      add('flute', midi, bar * 4 + beat, beats, v);
    }
  },
};

/* ---- 二、夜寂：无人的夜晚，蝉鸣点缀 ---- */
const SONG_NIGHT = {
  id: 'night',
  label: '夜寂',
  bpm: 52,
  bars: 24,
  schedule(add){
    const prog = [
      'Am','F','C','G','Am','F','Dm','E',
      'Am','F','C','G','Am','F','Dm','E',
      'Am','F','C','G','F','G','Am','Am',
    ];

    for (let bar = 0; bar < prog.length; bar++){
      const ch = CH[prog[bar]];
      const b = bar * 4;

      /* 合唱铺底：空旷、无人 */
      if (bar >= 2){
        for (const m of ch.n) add('choir', m, b, 3.9, 0.075);
      }

      /* 大提琴长音，每四小节一次 */
      if (bar % 4 === 0) add('cello', ch.r, b, 15.2, 0.13);

      /* 竖琴轻扫 */
      if (bar % 4 === 0){
        const tones = [ch.n[0], ch.n[1], ch.n[2], ch.n[0] + 12];
        for (let i = 0; i < tones.length; i++){
          add('harp', tones[i], b + i * 0.28, 2.2, 0.11);
        }
      }

      /* 钢琴：稀疏单音 */
      if (bar % 2 === 0){
        add('piano', ch.n[0] + 12, b + 0.5, 1.8, 0.10);
        add('piano', ch.n[2] + 12, b + 2.5, 1.5, 0.075);
      }

      /* 钟琴微光 */
      if (bar % 8 === 4){
        add('vibes', ch.n[2] + 24, b + 1.5, 2.6, 0.055);
        add('vibes', ch.n[1] + 24, b + 3.0, 2.2, 0.045);
      }
    }

    /* 长笛：远处飘来的短句 */
    const mel = [
      [10,0,81,1.5],[10,2,79,1],[11,0,76,2],[11,2.5,74,1.5],
      [12,0,72,2],[12,2,76,1],[13,0,74,3],
      [18,0,84,1.5],[18,2,81,1],[19,0,79,2],[19,2.5,76,1.5],
      [20,0,74,2],[20,2,72,1],[21,0,69,4],
    ];
    for (const [bar, beat, midi, beats] of mel){
      add('flute', midi, bar * 4 + beat, beats, 0.085);
    }
  },
  fx(off, master, dur){
    _addCrickets(off, master, 0, dur, 0x9e3779b9);
  },
};

/* ---- 三、风吟：大风掠过，略带忧伤 ---- */
const SONG_WIND = {
  id: 'wind',
  label: '风吟',
  bpm: 58,
  bars: 28,
  schedule(add){
    const prog = [
      'Dm','Bb','F','C','Dm','Bb','Gm','A',
      'Dm','Bb','F','C','Dm','Bb','Gm','A',
      'Bb','F','Gm','A','Bb','F','C','A',
      'Dm','Bb','Gm','A',
    ];

    for (let bar = 0; bar < prog.length; bar++){
      const ch = CH[prog[bar]];
      const b = bar * 4;

      /* 弦乐和声 */
      const sv = (bar >= 12 && bar < 20) ? 0.15 : 0.10;
      for (const m of ch.n) add('strings', m, b, 3.9, sv);

      /* 钢琴：两小节一次的低音与和弦 */
      if (bar % 2 === 0){
        add('piano', ch.r, b, 3.2, 0.14);
        add('piano', ch.n[0], b + 1.5, 1.4, 0.095);
        add('piano', ch.n[2], b + 2.6, 1.2, 0.08);
      }

      /* 圆号渐强：中段的风声 */
      if (bar >= 12 && bar < 20 && bar % 2 === 0){
        add('horn', ch.n[0] + 12, b, 3.8, 0.10);
      }

      /* 定音鼓：远雷般的重音 */
      if (bar === 8 || bar === 16 || bar === 24){
        add('timpani', ch.r, b, 2.4, 0.20);
      }
    }

    /* 大提琴主旋律 */
    const mel = [
      [0,0,62,3],[1,0,60,2],[1,2,58,2],[2,0,57,3],[3,0,55,2],[3,2,53,2],
      [4,0,50,4],[5,0,53,3],[6,0,57,2],[6,2,55,2],[7,0,53,3],
      [8,0,62,2],[8,2,65,2],[9,0,64,3],[10,0,62,2],[10,2,60,2],[11,0,58,3],
      [12,0,57,2],[12,2,60,2],[13,0,62,3],[14,0,65,2],[14,2,64,2],[15,0,62,3],
      [16,0,69,3],[17,0,67,2],[17,2,65,2],[18,0,64,3],[19,0,62,2],[19,2,60,2],
      [20,0,58,3],[21,0,57,2],[21,2,55,2],[22,0,53,4],[23,0,50,4],
      [24,0,57,3],[25,0,60,2],[25,2,62,2],[26,0,64,3],[27,0,62,4],
    ];
    for (const [bar, beat, midi, beats] of mel){
      add('cello', midi, bar * 4 + beat, beats, 0.20);
    }
  },
  fx(off, master, dur){
    _addWind(off, master, 0, dur, 0x51ed270b);
  },
};

const SONGS = [SONG_MOUNTAIN, SONG_NIGHT, SONG_WIND];

/* ============================== 合成辅助 ============================== */

function _makeNoise(off, seconds, seed){
  const sr = off.sampleRate;
  const len = Math.max(1, Math.floor(seconds * sr));
  const buf = off.createBuffer(1, len, sr);
  const d = buf.getChannelData(0);
  let s = seed >>> 0;
  for (let i = 0; i < len; i++){
    s = (s * 1664525 + 1013904223) >>> 0;
    d[i] = (s / 4294967296) * 2 - 1;
  }
  return buf;
}

function _makeImpulse(off, seconds, decay){
  const sr = off.sampleRate;
  const len = Math.max(1, Math.floor(seconds * sr));
  const buf = off.createBuffer(1, len, sr);
  const d = buf.getChannelData(0);
  let s = 0x1234567;
  for (let i = 0; i < len; i++){
    s = (s * 1664525 + 1013904223) >>> 0;
    const r = (s / 4294967296) * 2 - 1;
    d[i] = r * Math.pow(1 - i / len, decay);
  }
  return buf;
}

/* 蝉鸣：几组高频短脉冲，随机分布在夜色里 */
function _addCrickets(off, dest, start, dur, seed){
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };

  for (let t = start + 0.8; t < start + dur - 0.5; t += 0.9 + rnd() * 2.2){
    const freq = 3800 + rnd() * 900;
    const pulses = 2 + Math.floor(rnd() * 3);
    for (let k = 0; k < pulses; k++){
      const tt = t + k * 0.055;
      const osc = off.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const g = off.createGain();
      const v = 0.016 + rnd() * 0.010;
      g.gain.setValueAtTime(0.0001, tt);
      g.gain.linearRampToValueAtTime(v, tt + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, tt + 0.05);
      osc.connect(g); g.connect(dest);
      osc.start(tt); osc.stop(tt + 0.07);
    }
  }
}

/* 大风：带通噪声 + 缓慢阵风包络 */
function _addWind(off, dest, start, dur, seed){
  const src = off.createBufferSource();
  src.buffer = _makeNoise(off, 4.0, seed);
  src.loop = true;

  const bp = off.createBiquadFilter();
  bp.type = 'bandpass';
  bp.frequency.value = 520;
  bp.Q.value = 0.65;

  const lp = off.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 1600;

  const g = off.createGain();
  g.gain.setValueAtTime(0.018, start);

  /* 两个不同周期的阵风 */
  const lfo1 = off.createOscillator();
  lfo1.type = 'sine';
  lfo1.frequency.value = 0.075;
  const lg1 = off.createGain();
  lg1.gain.value = 0.020;
  lfo1.connect(lg1); lg1.connect(g.gain);

  const lfo2 = off.createOscillator();
  lfo2.type = 'sine';
  lfo2.frequency.value = 0.031;
  const lg2 = off.createGain();
  lg2.gain.value = 0.012;
  lfo2.connect(lg2); lg2.connect(g.gain);

  src.connect(bp); bp.connect(lp); lp.connect(g); g.connect(dest);
  src.start(start); src.stop(start + dur);
  lfo1.start(start); lfo1.stop(start + dur);
  lfo2.start(start); lfo2.stop(start + dur);
}

/* ============================== webaudiofont 加载 ============================== */

function _loadScript(src){
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('加载失败: ' + src));
    document.head.appendChild(s);
  });
}

function _waitPreset(preset){
  return new Promise((resolve) => {
    let tries = 0;
    const check = () => {
      const zones = preset.zones || [];
      for (let i = 0; i < zones.length; i++){
        const z = zones[i];
        if (z.file && !z.buffer){
          if (++tries < 600) setTimeout(check, 25);
          else resolve();
          return;
        }
      }
      resolve();
    };
    check();
  });
}

function _ensureWebAudioFont(){
  if (_wafReady) return _wafReady;
  _wafReady = (async () => {
    if (!ctx) return null;

    if (!window.WebAudioFontPlayer){
      await _loadScript(new URL('../../vendor/webaudiofont/WebAudioFontPlayer.js', import.meta.url).href);
    }

    const keys = Object.keys(INSTRUMENTS);
    for (const k of keys){
      const f = INSTRUMENTS[k].file;
      if (!window['_tone_' + f]){
        await _loadScript(new URL('../../vendor/webaudiofont/sound/' + f + '.js', import.meta.url).href);
      }
    }

    if (!window.WebAudioFontPlayer) throw new Error('WebAudioFontPlayer 不可用');
    _wafPlayer = new window.WebAudioFontPlayer();

    for (const k of keys){
      const preset = window['_tone_' + INSTRUMENTS[k].file];
      if (!preset) continue;
      _presets[k] = preset;
      if (!preset.__3dmcDecoded){
        _wafPlayer.adjustPreset(ctx, preset);
        await _waitPreset(preset);
        preset.__3dmcDecoded = true;
      }
    }
    return _wafPlayer;
  })().catch((e) => {
    console.warn('[music] webaudiofont 加载失败:', e);
    return null;
  });
  return _wafReady;
}

/* ============================== 离线渲染 ============================== */

function _getOfflineCtor(){
  if (typeof window === 'undefined') return null;
  return window.OfflineAudioContext || window.webkitOfflineAudioContext || null;
}

async function _renderSong(song){
  await _ensureWebAudioFont();
  if (!_wafPlayer) throw new Error('webaudiofont 未就绪');

  const OAC = _getOfflineCtor();
  if (!OAC) throw new Error('OfflineAudioContext 不可用');

  const sr = SONG_SAMPLE_RATE;
  const spb = 60 / song.bpm;
  const dur = song.bars * 4 * spb;
  const total = dur + SONG_TAIL;

  const off = new OAC(1, Math.ceil(total * sr), sr);

  /* webaudiofont 内部会调用 resume()；离线上下文不需要，也不该在
     startRendering() 之前被切到 running 状态。给它一个空实现。 */
  try { off.resume = () => Promise.resolve(); } catch (e){}

  /* 总线：增益 → 压缩 → 低通 → 输出，并联混响 */
  const master = off.createGain();
  master.gain.value = 0.9;

  const comp = off.createDynamicsCompressor();
  comp.threshold.value = -16;
  comp.knee.value = 22;
  comp.ratio.value = 2.6;
  comp.attack.value = 0.008;
  comp.release.value = 0.35;

  const lp = off.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 12500;
  lp.Q.value = 0.5;

  master.connect(comp);
  comp.connect(lp);
  lp.connect(off.destination);

  try {
    const conv = off.createConvolver();
    conv.buffer = _makeImpulse(off, 2.8, 2.2);
    const wet = off.createGain();
    wet.gain.value = 0.24;
    master.connect(conv);
    conv.connect(wet);
    wet.connect(lp);
  } catch (e){}

  const bus = {};
  for (const k of Object.keys(INSTRUMENTS)){
    const g = off.createGain();
    g.gain.value = INSTRUMENTS[k].gain;
    g.connect(master);
    bus[k] = g;
  }

  const add = (inst, midi, beat, beats, vol) => {
    const preset = _presets[inst];
    const target = bus[inst];
    if (!preset || !target) return;
    const when = Math.max(0.005, beat * spb + (Math.random() - 0.5) * 0.012);
    const len = Math.max(0.08, beats * spb);
    try {
      _wafPlayer.queueWaveTable(off, target, preset, when, midi, len, vol);
    } catch (e){}
  };

  song.schedule(add);
  if (typeof song.fx === 'function') song.fx(off, master, dur);

  const rendered = await new Promise((resolve, reject) => {
    try {
      const p = off.startRendering();
      if (p && typeof p.then === 'function') p.then(resolve, reject);
      else off.oncomplete = (e) => resolve(e.renderedBuffer);
    } catch (e){ reject(e); }
  });

  const src = rendered.getChannelData(0);
  const data = new Float32Array(src.length);
  data.set(src);

  /* 末尾 0.9 秒淡出，避免切尾爆音 */
  const fade = Math.min(data.length, Math.floor(0.9 * sr));
  for (let i = 0; i < fade; i++){
    data[data.length - fade + i] *= 1 - i / fade;
  }

  return { data, sampleRate: sr };
}

/* 16bit 单声道 WAV */
function _encodeWav(data, sampleRate){
  const len = data.length;
  const buf = new ArrayBuffer(44 + len * 2);
  const v = new DataView(buf);
  const ws = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };

  ws(0, 'RIFF');
  v.setUint32(4, 36 + len * 2, true);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, sampleRate, true);
  v.setUint32(28, sampleRate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  ws(36, 'data');
  v.setUint32(40, len * 2, true);

  let o = 44;
  for (let i = 0; i < len; i++){
    const s = Math.max(-1, Math.min(1, data[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    o += 2;
  }
  return buf;
}

/* ============================== IndexedDB ============================== */

/* ★ 把渲染好的 WAV 同步一份到服务器磁盘（3dmc/music/），方便直接拿文件 */
async function _saveWavToDisk(song, arrayBuffer){
  if (typeof fetch !== 'function') return false;
  try {
    const url = '/api/music/save?name=' + encodeURIComponent(song.label + '.wav');
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/wav' },
      body: arrayBuffer,
    });
    return !!(r && r.ok);
  } catch(e){ return false; }
}

/* 导出全部官方曲目：优先取 IndexedDB 缓存，没有就现场渲染 */
export async function exportMusicFiles(){
  const saved = [];
  for (const song of SONGS){
    try {
      let wav = await _idbGet('song:' + song.id);
      if (!wav){
        const rendered = await _renderSong(song);
        wav = _encodeWav(rendered.data, rendered.sampleRate);
        await _idbPut('song:' + song.id, wav);
      }
      const arr = (wav instanceof ArrayBuffer) ? wav : await wav.arrayBuffer();
      if (await _saveWavToDisk(song, arr)) saved.push(song.label + '.wav');
    } catch(e){
      console.warn('[music] 导出失败:', song.id, e);
    }
  }
  return saved;
}

/* ============================================================
   启动预渲染
   ------------------------------------------------------------
   官方曲目是程序化合成的。原来只有"被随机抽到并播放"时才渲染落盘，
   所以 music/ 里通常只有一两首。
   这里在进入世界后利用空闲时间把缺的曲目补齐：渲染 → 写 IndexedDB → 落盘。
   已缓存的直接跳过，不会每次启动都重复生成几 MB 的 WAV。
   ============================================================ */
let _prewarmStarted = false;

/* 探测服务器磁盘上是否已有该曲目：HEAD 只取响应头，不下载整首 */
async function _songOnDisk(song){
  if (typeof fetch !== 'function') return false;
  try {
    const r = await fetch('/music/' + encodeURIComponent(song.label + '.wav'),
      { method: 'HEAD', cache: 'no-store' });
    return !!(r && r.ok);
  } catch(e){ return false; }
}

export function prewarmMusicCache(){
  if (_prewarmStarted) return;
  _prewarmStarted = true;

  const run = async () => {
    for (const song of SONGS){
      const key = 'song:' + song.id;
      try {
        /* ★ 以磁盘为准：IndexedDB 是按浏览器 origin 共享的，
           换一份解压目录后 music/ 是空的，但缓存还在；
           只看缓存会导致磁盘永远补不齐。 */
        if (await _songOnDisk(song)) continue;

        let wav = await _idbGet(key);
        if (!wav && _loading.has(key)){
          try { await _loading.get(key); } catch(e){}
          wav = await _idbGet(key);
        }
        if (!wav){
          const rendered = await _renderSong(song);
          wav = _encodeWav(rendered.data, rendered.sampleRate);
          await _idbPut(key, wav);
        }
        await _saveWavToDisk(song, wav);
      } catch(e){
        console.warn('[music] 预渲染失败:', song.id, e);
      }
    }
  };

  /* 空闲时跑：不抢首帧和区块加载的 CPU */
  if (typeof requestIdleCallback === 'function'){
    requestIdleCallback(() => { run(); }, { timeout: 5000 });
  } else {
    setTimeout(run, 1500);
  }
}

function _db(){
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined'){ resolve(null); return; }
      const req = indexedDB.open(MUSIC_CACHE_DB, 1);
      req.onupgradeneeded = () => {
        try { req.result.createObjectStore(MUSIC_CACHE_STORE); } catch (e){}
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch (e){ resolve(null); }
  });
  return _dbPromise;
}

async function _idbGet(key){
  const db = await _db();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(MUSIC_CACHE_STORE, 'readonly');
      const rq = tx.objectStore(MUSIC_CACHE_STORE).get(key);
      rq.onsuccess = () => resolve(rq.result || null);
      rq.onerror = () => resolve(null);
    } catch (e){ resolve(null); }
  });
}

async function _idbPut(key, val){
  const db = await _db();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(MUSIC_CACHE_STORE, 'readwrite');
      tx.objectStore(MUSIC_CACHE_STORE).put(val, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch (e){ resolve(false); }
  });
}

/* ============================== 缓冲加载 ============================== */

function _decode(arrayBuffer){
  return new Promise((resolve, reject) => {
    try {
      const p = ctx.decodeAudioData(arrayBuffer, resolve, reject);
      if (p && typeof p.then === 'function') p.then(resolve, reject);
    } catch (e){ reject(e); }
  });
}

function _loadOfficialBuffer(song){
  const key = 'song:' + song.id;
  if (_bufferCache.has(key)) return Promise.resolve(_bufferCache.get(key));
  if (_loading.has(key)) return _loading.get(key);

  const p = (async () => {
    const cached = await _idbGet(key);
    if (cached){
      try {
        const arr = (cached instanceof ArrayBuffer) ? cached : await cached.arrayBuffer();
        const buf = await _decode(arr);
        _bufferCache.set(key, buf);
        return buf;
      } catch (e){ /* 缓存损坏，重新渲染 */ }
    }

    const rendered = await _renderSong(song);
    const wav = _encodeWav(rendered.data, rendered.sampleRate);
    const buf = ctx.createBuffer(1, rendered.data.length, rendered.sampleRate);
    buf.copyToChannel(rendered.data, 0);
    await _idbPut(key, wav);
    /* ★ 首次渲染后顺手落盘，玩过之后 3dmc/music/ 里就能看到文件 */
    _saveWavToDisk(song, wav);
    _bufferCache.set(key, buf);
    return buf;
  })();

  _loading.set(key, p);
  p.catch(() => {}).then(() => _loading.delete(key));
  return p;
}

function _loadUrlBuffer(track){
  const key = 'url:' + track.url;
  if (_bufferCache.has(key)) return Promise.resolve(_bufferCache.get(key));
  if (_loading.has(key)) return _loading.get(key);

  const p = (async () => {
    const cached = await _idbGet(key);
    if (cached){
      try {
        const arr = (cached instanceof ArrayBuffer) ? cached : await cached.arrayBuffer();
        const buf = await _decode(arr);
        _bufferCache.set(key, buf);
        return buf;
      } catch (e){}
    }

    const resp = await fetch(track.url);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const arr = await resp.arrayBuffer();
    const buf = await _decode(arr.slice(0));
    await _idbPut(key, arr);
    _bufferCache.set(key, buf);
    return buf;
  })();

  _loading.set(key, p);
  p.catch(() => {}).then(() => _loading.delete(key));
  return p;
}

let _readyPromise = null;
let _warmTimer = null;

function ensureMusicReady(){
  if (!ctx) return Promise.resolve(false);
  if (_readyPromise) return _readyPromise;
  _readyPromise = (async () => {
    const waf = await _ensureWebAudioFont();
    if (!waf) return false;
    for (const song of SONGS){
      try { await _loadOfficialBuffer(song); }
      catch (e){ console.warn('[music] 渲染失败:', song.id, e); }
    }
    return true;
  })();
  return _readyPromise;
}

/* 延迟预渲染：别和进游戏抢主线程，但也远早于第一次 60 秒判定 */
function _scheduleWarm(delay){
  if (_readyPromise || _warmTimer !== null) return;
  if (!musicEnabled || musicOwner !== 'official') return;
  _warmTimer = setTimeout(() => {
    _warmTimer = null;
    if (musicEnabled && musicOwner === 'official') ensureMusicReady();
  }, delay === undefined ? 2000 : delay);
}

/* ============================== 播放 ============================== */

function _trackById(id){
  for (const s of SONGS) if (s.id === id) return s;
  return _modTracks.get(id) || null;
}

function _allTracks(){
  return SONGS.concat(Array.from(_modTracks.values()));
}

function _fadeOutAndStop(sec){
  const src = musicSource;
  musicSource = null;
  songPlaying = false;
  songPending = false;
  currentTrack = null;
  if (!ctx || !outGain) return;
  const t = ctx.currentTime;
  try {
    outGain.gain.cancelScheduledValues(t);
    outGain.gain.setValueAtTime(Math.max(outGain.gain.value, SILENT), t);
    outGain.gain.linearRampToValueAtTime(SILENT, t + Math.max(0.02, sec));
  } catch (e){}
  if (src){
    try { src.stop(t + Math.max(0.02, sec) + 0.05); } catch (e){}
  }
}

async function _playTrack(track, token){
  if (!ctx || !outGain || !musicEnabled || !musicPlaying) return false;
  if (!track) return false;

  let buffer;
  try {
    buffer = track.mod ? await _loadUrlBuffer(track) : await _loadOfficialBuffer(track);
  } catch (e){
    console.warn('[music] 曲目加载失败:', track.id, e);
    return false;
  }
  if (token !== sourceToken || !musicEnabled || !musicPlaying) return false;

  /* 停掉上一首（快速淡出，避免爆音） */
  if (musicSource){
    try { musicSource.stop(ctx.currentTime + 0.08); } catch (e){}
    musicSource = null;
  }

  const src = ctx.createBufferSource();
  src.buffer = buffer;
  src.loop = !!track.loop;

  const gain = ctx.createGain();
  gain.gain.value = 1;

  src.connect(gain);
  gain.connect(outGain);

  const t0 = ctx.currentTime + 0.06;
  src.onended = () => {
    if (musicSource !== src) return;
    musicSource = null;
    songPlaying = false;
    const endedId = track.id;
    currentTrack = null;
    dwellMs = 0;
    for (const fn of _endedListeners){
      try { fn(endedId, track); } catch (e){}
    }
  };

  try { src.start(t0); } catch (e){ return false; }
  musicSource = src;
  songPlaying = true;
  currentTrack = track;

  /* 淡入 */
  const target = Math.max(SILENT, musicVolume * MUSIC_OUT);
  outGain.gain.cancelScheduledValues(t0);
  outGain.gain.setValueAtTime(SILENT, t0);
  outGain.gain.linearRampToValueAtTime(target, t0 + (track.mod ? 0.35 : 1.1));
  return true;
}

function _playRandomOfficial(){
  const list = _allTracks();
  if (!list.length) return;
  let pool = list.filter(t => t.id !== lastSongId);
  if (!pool.length) pool = list;
  const track = pool[Math.floor(Math.random() * pool.length)];
  lastSongId = track.id;
  const token = ++sourceToken;
  songPending = true;
  _playTrack(track, token).then(() => { songPending = false; },
                               () => { songPending = false; });
}

/* ============================== 公开 API ============================== */

export function initMusic(context, destination){
  if (inited || !context || !destination) return;
  ctx = context;
  outGain = ctx.createGain();
  outGain.gain.value = SILENT;
  outGain.connect(destination);
  inited = true;
}

export function startMusic(){
  prewarmMusicCache();   /* 空闲时把三首曲子全部渲染落盘（不依赖实时 AudioContext） */
  if (!ctx) return;
  musicPlaying = true;
  dwellKey = null;
  dwellMs = 0;
  _scheduleWarm();
}

export function stopMusic(){
  musicPlaying = false;
  sourceToken++;
  _fadeOutAndStop(0.8);
  dwellMs = 0;
  dwellKey = null;
}

export function setMusicEnabled(b){
  musicEnabled = !!b;
  if (!musicEnabled){
    sourceToken++;
    _fadeOutAndStop(0.5);
    dwellMs = 0;
    dwellKey = null;
  } else if (musicPlaying){
    dwellKey = null;
    dwellMs = 0;
    _scheduleWarm();
  }
  return musicEnabled;
}

export function isMusicEnabled(){
  return musicEnabled;
}

export function setMusicVolume(v){
  const n = Number(v);
  musicVolume = isFinite(n) ? Math.max(0, Math.min(1, n)) : musicVolume;
  if (ctx && outGain && musicEnabled && songPlaying){
    const t = ctx.currentTime;
    try {
      outGain.gain.cancelScheduledValues(t);
      outGain.gain.setValueAtTime(Math.max(outGain.gain.value, SILENT), t);
      outGain.gain.linearRampToValueAtTime(
        musicVolume <= 0.001 ? SILENT : musicVolume * MUSIC_OUT, t + 0.15);
    } catch (e){}
  }
  return musicVolume;
}

export function getMusicVolume(){
  return musicVolume;
}

/* 主循环每帧调用：dt 秒，chunkKey 为当前所在区块（含维度） */
export function updateMusicScheduler(dt, chunkKey){
  if (!musicEnabled || !musicPlaying || musicOwner !== 'official') return;

  /* 有歌在放 / 正在加载：不判定下一首；离开区块也不打断 */
  if (songPlaying || songPending){
    dwellKey = chunkKey;
    dwellMs = 0;
    return;
  }

  if (chunkKey !== dwellKey){
    dwellKey = chunkKey;
    dwellMs = 0;
    return;
  }

  dwellMs += Math.max(0, Math.min(1, dt)) * 1000;
  if (dwellMs >= DWELL_MS){
    dwellMs = 0;
    _playRandomOfficial();
  }
}

/* ---- mod：把曲目交给官方调度（路线一） ---- */
export function registerMusicTrack(def){
  if (!def || !def.id || !def.url) return null;
  const t = {
    id: String(def.id),
    label: def.label || String(def.id),
    url: def.url,
    mod: true,
    loop: !!def.loop,
  };
  _modTracks.set(t.id, t);
  return { id: t.id, label: t.label, loop: t.loop };
}

export function unregisterMusicTrack(id){
  return _modTracks.delete(String(id));
}

export function listMusicTracks(){
  return _allTracks().map(t => ({ id: t.id, label: t.label, mod: !!t.mod }));
}

/* ---- mod：自行接管播放（路线二） ---- */
export function setMusicOwner(owner){
  musicOwner = owner === 'mod' ? 'mod' : 'official';
  if (musicOwner === 'mod'){
    sourceToken++;
    _fadeOutAndStop(0.6);
    dwellMs = 0;
  } else {
    dwellKey = null;
    dwellMs = 0;
    /* 只在音乐系统已经启动后才预热，避免在主菜单就开渲染 */
    if (musicPlaying) _scheduleWarm(1200);
  }
  return musicOwner;
}

export function getMusicOwner(){
  return musicOwner;
}

export function playMusicById(id){
  if (!musicEnabled || !musicPlaying) return false;
  const track = _trackById(String(id));
  if (!track) return false;
  const token = ++sourceToken;
  songPending = true;
  _playTrack(track, token).then(() => { songPending = false; },
                               () => { songPending = false; });
  return true;
}

export function playMusicUrl(url, opts){
  opts = opts || {};
  if (!musicEnabled || !musicPlaying) return false;
  const track = {
    id: 'url:' + url,
    label: opts.label || url,
    url: url,
    mod: true,
    loop: !!opts.loop,
  };
  const token = ++sourceToken;
  songPending = true;
  _playTrack(track, token).then(() => { songPending = false; },
                               () => { songPending = false; });
  return true;
}

export function stopMusicPlayback(sec){
  sourceToken++;
  _fadeOutAndStop(sec === undefined ? 0.5 : sec);
}

export function isMusicPlaying(){
  return songPlaying;
}

export function getCurrentMusicId(){
  return currentTrack ? currentTrack.id : null;
}

export function onMusicEnded(fn){
  if (typeof fn === 'function') _endedListeners.add(fn);
}

export function offMusicEnded(fn){
  _endedListeners.delete(fn);
}
