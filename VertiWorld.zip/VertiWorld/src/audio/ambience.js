/* ============================================================
   ambience.js —— 洞穴环境音
   ------------------------------------------------------------
   玩家进入封闭洞穴时，淡入低频空气声 + 偶发滴水回音，
   离开后淡出。开关持久化到 localStorage，设置 → 声音 里可关。
   ============================================================ */

import { getSkyLightAt, heightAt } from '../world/terrain.js';
import { startCaveAmbience, stopCaveAmbience, tickCaveAmbience } from './audio.js';

const KEY = '3dmc_cave_ambience';

let _enabled = true;
try { _enabled = localStorage.getItem(KEY) !== 'off'; } catch (e) {}

let _active = false;      // 当前是否已开始播放
let _outsideT = 0;        // 连续不在洞穴里的时间（滞回）
let _retryT = 2;          // 音频未就绪时每 2 秒重试一次

export function isCaveAmbienceEnabled(){ return _enabled; }

export function setCaveAmbienceEnabled(on){
  _enabled = !!on;
  try { localStorage.setItem(KEY, _enabled ? 'on' : 'off'); } catch (e) {}
  if (!_enabled){
    _active = false;
    stopCaveAmbience();
  }
  return _enabled;
}

/** 封闭洞穴判定：眼睛处没有天光，且人在真实地表以下 */
function _isCave(pos){
  const sky = getSkyLightAt(pos.x, pos.y + 1.6, pos.z);
  if (sky > 3) return false;
  return pos.y < heightAt(pos.x, pos.z) - 3;
}

export function updateCaveAmbience(dt, pos){
  if (!pos) return;

  if (!_enabled){
    if (_active){ _active = false; stopCaveAmbience(); }
    return;
  }

  if (!_active){
    if (!_isCave(pos)){
      _outsideT = 0;
      return;
    }
    _retryT += dt;
    if (_retryT >= 2){
      _retryT = 0;
      if (startCaveAmbience()){ _active = true; _outsideT = 0; }
    }
    return;
  }

  if (_isCave(pos)){
    _outsideT = 0;
    tickCaveAmbience();
  } else {
    _outsideT += dt;
    if (_outsideT > 1.5){
      _active = false;
      stopCaveAmbience();
    }
  }
}
