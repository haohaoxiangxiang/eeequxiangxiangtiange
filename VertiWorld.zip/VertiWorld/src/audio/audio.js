/**
 * audio.js —— 程序化 + 文件双模音频模块
 * ---------------------------------------------------------------------------
 * 两种音频来源：
 *   ① 程序化合成（原有）：playSFX('dig.stone')
 *   ② 音频文件（新增）：  registerSound / playSound / playSoundAt
 *
 * 文件音效特性：
 *   · 支持 .ogg / .mp3 / .wav / .m4a / .webm
 *   · 懒加载 + 可选预加载
 *   · 3D 位置音效（距离衰减 + 立体声定位）
 *   · 一次性 / 循环播放，返回句柄可 stop / setVolume
 *   · 加载失败静默 no-op，不影响游戏
 */

/* ============================== 内部状态 ============================== */

import { initMusic } from './music.js';

let ctx = null;
let masterGain = null;
let sfxGain = null;
let noiseBuffer = null;

let masterVolume = 0.8;
let sfxEnabled = true;

let voiceCount = 0;
const MAX_VOICES = 32;

const SILENT = 0.0001;

const lastSfxTime = {};
const SFX_THROTTLE = {
  'water.fall':   220,
  'lava.sizzle':  260,
  'splash':       60,
};

/* ============================== 音频文件系统 ============================== */

/** 音效注册表：name -> { url, preload } */
const _soundRegistry = new Map();
/** 已解码缓冲：name -> AudioBuffer */
const _soundBuffers = new Map();
/** 正在加载中的 Promise：name -> Promise，防止重复加载 */
const _soundLoading = new Map();

/** 监听者位置/朝向提供者（由 main.js 注入） */
let _getListenerPos = () => ({ x: 0, y: 0, z: 0 });
let _getListenerDir = () => ({ x: 0, y: 0, z: -1 });

/**
 * 设置监听者位置/朝向来源。
 * @param {Function} getPos  返回 {x, y, z}
 * @param {Function} getDir  返回 {x, y, z}（相机朝向，单位向量）
 */
export function setListenerSource(getPos, getDir){
  if (typeof getPos === 'function') _getListenerPos = getPos;
  if (typeof getDir === 'function') _getListenerDir = getDir;
}

/**
 * 注册一个音效。
 * @param {string} name            唯一名，建议 <modId>.<soundName>
 * @param {string} url             相对路径 / 绝对路径 / 完整 URL
 * @param {object} [opts]          { preload: boolean }
 * @returns {boolean}
 */
export function registerSound(name, url, opts){
  if (typeof name !== 'string' || !name) return false;
  if (typeof url !== 'string' || !url) return false;

  _soundRegistry.set(name, {
    url,
    preload: !!(opts && opts.preload),
  });

  if (opts && opts.preload){
    loadSound(name).catch(() => {});
  }
  return true;
}

/**
 * 注销音效（不释放已解码的 buffer，避免其他实例在用）。
 * @returns {boolean}
 */
export function unregisterSound(name){
  return _soundRegistry.delete(name);
}

/**
 * 主动加载音效（返回 Promise<AudioBuffer|null>）。
 * 已加载过直接返回缓存。
 */
export async function loadSound(name){
  if (_soundBuffers.has(name)) return _soundBuffers.get(name);

  /* 防止并发重复加载 */
  if (_soundLoading.has(name)) return _soundLoading.get(name);

  const entry = _soundRegistry.get(name);
  if (!entry){
    console.warn(`[audio] 未注册的音效: ${name}`);
    return null;
  }

  const promise = (async () => {
    try {
      const c = initAudio();
      if (!c) return null;

      const res = await fetch(entry.url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const ab = await res.arrayBuffer();

      const buf = await _decodeAudio(c, ab);
      _soundBuffers.set(name, buf);
      return buf;
    } catch(e){
      console.warn(`[audio] 加载 "${name}" 失败:`, e.message || e);
      return null;
    } finally {
      _soundLoading.delete(name);
    }
  })();

  _soundLoading.set(name, promise);
  return promise;
}

/**
 * 兼容 Safari 老版本的 decodeAudioData 封装。
 */
function _decodeAudio(c, arrayBuffer){
  return new Promise((resolve, reject) => {
    const ret = c.decodeAudioData(arrayBuffer, resolve, reject);
    /* 部分浏览器返回 Promise */
    if (ret && typeof ret.then === 'function'){
      ret.then(resolve, reject);
    }
  });
}

/**
 * 播放音效（无位置）。
 * @param {string} name
 * @param {object} [opts] { volume, loop, rate }
 * @returns {object|null}  句柄 { stop(), setVolume(v), get playing() }
 */
export function playSound(name, opts){
  const c = initAudio();
  if (!c || c.state !== 'running') return null;
  if (!sfxEnabled) return null;

  const buf = _soundBuffers.get(name);
  if (!buf){
    /* 懒加载：加载完成后再播 */
    loadSound(name).then(b => {
      if (b) _playBuffer(c, b, opts || {});
    });
    return null;
  }
  return _playBuffer(c, buf, opts || {});
}

/**
 * 播放 3D 位置音效。
 * @param {string} name
 * @param {number} x, y, z
 * @param {object} [opts] { volume, loop, rate, maxDist }
 * @returns {object|null}
 */
export function playSoundAt(name, x, y, z, opts){
  const c = initAudio();
  if (!c || c.state !== 'running') return null;
  if (!sfxEnabled) return null;

  opts = opts || {};
  const buf = _soundBuffers.get(name);
  if (!buf){
    loadSound(name).then(b => {
      if (b) _playBuffer(c, b, { ...opts, x, y, z });
    });
    return null;
  }
  return _playBuffer(c, buf, { ...opts, x, y, z });
}

/**
 * 停止所有正在播放的文件音效。
 */
const _activeSounds = new Set();

export function stopAllSounds(){
  for (const h of _activeSounds){
    try { h.stop(); } catch(e){}
  }
  _activeSounds.clear();
}

/**
 * 内部：实际播放一个 AudioBuffer。
 */
function _playBuffer(c, buffer, opts){
  try {
    /* ---- 计算音量 / 立体声 ---- */
    let volume = opts.volume !== undefined ? opts.volume : 1.0;
    let pan = 0;
    let hasPan = false;

    if (opts.x !== undefined && opts.y !== undefined && opts.z !== undefined){
      const lp = _getListenerPos();
      const lf = _getListenerDir();

      const dx = opts.x - lp.x;
      const dy = opts.y - lp.y;
      const dz = opts.z - lp.z;
      const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);

      const maxDist = opts.maxDist || 32;
      if (dist > maxDist) return null;

      /* 距离衰减：平方曲线，听觉上更自然 */
      const t = 1 - dist / maxDist;
      volume *= t * t;

      /* 立体声：右向量 = (-fz, 0, fx) 是 forward 顺时针 90° */
      const rightX = -lf.z, rightZ = lf.x;
      const rlen = Math.hypot(rightX, rightZ);
      if (rlen > 0.01 && dist > 0.01){
        const dot = (dx * rightX + dz * rightZ) / (dist * rlen);
        pan = Math.max(-1, Math.min(1, dot));
        hasPan = true;
      }
    }

    if (volume <= 0.001) return null;

    /* ---- 构建节点图 ---- */
    const src = c.createBufferSource();
    src.buffer = buffer;
    src.loop = !!opts.loop;
    if (opts.rate && isFinite(opts.rate)){
      src.playbackRate.value = Math.max(0.1, Math.min(4, opts.rate));
    }

    const g = c.createGain();
    /* 短 fade in，避免爆音 */
    const now = c.currentTime;
    const when = now + 0.008;
    g.gain.setValueAtTime(SILENT, now);
    g.gain.linearRampToValueAtTime(volume, when);

    src.connect(g);

    let tail = g;
    if (hasPan){
      try {
        const panner = c.createStereoPanner();
        panner.pan.value = pan;
        g.connect(panner);
        tail = panner;
      } catch(e){
        /* 不支持 StereoPannerNode：忽略立体声 */
      }
    }
    tail.connect(sfxGain);

    src.start(when);

    /* ---- 返回句柄 ---- */
    let _ended = false;
    src.onended = () => {
      _ended = true;
      try { src.disconnect(); } catch(e){}
      try { g.disconnect(); } catch(e){}
      _activeSounds.delete(handle);
    };

    const handle = {
      src,
      gain: g,
      stop(){
        try { src.stop(); } catch(e){}
      },
      setVolume(v){
        const tt = c.currentTime;
        const nv = Math.max(0, Math.min(1, Number(v) || 0));
        try { g.gain.setTargetAtTime(nv, tt, 0.02); } catch(e){}
      },
      get playing(){ return !_ended; },
    };

    _activeSounds.add(handle);
    return handle;

  } catch(e){
    console.warn('[audio] play buffer failed:', e);
    return null;
  }
}

/* ============================== 基础工具 ============================== */

function getAudioContextCtor(){
  if (typeof window === 'undefined') return null;
  return window.AudioContext || window.webkitAudioContext || null;
}

function createNoiseBuffer(seconds){
  const len = Math.max(1, Math.floor(ctx.sampleRate * seconds));
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}

function hitEnv(param, t0, peak, attack, dur){
  const pk = Math.max(peak, 0.0004);
  const atk = Math.max(0.001, Math.min(attack, dur * 0.5));
  param.setValueAtTime(SILENT, t0);
  param.exponentialRampToValueAtTime(pk, t0 + atk);
  param.exponentialRampToValueAtTime(SILENT, t0 + Math.max(dur, atk + 0.005));
}

function adsrEnv(param, t0, peak, a, d, s, dur){
  const pk = Math.max(peak, 0.0004);
  const sus = Math.max(pk * (s !== undefined ? s : 0.4), 0.0004);
  let atk = Math.max(0.004, a || 0.03);
  let dec = Math.max(0.01, d || 0.2);
  if (atk + dec > dur * 0.8){
    const k = (dur * 0.8) / (atk + dec);
    atk *= k; dec *= k;
  }
  const rel = Math.max(0.03, Math.min(dur * 0.5, 0.45));
  const relStart = Math.max(t0 + atk + dec, t0 + dur - rel);
  const end = Math.max(t0 + dur, relStart + 0.02);
  param.setValueAtTime(SILENT, t0);
  param.exponentialRampToValueAtTime(pk, t0 + atk);
  param.exponentialRampToValueAtTime(sus, t0 + atk + dec);
  param.setValueAtTime(sus, relStart);
  param.exponentialRampToValueAtTime(SILENT, end);
  return end;
}

function makeVoice(durSec, isMusic){
  if (!ctx) return null;
  if (voiceCount >= MAX_VOICES) return null;
  voiceCount++;
  const nodes = [];
  let pending = 0;
  let released = false;
  let timer = 0;
  const release = function(){
    if (released) return;
    released = true;
    if (timer){ clearTimeout(timer); timer = 0; }
    voiceCount = Math.max(0, voiceCount - 1);
    for (let i = 0; i < nodes.length; i++){
      try { nodes[i].disconnect(); } catch (e) {}
    }
    nodes.length = 0;
  };
  return {
    src: function(node){ nodes.push(node); return node; },
    stop: function(node, when){
      pending++;
      try { node.stop(when); } catch (e) {}
      node.onended = function(){
        try { node.disconnect(); } catch (e) {}
        pending--;
        if (pending <= 0) release();
      };
    },
    end: function(){
      timer = setTimeout(release, Math.max(30, durSec * 1000) + 300);
    },
    isMusic: !!isMusic
  };
}

function noiseHit(t0, dur, o){
  const v = makeVoice(dur);
  if (!v || !noiseBuffer) return;
  o = o || {};
  const src = ctx.createBufferSource();
  src.buffer = noiseBuffer;
  src.loop = true;
  if (o.rate) src.playbackRate.value = o.rate;

  const flt = ctx.createBiquadFilter();
  flt.type = o.filter || 'lowpass';
  const f0 = Math.max(40, o.freq !== undefined ? o.freq : 1200);
  flt.frequency.setValueAtTime(f0, t0);
  if (o.sweepTo){
    flt.frequency.exponentialRampToValueAtTime(
      Math.max(40, o.sweepTo), t0 + dur * (o.sweepTime || 1));
  }
  if (o.q !== undefined) flt.Q.value = o.q;

  const g = ctx.createGain();
  hitEnv(g.gain, t0, o.peak !== undefined ? o.peak : 0.4,
         o.attack !== undefined ? o.attack : 0.003, dur);

  src.connect(flt); flt.connect(g); g.connect(sfxGain);
  v.src(src); v.src(flt); v.src(g);
  src.start(t0);
  v.stop(src, t0 + dur + 0.03);
  v.end();
}

function toneHit(t0, o){
  const dur = o.dur;
  const v = makeVoice(dur);
  if (!v) return;

  let peak = o.peak !== undefined ? o.peak : 0.4;
  let tremDepth = 0;
  if (o.trem){
    tremDepth = Math.min(o.trem.depth !== undefined ? o.trem.depth : peak * 0.4, peak * 0.7);
    peak = Math.max(0.02, peak - tremDepth * 2);
  }

  const osc = ctx.createOscillator();
  osc.type = o.type || 'sine';
  const f0 = Math.max(20, o.freq);
  osc.frequency.setValueAtTime(f0, t0);
  if (o.to && o.to > 0 && o.to !== f0){
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t0 + (o.glide || dur));
  }
  if (o.detune) osc.detune.value = o.detune;

  const g = ctx.createGain();
  if (o.sustain !== undefined){
    adsrEnv(g.gain, t0, peak, o.attack !== undefined ? o.attack : 0.02,
            0.18, o.sustain, dur);
  } else {
    hitEnv(g.gain, t0, peak, o.attack !== undefined ? o.attack : 0.004, dur);
  }

  let tail = g;
  if (o.lp){
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = o.lp;
    lp.Q.value = 0.7;
    g.connect(lp);
    tail = lp;
    v.src(lp);
  }
  osc.connect(g); v.src(osc); v.src(g);
  tail.connect(sfxGain);

  if (o.trem){
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = o.trem.rate || 5;
    const lg = ctx.createGain();
    lg.gain.value = tremDepth;
    lfo.connect(lg); lg.connect(g.gain);
    v.src(lfo); v.src(lg);
    lfo.start(t0);
    v.stop(lfo, t0 + dur + 0.03);
  } else if (o.vib){
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = o.vib.rate || 6;
    const lg = ctx.createGain();
    lg.gain.value = o.vib.cents !== undefined ? o.vib.cents : 15;
    lfo.connect(lg); lg.connect(osc.detune);
    v.src(lfo); v.src(lg);
    lfo.start(t0);
    v.stop(lfo, t0 + dur + 0.03);
  }

  osc.start(t0);
  v.stop(osc, t0 + dur + 0.03);
  v.end();
}

/* ============================== 音效表（合成） ============================== */

const SFX = {
  'dig.stone': function(t){
    noiseHit(t, 0.11, { filter: 'bandpass', freq: 1500, q: 1.2, peak: 0.5 });
    toneHit(t, { type: 'triangle', freq: 165, to: 95, dur: 0.09, peak: 0.28, lp: 800 });
  },
  'dig.wood': function(t){
    noiseHit(t, 0.09, { filter: 'bandpass', freq: 620, q: 3.2, peak: 0.45 });
    toneHit(t, { type: 'triangle', freq: 240, to: 150, dur: 0.07, peak: 0.22, lp: 1600 });
  },
  'dig.grass': function(t){
    noiseHit(t, 0.1, { filter: 'highpass', freq: 2400, peak: 0.3, attack: 0.004 });
    noiseHit(t + 0.02, 0.07, { filter: 'lowpass', freq: 700, peak: 0.18 });
  },
  'dig.sand': function(t){
    noiseHit(t, 0.13, { filter: 'lowpass', freq: 1100, sweepTo: 600, peak: 0.32, attack: 0.012 });
  },
  'dig.glass': function(t){
    noiseHit(t, 0.06, { filter: 'highpass', freq: 3200, peak: 0.3 });
    toneHit(t,        { type: 'triangle', freq: 2640, dur: 0.16, peak: 0.16, lp: 6000 });
    toneHit(t + 0.01, { type: 'triangle', freq: 3520, dur: 0.13, peak: 0.12, lp: 6000 });
    toneHit(t + 0.02, { type: 'sine',     freq: 4180, dur: 0.10, peak: 0.09 });
  },
  place: function(t){
    toneHit(t, { type: 'sine', freq: 200, to: 118, dur: 0.11, peak: 0.4, lp: 900 });
    noiseHit(t, 0.07, { filter: 'lowpass', freq: 900, peak: 0.26 });
  },
  'step.stone': function(t){
    noiseHit(t, 0.07, { filter: 'bandpass', freq: 950, q: 1.0, peak: 0.3 });
    toneHit(t, { type: 'sine', freq: 120, to: 80, dur: 0.06, peak: 0.2, lp: 600 });
  },
  'step.grass': function(t){
    noiseHit(t, 0.07, { filter: 'highpass', freq: 2100, peak: 0.24, attack: 0.005 });
  },
  'step.wood': function(t){
    noiseHit(t, 0.08, { filter: 'bandpass', freq: 520, q: 2.4, peak: 0.3 });
    toneHit(t, { type: 'triangle', freq: 190, to: 140, dur: 0.06, peak: 0.18, lp: 1400 });
  },
  'step.sand': function(t){
    noiseHit(t, 0.08, { filter: 'lowpass', freq: 950, peak: 0.24, attack: 0.01 });
  },
  hurt: function(t){
    toneHit(t, { type: 'sawtooth', freq: 430, to: 150, dur: 0.3, peak: 0.32, lp: 1500 });
    noiseHit(t, 0.14, { filter: 'bandpass', freq: 700, q: 0.8, peak: 0.16 });
  },
  eat: function(t){
    noiseHit(t,        0.09, { filter: 'lowpass', freq: 620, peak: 0.30, attack: 0.006 });
    noiseHit(t + 0.08, 0.08, { filter: 'lowpass', freq: 520, peak: 0.26, attack: 0.006 });
    noiseHit(t + 0.16, 0.11, { filter: 'lowpass', freq: 700, peak: 0.24, attack: 0.006 });
    toneHit(t + 0.02, { type: 'sine', freq: 130, to: 100, dur: 0.16, peak: 0.14, lp: 500 });
  },
  craft: function(t){
    noiseHit(t,        0.06, { filter: 'bandpass', freq: 600, q: 2.6, peak: 0.34 });
    noiseHit(t + 0.07, 0.06, { filter: 'bandpass', freq: 760, q: 2.6, peak: 0.30 });
    toneHit(t + 0.10, { type: 'sine', freq: 660, dur: 0.12, peak: 0.18 });
    toneHit(t + 0.18, { type: 'sine', freq: 990, dur: 0.14, peak: 0.15 });
  },
  pop: function(t){
    toneHit(t, { type: 'sine', freq: 380, to: 880, dur: 0.08, peak: 0.35, glide: 0.06 });
  },
  bow: function(t){
    toneHit(t, { type: 'triangle', freq: 260, to: 110, dur: 0.16, peak: 0.22, lp: 1400 });
    noiseHit(t, 0.10, { filter: 'bandpass', freq: 900, q: 2.2, peak: 0.22 });
  },
  'arrow.hit': function(t){
    noiseHit(t, 0.045, { filter: 'highpass', freq: 2600, peak: 0.2 });
    toneHit(t, { type: 'square', freq: 520, to: 300, dur: 0.05, peak: 0.14, lp: 1800 });
  },
  click: function(t){
    toneHit(t, { type: 'square', freq: 1150, to: 900, dur: 0.03, peak: 0.16, lp: 3200 });
    noiseHit(t, 0.025, { filter: 'highpass', freq: 3800, peak: 0.12 });
  },
  splash: function(t){
    noiseHit(t, 0.32, { filter: 'lowpass', freq: 3200, sweepTo: 380, peak: 0.35, attack: 0.01 });
    noiseHit(t + 0.04, 0.16, { filter: 'bandpass', freq: 1300, q: 0.9, peak: 0.2 });
    toneHit(t + 0.10, { type: 'sine', freq: 420, to: 760, dur: 0.10, peak: 0.12 });
    toneHit(t + 0.18, { type: 'sine', freq: 560, to: 900, dur: 0.09, peak: 0.10 });
  },
  'water.fall': function(t){
    noiseHit(t,        0.50, { filter: 'lowpass',  freq: 2800, sweepTo: 500, peak: 0.32, attack: 0.02 });
    noiseHit(t + 0.03, 0.40, { filter: 'bandpass', freq: 900,  q: 0.6,      peak: 0.22 });
    noiseHit(t + 0.08, 0.15, { filter: 'highpass', freq: 3200,              peak: 0.12 });
  },
  'lava.sizzle': function(t){
    noiseHit(t, 0.40, { filter: 'lowpass', freq: 400, peak: 0.16, attack: 0.05 });
    for (let i = 0; i < 5; i++){
      noiseHit(t + i * 0.06 + Math.random() * 0.02, 0.02,
        { filter: 'bandpass', freq: 1800 + Math.random() * 2000, q: 2, peak: 0.09 });
    }
  },
  furnace: function(t){
    noiseHit(t,        0.340, { filter: 'lowpass',  freq: 320, peak: 0.20, attack: 0.05 });
    noiseHit(t + 0.04, 0.040, { filter: 'bandpass', freq: 2400, q: 2.0, peak: 0.16 });
    noiseHit(t + 0.12, 0.035, { filter: 'bandpass', freq: 3000, q: 2.4, peak: 0.13 });
    noiseHit(t + 0.21, 0.040, { filter: 'bandpass', freq: 1900, q: 2.0, peak: 0.15 });
    noiseHit(t + 0.29, 0.030, { filter: 'bandpass', freq: 2700, q: 2.2, peak: 0.10 });
  },
  'mob.cow': function(t){
    toneHit(t, { type: 'sawtooth', freq: 196, to: 148, dur: 0.34, peak: 0.34,
                 lp: 780, detune: -6, trem: { rate: 11, depth: 0.07 } });
  },
  'mob.sheep': function(t){
    toneHit(t, { type: 'sawtooth', freq: 350, to: 300, dur: 0.30, peak: 0.24,
                 lp: 1300, vib: { rate: 7.5, cents: 28 } });
  },
  'mob.chicken': function(t){
    toneHit(t,        { type: 'square', freq: 980,  to: 720, dur: 0.06, peak: 0.18, lp: 3400 });
    toneHit(t + 0.09, { type: 'square', freq: 1150, to: 820, dur: 0.07, peak: 0.16, lp: 3400 });
  },
  levelup: function(t){
    const notes = [523.25, 659.25, 783.99, 1046.5];
    for (let i = 0; i < notes.length; i++){
      toneHit(t + i * 0.06, { type: 'sine', freq: notes[i], dur: 0.13, peak: 0.22, attack: 0.008 });
    }
    toneHit(t + 0.06, { type: 'triangle', freq: 261.63, dur: 0.24, peak: 0.12, lp: 2000 });
  }
};

/* ============================== 公开 API ============================== */

export function initAudio(){
  try {
    if (!ctx){
      const Ctor = getAudioContextCtor();
      if (!Ctor) return null;
      const c = new Ctor();
      ctx = c;
      masterGain = ctx.createGain();
      masterGain.gain.value = masterVolume;
      masterGain.connect(ctx.destination);

      sfxGain = ctx.createGain();
      sfxGain.gain.value = 0.9;
      sfxGain.connect(masterGain);

      /* 背景音乐交给 music.js（webaudiofont 预渲染 + 智能调度） */
      initMusic(ctx, masterGain);

      noiseBuffer = createNoiseBuffer(1.0);
    }
    if (ctx.state === 'suspended' && typeof ctx.resume === 'function'){
      const p = ctx.resume();
      if (p && typeof p.catch === 'function') p.catch(function(){});
    }
    return ctx;
  } catch (e){
    ctx = null; masterGain = null; sfxGain = null; noiseBuffer = null;
    return null;
  }
}

export function playSFX(name){
  if (!sfxEnabled) return;
  const fn = SFX[name];
  if (typeof fn !== 'function') return;

  const throttle = SFX_THROTTLE[name];
  if (throttle){
    const now = (typeof performance !== 'undefined' && performance.now)
      ? performance.now() : Date.now();
    if (lastSfxTime[name] && now - lastSfxTime[name] < throttle) return;
    lastSfxTime[name] = now;
  }

  const c = initAudio();
  if (!c || c.state !== 'running') return;
  try { fn(c.currentTime + 0.01); } catch (e) { }
}

let sfxVolume = 1;

export function setSfxVolume(v){
  const n = Number(v);
  sfxVolume = isFinite(n) ? Math.max(0, Math.min(1, n)) : sfxVolume;
  if (ctx && sfxGain){
    try { sfxGain.gain.setTargetAtTime(0.9 * sfxVolume, ctx.currentTime, 0.02); }
    catch (e) { sfxGain.gain.value = 0.9 * sfxVolume; }
  }
  return sfxVolume;
}
export function getSfxVolume(){ return sfxVolume; }

export function setSfxEnabled(b){
  sfxEnabled = !!b;
  if (!sfxEnabled) stopAllSounds();
  return sfxEnabled;
}

/* ============================== 洞穴环境音 ==============================
   低频空气声 + 偶发滴水回音。由 ambience.js 根据玩家是否在洞穴里启停。
   接到 sfxGain 上，所以音效音量滑块同样控制它。 */
let _caveAmb = null;

export function startCaveAmbience(){
  const c = initAudio();
  if (!c || c.state !== 'running' || _caveAmb) return !!_caveAmb;

  try {
    const bed = c.createGain();
    bed.gain.value = 0.0001;
    const mod = c.createGain();
    mod.gain.value = 1;
    bed.connect(mod);
    mod.connect(sfxGain);

    /* 低通噪声：洞穴的"空气" */
    const src = c.createBufferSource();
    src.buffer = createNoiseBuffer(5);
    src.loop = true;
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 165;
    lp.Q.value = 0.5;
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 28;
    src.connect(lp);
    lp.connect(hp);
    hp.connect(bed);

    /* 缓慢起伏，避免死板的白噪声 */
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.045;
    const lfoGain = c.createGain();
    lfoGain.gain.value = 0.35;
    lfo.connect(lfoGain);
    lfoGain.connect(mod.gain);

    const t0 = c.currentTime;
    src.start(t0);
    lfo.start(t0);
    bed.gain.setTargetAtTime(0.075, t0, 1.2);

    _caveAmb = {
      c, bed, src, extra: [lp, hp, lfo, lfoGain, mod],
      nextDrip: t0 + 2 + Math.random() * 4,
    };
  } catch (e){
    _caveAmb = null;
  }
  return !!_caveAmb;
}

export function stopCaveAmbience(){
  const a = _caveAmb;
  if (!a) return;
  _caveAmb = null;
  try {
    const t = a.c.currentTime;
    a.bed.gain.cancelScheduledValues(t);
    a.bed.gain.setTargetAtTime(0.0001, t, 0.35);
    setTimeout(() => {
      try { a.src.stop(); } catch (e) {}
      try { a.src.disconnect(); a.bed.disconnect(); for (const n of a.extra) n.disconnect(); } catch (e) {}
    }, 1400);
  } catch (e) {}
}

function _caveDrip(c){
  const t = c.currentTime + 0.02;
  const freq = 760 + Math.random() * 900;

  const osc = c.createOscillator();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(freq, t);
  osc.frequency.exponentialRampToValueAtTime(freq * 0.72, t + 0.14);

  const env = c.createGain();
  env.gain.setValueAtTime(0.0001, t);
  env.gain.exponentialRampToValueAtTime(0.045, t + 0.006);
  env.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);

  const pan = (typeof c.createStereoPanner === 'function') ? c.createStereoPanner() : null;
  let out = env;
  if (pan){ pan.pan.value = (Math.random() * 2 - 1) * 0.75; env.connect(pan); out = pan; }

  /* 回声：短延迟 + 衰减反馈，几秒后自动静音回收 */
  const delay = c.createDelay(0.8);
  delay.delayTime.value = 0.24 + Math.random() * 0.12;
  const fb = c.createGain();
  fb.gain.value = 0.3;
  const wet = c.createGain();
  wet.gain.value = 0.55;
  out.connect(delay);
  delay.connect(fb);
  fb.connect(delay);
  delay.connect(wet);
  wet.connect(_caveAmb.bed);

  osc.connect(env);
  out.connect(_caveAmb.bed);
  osc.start(t);
  osc.stop(t + 0.25);

  setTimeout(() => {
    try { fb.gain.value = 0; osc.disconnect(); } catch (e) {}
  }, 6000);
}

/** 每帧调用：按需生成滴水回音 */
export function tickCaveAmbience(){
  const a = _caveAmb;
  if (!a) return;
  const c = a.c;
  if (c.state !== 'running') return;
  if (c.currentTime >= a.nextDrip){
    _caveDrip(c);
    a.nextDrip = c.currentTime + 4.5 + Math.random() * 8;
  }
}

export function setVolume(v){
  const n = Number(v);
  masterVolume = isFinite(n) ? Math.max(0, Math.min(1, n)) : masterVolume;
  if (ctx && masterGain){
    const t = ctx.currentTime;
    try { masterGain.gain.setTargetAtTime(masterVolume, t, 0.02); }
    catch (e) { masterGain.gain.value = masterVolume; }
  }
  return masterVolume;
}

export function getVolume(){
  return masterVolume;
}

/* ============================== 背景音乐 ==============================
   实现在 music.js：webaudiofont 预渲染、落盘缓存、按区块停留调度。
   这里统一重导出，保持 main.js / settings.js / mod-host.js 的旧导入路径可用。 */
export {
  startMusic, stopMusic, setMusicEnabled, isMusicEnabled,
  setMusicVolume, getMusicVolume, updateMusicScheduler,
  registerMusicTrack, unregisterMusicTrack, listMusicTracks,
  setMusicOwner, getMusicOwner, playMusicById, playMusicUrl,
  stopMusicPlayback, isMusicPlaying, getCurrentMusicId,
  onMusicEnded, offMusicEnded,
} from './music.js';