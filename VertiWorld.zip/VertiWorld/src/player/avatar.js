/* ============================================================
   avatar.js —— 玩家实体外观 + 背包角色面板预览
   ------------------------------------------------------------
   玩家实体：竖直的纯色发光长方体，头与身体同截面但独立，
   头部可随视角转动；眼睛是两块方形亮片，中间有方形黑眼珠。
   第一人称隐藏，第二/第三人称显示。

   角色面板：独立的小型 WebGL 渲染器，复用同一套模型，
   头部和眼珠跟随鼠标。盔甲以金属色块覆盖在身体对应位置。
   ============================================================ */

import * as THREE from '../vendor/three.module.js';
import { scene } from '../render/render-core.js';
import { player } from './player-core.js';
import { getViewMode } from './view-mode.js';
import { BLOCKS } from '../world/blocks.js';

const BODY_W = 0.46, BODY_H = 1.30, BODY_D = 0.30;
const HEAD_W = 0.46, HEAD_H = 0.50, HEAD_D = 0.30;

const GLOW = 0x79dcf2;

function _glowMat(){
  return new THREE.MeshLambertMaterial({
    color: 0x16323a, emissive: GLOW, emissiveIntensity: 0.85,
  });
}

function _armorMat(hex){
  return new THREE.MeshLambertMaterial({ color: hex, emissive: 0x2a323c });
}

/* 盔甲材质颜色：按装备 id 前缀区分铜/金/铁/钻 */
const ARMOR_TINTS = {
  copper:  0xc87a3c,
  gold:    0xf0d040,
  iron:    0xc9d3e0,
  diamond: 0x5ee0e0,
  ancient: 0x8a99a2,
};
const ARMOR_SLOT_SHADE = { head: 1.08, chest: 1.0, legs: 0.9, feet: 0.82 };

function _armorTint(item){
  /* 背包里存的是数字方块 id，需要先转回名字（iron_helmet 等） */
  const b = item ? BLOCKS[item.id] : null;
  const id = b ? b.name : (item && item.id ? String(item.id) : '');
  for (const mat in ARMOR_TINTS){
    if (id.startsWith(mat + '_')) return ARMOR_TINTS[mat];
  }
  return ARMOR_TINTS.iron;
}

function _box(w, h, d, mat, x, y, z){
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  return m;
}

/**
 * 构建玩家外观模型。
 * 原点在脚底，朝 -Z。
 */
export function buildAvatarModel(){
  const g = new THREE.Group();
  const glow = _glowMat();

  /* 身体：竖直长方体 */
  g.add(_box(BODY_W, BODY_H, BODY_D, glow, 0, BODY_H / 2, 0));

  /* 头：与身体同宽同深，独立可转 */
  const head = new THREE.Group();
  head.position.y = BODY_H;
  head.add(_box(HEAD_W, HEAD_H, HEAD_D, glow, 0, HEAD_H / 2, 0));

  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xeaffff });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x05070d });
  const shineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const pupils = [];
  for (const sx of [-1, 1]){
    /* 卡哇伊大眼睛：大眼白 + 大黑眼珠 + 一点高光 */
    const eye = _box(0.17, 0.17, 0.012, eyeMat, sx * 0.11, HEAD_H * 0.62, -HEAD_D / 2 - 0.006);
    head.add(eye);
    const pupil = _box(0.095, 0.095, 0.012, pupilMat, sx * 0.11, HEAD_H * 0.62, -HEAD_D / 2 - 0.014);
    head.add(pupil);
    const shine = _box(0.03, 0.03, 0.012, shineMat,
      sx * 0.11 - 0.022, HEAD_H * 0.62 + 0.022, -HEAD_D / 2 - 0.02);
    head.add(shine);
    pupils.push({ mesh: pupil, bx: sx * 0.11, by: HEAD_H * 0.62 });
  }
  g.add(head);

  /* 盔甲覆盖层（默认隐藏） */
  const armor = {
    head:  _box(HEAD_W + 0.06, 0.13, HEAD_D + 0.06, _armorMat(0xd6dee9), 0, HEAD_H - 0.04, 0),
    chest: _box(BODY_W + 0.06, 0.62, BODY_D + 0.06, _armorMat(0xc9d3e0), 0, 1.00, 0),
    legs:  _box(BODY_W + 0.04, 0.42, BODY_D + 0.04, _armorMat(0xb7c2d0), 0, 0.42, 0),
    feet:  _box(BODY_W + 0.06, 0.16, BODY_D + 0.06, _armorMat(0xa8b4c4), 0, 0.08, 0),
  };
  for (const k in armor){
    armor[k].visible = false;
    if (k === 'head') head.add(armor[k]);
    else g.add(armor[k]);
  }

  return { group: g, head, pupils, armor };
}

/* ============================================================
   世界中的玩家实体
   ============================================================ */
let worldAvatar = null;

export function initPlayerAvatar(){
  if (worldAvatar) return worldAvatar;
  worldAvatar = buildAvatarModel();
  worldAvatar.group.visible = false;
  scene.add(worldAvatar.group);
  return worldAvatar;
}

export function applyArmorVisibility(model, armorState){
  for (const k in model.armor){
    const it = armorState ? armorState[k] : null;
    const mesh = model.armor[k];
    mesh.visible = !!it;
    if (it && mesh.material){
      const c = new THREE.Color(_armorTint(it));
      c.multiplyScalar(ARMOR_SLOT_SHADE[k] || 1);
      mesh.material.color.copy(c);
    }
  }
}

export function updatePlayerAvatar(){
  if (!worldAvatar) return;
  const show = getViewMode() !== 0;
  worldAvatar.group.visible = show;
  if (!show) return;
  worldAvatar.group.position.set(player.pos.x, player.pos.y, player.pos.z);
  worldAvatar.group.rotation.y = player.yaw;
  worldAvatar.head.rotation.x = player.pitch * 0.8;
  applyArmorVisibility(worldAvatar, player.armor);
}

/* ============================================================
   背包里的角色面板
   ============================================================ */
let preview = null;
let previewLook = { x: 0, y: 0 };
let previewActive = false;

export function setCharPreviewActive(on){
  previewActive = !!on;
}

export function setCharLook(nx, ny){
  previewLook.x = Math.max(-1, Math.min(1, nx || 0));
  previewLook.y = Math.max(-1, Math.min(1, ny || 0));
  if (!preview) return;
  /* 面板模型转 180°，让正面朝向玩家；左右转向仍跟鼠标同向 */
  preview.head.rotation.y = previewLook.x * 0.7;
  preview.head.rotation.x = previewLook.y * 0.45;
  for (const p of preview.pupils){
    p.mesh.position.x = p.bx - previewLook.x * 0.022;
    p.mesh.position.y = p.by - previewLook.y * 0.022;
  }
}

export function initCharPreview(canvas){
  if (preview) return true;
  if (!canvas) return false;
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  } catch (e){
    return false;
  }
  renderer.setClearColor(0x000000, 0);

  const ps = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(34, 1, 0.1, 30);
  cam.position.set(0, 1.05, 3.5);
  cam.lookAt(0, 0.95, 0);

  ps.add(new THREE.AmbientLight(0xffffff, 0.95));
  const key = new THREE.DirectionalLight(0xffffff, 1.15);
  key.position.set(2.5, 4, 3);
  ps.add(key);
  const rim = new THREE.DirectionalLight(0x88ccff, 0.7);
  rim.position.set(-3, 2, -2);
  ps.add(rim);

  const model = buildAvatarModel();
  /* 模型默认朝 -Z，面板相机在 +Z，转 180° 才能看到正脸 */
  model.group.rotation.y = Math.PI;
  ps.add(model.group);

  preview = { renderer, scene: ps, camera: cam, model, head: model.head, pupils: model.pupils };
  resizeCharPreview(canvas.clientWidth, canvas.clientHeight);
  applyArmorVisibility(model, player.armor);
  setCharLook(0, 0);
  return true;
}

export function resizeCharPreview(w, h){
  if (!preview) return;
  const W = Math.max(1, Math.floor(w || 140));
  const H = Math.max(1, Math.floor(h || 260));
  preview.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  preview.renderer.setSize(W, H, false);
  preview.camera.aspect = W / H;
  preview.camera.updateProjectionMatrix();
}

export function renderCharPreview(){
  if (!preview || !previewActive) return;
  applyArmorVisibility(preview.model, player.armor);
  preview.renderer.render(preview.scene, preview.camera);
}
