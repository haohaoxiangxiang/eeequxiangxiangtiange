/* ============================================================
   player-core.js —— 输入 + 玩家状态机
   ------------------------------------------------------------
★ 合并自两个玩家文件（约 26KB）：
     input.js   键鼠 / 触屏 / 摇杆 / 输入独占（consume、suspend）
     player.js  玩家状态、移动碰撞、血/饿/氧、视角、维度位置记忆
   读输入的到处都有，但真正"动"只有 player.js，合在一起更方便追。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from 'three';
import { BLOCKS } from '../world/blocks.js';
import { IS_TOUCH } from './../core/engine-core.js';
import { PLAYER_W, PLAYER_H, SEA_LEVEL, Y_MIN } from './../core/engine-core.js';
import { camera } from './../render/render-core.js';
import { clamp } from './../core/runtime.js';
import { emit, defineHook } from './../core/engine-core.js';
import { getBlockWorld, heightAt, biomeAt, isWaterLike, isWorldBlockLoaded } from '../world/terrain.js';
import { playSFX } from '../audio/audio.js';
import { spawnSplash } from './../world/world-core.js';
import { applyViewCamera } from './view-mode.js';
import {
  actionsForCode, canonicalKeyFor, padCodeForIndex, runBindingCallback,
} from '../core/key-bindings.js';

/* ============================================================
   ★ 移动参数（可在运行时通过 G.setMovementConfig 调整）
   ------------------------------------------------------------
   单位：速度为格/秒，加速度为格/秒²，时间为秒。
   只接受有限数字，非法值会被忽略。
   ============================================================ */
const DEFAULT_MOVEMENT_CONFIG = Object.freeze({
  walkSpeed: 4.4,
  sneakSpeed: 2.0,
  sprintSpeed: 7.0,
  waterSpeed: 3.6,
  flySpeed: 12,
  flySprintSpeed: 26,
  groundAccel: 14,
  airAccel: 5,
  jumpVelocity: 8.6,
  gravity: 28,
  maxFallSpeed: 58,
  flyingVerticalFactor: 0.8,
  waterGravity: 9,
  waterBuoyancy: 3.4,
  waterDamping: 2.2,
  waterMaxSpeed: 5,
});

const movementConfig = { ...DEFAULT_MOVEMENT_CONFIG };

function _validNum(v){
  return typeof v === 'number' && Number.isFinite(v);
}

function setMovementConfig(partial){
  if (!partial || typeof partial !== 'object') return { ...movementConfig };
  for (const k of Object.keys(DEFAULT_MOVEMENT_CONFIG)){
    if (_validNum(partial[k])) movementConfig[k] = partial[k];
  }
  return { ...movementConfig };
}

function getMovementConfig(){
  return { ...movementConfig };
}

function resetMovementConfig(){
  Object.assign(movementConfig, DEFAULT_MOVEMENT_CONFIG);
  return getMovementConfig();
}


/* =================================================================
   player/input.js
   ================================================================= */
const input = {
  keys: {},
  /* ★ 动作绑定状态（键位可在设置里自由修改，移动等逻辑只认这里） */
  actions: {},
  jump: false,
  sneak: false,
  sprintToggle: false,
  mine: false,
  place: false,
  joyX: 0,
  joyY: 0,
  doubleJump: false,
  toggleFly: false,
  toggleInv: false,
  resetPos: false,
  selectSlot: -1,
  bowHold: false,
  bowRelease: false,
  bowEquipped: false,
  /* ★ 屏幕上的「左键 / 右键」按钮（可自定义布局添加） */
  uiMine: false,
  uiUse: false,
  /* ★ 触屏短按标记：准星模式用 tap；触点模式的落点用 tapScreen */
  tap: false,
  tapScreen: null,
  mineScreen: null
};

/* ---- 触屏瞄准方式：'crosshair' 准星（默认，基岩版） / 'finger' 手指落点 ---- */
let touchAimMode = 'crosshair';
function setTouchAimMode(mode){
  touchAimMode = (mode === 'finger') ? 'finger' : 'crosshair';
  return touchAimMode;
}
function getTouchAimMode(){ return touchAimMode; }

/* ---- 视角灵敏度（倍率，1.0 为基准） ---- */
let lookSensitivity = 1.0;
function setLookSensitivity(v){
  lookSensitivity = (typeof v === 'number' && isFinite(v) && v > 0) ? v : 1.0;
}
function getLookSensitivity(){ return lookSensitivity; }

/* ---- 拿游戏画布（必须显式按 id 取，不能用 querySelector('canvas')，
       否则会选到菜单里的 <canvas id="worldPreview">） ---- */
function getGameCanvas(){
  return document.getElementById('game-canvas');
}

/* ---- 飞行双击检测 ---- */
let lastJumpTime = 0;
let pendingFlyToggle = false;

function jumpDown(){
  const now = performance.now();
  if (now - lastJumpTime < 380){
    pendingFlyToggle = true;
    lastJumpTime = 0;
  } else {
    lastJumpTime = now;
  }
  input.jump = true;
}
function jumpUp(){ input.jump = false; }

/* ============================================================
   ★ 动作绑定：键盘 / 鼠标 / 手柄 → 游戏动作
   ------------------------------------------------------------
   键位来自 core/key-bindings.js（设置里可改），这里只负责把
   「这个键被按下」翻译成动作状态。移动逻辑只读 input.actions，
   所以把前进从 W 改成 ↑ 之后，W 就真的不再前进。
   ============================================================ */
const _virtualPad = Object.create(null);
const _padHeld = Object.create(null);

function setVirtualPad(code, down){
  if (code) _virtualPad[code] = !!down;
}

function applyBoundAction(action, down, ev){
  if (!action) return false;
  const next = !!down;
  const prev = !!input.actions[action];
  input.actions[action] = next;
  const canon = canonicalKeyFor(action);
  if (canon) input.keys[canon] = next;
  switch (action){
    case 'jump':
      if (next) jumpDown(); else jumpUp();
      if (next && ev && ev.preventDefault) ev.preventDefault();
      break;
    case 'sneak':
      input.sneak = next;
      break;
    case 'inventory':
      if (next) input.toggleInv = true;
      break;
    case 'fly':
      if (next) pendingFlyToggle = true;
      break;
    case 'resetPos':
      if (next) input.resetPos = true;
      break;
  }
  if (prev !== next) runBindingCallback(action, next);
  return true;
}

/* 键码 → 动作。手柄码只在虚拟按键/轮询里生效
   ★ 允许一个键绑多个动作（冲突时全部触发，和 MC 一样） */
function applyBindingCode(code, down, ev){
  if (!code) return false;
  if (code.indexOf('pad:') === 0){
    setVirtualPad(code, down);
    return true;
  }
  const acts = actionsForCode(code);
  if (!acts.length) return false;
  for (const a of acts) applyBoundAction(a, down, ev);
  return true;
}

/* 物理手柄（标准映射）+ 屏幕上的虚拟手柄按钮 */
function pollGamepads(){
  const now = Object.create(null);
  let pads = [];
  try {
    pads = navigator.getGamepads ? (navigator.getGamepads() || []) : [];
  } catch(e){ pads = []; }
  for (let i = 0; i < pads.length; i++){
    const p = pads[i];
    if (!p || !p.buttons) continue;
    for (let b = 0; b < p.buttons.length; b++){
      const st = p.buttons[b];
      if (st && (st.pressed || st.value > 0.35)){
        const code = padCodeForIndex(b);
        if (code) now[code] = true;
      }
    }
  }
  for (const code in _virtualPad){
    if (_virtualPad[code]) now[code] = true;
  }
  /* 只在状态变化时触发，避免跳跃/背包这种边沿动作连发 */
  for (const code in now){
    if (_padHeld[code]) continue;
    _padHeld[code] = true;
    for (const a of actionsForCode(code)) applyBoundAction(a, true, null);
  }
  for (const code in _padHeld){
    if (!_padHeld[code] || now[code]) continue;
    _padHeld[code] = false;
    for (const a of actionsForCode(code)) applyBoundAction(a, false, null);
  }
}

/* 进入编辑/选择按键时清掉按住的键，避免卡住 */
window.__resetGameKeys = () => {
  for (const k in input.keys) input.keys[k] = false;
  for (const k in input.actions) input.actions[k] = false;
  for (const k in _virtualPad) _virtualPad[k] = false;
  input.jump = false;
  input.sneak = false;
};

/* ---- 键盘 ---- */
window.addEventListener('keydown', e => {
  if (e.repeat) return;
  /* 按键编辑模式 / 选择按键弹窗里，键盘用于改键，不驱动游戏 */
  if (window.__keyPickerOpen) return;
  if (document.body.classList.contains('touch-editing')) return;
  /* F5：切换人称，阻止浏览器刷新 */
  if (e.code === 'F5'){
    e.preventDefault();
    input.cycleView = true;
    return;
  }
  input.keys[e.code] = true;
  applyBindingCode(e.code, true, e);
  if (e.code.startsWith('Digit')){
    const n = parseInt(e.code.slice(5), 10);
    if (n >= 1 && n <= 9) input.selectSlot = n - 1;
  }
  if (e.code === 'Escape') input.toggleInv = true;
});
window.addEventListener('keyup', e => {
  input.keys[e.code] = false;
  applyBindingCode(e.code, false, e);
});

/* ---- 鼠标 ---- */
let isLocked = false;
let mouseLeft = false, mouseRight = false;

function initMouseLock(){
  const c = getGameCanvas();
  if (!c) return;

  c.addEventListener('mousedown', e => {
    if (IS_TOUCH) return;                          // 触屏模式忽略鼠标
    if (document.body.classList.contains('touch-editing')) return;
    if (!isLocked){ c.requestPointerLock(); return; }
    if (e.button === 0){
      mouseLeft = true;
      for (const a of actionsForCode('mouseLeft')) applyBoundAction(a, true, e);
    }
    if (e.button === 2){
      mouseRight = true;
      for (const a of actionsForCode('mouseRight')) applyBoundAction(a, true, e);
    }
  });

  window.addEventListener('mouseup', e => {
    if (IS_TOUCH) return;
    if (e.button === 0){
      mouseLeft = false;
      for (const a of actionsForCode('mouseLeft')) applyBoundAction(a, false, e);
    }
    if (e.button === 2){
      mouseRight = false;
      for (const a of actionsForCode('mouseRight')) applyBoundAction(a, false, e);
    }
  });

  c.addEventListener('contextmenu', e => e.preventDefault());

  document.addEventListener('pointerlockchange', () => {
    isLocked = document.pointerLockElement === c;
    if (!isLocked){ mouseLeft = false; mouseRight = false; }
  });

  document.addEventListener('mousemove', e => {
    if (IS_TOUCH || !isLocked) return;
    const s = 0.0024 * lookSensitivity;
    input.yawDelta   = (input.yawDelta   || 0) - e.movementX * s;
    input.pitchDelta = (input.pitchDelta || 0) - e.movementY * s;
  });

  window.addEventListener('wheel', e => {
    if (IS_TOUCH) return;
    input.wheelDelta = (input.wheelDelta || 0) + (e.deltaY > 0 ? 1 : -1);
  }, { passive: true });
}

/* ---- 触屏手势 ---- */
function initTouchGestures(){
  const c = getGameCanvas();
  if (!c) return;

  const gesture = {
    id: null, startX: 0, startY: 0, lastX: 0, lastY: 0,
    startT: 0, moved: false, mining: false, bowing: false, longTimer: null
  };
  const MOVE_THRESHOLD = 12;
  const LONG_PRESS_MS = 240;

  function clearLongTimer(){
    if (gesture.longTimer){ clearTimeout(gesture.longTimer); gesture.longTimer = null; }
  }
  function resetGesture(){
    clearLongTimer();
    gesture.id = null;
    gesture.mining = false;
    gesture.bowing = false;
    gesture.moved = false;
    input.mine = false;
    input.bowHold = false;
    input.tap = false;
    input.tapScreen = null;
    input.mineScreen = null;
  }

  c.addEventListener('touchstart', e => {
    if (!IS_TOUCH) return;
    if (document.body.classList.contains('touch-editing')) return;
    if (document.getElementById('inv').classList.contains('show')) return;
    if (document.getElementById('settings').classList.contains('show')) return;
    for (const t of e.changedTouches){
      if (gesture.id === null){
        gesture.id = t.identifier;
        gesture.startX = gesture.lastX = t.clientX;
        gesture.startY = gesture.lastY = t.clientY;
        /* ★ 用事件时间戳而不是 performance.now()：低端机主线程卡顿时，
           触摸回调会延后执行，用回调时刻计时会把快速点击误判成长按 */
        gesture.startT = (e.timeStamp > 0) ? e.timeStamp : performance.now();
        gesture.moved = false;
        gesture.mining = false;
        gesture.bowing = false;
        clearLongTimer();
        gesture.longTimer = setTimeout(() => {
          if (!gesture.moved && gesture.id !== null){
            if (input.bowEquipped){
              gesture.bowing = true;
              input.bowHold = true;
            } else {
              gesture.mining = true;
              input.mine = true;
              /* 触点模式：长按挖手指指着的方块；准星模式由主循环用中心准星 */
              if (touchAimMode === 'finger')
                input.mineScreen = { x: gesture.startX, y: gesture.startY };
            }
          }
        }, LONG_PRESS_MS);
      }
    }
  }, { passive: true });

  c.addEventListener('touchmove', e => {
    if (!IS_TOUCH) return;
    for (const t of e.changedTouches){
      if (t.identifier !== gesture.id) continue;
      const dx = t.clientX - gesture.lastX;
      const dy = t.clientY - gesture.lastY;
      gesture.lastX = t.clientX;
      gesture.lastY = t.clientY;
      const totalDx = t.clientX - gesture.startX;
      const totalDy = t.clientY - gesture.startY;
      if (!gesture.moved && Math.hypot(totalDx, totalDy) > MOVE_THRESHOLD){
        gesture.moved = true;
        clearLongTimer();
      }
      if (gesture.moved && !gesture.mining){
        const ts = 0.0052 * lookSensitivity;
        input.yawDelta   = (input.yawDelta   || 0) - dx * ts;
        input.pitchDelta = (input.pitchDelta || 0) - dy * ts;
      }
    }
  }, { passive: true });

  function endGesture(e){
    if (!IS_TOUCH) return;
    for (const t of e.changedTouches){
      if (t.identifier !== gesture.id) continue;
      clearLongTimer();
      const endT = (e.timeStamp > 0) ? e.timeStamp : performance.now();
      let duration = endT - gesture.startT;
      if (!(duration >= 0 && duration < 1e7)) duration = 0; /* 时间戳异常时按快速点击处理 */
      if (gesture.bowing){
        input.bowHold = false;
        input.bowRelease = true;
      } else if (gesture.mining){
        input.mine = false;
      } else if (!gesture.moved && duration < LONG_PRESS_MS + 120){
        if (touchAimMode === 'finger'){
          /* 触点模式：记录手指落点，由主循环按落点判定 */
          input.tapScreen = { x: gesture.startX, y: gesture.startY };
        } else {
          /* 准星模式（默认）：和基岩版一样按屏幕中心准星判定 */
          input.tap = true;
        }
      }
      input.mineScreen = null;
      gesture.id = null;
      gesture.mining = false;
      gesture.bowing = false;
      gesture.moved = false;
    }
  }
  c.addEventListener('touchend', endGesture, { passive: true });
  c.addEventListener('touchcancel', endGesture, { passive: true });

  // 供外部调用，切模式时清干净
  window.__resetGesture = resetGesture;
}

/* ---- 虚拟摇杆 ---- */
function initJoystick(){
  const stickEl = document.getElementById('stick');
  const knobEl  = document.getElementById('knob');
  if (!stickEl) return;
  let stickId = null, stickCX = 0, stickCY = 0, stickR = 44;

  stickEl.addEventListener('touchstart', e => {
    if (!IS_TOUCH) return;
    if (document.body.classList.contains('touch-editing')) return;
    e.preventDefault(); e.stopPropagation();
    const t = e.changedTouches[0];
    stickId = t.identifier;
    const r = stickEl.getBoundingClientRect();
    stickCX = r.left + r.width / 2;
    stickCY = r.top + r.height / 2;
    stickR = Math.max(24, r.width * 0.36);
    updateStick(t.clientX, t.clientY);
  }, { passive: false });

  stickEl.addEventListener('touchmove', e => {
    if (!IS_TOUCH) return;
    e.preventDefault(); e.stopPropagation();
    for (const t of e.changedTouches)
      if (t.identifier === stickId) updateStick(t.clientX, t.clientY);
  }, { passive: false });

  function endStick(e){
    if (!IS_TOUCH) return;
    for (const t of e.changedTouches){
      if (t.identifier === stickId){
        stickId = null;
        input.joyX = 0; input.joyY = 0;
        knobEl.style.transform = 'translate(0,0)';
      }
    }
  }
  stickEl.addEventListener('touchend', endStick, { passive: true });
  stickEl.addEventListener('touchcancel', endStick, { passive: true });

  function updateStick(cx, cy){
    const maxR = stickR;
    let dx = cx - stickCX, dy = cy - stickCY;
    const d = Math.hypot(dx, dy);
    if (d > maxR){ dx = dx / d * maxR; dy = dy / d * maxR; }
    knobEl.style.transform = `translate(${dx}px, ${dy}px)`;
    input.joyX = dx / maxR;
    input.joyY = dy / maxR;
  }
}

/* ---- 移动端按钮（布局由 ui/touch-controls.js 生成，这里只负责动作） ---- */
function _keyNameOf(code){
  if (!code) return '';
  if (code.indexOf('Key') === 0) return code.slice(3).toLowerCase();
  if (code.indexOf('Digit') === 0) return code.slice(5);
  if (code === 'Space') return ' ';
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'Shift';
  if (code === 'ControlLeft' || code === 'ControlRight') return 'Control';
  if (code === 'AltLeft' || code === 'AltRight') return 'Alt';
  return code;
}

function initTouchButtons(){
  const root = document.getElementById('touch');
  if (!root) return;

  const entries = new Map();

  function isEditing(){
    return document.body.classList.contains('touch-editing');
  }

  function dispatchKey(type, code){
    if (!code) return;
    try {
      window.dispatchEvent(new KeyboardEvent(type, {
        code, key: _keyNameOf(code), bubbles: true, cancelable: true,
      }));
    } catch(e){}
  }

  /* 返回 true 表示这个"按键"其实是鼠标按钮，已经处理 */
  function pressMouse(code, down){
    if (code !== 'mouseLeft' && code !== 'mouseRight') return false;
    const acts = actionsForCode(code);
    for (const a of acts) applyBoundAction(a, down, null);
    if (code === 'mouseLeft'){ input.uiMine = down; return true; }
    input.uiUse = down;
    input.bowHold = down;
    if (!down) input.bowRelease = true;
    return true;
  }

  function pressAction(el, entry){
    const act = el.dataset.act;
    switch (act){
      case 'jump': jumpDown(); break;
      case 'sneak': input.sneak = true; break;
      case 'sprint':
        input.sprintToggle = !input.sprintToggle;
        el.classList.toggle('on', input.sprintToggle);
        break;
      case 'mine': input.uiMine = true; break;
      case 'use': input.uiUse = true; input.bowHold = true; break;
      case 'inv': input.toggleInv = true; break;
      case 'menu': {
        const b = document.getElementById('btnMenu');
        if (b) b.click();
        break;
      }
      case 'slotPrev': input.wheelDelta = (input.wheelDelta || 0) - 1; break;
      case 'slotNext': input.wheelDelta = (input.wheelDelta || 0) + 1; break;
      case 'key': {
        entry.key = el.dataset.key || '';
        if (entry.key.indexOf('pad:') === 0){ setVirtualPad(entry.key, true); break; }
        if (!pressMouse(entry.key, true)) dispatchKey('keydown', entry.key);
        break;
      }
    }
  }

  function releaseAction(el, entry){
    const act = el.dataset.act;
    switch (act){
      case 'jump': jumpUp(); break;
      case 'sneak': input.sneak = false; break;
      case 'mine': input.uiMine = false; break;
      case 'use':
        input.uiUse = false;
        input.bowHold = false;
        input.bowRelease = true;
        break;
      case 'key':
        if (entry.key.indexOf('pad:') === 0){ setVirtualPad(entry.key, false); break; }
        if (!pressMouse(entry.key, false)) dispatchKey('keyup', entry.key);
        break;
    }
  }

  root.addEventListener('touchstart', e => {
    if (!IS_TOUCH || isEditing()) return;
    const el = e.target.closest && e.target.closest('.tbtn');
    if (!el) return;
    e.preventDefault();
    e.stopPropagation();
    for (const t of e.changedTouches){
      if (entries.has(t.identifier)) continue;
      const entry = { el, key: el.dataset.key || '' };
      entries.set(t.identifier, entry);
      pressAction(el, entry);
    }
  }, { passive: false });

  function endTouch(e){
    if (!IS_TOUCH) return;
    for (const t of e.changedTouches){
      const entry = entries.get(t.identifier);
      if (!entry) continue;
      entries.delete(t.identifier);
      if (e.type !== 'touchcancel') e.preventDefault();
      e.stopPropagation();
      releaseAction(entry.el, entry);
    }
  }
  root.addEventListener('touchend', endTouch, { passive: false });
  root.addEventListener('touchcancel', endTouch, { passive: false });

  /* 切到编辑模式时清掉按住的虚拟键，避免卡在按住状态 */
  window.__resetTouchButtons = () => {
    for (const [id, entry] of entries){
      releaseAction(entry.el, entry);
    }
    entries.clear();
  };
}

/* ============================================================
   ★ 输入独占（给 mod 用）
   ------------------------------------------------------------
   原来 mouseLeft / mouseRight 每帧被 consumeMouseState() 无条件写回，
   mod 在 game.tick 里置 false，下一帧照样被覆盖 —— 想独占右键（比如右键
   曲柄，同时原版还放下手持方块）根本做不到；多个 mod 作者都卡在这里，
   只能靠 exitPointerLock + 手动清 keys + 清摇杆 这种 hack。

   现在给两个入口：
     G.input.consume(name)   消费一次（按住期间要逐帧调用）
     G.input.suspend()      彻底停掉玩家输入（打开自己的 UI 时用）
     G.input.resume()       恢复
   注意时序：game.tick 在 applyInput() 之前，所以 mod 在 tick 里 consume，
   同一帧的写回就已经是 false，不需要等下一帧。
   ============================================================ */
const CONSUMABLE = ['mouseLeft', 'mouseRight', 'jump', 'mine', 'place', 'sneak'];
let _consumed = new Set();
let _suspended = false;

input.isSuspended = function(){ return _suspended; };

input.consume = function(name){
  if (_suspended) return true;
  const k = String(name);
  if (CONSUMABLE.indexOf(k) < 0) return false;
  _consumed.add(k);
  switch (k){
    case 'jump':  input.jump  = false; break;
    case 'mine':  input.mine  = false; break;
    case 'place': input.place = false; break;
    case 'sneak': input.sneak = false; break;
  }
  return true;
};

input.suspend = function(){
  if (_suspended) return false;
  _suspended = true;
  for (const k in input.keys) input.keys[k] = false;
  for (const k in input.actions) input.actions[k] = false;
  for (const k in _virtualPad) _virtualPad[k] = false;
  input.jump = false; input.sneak = false;
  input.mine = false; input.place = false;
  input.uiMine = false; input.uiUse = false;
  input.joyX = 0; input.joyY = 0;
  input.yawDelta = 0; input.pitchDelta = 0;
  return true;
};

input.resume = function(){
  if (!_suspended) return false;
  _suspended = false;
  _consumed.clear();
  return true;
};

/* ---- 每帧取用 ---- */
function consumeMouseState(){
  const sup = _suspended;
  input.mouseLeft  = (sup || _consumed.has('mouseLeft'))  ? false : mouseLeft;
  input.mouseRight = (sup || _consumed.has('mouseRight')) ? false : mouseRight;

  if (sup){
    /* suspend 期间每帧压住：键盘事件还会写 input.keys，
       所以在 updatePlayer 之前清一次，玩家才真的不会动。 */
    for (const k in input.keys) input.keys[k] = false;
    for (const k in input.actions) input.actions[k] = false;
    for (const k in _virtualPad) _virtualPad[k] = false;
    input.jump = false; input.sneak = false;
    input.mine = false; input.place = false;
    input.uiMine = false; input.uiUse = false;
    input.joyX = 0; input.joyY = 0;
  }

  /* 消费标记写完就清：想持续独占就得每帧 consume */
  if (_consumed.size) _consumed.clear();
}
function consumeFlyToggle(){
  if (pendingFlyToggle){ pendingFlyToggle = false; return true; }
  return false;
}

/* =================================================================
   player/player.js
   ================================================================= */
const player = {
  pos: new THREE.Vector3(0, SEA_LEVEL + 4, 0),
  vel: new THREE.Vector3(),
  yaw: 0, pitch: 0,
  onGround: false,
  inWater: false,
  wasInWater: false,
  inLava: false,
  flying: false,
  mode: 'survival',
  health: 20,
  maxHealth: 20,
  breath: 1.0,
  breathActive: false,
  sprinting: false,
  sneaking: false,
  hunger: 20,
  maxHunger: 20,
  saturation: 5,
  exhaustion: 0,

  /* 盔甲：head / chest / legs / feet，值为 { id, count } 或 null */
  armor: { head: null, chest: null, legs: null, feet: null },

  posByDim: {},

  eatFood(food, sat){
    this.hunger = Math.min(this.maxHunger, this.hunger + food);
    this.saturation = Math.min(this.hunger, this.saturation + (sat || 0));
  }
};

/* ============================================================
   ★ M4：位置快照工具
   ============================================================ */

function snapshotPosForDim(dim){
  if (!dim) return;
  const snap = player.posByDim[dim] || (player.posByDim[dim] = {});
  snap.x = player.pos.x;
  snap.y = player.pos.y;
  snap.z = player.pos.z;
  snap.yaw = player.yaw;
  snap.pitch = player.pitch;
}

function restorePosFromDim(dim){
  const snap = player.posByDim[dim];
  if (!snap) return false;
  player.pos.set(snap.x, snap.y, snap.z);
  player.vel.set(0, 0, 0);
  player.yaw = snap.yaw || 0;
  player.pitch = snap.pitch || 0;
  return true;
}

/* ============================================================
   碰撞
   ============================================================ */
function blockSpan(b, lx, lz){
  if (!b || !b.solid) return null;
  if (b.slab) return [0, 0.5];
  if (b.stair){
    const d = b.stairDir | 0;
    let high;
    if (d === 0)      high = (lz >= 0.5);
    else if (d === 2) high = (lz <  0.5);
    else if (d === 1) high = (lx >= 0.5);
    else              high = (lx <  0.5);
    return high ? [0, 1] : [0, 0.5];
  }
  const hR = b.heightRatio !== undefined ? b.heightRatio : 1;
  return [0, hR];
}

/* ============================================================
   饱食度
   ============================================================ */
let starveTimer = 0;

function updateHunger(dt, moving, sprinting){
  if (player.mode === 'creative'){
    player.hunger = player.maxHunger;
    player.exhaustion = 0;
    player.saturation = 0;
    starveTimer = 0;
    return;
  }

  if (sprinting && moving)      player.exhaustion += dt * 0.10;
  else if (moving)              player.exhaustion += dt * 0.01;
  if (player.inWater)           player.exhaustion += dt * 0.01;

  while (player.exhaustion >= 4){
    player.exhaustion -= 4;
    if (player.saturation > 0){
      player.saturation = Math.max(0, player.saturation - 1);
    } else if (player.hunger > 0){
      player.hunger = Math.max(0, player.hunger - 1);
    } else break;
  }

  if (player.hunger <= 0 && player.health > 0){
    starveTimer += dt;
    if (starveTimer > 4){
      starveTimer = 0;
      damage(1);
    }
  } else starveTimer = 0;
}

/* ============================================================
   碰撞 / 支撑
   ============================================================ */
function collideAt(px, py, pz){
  // ★ 极限性能优化：如果脚下的区块还没加载出来，给个虚拟支撑，防止掉入虚空
  // 等区块加载完后，这个临时支撑会自动消失
  if (!isWorldBlockLoaded(Math.floor(px), Math.floor(py), Math.floor(pz))) {
    return true;
  }

  const hw = PLAYER_W * 0.5;
  const x0 = Math.floor(px - hw + 1e-5), x1 = Math.floor(px + hw - 1e-5);
  const y0 = Math.floor(py + 1e-5),       y1 = Math.floor(py + PLAYER_H - 1e-5);
  const z0 = Math.floor(pz - hw + 1e-5), z1 = Math.floor(pz + hw - 1e-5);
  for (let x = x0; x <= x1; x++)
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++){
        const b = BLOCKS[getBlockWorld(x, y, z)];
        const span = blockSpan(b, px - x, pz - z);
        if (!span) continue;
        const top = y + span[1], bot = y + span[0];
        if (top > py + 1e-5 && bot < py + PLAYER_H - 1e-5) return true;
      }
  return false;
}

function supportHeight(px, py, pz){
  const hw = PLAYER_W * 0.5;
  const x0 = Math.floor(px - hw + 1e-5), x1 = Math.floor(px + hw - 1e-5);
  const z0 = Math.floor(pz - hw + 1e-5), z1 = Math.floor(pz + hw - 1e-5);
  let best = -Infinity;
  for (let y = Math.floor(py) - 1; y <= Math.floor(py); y++){
    for (let x = x0; x <= x1; x++)
      for (let z = z0; z <= z1; z++){
        const b = BLOCKS[getBlockWorld(x, y, z)];
        const span = blockSpan(b, px - x, pz - z);
        if (!span) continue;
        const top = y + span[1];
        if (top <= py + 0.001 && top > best) best = top;
      }
  }
  return best;
}

const STEP_HEIGHT = 0.6;
function tryStepUp(px, py, pz){
  const support = supportHeight(px, py, pz);
  const base = isFinite(support) ? support : py;
  for (const lift of [0.5, STEP_HEIGHT]){
    const ny = base + lift;
    if (ny - py > STEP_HEIGHT + 1e-5) continue;
    if (ny < py - 1e-5) continue;
    if (collideAt(px, ny, pz)) continue;
    if (!collideAt(px, ny - 0.06, pz)) continue;
    return ny;
  }
  return null;
}

/* ============================================================
   出生点搜索
   ============================================================ */
function findSpawn(){
  const R_MAX = 2000;
  const DA = Math.PI / 8;

  for (let r = 0; r < R_MAX; r += 8){
    for (let a = 0; a < 16; a++){
      const ang = a * DA;
      const x = Math.round(Math.cos(ang) * r);
      const z = Math.round(Math.sin(ang) * r);
      const h = Math.floor(heightAt(x, z));
      if (h <= SEA_LEVEL + 2) continue;

      const b = biomeAt(x, z, h);
      if (b === 0 || b === 15 || b === 14 || b === 8 || b === 9) continue;
      return { x, z, fallback: false };
    }
  }

  for (let r = 0; r < R_MAX; r += 8){
    for (let a = 0; a < 16; a++){
      const ang = a * DA;
      const x = Math.round(Math.cos(ang) * r);
      const z = Math.round(Math.sin(ang) * r);
      const h = Math.floor(heightAt(x, z));
      if (h <= SEA_LEVEL + 1) continue;

      const b = biomeAt(x, z, h);
      if (b === 0 || b === 15) continue;
      return { x, z, fallback: false };
    }
  }

  console.warn('[player] 未找到宜居出生点，使用原点上方安全高度');
  return { x: 0, z: 0, fallback: true };
}

let _spawnHint = null;
function setSpawnHint(pos){
  if (pos && typeof pos.x === 'number' && typeof pos.z === 'number'){
    _spawnHint = pos;
    player.pos.set(pos.x, pos.y || Math.floor(heightAt(pos.x, pos.z)) + 3, pos.z);
  }
}

const spawn = findSpawn();

{
  const spawnH = Math.floor(heightAt(spawn.x, spawn.z));
  const spawnY = spawn.fallback
    ? SEA_LEVEL + 8
    : Math.max(SEA_LEVEL + 3, spawnH + 2);
  player.pos.set(spawn.x + 0.5, spawnY, spawn.z + 0.5);
}

let lavaTimer = 0, drownTimer = 0, regenTimer = 0;
let onDamage = null;
function setOnDamage(fn){ onDamage = fn; }

function triggerDamageUI(){
  if (onDamage) onDamage(player.health, player.maxHealth);
}

/* ============================================================
   伤害
   ============================================================ */
function _damageImpl(n){
  if (player.mode === 'creative') return;
  emit('player.damage:before', n, player.health);

  /* 盔甲减伤：每点防御 4%，上限 90%（远古石套 24 点可到 90%） */
  let def = 0;
  if (player.armor){
    for (const k in player.armor){
      const it = player.armor[k];
      const b = it && BLOCKS[it.id];
      if (b && b.defense) def += b.defense;
    }
  }
  if (def > 0) n = Math.round(n * (1 - Math.min(0.9, def * 0.04)) * 2) / 2;

  const prevHealth = player.health;
  player.health = Math.max(0, player.health - n);
  if (onDamage) onDamage(player.health, player.maxHealth);

  emit('player.damage', n, player.health, prevHealth);

  if (player.health <= 0){
    const respawnY = spawn.fallback
      ? SEA_LEVEL + 8
      : Math.max(SEA_LEVEL + 3,
                 Math.floor(heightAt(spawn.x, spawn.z)) + 3);
    player.pos.set(spawn.x + 0.5, respawnY, spawn.z + 0.5);
    player.vel.set(0, 0, 0);
    player.health = player.maxHealth;
    player.breath = 1.0;
    if (onDamage) onDamage(player.health, player.maxHealth);

    emit('player.death', spawn.x + 0.5, spawn.z + 0.5);
  }
}
const damage = defineHook('player.damage', _damageImpl);

/* ============================================================
   玩家更新
   ============================================================ */
function _updatePlayerImpl(dt, input){
  emit('player.update:head', dt, input);
  pollGamepads();
  const yaw = player.yaw;
  let ix = 0, iz = 0;

  if (input.actions.forward) iz += 1;
  if (input.actions.back)    iz -= 1;
  if (input.actions.left)    ix -= 1;
  if (input.actions.right)   ix += 1;
  ix += input.joyX;
  iz -= input.joyY;

  const mag = Math.hypot(ix, iz);
  if (mag > 1){ ix /= mag; iz /= mag; }
  const moving = mag > 0.12;

  player.sneaking = input.sneak && !player.flying;
  const wantSprint = (input.actions.sprint || input.sprintToggle) && moving && !player.sneaking;
  player.sprinting = wantSprint;

  const feetBlk = BLOCKS[getBlockWorld(
    Math.floor(player.pos.x), Math.floor(player.pos.y + 0.1), Math.floor(player.pos.z))];
  const bodyBlk = BLOCKS[getBlockWorld(
    Math.floor(player.pos.x), Math.floor(player.pos.y + 1.0), Math.floor(player.pos.z))];

  player.inWater = isWaterLike(bodyBlk) || isWaterLike(feetBlk);
  player.inLava  = (bodyBlk && bodyBlk.name === 'lava') || (feetBlk && feetBlk.name === 'lava');

  if (player.inWater && !player.wasInWater){
    const feetY = Math.floor(player.pos.y + 0.1);
    spawnSplash(
      player.pos.x,
      feetY + 0.1,
      player.pos.z,
      Math.min(1.4, Math.abs(player.vel.y) * 0.25 + 0.8)
    );
    playSFX('splash');
    emit('player.enterWater', player.pos.x, player.pos.y, player.pos.z);
  }
  if (!player.inWater && player.wasInWater){
    emit('player.exitWater', player.pos.x, player.pos.y, player.pos.z);
  }
  player.wasInWater = player.inWater;

  let speed;
  if (player.flying) speed = player.sprinting ? movementConfig.flySprintSpeed : movementConfig.flySpeed;
  else if (player.inWater) speed = movementConfig.waterSpeed;
  else if (player.sneaking) speed = movementConfig.sneakSpeed;
  else if (player.sprinting) speed = movementConfig.sprintSpeed;
  else speed = movementConfig.walkSpeed;

  const fwdX = -Math.sin(yaw), fwdZ = -Math.cos(yaw);
  const rgtX =  Math.cos(yaw), rgtZ = -Math.sin(yaw);
  const dirX = fwdX * iz + rgtX * ix;
  const dirZ = fwdZ * iz + rgtZ * ix;

  const accel = player.onGround || player.flying || player.inWater
    ? movementConfig.groundAccel
    : movementConfig.airAccel;
  const k = Math.min(1, accel * dt);
  player.vel.x += (dirX * speed - player.vel.x) * k;
  player.vel.z += (dirZ * speed - player.vel.z) * k;

  if (player.flying){
    let vy = 0;
    if (input.jump) vy += speed * movementConfig.flyingVerticalFactor;
    if (input.sneak) vy -= speed * movementConfig.flyingVerticalFactor;
    player.vel.y += (vy - player.vel.y) * Math.min(1, 12 * dt);
  } else if (player.inWater){
    player.vel.y -= movementConfig.waterGravity * dt;
    if (input.jump) player.vel.y = movementConfig.waterBuoyancy;
    player.vel.y *= (1 - Math.min(1, movementConfig.waterDamping * dt));
    player.vel.y = clamp(player.vel.y, -movementConfig.waterMaxSpeed, movementConfig.waterMaxSpeed);
  } else {
    player.vel.y -= movementConfig.gravity * dt;
    if (input.jump && player.onGround){
      player.vel.y = movementConfig.jumpVelocity;
      player.onGround = false;
      emit('player.jump', player.pos.x, player.pos.y, player.pos.z);
    }
    player.vel.y = Math.max(player.vel.y, -movementConfig.maxFallSpeed);
    emit('player.update:gravity', dt, player.vel);
  }

  const dx = player.vel.x * dt;
  const dy = player.vel.y * dt;
  const dz = player.vel.z * dt;

  player.onGround = collideAt(player.pos.x, player.pos.y - 0.06, player.pos.z);

  const py0 = player.pos.y;

  if (!collideAt(player.pos.x + dx, player.pos.y, player.pos.z)) player.pos.x += dx;
  else {
    const stepped = player.onGround || player.inWater ? tryStepUp(player.pos.x + dx, py0, player.pos.z) : null;
    if (stepped !== null){
      player.pos.x += dx;
      player.pos.y = stepped;
      player.onGround = true;
    } else player.vel.x = 0;
  }

  if (!collideAt(player.pos.x, player.pos.y, player.pos.z + dz)) player.pos.z += dz;
  else {
    const stepped = player.onGround || player.inWater ? tryStepUp(player.pos.x, py0, player.pos.z + dz) : null;
    if (stepped !== null){
      player.pos.z += dz;
      if (player.pos.y < stepped){ player.pos.y = stepped; player.onGround = true; }
    } else player.vel.z = 0;
  }

  const prevVy = player.vel.y;
  if (!collideAt(player.pos.x, player.pos.y + dy, player.pos.z)){
    player.pos.y += dy;
    if (dy < 0) player.onGround = false;
  } else {
    if (prevVy < 0){
      if (player.mode === 'survival' && prevVy < -15){
        const dmg = Math.floor((-prevVy - 15) / 3.2) + 1;
        if (dmg > 0) damage(dmg);
      }
      player.onGround = true;
      emit('player.land', player.pos.x, player.pos.y, player.pos.z, -prevVy);
    }
    player.vel.y = 0;
  }

  if (player.pos.y < Y_MIN - 2){
    const respawnY = spawn.fallback
      ? SEA_LEVEL + 8
      : Math.max(SEA_LEVEL + 3,
                 Math.floor(heightAt(spawn.x, spawn.z)) + 3);
    player.pos.set(spawn.x + 0.5, respawnY, spawn.z + 0.5);
    player.vel.set(0, 0, 0);
    damage(2);
  }

  if (player.inLava && player.mode === 'survival'){
  emit('player.update:collision', dt, player.pos, player.vel);
    lavaTimer += dt;
    if (lavaTimer > 0.5){ lavaTimer = 0; damage(2); }
  } else lavaTimer = 0;

  const eyeH = player.sneaking ? 1.42 : 1.62;
  const headBlock = BLOCKS[getBlockWorld(
    Math.floor(player.pos.x),
    Math.floor(player.pos.y + eyeH),
    Math.floor(player.pos.z))];
  const headUnderwater = isWaterLike(headBlock);
  player.breathActive = headUnderwater && player.mode === 'survival';

  if (player.breathActive){
    player.breath -= dt / 12;
    if (player.breath <= 0){
      player.breath = 0;
      drownTimer += dt;
      if (drownTimer > 1){ drownTimer = 0; damage(2); }
    }
  } else {
    drownTimer = 0;
    player.breath = Math.min(1, player.breath + dt / 3);
  }

  updateHunger(dt, moving, player.sprinting);

  if (player.mode === 'survival' && player.health < player.maxHealth && player.hunger >= 18){
    regenTimer += dt;
    if (regenTimer > 4){
      regenTimer = 0;
      player.health = Math.min(player.maxHealth, player.health + 1);
      player.exhaustion += 6;
      if (onDamage) onDamage(player.health, player.maxHealth);
    }
  } else regenTimer = 0;

  camera.position.set(player.pos.x, player.pos.y + eyeH, player.pos.z);
  emit('player.update:tail', dt, player);
  camera.rotation.set(player.pitch, player.yaw, 0);
  applyViewCamera(camera, player);
}
const updatePlayer = defineHook('player.update', _updatePlayerImpl);

/* =================================================================
   re-export
   ================================================================= */
export {
  input, setLookSensitivity, getLookSensitivity, setTouchAimMode, getTouchAimMode, initMouseLock, initTouchGestures, initJoystick, initTouchButtons, consumeMouseState, consumeFlyToggle, player, snapshotPosForDim, restorePosFromDim, collideAt, setSpawnHint, spawn, setOnDamage, triggerDamageUI, damage, updatePlayer,
  /* ★ 移动参数配置（G.setMovementConfig / G.getMovementConfig 转发到这里） */
  setMovementConfig, getMovementConfig, resetMovementConfig, DEFAULT_MOVEMENT_CONFIG,
};
