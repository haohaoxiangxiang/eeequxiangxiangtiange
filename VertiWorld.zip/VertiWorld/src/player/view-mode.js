/* ============================================================
   view-mode.js —— 第一 / 第三人称切换
   ------------------------------------------------------------
   0 = 第一人称（隐藏玩家实体）
   1 = 第三人称背后
   2 = 第三人称正面
   ============================================================ */

let mode = 0;

export const VIEW_NAMES = ['第一人称', '第三人称', '第三人称（正面）'];

export function getViewMode(){ return mode; }

export function setViewMode(m){
  mode = ((Math.floor(Number(m) || 0) % 3) + 3) % 3;
  return mode;
}

export function cycleViewMode(){
  mode = (mode + 1) % 3;
  return mode;
}

export function isFirstPerson(){ return mode === 0; }

/** 把相机推到玩家身后/身前；第三人称才生效 */
export function applyViewCamera(camera, player){
  if (mode === 0) return;
  const dist = 3.4;
  const fx = -Math.sin(player.yaw);
  const fz = -Math.cos(player.yaw);
  if (mode === 1){
    camera.position.x -= fx * dist;
    camera.position.z -= fz * dist;
    camera.position.y += 0.25;
  } else {
    /* 正面视角：相机绕玩家做球面轨道，俯仰也参与，抬头/低头时视角会真正变化 */
    const p = Math.max(-0.4, Math.min(0.9, player.pitch || 0));
    const cp = Math.cos(p);
    const sp = Math.sin(p);
    camera.position.set(
      player.pos.x + fx * dist * cp,
      player.pos.y + 1.5 + sp * dist,
      player.pos.z + fz * dist * cp
    );
    camera.lookAt(player.pos.x, player.pos.y + 1.35, player.pos.z);
  }
}
