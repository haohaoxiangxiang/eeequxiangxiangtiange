/* ============================================================
   status-effects.js —— 通用状态/效果系统
   ------------------------------------------------------------
   宿主只提供"计时 + 回调 + 堆叠"，具体效果（回血、扣血、加速、
   中毒、燃烧…）全部由 mod 在 onTick / onApply / onRemove 里实现。

   · duration <= 0 → 永久，直到 removeStatus / clear
   · tickInterval 单位秒，0 表示不调用 onTick（只算持续时间）
   · 同一 id 重复 apply 会刷新持续时间并堆叠（maxStacks 封顶）
   · 回调异常会被隔离，不会打断主循环
   ============================================================ */

import { player } from './player-core.js';
import { emit } from './../core/engine-core.js';

const _types = new Map();    // id -> 定义
const _active = new Map();   // id -> 运行中实例

function _finiteNum(v, fallback){
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

/* ============================================================
   注册
   ============================================================ */
function registerStatusEffect(id, def){
  if (typeof id !== 'string' || !id) return false;
  if (!def || typeof def !== 'object') return false;

  const type = {
    id,
    name: typeof def.name === 'string' && def.name ? def.name : id,
    duration: _finiteNum(def.duration, 10),
    maxStacks: Math.max(1, Math.floor(_finiteNum(def.maxStacks, 1))),
    tickInterval: Math.max(0, _finiteNum(def.tickInterval, 1)),
    onApply: typeof def.onApply === 'function' ? def.onApply : null,
    onTick: typeof def.onTick === 'function' ? def.onTick : null,
    onRemove: typeof def.onRemove === 'function' ? def.onRemove : null,
    data: def.data === undefined ? null : def.data,
  };

  _types.set(id, type);
  return true;
}

function unregisterStatusEffect(id){
  removeStatus(id, 'unregister');
  return _types.delete(id);
}

function getStatusEffectType(id){
  return _types.get(id) || null;
}

function listStatusEffectTypes(){
  return Array.from(_types.values()).map(t => ({
    id: t.id,
    name: t.name,
    duration: t.duration,
    maxStacks: t.maxStacks,
    tickInterval: t.tickInterval,
  }));
}

/* ============================================================
   施加 / 移除
   ============================================================ */
function _call(fn, inst, tag){
  if (!fn) return;
  try { fn(player, inst); }
  catch (e){ console.error(`[status] "${tag}" 回调出错:`, e); }
}

function applyStatus(id, duration, opts){
  const type = _types.get(id);
  if (!type) return null;

  const d = duration === undefined ? type.duration : _finiteNum(duration, type.duration);
  const stacks = opts && Number.isFinite(opts.stacks) ? Math.max(1, Math.floor(opts.stacks)) : 1;
  const inst0 = _active.get(id);

  let inst;
  if (inst0){
    inst0.stacks = Math.min(type.maxStacks, inst0.stacks + stacks);
    if (d > 0) inst0.remaining = Math.max(inst0.remaining, d);
    else inst0.remaining = Infinity;
    if (opts && opts.data && typeof opts.data === 'object'){
      inst0.data = inst0.data && typeof inst0.data === 'object'
        ? { ...inst0.data, ...opts.data }
        : { ...opts.data };
    }
    inst = inst0;
  } else {
    inst = {
      id,
      type,
      remaining: d > 0 ? d : Infinity,
      elapsed: 0,
      tickAcc: 0,
      stacks,
      data: opts && opts.data && typeof opts.data === 'object' ? { ...opts.data } : (type.data && typeof type.data === 'object' ? { ...type.data } : type.data),
    };
    _active.set(id, inst);
  }

  _call(type.onApply, inst, `${id}.onApply`);
  emit('status.apply', id, inst);
  return inst;
}

function removeStatus(id, reason){
  const inst = _active.get(id);
  if (!inst) return false;
  const why = reason || 'manual';
  _active.delete(id);
  _call(inst.type.onRemove, { ...inst, reason: why }, `${id}.onRemove`);
  emit('status.remove', id, why, inst);
  return true;
}

function clearStatusEffects(reason){
  const why = reason || 'clear';
  let n = 0;
  for (const id of Array.from(_active.keys())){
    if (removeStatus(id, why)) n++;
  }
  return n;
}

function hasStatus(id){
  return _active.has(id);
}

function getStatus(id){
  const inst = _active.get(id);
  if (!inst) return null;
  return {
    id: inst.id,
    name: inst.type.name,
    remaining: inst.remaining,
    elapsed: inst.elapsed,
    stacks: inst.stacks,
    data: inst.data,
  };
}

function getActiveStatuses(){
  return Array.from(_active.values()).map(inst => ({
    id: inst.id,
    name: inst.type.name,
    remaining: inst.remaining,
    elapsed: inst.elapsed,
    stacks: inst.stacks,
    data: inst.data,
  }));
}

/* ============================================================
   每帧推进（main.js 在 updatePlayer 之后调用）
   ============================================================ */
function updateStatusEffects(dt){
  if (!(dt > 0) || _active.size === 0) return;

  for (const inst of Array.from(_active.values())){
    if (!_active.has(inst.id)) continue;

    /* 到期先移除，避免最后一帧还触发 onTick */
    if (inst.remaining !== Infinity){
      inst.remaining -= dt;
      if (inst.remaining <= 0){
        removeStatus(inst.id, 'expire');
        continue;
      }
    }

    inst.elapsed += dt;

    const interval = inst.type.tickInterval;
    if (interval > 0 && inst.type.onTick){
      inst.tickAcc += dt;
      /* 单帧最多补 4 次，避免长时间卡顿后爆回调 */
      let guard = 4;
      while (inst.tickAcc >= interval && guard-- > 0){
        inst.tickAcc -= interval;
        _call(inst.type.onTick, inst, `${inst.id}.onTick`);
        if (!_active.has(inst.id)) break;
      }
    }
  }
}

/* ============================================================
   重置（换存档/测试用）
   ============================================================ */
function resetStatusEffects(){
  clearStatusEffects('reset');
  _types.clear();
}

export {
  registerStatusEffect,
  unregisterStatusEffect,
  getStatusEffectType,
  listStatusEffectTypes,
  applyStatus,
  removeStatus,
  clearStatusEffects,
  hasStatus,
  getStatus,
  getActiveStatuses,
  updateStatusEffects,
  resetStatusEffects,
};
