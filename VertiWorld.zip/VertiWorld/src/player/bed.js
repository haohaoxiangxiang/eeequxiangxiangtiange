/* ============================================================
   bed.js —— 床：跳过夜晚 + 设置重生点 + 连续不睡觉天数
   ------------------------------------------------------------
   · 只有在傍晚/夜里右键床才能睡，睡醒直接到清晨
   · 重生点用 player-core 的 spawn 对象（本局有效）
   · 每天日出时 daysAwake +1；睡一觉清零
     （厉鬼刷怪用：连续 10 天不睡觉）
   ============================================================ */

import { player, spawn } from './player-core.js';
import { getTimeOfDay, setTimeOfDay, getDayFactor } from '../render/sky.js';
import { toast } from '../ui/ui.js';
import { playSFX } from '../audio/audio.js';

let daysAwake = 0;
let _lastT = null;

/** 主循环每帧调用：检测 timeOfDay 回绕（跨过日出）→ 天数 +1 */
export function tickDayCycle(){
  const t = getTimeOfDay();
  if (_lastT !== null && t < _lastT - 0.5) daysAwake++;
  _lastT = t;
}

export function getDaysAwake(){ return daysAwake; }
export function setDaysAwake(n){ daysAwake = Math.max(0, Math.floor(Number(n) || 0)); }
export function resetDaysAwake(){ daysAwake = 0; _lastT = getTimeOfDay(); }

/** 右键床：夜里睡到清晨，回满血并记录重生点 */
export function trySleep(x, y, z){
  if (getDayFactor() > 0.4){
    toast('天还亮着，睡不着');
    playSFX('click');
    return;
  }
  setTimeOfDay(0.03);
  daysAwake = 0;
  _lastT = 0.03;

  player.health = player.maxHealth;
  player.vel.set(0, 0, 0);

  spawn.x = Math.floor(x);
  spawn.z = Math.floor(z);
  spawn.fallback = false;

  toast('睡到清晨 · 重生点已设置');
  playSFX('pop');
}
