/* ============================================================
   save-core.js —— 存档读写 + 世界存取 + mod 加载器
   ------------------------------------------------------------
★ 合并自 4 个 save 文件（约 44KB）：
     api.js          /api/saves/* 请求封装
     mod-storage.js  每个 mod 自己的 KV 存储（建立在 api.js 之上）
     world-save.js   世界的创建 / 载入 / 保存 / 退出
     loader.js       运行时加载 mod（manifest、依赖、失败隔离）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import {
  setWorldConfig, setBlockWorld, setFluidLevel, setFluidSource,
  setOnBlockChanged, serializeEdits, deserializeEdits,
  serializeBlockData, deserializeBlockData,
  setChunkDbSaveId, heightAt, biomeAt,          // ★ 加 biomeAt
} from '../world/terrain.js';
import { BLOCKS, B } from '../world/blocks.js';
import { WORLD_TYPE, CHH, SEA_LEVEL, getDefaultWorldHeight,
         clampWorldHeight, setWorldHeight,
         setActiveDimensionId as _setActiveDimId } from './../core/engine-core.js';
import { clearAnimals, serializeAnimals, deserializeAnimals }
  from './../entities/entities-core.js';
import { clearFurnaces, serializeFurnaces, deserializeFurnaces }
  from './../items/items-logic.js';
import { clearLeaves } from './../world/world-registry.js';
import { clearSplash } from './../world/world-core.js';
import { drops } from './../items/items-logic.js';
import { emit } from './../core/engine-core.js';
import { getActiveGenerator } from './../world/world-meta.js';
import { getDimension, hasDimension, getActiveDimensionId }
  from './../world/world-registry.js';
import { inventory, clearInventory, notifyInventory }
  from './../items/items-core.js';
import { log, setLogSaveId } from './../core/runtime.js';
import { player, snapshotPosForDim, restorePosFromDim, setSpawnHint }
  from './../player/player-core.js';
import { resetFluid } from './../world/world-core.js';
import { scene } from './../render/render-core.js';
import { setActiveGenerator } from './../world/world-meta.js';
import { setChestSaveId, flushAllChests, clearChests }
  from './../items/items-core.js';
import { setSkyPreset as _setSkyPreset, setBiomeFog as _setBiomeFog }
  from '../render/sky.js';
import { startDiagnostics, stopDiagnostics } from '../core/diagnostics.js';
import { updateHearts, updateHunger, toast } from '../ui/ui.js';
import { initWeather, serializeWeather } from '../world/weather.js';


/* =================================================================
   save/api.js
   ================================================================= */
/* ============================================================
   api.js —— 存档核心文件读写（客户端）
   ------------------------------------------------------------
   所有对 saves/ 的访问都通过服务器 /api/saves/* 路由。
   本模块只负责拼 URL、发请求、解析 JSON。
   ============================================================ */

const BASE = '/api/saves';

/* 与服务端保持一致的校验规则 */
const SAVE_ID_RE   = /^[a-zA-Z0-9_-]{1,64}$/;
const FILE_NAME_RE = /^[a-zA-Z0-9_.\-]{1,128}$/;

/* ---- 内部：参数校验 ---- */

function assertId(id){
  if (typeof id !== 'string' || !SAVE_ID_RE.test(id)){
    throw new Error('api.js: 非法存档 id: ' + id);
  }
}
function assertName(name){
  if (typeof name !== 'string' || !FILE_NAME_RE.test(name)){
    throw new Error('api.js: 非法文件名: ' + name);
  }
  if (name.startsWith('.')){
    throw new Error('api.js: 文件名不能以 . 开头: ' + name);
  }
}

/* ---- 内部：底层请求 ---- */

async function request(method, url, body, opts){
  opts = opts || {};
  const init = { method, headers: {} };

  if (body !== undefined && body !== null){
    if (body instanceof ArrayBuffer || body instanceof Uint8Array){
      init.body = body;
      init.headers['Content-Type'] = 'application/octet-stream';
    } else if (typeof body === 'string'){
      init.body = body;
      init.headers['Content-Type'] = 'text/plain; charset=utf-8';
    } else {
      init.body = JSON.stringify(body);
      init.headers['Content-Type'] = 'application/json';
    }
  }

  let r;
  try {
    r = await fetch(url, init);
  } catch(e){
    if (opts.optional) return null;
    throw new Error(`api.js: ${method} ${url} 网络错误: ${e.message}`);
  }
  if (!r.ok){
    if (opts.optional) return null;
    throw new Error(`api.js: ${method} ${url} → HTTP ${r.status}`);
  }
  return r;
}

async function requestJson(method, url, body, opts){
  const r = await request(method, url, body, opts);
  if (r === null) return null;
  try { return await r.json(); }
  catch(e){ return null; }
}

/* ============================================================
   公开 API
   ============================================================ */

/** 列出所有存档（world.json 内容数组），按 lastPlayed 降序 */
async function listSaves(){
  const arr = await requestJson('GET', BASE, undefined, { optional: true });
  if (!Array.isArray(arr)) return [];
  arr.sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0));
  return arr;
}

/**
 * 创建一个新存档。
 * 服务端会在 saves/<id>/ 下建目录骨架（data/, lod/）并写 world.json。
 */
async function createSave(id, meta){
  assertId(id);
  return await requestJson('POST', BASE, { id, meta: meta || { id } });
}

/** 删除存档及其所有数据（整个目录） */
async function deleteSave(id){
  assertId(id);
  const r = await request('DELETE', `${BASE}/${encodeURIComponent(id)}`,
                          undefined, { optional: true });
  return !!r;
}

/**
 * 读存档里的核心文件（world.json / player.json / inventory.json / blocks.json …）
 * 不存在返回 null。
 */
async function readFile(saveId, name){
  assertId(saveId);
  assertName(name);
  return await requestJson(
    'GET', `${BASE}/${encodeURIComponent(saveId)}/${name}`,
    undefined, { optional: true }
  );
}

/** 写存档核心文件。data 可以是对象（自动 JSON.stringify）或字符串。 */
async function writeFile(saveId, name, data){
  assertId(saveId);
  assertName(name);
  await request('PUT', `${BASE}/${encodeURIComponent(saveId)}/${name}`, data);
  return true;
}

/* ---- 嵌套子路径读写（chests/<dim>/x_y_z.json 等） ---- */

/**
 * 校验并规范化"相对路径"：允许用 / 分级，每一级都要满足文件名规则。
 * 与服务端 /api/saves/<sid>/<rel> 的校验保持一致。
 */
function assertRelPath(relPath){
  if (typeof relPath !== 'string' || !relPath){
    throw new Error('api.js: 非法路径: ' + relPath);
  }
  const segs = relPath.split('/');
  for (const s of segs){
    if (!s || s === '.' || s === '..' || s.startsWith('.')){
      throw new Error('api.js: 非法路径: ' + relPath);
    }
    if (!FILE_NAME_RE.test(s)){
      throw new Error('api.js: 非法路径段: ' + s);
    }
  }
  return segs.map(encodeURIComponent).join('/');
}

/** 读嵌套路径上的 JSON。不存在 / 解析失败返回 null。 */
async function readSaveJson(saveId, relPath){
  assertId(saveId);
  const safe = assertRelPath(relPath);
  return await requestJson(
    'GET', `${BASE}/${encodeURIComponent(saveId)}/${safe}`,
    undefined, { optional: true }
  );
}

/** 写嵌套路径上的 JSON（父目录不存在时服务端会自动建）。 */
async function writeSaveJson(saveId, relPath, data){
  assertId(saveId);
  const safe = assertRelPath(relPath);
  await request('PUT', `${BASE}/${encodeURIComponent(saveId)}/${safe}`, data);
  return true;
}

/** 删除嵌套路径上的文件（不存在也算成功）。 */
async function deleteSavePath(saveId, relPath){
  assertId(saveId);
  const safe = assertRelPath(relPath);
  const r = await request('DELETE', `${BASE}/${encodeURIComponent(saveId)}/${safe}`,
                          undefined, { optional: true });
  return !!r;
}

/* ---- 二进制读写（lod 缓存、快照） ---- */

async function readBytes(saveId, name){
  assertId(saveId);
  assertName(name);
  const r = await request('GET', `${BASE}/${encodeURIComponent(saveId)}/${name}`,
                          undefined, { optional: true });
  if (!r) return null;
  return await r.arrayBuffer();
}

async function writeBytes(saveId, name, buf){
  assertId(saveId);
  assertName(name);
  await request('PUT', `${BASE}/${encodeURIComponent(saveId)}/${name}`, buf);
  return true;
}

/** 读一份纯文本 */
async function readText(saveId, name){
  assertId(saveId);
  assertName(name);
  const r = await request('GET', `${BASE}/${encodeURIComponent(saveId)}/${name}`,
                          undefined, { optional: true });
  if (!r) return null;
  return await r.text();
}

/** 列出某存档 data/ 下有哪些 mod 建过目录 */
async function io_listModsInSave(saveId){
  assertId(saveId);
  const arr = await requestJson('GET',
    `${BASE}/${encodeURIComponent(saveId)}/mods`,
    undefined, { optional: true });
  return Array.isArray(arr) ? arr : [];
}

/* =================================================================
   save/mod-storage.js
   ================================================================= */
const SAVE_BASE = '/api/saves';

function normRel(p){
  return String(p == null ? '' : p)
    .replace(/\\/g, '/')
    .replace(/^\/+|\/+$/g, '');
}

function buildStorage(saveId, modId){
  const base = `${SAVE_BASE}/${encodeURIComponent(saveId)}/mods/${encodeURIComponent(modId)}`;

  const url = (rel) => {
    const r = normRel(rel);
    if (r === '') return base;
    return base + '/' + r.split('/').map(encodeURIComponent).join('/');
  };

  const api = {
    /** mod 自己的 id（就是磁盘上的目录名） */
    id: modId,

    /** 是否存在（文件或目录） */
    async exists(rel){
      const r = await fetch(url(rel), { method: 'GET' });
      return r.ok;
    },

    /** 列目录。返回 [{name, dir, size, mtime}]；不存在返回 null */
    async list(rel = ''){
      const r = await fetch(url(rel), { method: 'GET' });
      if (!r.ok) return null;
      const ct = r.headers.get('content-type') || '';
      if (!ct.includes('application/json')) return null;  // 那是文件
      const data = await r.json();
      return data.type === 'dir' ? data.entries : null;
    },

    async readText(rel){
      const r = await fetch(url(rel), { method: 'GET' });
      if (!r.ok) return null;
      return r.text();
    },

    async readJSON(rel){
      const t = await api.readText(rel);
      if (t == null) return null;
      try { return JSON.parse(t); } catch(e){ return null; }
    },

    async readBytes(rel){
      const r = await fetch(url(rel), { method: 'GET' });
      if (!r.ok) return null;
      return r.arrayBuffer();
    },

    async writeText(rel, text){
      const r = await fetch(url(rel), {
        method: 'PUT',
        body: String(text),
        headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      });
      if (!r.ok) throw new Error(`write ${rel} → ${r.status}`);
    },

    async writeJSON(rel, obj){
      await api.writeText(rel, JSON.stringify(obj));
    },

    async writeBytes(rel, buf){
      const r = await fetch(url(rel), {
        method: 'PUT',
        body: buf,
        headers: { 'Content-Type': 'application/octet-stream' },
      });
      if (!r.ok) throw new Error(`writeBytes ${rel} → ${r.status}`);
    },

    /** mkdir -p */
    async mkdir(rel){
      const r = await fetch(url(rel), { method: 'POST' });
      if (!r.ok) throw new Error(`mkdir ${rel} → ${r.status}`);
    },

    /** 删除文件或目录（递归） */
    async remove(rel){
      const r = await fetch(url(rel), { method: 'DELETE' });
      return r.ok;
    },
  };

  return api;
}

/* 每个 (saveId, modId) 只建一次，避免重复 fetch */
const _cache = new Map();
function getModStorage(saveId, modId){
  if (!saveId || !modId) throw new Error('getModStorage: saveId & modId required');
  const key = saveId + '/' + modId;
  let s = _cache.get(key);
  if (!s){ s = buildStorage(saveId, modId); _cache.set(key, s); }
  return s;
}

/** 存档切换时清一下缓存 */
function clearModStorageCache(){ _cache.clear(); }

/** 列出当前存档里装过哪些 mod（发现别人装的 mod 目录） */
async function ms_listModsInSave(saveId){
  const r = await fetch(`${SAVE_BASE}/${encodeURIComponent(saveId)}/mods`);
  if (!r.ok) return [];
  return r.json();
}

/* =================================================================
   save/world-save.js
   ================================================================= */
/* ============================================================
   world-save.js —— 世界存档生命周期
   ------------------------------------------------------------
   ★ 累积修改：
     · hashSeed()：修复长种子坍缩（所有长串都变同一世界）
     · 纯数字种子直通，输入 98765 就是 98765
     · _findSpawnForDimension 两轮搜索 + 群系排除 + 抬高兜底
   ============================================================ */
























/* ---- 模块状态 ---- */
let currentSave = null;
let blockChanges = [];
let suppressBlockChange = false;
let _switchingDimension = false;
let _enterGame = null;

function getCurrentSave(){ return currentSave; }
function setCurrentSave(cs){ currentSave = cs; }
function getBlockChanges(){ return blockChanges; }

/* ============================================================
   方块名 ↔ id
   ============================================================ */
function nameToId(name){
  if (typeof name !== 'string') return null;
  const b = B[name];
  return b ? b.id : null;
}

let _unknownBlockId = null;
function getUnknownBlockId(){
  if (_unknownBlockId === null){
    const b = B['unknown_block'];
    _unknownBlockId = b ? b.id : 0;
  }
  return _unknownBlockId;
}

function resolveBlockId(rec){
  if (!rec) return null;

  if (typeof rec.n === 'string'){
    const id = nameToId(rec.n);
    if (id !== null) return id;
    const uid = getUnknownBlockId();
    return uid > 0 ? uid : null;
  }

  if (typeof rec.id === 'number'){
    const b = BLOCKS[rec.id];
    if (b) return b.id;
    const uid = getUnknownBlockId();
    return uid > 0 ? uid : null;
  }
  return null;
}

function generateId(){
  return 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

/* ============================================================
   ★ 种子哈希
   ------------------------------------------------------------
   · 纯数字且 <= 15 位 → 直接用（输入 98765 就是 98765）
   · 其它 → FNV-1a 32 位哈希
     （旧的 Knuth 乘法哈希对重复字符长串会坍缩到固定循环，
      导致所有长种子生成同一个世界）
   ============================================================ */
function hashSeed(str){
  const s = String(str == null ? '' : str).trim();
  if (!s) return Math.floor(Math.random() * 100000000);

  /* 纯数字直通 */
  if (/^\d{1,15}$/.test(s)){
    return Number(s) % 100000000;
  }

  /* FNV-1a 32 位 */
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++){
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0) % 100000000;
}

/* ============================================================
   初始化
   ============================================================ */
function initWorldSave({ onEnterGame, worldHeightInput }){
  _enterGame = onEnterGame;
  _worldHeightInput = (typeof worldHeightInput === 'number' && worldHeightInput > 0) ? worldHeightInput : 400;

  setOnBlockChanged((x, y, z, id, lv, src) => {
    if (suppressBlockChange) return;
    for (let i = blockChanges.length - 1; i >= 0; i--){
      if (blockChanges[i].x === x && blockChanges[i].y === y && blockChanges[i].z === z){
        blockChanges.splice(i, 1); break;
      }
    }
    const blk = BLOCKS[id];
    blockChanges.push({ x, y, z, n: blk ? blk.name : 'air',
                       lv: lv || 0, src: src ? 1 : 0 });
  });
}

let _worldHeightInput = 400;
function setWorldHeightInput(v){ _worldHeightInput = v; }

/* ============================================================
   新建世界
   ============================================================ */
async function startNewWorld(name, type, seedStr){
  /* ★ 用 hashSeed 取代原来的内联哈希 */
  const seed = hashSeed(seedStr);

  const id = generateId();
  const meta = {
    formatVersion: 2, id,
    name: name || '新的世界',
    type: type || WORLD_TYPE.VANILLA,
    seed,
    worldHeight: _worldHeightInput,
    createdAt: Date.now(),
    lastPlayed: Date.now(),
    plugins: [],
    usedMods: [],
    gameRules: {},
    seasonPhase: 0,   /* 0 = 春分；由 main.js 的 tickSeason 推进 */
  };

  try {
    const selected = (typeof window.__getCreateDialogMods === 'function')
      ? window.__getCreateDialogMods()
      : null;
    if (Array.isArray(selected)){
      meta.plugins = selected.slice();
    } else {
      meta.plugins = [];
    }
    meta.usedMods = meta.plugins.slice();

    /* ★ 该世界类型自己的创建选项（不同模式有不同的项，见 core/generators.js） */
    try {
      const all = (typeof window.__getCreateDialogOptions === 'function')
        ? window.__getCreateDialogOptions() : null;
      const mine = all && all[meta.type];
      if (mine && Object.keys(mine).length) meta.worldOptions = mine;
    } catch(e){ /* 没有就算了 */ }
  } catch(e){
    meta.plugins = [];
    meta.usedMods = [];
  }

  try { await createSave(id, meta); }
  catch(e){
    console.error('[save] create failed', e);
    toast('创建失败：' + (e.message || e));
    return false;
  }

  player.posByDim = {};
  _setActiveDimId('overworld');

  currentSave = meta;
  blockChanges = [];
  applySaveToWorld({ ...meta, blocks: [], inventory: [] }, true);
  try { initWeather(null); } catch(e){}

  setLogSaveId(id);
  log.i('main', '新建世界', name);
  emit('world.create', meta);

  try { await loadModsForSave(id, meta.plugins || []); }
  catch(e){ console.error('[mods] load failed', e); }
  return true;
}

/* ============================================================
   加载已有世界
   ============================================================ */
async function loadExistingWorld(meta){
  let freshMeta = null;
  try {
    freshMeta = await readFile(meta.id, 'world.json');
  } catch(e){
    console.warn('[save] 读最新 world.json 失败:', e);
  }
  if (freshMeta && typeof freshMeta === 'object'){
    meta = { ...meta, ...freshMeta };
  }

  const [playerData, invData, blocksData, entitiesData, furnacesData, editsData, bdData] =
    await Promise.all([
      readFile(meta.id, 'player.json'),
      readFile(meta.id, 'inventory.json'),
      readFile(meta.id, 'blocks.json'),
      readFile(meta.id, 'entities.json'),
      readFile(meta.id, 'furnaces.json'),
      readFile(meta.id, 'edits.json'),
      readFile(meta.id, 'blockdata.json'),
    ]);

  currentSave = { ...meta };
  try { initWeather(currentSave.weather || null); } catch(e){}

  if (!Array.isArray(currentSave.usedMods)){
    currentSave.usedMods = Array.isArray(currentSave.plugins)
      ? currentSave.plugins.slice()
      : [];
  }

  player.posByDim = {};
  if (playerData){
    if (playerData.posByDim && typeof playerData.posByDim === 'object'){
      player.posByDim = playerData.posByDim;
    } else if (playerData.pos){
      player.posByDim = {
        overworld: {
          x: playerData.pos.x, y: playerData.pos.y, z: playerData.pos.z,
          yaw: playerData.yaw || 0, pitch: playerData.pitch || 0,
        },
      };
    }
    currentSave.playerMode = playerData.mode || 'survival';
    currentSave.playerArmor = playerData.armor || null;

    if (playerData.dim && hasDimension(playerData.dim)){
      _setActiveDimId(playerData.dim);
    } else {
      _setActiveDimId('overworld');
    }
  }

  currentSave.inventory = (invData && invData.slots) || [];
  currentSave.blocks    = (blocksData && blocksData.list) || [];
  currentSave.edits     = (editsData && editsData.list) || [];
  blockChanges = currentSave.blocks.slice();

  applySaveToWorld(currentSave, false);

  deserializeBlockData((bdData && bdData.list) || []);
  deserializeAnimals((entitiesData && entitiesData.list) || []);
  deserializeFurnaces((furnacesData && furnacesData.list) || []);

  setLogSaveId(meta.id);
  log.i('main', '载入世界', meta.name);

  clearModStorageCache();
  try { await loadModsForSave(meta.id, meta.plugins || []); }
  catch(e){ console.error('[mods] load failed', e); }
}

/* ============================================================
   应用存档到世界
   ============================================================ */
function applySaveToWorld(save, isNew){
  const wh = save.worldHeight != null
    ? save.worldHeight
    : getDefaultWorldHeight(save.type);
  setWorldHeight(wh, save.type);
  save.worldHeight = CHH;

  setWorldConfig(save.type, save.seed);
  setChunkDbSaveId(save.id);
  /* ★ 箱子按存档绑定：换存档后内存里的旧箱子一律作废 */
  setChestSaveId(save.id);

  try { startDiagnostics(save.id, document.getElementById('game-canvas')); } catch(e){}

  if (Array.isArray(save.edits)) deserializeEdits(save.edits);
  else if (isNew) deserializeEdits([]);
  if (isNew) deserializeBlockData([]);

  clearAnimals();
  clearFurnaces();
  clearChests();
  for (const d of drops){
    scene.remove(d.mesh);
    if (d.mesh.geometry) d.mesh.geometry.dispose();
    if (d.mesh.material) d.mesh.material.dispose();
  }
  drops.length = 0;

  player.mode = save.playerMode || 'survival';
  player.flying = player.mode === 'creative';
  player.health = player.maxHealth;
  player.breath = 1.0;
  player.hunger = player.maxHunger;
  player.saturation = 0;
  player.exhaustion = 0;
  clearInventory();

  /* 盔甲 */
  player.armor = { head: null, chest: null, legs: null, feet: null };
  if (save.playerArmor && typeof save.playerArmor === 'object'){
    for (const k of ['head', 'chest', 'legs', 'feet']){
      const it = save.playerArmor[k];
      if (!it || !(it.count > 0)) continue;
      let id = null;
      if (typeof it.n === 'string') id = nameToId(it.n);
      else if (typeof it.id === 'number' && BLOCKS[it.id]) id = it.id;
      if (id === undefined || id === null) continue;
      player.armor[k] = { id, count: 1 };
    }
  }

  if (save.inventory && Array.isArray(save.inventory)){
    for (let i = 0; i < Math.min(save.inventory.length, inventory.length); i++){
      const s = save.inventory[i];
      if (!s || !(s.count > 0)) continue;
      let id = null;
      if (typeof s.n === 'string') id = nameToId(s.n);
      else if (typeof s.id === 'number' && BLOCKS[s.id]) id = s.id;
      if (id === undefined || id === null) continue;
      inventory[i] = { id, count: s.count };
      if (s.durability !== undefined){
        inventory[i].durability = s.durability;
        inventory[i].maxDurability = s.maxDurability;
      }
      if (s.meta !== undefined) inventory[i].meta = s.meta;  /* ★ 恢复 meta */
    }
    notifyInventory();
  }

  const curDim = getActiveDimensionId();
  _applyDimensionEnvironment(curDim);

  if (!isNew && player.posByDim[curDim]){
    restorePosFromDim(curDim);
  } else {
    const gen = getActiveGenerator();
    if (gen && typeof gen.spawnHint === 'function'){
      const hint = gen.spawnHint(save.seed);
      if (hint && typeof hint.x === 'number'){
        setSpawnHint(hint);
        player.vel.set(0, 0, 0);
        snapshotPosForDim(curDim);
        updateHearts(player.health, player.maxHealth, player.mode);
        return;
      }
    }
    const spawnPos = _findSpawnForDimension(curDim);
    player.pos.set(spawnPos.x + 0.5, spawnPos.y, spawnPos.z + 0.5);
    player.vel.set(0, 0, 0);
    player.yaw = 0; player.pitch = 0;
    snapshotPosForDim(curDim);
  }

  const restored = save.blocks ? save.blocks.slice() : [];
  suppressBlockChange = true;
  for (const b of restored){
    const id = resolveBlockId(b);
    if (id === null) continue;
    setBlockWorld(b.x, b.y, b.z, id);
    if (b.lv)  setFluidLevel(b.x, b.y, b.z, b.lv);
    if (b.src) setFluidSource(b.x, b.y, b.z, 1);
  }
  suppressBlockChange = false;
  blockChanges = restored.slice();

  clearLeaves();
  resetFluid();
  clearSplash();

  updateHearts(player.health, player.maxHealth, player.mode);
  updateHunger(player.hunger, player.maxHunger, player.mode);
  const modeBtns = document.querySelectorAll('#setMode button');
  modeBtns.forEach(b => b.classList.toggle('active', b.dataset.val === player.mode));

  try { localStorage.setItem('3dmc_last_save_id', save.id); } catch(e){}

  emit('world.load', save, isNew);
}

/* ============================================================
   保存
   ============================================================ */
async function savePlayerOnly(){
  if (!currentSave) return;
  const curDim = getActiveDimensionId();
  snapshotPosForDim(curDim);
  try {
    await writeFile(currentSave.id, 'player.json', {
      dim: curDim,
      posByDim: player.posByDim,
      mode: player.mode,
      health: player.health, hunger: player.hunger,
      saturation: player.saturation, exhaustion: player.exhaustion,
      breath: player.breath, armor: player.armor,
    });
  } catch(e){ console.warn('[save] player save failed', e); }
}

async function persistCurrentWorld(){
  if (!currentSave) return;
  currentSave.lastPlayed = Date.now();

  const meta = {
    formatVersion: 2, id: currentSave.id,
    name: currentSave.name, type: currentSave.type, seed: currentSave.seed,
    worldHeight: currentSave.worldHeight,
    createdAt: currentSave.createdAt, lastPlayed: currentSave.lastPlayed,
    plugins: currentSave.plugins || [],
    usedMods: currentSave.usedMods || currentSave.plugins || [],
    gameRules: currentSave.gameRules || {},
    /* ★ 季节相位持久化：由 main.js tickSeason 写入 currentSave.seasonPhase，
       老存档可能是 undefined，兜底 0 */
    seasonPhase: (typeof currentSave.seasonPhase === 'number')
      ? currentSave.seasonPhase
      : 0,
    /* ★ 天气状态持久化 */
    weather: (() => { try { return serializeWeather(); } catch(e){ return null; } })(),
  };

  const curDim = getActiveDimensionId();
  snapshotPosForDim(curDim);

  const playerData = {
    dim: curDim,
    posByDim: player.posByDim,
    mode: player.mode,
    health: player.health, hunger: player.hunger,
    saturation: player.saturation, exhaustion: player.exhaustion, breath: player.breath,
    armor: player.armor,
  };
  const invData = {
    v: 1,
    slots: inventory.map(s => {
      if (!s) return null;
      const blk = BLOCKS[s.id];
      const out = { n: blk ? blk.name : null, id: s.id, count: s.count,
                    durability: s.durability, maxDurability: s.maxDurability };
      if (s.meta !== undefined) out.meta = s.meta;   /* ★ 携带 meta */
      return out;
    })
  };
  const blocksData   = { v: 1, list: blockChanges };
  const entitiesData = { v: 1, list: serializeAnimals() };
  const furnacesData = { v: 1, list: serializeFurnaces() };
  const editsData    = { v: 1, list: serializeEdits() };
  const bdData       = { v: 1, list: serializeBlockData() };

  try {
    await Promise.all([
      writeFile(currentSave.id, 'world.json',     meta),
      writeFile(currentSave.id, 'player.json',    playerData),
      writeFile(currentSave.id, 'inventory.json', invData),
      writeFile(currentSave.id, 'blocks.json',    blocksData),
      writeFile(currentSave.id, 'entities.json',  entitiesData),
      writeFile(currentSave.id, 'furnaces.json',  furnacesData),
      writeFile(currentSave.id, 'edits.json',     editsData),
      writeFile(currentSave.id, 'blockdata.json', bdData),
    ]);
    /* ★ 箱子各自是独立文件，只有被改过的才会写 */
    try { await flushAllChests(); }
    catch(e){ console.warn('[save] 箱子落盘失败:', e && e.message); }

    const { flushSaveQueue } = await import('./../world/world-core.js');
    await flushSaveQueue();
  } catch(e){
    console.error('[save] persist failed', e);
    toast('保存失败：' + (e.message || e));
  }

  emit('world.save', currentSave.id, currentSave);
}

/* ============================================================
   ★ 维度出生点
   ------------------------------------------------------------
   两轮搜索：
     ① 宜居群系（排除海洋/河流/蘑菇岛/雪原/沙漠）
     ② 放宽（只要非海洋非河流）
   兜底：原点上方 SEA_LEVEL + 8，不会淹死
   ============================================================ */
function _findSpawnForDimension(dimId){
  const R_MAX = 2000;
  const DA = Math.PI / 8;   // 16 个方向

  /* ---- 第一轮：宜居群系 ---- */
  for (let r = 0; r < R_MAX; r += 8){
    for (let a = 0; a < 16; a++){
      const ang = a * DA;
      const x = Math.round(Math.cos(ang) * r);
      const z = Math.round(Math.sin(ang) * r);
      const h = Math.floor(heightAt(x, z));
      if (h <= SEA_LEVEL + 2) continue;

      const b = biomeAt(x, z, h);
      /* 排除：海洋(0) / 河流(15) / 蘑菇岛(14) / 雪原(8) / 沙漠(9) */
      if (b === 0 || b === 15 || b === 14 || b === 8 || b === 9) continue;
      return { x, z, y: h + 3 };
    }
  }

  /* ---- 第二轮：放宽 ---- */
  for (let r = 0; r < R_MAX; r += 8){
    for (let a = 0; a < 16; a++){
      const ang = a * DA;
      const x = Math.round(Math.cos(ang) * r);
      const z = Math.round(Math.sin(ang) * r);
      const h = Math.floor(heightAt(x, z));
      if (h <= SEA_LEVEL + 1) continue;

      const b = biomeAt(x, z, h);
      if (b === 0 || b === 15) continue;
      return { x, z, y: h + 3 };
    }
  }

  /* ---- 兜底 ---- */
  console.warn('[world-save] 未找到宜居出生点，使用原点上方');
  return { x: 0, z: 0, y: SEA_LEVEL + 8 };
}

function _applyDimensionEnvironment(dimId){
  const dim = getDimension(dimId);
  let genId;
  if (dimId === 'overworld'){
    genId = currentSave ? currentSave.type : 'vanilla';
  } else {
    genId = (dim && dim.generator) ? dim.generator : 'vanilla';
  }
  setActiveGenerator(genId);

  if (dim && dim.skyPreset) _setSkyPreset(dim.skyPreset);
  else _setSkyPreset(null);

  if (dim && dim.biomeFog) _setBiomeFog(dim.biomeFog);
  else _setBiomeFog(null);
}

async function switchDimension(dimId, silent){
  if (_switchingDimension) return false;
  if (!currentSave) return false;
  if (!hasDimension(dimId)){
    console.warn(`[dim] 未注册的维度: ${dimId}`);
    return false;
  }
  if (dimId === getActiveDimensionId()) return false;

  _switchingDimension = true;
  const fromDim = getActiveDimensionId();

  try {
    snapshotPosForDim(fromDim);
    const { clearActiveDimensionChunks } = await import('../world/terrain.js');
    clearActiveDimensionChunks();

    if (!_setActiveDimId(dimId)){
      console.error('[dim] setActiveDimensionId 失败');
      return false;
    }

    _applyDimensionEnvironment(dimId);

    if (!restorePosFromDim(dimId)){
      const spawnPos = _findSpawnForDimension(dimId);
      player.pos.set(spawnPos.x + 0.5, spawnPos.y, spawnPos.z + 0.5);
      player.vel.set(0, 0, 0);
      player.yaw = 0;
      player.pitch = 0;
      snapshotPosForDim(dimId);
    }

    if (_enterGame) _enterGame(silent);

    log.i('dim', `切换到维度 ${fromDim} → ${dimId}`);
    emit('dimension.change', fromDim, dimId);
    return true;
  } catch(e){
    console.error('[dim] 切换失败:', e && e.message);
    return false;
  } finally {
    _switchingDimension = false;
  }
}

/* =================================================================
   save/loader.js
   ================================================================= */
/* ============================================================
   loader.js —— mod 加载器
   ------------------------------------------------------------
   职责：
   · 从 /api/mods 拿可用 mod 列表
   · 按 world.json 的 plugins 逐个动态 import
   · 调 mod.onEnable(saveId, meta, G) 让它初始化
   · 切存档时按反序调 onDisable(saveId)
   · 一个 mod 抛错不影响其他 mod
   · 宿主事件 → 同步派发到全局事件总线
   · 记录每次加载结果，供 UI（mod-status 面板）展示

   ⚠ 浏览器 ESM 有缓存：同一个 /mods/<id>/main.js 只会 eval 一次。
     mod 顶层的副作用（scene.add、事件注册）请放到 onEnable 里，
     否则切存档后不会重跑。

   ⚠ __GAME__ 由 main.js 的 installHost() 挂载，通常早于 loadModsForSave。
     若尚未挂载，onEnable 第三个参数会是 null（mod 需自行容错）。
   ============================================================ */



const API_MODS = '/api/mods';
const HOST_API_VERSION = 4;

/* 已加载 mod: id -> { id, meta, instance, saveId } */
const _loaded = new Map();

/* 可用 mod 列表缓存（一次会话只拉一次） */
let _availableCache = null;

/* 当前加载的存档 id */
let _currentSaveId = null;

/* ★ M5：本次加载结果（成功后写，供 UI 读取） */
let _lastLoadResult = { loaded: [], failed: [], skipped: [], warnings: [] };

/* ============================================================
   内部
   ============================================================ */

async function fetchAvailableMods(force){
  if (_availableCache && !force) return _availableCache;
  try {
    const r = await fetch(API_MODS);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const arr = await r.json();
    _availableCache = Array.isArray(arr) ? arr : [];
  } catch(e){
    console.warn('[loader] 无法获取 mod 列表:', e.message);
    _availableCache = [];
  }
  return _availableCache;
}

function checkApiVersion(meta){
  const want = Number(meta.apiVersion) || 1;
  if (want > HOST_API_VERSION){
    return `需要 API v${want}，宿主只支持 v${HOST_API_VERSION}`;
  }
  return null;
}

/* 拿宿主门面（可能为 null，比如安装时机变化） */
function getHost(){
  if (typeof window === 'undefined') return null;
  return window.__GAME__ || null;
}

/* 等 __GAME__ 就绪（最多等 ~200ms） */
async function waitForHost(){
  if (getHost()) return getHost();
  for (let i = 0; i < 20; i++){
    await new Promise(r => setTimeout(r, 10));
    if (getHost()) return getHost();
  }
  return null;
}

/* ============================================================
   ★ Phase 1.3：/api/hooks 静态校验
   ============================================================ */
let _hooksRegistryPromise = null;
function _fetchHooksRegistry(){
  if (_hooksRegistryPromise) return _hooksRegistryPromise;
  _hooksRegistryPromise = fetch('/api/hooks')
    .then(r => r.ok ? r.json() : { hooks: [], events: [] })
    .catch(() => ({ hooks: [], events: [] }));
  return _hooksRegistryPromise;
}

function _validateDetectedUsage(available, result, registry){
  const validHooks  = new Set((registry.hooks  || []).map(x => x.name));
  const validEvents = new Set((registry.events || []).map(x => x.name));
  const loadedSet = new Set(result.loaded);

  for (const meta of available){
    if (!loadedSet.has(meta.id)) continue;
    for (const name of (meta.detectedHooks || [])){
      if (!validHooks.has(name)){
        result.warnings.push({
          id: meta.id, kind: 'hook', name,
          message: `引用了不存在的 hook 点: "${name}"`,
        });
      }
    }
    for (const name of (meta.detectedEvents || [])){
      if (!validEvents.has(name)){
        result.warnings.push({
          id: meta.id, kind: 'event', name,
          message: `订阅了不存在的事件: "${name}"`,
        });
      }
    }
  }
}

function _topoSort(ids, byId){
  /* ★ [loader-v2] 拓扑排序
     · 环：记录并跳过环内节点，其他 mod 继续加载
     · 缺失依赖：记录到 warnings（可选依赖不报）
     · dependencies 支持 'mod_id' 或 { id, version, optional }
     · 稳定顺序：同层级按 plugins 数组原顺序
  */
  const out = [];
  const visited = new Set();
  const visiting = new Set();
  const cycles = [];
  const missingDeps = [];
  const idSet = new Set(ids);

  function visit(id, stack){
    if (visited.has(id)) return;
    if (visiting.has(id)){
      const cycleStart = stack.indexOf(id);
      const cycle = cycleStart >= 0
        ? stack.slice(cycleStart).concat(id)
        : stack.concat(id);
      cycles.push(cycle.join(' → '));
      return;
    }
    visiting.add(id);
    const m = byId.get(id);
    if (m && Array.isArray(m.dependencies)){
      for (const dep of m.dependencies){
        const depId = typeof dep === 'string' ? dep : (dep && dep.id);
        if (!depId) continue;
        const isOptional = (typeof dep === 'object' && dep && (dep.optional || dep.soft));
        if (!idSet.has(depId)){
          if (!isOptional) missingDeps.push({ mod: id, dep: depId });
          continue;
        }
        visit(depId, stack.concat(id));
      }
    }
    visiting.delete(id);
    if (!visited.has(id)){
      visited.add(id);
      out.push(id);
    }
  }

  for (const id of ids) visit(id, []);
  return { sorted: out, cycles, missingDeps };
}

/* ★ [loader-v2] 依赖失败级联检查 */
function _checkCascadeFail(id, meta, failedSet, skippedSet){
  if (!meta || !Array.isArray(meta.dependencies)) return null;
  for (const dep of meta.dependencies){
    if (typeof dep === 'object' && dep && (dep.optional || dep.soft)) continue;
    const depId = typeof dep === 'string' ? dep : (dep && dep.id);
    if (!depId) continue;
    if (failedSet.has(depId)) return `依赖 "${depId}" 加载失败`;
    if (skippedSet.has(depId)) return `依赖 "${depId}" 被跳过`;
  }
  return null;
}

/* ★ [loader-v2] 依赖版本约束检查 */
function _checkDependencyVersions(meta, byId){
  if (!Array.isArray(meta.dependencies)) return null;
  for (const dep of meta.dependencies){
    if (typeof dep !== 'object' || !dep || !dep.version) continue;
    const depId = dep.id;
    if (!depId) continue;
    const depMeta = byId.get(depId);
    if (!depMeta) continue;
    if (!_satisfiesVersion(depMeta.version || '0.0.0', dep.version)){
      return `依赖 "${depId}" 需要 "${dep.version}"，实际 v${depMeta.version || '0.0.0'}`;
    }
  }
  return null;
}

/* ★ [loader-v2] 简化版语义化版本检查 */
function _satisfiesVersion(actual, constraint){
  if (!constraint) return true;
  const s = String(constraint).trim();
  const m = s.match(/^(>=|<=|>|<|=|\^|~)?\s*(.+)$/);
  if (!m) return true;
  const op = m[1] || '=';
  const target = m[2].trim();
  const cmp = _compareVersions(actual, target);
  if (op === '>=') return cmp >= 0;
  if (op === '<=') return cmp <= 0;
  if (op === '>')  return cmp > 0;
  if (op === '<')  return cmp < 0;
  if (op === '=')  return cmp === 0;
  if (op === '^' || op === '~') return cmp >= 0;
  return true;
}

function _compareVersions(a, b){
  const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++){
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

/* ============================================================
   公开 API
   ============================================================ */

/**
 * 为某个存档加载启用的 mod。
 * @param {string}   saveId
 * @param {string[]} enabledIds  world.json 里的 plugins
 * @returns {Promise<{loaded: string[], failed: string[]}>}
 */
async function loadModsForSave(saveId, enabledIds){
  if (_currentSaveId !== null && _currentSaveId !== saveId){
    await unloadAllMods(_currentSaveId);
  }
  _currentSaveId = saveId;

  clearModStorageCache();

  /* ★ [loader-v2] 结果分 4 类 */
  _lastLoadResult = { loaded: [], failed: [], skipped: [], warnings: [] };

  const ids = Array.isArray(enabledIds)
    ? enabledIds.filter(x => typeof x === 'string' && x.length > 0)
    : [];

  const result = { loaded: [], failed: [], skipped: [] };
  if (ids.length === 0) return result;

  const available = await fetchAvailableMods();
  const byId = new Map(available.map(m => [m.id, m]));

  /* ★ [loader-v2] 拓扑排序 + 环/缺失检查 */
  const topo = _topoSort(ids, byId);
  const sortedIds = topo.sorted;

  if (topo.cycles.length){
    for (const cy of topo.cycles){
      console.error(`[loader] ⚠ 依赖环: ${cy}`);
      _lastLoadResult.warnings.push({
        id: cy, kind: 'cycle', name: '', message: `依赖环: ${cy}`,
      });
    }
  }
  if (topo.missingDeps.length){
    for (const { mod, dep } of topo.missingDeps){
      console.warn(`[loader] "${mod}" 依赖 "${dep}"，但 "${dep}" 未启用`);
      _lastLoadResult.warnings.push({
        id: mod, kind: 'missing_dep', name: dep,
        message: `依赖 "${dep}" 未启用`,
      });
    }
  }

  const G = await waitForHost();
  if (!G){
    console.warn('[loader] __GAME__ 未就绪，mod 将拿不到宿主导出');
  }

  /* ★ [loader-v2] 级联跳过跟踪 */
  const failedSet = new Set();
  const skippedSet = new Set();

  for (const id of sortedIds){
    /* 1. 依赖失败 → 级联跳过 */
    const cascadeReason = _checkCascadeFail(id, byId.get(id), failedSet, skippedSet);
    if (cascadeReason){
      result.skipped.push(id);
      skippedSet.add(id);
      _lastLoadResult.skipped.push({
        id, reason: 'dependency_failed', message: cascadeReason,
      });
      console.warn(`[loader] "${id}" 跳过: ${cascadeReason}`);
      continue;
    }

    /* 2. 缺失 */
    const meta = byId.get(id);
    if (!meta){
      console.warn(`[loader] 存档启用了 "${id}"，但 mods/ 下找不到`);
      result.failed.push(id);
      failedSet.add(id);
      _lastLoadResult.failed.push({
        id, reason: 'not_found', message: 'mods/ 目录下找不到这个 mod',
      });
      continue;
    }

    /* 3. API 版本 */
    const verErr = checkApiVersion(meta);
    if (verErr){
      console.warn(`[loader] "${id}" API 版本不兼容: ${verErr}`);
      result.failed.push(id);
      failedSet.add(id);
      _lastLoadResult.failed.push({
        id, reason: 'api_version', message: verErr,
      });
      continue;
    }

    /* 4. 依赖版本约束 */
    const depVerErr = _checkDependencyVersions(meta, byId);
    if (depVerErr){
      console.warn(`[loader] "${id}" 依赖版本不满足: ${depVerErr}`);
      result.failed.push(id);
      failedSet.add(id);
      _lastLoadResult.failed.push({
        id, reason: 'dep_version', message: depVerErr,
      });
      continue;
    }

    /* 5. 加载 */
    const r = await _loadOne(id, meta, saveId, G);
    if (r.ok){
      result.loaded.push(id);
      _lastLoadResult.loaded.push(id);
    } else {
      result.failed.push(id);
      failedSet.add(id);
      _lastLoadResult.failed.push({
        id, reason: 'load_error',
        message: (r.error && (r.error.message || String(r.error))) || '加载失败',
      });
    }
  }

  /* hook 校验 */
  try {
    const reg = await _fetchHooksRegistry();
    _validateDetectedUsage(available, _lastLoadResult, reg);
  } catch(e){
    console.warn('[loader] hook 校验跳过:', e);
  }

  console.log(
    `[loader] 加载完成: ${result.loaded.length} 成功 / ${result.failed.length} 失败` +
    (result.skipped.length ? ` / ${result.skipped.length} 跳过` : '') +
    (_lastLoadResult.warnings.length ? ` / ${_lastLoadResult.warnings.length} 警告` : '')
  );
  if (_lastLoadResult.warnings.length){
    for (const w of _lastLoadResult.warnings){
      console.warn(`[loader] ⚠ ${w.id}: ${w.message}`);
    }
  }
  return result;
}

/**
 * 加载单个 mod（内部 + reloadMod 复用）。
 * @returns {Promise<{ ok: boolean, error?: Error }>}
 */
async function _loadOne(id, meta, saveId, G, retryCount){
  const MAX_RETRY = 1;
  const attempt = retryCount || 0;

  try {
    const entry = meta.entry || 'main.js';
    const url = `/mods/${encodeURIComponent(id)}/` +
                entry.split('/').map(encodeURIComponent).join('/') +
                (attempt > 0 ? `?retry=${attempt}` : '');

    const mod = await import(/* @vite-ignore */ url);
    const instance = (mod && mod.default) ? mod.default : mod;

    if (typeof instance.onEnable === 'function'){
      await instance.onEnable(saveId, meta, G);
    }

    _loaded.set(id, { id, meta, instance, saveId });
    console.log(`[loader] ✔ 已加载 mod: ${id} v${meta.version || '?'}`);
    emit('mod.loaded', id, meta, instance);
    return { ok: true };
  } catch(e){
    console.error(`[loader] ✘ 加载 mod "${id}" 失败:`, e);
    if (attempt < MAX_RETRY && _isRetryable(e)){
      console.warn(`[loader] 重试 "${id}" ...`);
      await new Promise(r => setTimeout(r, 300));
      return await _loadOne(id, meta, saveId, G, attempt + 1);
    }
    emit('mod.load_failed', id, meta, e);
    return { ok: false, error: e };
  }
}

/* 判断是否值得重试：网络 / 缓存类错误 */
function _isRetryable(e){
  if (!e) return false;
  const msg = String(e.message || e);
  return /network|fetch|timeout|loading chunk|failed to fetch/i.test(msg);
}

/**
 * 卸载当前存档的所有 mod（按加载的相反顺序）。
 */
async function unloadAllMods(saveId){
  const sid = saveId || _currentSaveId;
  const entries = Array.from(_loaded.values()).reverse();
  _loaded.clear();
  _currentSaveId = null;
  _lastLoadResult = { loaded: [], failed: [], skipped: [], warnings: [] };   // ★ M5 + loader-v2

  for (const { id, instance, meta } of entries){
    try {
      if (typeof instance.onDisable === 'function'){
        await instance.onDisable(sid);
      }
    } catch(e){
      console.error(`[loader] mod "${id}" onDisable 出错:`, e);
    }
    console.log(`[loader] ✘ 已卸载 mod: ${id}`);
    emit('mod.unloaded', id, meta, instance);
  }
}

/**
 * ★ 热重载单个 mod（开发用）。
 * 会先卸载旧的，再重新加载。浏览器 ESM 缓存无法清除，
 * 所以通过 URL 加时间戳参数绕过缓存 —— 但这会导致 import 的是
 * "新模块"，mod 内部如果有跨模块状态会丢。慎用。
 */
async function reloadMod(id){
  const old = _loaded.get(id);
  const saveId = old ? old.saveId : _currentSaveId;
  if (!saveId){
    console.warn('[loader] reloadMod: 无当前存档');
    return false;
  }

  const available = await fetchAvailableMods(true);
  const meta = available.find(m => m.id === id);
  if (!meta){
    console.warn(`[loader] reloadMod: 找不到 mod "${id}"`);
    return false;
  }

  if (old){
    try {
      if (typeof old.instance.onDisable === 'function'){
        await old.instance.onDisable(saveId);
      }
    } catch(e){ console.error(`[loader] "${id}" onDisable 出错:`, e); }
    _loaded.delete(id);
  }

  const G = getHost();
  const entry = meta.entry || 'main.js';
  const url = `/mods/${encodeURIComponent(id)}/` +
              entry.split('/').map(encodeURIComponent).join('/') +
              `?t=${Date.now()}`;
  try {
    const mod = await import(/* @vite-ignore */ url);
    const instance = (mod && mod.default) ? mod.default : mod;
    if (typeof instance.onEnable === 'function'){
      await instance.onEnable(saveId, meta, G);
    }
    _loaded.set(id, { id, meta, instance, saveId });
    console.log(`[loader] ♻ 已重载 mod: ${id}`);
    emit('mod.reloaded', id, meta, instance);
    return true;
  } catch(e){
    console.error(`[loader] 重载 "${id}" 失败:`, e);
    return false;
  }
}

/** 拿某个已加载 mod 的实例 */
function getLoadedMod(id){
  const rec = _loaded.get(id);
  return rec ? rec.instance : null;
}

/** 当前所有已加载 mod 的 id */
function getLoadedModIds(){
  return Array.from(_loaded.keys());
}

/** 已加载 mod 的元数据 */
function getLoadedModMeta(id){
  const rec = _loaded.get(id);
  return rec ? rec.meta : null;
}

/** 当前存档 id */
function getLoaderSaveId(){
  return _currentSaveId;
}

/* ============================================================
   ★ M5：加载结果 API（供 mod-status 面板使用）
   ============================================================ */

/**
 * 拿最近一次 loadModsForSave 的结果。
 * @returns {{ loaded: string[], failed: Array<{id, reason, message}> }}
 */
function getLastLoadResult(){
  return {
    loaded: _lastLoadResult.loaded.slice(),
    failed: _lastLoadResult.failed.map(f => ({ ...f })),
    skipped: (_lastLoadResult.skipped || []).map(s => ({ ...s })),
    warnings: (_lastLoadResult.warnings || []).map(w => ({ ...w })),
  };
}

/** 清空加载结果（切存档 / 卸载时） */
function clearLastLoadResult(){
  _lastLoadResult = { loaded: [], failed: [], skipped: [], warnings: [] };
}

/**
 * 宿主手动广播事件给所有已加载 mod。
 * mod 侧同名方法存在就被调用；同时抛到全局事件总线。
 *
 * 例：await broadcast('onBlockBreak', x, y, z, blockId);
 */
async function broadcast(eventName, ...args){
  const list = Array.from(_loaded.values());
  for (let i = 0; i < list.length; i++){
    const { id, instance } = list[i];
    const fn = instance[eventName];
    if (typeof fn !== 'function') continue;
    try { await fn(...args); }
    catch(e){ console.error(`[loader] mod "${id}".${eventName} 出错:`, e); }
  }
  /* ★ 同步派发到全局事件总线 */
  emit(eventName, ...args);
}

/** 强制刷新可用 mod 列表缓存 */
async function refreshModList(){
  _availableCache = null;
  return await fetchAvailableMods(true);
}

/** 当前可用 mod 列表 */
async function getAvailableMods(){
  return await fetchAvailableMods();
}

/* =================================================================
   re-export
   ================================================================= */
export {
  listSaves, createSave, deleteSave, readFile, writeFile, readSaveJson, writeSaveJson, deleteSavePath, readBytes, writeBytes, readText, io_listModsInSave, getModStorage, clearModStorageCache, getCurrentSave, setCurrentSave, getBlockChanges, initWorldSave, setWorldHeightInput, startNewWorld, loadExistingWorld, applySaveToWorld, savePlayerOnly, persistCurrentWorld, switchDimension, loadModsForSave, unloadAllMods, reloadMod, getLoadedMod, getLoadedModIds, getLoadedModMeta, getLoaderSaveId, getLastLoadResult, clearLastLoadResult, broadcast, refreshModList, getAvailableMods,
};
