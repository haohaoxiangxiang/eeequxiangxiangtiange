/* ============================================================
   highlight.js —— 实体高亮
   ------------------------------------------------------------
   发光箭矢命中实体后，在实体外面套一层加色发光外壳，
   持续几秒后消失。不改实体材质（材质是共享的，改会全部高亮）。
   ============================================================ */

import * as THREE from 'three';
import { scene } from '../render/render-core.js';

const shells = [];

export function highlightEntity(a, seconds){
  if (!a || a.dead) return;
  const w = Math.max(0.5, (a.width || 0.6)) * 1.35;
  const h = Math.max(1.0, (a.height || 1.8)) * 1.12;
  const geo = new THREE.BoxGeometry(w, h, w);
  const mat = new THREE.MeshBasicMaterial({
    color: 0xa8ffb0,
    transparent: true,
    opacity: 0.22,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(a.pos.x, a.pos.y + h * 0.5, a.pos.z);
  scene.add(mesh);
  shells.push({ mesh, entity: a, t: seconds || 3, h });
}

export function updateHighlights(dt){
  for (let i = shells.length - 1; i >= 0; i--){
    const s = shells[i];
    s.t -= dt;
    const a = s.entity;
    if (s.t <= 0 || !a || a.dead){
      scene.remove(s.mesh);
      s.mesh.geometry.dispose();
      s.mesh.material.dispose();
      shells.splice(i, 1);
      continue;
    }
    s.mesh.position.set(a.pos.x, a.pos.y + s.h * 0.5, a.pos.z);
    s.mesh.material.opacity = 0.22 * Math.min(1, s.t / 0.6);
  }
}

export function clearHighlights(){
  for (let i = 0; i < shells.length; i++){
    scene.remove(shells[i].mesh);
    shells[i].mesh.geometry.dispose();
    shells[i].mesh.material.dispose();
  }
  shells.length = 0;
}
