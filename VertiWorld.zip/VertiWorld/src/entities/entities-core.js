/* ============================================================
   entities-core.js —— 实体类型注册表 + 动物 AI
   ------------------------------------------------------------
★ 合并自两个文件：
     entity-registry.js  实体类型注册表（4.5KB，只被 animals.js 引用）
     animals.js          动物 AI / 生怪 / 距离分级 tick（39KB）
   registry 只有一个使用者，合并掉这一层。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from 'three';
import { BLOCKS, B } from '../world/blocks.js';
import { SEA_LEVEL, Y_MIN, CS } from './../core/engine-core.js';
import { clamp } from './../core/runtime.js';
import { emit, emitCancellable, on } from './../core/engine-core.js';
import { getBlockWorld, isSolidWorld, heightAt, biomeAt, chunks, chunkKey } from '../world/terrain.js';
import { getBiome } from '../world/world-core.js';
import { scene } from './../render/render-core.js';
import { spawnDrop } from './../items/items-logic.js';


/* =================================================================
   entity-registry.js
   ================================================================= */
/* ============================================================
   entity-registry.js —— 实体类型注册表
   ------------------------------------------------------------
   新增 category 字段（可选）：
     'land_herbivore'  陆生草食（默认 land 类）
     'land_predator'   陆生肉食
     'water'           水生
     'flying'          飞行
     'other'           未分类

   不填时按 spawnKind 自动推断：
     spawnKind: 'land'  → 'land_herbivore'
     spawnKind: 'water' → 'water'
     其它              → 'other'
   ============================================================ */

const _types = new Map();

function registerEntity(id, cfg){
  if (typeof id !== 'string' || !id){
    console.warn('[entity] 非法 id:', id);
    return null;
  }
  if (!cfg || typeof cfg.build !== 'function'){
    console.warn(`[entity] "${id}" 缺少 build 函数`);
    return null;
  }
  if (_types.has(id)){
    console.warn(`[entity] "${id}" 已存在，忽略`);
    return _types.get(id);
  }

  /* 分类推断 */
  let category = cfg.category;
  if (!category){
    if (cfg.spawnKind === 'land') category = 'land_herbivore';
    else if (cfg.spawnKind === 'water') category = 'water';
    else category = 'other';
  }

  const type = {
    id,
    label:  cfg.label || id,
    build:  cfg.build,

    update:     typeof cfg.update     === 'function' ? cfg.update     : null,
    onDamage:   typeof cfg.onDamage   === 'function' ? cfg.onDamage   : null,
    onDeath:    typeof cfg.onDeath    === 'function' ? cfg.onDeath    : null,
    onSpawn:    typeof cfg.onSpawn    === 'function' ? cfg.onSpawn    : null,
    onInteract: typeof cfg.onInteract === 'function' ? cfg.onInteract : null,
    loot:       typeof cfg.loot       === 'function' ? cfg.loot       : (() => []),

    health: cfg.health !== undefined ? cfg.health : 10,
    width:  cfg.width  !== undefined ? cfg.width  : 0.6,
    height: cfg.height !== undefined ? cfg.height : 1.8,
    depth:  cfg.depth  !== undefined ? cfg.depth  : 0.6,
    speed:  cfg.speed  !== undefined ? cfg.speed  : 1.0,

    flying:  !!cfg.flying,
    aquatic: !!cfg.aquatic,

    /* ★ 新增：分类 */
    category,
    persistent: !!cfg.persistent,

    spawnKind:   cfg.spawnKind   || null,
    spawnWeight: cfg.spawnWeight !== undefined ? cfg.spawnWeight : 1,
    spawnCap:    cfg.spawnCap    !== undefined ? cfg.spawnCap    : null,

    params: cfg.params || {},
  };

  _types.set(id, type);
  console.log(`[entity] 注册实体: ${id} (${type.label}) [${category}]`);
  return type;
}

function getEntityType(id){
  return _types.get(id) || null;
}

function hasEntityType(id){
  return _types.has(id);
}

function listEntityTypes(){
  return Array.from(_types.keys());
}

function getAllEntityTypes(){
  return Array.from(_types.values());
}

function getEntityTypeCount(){
  return _types.size;
}

function getSpawnableTypes(kind){
  const out = [];
  for (const t of _types.values()){
    if (t.spawnKind === kind) out.push(t);
  }
  return out;
}

/* ★ 新增：按分类列出类型 */
function getTypesByCategory(category){
  const out = [];
  for (const t of _types.values()){
    if (t.category === category) out.push(t);
  }
  return out;
}

/* =================================================================
   animals.js
   ================================================================= */
/* ============================================================
   诊断
   ============================================================ */
function getAnimalCount(){
  try { return animals.length; } catch(e){ return 0; }
}

function getDormantCount(){
  try {
    let n = 0;
    for (const a of animals) if (a.dormant) n++;
    return n;
  } catch(e){ return 0; }
}

/* ============================================================
   动物列表
   ============================================================ */
const animals = [];

/* ============================================================
   分类上限
   ============================================================ */
const _entityCaps = new Map();

const DEFAULT_CAPS = {
  land_herbivore: 60,
  land_predator:  20,
  water:          50,
  flying:         30,
  other:          20,
};

for (const [k, v] of Object.entries(DEFAULT_CAPS)){
  _entityCaps.set(k, v);
}

function setEntityCap(category, cap){
  if (typeof category !== 'string' || !category) return false;
  const n = Math.floor(Number(cap));
  if (!isFinite(n) || n < 0 || n > 500) return false;
  _entityCaps.set(category, n);
  console.log(`[entity] 上限 ${category} → ${n}`);
  return true;
}

function getEntityCap(category){
  return _entityCaps.get(category) || 0;
}

function listEntityCaps(){
  const out = {};
  for (const [k, v] of _entityCaps) out[k] = v;
  return out;
}

/* 按倍率统一缩放所有分类上限（设置里的"生物数量"） */
function setEntityCapScale(scale){
  const s = Math.max(0, Math.min(3, Number(scale) || 0));
  for (const [k, v] of Object.entries(DEFAULT_CAPS)){
    _entityCaps.set(k, Math.round(v * s));
  }
  return s;
}

function _getCategory(typeId){
  const cfg = getEntityType(typeId);
  return (cfg && cfg.category) || 'other';
}

/* ============================================================
   距离分级 tick
   ============================================================ */
let _tickNear = 16;
let _tickMid  = 48;
let _tickFar  = 96;

function setTickDistances(opts){
  if (!opts || typeof opts !== 'object') return;
  if (typeof opts.near === 'number') _tickNear = Math.max(4, opts.near);
  if (typeof opts.mid  === 'number') _tickMid  = Math.max(_tickNear, opts.mid);
  if (typeof opts.far  === 'number') _tickFar  = Math.max(_tickMid, opts.far);
  console.log(`[entity] tick 距离: near=${_tickNear} mid=${_tickMid} far=${_tickFar}`);
}

function getTickDistances(){
  return { near: _tickNear, mid: _tickMid, far: _tickFar };
}

function _tickIntervalFor(distSq){
  const near = _tickNear;
  const mid  = _tickMid;
  const far  = _tickFar;
  if (distSq <= near * near) return 1;
  if (distSq <= mid  * mid)  return 4;
  if (distSq <= far  * far)  return 16;
  return -1;
}

/* ============================================================
   休眠 / 距离
   ============================================================ */
const SPAWN_RADIUS = 40;
/* 和 MC 一致：离玩家 24 格内不生成实体，避免"当面刷脸" */
const MIN_SPAWN_D  = 24;
const SPAWN_COOLDOWN = 500;
const AUTO_SPAWN_INTERVAL = 2.5;
const GRAVITY = 26;
const STEP_JUMP = 7.8;

let CULL_DIST   = 8 * 16;
let RESUME_DIST = CULL_DIST - 8;
let CULL_D2     = CULL_DIST   * CULL_DIST;
let RESUME_D2   = RESUME_DIST * RESUME_DIST;

function setSimDistance(blocks){
  const b = Math.max(2, Math.min(32, blocks | 0));
  CULL_DIST   = b * 16;
  RESUME_DIST = Math.max(16, CULL_DIST - 8);
  CULL_D2     = CULL_DIST   * CULL_DIST;
  RESUME_D2   = RESUME_DIST * RESUME_DIST;

  if (_tickFar  > CULL_DIST) _tickFar  = CULL_DIST;
  if (_tickMid  > _tickFar)  _tickMid  = _tickFar;
  if (_tickNear > _tickMid)  _tickNear = _tickMid;
}
function getSimDistanceBlocks(){
  return Math.round(CULL_DIST / 16);
}

/* ============================================================
   ★ 超远 dormant 清理
   ------------------------------------------------------------
   玩家跑图时，dormant 动物堆积在数组里。
   定期清理 256 格以外的，避免内存无限增长。
   ============================================================ */
const PURGE_INTERVAL  = 5;              // 每 5 秒扫一次
const PURGE_DIST_SQ   = 256 * 256;      // 256 格外直接删
let _purgeTimer = 0;

/* ============================================================
   ★ mod 实体 AI 的失败计数
   ------------------------------------------------------------
   原来 cfg.update 抛一次异常就被置 null —— 永久失效，而且只留一行日志，
   mod 的 AI 只要有一帧偶发报错（某个依赖还没就绪）就全局失去 AI，无法恢复。
   改成连续失败 AI_FAIL_LIMIT 次才停用；中间成功一次就清零。
   被停用的类型可以查 listDisabledEntityAi()，便于在 Mod 状态里提示。
   ============================================================ */
const AI_FAIL_LIMIT = 5;
const _aiFails = new Map();      // type -> 连续失败次数
const _aiDead  = new Set();      // 已停用的类型

function listDisabledEntityAi(){
  return Array.from(_aiDead);
}

/* ============================================================
   共享几何体 / 材质
   ============================================================ */
const BOX = new THREE.BoxGeometry(1, 1, 1);

const MAT = {
  cowBody:  new THREE.MeshLambertMaterial({ color: 0xf2f2f2 }),
  cowPatch: new THREE.MeshLambertMaterial({ color: 0x2b2b2b }),
  cowHorn:  new THREE.MeshLambertMaterial({ color: 0xd8d2c0 }),
  cowSnout: new THREE.MeshLambertMaterial({ color: 0xd9a08c }),

  sheepWool: new THREE.MeshLambertMaterial({ color: 0xf6f5ee }),
  sheepSkin: new THREE.MeshLambertMaterial({ color: 0xcfc9b8 }),

  pigBody:  new THREE.MeshLambertMaterial({ color: 0xf0a0a8 }),
  pigSnout: new THREE.MeshLambertMaterial({ color: 0xe0838d }),

  chickenBody: new THREE.MeshLambertMaterial({ color: 0xfaf8f0 }),
  chickenBeak: new THREE.MeshLambertMaterial({ color: 0xe8a92b }),
  chickenComb: new THREE.MeshLambertMaterial({ color: 0xd0342c }),

  fishBody: new THREE.MeshLambertMaterial({ color: 0x2f86c9 }),
  fishFin:  new THREE.MeshLambertMaterial({ color: 0x63b8e8 }),
  fishEye:  new THREE.MeshLambertMaterial({ color: 0x101418 }),

  hurt: new THREE.MeshLambertMaterial({ color: 0xff3b30 })
};

function part(mat, w, h, d, x, y, z, shadow){
  const m = new THREE.Mesh(BOX, mat);
  m.scale.set(w, h, d);
  m.position.set(x, y, z);
  if (shadow) m.castShadow = true;
  return m;
}

function makeLeg(mat, w, h, d, x, y, z, swing){
  const pivot = new THREE.Group();
  pivot.position.set(x, y, z);
  pivot.userData.swing = swing;
  pivot.add(part(mat, w, h, d, 0, -h / 2, 0, false));
  return pivot;
}

/* ============================================================
   模型构建
   ============================================================ */
function buildCow(){
  const g = new THREE.Group();
  const body = part(MAT.cowBody, 0.70, 0.65, 1.40, 0, 0.87, 0, true);
  g.add(body);
  g.add(part(MAT.cowPatch, 0.72, 0.26, 0.42, 0, 0.98, -0.30, false));
  g.add(part(MAT.cowPatch, 0.72, 0.22, 0.34, 0, 0.80,  0.34, false));

  const head = new THREE.Group();
  head.position.set(0, 1.13, -0.90);
  head.add(part(MAT.cowBody, 0.45, 0.45, 0.45, 0, 0, 0, true));
  head.add(part(MAT.cowSnout, 0.30, 0.22, 0.20, 0, -0.10, -0.30, false));
  head.add(part(MAT.cowHorn, 0.08, 0.08, 0.20, -0.19, 0.26, 0, false));
  head.add(part(MAT.cowHorn, 0.08, 0.08, 0.20,  0.19, 0.26, 0, false));
  g.add(head);

  const legs = [
    makeLeg(MAT.cowBody, 0.18, 0.55, 0.18, -0.22, 0.55, -0.42,  1),
    makeLeg(MAT.cowBody, 0.18, 0.55, 0.18,  0.22, 0.55, -0.42, -1),
    makeLeg(MAT.cowBody, 0.18, 0.55, 0.18, -0.22, 0.55,  0.42, -1),
    makeLeg(MAT.cowBody, 0.18, 0.55, 0.18,  0.22, 0.55,  0.42,  1)
  ];
  for (const l of legs) g.add(l);
  return { group: g, parts: { legs, head, body, tail: null } };
}

function buildPig(){
  const g = new THREE.Group();
  const body = part(MAT.pigBody, 0.66, 0.56, 1.05, 0, 0.63, 0, true);
  g.add(body);

  const head = new THREE.Group();
  head.position.set(0, 0.72, -0.68);
  head.add(part(MAT.pigBody, 0.40, 0.38, 0.36, 0, 0, 0, true));
  head.add(part(MAT.pigSnout, 0.20, 0.15, 0.10, 0, -0.07, -0.21, false));
  head.add(part(MAT.pigBody, 0.07, 0.13, 0.05, -0.15, 0.22, 0.01, false));
  head.add(part(MAT.pigBody, 0.07, 0.13, 0.05,  0.15, 0.22, 0.01, false));
  g.add(head);

  const legs = [
    makeLeg(MAT.pigBody, 0.16, 0.40, 0.16, -0.20, 0.40, -0.32,  1),
    makeLeg(MAT.pigBody, 0.16, 0.40, 0.16,  0.20, 0.40, -0.32, -1),
    makeLeg(MAT.pigBody, 0.16, 0.40, 0.16, -0.20, 0.40,  0.32, -1),
    makeLeg(MAT.pigBody, 0.16, 0.40, 0.16,  0.20, 0.40,  0.32,  1)
  ];
  for (const l of legs) g.add(l);
  return { group: g, parts: { legs, head, body, tail: null } };
}

function buildSheep(){
  const g = new THREE.Group();
  const body = part(MAT.sheepWool, 0.85, 0.70, 1.20, 0, 0.80, 0, true);
  g.add(body);
  g.add(part(MAT.sheepWool, 0.70, 0.22, 0.95, 0, 1.20, 0.02, false));

  const head = new THREE.Group();
  head.position.set(0, 0.98, -0.70);
  head.add(part(MAT.sheepSkin, 0.40, 0.40, 0.40, 0, 0, 0, true));
  head.add(part(MAT.sheepWool, 0.44, 0.18, 0.44, 0, 0.24, 0, false));
  head.add(part(MAT.sheepSkin, 0.12, 0.12, 0.10, 0, -0.06, -0.22, false));
  g.add(head);

  const legs = [
    makeLeg(MAT.sheepSkin, 0.16, 0.45, 0.16, -0.20, 0.45, -0.33,  1),
    makeLeg(MAT.sheepSkin, 0.16, 0.45, 0.16,  0.20, 0.45, -0.33, -1),
    makeLeg(MAT.sheepSkin, 0.16, 0.45, 0.16, -0.20, 0.45,  0.33, -1),
    makeLeg(MAT.sheepSkin, 0.16, 0.45, 0.16,  0.20, 0.45,  0.33,  1)
  ];
  for (const l of legs) g.add(l);
  return { group: g, parts: { legs, head, body, tail: null } };
}

function buildChicken(){
  const g = new THREE.Group();
  const body = part(MAT.chickenBody, 0.32, 0.32, 0.44, 0, 0.42, 0, true);
  g.add(body);
  g.add(part(MAT.chickenBody, 0.06, 0.18, 0.26, -0.18, 0.44, 0.02, false));
  g.add(part(MAT.chickenBody, 0.06, 0.18, 0.26,  0.18, 0.44, 0.02, false));
  g.add(part(MAT.chickenBody, 0.16, 0.20, 0.12, 0, 0.58, 0.26, false));

  const head = new THREE.Group();
  head.position.set(0, 0.62, -0.20);
  head.add(part(MAT.chickenBody, 0.22, 0.22, 0.22, 0, 0, 0, true));
  head.add(part(MAT.chickenBeak, 0.10, 0.08, 0.14, 0, -0.02, -0.17, false));
  head.add(part(MAT.chickenComb, 0.07, 0.08, 0.14, 0, 0.15, 0, false));
  head.add(part(MAT.chickenComb, 0.06, 0.09, 0.08, 0, -0.10, -0.12, false));
  g.add(head);

  const legs = [
    makeLeg(MAT.chickenBeak, 0.07, 0.26, 0.07, -0.11, 0.26, 0.02,  1),
    makeLeg(MAT.chickenBeak, 0.07, 0.26, 0.07,  0.11, 0.26, 0.02, -1)
  ];
  for (const l of legs) g.add(l);
  return { group: g, parts: { legs, head, body, tail: null } };
}

function buildFish(){
  const g = new THREE.Group();
  const body = part(MAT.fishBody, 0.16, 0.30, 0.50, 0, 0.20, 0, true);
  g.add(body);
  g.add(part(MAT.fishFin, 0.04, 0.12, 0.20, 0, 0.40, 0.02, false));
  g.add(part(MAT.fishFin, 0.20, 0.06, 0.12, 0, 0.16, -0.08, false));
  g.add(part(MAT.fishEye, 0.03, 0.04, 0.03, -0.08, 0.26, -0.20, false));
  g.add(part(MAT.fishEye, 0.03, 0.04, 0.03,  0.08, 0.26, -0.20, false));

  const tail = new THREE.Group();
  tail.position.set(0, 0.20, 0.24);
  tail.add(part(MAT.fishFin, 0.04, 0.26, 0.18, 0, 0, 0.09, false));
  g.add(tail);
  return { group: g, parts: { legs: [], head: null, body, tail } };
}

/* ============================================================
   小工具
   ============================================================ */
const randRange = (a, b) => a + Math.random() * (b - a);
const randInt = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

function blockAt(x, y, z){
  const id = getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z));
  if (!id) return null;
  return BLOCKS[id] || null;
}
function isWaterAt(x, y, z){
  const b = blockAt(x, y, z);
  return !!b && b.name === 'water';
}
function isLiquidAt(x, y, z){
  const b = blockAt(x, y, z);
  return !!b && !!b.liquid;
}
function itemId(name){
  const b = B[name];
  return (b && typeof b.id === 'number') ? b.id : null;
}
function collideAnimalAt(x, y, z, w, h){
  const hw = w * 0.5;
  const x0 = Math.floor(x - hw + 1e-5), x1 = Math.floor(x + hw - 1e-5);
  const y0 = Math.floor(y + 1e-5),       y1 = Math.floor(y + h - 1e-5);
  const z0 = Math.floor(z - hw + 1e-5), z1 = Math.floor(z + hw - 1e-5);
  for (let bx = x0; bx <= x1; bx++)
    for (let by = y0; by <= y1; by++)
      for (let bz = z0; bz <= z1; bz++)
        if (isSolidWorld(bx, by, bz)) return true;
  return false;
}

/* ============================================================
   world API
   ============================================================ */
const worldApi = {
  isSolid:      isSolidWorld,
  getBlock:     getBlockWorld,
  blockAt,
  isWaterAt,
  isLiquidAt,
  heightAt,
  collideAnimalAt,
  moveWithCollision: (a, dt) => moveWithCollision(a, dt),
  SEA_LEVEL,
  Y_MIN,
  gravity:  GRAVITY,
  stepJump: STEP_JUMP,
};

function getWorldApi(){ return worldApi; }

/* ============================================================
   内置 AI
   ============================================================ */
function moveWithCollision(a, dt){
  const w = a.width, h = a.height;
  const dx = a.vel.x * dt, dy = a.vel.y * dt, dz = a.vel.z * dt;

  a.hitWall = false;
  a.onGround = collideAnimalAt(a.pos.x, a.pos.y - 0.06, a.pos.z, w, h);

  if (dx !== 0){
    if (!collideAnimalAt(a.pos.x + dx, a.pos.y, a.pos.z, w, h)) a.pos.x += dx;
    else { a.vel.x = 0; a.hitWall = true; }
  }
  if (dz !== 0){
    if (!collideAnimalAt(a.pos.x, a.pos.y, a.pos.z + dz, w, h)) a.pos.z += dz;
    else { a.vel.z = 0; a.hitWall = true; }
  }
  if (dy !== 0){
    if (!collideAnimalAt(a.pos.x, a.pos.y + dy, a.pos.z, w, h)){
      a.pos.y += dy;
      if (dy < 0) a.onGround = false;
    } else {
      if (a.vel.y < 0) a.onGround = true;
      a.vel.y = 0;
    }
  }
}

function probeAhead(a, px, pz){
  const fy = Math.floor(a.pos.y + 0.35);
  let solid = false, water = false;
  for (let y = fy + 1; y >= fy - 2; y--){
    const b = blockAt(px, y, pz);
    if (!b) continue;
    if (b.liquid){ water = true; continue; }
    if (b.solid){ solid = true; break; }
  }
  return { solid, water };
}

function turnAround(a){
  a.yaw += Math.PI * randRange(0.55, 1.45);
  a.timer = Math.max(a.timer, randRange(1.2, 3.0));
  a.state = 'walk';
}

function updateLandAnimal(a, dt, playerPos, world){
  const speed = (a._cfg && a._cfg.speed) || 1.15;

  a.timer -= dt;
  if (a.timer <= 0){
    if (a.state === 'walk' && Math.random() < 0.45){
      a.state = 'idle';
      a.timer = randRange(1.5, 4.0);
    } else {
      a.state = 'walk';
      a.timer = randRange(2.0, 5.5);
      a.yaw = Math.random() * Math.PI * 2;
    }
  }

  const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw);
  const probeD = a.width * 0.5 + 0.45;
  const px = a.pos.x + fx * probeD;
  const pz = a.pos.z + fz * probeD;
  const feet = blockAt(px, a.pos.y + 0.35, pz);
  const head = blockAt(px, a.pos.y + a.height * 0.8, pz);
  const ahead = probeAhead(a, px, pz);

  if (head && head.solid){
    turnAround(a);
  } else if (a.onGround && (!ahead.solid || ahead.water)){
    turnAround(a);
  } else if (feet && feet.solid){
    if (a.onGround && !collideAnimalAt(a.pos.x, a.pos.y + 1.05, a.pos.z, a.width, a.height))
      a.vel.y = STEP_JUMP;
    else if (a.onGround)
      turnAround(a);
  }

  const want = (a.state === 'walk') ? speed : 0;
  const k = Math.min(1, 8 * dt);
  a.vel.x += (fx * want - a.vel.x) * k;
  a.vel.z += (fz * want - a.vel.z) * k;

  a.inWater = isLiquidAt(a.pos.x, a.pos.y + a.height * 0.4, a.pos.z);

  if (a.inWater){
    a.vel.y += 30 * dt;
    if (a.vel.y > 2.2) a.vel.y = 2.2;
    a.vel.x *= (1 - Math.min(1, 1.4 * dt));
    a.vel.z *= (1 - Math.min(1, 1.4 * dt));
  } else {
    a.vel.y -= GRAVITY * dt;
  }
  a.vel.y = Math.max(a.vel.y, -50);

  moveWithCollision(a, dt);

  if (a.pos.y < Y_MIN - 2){ removeAnimal(a); return; }
  if (a.hitWall && a.onGround && a.state === 'walk') turnAround(a);
}

function updateFish(a, dt, playerPos, world){
  const speed = (a._cfg && a._cfg.speed) || 1.35;

  a.timer -= dt;
  if (a.timer <= 0){
    a.timer = randRange(1.5, 4.0);
    a.yaw = Math.random() * Math.PI * 2;
    a.vy = randRange(-0.45, 0.45);
    a.state = (Math.random() < 0.25) ? 'idle' : 'walk';
  }

  const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw);
  const want = (a.state === 'walk') ? speed : 0;
  const k = Math.min(1, 6 * dt);
  a.vel.x += (fx * want - a.vel.x) * k;
  a.vel.z += (fz * want - a.vel.z) * k;

  const bodyInWater = isWaterAt(a.pos.x, a.pos.y + a.height * 0.5, a.pos.z);

  if (!bodyInWater){
    a.vy = -0.6;
    a.vel.y -= 9 * dt;
  } else {
    if (!isWaterAt(a.pos.x, a.pos.y + a.height + 0.2, a.pos.z)) a.vel.y -= 7 * dt;
    if (!isWaterAt(a.pos.x, a.pos.y - 0.25, a.pos.z))           a.vel.y += 7 * dt;
    a.vel.y += (a.vy - a.vel.y) * Math.min(1, 3 * dt);
  }

  a.vel.x *= (1 - Math.min(1, 0.9 * dt));
  a.vel.z *= (1 - Math.min(1, 0.9 * dt));
  a.vel.y = clamp(a.vel.y, -1.6, 1.6);

  moveWithCollision(a, dt);

  if (a.hitWall){
    a.yaw += Math.PI * randRange(0.5, 1.3);
    a.timer = Math.max(a.timer, 1.0);
  }

  a.inWater = isWaterAt(a.pos.x, a.pos.y + a.height * 0.5, a.pos.z);
  if (a.inWater) a.dry = 0;
  else {
    a.dry += dt;
    if (a.dry > 6){ removeAnimal(a); return; }
  }
  if (a.pos.y < Y_MIN - 2){ removeAnimal(a); return; }
}

/* ============================================================
   内置 5 种实体注册
   ============================================================ */
registerEntity('cow', {
  label: '牛',
  build: buildCow,
  health: 7.5,
  width: 0.75, height: 1.30, depth: 1.50,
  speed: 1.15,
  aquatic: false,
  spawnKind: 'land',
  category: 'land_herbivore',
  spawnWeight: 30,
  loot(){ return [{ name: 'raw_beef', min: 1, max: 3 }]; },
});

registerEntity('sheep', {
  label: '羊',
  build: buildSheep,
  health: 5,
  width: 0.85, height: 1.30, depth: 1.40,
  speed: 1.05,
  aquatic: false,
  spawnKind: 'land',
  category: 'land_herbivore',
  spawnWeight: 35,
  loot(){
    return [
      { name: 'raw_mutton', min: 1, max: 2 },
      { name: 'wool',       min: 1, max: 1 },
    ];
  },
});

registerEntity('pig', {
  label: '猪',
  build: buildPig,
  health: 6,
  width: 0.70, height: 1.05, depth: 1.15,
  speed: 1.0,
  aquatic: false,
  spawnKind: 'land',
  category: 'land_herbivore',
  spawnWeight: 25,
  loot(){ return [{ name: 'raw_pork', min: 1, max: 2 }]; },
});

registerEntity('chicken', {
  label: '鸡',
  build: buildChicken,
  health: 3,
  width: 0.40, height: 0.70, depth: 0.70,
  speed: 1.25,
  aquatic: false,
  spawnKind: 'land',
  category: 'land_herbivore',
  spawnWeight: 35,
  loot(){ return [{ name: 'raw_chicken', min: 1, max: 1 }]; },
});

registerEntity('fish', {
  label: '鱼',
  build: buildFish,
  health: 3,
  width: 0.30, height: 0.40, depth: 0.62,
  speed: 1.35,
  aquatic: true,
  spawnKind: 'water',
  category: 'water',
  spawnWeight: 1,
  loot(){ return [{ name: 'raw_fish', min: 1, max: 1 }]; },
});

/* ============================================================
   创建 / 移除
   ============================================================ */
function createAnimal(type, x, y, z){
  const cfg = getEntityType(type);
  if (!cfg){
    console.warn(`[entity] 未知类型: ${type}`);
    return null;
  }

  let built;
  try {
    built = cfg.build();
  } catch(e){
    console.error(`[entity] "${type}".build 抛错:`, e);
    return null;
  }
  if (!built || !built.group){
    console.error(`[entity] "${type}".build 未返回 { group }`);
    return null;
  }

  const a = {
    type,
    label: cfg.label,
    category: cfg.category || 'other',
    persistent: !!cfg.persistent,

    group: built.group,
    parts: built.parts || {},
    meshes: [],

    pos: new THREE.Vector3(x, y, z),
    vel: new THREE.Vector3(),

    health: cfg.health,
    maxHealth: cfg.health,

    width: cfg.width,
    height: cfg.height,
    depth: cfg.depth,

    onGround: false,
    inWater: false,
    hitWall: false,

    yaw: Math.random() * Math.PI * 2,
    state: 'idle',
    timer: randRange(0.5, 3),

    walkPhase: Math.random() * 6.28,
    bobPhase: Math.random() * 6.28,
    age: 0,
    hurt: 0,
    hurtFlashOn: false,
    dead: false,
    dry: 0,
    vy: randRange(-0.4, 0.4),

    dormant: false,
    _tickAcc: 0,

    _cfg: cfg,
    data: {},
    flying:  cfg.flying,
    aquatic: cfg.aquatic,
  };

  built.group.traverse(o => {
    if (o.isMesh){
      o.userData.baseMat = o.material;
      a.meshes.push(o);
    }
  });

  built.group.position.copy(a.pos);
  built.group.rotation.y = a.yaw;
  scene.add(built.group);

  if (cfg.onSpawn){
    try { cfg.onSpawn(a); }
    catch(e){ console.error(`[entity] "${type}".onSpawn 抛错:`, e); }
  }

  emit('animal.spawn', a);
  return a;
}

function removeAnimal(a, index){
  if (!a || a.dead) return;
  a.dead = true;
  scene.remove(a.group);
  a.meshes.length = 0;
  const i = (index === undefined) ? animals.indexOf(a) : index;
  if (i >= 0) animals.splice(i, 1);
}

function setHurtFlash(a, on){
  if (a.hurtFlashOn === on) return;
  a.hurtFlashOn = on;
  for (const m of a.meshes) m.material = on ? MAT.hurt : m.userData.baseMat;
}

/* ============================================================
   掉落
   ============================================================ */
function dropAnimalLoot(a){
  const cfg = a._cfg || getEntityType(a.type);
  if (!cfg || typeof cfg.loot !== 'function') return;
  const bx = Math.floor(a.pos.x);
  const by = Math.floor(a.pos.y + a.height * 0.5);
  const bz = Math.floor(a.pos.z);
  for (const entry of cfg.loot()){
    const id = itemId(entry.name);
    if (id === null) continue;
    const count = randInt(entry.min, entry.max);
    if (count <= 0) continue;
    spawnDrop(bx + 0.5, by + 0.5, bz + 0.5, id, count);
  }
}

/* ============================================================
   生成：地表 / 水柱
   ============================================================ */
const LAND_SURFACE = { grass: 1, dirt: 1, sand: 1, snow: 1 };

function findLandSpawn(playerPos, origin = playerPos, radius = SPAWN_RADIUS){
  const ox = origin.x, oz = origin.z;
  for (let i = 0; i < 24; i++){
    const ang = Math.random() * Math.PI * 2;
    /* 点在区块内均匀散开；离玩家 24 格内由下面的 MIN_SPAWN_D 过滤 */
    const r = randRange(0, Math.max(1, radius));
    const x = Math.floor(ox + Math.cos(ang) * r);
    const z = Math.floor(oz + Math.sin(ang) * r);

    const h = Math.floor(heightAt(x, z));
    if (h <= SEA_LEVEL) continue;

    const surf = blockAt(x, h, z);
    if (!surf || !surf.solid) continue;
    if (!LAND_SURFACE[surf.name]) continue;
    if (isSolidWorld(x, h + 1, z) || isSolidWorld(x, h + 2, z)) continue;
    if (isLiquidAt(x, h + 1, z) || isLiquidAt(x, h + 2, z)) continue;

    const y = h + 1;
    if (collideAnimalAt(x + 0.5, y, z + 0.5, 1.0, 2.0)) continue;
    if (Math.hypot(x + 0.5 - playerPos.x, z + 0.5 - playerPos.z) < MIN_SPAWN_D) continue;

    return { x: x + 0.5, y, z: z + 0.5 };
  }
  return null;
}

function findFishSpawn(playerPos, origin = playerPos, radius = SPAWN_RADIUS){
  const ox = origin.x, oz = origin.z;
  for (let i = 0; i < 24; i++){
    const ang = Math.random() * Math.PI * 2;
    const r = randRange(0, Math.max(1, radius));
    const x = Math.floor(ox + Math.cos(ang) * r);
    const z = Math.floor(oz + Math.sin(ang) * r);

    for (let d = 1; d <= 5; d++){
      const y = SEA_LEVEL - d;
      if (!isWaterAt(x, y, z)) continue;
      if (!isWaterAt(x, y + 1, z)) continue;
      if (isSolidWorld(x, y, z) || isSolidWorld(x, y + 1, z)) continue;
      if (Math.hypot(x + 0.5 - playerPos.x, z + 0.5 - playerPos.z) < MIN_SPAWN_D) continue;
      return { x: x + 0.5, y: y + 0.1, z: z + 0.5 };
    }
  }
  return null;
}

function pickWeightedType(kind){
  const list = getSpawnableTypes(kind);
  if (!list.length) return null;
  let total = 0;
  for (const t of list) total += Math.max(0, t.spawnWeight);
  if (total <= 0) return list[0].id;
  let r = Math.random() * total;
  for (const t of list){
    r -= Math.max(0, t.spawnWeight);
    if (r <= 0) return t.id;
  }
  return list[list.length - 1].id;
}

/* ★ A 修复：排除 dormant */
function _countByCategory(){
  const counts = new Map();
  for (const a of animals){
    if (a.dormant) continue;
    const cat = a.category || 'other';
    counts.set(cat, (counts.get(cat) || 0) + 1);
  }
  return counts;
}

function _countByType(typeId){
  let n = 0;
  for (const a of animals) if (a.type === typeId) n++;
  return n;
}

function getEntityCounts(){
  const out = {};
  for (const a of animals){
    if (a.dormant) continue;
    const cat = a.category || 'other';
    out[cat] = (out[cat] || 0) + 1;
  }
  return out;
}

function getEntityCountByType(typeId){
  return _countByType(typeId);
}

let lastSpawnAttempt = -1e9;
let _lastPlayerPos = null;
const MAX_POP_RADIUS = 9;   // 实体最多铺到玩家周围 9 区块（模拟距离再大也不铺更远）
const _populatedChunks = new Set();

/* 实体铺开范围跟随「模拟距离」，而不是固定 3×3：
   视距 2 → 只铺身边；视距 8 → 铺到约 7 个区块；视距 32 → 最多 9 个区块。
   再远本来就会休眠/剔除，铺过去既看不到也白算。 */
function _popRadiusChunks(){
  return clamp(getSimDistanceBlocks() - 1, 1, MAX_POP_RADIUS);
}

/* 区块级的确定性随机：同一区块每次判定结果一致，营地/鱼群不会忽有忽无 */
function _chunkRoll(cx, cz, salt){
  let h = Math.imul(cx, 73856093) ^ Math.imul(cz, 19349663) ^ Math.imul(salt, 83492791);
  h ^= h >>> 13;
  h = Math.imul(h, 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/* 不是每个区块都该有兽群：按群系树木密度给出「有兽群」的概率，避免均匀铺满 */
function _herdChance(x, z){
  let density = 0;
  try {
    const b = getBiome(biomeAt(x, z, SEA_LEVEL));
    if (b) density = Math.max(0, Number(b.treeDensity) || 0);
  } catch(e){}
  return Math.min(0.20, 0.08 + density * 1.2);
}

/* 找到离玩家最近、还没有做过"初次成批生成"的区块 */
function _findNearestUnpopulatedChunk(playerPos){
  const pcx = Math.floor(playerPos.x / CS);
  const pcz = Math.floor(playerPos.z / CS);
  const R = _popRadiusChunks();
  let best = null, bestD = Infinity;

  for (const c of chunks.values()){
    if (!c || !c.ready || !c.blocks) continue;
    const dx = c.cx - pcx, dz = c.cz - pcz;
    if (dx * dx + dz * dz > R * R) continue;

    const k = chunkKey(c.cx, c.cz);
    if (_populatedChunks.has(k)) continue;

    const d = dx * dx + dz * dz;
    if (d < bestD){ bestD = d; best = c; }
  }
  return best;
}

/* 按群系树木密度决定这一群的大小，树林里更容易遇到成群的动物 */
function _herdSizeAt(x, z){
  let density = 0;
  try {
    const b = getBiome(biomeAt(x, z, SEA_LEVEL));
    if (b) density = Math.max(0, Number(b.treeDensity) || 0);
  } catch(e){}
  return clamp(1 + Math.round(Math.min(2, density * 25)) + randInt(0, 1), 1, 3);
}

/* 在一个区块内成批生成：陆地一群 + 水里一小群鱼（都不是每个区块都有） */
function spawnChunkBatch(chunk, playerPos){
  _populatedChunks.add(chunkKey(chunk.cx, chunk.cz));

  const counts = _countByCategory();
  const origin = { x: chunk.cx * CS + CS * 0.5, z: chunk.cz * CS + CS * 0.5 };
  const radius = CS * 0.85;

  const R = _popRadiusChunks();
  const herdP = R <= 1 ? 1 : _herdChance(origin.x, origin.z);
  const fishP = R <= 1 ? 0.5 : 0.10;

  /* ---- 陆地：一整群一起出现 ---- */
  if (_chunkRoll(chunk.cx, chunk.cz, 1) < herdP){
    const herd = _herdSizeAt(origin.x, origin.z);
    for (let i = 0; i < herd; i++){
      const typeId = pickWeightedType('land');
      if (!typeId) break;

      const cfg = getEntityType(typeId);
      const cat = (cfg && cfg.category) || 'other';
      const cap = _entityCaps.get(cat) || 0;
      const cur = counts.get(cat) || 0;
      if (cur >= cap) break;
      if (cfg && cfg.spawnCap !== null && _countByType(typeId) >= cfg.spawnCap) continue;

      const spot = findLandSpawn(playerPos, origin, radius);
      if (!spot) break;

      const a = createAnimal(typeId, spot.x, spot.y, spot.z);
      if (!a) continue;
      animals.push(a);
      counts.set(cat, cur + 1);
    }
  }

  /* ---- 水生：一小群鱼 ---- */
  if (_chunkRoll(chunk.cx, chunk.cz, 2) < fishP){
    const school = 1 + randInt(0, 1);
    for (let i = 0; i < school; i++){
      const typeId = pickWeightedType('water');
      if (!typeId) break;

      const cfg = getEntityType(typeId);
      const cat = (cfg && cfg.category) || 'other';
      const cap = _entityCaps.get(cat) || 0;
      const cur = counts.get(cat) || 0;
      if (cur >= cap) break;
      if (cfg && cfg.spawnCap !== null && _countByType(typeId) >= cfg.spawnCap) continue;

      const spot = findFishSpawn(playerPos, origin, radius);
      if (!spot) break;

      const a = createAnimal(typeId, spot.x, spot.y, spot.z);
      if (!a) continue;
      animals.push(a);
      counts.set(cat, cur + 1);
    }
  }
}

/* 每个区块只在第一次进入玩家附近时成批生成一次；之后不再原地补满。
   这里只做兜底（例如区块先在远处加载、玩家后来才走近）。 */
function spawnAnimalsAround(playerPos){
  if (!playerPos) return;

  const now = (typeof performance !== 'undefined' && performance.now)
    ? performance.now() : Date.now();
  if (now - lastSpawnAttempt < SPAWN_COOLDOWN) return;
  lastSpawnAttempt = now;

  const R = _popRadiusChunks();
  const n = R <= 1 ? 4 : Math.min(12, R * 2);
  for (let i = 0; i < n; i++){
    const chunk = _findNearestUnpopulatedChunk(playerPos);
    if (!chunk) break;
    spawnChunkBatch(chunk, playerPos);
  }
}

/* 区块首次加载完成时，若在玩家的实体范围内，立刻成批生成（一次性） */
on('chunk.decorate', (chunk) => {
  try {
    if (!chunk || !_lastPlayerPos) return;
    const pcx = Math.floor(_lastPlayerPos.x / CS);
    const pcz = Math.floor(_lastPlayerPos.z / CS);
    const R = _popRadiusChunks();
    const dx = chunk.cx - pcx, dz = chunk.cz - pcz;
    if (dx * dx + dz * dz > R * R) return;
    const k = chunkKey(chunk.cx, chunk.cz);
    if (_populatedChunks.has(k)) return;
    spawnChunkBatch(chunk, _lastPlayerPos);
  } catch(e){ /* 生成失败不影响区块加载 */ }
});

function clearAnimals(){
  for (const a of animals){
    a.dead = true;
    a.meshes.length = 0;
    scene.remove(a.group);
  }
  animals.length = 0;
  _populatedChunks.clear();
}

/* ============================================================
   spawn / 移除（mod 用）
   ============================================================ */
function spawnEntity(type, x, y, z){
  const a = createAnimal(type, +x, +y, +z);
  if (a) animals.push(a);
  return a;
}

function removeEntity(a){
  if (!a || a.dead) return false;
  removeAnimal(a);
  return true;
}

/* 修改某种实体类型的掉落：函数或 [{name,min,max,chance}] 数组；null = 不掉落 */
function setEntityLoot(typeId, loot){
  const t = getEntityType(typeId);
  if (!t) return false;
  if (typeof loot === 'function'){
    t.loot = loot;
    return true;
  }
  if (Array.isArray(loot)){
    t.loot = () => loot;
    return true;
  }
  if (loot == null){
    t.loot = () => [];
    return true;
  }
  return false;
}

/* ============================================================
   桶相关
   ============================================================ */
function captureFish(a){
  if (!a || a.dead) return false;
  if (a.type !== 'fish') return false;
  removeAnimal(a);
  return true;
}

function spawnFishAt(x, y, z){
  const a = createAnimal('fish', x, y, z);
  if (a) animals.push(a);
  return a;
}

/* ============================================================
   伤害与死亡
   ============================================================ */
function damageAnimal(a, amount, source){
  if (!a || a.dead) return;
  const dmg = Number(amount);
  if (!isFinite(dmg) || dmg <= 0) return;

  const cfg = a._cfg || getEntityType(a.type);

  /* ★ 可取消：mod 在 entity.damage:before 里 return true 即可免疫这次伤害
     （放在扣血之前，所以取消时血量、击退、死亡结算都不会发生） */
  if (emitCancellable('entity.damage:before', a, dmg, source || null)) return;

  a.health -= dmg;
  a.hurt = 0.26;
  setHurtFlash(a, true);

  if (cfg && cfg.onDamage){
    try { cfg.onDamage(a, dmg, source || null); }
    catch(e){ console.error(`[entity] "${a.type}".onDamage 抛错:`, e); }
  }

  const backX = Math.sin(a.yaw), backZ = Math.cos(a.yaw);
  const k = a.aquatic ? 1.2 : 3.6;
  a.vel.x += backX * k;
  a.vel.z += backZ * k;
  if (!a.aquatic) a.vel.y = Math.max(a.vel.y, 3.2);

  emit('animal.damage', a, dmg, source || null);

  if (a.health <= 0){
    a.health = 0;
    dropAnimalLoot(a);

    if (cfg && cfg.onDeath){
      try { cfg.onDeath(a); }
      catch(e){ console.error(`[entity] "${a.type}".onDeath 抛错:`, e); }
    }

    emit('animal.death', a);
    removeAnimal(a);
  }
}

const damageEntity = damageAnimal;

/* ============================================================
   射线检测
   ============================================================ */
function rayBoxT(ox, oy, oz, dx, dy, dz, minx, miny, minz, maxx, maxy, maxz){
  let t0 = 0, t1 = Infinity;
  let inv, ta, tb, tmp;

  if (Math.abs(dx) < 1e-8){
    if (ox < minx || ox > maxx) return -1;
  } else {
    inv = 1 / dx;
    ta = (minx - ox) * inv; tb = (maxx - ox) * inv;
    if (ta > tb){ tmp = ta; ta = tb; tb = tmp; }
    if (ta > t0) t0 = ta;
    if (tb < t1) t1 = tb;
    if (t0 > t1) return -1;
  }
  if (Math.abs(dy) < 1e-8){
    if (oy < miny || oy > maxy) return -1;
  } else {
    inv = 1 / dy;
    ta = (miny - oy) * inv; tb = (maxy - oy) * inv;
    if (ta > tb){ tmp = ta; ta = tb; tb = tmp; }
    if (ta > t0) t0 = ta;
    if (tb < t1) t1 = tb;
    if (t0 > t1) return -1;
  }
  if (Math.abs(dz) < 1e-8){
    if (oz < minz || oz > maxz) return -1;
  } else {
    inv = 1 / dz;
    ta = (minz - oz) * inv; tb = (maxz - oz) * inv;
    if (ta > tb){ tmp = ta; ta = tb; tb = tmp; }
    if (ta > t0) t0 = ta;
    if (tb < t1) t1 = tb;
    if (t0 > t1) return -1;
  }
  return t0;
}

function getAnimalAt(origin, dir, maxDist, hitInfo){
  if (!origin || !dir || !animals.length) return null;

  let dx = dir.x, dy = dir.y, dz = dir.z;
  const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
  if (!isFinite(len) || len < 1e-8) return null;
  dx /= len; dy /= len; dz /= len;

  const range = (typeof maxDist === 'number' && isFinite(maxDist) && maxDist > 0) ? maxDist : 6;
  const pad = 0.05;

  let best = null, bestT = Infinity;
  for (const a of animals){
    if (a.dead || a.dormant) continue;
    const hw = a.width * 0.5 + pad;
    const hd = a.depth * 0.5 + pad;
    const minx = a.pos.x - hw, maxx = a.pos.x + hw;
    const miny = a.pos.y - pad, maxy = a.pos.y + a.height + pad;
    const minz = a.pos.z - hd, maxz = a.pos.z + hd;

    const t = rayBoxT(origin.x, origin.y, origin.z, dx, dy, dz,
                      minx, miny, minz, maxx, maxy, maxz);
    if (t < 0 || t > range) continue;
    if (t < bestT){ bestT = t; best = a; }
  }
  if (best && hitInfo) hitInfo.t = bestT;
  return best;
}

const getEntityAt = getAnimalAt;

/* ============================================================
   动画
   ============================================================ */
function animateAnimal(a, dt, moving){
  const p = a.parts;

  if (a.aquatic){
    const t = a.age;
    if (p.tail) p.tail.rotation.y = Math.sin(t * 9) * 0.45;
    if (p.body) p.body.rotation.x = Math.sin(t * 3.1) * 0.06;
    a.group.position.set(a.pos.x, a.pos.y + Math.sin(t * 2.2) * 0.02, a.pos.z);
    a.group.rotation.y = a.yaw;
    return;
  }

  const speed = Math.hypot(a.vel.x, a.vel.z);
  const legs = p.legs || [];

  if (moving){
    a.walkPhase += dt * (3.2 + speed * 2.6);
    const swing = Math.sin(a.walkPhase) * 0.55;
    for (const leg of legs) leg.rotation.x = swing * (leg.userData.swing || 1);
  } else {
    const back = Math.max(0, 1 - 8 * dt);
    for (const leg of legs) leg.rotation.x *= back;
  }

  a.bobPhase += dt * (moving ? 7.0 : 1.8);
  const bob = moving ? Math.sin(a.bobPhase) * 0.03 : Math.sin(a.bobPhase) * 0.018;
  a.group.position.set(a.pos.x, a.pos.y + bob, a.pos.z);
  a.group.rotation.y = a.yaw;

  if (p.head) p.head.rotation.z = Math.sin(a.age * 1.3) * 0.04;
}

/* ============================================================
   每帧更新
   ============================================================ */
let autoSpawnTimer = 0;

function updateAnimals(dt, playerPos){
  const step = clamp(Number(dt) || 0, 0, 0.05);
  if (playerPos) _lastPlayerPos = playerPos;

  if (playerPos){
    autoSpawnTimer += step;
    if (autoSpawnTimer >= AUTO_SPAWN_INTERVAL){
      autoSpawnTimer = 0;
      spawnAnimalsAround(playerPos);
    }
  }

  /* ★ B1 修复：定期清理超远 dormant */
  if (playerPos){
    _purgeTimer += step;
    if (_purgeTimer > PURGE_INTERVAL){
      _purgeTimer = 0;
      for (let i = animals.length - 1; i >= 0; i--){
        const a = animals[i];
        if (!a || a.dead) continue;
        if (!a.dormant) continue;
        if (a.persistent) continue;
        const dx = a.pos.x - playerPos.x;
        const dz = a.pos.z - playerPos.z;
        if (dx * dx + dz * dz > PURGE_DIST_SQ){
          removeAnimal(a, i);
        }
      }
    }
  }

  for (let i = animals.length - 1; i >= 0; i--){
    const a = animals[i];
    if (!a || a.dead){ animals.splice(i, 1); continue; }

    let d2 = 0;
    if (playerPos){
      const dx = a.pos.x - playerPos.x;
      const dy = a.pos.y - playerPos.y;
      const dz = a.pos.z - playerPos.z;
      d2 = dx * dx + dy * dy + dz * dz;
    }

    if (a.dormant){
      if (!playerPos || d2 > RESUME_D2) continue;
      a.dormant = false;
      a._tickAcc = 0;
      scene.add(a.group);
      a.group.position.copy(a.pos);
      a.group.rotation.y = a.yaw;
    } else if (playerPos && d2 > CULL_D2){
      if (!a.persistent) {
        a.dormant = true;
        scene.remove(a.group);
        continue;
      }
    }

    /* 距离分级 tick */
    const interval = _tickIntervalFor(d2);
    if (interval < 0){
      a.age += step;
      const moving = Math.hypot(a.vel.x, a.vel.z) > 0.12;
      animateAnimal(a, step, moving);
      continue;
    }

    if (interval > 1){
      a._tickAcc = (a._tickAcc || 0) + 1;
      if (a._tickAcc < interval){
        const moving = Math.hypot(a.vel.x, a.vel.z) > 0.12;
        animateAnimal(a, step, moving);
        continue;
      }
      a._tickAcc = 0;
    }

    const aiDt = Math.min(step * interval, 0.1);

    a.age += aiDt;

    if (a.hurt > 0){
      a.hurt -= aiDt;
      if (a.hurt <= 0){ a.hurt = 0; setHurtFlash(a, false); }
    }

    const cfg = a._cfg || getEntityType(a.type);
    if (cfg && cfg.update){
      try {
        emit('entity.update:before', a, aiDt);
        cfg.update(a, aiDt, playerPos, worldApi);
        emit('entity.update:after', a, aiDt);
        /* 成功一次就把连续失败计数清零：偶发错误不该累计成停用 */
        if (_aiFails.size) _aiFails.delete(a.type);
      } catch(e){
        const n = (_aiFails.get(a.type) || 0) + 1;
        _aiFails.set(a.type, n);
        console.error(`[entity] "${a.type}".update 抛错（连续 ${n}/${AI_FAIL_LIMIT}）:`, e);
        if (n >= AI_FAIL_LIMIT){
          cfg.update = null;
          _aiDead.add(a.type);
          console.error(`[entity] "${a.type}" 的 update 连续失败 ${AI_FAIL_LIMIT} 次，已停用该类型 AI`);
        }
      }
    } else if (a.aquatic){
      updateFish(a, aiDt, playerPos, worldApi);
    } else {
      updateLandAnimal(a, aiDt, playerPos, worldApi);
    }

    if (a.dead) continue;

    const moving = Math.hypot(a.vel.x, a.vel.z) > 0.12;
    animateAnimal(a, step, moving);
  }
}

/* ============================================================
   存档
   ============================================================ */
function serializeAnimals(){
  const out = [];
  for (const a of animals){
    if (!a || a.dead) continue;
    out.push({
      type:   a.type,
      x:      a.pos.x,
      y:      a.pos.y,
      z:      a.pos.z,
      yaw:    a.yaw,
      health: a.health,
      vy:     a.vy,
      state:  a.state,
      timer:  a.timer,
      age:    a.age,
      data:   a.data && Object.keys(a.data).length ? a.data : undefined,
    });
  }
  return out;
}

function deserializeAnimals(data){
  clearAnimals();
  if (!Array.isArray(data)) return;

  for (const rec of data){
    if (!rec || !hasEntityType(rec.type)) continue;
    const x = Number(rec.x), y = Number(rec.y), z = Number(rec.z);
    if (!isFinite(x) || !isFinite(y) || !isFinite(z)) continue;

    const a = createAnimal(rec.type, x, y, z);
    if (!a) continue;

    if (typeof rec.yaw    === 'number' && isFinite(rec.yaw))    a.yaw    = rec.yaw;
    if (typeof rec.health === 'number' && isFinite(rec.health)) a.health = Math.min(a.maxHealth, Math.max(0, rec.health));
    if (typeof rec.vy     === 'number' && isFinite(rec.vy))     a.vy     = rec.vy;
    if (rec.state === 'walk' || rec.state === 'idle')           a.state  = rec.state;
    if (typeof rec.timer  === 'number' && isFinite(rec.timer))  a.timer  = rec.timer;
    if (typeof rec.age    === 'number' && isFinite(rec.age))    a.age    = rec.age;
    if (rec.data && typeof rec.data === 'object')               a.data   = rec.data;

    a.group.position.copy(a.pos);
    a.group.rotation.y = a.yaw;

    animals.push(a);
  }
}

/* ============================================================
   re-export
   ============================================================ */

/* =================================================================
   re-export
   ================================================================= */
export {
  registerEntity, getEntityType, hasEntityType, listEntityTypes, getAllEntityTypes, getEntityTypeCount, getSpawnableTypes, getTypesByCategory, getAnimalCount, getDormantCount, animals, setEntityCap, getEntityCap, listEntityCaps, setEntityCapScale, setTickDistances, getTickDistances, setSimDistance, getSimDistanceBlocks, listDisabledEntityAi, getWorldApi, getEntityCounts, getEntityCountByType, spawnAnimalsAround, clearAnimals, spawnEntity, removeEntity, setEntityLoot, captureFish, spawnFishAt, damageAnimal, damageEntity, getAnimalAt, getEntityAt, updateAnimals, serializeAnimals, deserializeAnimals
};
