/* ============================================================
   hostile.js —— 敌对生物（8 种）+ 夜间刷怪 + 投射物
   ------------------------------------------------------------
   注册到 entities-core 的类型：
     zombie          普通僵尸（怕阳光）
     drowned         溺尸（水边，怕阳光）
     husk            尸壳（沙漠，不怕光）
     vampire         吸血鬼（可变蝙蝠，怕阳光）
     mutant_flower   变异食人花（3 级，怕光）
     golem_ancient   远古故障石人（远程投石，可用魔法水晶修复）
     golem_guard     远古守卫（修复后跟随玩家）
     lava_bubble     岩浆泡（岩浆里跳出来喷火球）
     wraith          厉鬼（物理免疫，见光消失）

   刷怪由 updateHostileMobs() 统一调度，main.js 每帧调用一次。
   ============================================================ */

import * as THREE from 'three';

import {
  registerEntity, spawnEntity, removeEntity, animals,
  damageAnimal,
} from './entities-core.js';
import { player, damage } from '../player/player-core.js';
import { registerStatusEffect, applyStatus } from '../player/status-effects.js';
import { on, emit, Y_MIN } from '../core/engine-core.js';
import { BLOCKS } from '../world/blocks.js';
import {
  getBlockWorld, heightAt, biomeAt,
  getSkyLightAt, getBlockLightAt,
} from '../world/terrain.js';
import { getBiome } from '../world/world-core.js';
import { getDayFactor } from '../render/sky.js';
import { getActiveDimensionId, getDimension } from '../world/world-registry.js';
import { inventory, takeFromSlot } from '../items/items-core.js';
import { getDaysAwake, tickDayCycle, setDaysAwake } from '../player/bed.js';
import { playSFX } from '../audio/audio.js';
import { scene } from '../render/render-core.js';

/* ============================================================
   基础工具
   ============================================================ */
const BOX = new THREE.BoxGeometry(1, 1, 1);

function M(color, extra){
  const o = { color };
  if (extra) Object.assign(o, extra);
  return new THREE.MeshLambertMaterial(o);
}

function B(m, w, h, d, x, y, z){
  const mesh = new THREE.Mesh(BOX, m);
  mesh.scale.set(w, h, d);
  mesh.position.set(x, y, z);
  return mesh;
}

function blockNameAt(x, y, z){
  const id = getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z));
  const b = BLOCKS[id];
  return b ? b.name : 'air';
}

function isSolidAt(x, y, z){
  const id = getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z));
  const b = BLOCKS[id];
  return !!(b && b.solid && !b.liquid);
}

/** 有效光照：方块光，或白天的天光 */
function lightAt(x, y, z){
  const blk = getBlockLightAt(x, y, z);
  const sky = getSkyLightAt(x, y, z);
  const day = getDayFactor();
  return Math.max(blk, Math.round(sky * day));
}

function inSunlight(a){
  if (getDayFactor() < 0.55) return false;
  return getSkyLightAt(a.pos.x, a.pos.y + a.height * 0.9, a.pos.z) >= 12;
}

function faceTo(a, x, z){
  a.yaw = Math.atan2(-(x - a.pos.x), -(z - a.pos.z));
}

/** 朝目标水平移动；被挡住就跳一下（flying = 不加重力） */
function chase(a, dt, target, world, speed, stopDist, flying){
  const dx = target.x - a.pos.x;
  const dz = target.z - a.pos.z;
  const d = Math.hypot(dx, dz) || 1;
  if (d > stopDist){
    const k = Math.min(1, 7 * dt);
    a.vel.x += (dx / d * speed - a.vel.x) * k;
    a.vel.z += (dz / d * speed - a.vel.z) * k;
  } else {
    const k = Math.max(0, 1 - 9 * dt);
    a.vel.x *= k;
    a.vel.z *= k;
  }
  faceTo(a, target.x, target.z);
  if (!flying){
    if (a.onGround && a.hitWall) a.vel.y = world.stepJump;
    a.vel.y -= world.gravity * dt;
  }
  world.moveWithCollision(a, dt);
}

/** 原地游荡（没发现玩家时） */
function wander(a, dt, world){
  a.data.wt = (a.data.wt || 0) - dt;
  if (a.data.wt <= 0){
    a.data.wt = 2 + Math.random() * 4;
    a.yaw = Math.random() * Math.PI * 2;
    a.data.walking = Math.random() < 0.6;
  }
  const sp = a.data.walking ? 0.55 : 0;
  const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw);
  const k = Math.min(1, 5 * dt);
  a.vel.x += (fx * sp - a.vel.x) * k;
  a.vel.z += (fz * sp - a.vel.z) * k;
  if (a.onGround && a.hitWall) a.vel.y = world.stepJump;
  a.vel.y -= world.gravity * dt;
  world.moveWithCollision(a, dt);
}

function melee(a, dt, target, dmg, reach){
  a.data.atkCd = Math.max(0, (a.data.atkCd || 0) - dt);
  const dx = target.x - a.pos.x;
  const dz = target.z - a.pos.z;
  const dy = target.y - a.pos.y;
  if (a.data.atkCd > 0) return false;
  if (Math.hypot(dx, dz) > reach || Math.abs(dy) > 2.2) return false;
  a.data.atkCd = 1.0;
  damage(dmg);
  playSFX('hurt');
  return true;
}

function distToPlayer(a){
  const dx = player.pos.x - a.pos.x;
  const dy = player.pos.y - a.pos.y;
  const dz = player.pos.z - a.pos.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/* ============================================================
   感知：怪物不是全知。
   · 只有看见玩家（视线不被实心方块挡住），或玩家贴到很近，才会追
   · 脱离视线后靠记忆再追几秒（追最后位置），超时回到游荡
   ============================================================ */
const AGGRO_MEMORY = 7;   // 失去视线后仍追的秒数
const AGGRO_CLOSE  = 7;   // 这个距离内不看视线也能察觉

function canSeePlayer(a, maxD){
  const ax = a.pos.x, ay = a.pos.y + (a.height || 1.8) * 0.85, az = a.pos.z;
  const dx = player.pos.x - ax;
  const dy = (player.pos.y + 1.5) - ay;
  const dz = player.pos.z - az;
  const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
  if (d > maxD) return false;
  /* 步进采样做视线判定（方块世界够用，比真射线便宜） */
  const steps = Math.min(40, Math.max(2, Math.ceil(d / 0.5)));
  for (let i = 1; i < steps; i++){
    const t = i / steps;
    if (isSolidAt(ax + dx * t, ay + dy * t, az + dz * t)) return false;
  }
  return true;
}

function perceives(a, dt, playerPos, range){
  if (!a || a.dead || !playerPos) return false;
  if (!a.data) a.data = {};
  a.data.aggroT = Math.max(0, (a.data.aggroT || 0) - dt);
  const d = distToPlayer(a);
  if (d <= AGGRO_CLOSE){
    a.data.aggroT = AGGRO_MEMORY;
    return true;
  }
  if (a.data.aggroT > 0) return true;
  if (d > range) return false;
  if (canSeePlayer(a, range)){
    a.data.aggroT = AGGRO_MEMORY;
    return true;
  }
  return false;
}

/** 阳光灼烧：每 0.7 秒掉 2 点，死亡直接移除（不掉战利品） */
function sunBurn(a, dt){
  a.data.sunT = (a.data.sunT || 0) + dt;
  if (a.data.sunT < 0.7) return;
  a.data.sunT = 0;
  a.health -= 2;
  a.hurt = 0.2;
  if (a.health <= 0) removeEntity(a);
}

/* ============================================================
   模型：通用人形
   ============================================================ */
function humanoid(o){
  const g = new THREE.Group();
  const skin  = M(o.skin);
  const cloth = M(o.cloth);
  const pants = M(o.pants !== undefined ? o.pants : o.cloth);
  const legs = [], arms = [];

  for (const sx of [-0.13, 0.13]){
    const p = new THREE.Group();
    p.position.set(sx, 0.72, 0);
    p.add(B(pants, 0.22, 0.72, 0.24, 0, -0.36, 0));
    g.add(p); legs.push(p);
  }

  g.add(B(cloth, 0.5, 0.62, 0.27, 0, 1.03, 0));

  const head = new THREE.Group();
  head.position.set(0, 1.55, 0);
  head.add(B(skin, 0.42, 0.42, 0.42, 0, 0, 0));
  if (o.eye !== undefined){
    const em = M(o.eye, o.eyeGlow ? { emissive: o.eye, emissiveIntensity: 1 } : undefined);
    head.add(B(em, 0.07, 0.05, 0.03, -0.09, 0.04, -0.216));
    head.add(B(em, 0.07, 0.05, 0.03,  0.09, 0.04, -0.216));
  }
  g.add(head);

  for (const sx of [-0.32, 0.32]){
    const p = new THREE.Group();
    p.position.set(sx, 1.28, 0);
    p.add(B(cloth, 0.16, 0.6, 0.18, 0, -0.28, 0));
    g.add(p); arms.push(p);
  }

  return { group: g, parts: { legs, arms, head } };
}

/* ============================================================
   僵尸 / 溺尸 / 尸壳
   ============================================================ */
function buildZombie(o){
  const r = humanoid(o);
  for (const arm of r.parts.arms) arm.rotation.x = -1.35;
  return r;
}

registerEntity('zombie', {
  label: '僵尸', category: 'land_predator',
  health: 10, width: 0.6, height: 1.8, speed: 1.5,
  build: () => buildZombie({ skin: 0x5b8f4a, cloth: 0x2f5f8f, pants: 0x2a3f6a, eye: 0x1a1a1a }),
  onSpawn(a){
    /* 25% 概率穿一整套铁甲：更硬一点 */
    if (Math.random() >= 0.25) return;
    a.data.armored = true;
    a.health += 5;
    a.maxHealth = a.health;
    const am = M(0x9aa3ad);
    a.parts.head.add(B(am, 0.46, 0.2, 0.46, 0, 0.16, 0));
    a.group.add(B(am, 0.54, 0.28, 0.31, 0, 1.15, 0));
    a.group.add(B(am, 0.54, 0.2, 0.31, 0, 0.8, 0));
  },
  update(a, dt, playerPos, world){
    if (inSunlight(a)) sunBurn(a, dt);
    if (perceives(a, dt, playerPos, 28)){
      chase(a, dt, playerPos, world, 1.55, 1.15);
      melee(a, dt, playerPos, 3, 1.7);
    } else {
      wander(a, dt, world);
    }
  },
  loot: () => [{ name: 'string', min: 0, max: 1 }],
});

registerEntity('drowned', {
  label: '溺尸', category: 'land_predator',
  health: 10, width: 0.6, height: 1.8, speed: 1.45,
  build: () => buildZombie({ skin: 0x5f9a95, cloth: 0x2f6f6a, pants: 0x234a4a, eye: 0x0a3a3a }),
  update(a, dt, playerPos, world){
    if (inSunlight(a)) sunBurn(a, dt);
    const inWater = blockNameAt(a.pos.x, a.pos.y + 0.4, a.pos.z) === 'water';
    const sp = inWater ? 2.1 : 1.25;
    if (perceives(a, dt, playerPos, 26)){
      chase(a, dt, playerPos, world, sp, 1.15);
      melee(a, dt, playerPos, 3, 1.7);
    } else {
      wander(a, dt, world);
    }
  },
  loot: () => [{ name: 'string', min: 0, max: 1 }],
});

registerEntity('husk', {
  label: '尸壳', category: 'land_predator',
  health: 12, width: 0.6, height: 1.8, speed: 1.4,
  build: () => buildZombie({ skin: 0xc9b489, cloth: 0xa89468, pants: 0x8a7752, eye: 0x2a2418 }),
  update(a, dt, playerPos, world){
    if (perceives(a, dt, playerPos, 28)){
      chase(a, dt, playerPos, world, 1.45, 1.15);
      melee(a, dt, playerPos, 4, 1.7);
    } else {
      wander(a, dt, world);
    }
  },
  loot: () => [{ name: 'string', min: 0, max: 1 }],
});

/* ============================================================
   吸血鬼：人形 ↔ 蝙蝠
   ============================================================ */
registerEntity('vampire', {
  label: '吸血鬼', category: 'land_predator',
  health: 14, width: 0.6, height: 1.8, speed: 1.9,
  build(){
    const r = humanoid({ skin: 0xd8cfd0, cloth: 0x2a2230, pants: 0x1a1620, eye: 0xc02030, eyeGlow: true });
    const wingMat = M(0x241a2a);
    const wings = new THREE.Group();
    const l = B(wingMat, 0.06, 0.5, 0.8, -0.34, 1.15, 0.18);
    l.rotation.z = 0.5;
    const rr = B(wingMat, 0.06, 0.5, 0.8, 0.34, 1.15, 0.18);
    rr.rotation.z = -0.5;
    wings.add(l, rr);
    wings.visible = false;
    r.group.add(wings);
    r.parts.wings = wings;
    r.parts.body = r.group;
    return r;
  },
  onSpawn(a){
    a.data.form = 'human';
    a.data.formT = 5;
  },
  update(a, dt, playerPos, world){
    if (inSunlight(a)) sunBurn(a, dt);
    if (a.dead) return;

    const d = playerPos ? distToPlayer(a) : 99;
    a.data.formT -= dt;

    /* 变身判定 */
    if (a.data.form === 'human' && (a.data.formT <= 0 || d > 9)){
      a.data.form = 'bat';
      a.data.formT = 4.5;
      a.parts.wings.visible = true;
      a.group.scale.setScalar(0.62);
      a.height = 1.2; a.width = 0.4;
    } else if (a.data.form === 'bat' && a.data.formT <= 0){
      a.data.form = 'human';
      a.data.formT = 6 + Math.random() * 4;
      a.parts.wings.visible = false;
      a.group.scale.setScalar(1);
      a.height = 1.8; a.width = 0.6;
    }

    const sees = perceives(a, dt, playerPos, 30);
    if (a.data.form === 'bat'){
      /* 蝙蝠形态：发现玩家后飞向头顶 */
      a.data.flyT = (a.data.flyT || 0) + dt;
      if (playerPos && sees){
        const targetY = playerPos.y + 1.4 + Math.sin(a.age * 3) * 0.35;
        const k = Math.min(1, 3 * dt);
        a.vel.y += ((targetY - a.pos.y) * 2.2 - a.vel.y) * k;
        chase(a, dt, playerPos, world, 2.6, 2.2, true);
      } else {
        a.vel.y = Math.sin(a.age * 3) * 0.4;
        world.moveWithCollision(a, dt);
      }
      if (playerPos && sees) melee(a, dt, playerPos, 2, 2.4);
    } else {
      if (sees){
        chase(a, dt, playerPos, world, 1.9, 1.2);
        melee(a, dt, playerPos, 4, 1.8);
      } else {
        wander(a, dt, world);
      }
    }
  },
  loot: () => [{ name: 'magic_dust', min: 0, max: 1 }],
});

/* ============================================================
   变异食人花（三级）
   ============================================================ */
const FLOWER_TIERS = [
  { petals: 0x8a4fd0, core: 0x3a1a55, hp: 8,  dmg: 2, speed: 0.85 },
  { petals: 0x6a2fae, core: 0x2a0f45, hp: 14, dmg: 3, speed: 1.0 },
  { petals: 0x4a1080, core: 0x1a0528, hp: 22, dmg: 5, speed: 1.15 },
];

registerEntity('mutant_flower', {
  label: '变异食人花', category: 'land_predator',
  health: 8, width: 0.7, height: 1.5, speed: 0.9,
  build(){
    const g = new THREE.Group();
    const stemMat = M(0x3f6b2a);
    g.add(B(stemMat, 0.16, 1.0, 0.16, 0, 0.5, 0));
    g.add(B(stemMat, 0.5, 0.06, 0.22, -0.2, 0.55, 0));
    g.add(B(stemMat, 0.5, 0.06, 0.22, 0.2, 0.62, 0));

    const head = new THREE.Group();
    head.position.set(0, 1.12, 0);
    const petals = [];
    for (let i = 0; i < 6; i++){
      const ang = i / 6 * Math.PI * 2;
      const m = M(0x8a4fd0);
      const p = B(m, 0.34, 0.1, 0.3, Math.cos(ang) * 0.28, 0.1, Math.sin(ang) * 0.28);
      p.rotation.y = -ang;
      p.rotation.z = 0.35;
      head.add(p); petals.push(p);
    }
    const core = B(M(0x3a1a55), 0.3, 0.16, 0.3, 0, 0.08, 0);
    const eye = M(0xe8d44a, { emissive: 0xe8d44a, emissiveIntensity: 0.8 });
    head.add(core, B(eye, 0.07, 0.06, 0.03, -0.08, 0.12, -0.16), B(eye, 0.07, 0.06, 0.03, 0.08, 0.12, -0.16));
    g.add(head);

    return { group: g, parts: { head, petals, core } };
  },
  onSpawn(a){
    const r = Math.random();
    const tier = r < 0.6 ? 0 : (r < 0.9 ? 1 : 2);
    const t = FLOWER_TIERS[tier];
    a.data.tier = tier;
    a.health = t.hp;
    a.maxHealth = t.hp;
    for (const p of a.parts.petals) p.material.color.setHex(t.petals);
    a.parts.core.material.color.setHex(t.core);
    a.group.scale.setScalar(1 + tier * 0.12);
  },
  update(a, dt, playerPos, world){
    const t = FLOWER_TIERS[a.data.tier || 0];
    /* 怕光：光照 >= 8 持续灼烧 */
    if (lightAt(a.pos.x, a.pos.y + a.height * 0.8, a.pos.z) >= 8){
      a.data.lightT = (a.data.lightT || 0) + dt;
      if (a.data.lightT >= 0.7){
        a.data.lightT = 0;
        a.health -= 4;
        a.hurt = 0.2;
        if (a.health <= 0){ removeEntity(a); return; }
      }
    } else {
      a.data.lightT = 0;
    }

    if (perceives(a, dt, playerPos, 22)){
      chase(a, dt, playerPos, world, t.speed, 1.3);
      melee(a, dt, playerPos, t.dmg, 1.9);
    } else {
      wander(a, dt, world);
    }
    /* 花头随呼吸摆动 */
    if (a.parts.head) a.parts.head.rotation.x = Math.sin(a.age * 2) * 0.12;
  },
  loot: () => [{ name: 'magic_dust', min: 0, max: 2 }],
});

/* ============================================================
   远古故障石人 / 远古守卫
   ============================================================ */
function buildGolem(o){
  const g = new THREE.Group();
  const body = M(o.body), dark = M(o.dark);
  g.add(B(body, 0.9, 0.8, 0.6, 0, 1.15, 0));
  g.add(B(body, 0.56, 0.5, 0.5, 0, 1.75, 0));
  const legs = [];
  for (const sx of [-0.22, 0.22]){
    const p = new THREE.Group();
    p.position.set(sx, 0.75, 0);
    p.add(B(dark, 0.3, 0.75, 0.32, 0, -0.37, 0));
    g.add(p); legs.push(p);
  }
  const arms = [];
  for (const sx of [-0.62, 0.62]){
    const p = new THREE.Group();
    p.position.set(sx, 1.45, 0);
    p.add(B(body, 0.26, 0.85, 0.28, 0, -0.4, 0));
    g.add(p); arms.push(p);
  }
  /* 裂纹 / 核心 */
  g.add(B(dark, 0.08, 0.5, 0.02, -0.18, 1.2, -0.31));
  g.add(B(dark, 0.06, 0.3, 0.02, 0.14, 1.05, -0.31));
  const eye = M(o.eye, { emissive: o.eye, emissiveIntensity: 1 });
  g.add(B(eye, 0.12, 0.08, 0.04, -0.12, 1.8, -0.26));
  g.add(B(eye, 0.12, 0.08, 0.04, 0.12, 1.8, -0.26));
  if (o.gem){
    const gem = M(o.gem, { emissive: o.gem, emissiveIntensity: 0.9 });
    g.add(B(gem, 0.26, 0.26, 0.08, 0, 1.3, -0.32));
  }
  return { group: g, parts: { legs, arms } };
}

registerEntity('golem_ancient', {
  label: '远古故障石人', category: 'land_predator',
  health: 15, width: 0.9, height: 2.1, speed: 0.75,
  build: () => buildGolem({ body: 0x6d7076, dark: 0x3a3d42, eye: 0xd03020 }),
  onSpawn(a){ a.data.cool = 2.2; },
  update(a, dt, playerPos, world){
    if (!playerPos) return;
    const d = distToPlayer(a);
    if (!perceives(a, dt, playerPos, 34)){ wander(a, dt, world); return; }

    if (d < 2.4){
      chase(a, dt, playerPos, world, 0.6, 1.4);
      melee(a, dt, playerPos, 5, 2.1);
      return;
    }
    /* 中距离：停下投石 */
    faceTo(a, playerPos.x, playerPos.z);
    a.vel.x *= Math.max(0, 1 - 6 * dt);
    a.vel.z *= Math.max(0, 1 - 6 * dt);
    a.vel.y -= world.gravity * dt;
    world.moveWithCollision(a, dt);

    a.data.cool -= dt;
    if (a.data.cool <= 0 && d < 20){
      a.data.cool = 2.8;
      throwRock(a, playerPos);
    }
  },
  loot: () => [{ name: 'magic_crystal', min: 0, max: 1 }],
});

registerEntity('golem_guard', {
  label: '远古守卫', category: 'other', persistent: true,
  health: 20, width: 0.9, height: 2.1, speed: 1.3,
  build: () => buildGolem({ body: 0xb9c6cc, dark: 0x5d6f78, eye: 0x4fe0ff, gem: 0x40e0ff }),
  onSpawn(a){ a.data.cool = 0; a.data.home = a.pos.clone(); },
  update(a, dt, playerPos, world){
    /* 找最近的敌对生物 */
    let target = null, best = 12 * 12;
    for (const o of animals){
      if (!o || o.dead || o === a) continue;
      if (o.category !== 'land_predator') continue;
      if (o.type === 'golem_guard') continue;
      const dx = o.pos.x - a.pos.x, dz = o.pos.z - a.pos.z;
      const d2 = dx * dx + dz * dz;
      if (d2 < best){ best = d2; target = o; }
    }

    if (target){
      const dx = target.pos.x - a.pos.x, dz = target.pos.z - a.pos.z;
      const d = Math.hypot(dx, dz) || 1;
      chase(a, dt, target.pos, world, 1.5, 1.5);
      a.data.cool = Math.max(0, (a.data.cool || 0) - dt);
      if (d < 2.2 && a.data.cool <= 0){
        a.data.cool = 1.1;
        damageAnimal(target, 7);
        playSFX('dig.stone');
      }
      return;
    }

    if (playerPos){
      const d = distToPlayer(a);
      if (d > 5){
        chase(a, dt, playerPos, world, d > 12 ? 2.0 : 1.2, 3.5);
      } else {
        a.vel.x *= Math.max(0, 1 - 6 * dt);
        a.vel.z *= Math.max(0, 1 - 6 * dt);
        a.vel.y -= world.gravity * dt;
        world.moveWithCollision(a, dt);
        faceTo(a, playerPos.x, playerPos.z);
      }
    }
  },
  loot: () => [{ name: 'magic_crystal', min: 1, max: 1 }],
});

/* ============================================================
   故障守卫（失落古城 Boss，石头材质）
   ============================================================ */
function buildRuinGuardian(){
  const g = new THREE.Group();
  const stone = M(0x7c8188);
  const dark  = M(0x4a4f55);
  const moss  = M(0x537446);
  const coreMat = M(0x35e0ff, { emissive: 0x18b8e0, emissiveIntensity: 0.9 });
  const eyeMat  = M(0xff3a22, { emissive: 0xff2410, emissiveIntensity: 1.2 });

  const legs = [];
  for (const sx of [-0.5, 0.5]){
    const p = new THREE.Group();
    p.position.set(sx, 1.55, 0);
    p.add(B(dark, 0.5, 1.55, 0.62, 0, -0.77, 0));
    g.add(p); legs.push(p);
  }

  g.add(B(stone, 1.8, 1.5, 1.05, 0, 2.3, 0));
  g.add(B(dark, 2.1, 0.35, 1.12, 0, 3.0, 0));
  g.add(B(stone, 0.85, 0.7, 0.8, 0, 3.45, 0));

  const arms = [];
  for (const sx of [-1.0, 1.0]){
    const p = new THREE.Group();
    p.position.set(sx, 2.9, 0);
    p.add(B(dark, 0.46, 1.5, 0.5, 0, -0.7, 0));
    p.add(B(stone, 0.54, 0.5, 0.58, 0, -1.45, 0));
    g.add(p); arms.push(p);
  }

  /* 苔藓与裂纹 */
  g.add(B(moss, 0.7, 0.12, 1.08, -0.4, 3.2, 0));
  g.add(B(moss, 0.5, 0.10, 0.5, 0.55, 1.72, 0.5));
  g.add(B(dark, 0.08, 1.0, 0.02, -0.35, 2.4, -0.54));
  g.add(B(dark, 0.06, 0.5, 0.02, 0.42, 2.1, -0.54));

  /* 发光核心与双眼 */
  g.add(B(coreMat, 0.42, 0.42, 0.06, 0, 2.45, -0.55));
  g.add(B(eyeMat, 0.16, 0.10, 0.04, -0.20, 3.50, -0.42));
  g.add(B(eyeMat, 0.16, 0.10, 0.04, 0.20, 3.50, -0.42));

  return { group: g, parts: { legs, arms, coreMat, eyeMat } };
}

registerEntity('ruin_guardian', {
  label: '故障守卫', category: 'other', persistent: true,
  health: 150, width: 2.0, height: 3.6, speed: 0.9,
  build: buildRuinGuardian,
  onSpawn(a){
    a.data.state = 'idle';
    a.data.t = 0;
    a.data.chargeCd = 6;
    a.data.rockCd = 3;
    a.data.quakeCd = 9;
    a.data.walkPhase = 0;
    a.data.home = { x: a.pos.x, y: a.pos.y, z: a.pos.z };
  },
  onDeath(a){
    emit('lostcity.boss.death', { x: a.pos.x, z: a.pos.z });
  },
  update(a, dt, playerPos, world){
    if (!playerPos) return;
    const st = a.data;
    st.t += dt;

    /* 行走动画 */
    const sp = Math.hypot(a.vel.x, a.vel.z);
    st.walkPhase += dt * (1.6 + sp * 2.0);
    const sw = Math.sin(st.walkPhase) * (0.12 + sp * 0.12);
    if (a.parts.legs){
      a.parts.legs[0].rotation.x = sw;
      a.parts.legs[1].rotation.x = -sw;
    }
    if (a.parts.arms){
      const quakeLift = st.state === 'quake' ? -1.4 : 0;
      a.parts.arms[0].rotation.x = -sw * 0.8 + quakeLift;
      a.parts.arms[1].rotation.x = sw * 0.8 + quakeLift;
    }
    if (a.parts.coreMat){
      a.parts.coreMat.emissiveIntensity = 0.6 + Math.sin(st.t * 3.2) * 0.25;
    }

    const d = distToPlayer(a);

    /* 离得太远：慢慢回到广场 */
    if (d > 46){
      if (st.state !== 'idle'){
        st.state = 'idle';
        st.chargeHit = false;
      }
      chase(a, dt, st.home, world, 0.7, 2.5);
      return;
    }

    st.chargeCd -= dt;
    st.rockCd -= dt;
    st.quakeCd -= dt;

    if (st.state === 'telegraph'){
      st.stateT -= dt;
      faceTo(a, playerPos.x, playerPos.z);
      a.vel.x *= Math.max(0, 1 - 8 * dt);
      a.vel.z *= Math.max(0, 1 - 8 * dt);
      a.vel.y -= world.gravity * dt;
      world.moveWithCollision(a, dt);
      if (st.stateT <= 0){
        st.state = 'charge';
        st.stateT = 0.8;
        const dx = playerPos.x - a.pos.x, dz = playerPos.z - a.pos.z;
        const len = Math.hypot(dx, dz) || 1;
        st.dirX = dx / len;
        st.dirZ = dz / len;
        st.chargeHit = false;
      }
      return;
    }

    if (st.state === 'charge'){
      st.stateT -= dt;
      a.vel.x = st.dirX * 5.6;
      a.vel.z = st.dirZ * 5.6;
      a.vel.y -= world.gravity * dt;
      world.moveWithCollision(a, dt);
      if (!st.chargeHit && d < 2.9){
        st.chargeHit = true;
        damage(12);
        player.vel.x += st.dirX * 7;
        player.vel.z += st.dirZ * 7;
        player.vel.y = Math.max(player.vel.y, 4.5);
        playSFX('hurt');
      }
      if (st.stateT <= 0){
        st.state = 'idle';
        st.chargeHit = false;
        st.chargeCd = 7 + Math.random() * 3;
      }
      return;
    }

    if (st.state === 'quake'){
      st.stateT -= dt;
      a.vel.x *= Math.max(0, 1 - 8 * dt);
      a.vel.z *= Math.max(0, 1 - 8 * dt);
      a.vel.y -= world.gravity * dt;
      world.moveWithCollision(a, dt);
      if (st.stateT <= 0) st.state = 'idle';
      return;
    }

    /* 地震：近身范围伤害 + 镜头震动 */
    if (d < 10 && st.quakeCd <= 0 && a.onGround){
      st.quakeCd = 9 + Math.random() * 4;
      st.state = 'quake';
      st.stateT = 0.55;
      faceTo(a, playerPos.x, playerPos.z);
      emit('world.quake', 1.0);
      playSFX('dig.stone');
      if (d < 9){
        damage(7);
        player.vel.y = Math.max(player.vel.y, 5.2);
      }
      return;
    }

    /* 冲撞：中距离蓄力后直线冲击 */
    if (d >= 6 && d < 22 && st.chargeCd <= 0){
      st.state = 'telegraph';
      st.stateT = 0.7;
      a.vel.x *= 0.5;
      a.vel.z *= 0.5;
      a.vel.y -= world.gravity * dt;
      world.moveWithCollision(a, dt);
      emit('world.quake', 0.35);
      return;
    }

    /* 投大型石块 */
    if (d >= 8 && d < 30 && st.rockCd <= 0){
      st.rockCd = 4.5 + Math.random() * 2;
      faceTo(a, playerPos.x, playerPos.z);
      throwBoulder(a, playerPos);
      return;
    }

    if (d > 3){
      chase(a, dt, playerPos, world, 1.0, 2.7);
    } else {
      faceTo(a, playerPos.x, playerPos.z);
      melee(a, dt, playerPos, 11, 3.2);
    }
  },
  loot: () => [],
});

/* ============================================================
   岩浆泡
   ============================================================ */
registerEntity('lava_bubble', {
  label: '岩浆泡', category: 'other',
  health: 8, width: 0.8, height: 0.8, speed: 0.5,
  build(){
    const g = new THREE.Group();
    const mat = M(0xd84a10, { emissive: 0x8a2200, emissiveIntensity: 0.9 });
    const core = M(0xffb020, { emissive: 0xff7a00, emissiveIntensity: 1.2 });
    g.add(B(mat, 0.7, 0.5, 0.7, 0, 0.3, 0));
    g.add(B(core, 0.4, 0.3, 0.4, 0, 0.34, 0));
    g.add(B(mat, 0.24, 0.18, 0.24, -0.28, 0.52, 0.16));
    g.add(B(mat, 0.18, 0.14, 0.18, 0.26, 0.55, -0.12));
    return { group: g, parts: {} };
  },
  onSpawn(a){ a.data.cool = 1.5; },
  update(a, dt, playerPos, world){
    const inLava = blockNameAt(a.pos.x, a.pos.y + 0.2, a.pos.z) === 'lava';

    if (perceives(a, dt, playerPos, 16)){
      faceTo(a, playerPos.x, playerPos.z);
      /* 玩家靠近 → 跳出岩浆 */
      if (inLava && a.data.hop !== false){
        a.vel.y = 5.5;
        a.data.hop = false;
        a.data.hopT = 2.5;
      }
      a.data.cool -= dt;
      if (a.data.cool <= 0){
        a.data.cool = 2.6;
        throwFireball(a, playerPos);
      }
    }
    if (a.data.hop === false){
      a.data.hopT -= dt;
      if (a.data.hopT <= 0) a.data.hop = true;
    }

    if (!inLava) a.vel.y -= world.gravity * dt;
    else a.vel.y = Math.max(a.vel.y, -0.4);
    world.moveWithCollision(a, dt);
  },
  loot: () => [{ name: 'magic_dust', min: 0, max: 1 }],
});

/* ============================================================
   厉鬼：物理免疫，见光消失
   ============================================================ */
registerEntity('wraith', {
  label: '厉鬼', category: 'flying',
  health: 24, width: 0.7, height: 1.9, speed: 1.4, flying: true,
  build(){
    const g = new THREE.Group();
    const robe = M(0x151018, { transparent: true, opacity: 0.82 });
    const pale = M(0xcfd8dd);
    g.add(B(robe, 0.66, 1.25, 0.42, 0, 1.05, 0));
    const hood = new THREE.Group();
    hood.position.set(0, 1.85, 0);
    hood.add(B(robe, 0.56, 0.5, 0.46, 0, 0, 0));
    hood.add(B(pale, 0.34, 0.3, 0.05, 0, -0.02, -0.23));
    const eye = M(0x8adfff, { emissive: 0x8adfff, emissiveIntensity: 1 });
    hood.add(B(eye, 0.06, 0.05, 0.03, -0.08, 0.02, -0.26));
    hood.add(B(eye, 0.06, 0.05, 0.03, 0.08, 0.02, -0.26));
    g.add(hood);
    g.add(B(robe, 0.2, 0.55, 0.2, -0.34, 1.1, 0));
    g.add(B(robe, 0.2, 0.55, 0.2, 0.34, 1.1, 0));
    return { group: g, parts: { head: hood } };
  },
  update(a, dt, playerPos, world){
    /* 见光立刻消散 */
    if (lightAt(a.pos.x, a.pos.y + a.height * 0.8, a.pos.z) >= 3){
      removeEntity(a);
      return;
    }
    if (!playerPos) return;
    if (perceives(a, dt, playerPos, 24)){
      const targetY = playerPos.y + 1.2;
      const k = Math.min(1, 2.5 * dt);
      a.vel.y += ((targetY - a.pos.y) * 2.0 - a.vel.y) * k;
      chase(a, dt, playerPos, world, 1.5, 1.5, true);
      melee(a, dt, playerPos, 4, 2.2);
    } else {
      a.vel.y = Math.sin(a.age * 1.7) * 0.25;
      world.moveWithCollision(a, dt);
    }
    if (a.parts.head) a.parts.head.rotation.z = Math.sin(a.age * 1.9) * 0.08;
  },
  loot: () => [{ name: 'magic_dust', min: 0, max: 1 }],
});

/* 物理攻击免疫（见光消失由 AI 处理） */
on('entity.damage:before', (a, dmg, source) => {
  if (a && a.type === 'wraith' && source !== 'light') return true;
});

/* ============================================================
   投射物：石块 / 火球
   ============================================================ */
const projectiles = [];

function throwRock(a, target){
  const from = new THREE.Vector3(a.pos.x, a.pos.y + 1.75, a.pos.z);
  const to = new THREE.Vector3(target.x, target.y + 0.9, target.z);
  makeProjectile('rock', from, to, 14, 4);
  playSFX('arrow.hit');
}

/* 故障守卫：大型石块 */
function throwBoulder(a, target){
  const from = new THREE.Vector3(a.pos.x, a.pos.y + 2.9, a.pos.z);
  const to = new THREE.Vector3(target.x, target.y + 0.9, target.z);
  makeProjectile('boulder', from, to, 13, 10);
  playSFX('arrow.hit');
}

function throwFireball(a, target){
  const from = new THREE.Vector3(a.pos.x, a.pos.y + 0.5, a.pos.z);
  const to = new THREE.Vector3(target.x, target.y + 0.9, target.z);
  makeProjectile('fireball', from, to, 11, 3);
  playSFX('lava.sizzle');
}

function makeProjectile(kind, from, to, speed, dmg){
  let geo;
  if (kind === 'fireball') geo = new THREE.SphereGeometry(0.17, 8, 6);
  else if (kind === 'boulder') geo = new THREE.DodecahedronGeometry(0.5, 0);
  else geo = new THREE.BoxGeometry(0.22, 0.22, 0.22);

  const mat = kind === 'fireball'
    ? new THREE.MeshBasicMaterial({ color: 0xff8a20 })
    : new THREE.MeshLambertMaterial({ color: kind === 'boulder' ? 0x70757c : 0x7a7a7a });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.copy(from);

  const dir = to.clone().sub(from).normalize();
  const vel = dir.multiplyScalar(speed);
  vel.y += kind === 'fireball' ? 1.2 : (kind === 'boulder' ? 2.8 : 2.2);

  scene.add(mesh);
  projectiles.push({
    kind, mesh, dmg,
    pos: from.clone(),
    vel,
    life: 5,
    gravity: kind === 'fireball' ? 9 : (kind === 'boulder' ? 16 : 18),
  });
}

function removeProjectile(i){
  const p = projectiles[i];
  if (!p) return;
  scene.remove(p.mesh);
  if (p.kind === 'fireball' || p.kind === 'boulder') p.mesh.geometry.dispose();
  projectiles.splice(i, 1);
}

function updateProjectiles(dt){
  const pcx = player.pos.x, pcy = player.pos.y + 0.9, pcz = player.pos.z;
  for (let i = projectiles.length - 1; i >= 0; i--){
    const p = projectiles[i];
    p.life -= dt;
    if (p.life <= 0){ removeProjectile(i); continue; }

    p.vel.y -= p.gravity * dt;
    p.pos.addScaledVector(p.vel, dt);

    /* 撞方块 */
    const id = getBlockWorld(Math.floor(p.pos.x), Math.floor(p.pos.y), Math.floor(p.pos.z));
    const blk = BLOCKS[id];
    if (blk && blk.solid && !blk.liquid){
      removeProjectile(i);
      continue;
    }

    /* 撞玩家 */
    const dx = p.pos.x - pcx, dy = p.pos.y - pcy, dz = p.pos.z - pcz;
    if (dx * dx + dy * dy + dz * dz < 0.75 * 0.75){
      damage(p.dmg);
      if (p.kind === 'fireball') applyStatus('burning', 5);
      playSFX('hurt');
      removeProjectile(i);
      continue;
    }

    p.mesh.position.copy(p.pos);
  }
}

/* 燃烧状态：每秒 1 点伤害 */
registerStatusEffect('burning', {
  name: '燃烧',
  duration: 5,
  tickInterval: 1,
  onTick(){ damage(1); },
});

/* ============================================================
   刷怪
   ============================================================ */
const HOSTILE_TYPES = new Set([
  'zombie', 'drowned', 'husk', 'vampire', 'mutant_flower',
  'golem_ancient', 'lava_bubble', 'wraith', 'golem_guard',
]);

const TYPE_CAPS = {
  zombie: 6, drowned: 4, husk: 4, vampire: 3,
  mutant_flower: 3, golem_ancient: 2, lava_bubble: 3, wraith: 2,
};

const MAX_HOSTILES = 12;
const SPAWN_INTERVAL = 2.0;

let _spawnTimer = 0;

function countHostiles(){
  let n = 0;
  for (const a of animals){
    if (!a || a.dead) continue;
    if (a.type === 'golem_guard') continue;
    if (HOSTILE_TYPES.has(a.type)) n++;
  }
  return n;
}
function countType(t){
  let n = 0;
  for (const a of animals) if (a && !a.dead && a.type === t) n++;
  return n;
}

function isHellDimension(){
  /* 本作没有独立下界维度，"地心世界"是 Y_MIN 上方的深层岩浆带 */
  if (player.pos.y <= Y_MIN + 40) return true;
  const id = getActiveDimensionId();
  let name = '';
  try { const d = getDimension(id); name = (d && d.name) || ''; } catch(e){}
  return /nether|lava|magma|core|hell|地心/i.test(id + ' ' + name);
}

/** 地表随机点（heightAt 返回最顶层实心方块 y，脚站在 h+1） */
function findSurfaceSpot(playerPos){
  for (let i = 0; i < 8; i++){
    const ang = Math.random() * Math.PI * 2;
    const r = 24 + Math.random() * 24;      // 24~48 格：MC 式"看不见的地方生成"
    const x = Math.floor(playerPos.x + Math.cos(ang) * r);
    const z = Math.floor(playerPos.z + Math.sin(ang) * r);
    const h = Math.floor(heightAt(x, z));
    if (h <= -60 || h >= 380) continue;
    /* h 是地面方块，上面两格必须是空的 */
    if (!isSolidAt(x, h, z)) continue;
    if (isSolidAt(x, h + 1, z) || isSolidAt(x, h + 2, z)) continue;
    const ground = blockNameAt(x, h, z);
    if (ground === 'water' || ground === 'lava') continue;
    return { x: x + 0.5, y: h + 1, z: z + 0.5 };
  }
  return null;
}

/** 水面随机点（溺尸用）：水面下是实心河床 */
function findWaterSpot(playerPos){
  for (let i = 0; i < 10; i++){
    const ang = Math.random() * Math.PI * 2;
    const r = 24 + Math.random() * 24;
    const x = Math.floor(playerPos.x + Math.cos(ang) * r);
    const z = Math.floor(playerPos.z + Math.sin(ang) * r);
    const h = Math.floor(heightAt(x, z));
    if (h <= -60 || h >= 380) continue;
    if (!isSolidAt(x, h, z)) continue;
    if (blockNameAt(x, h + 1, z) !== 'water') continue;
    return { x: x + 0.5, y: h + 1, z: z + 0.5 };
  }
  return null;
}

/** 地下随机点（洞穴） */
function findCaveSpot(playerPos){
  for (let i = 0; i < 12; i++){
    const ang = Math.random() * Math.PI * 2;
    const r = 20 + Math.random() * 20;
    const x = Math.floor(playerPos.x + Math.cos(ang) * r);
    const z = Math.floor(playerPos.z + Math.sin(ang) * r);
    const surf = Math.floor(heightAt(x, z));
    const yMin = Math.max(-56, surf - 46);
    const y = yMin + Math.floor(Math.random() * Math.max(1, surf - yMin - 6));
    if (!isSolidAt(x, y - 1, z)) continue;
    if (isSolidAt(x, y, z) || isSolidAt(x, y + 1, z)) continue;
    if (lightAt(x, y, z) > 7) continue;
    /* 3D 距离也拉远，避免在眼前的矿洞里凭空出现 */
    const dx = x + 0.5 - playerPos.x, dy = y - playerPos.y, dz = z + 0.5 - playerPos.z;
    if (Math.sqrt(dx * dx + dy * dy + dz * dz) < 18) continue;
    return { x: x + 0.5, y, z: z + 0.5 };
  }
  return null;
}

/** 玩家附近有没有岩浆（岩浆泡用）：先按玩家所在高度扫，再退回地表 */
function nearLava(playerPos){
  for (let i = 0; i < 14; i++){
    const x = Math.floor(playerPos.x + (Math.random() - 0.5) * 24);
    const z = Math.floor(playerPos.z + (Math.random() - 0.5) * 24);
    const y0 = Math.floor(playerPos.y + (Math.random() - 0.5) * 12);
    for (let y = y0 + 2; y >= y0 - 6; y--){
      if (blockNameAt(x, y, z) === 'lava') return { x: x + 0.5, y, z: z + 0.5 };
    }
  }
  for (let i = 0; i < 8; i++){
    const x = Math.floor(playerPos.x + (Math.random() - 0.5) * 24);
    const z = Math.floor(playerPos.z + (Math.random() - 0.5) * 24);
    const surf = Math.floor(heightAt(x, z));
    for (let y = surf + 1; y > Math.max(-60, surf - 24); y--){
      const n = blockNameAt(x, y, z);
      if (n === 'lava') return { x: x + 0.5, y, z: z + 0.5 };
      if (n !== 'air' && n !== 'water') break;
    }
  }
  return null;
}

function pickWeighted(list){
  let total = 0;
  for (const e of list) total += e.w;
  if (total <= 0) return null;
  let r = Math.random() * total;
  for (const e of list){ r -= e.w; if (r <= 0) return e.type; }
  return list[list.length - 1].type;
}

function trySpawnHostile(playerPos){
  if (countHostiles() >= MAX_HOSTILES) return;
  const night = getDayFactor() < 0.35;
  const sun = getDayFactor() > 0.55;
  const hell = isHellDimension();

  /* 岩浆泡：岩浆里生成；地心世界必刷，其他维度小概率 */
  if (countType('lava_bubble') < TYPE_CAPS.lava_bubble && (hell || Math.random() < 0.35)){
    const spot = nearLava(playerPos);
    if (spot){
      spawnEntity('lava_bubble', spot.x, spot.y, spot.z);
      return;
    }
  }

  /* 夜间地表 */
  if (night){
    /* 溺尸：优先找水边 */
    if (countType('drowned') < TYPE_CAPS.drowned && Math.random() < 0.4){
      const ws = findWaterSpot(playerPos);
      if (ws){
        spawnEntity('drowned', ws.x, ws.y, ws.z);
        return;
      }
    }

    const spot = findSurfaceSpot(playerPos);
    if (spot){
      const biomeId = (() => { try { return biomeAt(spot.x, spot.z); } catch(e){ return -1; } })();
      const biomeName = (() => { const b = getBiome(biomeId); return b && b.name; })();

      const list = [];
      if (countType('zombie') < TYPE_CAPS.zombie) list.push({ type: 'zombie', w: 30 });
      if (countType('vampire') < TYPE_CAPS.vampire) list.push({ type: 'vampire', w: 12 });
      if (countType('mutant_flower') < TYPE_CAPS.mutant_flower) list.push({ type: 'mutant_flower', w: 14 });
      if (countType('husk') < TYPE_CAPS.husk && biomeName === 'desert') list.push({ type: 'husk', w: 18 });
      if (getDaysAwake() >= 10 && countType('wraith') < TYPE_CAPS.wraith){
        if (lightAt(spot.x, spot.y, spot.z) < 3) list.push({ type: 'wraith', w: 30 });
      }
      const type = pickWeighted(list);
      if (type){
        spawnEntity(type, spot.x, spot.y, spot.z);
        return;
      }
    }
  }

  /* 石人：洞穴里的古代造物，白天黑夜都可能遇到 */
  if (countType('golem_ancient') < TYPE_CAPS.golem_ancient && Math.random() < 0.3){
    const spot = findCaveSpot(playerPos);
    if (spot){
      spawnEntity('golem_ancient', spot.x, spot.y, spot.z);
      return;
    }
  }

  /* 白天：洞穴里也刷少量僵尸，矿洞才有威胁 */
  if (sun && countType('zombie') < TYPE_CAPS.zombie && Math.random() < 0.25){
    const spot = findCaveSpot(playerPos);
    if (spot) spawnEntity('zombie', spot.x, spot.y, spot.z);
  }
}

/* ============================================================
   主循环入口
   ============================================================ */
export function updateHostileMobs(dt, playerPos){
  const step = Math.max(0, Math.min(0.05, Number(dt) || 0));
  if (!(step > 0)) return;

  tickDayCycle();
  updateProjectiles(step);

  _spawnTimer += step;
  if (_spawnTimer >= SPAWN_INTERVAL){
    _spawnTimer = 0;
    if (playerPos) trySpawnHostile(playerPos);
  }
}

/* ============================================================
   魔法水晶修复石人 → 远古守卫
   ============================================================ */
export function tryRepairGolem(ent, slotIndex){
  if (!ent || ent.type !== 'golem_ancient') return false;
  const s = inventory[slotIndex];
  if (!s) return false;
  const def = BLOCKS[s.id];
  if (!def || def.name !== 'magic_crystal') return false;

  takeFromSlot(slotIndex, 1);
  const px = ent.pos.x, py = ent.pos.y, pz = ent.pos.z;
  removeEntity(ent);
  const g = spawnEntity('golem_guard', px, py, pz);
  if (g){
    g.data.home = g.pos.clone();
    playSFX('pop');
  }
  return true;
}

/* ============================================================
   调试钩子：控制台快速验证
   ------------------------------------------------------------
   __hostile.spawn('wraith', x, y, z)   手动在身边生成
   __hostile.spawnNear('zombie')        在玩家前方生成
   __hostile.setDays(10)                直接满足厉鬼的 10 天条件
   ============================================================ */
if (typeof window !== 'undefined'){
  window.__hostile = {
    spawn(type, x, y, z){ return spawnEntity(type, x, y, z); },
    spawnNear(type, dist = 4){
      const a = (player.yaw || 0);
      return spawnEntity(type,
        player.pos.x - Math.sin(a) * dist,
        player.pos.y,
        player.pos.z - Math.cos(a) * dist);
    },
    setDays(n){ setDaysAwake(n); return getDaysAwake(); },
    list(){ return animals.filter(a => HOSTILE_TYPES.has(a.type)).map(a => a.type); },
  };
}
