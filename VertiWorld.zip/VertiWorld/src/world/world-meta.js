/* ============================================================
   world-meta.js —— 世界层的"注册表 + 小工具"（合并自 3 个小文件）
   ------------------------------------------------------------
   ★ 原来拆成三个文件，加起来才 7KB，合成一个更好找：
       raycast.js             体素射线（准星命中判定）
       river.js               河流噪声 riverValue()
       generator-registry.js  世界生成器注册表（UI 元数据 + 运行时注册）
   biome-registry.js 体积较大（11KB）且被 7 个文件引用，保持独立。
   对外 API 不变，见文末 re-export。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import { BLOCKS } from './blocks.js';
import { fbm } from './../core/runtime.js';
import { getBlockWorld } from './terrain.js';


/* =================================================================
   raycast.js
   ================================================================= */
function raycastVoxel(origin, dir, maxDist, includeLiquid){
  let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
  const stepX = dir.x > 0 ? 1 : -1;
  const stepY = dir.y > 0 ? 1 : -1;
  const stepZ = dir.z > 0 ? 1 : -1;
  const tDeltaX = dir.x === 0 ? Infinity : Math.abs(1 / dir.x);
  const tDeltaY = dir.y === 0 ? Infinity : Math.abs(1 / dir.y);
  const tDeltaZ = dir.z === 0 ? Infinity : Math.abs(1 / dir.z);
  let tMaxX = dir.x === 0 ? Infinity : ((stepX > 0 ? (x + 1 - origin.x) : (origin.x - x)) / Math.abs(dir.x));
  let tMaxY = dir.y === 0 ? Infinity : ((stepY > 0 ? (y + 1 - origin.y) : (origin.y - y)) / Math.abs(dir.y));
  let tMaxZ = dir.z === 0 ? Infinity : ((stepZ > 0 ? (z + 1 - origin.z) : (origin.z - z)) / Math.abs(dir.z));
  let nx = 0, ny = 0, nz = 0;
  let tEnter = 0;

  for (let i = 0; i < 256; i++){
    const bId = getBlockWorld(x, y, z);
    if (bId !== 0){
      const b = BLOCKS[bId];
      /* 可挖/可交互：实体方块 + 薄片（花瓣/睡莲）+ 十字花草（花/草/海草）
         + 可交互方块（拉杆/按钮/门等）
         + 方块模型（压力板/火把/拉杆/按钮等非实心小模型，准星必须能命中）
         手持桶时（includeLiquid=true）也命中液体，让桶能取水/岩浆 */
      if (b.solid || b.flatRender || b.cross || b.interactive || b.model || (includeLiquid && b.liquid))
        return { x, y, z, nx, ny, nz, id: bId, dist: tEnter };
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ){
      if (tMaxX > maxDist) break;
      tEnter = tMaxX;
      x += stepX; tMaxX += tDeltaX; nx = -stepX; ny = 0; nz = 0;
    } else if (tMaxY < tMaxZ){
      if (tMaxY > maxDist) break;
      tEnter = tMaxY;
      y += stepY; tMaxY += tDeltaY; nx = 0; ny = -stepY; nz = 0;
    } else {
      if (tMaxZ > maxDist) break;
      tEnter = tMaxZ;
      z += stepZ; tMaxZ += tDeltaZ; nx = 0; ny = 0; nz = -stepZ;
    }
  }
  return null;
}

/* =================================================================
   river.js
   ================================================================= */
/* ============================================================
   river.js —— 河流噪声
   ------------------------------------------------------------
   只提供 riverValue()：返回 [0, 1] 的"到河心距离"。
     0   = 河心
     1   = 远离河流

   谁在用它：
     · density.js        —— 河床下切
     · world-gen.js      —— RIVER 群系判定

   两者必须用同一个 riverValue 和同一组阈值，否则会出现
   "有河床但没河群系"或"河群系但没水"的错位。

   ★ 本轮改动：
     频率 0.0022 → 0.0040
     波长 455 格 → 250 格，让河道更细、形成网状
   ============================================================ */


function riverValue(wx, wz, seed){
  const n = fbm(wx * 0.0040, wz * 0.0040, 3, seed + 900);
  return Math.abs(n * 2 - 1);
}

/* =================================================================
   generator-registry.js
   ================================================================= */
/* ============================================================
   generator-registry.js —— 世界生成器注册表
   ------------------------------------------------------------
   现在只持有 **UI 元数据**：label / icon / desc / hidden。
   真实地形函数（heightAt / biomeAt）已迁往 world-gen.js，
   这里不再保存也不再转发。

   ★ P3+：hidden 字段用于临时下线开发中的生成器。
   ============================================================ */

const _generators = new Map();
let _activeId = null;

/* ============================================================
   注册
   ============================================================ */
function registerGenerator(id, cfg){
  if (typeof id !== 'string' || !id){
    console.warn('[gen] 非法 id:', id);
    return null;
  }
  if (!cfg || typeof cfg !== 'object'){
    console.warn(`[gen] "${id}" cfg 无效`);
    return null;
  }
  if (_generators.has(id)){
    console.warn(`[gen] "${id}" 已存在，忽略`);
    return _generators.get(id);
  }

  const gen = {
    id,
    label:      cfg.label || id,
    icon:       cfg.icon  || '■',
    desc:       cfg.desc  || '',
    hidden:     !!cfg.hidden,
    heightLimits: cfg.heightLimits || null,
    options: Array.isArray(cfg.options)
      ? cfg.options.filter(o => o && typeof o === 'object' && typeof o.key === 'string')
      : cfg.options,

    /* ★ 自定义地形钩子：mod 可以真正接管生成逻辑 */
    /* ★ Worker 可达的 mod 生成器 URL（完整路径，如 /mods/xxx/worldgen.js）
       提供这个字段 → 该世界类型可以在 Worker 里生成，性能不掉
       不提供 → 走主线程生成（onGenerate / heightAt / biomeAt 等钩子） */
    worldgenUrl: typeof cfg.worldgenUrl === 'string' ? cfg.worldgenUrl : null,
    onGenerate:  typeof cfg.onGenerate  === 'function' ? cfg.onGenerate  : null,
    heightAt:    typeof cfg.heightAt    === 'function' ? cfg.heightAt    : null,
    biomeAt:     typeof cfg.biomeAt     === 'function' ? cfg.biomeAt     : null,
    onDecorate:  typeof cfg.onDecorate  === 'function' ? cfg.onDecorate  : null,
    onChunkGen:  typeof cfg.onChunkGen  === 'function' ? cfg.onChunkGen  : null,
  };

  _generators.set(id, gen);
  console.log(`[gen] 注册生成器: ${id} (${gen.label})${gen.hidden ? ' [隐藏]' : ''}`);
  return gen;
}

/* ============================================================
   ★ 被 mod「声明」但还没加载的世界类型
   ------------------------------------------------------------
   mod 只有进了世界才会被加载，而世界类型是在【创建世界时】选的 ——
   所以创建界面需要一份提前知道的清单，来源是 /api/mods 里各 mod
   manifest.json 的 worldTypes 字段（纯静态声明，不执行任何 mod 代码）。

   这些条目先落在这里：
     · ui/menu.js  用来渲染类型列表、并把选项交给创建界面
     · terrain.js  用来判断"这个类型不是不存在，只是还没加载"
     · main.js     用来在没有运行时 options 时兜底取声明里的 options

   查询顺序永远是【先 _generators（运行时注册，最准）再 _declared】。
   ============================================================ */
const _declared = new Map();

function declareWorldType(id, info){
  if (typeof id !== 'string' || !id) return null;
  const rec = Object.assign({ id }, info || {});
  _declared.set(id, rec);
  return rec;
}

function getDeclaredWorldType(id){
  return _declared.get(id) || null;
}

function listDeclaredWorldTypes(){
  return Array.from(_declared.values());
}

function clearDeclaredWorldTypes(){
  _declared.clear();
}

/* ============================================================
   查询
   ============================================================ */
function getGenerator(id){
  return _generators.get(id) || null;
}

function getActiveGenerator(){
  return _activeId ? (_generators.get(_activeId) || null) : null;
}

function getActiveGeneratorId(){
  return _activeId;
}

function hasGenerator(id){
  return _generators.has(id);
}

/* ============================================================
   切换
   ============================================================ */
function setActiveGenerator(id){
  if (!id){
    _activeId = null;
    return true;
  }
  if (!_generators.has(id)) return false;
  _activeId = id;
  return true;
}

/* ============================================================
   列表
   ============================================================ */
function listGenerators(){
  return Array.from(_generators.values()).map(g => ({
    id:    g.id,
    label: g.label,
    icon:  g.icon,
    desc:  g.desc,
    hidden: g.hidden,
  }));
}

/* ★ 过滤掉隐藏的生成器（用于创建世界对话框） */
function listSelectableGenerators(){
  return listGenerators().filter(g => !g.hidden);
}

function getGeneratorCount(){
  return _generators.size;
}

/* ============================================================
   高度限制
   ============================================================ */
function getGeneratorHeightLimit(id){
  const g = _generators.get(id);
  return (g && g.heightLimits) ? g.heightLimits : null;
}

/* =================================================================
   re-export
   ================================================================= */
export {
  raycastVoxel, riverValue, registerGenerator, declareWorldType, getDeclaredWorldType, listDeclaredWorldTypes, clearDeclaredWorldTypes, getGenerator, getActiveGenerator, getActiveGeneratorId, hasGenerator, setActiveGenerator, listGenerators, listSelectableGenerators, getGeneratorCount, getGeneratorHeightLimit
};
