/* ============================================================
   magic.js —— 魔法系统基础
   · 魔法强度：水晶=1，矿石=0.5，粉末=0
   · 传播：源头 → 相邻粉末（衰减）；断开隔 1 格可传（额外衰减）
   · 3D 模型：魔法水晶的立方体本体 invisible，用 Octahedron 顶上
   ============================================================ */
import * as THREE from 'three';
import { CS, Y_MIN, CHH, emit, on } from './../core/engine-core.js';
import { scene } from './../render/render-core.js';
import { getBlockWorld, setBlockWorld, isWorldBlockLoaded, getBlockData, setBlockData, removeBlockData, getChunksMap, setMagicTintFn } from './terrain.js';
import { BLOCKS, B } from './blocks.js';
import { registerCreativeCategory } from './world-registry.js';

/* 传播常数 */
const DECAY_NORMAL = 0.90;
const DECAY_GAP    = 0.72;
const MIN_STRENGTH = 0.02;
const MAX_VISITS   = 96;

const DIRS6 = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];

/* ============================================================
   3D 模型
   ============================================================ */
let _sharedGeo = null, _sharedMat = null;
let _ringGeo = null, _ringMat = null;

function _ensureShared(){
  if (_sharedGeo) return;
  _sharedGeo = new THREE.OctahedronGeometry(0.5, 0);
  _sharedMat = new THREE.MeshStandardMaterial({
    color: 0xb070ff, emissive: 0x503080, emissiveIntensity: 0.4,
    transparent: true, opacity: 0.9, roughness: 0.8, metalness: 0.0,
  });
}

function _makeCrystalModel(){
  _ensureShared();
  const g = new THREE.Group();
  const baseGeo = new THREE.CylinderGeometry(0.35, 0.45, 0.12, 8);
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x333333, roughness: 0.9, metalness: 0.1
  });
  const base = new THREE.Mesh(baseGeo, baseMat);
  base.position.y = 0.06;
  base.castShadow = true;
  base.receiveShadow = true;
  g.add(base);

  const crystal = new THREE.Mesh(_sharedGeo, _sharedMat);
  crystal.position.y = 0.52;
  crystal.scale.set(0.4, 0.9, 0.4); 
  crystal.castShadow = true;
  g.add(crystal);

  g.userData.crystal = crystal;
  g.userData.phase = Math.random() * Math.PI * 2;
  return g;
}

const _visuals = new Map();     // "x,y,z" -> THREE.Group
const _scannedChunks = new Set(); // "cx,cz"

function _attach(x, y, z){
  const key = x + ',' + y + ',' + z;
  if (_visuals.has(key)) return;
  const m = _makeCrystalModel();
  m.position.set(x + 0.5, y, z + 0.5);
  scene.add(m);
  _visuals.set(key, m);
}

function _detach(x, y, z){
  const key = x + ',' + y + ',' + z;
  const m = _visuals.get(key);
  if (!m) return;
  scene.remove(m);
  _visuals.delete(key);
}

function _clearAll(){
  for (const m of _visuals.values()) scene.remove(m);
  _visuals.clear();
}

function _scanChunk(chunk){
  if (!chunk || !chunk.blocks) return;
  const key = chunk.cx + ',' + chunk.cz;
  if (_scannedChunks.has(key)) return;
  _scannedChunks.add(key);

  const crystalId = B.magic_crystal ? B.magic_crystal.id : -1;
  if (crystalId < 0) return;

  const bx = chunk.cx * CS, bz = chunk.cz * CS;
  const blocks = chunk.blocks;
  const minY = chunk.minY != null ? Math.max(Y_MIN, chunk.minY) : Y_MIN;
  const maxY = chunk.maxY != null ? Math.min(CHH - 1, chunk.maxY) : CHH - 1;

  for (let y = minY; y <= maxY; y++){
    for (let z = 0; z < CS; z++){
      for (let x = 0; x < CS; x++){
        const i = (((y - Y_MIN) * CS) + z) * CS + x;
        if (blocks[i] === crystalId){
          _attach(bx + x, y, bz + z);
        }
      }
    }
  }
}

function _removeChunkVisuals(cx, cz){
  const bx = cx * CS, bz = cz * CS;
  for (const key of Array.from(_visuals.keys())){
    const [xs, , zs] = key.split(',');
    const x = +xs, z = +zs;
    if (x >= bx && x < bx + CS && z >= bz && z < bz + CS){
      _detach(x, 0, z);   // y 会被忽略
      const m = _visuals.get(key);
      if (m) scene.remove(m);
      _visuals.delete(key);
    }
  }
}

/* ============================================================
   事件
   ============================================================ */










function _onChunkInstall(chunk){ _scanChunk(chunk); }
function _onChunkUnload(chunk){
  if (!chunk) return;
  _scannedChunks.delete(chunk.cx + ',' + chunk.cz);
  _removeChunkVisuals(chunk.cx, chunk.cz);
}
function _onWorldLoad(){
  _clearAll();
  _scannedChunks.clear();
}

/* ============================================================
   魔法强度查询（BFS）
   ============================================================ */
/* 一个方块作为魔法源头的强度；0 表示不是源头 */
function _sourceStrength(blk){
  if (!blk) return 0;
  /* 通用的"通电方块"：木质按钮/压力板等通过 powerOn 接入同一套动力网络 */
  if (blk.powerOn > 0) return blk.powerOn;
  if (blk.name === 'magic_crystal') return 1.0;
  if (blk.name === 'magic_crystal_block') return 1.0;
  if (blk.name === 'magic_ore') return 0.5;
  /* 魔法火把：类似红石火把的恒定弱电源 */
  if (blk.name === 'magic_torch') return 0.2;
  if (blk.name === 'magic_lever_on' ||
      blk.name === 'magic_button_on' ||
      blk.name === 'magic_pressure_plate_on') return 0.1;
  return 0;
}

export function getMagicStrengthAt(wx, wy, wz){
  wx = Math.floor(wx); wy = Math.floor(wy); wz = Math.floor(wz);
  if (wy < Y_MIN || wy >= CHH) return 0;
  if (!isWorldBlockLoaded(wx, wy, wz)) return 0;

  const startId = getBlockWorld(wx, wy, wz);
  const startBlk = BLOCKS[startId];
  if (!startBlk) return 0;

  const startSrc = _sourceStrength(startBlk);
  if (startSrc > 0) return startSrc;
  if (startBlk.name !== 'magic_dust') return 0;

  /* BFS 找源头 */
  const startKey = wx + ',' + wy + ',' + wz;
  const seen = new Map();
  seen.set(startKey, { d: 0, gap: 0 });
  const queue = [{ x: wx, y: wy, z: wz, d: 0, gap: 0 }];
  let best = 0;
  let visits = 0;

  while (queue.length && visits < MAX_VISITS){
    const cur = queue.shift();
    visits++;

    for (const [dx, dy, dz] of DIRS6){
      const nx = cur.x + dx, ny = cur.y + dy, nz = cur.z + dz;
      if (ny < Y_MIN || ny >= CHH) continue;
      const nbId = getBlockWorld(nx, ny, nz);
      const nb = BLOCKS[nbId];
      if (!nb) continue;

      /* 直接相邻 */
      const src = _sourceStrength(nb);
      if (src > 0){
        const s = src * Math.pow(DECAY_NORMAL, cur.d + 1) * Math.pow(DECAY_GAP, cur.gap);
        if (s > best) best = s;
        continue;
      }
      if (nb.name === 'magic_dust'){
        const key = nx + ',' + ny + ',' + nz;
        const prev = seen.get(key);
        if (!prev || cur.d + 1 < prev.d || cur.gap < prev.gap){
          const entry = { d: cur.d + 1, gap: cur.gap };
          seen.set(key, entry);
          queue.push({ x: nx, y: ny, z: nz, d: entry.d, gap: entry.gap });
        }
        continue;
      }

      /* 断开的粉末：跳过一格 */
      if (nb.solid) continue;
      const jx = nx + dx, jy = ny + dy, jz = nz + dz;
      if (jy < Y_MIN || jy >= CHH) continue;
      const jbId = getBlockWorld(jx, jy, jz);
      const jb = BLOCKS[jbId];
      if (!jb) continue;

      const gapSrc = _sourceStrength(jb);
      if (gapSrc > 0){
        const s = gapSrc * Math.pow(DECAY_NORMAL, cur.d + 1) * Math.pow(DECAY_GAP, cur.gap + 1);
        if (s > best) best = s;
        continue;
      }
      if (jb.name === 'magic_dust'){
        const key = jx + ',' + jy + ',' + jz;
        const prev = seen.get(key);
        const nextD = cur.d + 2, nextGap = cur.gap + 1;
        if (!prev || nextD < prev.d || nextGap < prev.gap){
          seen.set(key, { d: nextD, gap: nextGap });
          queue.push({ x: jx, y: jy, z: jz, d: nextD, gap: nextGap });
        }
      }
    }
  }

  return Math.min(1, best);
}

export function getMagicSourcesNear(wx, wy, wz, radius){
  const r = Math.max(1, Math.min(64, radius | 0));
  const r2 = r * r;
  wx = Math.floor(wx); wy = Math.floor(wy); wz = Math.floor(wz);
  const out = [];
  for (let dy = -r; dy <= r; dy++){
    for (let dz = -r; dz <= r; dz++){
      for (let dx = -r; dx <= r; dx++){
        if (dx*dx + dy*dy + dz*dz > r2) continue;
        const x = wx + dx, y = wy + dy, z = wz + dz;
        if (y < Y_MIN || y >= CHH) continue;
        if (!isWorldBlockLoaded(x, y, z)) continue;
        const id = getBlockWorld(x, y, z);
        const blk = BLOCKS[id];
        if (!blk) continue;
        if (blk.name === 'magic_crystal') out.push({ x, y, z, type: 'crystal', strength: 1.0 });
        else if (blk.name === 'magic_ore') out.push({ x, y, z, type: 'ore', strength: 0.5 });
      }
    }
  }
  return out;
}

/* ============================================================
   ★ 动态颜色：强度 → 顶点色
   ------------------------------------------------------------
   无魔法 → 中性灰 #808088
   有魔法 → 紫粉，越强越亮（不发光，靠顶点色调制）
   ============================================================ */
function isPowerSource(blk) {
    if (!blk) return false;
    if (blk.powerOn > 0) return true;
    return blk.name === 'magic_crystal' || blk.name === 'magic_crystal_block' ||
           blk.name === 'magic_ore' ||
           blk.name === 'magic_torch' ||
           blk.name === 'magic_lever_on' || blk.name === 'magic_button_on' ||
           blk.name === 'magic_pressure_plate_on';
}

function checkAndUpdateDust(wx, wy, wz) {
    const id = getBlockWorld(wx, wy, wz);
    const blk = BLOCKS[id];
    if (!blk) return;
    
    if (blk.name !== 'magic_dust' && blk.name !== 'magic_dust_on') return;

    let powered = false;
    for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
            for (let dz = -1; dz <= 1; dz++) {
                const nid = getBlockWorld(wx + dx, wy + dy, wz + dz);
                if (isPowerSource(BLOCKS[nid])) {
                    powered = true; break;
                }
            }
            if (powered) break;
        }
        if (powered) break;
    }
    
    const targetName = powered ? 'magic_dust_on' : 'magic_dust';
    if (blk.name !== targetName) {
        const targetBlk = B[targetName];
        if (targetBlk) setBlockWorld(wx, wy, wz, targetBlk.id);
    }
}

/* ============================================================
   动画
   ============================================================ */
let _animTime = 0;










/* ============================================================
   初始化
   ============================================================ */
let _initialized = false;








// ============================================================
// 魔法网络连通逻辑（终极重写版）
// ============================================================





function _onBlockChanged(x, y, z, oldId, newId){
  const oldBlk = BLOCKS[oldId];
  const newBlk = BLOCKS[newId];
  
  // 防死循环：粉末切换自身，只刷新渲染不跑网络
  if (oldBlk && newBlk) {
      const oldN = oldBlk.name;
      const newN = newBlk.name;
      if ((oldN === 'magic_dust' && newN === 'magic_dust_on') ||
          (oldN === 'magic_dust_on' && newN === 'magic_dust')) {
          _markChunksDirty(x, z);
          return;
      }
  }

  const wasCrystal = oldBlk && oldBlk.name === 'magic_crystal';
  const isCrystal  = newBlk && newBlk.name === 'magic_crystal';
  if (wasCrystal) _detach(x, y, z);
  if (isCrystal)  _attach(x, y, z);

  if (wasCrystal || isCrystal){
    emit('magic.changed', x, y, z, isCrystal ? 'add' : 'remove');
  }
  
  const isMagic = (b) => b && (
    b.buttonOff || b.plateOff || b.buttonOn || b.plateOn ||
    b.name === 'magic_crystal' || b.name === 'magic_crystal_block' || b.name === 'magic_ore' ||
    b.name === 'magic_torch' ||
    b.name === 'magic_dust' || b.name === 'magic_dust_on' ||
    b.name === 'magic_lever' || b.name === 'magic_lever_on' ||
    b.name === 'magic_button' || b.name === 'magic_button_on' ||
    b.name === 'magic_pressure_plate' || b.name === 'magic_pressure_plate_on' ||
    b.name === 'magic_pedestal' ||
    b.name === 'magic_door' || b.name === 'magic_door_open' ||
    b.name === 'magic_door_top' || b.name === 'magic_door_open_top');

  /* 动力元件 / 门的追踪表 */
  _trackMagicBlock(x, y, z, newBlk);

  if (newBlk && newBlk.name === 'magic_pedestal') setTimeout(() => _updatePedestalModel(x, y, z), 0);
  if (oldBlk && oldBlk.name === 'magic_pedestal') setTimeout(() => _updatePedestalModel(x, y, z), 0);
  if (isMagic(oldBlk) || isMagic(newBlk)) {
      _updateNetwork(x, y, z);
      _markChunksDirty(x, z);
  }
}












// 区块加载时，把展台模型重新加回来！


// 区块卸载时，清理模型防止内存泄漏






















export 


let _pedestalVisuals = new Map();
let _pedestalTimer = 0;

function _markChunksDirty(wx, wz) {
    if (typeof getChunksMap !== 'function') return;
    const map = getChunksMap();
    if (!map) return;
    const cx = Math.floor(wx / 16);
    const cz = Math.floor(wz / 16);
    for (const chunk of map.values()) {
        if (Math.abs(chunk.cx - cx) <= 1 && Math.abs(chunk.cz - cz) <= 1) {
            chunk.dirty = true;
            chunk.dirtyGen = (chunk.dirtyGen || 0) + 1;
        }
    }
}

function _updateNetwork(wx, wy, wz) {
    const visited = new Set();
    const allDusts = new Set();
    const seeds = [];
    
    // 1. 收集周围相连的粉末
    for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
            for (let dz = -1; dz <= 1; dz++) {
                const nx = wx + dx, ny = wy + dy, nz = wz + dz;
                const nid = getBlockWorld(nx, ny, nz);
                const nb = BLOCKS[nid];
                if (nb && (nb.name === 'magic_dust' || nb.name === 'magic_dust_on')) {
                    seeds.push([nx, ny, nz]);
                }
            }
        }
    }
    
    for (const seed of seeds) {
        const [sx, sy, sz] = seed;
        const skey = `${sx},${sy},${sz}`;
        if (visited.has(skey)) continue;
        
        const queue = [seed];
        visited.add(skey);
        
        while (queue.length) {
            const [cx, cy, cz] = queue.shift();
            allDusts.add(`${cx},${cy},${cz}`);
            
            for (let dx = -1; dx <= 1; dx++) {
                for (let dy = -1; dy <= 1; dy++) {
                    for (let dz = -1; dz <= 1; dz++) {
                        if (dx === 0 && dy === 0 && dz === 0) continue;
                        const nx = cx + dx, ny = cy + dy, nz = cz + dz;
                        const nid = getBlockWorld(nx, ny, nz);
                        const nb = BLOCKS[nid];
                        if (nb && (nb.name === 'magic_dust' || nb.name === 'magic_dust_on')) {
                            const k = `${nx},${ny},${nz}`;
                            if (!visited.has(k)) {
                                visited.add(k);
                                queue.push([nx, ny, nz]);
                            }
                        }
                    }
                }
            }
        }
    }
    
    const poweredDusts = new Set();
    const dirs6 = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
    
    // 2. 找出网络附近的所有电源
    const sources = [];
    for (const d of allDusts) {
        const [dx, dy, dz] = d.split(',').map(Number);
        for (const [ox, oy, oz] of dirs6) {
            const nx = dx + ox, ny = dy + oy, nz = dz + oz;
            const nid = getBlockWorld(nx, ny, nz);
            const nb = BLOCKS[nid];
            if (!nb) continue;
            
            let maxDist = 0;
            if (nb.powerOn > 0) {
                /* 通用动力元件（木质按钮 / 压力板）：强度 × 50 格 */
                maxDist = Math.floor(nb.powerOn * 50);
            } else if (nb.name === 'magic_crystal_block') {
                maxDist = 50;
            } else if (nb.name === 'magic_ore') {
                maxDist = 5;
            } else if (nb.name === 'magic_torch') {
                /* 火把强度 0.2：0.2 * 50 = 10 格粉末 */
                maxDist = 10;
            } else if (nb.name === 'magic_lever_on' ||
                       nb.name === 'magic_button_on' ||
                       nb.name === 'magic_pressure_plate_on') {
                /* 动力元件输出 0.1 强度：0.1 * 50 = 5 格粉末 */
                maxDist = 5;
            } else if (nb.name === 'magic_pedestal') {
                const data = getBlockData(nx, ny, nz);
                if (data && data.item) {
                    let str = 0;
                    if (data.item === 'magic_crystal') str = 0.5 * (data.dur / 100);
                    else if (data.item === 'magic_crystal_block') str = 1.0;
                    else if (data.item === 'magic_pulse_core') {
                        const state = data._pulseState || { energy: 0, firing: 0 };
                        str = state.firing > 0 ? 1.0 : state.energy;
                    }
                    maxDist = Math.floor(str * 50);
                }
            }
            // 记录电源：起点为它相邻的那根粉末
            if (maxDist > 0) sources.push({ x: dx, y: dy, z: dz, maxDist });
        }
    }
    
    // 3. 对每个电源进行 BFS 标记（因为电源通常很少，所以极快）
    for (const src of sources) {
        const pQueue = [{x: src.x, y: src.y, z: src.z, dist: 0}];
        const pVisited = new Set([`${src.x},${src.y},${src.z}`]);
        while(pQueue.length) {
            const cur = pQueue.shift();
            if (cur.dist > src.maxDist) continue;
            poweredDusts.add(`${cur.x},${cur.y},${cur.z}`);
            for (const [px, py, pz] of dirs6) {
                const tx = cur.x+px, ty = cur.y+py, tz = cur.z+pz;
                const tk = `${tx},${ty},${tz}`;
                if (!pVisited.has(tk)) {
                    const tid = getBlockWorld(tx, ty, tz);
                    const tb = BLOCKS[tid];
                    if (tb && (tb.name === 'magic_dust' || tb.name === 'magic_dust_on')) {
                        pVisited.add(tk);
                        pQueue.push({x: tx, y: ty, z: tz, dist: cur.dist + 1});
                    }
                }
            }
        }
    }

    // 4. 统一切换方块状态
    for (const d of allDusts) {
        const [dx, dy, dz] = d.split(',').map(Number);
        const id = getBlockWorld(dx, dy, dz);
        const b = BLOCKS[id];
        const isPowered = poweredDusts.has(d);
        const targetName = isPowered ? 'magic_dust_on' : 'magic_dust';
        if (b && b.name !== targetName) {
            setBlockWorld(dx, dy, dz, B[targetName].id);
        }
    }
}

/* 展台外壳已改成方块模型（由区块网格渲染），这里只保留“放在展台上的物品”这个动态小模型 */
function _makePedestalModel(hasItem, itemType) {
    if (!hasItem) return null;
    const g = new THREE.Group();
    if (itemType === 'magic_pulse_core') {
        const pMat = new THREE.MeshStandardMaterial({ color: 0xffaa00, emissive: 0xff4400, emissiveIntensity: 0.8 });
        const p = new THREE.Mesh(new THREE.OctahedronGeometry(0.3, 0), pMat);
        p.position.y = 0.45; g.add(p);
    } else if (itemType === 'magic_crystal') {
        _ensureShared();
        const c = new THREE.Mesh(_sharedGeo, _sharedMat);
        c.scale.set(0.3, 0.6, 0.3); c.position.y = 0.4; g.add(c);
    } else if (itemType === 'magic_crystal_block') {
        const bMat = new THREE.MeshStandardMaterial({ color: 0xb070ff, emissive: 0x8040ff, emissiveIntensity: 0.5 });
        const b = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.6), bMat);
        b.position.y = 0.35; g.add(b);
    } else {
        return null;
    }
    return g;
}

function _updatePedestalModel(x, y, z) {
    const key = `${x},${y},${z}`;
    let m = _pedestalVisuals.get(key);
    if (m) { scene.remove(m); _pedestalVisuals.delete(key); }

    const id = getBlockWorld(x, y, z);
    if (BLOCKS[id] && BLOCKS[id].name === 'magic_pedestal') {
        const data = getBlockData(x, y, z);
        m = _makePedestalModel(data && data.item, data ? data.item : null);
        if (!m) return;   /* 空展台没有动态模型，外壳由区块网格渲染 */
        m.position.set(x + 0.5, y, z + 0.5);
        scene.add(m);
        _pedestalVisuals.set(key, m);
    }
}

/* ============================================================
   动力元件 / 门：运行时状态
   ============================================================ */
const LEVER_SECONDS = 4.0;     /* 拉杆一次输出 0.1 强度，持续 4 秒 */
const BUTTON_SECONDS = 1.0;    /* 按钮按一次输出 0.1 强度，持续 1 秒 */
const DOOR_LATCH_SECONDS = 2.0;/* 持续受魔法超过 2 秒 → 保持开启 */

const _leverTimers = new Map();   /* key -> 剩余秒数 */
const _buttonTimers = new Map();
const _plates = new Set();        /* 已加载的压力板坐标 */
const _plateTimers = new Map();   /* 箭矢等外部触发：坐标 → 剩余秒数 */
const _doors = new Set();         /* 已加载的门坐标 */
const _doorStates = new Map();    /* key -> { timer, latch } */

function _keyOf(x, y, z){ return x + ',' + y + ',' + z; }

const _DOOR_BOTTOM_NAMES = new Set(['magic_door', 'magic_door_open', 'iron_door', 'iron_door_open']);
const _DOOR_TOP_NAMES = new Set(['magic_door_top', 'magic_door_open_top', 'iron_door_top', 'iron_door_open_top']);

function _isDoorName(n){ return _DOOR_BOTTOM_NAMES.has(n) || _DOOR_TOP_NAMES.has(n); }
function _isDoorBottomName(n){ return _DOOR_BOTTOM_NAMES.has(n); }
function _isDoorTopName(n){ return _DOOR_TOP_NAMES.has(n); }
function _isDoorOpenName(n){ return n === 'magic_door_open' || n === 'iron_door_open' ||
                                   n === 'magic_door_open_top' || n === 'iron_door_open_top'; }
function _doorPair(name){
    const iron = name.indexOf('iron_') === 0;
    return iron
        ? { closed: B.iron_door, open: B.iron_door_open, topClosed: B.iron_door_top, topOpen: B.iron_door_open_top }
        : { closed: B.magic_door, open: B.magic_door_open, topClosed: B.magic_door_top, topOpen: B.magic_door_open_top };
}

/* 同时切换门的下半格与上半格 */
function _applyDoorState(x, y, z, open, iron){
    const pair = _doorPair(iron ? 'iron_door' : 'magic_door');
    const bottom = open ? pair.open : pair.closed;
    const top    = open ? pair.topOpen : pair.topClosed;
    if (bottom) setBlockWorld(x, y, z, bottom.id);
    const topBlk = BLOCKS[getBlockWorld(x, y + 1, z)];
    if (top && topBlk && _isDoorTopName(topBlk.name)){
        setBlockWorld(x, y + 1, z, top.id);
    }
}

/* 老存档 / 手动放下的单格门：补上上半格，保证两格高 */
function _ensureDoorTop(x, y, z, open, iron){
    if (getBlockWorld(x, y + 1, z) !== 0) return;
    const pair = _doorPair(iron ? 'iron_door' : 'magic_door');
    const top = open ? pair.topOpen : pair.topClosed;
    if (top) setBlockWorld(x, y + 1, z, top.id, { silent: true });
}

/* 方块变化时维护追踪表（放在 _onBlockChanged 里调用） */
function _trackMagicBlock(x, y, z, blk){
    const key = _keyOf(x, y, z);
    const n = blk ? blk.name : '';
    /* 任何带 plateOff / plateOn 的方块都视为压力板（魔法板 + 木质板） */
    if (blk && blk.plateOn) _plates.add(key);
    else _plates.delete(key);

    if (_isDoorBottomName(n)){ _doors.add(key); }
    else if (!_isDoorTopName(n)){ _doors.delete(key); _doorStates.delete(key); }

    if (n !== 'magic_lever' && n !== 'magic_lever_on') _leverTimers.delete(key);
    /* 任何带 buttonOn 的按钮都保留计时器（魔法按钮 + 木质按钮） */
    if (!(blk && blk.buttonOn)) _buttonTimers.delete(key);
}

function _getDoorState(x, y, z){
    const key = _keyOf(x, y, z);
    let st = _doorStates.get(key);
    if (!st){
        const data = getBlockData(x, y, z);
        st = { timer: 0, latch: !!(data && data._doorLatch), blockPower: false };
        _doorStates.set(key, st);
    }
    return st;
}

function _persistDoorLatch(x, y, z, latch){
    const data = getBlockData(x, y, z) || {};
    data._doorLatch = !!latch;
    setBlockData(x, y, z, data);
}

/* 门是否正在接收魔法：相邻有通电粉末或动力源/有物品的展台 */
function _isDoorPowered(x, y, z){
    for (const yy of [y, y + 1]){
        for (const [dx, dy, dz] of DIRS6){
            const nx = x + dx, ny = yy + dy, nz = z + dz;
            const nb = BLOCKS[getBlockWorld(nx, ny, nz)];
            if (!nb) continue;
            if (nb.name === 'magic_dust_on' || nb.powerOn > 0 ||
                nb.name === 'magic_crystal' ||
                nb.name === 'magic_crystal_block' ||
                nb.name === 'magic_torch' ||
                nb.name === 'magic_ore' || nb.name === 'magic_lever_on' ||
                nb.name === 'magic_button_on' || nb.name === 'magic_pressure_plate_on'){
                return true;
            }
            if (nb.name === 'magic_pedestal'){
                const data = getBlockData(nx, ny, nz);
                if (data && data.item) return true;
            }
        }
    }
    return false;
}

function _updatePowerTimers(dt){
    for (const key of Array.from(_leverTimers.keys())){
        const left = _leverTimers.get(key) - dt;
        if (left > 0){ _leverTimers.set(key, left); continue; }
        _leverTimers.delete(key);
        const [x, y, z] = key.split(',').map(Number);
        if (BLOCKS[getBlockWorld(x, y, z)]?.name === 'magic_lever_on'){
            setBlockWorld(x, y, z, B.magic_lever.id);
            _clearActivation(x, y, z);
        }
    }
    for (const key of Array.from(_buttonTimers.keys())){
        const left = _buttonTimers.get(key) - dt;
        if (left > 0){ _buttonTimers.set(key, left); continue; }
        _buttonTimers.delete(key);
        const [x, y, z] = key.split(',').map(Number);
        const cur = BLOCKS[getBlockWorld(x, y, z)];
        /* 任何带 buttonOff 的按钮（魔法按钮 + 木质按钮）复位 */
        if (cur && cur.buttonOff && B[cur.buttonOff] && cur.name !== cur.buttonOff){
            setBlockWorld(x, y, z, B[cur.buttonOff].id);
            _clearActivation(x, y, z);
        }
    }
}

function _updatePressurePlates(dt){
    if (!_plates.size) return;
    /* 外部触发（箭矢命中）计时 */
    if (_plateTimers.size){
        for (const [k, left] of Array.from(_plateTimers)){
            const n = left - (dt || 0);
            if (n <= 0) _plateTimers.delete(k);
            else _plateTimers.set(k, n);
        }
    }
    const pos = window.__GAME__ && window.__GAME__.getPos ? window.__GAME__.getPos() : null;
    for (const key of Array.from(_plates)){
        const [x, y, z] = key.split(',').map(Number);
        const blk = BLOCKS[getBlockWorld(x, y, z)];
        if (!blk || !blk.plateOff || !blk.plateOn){
            _plates.delete(key);
            _plateTimers.delete(key);
            continue;
        }
        const byPlayer = !!pos && Math.floor(pos.x) === x && Math.floor(pos.z) === z &&
                        pos.y >= y - 0.08 && pos.y < y + 0.45;
        const pressed = byPlayer || _plateTimers.has(key);
        const offBlk = B[blk.plateOff], onBlk = B[blk.plateOn];
        if (pressed && blk.name === blk.plateOff && onBlk){
            setBlockWorld(x, y, z, onBlk.id);
            _markActivation(x, y, z);
        } else if (!pressed && blk.name === blk.plateOn && offBlk){
            setBlockWorld(x, y, z, offBlk.id);
        }
    }
}

function _updateDoors(dt){
    if (!_doors.size) return;
    for (const key of Array.from(_doors)){
        const [x, y, z] = key.split(',').map(Number);
        const blk = BLOCKS[getBlockWorld(x, y, z)];
        if (!blk || !_isDoorBottomName(blk.name)){
            _doors.delete(key);
            _doorStates.delete(key);
            continue;
        }
        const isOpen = _isDoorOpenName(blk.name);
        const isIron = blk.name.indexOf('iron_') === 0;
        const st = _getDoorState(x, y, z);
        _ensureDoorTop(x, y, z, isOpen, isIron);

        const powered = _isDoorPowered(x, y, z);

        if (powered){
            if (isIron){
                /* 铁门：完全由机关控制，不做锁存，断电就关 */
                st.latch = false;
            } else if (!st.blockPower){
                st.timer += dt;
                if (st.timer >= DOOR_LATCH_SECONDS && !st.latch){
                    st.latch = true;
                    _persistDoorLatch(x, y, z, true);
                }
            }
        } else {
            st.timer = 0;
            st.blockPower = false;
        }

        if (powered && !st.blockPower && !isOpen){
            _applyDoorState(x, y, z, true, isIron);
        } else if (!powered && !st.latch && isOpen){
            _applyDoorState(x, y, z, false, isIron);
        }
    }
}

/* ============================================================
   对外接口：拉杆 / 按钮 / 门
   ============================================================ */
function _markActivation(x, y, z){
    const data = getBlockData(x, y, z) || {};
    data._onAt = Date.now();
    setBlockData(x, y, z, data);
}
function _clearActivation(x, y, z){
    const data = getBlockData(x, y, z);
    if (data && data._onAt !== undefined){
        delete data._onAt;
        setBlockData(x, y, z, data);
    }
}

export function pullLever(x, y, z){
    const blk = BLOCKS[getBlockWorld(x, y, z)];
    if (!blk) return false;
    if (blk.name === 'magic_lever_on'){
        _leverTimers.delete(_keyOf(x, y, z));
        _clearActivation(x, y, z);
        setBlockWorld(x, y, z, B.magic_lever.id);
        return true;
    }
    if (blk.name !== 'magic_lever') return false;
    setBlockWorld(x, y, z, B.magic_lever_on.id);
    _markActivation(x, y, z);
    _leverTimers.set(_keyOf(x, y, z), LEVER_SECONDS);
    return true;
}

export function pressButton(x, y, z){
    const blk = BLOCKS[getBlockWorld(x, y, z)];
    if (!blk || !blk.buttonOn || !blk.buttonOff) return false;
    const onBlk = B[blk.buttonOn];
    if (!onBlk) return false;
    if (blk.name === blk.buttonOff){
        setBlockWorld(x, y, z, onBlk.id);
    }
    _markActivation(x, y, z);
    _buttonTimers.set(_keyOf(x, y, z), BUTTON_SECONDS);
    return true;
}

/* 箭矢等外部物体压住压力板：保持 seconds 秒后自动弹起 */
export function pressPressurePlate(x, y, z, seconds){
    const blk = BLOCKS[getBlockWorld(x, y, z)];
    if (!blk || !blk.plateOff || !blk.plateOn) return false;
    const key = _keyOf(x, y, z);
    _plates.add(key);
    _plateTimers.set(key, Math.max(0.3, seconds || 1.0));
    const onBlk = B[blk.plateOn];
    if (blk.name === blk.plateOff && onBlk){
        setBlockWorld(x, y, z, onBlk.id);
        _markActivation(x, y, z);
    }
    return true;
}

export function toggleDoor(x, y, z){
    let blk = BLOCKS[getBlockWorld(x, y, z)];
    /* 点到上半格：以下半格为准 */
    if (blk && _isDoorTopName(blk.name)){
        y -= 1;
        blk = BLOCKS[getBlockWorld(x, y, z)];
    }
    if (!blk || !_isDoorBottomName(blk.name)) return false;
    /* 铁门不能用手开关，只能由魔法机关驱动 */
    if (blk.name.indexOf('iron_door') === 0) return false;
    const st = _getDoorState(x, y, z);
    const opening = !_isDoorOpenName(blk.name);
    st.timer = 0;
    st.latch = opening;          /* 手动打开：保持开 */
    /* 手动关闭时，即使旁边还有魔法也先保持关闭，直到魔法真正断电 */
    st.blockPower = !opening;
    _persistDoorLatch(x, y, z, opening);
    _applyDoorState(x, y, z, opening, false);
    return true;
}

function _onChunkInstall2(chunk) {
    if (!chunk || !chunk.blocks) return;
    const bx = chunk.cx * 16, bz = chunk.cz * 16;
    const pedId = B.magic_pedestal ? B.magic_pedestal.id : -1;
    const plateId = B.magic_pressure_plate ? B.magic_pressure_plate.id : -1;
    const plateOnId = B.magic_pressure_plate_on ? B.magic_pressure_plate_on.id : -1;
    const doorId = B.magic_door ? B.magic_door.id : -1;
    const doorOpenId = B.magic_door_open ? B.magic_door_open.id : -1;
    const ironDoorId = B.iron_door ? B.iron_door.id : -1;
    const ironDoorOpenId = B.iron_door_open ? B.iron_door_open.id : -1;
    const leverOnId = B.magic_lever_on ? B.magic_lever_on.id : -1;
    const buttonOnId = B.magic_button_on ? B.magic_button_on.id : -1;

    for (let y = chunk.minY || Y_MIN; y < (chunk.maxY || CHH); y++) {
        for (let z = 0; z < 16; z++) {
            for (let x = 0; x < 16; x++) {
                const i = (((y - Y_MIN) * 16) + z) * 16 + x;
                const id = chunk.blocks[i];
                const wx = bx + x, wz = bz + z;
                if (id === pedId) {
                    _updatePedestalModel(wx, y, wz);
                } else if (id === plateId || id === plateOnId) {
                    _plates.add(_keyOf(wx, y, wz));
                } else if (id === doorId || id === doorOpenId ||
                           id === ironDoorId || id === ironDoorOpenId) {
                    _doors.add(_keyOf(wx, y, wz));
                } else if (id === leverOnId || id === buttonOnId) {
                    /* 区块重建/读档后按激活时间恢复剩余时长 */
                    const isLever = id === leverOnId;
                    const dur = isLever ? LEVER_SECONDS : BUTTON_SECONDS;
                    const data = getBlockData(wx, y, wz);
                    const left = (data && data._onAt)
                        ? dur - (Date.now() - data._onAt) / 1000
                        : 0;
                    if (left > 0){
                        (isLever ? _leverTimers : _buttonTimers).set(_keyOf(wx, y, wz), left);
                    } else {
                        const offName = isLever ? 'magic_lever' : 'magic_button';
                        if (B[offName]) setBlockWorld(wx, y, wz, B[offName].id, { silent: true });
                        _clearActivation(wx, y, wz);
                    }
                }
            }
        }
    }
}

function _onChunkUnload2(chunk) {
    if (!chunk) return;
    const bx = chunk.cx * 16, bz = chunk.cz * 16;
    for (const key of Array.from(_pedestalVisuals.keys())) {
        const [x, , z] = key.split(',').map(Number);
        if (x >= bx && x < bx + 16 && z >= bz && z < bz + 16) {
            const m = _pedestalVisuals.get(key);
            if (m) scene.remove(m);
            _pedestalVisuals.delete(key);
        }
    }
    for (const [key] of Array.from(_leverTimers)) {
        const [x, , z] = key.split(',').map(Number);
        if (x >= bx && x < bx + 16 && z >= bz && z < bz + 16) _leverTimers.delete(key);
    }
    for (const [key] of Array.from(_buttonTimers)) {
        const [x, , z] = key.split(',').map(Number);
        if (x >= bx && x < bx + 16 && z >= bz && z < bz + 16) _buttonTimers.delete(key);
    }
    for (const key of Array.from(_plates)) {
        const [x, , z] = key.split(',').map(Number);
        if (x >= bx && x < bx + 16 && z >= bz && z < bz + 16) _plates.delete(key);
    }
    for (const key of Array.from(_doors)) {
        const [x, , z] = key.split(',').map(Number);
        if (x >= bx && x < bx + 16 && z >= bz && z < bz + 16){
            _doors.delete(key);
            _doorStates.delete(key);
        }
    }
}

export function updateMagic(dt){
  _animTime += dt;

  _updatePowerTimers(dt);
  _updatePressurePlates(dt);
  _updateDoors(dt);
  
  _pedestalTimer += dt;
  if (_pedestalTimer >= 300) { 
      _pedestalTimer = 0;
      for (const key of Array.from(_pedestalVisuals.keys())) {
          const [x, y, z] = key.split(',').map(Number);
          const data = getBlockData(x, y, z);
          if (!data || !data.item) continue;

          /* 水晶：每 5 分钟 -20（约 25 分钟寿命）
             水晶块：每 5 分钟 -5（约 100 分钟寿命，慢 4 倍） */
          let loss = 0;
          if (data.item === 'magic_crystal') loss = 20;
          else if (data.item === 'magic_crystal_block'){
              if (typeof data.dur !== 'number') data.dur = 100;
              loss = 5;
          }
          if (loss <= 0) continue;

          data.dur -= loss;
          if (data.dur <= 0) removeBlockData(x, y, z);
          else setBlockData(x, y, z, data);
          if (data.item === 'magic_crystal') _updatePedestalModel(x, y, z);
          _updateNetwork(x, y, z);
      }
  }

  for (const key of Array.from(_pedestalVisuals.keys())) {
      const [x, y, z] = key.split(',').map(Number);
      const data = getBlockData(x, y, z);
      if (!data || data.item !== 'magic_pulse_core') continue;

      let state = data._pulseState;
      if (!state) {
          state = { energy: 0, timer: 0, firing: 0 };
          data._pulseState = state;
      }

      if (state.firing > 0) {
          state.firing -= dt;
          if (state.firing <= 0) {
              state.firing = 0;
              state.energy = 0;
              _updateNetwork(x, y, z);
          }
      } else {
          state.timer += dt;
          const interval = data.chargeTime || 2;
          if (state.timer >= interval) {
              state.timer = 0;
              if (state.energy < 0.8) {
                  state.energy = Math.min(1.0, state.energy + 0.1);
                  _updateNetwork(x, y, z);
              }
              if (state.energy >= 0.8) {
                  state.energy = 1.0;
                  state.firing = 1.0;
                  _updateNetwork(x, y, z);
              }
          }
      }
      setBlockData(x, y, z, data);
  }
}
export function initMagic(){
  if (_initialized) return;
  _initialized = true;

  /* ★ 把 tint 计算器注册给 terrain.js（chunk ready 时自动算） */
  try { setMagicTintFn(computeChunkMagicTint); } catch(e){}
  
  if (window.__GAME__ && window.__GAME__.registerRecipe) {
      /* 把 3×3 的 pattern 转成运行时配方要求的 shape 格式 */
      const regMagicRecipe = (pattern, result) => {
          const shape = [];
          for (let r = 0; r < 3; r++){
              for (let c = 0; c < 3; c++){
                  const name = pattern[r] && pattern[r][c];
                  if (name) shape.push({ pos: r * 3 + c, item: name });
              }
          }
          window.__GAME__.registerRecipe({ size: 3, shape, result });
      };

      regMagicRecipe([
          ['oak_planks', 'glass', 'oak_planks'],
          ['glass', null, 'glass'],
          ['oak_planks', 'oak_planks', 'oak_planks']
      ], { name: 'magic_pedestal', count: 1 });

      regMagicRecipe([
          ['magic_crystal', 'magic_crystal', 'magic_crystal'],
          ['magic_crystal', 'magic_crystal', 'magic_crystal'],
          ['magic_crystal', 'magic_crystal', 'magic_crystal']
      ], { name: 'magic_crystal_block', count: 1 });

      // 脉冲核心：铁-水晶-铁 / 水晶-空-水晶 / 铁-水晶-铁
      regMagicRecipe([
          ['iron_ingot', 'magic_crystal', 'iron_ingot'],
          ['magic_crystal', null, 'magic_crystal'],
          ['iron_ingot', 'magic_crystal', 'iron_ingot']
      ], { name: 'magic_pulse_core', count: 4 });

      // 1 水晶 = 8 粉末
      regMagicRecipe([
          [null, null, null],
          [null, 'magic_crystal', null],
          [null, null, null]
      ], { name: 'magic_dust', count: 8 });

      // 1 水晶 + 1 木棍 = 4 魔法火把
      regMagicRecipe([
          [null, 'magic_crystal', null],
          [null, 'stick', null],
          [null, null, null]
      ], { name: 'magic_torch', count: 4 });
  }

  try {
    registerCreativeCategory({
      id: 'magic', label: '动力', order: 45, icon: 'magic_crystal_icon',
    });
  } catch(e){}

  on('world.blockChanged', _onBlockChanged);
  on('magic.pedestalUpdated', (x, y, z) => {
    _updatePedestalModel(x, y, z);
    _updateNetwork(x, y, z);
  });
  on('chunk.mesh:install', _onChunkInstall2);
  on('chunk.mesh:unload', _onChunkUnload2);
  on('world.load', _onWorldLoad);

  console.log('[magic] 初始化完成');
}
