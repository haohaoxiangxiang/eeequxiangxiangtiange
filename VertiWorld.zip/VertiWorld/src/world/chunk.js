/* ============================================================
   chunk.js —— 区块网格化 + 调度
   ============================================================ */

import * as THREE from 'three';
import { CS, CHH, Y_MIN } from './../core/engine-core.js';
import { emit, on } from './../core/engine-core.js';
import { BLOCKS } from './blocks.js';
import { UVRECT, TEX } from './textures.js';
import { getChunk, getChunkDecorated, getBlockWorld, getFluidLevel,
         getChunkRaw,
         chunkKey, getChunksMap, unloadChunk, isWorldBlockLoaded,
       } from './terrain.js';
import { matSolid, matTrans, matEmissive, getLeafMaterial, getLeafAlpha, matCross }
  from './../render/render-core.js';
import { scene } from './../render/render-core.js';
import { buildChunkGeometry } from './core/mesh-builder.js';

import { getPool } from '../worker/pool.js';
import { MSG }     from './../worker/pool.js';
import { FLAGS }   from './../worker/pool.js';
import { getDeviceProfile } from './../core/runtime.js';
import { USE_SAB } from './../core/runtime.js';

/* ============================================================
   Mesh Worker 开关
   ============================================================ */
function _resolveMeshWorkerInit(){
  if (typeof FLAGS.meshWorkerEnabled === 'boolean'){
    return FLAGS.meshWorkerEnabled;
  }
  try {
    const saved = localStorage.getItem('3dmc_mesh_worker');
    if (saved === 'on')  return true;
    if (saved === 'off') return false;
  } catch(e){}
  try {
    return getDeviceProfile().meshWorker;
  } catch(e){
    return false;
  }
}

let _meshWorkerEnabled = _resolveMeshWorkerInit();

export function setMeshWorkerEnabled(on){
  const v = !!on;
  if (v === _meshWorkerEnabled) return;
  _meshWorkerEnabled = v;
  const chunks = getChunksMap();
  for (const c of chunks.values()){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
}

export function getMeshWorkerEnabled(){ return _meshWorkerEnabled; }

/* ============================================================
   blockTable 缓存
   ============================================================ */
let _blockTable = null;

function _buildBlockTable(){
  const out = new Array(BLOCKS.length);
  for (let i = 0; i < BLOCKS.length; i++){
    const b = BLOCKS[i];
    if (!b){ out[i] = null; continue; }

    const solidIdx = TEX[b.name + '_solid'];
    /* ★ MC 风格叠加层：草方块侧面需要第二层透明贴图 */
    const overlayIdx = TEX['grass_side_overlay'];
    const overlayTiles = (b.name === 'grass' && overlayIdx !== undefined)
      ? [overlayIdx, overlayIdx, null, null, overlayIdx, overlayIdx]
      : null;
    out[i] = {
      id: b.id,
      name: b.name,
      tiles: b.tiles,
      overlayTiles,
      _solidTiles: (solidIdx === undefined)
        ? null
        : [solidIdx, solidIdx, solidIdx, solidIdx, solidIdx, solidIdx],
      opaque: b.opaque,
      occludes: b.occludes,
      mergeSame: b.mergeSame,
      solid: b.solid,
      transparent: b.transparent,
      liquid: b.liquid,
      heightRatio: b.heightRatio,
      flatRender: b.flatRender,
      isLeaves: b.isLeaves,
      emissive: b.emissive,
      cross: b.cross,
      slab: b.slab,
      stair: b.stair,
      stairDir: b.stairDir,
      waterPlant: b.waterPlant,
      waterSurface: b.waterSurface,
      tint: b.tint,
      invisible: b.invisible,
      dynamic: b.dynamic,
      model: b.model,
    };
  }
  return out;
}

function _getBlockTable(){
  if (!_blockTable) _blockTable = _buildBlockTable();
  return _blockTable;
}

export function invalidateBlockTable(){ _blockTable = null; }

/* ============================================================
   十字剔除
   ============================================================ */
let _crossCullEnabled = true;
let _crossCullDy      = 20;

export function setCrossCullEnabled(on){
  const v = !!on;
  if (v === _crossCullEnabled) return;
  _crossCullEnabled = v;
  const chunks = getChunksMap();
  for (const c of chunks.values()){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
}
export function isCrossCullEnabled(){ return _crossCullEnabled; }

export function setCrossCullDistance(dy){
  const v = Math.max(8, Math.min(128, Math.floor(Number(dy) || 20)));
  if (v === _crossCullDy) return v;
  _crossCullDy = v;
  const chunks = getChunksMap();
  for (const c of chunks.values()){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
  return _crossCullDy;
}
export function getCrossCullDistance(){ return _crossCullDy; }

const Y_DIRTY_THRESHOLD = 8;
let _playerY       = 0;
let _hasInitialY   = false;
let _lastYForDirty = 0;

/* ============================================================
   Worker 池
   ============================================================ */
function _getMeshPool(){
  if (!_meshWorkerEnabled) return null;
  try {
    return getPool();
  } catch(e){
    console.warn('[chunk] Worker 池不可用，降级主线程:', e);
    _meshWorkerEnabled = false;
    return null;
  }
}

/* ============================================================
   SAB 视图
   ============================================================ */
const _isSABView = (view) => {
  if (!USE_SAB) return false;
  if (!view) return false;
  try {
    return typeof SharedArrayBuffer !== 'undefined' &&
           view.buffer instanceof SharedArrayBuffer;
  } catch(e){ return false; }
};

/* ============================================================
   几何字节数
   ============================================================ */
function geometryBytes(g){
  let b = 0;
  try {
    const seen = new Set();
    const add = (a) => {
      if (!a || !a.array) return;
      const buf = a.array.buffer || a.array;
      if (seen.has(buf)) return;
      seen.add(buf);
      b += a.array.byteLength || (a.array.length * (a.array.BYTES_PER_ELEMENT || 4));
    };
    const names = g.getAttributeNames ? g.getAttributeNames() : Object.keys(g.attributes || {});
    for (const n of names) add(g.attributes[n]);
    add(g.index);
  } catch(e){}
  return b;
}

/* ============================================================
   ★ 从打包格式创建 Mesh
   ============================================================ */
function _mkFromPacked(packed, mat, cx, cz, minY, maxY, opts){
  if (!packed || !packed.vbuf || !packed.vcount) return null;

  const g = new THREE.BufferGeometry();
  const interleaved = new THREE.InterleavedBuffer(packed.vbuf, 16);

  g.setAttribute('position', new THREE.InterleavedBufferAttribute(interleaved, 3, 0));
  g.setAttribute('normal',   new THREE.InterleavedBufferAttribute(interleaved, 3, 3));
  g.setAttribute('color',    new THREE.InterleavedBufferAttribute(interleaved, 3, 6));
  g.setAttribute('uv',       new THREE.InterleavedBufferAttribute(interleaved, 2, 9));
  g.setAttribute('uvRect',   new THREE.InterleavedBufferAttribute(interleaved, 4, 11));
  /* ★ 方块光（0-1）：火把 / 荧石等转成独立亮度，夜里不被天光衰减带走 */
  g.setAttribute('aBlock',   new THREE.InterleavedBufferAttribute(interleaved, 1, 15));
  g.setIndex(new THREE.BufferAttribute(packed.ibuf, 1));

  const centerX = cx * CS + CS / 2;
  const centerZ = cz * CS + CS / 2;
  const centerY = (minY + maxY) / 2;
  const radiusXZ = Math.SQRT2 * CS / 2;
  const radiusY = (maxY - minY) / 2;
  const radius = Math.sqrt(radiusXZ * radiusXZ + radiusY * radiusY) + 2;

  g.boundingSphere = new THREE.Sphere(
    new THREE.Vector3(centerX, centerY, centerZ),
    radius
  );
  g.boundingBox = new THREE.Box3(
    new THREE.Vector3(cx * CS, minY, cz * CS),
    new THREE.Vector3(cx * CS + CS, maxY, cz * CS + CS)
  );

  const m = new THREE.Mesh(g, mat);
  m.castShadow    = !!opts.cast;
  m.receiveShadow = !!opts.receive;
  m.renderOrder   = opts.order || 0;
  m.matrixAutoUpdate = false;
  m.updateMatrix();
  m.frustumCulled = true;
  scene.add(m);
  return m;
}

const _toF32 = x => (x instanceof Float32Array) ? x : new Float32Array(x);
const _toU32 = x => (x instanceof Uint32Array) ? x : new Uint32Array(x);

function _mkLegacy(arr, mat, opts){
  if (!arr || !arr.p || arr.p.length === 0) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(_toF32(arr.p), 3));
  g.setAttribute('normal',   new THREE.BufferAttribute(_toF32(arr.n), 3));
  g.setAttribute('uv',       new THREE.BufferAttribute(_toF32(arr.u), 2));
  g.setAttribute('uvRect',   new THREE.BufferAttribute(_toF32(arr.r), 4));
  g.setAttribute('color',    new THREE.BufferAttribute(_toF32(arr.c), 3));
  g.setIndex(new THREE.BufferAttribute(_toU32(arr.i), 1));
  g.computeBoundingSphere();
  const m = new THREE.Mesh(g, mat);
  m.castShadow    = !!opts.cast;
  m.receiveShadow = !!opts.receive;
  m.renderOrder   = opts.order || 0;
  m.matrixAutoUpdate = false;
  m.updateMatrix();
  m.frustumCulled = true;
  scene.add(m);
  return m;
}

function _clearMeshes(chunk){
  if (chunk) emit('chunk.mesh:unload', chunk);
  const clearStart = (typeof performance !== 'undefined') ? performance.now() : 0;
  let freed = 0;
  for (const key of ['mesh', 'meshE', 'meshT', 'meshL', 'meshC']){
    if (chunk[key]){
      const geo = chunk[key].geometry;
      try { freed += geometryBytes(geo); } catch(e){}
      scene.remove(chunk[key]);
      geo.dispose();
      chunk[key] = null;
    }
  }
  if (freed > 0){
    try {
      const p = (typeof window !== 'undefined') ? (window.__perf = window.__perf || {}) : null;
      if (p){
        p.geoFreeBytes = (p.geoFreeBytes || 0) + freed;
        p.geoFrees     = (p.geoFrees || 0) + 1;
        if (clearStart){
          const d = performance.now() - clearStart;
          p.geoFreeMs    = (p.geoFreeMs || 0) + d;
          if (d > (p.geoFreeMaxMs || 0)) p.geoFreeMaxMs = d;
        }
      }
    } catch(e){}
  }
}

function _installGroups(chunk, groups){
  try {
    const p = (typeof window !== 'undefined') ? (window.__perf = window.__perf || {}) : null;
    if (p) p.installs = (p.installs || 0) + 1;
  } catch(e){}

  const minY = chunk.minY != null ? chunk.minY : Y_MIN;
  const maxY = chunk.maxY != null ? chunk.maxY : CHH - 1;
  const isPacked = !!(
    (groups.O && groups.O.vbuf) ||
    ['E', 'T', 'L', 'C'].some(k => groups[k] && groups[k].vbuf)
  );

  const install = (key, mat, opts) => {
    const g = groups[key];
    if (!g) return;
    const mesh = isPacked
      ? _mkFromPacked(g, mat, chunk.cx, chunk.cz, minY, maxY, opts)
      : _mkLegacy(g, mat, opts);
    if (mesh){
      const name = key === 'O' ? 'mesh' : ('mesh' + key);
      chunk[name] = mesh;
    }
  };

  install('O', matSolid,             { cast: true,  receive: true,  order: 0 });
  install('E', matEmissive,          { cast: false, receive: false, order: 0 });
  install('T', matTrans,             { cast: false, receive: false, order: 1 });
  install('L', getLeafMaterial(),    { cast: true,  receive: true,  order: 0 });
  install('C', matCross,             { cast: false, receive: true,  order: 1 });

  let mb = 0;
  for (const key of ['mesh', 'meshE', 'meshT', 'meshL', 'meshC']){
    if (chunk[key]) mb += geometryBytes(chunk[key].geometry);
  }
  chunk.meshBytes = mb;
  emit('chunk.mesh:install', chunk, groups, mb);

  if (mb > 0){
    try {
      const p = (typeof window !== 'undefined') ? (window.__perf = window.__perf || {}) : null;
      if (p) p.geoAllocBytes = (p.geoAllocBytes || 0) + mb;
    } catch(e){}
  }
}

/* ============================================================
   ★ 打包边界光照 (从邻居区块借用光照)
   ============================================================ */
function _buildExtLight(cx, cz, minY, maxY, getArrFn){
  const CS2 = CS + 2;
  const H = maxY - minY + 3;
  const ext = new Uint8Array(CS2 * H * CS2);
  const layerSize = CS2 * CS2;

  let nW = null, nE = null, nN = null, nS = null, nNW = null, nNE = null, nSW = null, nSE = null, center = null;
  try {
    nW  = getChunkRaw(cx - 1, cz);
    nE  = getChunkRaw(cx + 1, cz);
    nN  = getChunkRaw(cx, cz - 1);
    nS  = getChunkRaw(cx, cz + 1);
    nNW = getChunkRaw(cx - 1, cz - 1);
    nNE = getChunkRaw(cx + 1, cz - 1);
    nSW = getChunkRaw(cx - 1, cz + 1);
    nSE = getChunkRaw(cx + 1, cz + 1);
    center = getChunkRaw(cx, cz);
  } catch(e) {
    console.warn('[chunk] 获取邻居区块失败:', e);
  }

  function readLight(c, lx, wy, lz) {
    if (!c) return 0;
    const arr = getArrFn(c);
    if (!arr) return 0;
    if (wy < Y_MIN || wy >= CHH) return 0;
    const i = (((wy - Y_MIN) * CS) + lz) * CS + lx;
    return arr[i] || 0;
  }

  for (let dy = 0; dy < H; dy++){
    const y = minY - 1 + dy;
    if (y < Y_MIN || y >= CHH) continue;
    const yBase = dy * layerSize;

    if (center) {
      for (let lz = 0; lz < CS; lz++) {
        for (let lx = 0; lx < CS; lx++) {
          ext[yBase + (lz + 1) * CS2 + (lx + 1)] = readLight(center, lx, y, lz);
        }
      }
    }

    const rowN = yBase;
    for (let lx = 0; lx < CS; lx++) ext[rowN + (lx + 1)] = readLight(nN, lx, y, CS - 1);
    const rowS = yBase + (CS + 1) * CS2;
    for (let lx = 0; lx < CS; lx++) ext[rowS + (lx + 1)] = readLight(nS, lx, y, 0);

    for (let lz = 0; lz < CS; lz++) ext[yBase + (lz + 1) * CS2 + 0] = readLight(nW, CS - 1, y, lz);
    for (let lz = 0; lz < CS; lz++) ext[yBase + (lz + 1) * CS2 + (CS + 1)] = readLight(nE, 0, y, lz);

    ext[yBase + 0] = readLight(nNW, CS - 1, y, CS - 1);
    ext[yBase + (CS + 1)] = readLight(nNE, 0, y, CS - 1);
    ext[yBase + (CS + 1) * CS2] = readLight(nSW, CS - 1, y, 0);
    ext[yBase + (CS + 1) * CS2 + (CS + 1)] = readLight(nSE, 0, y, 0);
  }
  return ext;
}

function _buildMeshSync(chunk){
  if (!chunk || !chunk.blocks) return;
  _clearMeshes(chunk);

  const minY = chunk.minY != null ? Math.max(Y_MIN, chunk.minY) : Y_MIN;
  const maxY = Math.min(CHH - 1, chunk.maxY + 1);

  const groups = buildChunkGeometry({
    cx: chunk.cx,
    cz: chunk.cz,
    blocks: chunk.blocks,
    topY: chunk.topY,
    minY: chunk.minY,
    maxY: chunk.maxY,
    blockTable: _getBlockTable(),
    uvRectTable: UVRECT,
    leafAlpha: getLeafAlpha(),
    crossCull: {
      enabled: _crossCullEnabled,
      dy: _crossCullDy,
      playerY: _playerY,
    },
    getBlockAt: getBlockWorld,
    getFluidLevel,
    isLoaded: isWorldBlockLoaded,
    Y_MIN, CHH,
    tintMapGrass: chunk.tintMapGrass,
    tintMapFoliage: chunk.tintMapFoliage,
    tintMapMagic: chunk.tintMapMagic,   // [magic-dust] mesh-sync
    skyLight: chunk.skyLight,
    blockLight: chunk.blockLight,
    extSkyLight: _buildExtLight(chunk.cx, chunk.cz, minY, maxY, c => c.skyLight),
    extBlockLight: _buildExtLight(chunk.cx, chunk.cz, minY, maxY, c => c.blockLight),
    waterMode: _waterMode,
  });

  _installGroups(chunk, groups);
  chunk.dirty = false;
}

function _readBlockFromChunk(c, lx, wy, lz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  return c.blocks[(((wy - Y_MIN) * CS) + lz) * CS + lx];
}

function _buildExtBlocks(cx, cz, minY, maxY){
  const CS2 = CS + 2;
  const H = maxY - minY + 3;
  const ext = new Uint8Array(CS2 * H * CS2);
  const layerSize = CS2 * CS2;

  const nW  = getChunkRaw(cx - 1, cz);
  const nE  = getChunkRaw(cx + 1, cz);
  const nN  = getChunkRaw(cx, cz - 1);
  const nS  = getChunkRaw(cx, cz + 1);
  const nNW = getChunkRaw(cx - 1, cz - 1);
  const nNE = getChunkRaw(cx + 1, cz - 1);
  const nSW = getChunkRaw(cx - 1, cz + 1);
  const nSE = getChunkRaw(cx + 1, cz + 1);

  for (let dy = 0; dy < H; dy++){
    const y = minY - 1 + dy;
    if (y < Y_MIN || y >= CHH) continue;
    const yBase = dy * layerSize;

    const rowN = yBase;
    for (let lx = 0; lx < CS; lx++){
      ext[rowN + (lx + 1)] = nN
        ? _readBlockFromChunk(nN, lx, y, CS - 1)
        : 0;
    }

    const rowS = yBase + (CS + 1) * CS2;
    for (let lx = 0; lx < CS; lx++){
      ext[rowS + (lx + 1)] = nS
        ? _readBlockFromChunk(nS, lx, y, 0)
        : 0;
    }

    for (let lz = 0; lz < CS; lz++){
      ext[yBase + (lz + 1) * CS2 + 0] = nW
        ? _readBlockFromChunk(nW, CS - 1, y, lz)
        : 0;
    }

    for (let lz = 0; lz < CS; lz++){
      ext[yBase + (lz + 1) * CS2 + (CS + 1)] = nE
        ? _readBlockFromChunk(nE, 0, y, lz)
        : 0;
    }

    ext[yBase + 0]                                  = nNW ? _readBlockFromChunk(nNW, CS - 1, y, CS - 1) : 0;
    ext[yBase + (CS + 1)]                           = nNE ? _readBlockFromChunk(nNE, 0,      y, CS - 1) : 0;
    ext[yBase + (CS + 1) * CS2]                     = nSW ? _readBlockFromChunk(nSW, CS - 1, y, 0)      : 0;
    ext[yBase + (CS + 1) * CS2 + (CS + 1)]          = nSE ? _readBlockFromChunk(nSE, 0,      y, 0)      : 0;
  }
  return ext;
}

let _playerCx = 0, _playerCz = 0;
let _playerFx = 0, _playerFz = -1;

export function computeChunkPriority(dx, dz){
  const d2 = dx * dx + dz * dz;
  if (d2 < 0.0001) return 0;
  const dist = Math.sqrt(d2);
  const dot = (dx * _playerFx + dz * _playerFz) / dist;
  return Math.max(0, dist * (1 - dot * 0.5));
}

function _meshPriorityFor(chunk){
  return computeChunkPriority(
    chunk.cx - _playerCx,
    chunk.cz - _playerCz
  );
}

function _submitMeshTask(chunk, pool){
  chunk.meshing = true;
  chunk.meshGen = chunk.dirtyGen || 0;

  const minY = chunk.minY != null ? Math.max(Y_MIN, chunk.minY) : Y_MIN;
  const maxY = Math.min(CHH - 1, chunk.maxY + 1);

  const extBlocks = _buildExtBlocks(chunk.cx, chunk.cz, minY, maxY);
  const extSkyLightArg = _buildExtLight(chunk.cx, chunk.cz, minY, maxY, c => c.skyLight);
  const extBlockLightArg = _buildExtLight(chunk.cx, chunk.cz, minY, maxY, c => c.blockLight);

  const transfers = [extBlocks.buffer, extSkyLightArg.buffer, extBlockLightArg.buffer];
  let blocksArg = chunk.blocks;
  let fluidArg  = chunk.fluid;
  let skyLightArg = chunk.skyLight ? chunk.skyLight.slice() : null;
  let blockLightArg = chunk.blockLight ? chunk.blockLight.slice() : null;
  
  if (skyLightArg) transfers.push(skyLightArg.buffer);
  if (blockLightArg) transfers.push(blockLightArg.buffer);

  if (_isSABView(blocksArg)){
    blocksArg = chunk.blocks.buffer;
  } else {
    blocksArg = chunk.blocks.slice();
    transfers.push(blocksArg.buffer);
  }

  if (_isSABView(fluidArg)){
    fluidArg = chunk.fluid.buffer;
  } else {
    fluidArg = chunk.fluid.slice();
    transfers.push(fluidArg.buffer);
  }

  pool.post(MSG.GEN_MESH, {
    cx: chunk.cx, cz: chunk.cz,
    minY, maxY,
    blocks: blocksArg,
    fluid:  fluidArg,
    extBlocks,
    skyLight: skyLightArg,
    blockLight: blockLightArg,
    extSkyLight: extSkyLightArg,
    extBlockLight: extBlockLightArg,
    leafAlpha: getLeafAlpha(),
    crossCull: {
      enabled: _crossCullEnabled,
      dy: _crossCullDy,
      playerY: _playerY,
    },
    tintMapGrass:   chunk.tintMapGrass,
    tintMapFoliage: chunk.tintMapFoliage,
    tintMapMagic:   chunk.tintMapMagic,   // [magic-dust] mesh-worker
    waterMode: _waterMode,
  }, transfers, undefined, _meshPriorityFor(chunk))
  .then(res => _handleMeshResult(chunk, res))
  .catch(e => {
    console.warn(`[chunk] mesh worker ${chunk.cx},${chunk.cz} 失败:`, e);
    chunk.meshing = false;
    chunk.dirty = true;
  });
}

const _meshResultQueue = [];
const MESH_RESULT_PER_FRAME = 1;
const MESH_INSTALL_TIME_BUDGET = 2.0;

function _clampNum(v, lo, hi){ return v < lo ? lo : (v > hi ? hi : v); }

function _handleMeshResult(chunk, result){
  if (!chunk.meshing) return;
  if (!chunk.blocks) return;
  _meshResultQueue.push({ chunk, result });
}

function _drainMeshResults(workMs){
  const _budgetMs = (typeof workMs === 'number' && isFinite(workMs))
    ? workMs : MESH_INSTALL_TIME_BUDGET;
  const _maxCount = _budgetMs > 2.5 ? 2 : MESH_RESULT_PER_FRAME;

  let n = 0;
  const start = performance.now();
  while (_meshResultQueue.length > 0 && n < _maxCount){
    if (performance.now() - start > _budgetMs) break;

    const { chunk, result } = _meshResultQueue.shift();
    if (!chunk.meshing || !chunk.blocks) continue;

    const groups = result.groups || result;

    _clearMeshes(chunk);
    _installGroups(chunk, groups);
    chunk.meshing = false;
    if ((chunk.dirtyGen || 0) === (chunk.meshGen || 0)){
      chunk.dirty = false;
    } else {
      chunk.dirty = true;
    }
    n++;
  }
}

export function buildMesh(chunk){
  if (!chunk || !chunk.blocks) return;
  if (_inBatch) { _batchDirtyChunks.add(chunk); return; }
  emit('chunk.mesh:build', chunk);

  if (chunk.meshing){
    chunk.dirty = true;
    return;
  }

  const pool = _getMeshPool();
  if (pool){
    _submitMeshTask(chunk, pool);
    return;
  }

  _buildMeshSync(chunk);
}

export function rebuildAllChunks(){
  const chunks = getChunksMap();
  for (const c of chunks.values()){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
}

let _effRenderDist = 0;
export function getEffectiveRenderDist(){ return _effRenderDist || 0; }

let _waterMode = 'vanilla';
export function setWaterRenderMode(mode){
  if (_waterMode === mode) return;
  _waterMode = mode;
  rebuildAllChunks();
}

let _inBatch = false;
let _batchDirtyChunks = new Set();
on('chunk.batch:start', () => { _inBatch = true; _batchDirtyChunks.clear(); });
on('chunk.batch:end', () => {
  _inBatch = false;
  for (const c of _batchDirtyChunks) c.dirty = true;
  _batchDirtyChunks.clear();
});

const UNLOAD_TIME_BUDGET = 3.0;

const _YAW_BUCKETS = 16;
const _SIG_RECHECK_FRAMES = 60;

let _lastChunkSetSize = -1;
let _sigTick = 0;
const _needCache = { key: '', offX: null, offZ: null, count: 0 };

function _yawBucketOf(yaw){
  let t = (yaw || 0) / (Math.PI * 2);
  t -= Math.floor(t);
  const b = Math.floor(t * _YAW_BUCKETS);
  return b >= _YAW_BUCKETS ? _YAW_BUCKETS - 1 : b;
}

function _getNeedOffsets(R, yawBucket){
  const key = R + ':' + yawBucket;
  if (_needCache.key === key) return _needCache;

  const list = [];
  for (let dx = -R; dx <= R; dx++){
    for (let dz = -R; dz <= R; dz++){
      if (dx * dx + dz * dz > R * R + R) continue;
      list.push({ dx, dz, d: computeChunkPriority(dx, dz) });
    }
  }
  list.sort((a, b) => a.d - b.d);

  const n = list.length;
  const offX = new Int16Array(n);
  const offZ = new Int16Array(n);
  for (let i = 0; i < n; i++){
    offX[i] = list[i].dx;
    offZ[i] = list[i].dz;
  }
  _needCache.key = key;
  _needCache.offX = offX;
  _needCache.offZ = offZ;
  _needCache.count = n;
  return _needCache;
}

export function updateChunks(playerPos, playerYaw, renderDist, IS_TOUCH, dynamicBudget, frameHeadroomMs){
  const chunks = getChunksMap();

  const pcx = Math.floor(playerPos.x / CS);
  const pcz = Math.floor(playerPos.z / CS);
  const pcy = playerPos.y;

  _playerY = pcy;

  _playerCx = pcx;
  _playerCz = pcz;
  _playerFx = -Math.sin(playerYaw || 0);
  _playerFz = -Math.cos(playerYaw || 0);

  const _yDirtyStep = Math.max(Y_DIRTY_THRESHOLD, _crossCullDy);

  if (!_hasInitialY){
    _hasInitialY = true;
    _lastYForDirty = pcy;
  } else if (_crossCullEnabled && Math.abs(pcy - _lastYForDirty) > _yDirtyStep){
    _lastYForDirty = pcy;
    for (const c of chunks.values()){
      if (c.meshC){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
    }
  }

  _effRenderDist = renderDist;

  const keep = renderDist + 4;

  const _hr = (typeof frameHeadroomMs === 'number' && isFinite(frameHeadroomMs))
    ? frameHeadroomMs : 6;

  const _unloadCap = _hr > 6 ? 3 : (_hr > 3 ? 2 : 1);
  let _unloaded = 0;

  const unloadStart = performance.now();
  for (const c of chunks.values()){
    if (_unloaded >= _unloadCap) break;
    if (performance.now() - unloadStart > UNLOAD_TIME_BUDGET) break;
    const d = Math.max(Math.abs(c.cx - pcx), Math.abs(c.cz - pcz));
    if (d > keep){ unloadChunk(c); _unloaded++; }
  }

  const R = renderDist;
  const offs = _getNeedOffsets(R, _yawBucketOf(playerYaw));
  const offX = offs.offX, offZ = offs.offZ, nNeed = offs.count;

  if (chunks.size !== _lastChunkSetSize || ++_sigTick >= _SIG_RECHECK_FRAMES){
    _sigTick = 0;
    _lastChunkSetSize = chunks.size;

    for (let i = 0; i < nNeed; i++){
      const cx = pcx + offX[i], cz = pcz + offZ[i];
      const c = chunks.get(chunkKey(cx, cz));
      if (!c) continue;
      if (!c.mesh && !c.meshing) continue;

      let sig = 0;
      for (let dx = -1; dx <= 1; dx++){
        for (let dz = -1; dz <= 1; dz++){
          sig = (sig << 1) | (chunks.has(chunkKey(cx + dx, cz + dz)) ? 1 : 0);
        }
      }
      if (c._nbsig !== sig){
        c._nbsig = sig;
        if (c.mesh){ c.dirty = true; c.dirtyGen = (c.dirtyGen || 0) + 1; }
      }
    }
  }

  const _workMs = _clampNum(_hr * 0.5, 0.5, 5);

  let genBudget = _hr > 5 ? 2 : 1;
  const genStart = performance.now();
  for (let i = 0; i < nNeed; i++){
    if (genBudget <= 0) break;
    if (performance.now() - genStart > _workMs) break;
    const cx = pcx + offX[i], cz = pcz + offZ[i];
    if (!chunks.has(chunkKey(cx, cz))){
      getChunkDecorated(cx, cz);
      genBudget--;
    }
  }

  let meshBudget = typeof dynamicBudget === 'number'
    ? dynamicBudget
    : (IS_TOUCH ? 2 : 3) + (CHH > 200 ? 1 : 0);

  if (_meshWorkerEnabled) meshBudget = Math.max(1, Math.min(meshBudget, 2));

  const meshStart = performance.now();
  for (let i = 0; i < nNeed; i++){
    if (meshBudget <= 0) break;
    if (performance.now() - meshStart > _workMs) break;

    const cx = pcx + offX[i], cz = pcz + offZ[i];
    const c = chunks.get(chunkKey(cx, cz));
    if (!c) continue;
    if (!c.ready) continue;
    if (c.meshing) continue;
    if (c.mesh && !c.dirty) continue;

    let ready = true;
    outer: for (let dx = -1; dx <= 1; dx++){
      for (let dz = -1; dz <= 1; dz++){
        const nc = chunks.get(chunkKey(cx + dx, cz + dz));
        if (!nc || !nc.ready){
          ready = false;
          break outer;
        }
      }
    }
    if (!ready) continue;

    buildMesh(c);
    meshBudget--;
  }

  _drainMeshResults(_workMs);
  emit('chunk.update:done', chunks.size);
}
