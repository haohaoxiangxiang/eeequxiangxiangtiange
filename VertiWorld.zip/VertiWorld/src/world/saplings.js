/* ============================================================
   saplings.js —— 树苗生长
   ------------------------------------------------------------
   · 玩家放下的树苗会登记进生长队列，过一段时间长成该群系
     最常见的树（橡木 / 云杉 / 樱花 / 红树）。
   · 区块重新载入后，从 edits 里重新收集树苗，避免"存档后
     再也不长"的问题。
   · 树干空间不足时自动延后重试。
   ============================================================ */

import { on } from '../core/engine-core.js';
import { B } from './blocks.js';
import { getBlockWorld, setBlockWorld, biomeAt, isWorldBlockLoaded, forEachEditInChunk } from './terrain.js';
import { getBiome } from './world-core.js';


const TREE_DEFS = {
  oak:     { trunkH: () => 4 + Math.floor(Math.random() * 3), leafR: 2.3, leafRY: 2.0, scale: 1.0 },
  spruce:  { trunkH: () => 6 + Math.floor(Math.random() * 4), leafR: 2.3, leafRY: 2.0, scale: 0.85 },
  sakura:  { trunkH: () => 4 + Math.floor(Math.random() * 2), leafR: 3.0, leafRY: 1.5, scale: 1.0 },
  mangrove:{ trunkH: () => 4 + Math.floor(Math.random() * 3), leafR: 2.6, leafRY: 1.4, scale: 1.0 },
};

const entries = new Map();     // "x,y,z" -> { x, y, z, growAt }
let inited = false;
let saplingId = 0;

const MIN_GROW_MS = 120000;    // 2 分钟
const MAX_GROW_MS = 300000;    // 5 分钟
const GROW_DIST   = 96;        // 玩家超过这个距离时先不长，避免远处白算


function keyOf(x, y, z){
  return x + ',' + y + ',' + z;
}

function register(x, y, z){
  const k = keyOf(x, y, z);
  if (entries.has(k)) return;
  const now = performance.now();
  entries.set(k, {
    x, y, z,
    growAt: now + MIN_GROW_MS + Math.random() * (MAX_GROW_MS - MIN_GROW_MS),
  });
}

function scanChunk(chunk){
  if (!chunk || chunk.cx === undefined) return;
  forEachEditInChunk(chunk.cx, chunk.cz, (x, y, z, rec) => {
    if (rec && rec.id === saplingId) register(x, y, z);
  });
}

function onBlockChanged(x, y, z, oldId, newId){
  if (newId === saplingId){
    register(x, y, z);
  } else if (oldId === saplingId){
    entries.delete(keyOf(x, y, z));
  }
}

function pickSpecies(x, y, z){
  let list = [];
  try {
    const b = getBiome(biomeAt(x, z, y));
    if (b && Array.isArray(b.treeTypes)) list = b.treeTypes;
  } catch(e){ /* 群系查询失败就用橡木 */ }
  const valid = list.filter(t => TREE_DEFS[t] && B[t + '_log'] && B[t + '_leaves'] && B[t + '_log'].id && B[t + '_leaves'].id);
  return valid.length ? valid[Math.floor(Math.random() * valid.length)] : 'oak';
}

/* 返回 'grown' | 'blocked' | 'gone' */
function growSapling(x, y, z){
  if (getBlockWorld(x, y, z) !== saplingId) return 'gone';

  const species = pickSpecies(x, y, z);
  const def = TREE_DEFS[species] || TREE_DEFS.oak;
  const logBlock = B[species + '_log'] || B.oak_log;
  const leafBlock = B[species + '_leaves'] || B.oak_leaves;
  if (!logBlock || !leafBlock) return 'blocked';
  const logId = logBlock.id;
  const leafId = leafBlock.id;

  const trunkH = def.trunkH();
  for (let i = 1; i < trunkH; i++){
    if (getBlockWorld(x, y + i, z) !== 0) return 'blocked';
  }

  for (let i = 0; i < trunkH; i++){
    setBlockWorld(x, y + i, z, logId);
  }

  const top = y + trunkH - 1;
  const R  = def.leafR * def.scale;
  const RY = def.leafRY * def.scale;
  for (let dx = -4; dx <= 4; dx++){
    for (let dz = -4; dz <= 4; dz++){
      for (let dy = -2; dy <= 4; dy++){
        const d = Math.sqrt(
          (dx * dx) / (R * R) +
          (dy * dy) / ((RY + 0.4) * (RY + 0.4)) +
          (dz * dz) / (R * R)
        );
        if (d > 1.05) continue;
        if (Math.abs(dx) >= 4 && Math.abs(dz) >= 4) continue;
        if (getBlockWorld(x + dx, top + dy, z + dz) === 0){
          setBlockWorld(x + dx, top + dy, z + dz, leafId);
        }
      }
    }
  }
  return 'grown';
}

export function updateSaplings(dt, playerPos){
  if (!inited) return;
  const now = performance.now();
  let grownThisTick = 0;

  for (const [k, e] of entries){
    if (grownThisTick >= 2) break;
    if (now < e.growAt) continue;

    if (!isWorldBlockLoaded(e.x, e.y, e.z)){
      e.growAt = now + 5000;
      continue;
    }
    if (getBlockWorld(e.x, e.y, e.z) !== saplingId){
      entries.delete(k);
      continue;
    }

    if (playerPos){
      const dx = e.x - playerPos.x;
      const dz = e.z - playerPos.z;
      if (dx * dx + dz * dz > GROW_DIST * GROW_DIST) continue;
    }

    const res = growSapling(e.x, e.y, e.z);
    if (res === 'grown'){
      entries.delete(k);
      grownThisTick++;
    } else if (res === 'blocked'){
      e.growAt = now + 8000 + Math.random() * 12000;
    } else {
      entries.delete(k);
    }
  }
}

export function initSaplings(){
  if (inited) return;
  inited = true;
  saplingId = B.sapling ? B.sapling.id : 0;
  if (!saplingId){
    console.warn('[saplings] 树苗方块未注册，生长系统停用');
    return;
  }
  on('chunk.decorate', (chunk) => { try { scanChunk(chunk); } catch(e){} });
  on('world.blockChanged', onBlockChanged);
}
