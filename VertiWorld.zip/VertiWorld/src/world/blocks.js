import { registerBlock, freezeBlocks } from './world-registry.js';

/* ============================================================
   注册入口
   ------------------------------------------------------------
   所有方块通过 registerBlock 注册，id 由注册器按顺序分配。
   末尾 freezeBlocks 冻结，冻结后 B / BLOCKS 就是普通对象。

   ★ M5：unknown_block 在 freezeBlocks() 之前注册，
     保证它是"内置方块"——mod 卸载后仍可用它做占位。
   ★ 新增：tint: 'grass' / 'foliage'，供群系染色使用。
   ============================================================ */

/* ============ 空气（id = 0） ============ */
registerBlock('air', '空气', {
  noTex: true,
  opaque: false, occludes: false, mergeSame: false,
  solid: false, transparent: true, liquid: false,
  hardness: 0,
  emissive: 0, requiresTool: false, tool: null, minTier: 0,
  heightRatio: 1, isLeaves: false, flatRender: false,
  tag: null, isItem: false, toolType: null, material: null,
  speed: 1, tier: 0, maxStack: 64, durability: 0, bucketType: null,
  waterPlant: false, waterSurface: false,
});

/* ============ 自然方块 ============ */
registerBlock('grass', '草方块',   { tex: { top: 'grass_top', side: 'grass_side', bottom: 'dirt' }, hardness: 0.6, tool: 'shovel', tint: 'grass' });
registerBlock('dirt', '泥土',      { tex: { all: 'dirt' }, hardness: 0.5, tool: 'shovel' });
registerBlock('stone', '石头',     { tex: { all: 'stone' }, hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone' });
registerBlock('cobble', '圆石',    { tex: { all: 'cobble' }, hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone' });
registerBlock('sand', '沙子',      { tex: { all: 'sand' }, hardness: 0.5, tool: 'shovel' });
registerBlock('sandstone', '砂岩', { tex: { all: 'sandstone' }, hardness: 0.8, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('gravel', '砂砾',    { tex: { all: 'gravel' }, hardness: 0.6, tool: 'shovel' });
registerBlock('clay', '黏土',      { tex: { all: 'clay' }, hardness: 0.6, tool: 'shovel' });

/* 三种原木 */
registerBlock('oak_log',    '橡木原木',  { tex: { top: 'oak_log_top',    side: 'oak_log_side',    bottom: 'oak_log_top' },    hardness: 2, tool: 'axe', tag: 'log' });
registerBlock('spruce_log', '云杉原木',  { tex: { top: 'spruce_log_top', side: 'spruce_log_side', bottom: 'spruce_log_top' }, hardness: 2, tool: 'axe', tag: 'log' });
registerBlock('sakura_log', '樱花原木',  { tex: { top: 'sakura_log_top', side: 'sakura_log_side', bottom: 'sakura_log_top' }, hardness: 2, tool: 'axe', tag: 'log' });

/* 三种树叶：不遮挡、不合并同类、不透明 */
registerBlock('oak_leaves', '橡木树叶', {
  tex: { all: 'oak_leaves' }, hardness: 0.2,
  isLeaves: true,
  opaque: false, occludes: false, mergeSame: false,
  leafColors: [0x58a63a, 0x6ec24a, 0x3e7a28], tool: 'shears', tint: 'foliage',
  lightFilter: 1,
});
registerBlock('spruce_leaves', '云杉树叶', {
  tex: { all: 'spruce_leaves' }, hardness: 0.2,
  isLeaves: true,
  opaque: false, occludes: false, mergeSame: false,
  leafColors: [0x3d7a3a, 0x4d8d46, 0x2a5a28], tool: 'shears', tint: 'foliage',
  lightFilter: 1,
});
registerBlock('sakura_leaves', '樱花树叶', {
  tex: { all: 'sakura_leaves' }, hardness: 0.2,
  isLeaves: true,
  opaque: false, occludes: false, mergeSame: false,
  leafColors: [0xffb6d0, 0xffc9dd, 0xe89ab8], tool: 'shears', tint: 'foliage',
  lightFilter: 1,
});

/* 三种木板 */
registerBlock('oak_planks',    '橡木木板', { tex: { all: 'oak_planks' },    hardness: 2, tool: 'axe', tag: 'planks' });
registerBlock('spruce_planks', '云杉木板', { tex: { all: 'spruce_planks' }, hardness: 2, tool: 'axe', tag: 'planks' });
registerBlock('sakura_planks', '樱花木板', { tex: { all: 'sakura_planks' }, hardness: 2, tool: 'axe', tag: 'planks' });

/* 花毯 */
registerBlock('petals', '粉色花毯', {
  tex: { all: 'petals' }, hardness: 0.2,
  heightRatio: 1/16, flatRender: true,
  opaque: false, occludes: false, solid: false
});

/* 玻璃 */
registerBlock('glass', '玻璃', {
  tex: { all: 'glass' }, hardness: 0.4,
  transparent: true, opaque: false, occludes: false, mergeSame: true
});

/* 水 */
registerBlock('water', '水', {
  tex: { all: 'water' }, hardness: 0,
  transparent: true, opaque: false, occludes: false, mergeSame: true,
  solid: false, liquid: true,
  lightFilter: 1,
});

/* 冰：半透明但遮挡 */
registerBlock('ice', '冰', {
  tex: { all: 'ice' }, hardness: 0.5,
  transparent: true, opaque: false, occludes: true, mergeSame: true,
  tool: 'pickaxe', minTier: 1,
  lightFilter: 1,
});

registerBlock('snow', '雪块', { tex: { all: 'snow' }, hardness: 0.4, tool: 'shovel' });

registerBlock('prismarine',        '海晶石',   { tex: { all: 'prismarine' },        hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('prismarine_bricks', '海晶石砖', { tex: { all: 'prismarine_bricks' }, hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('dark_prismarine',   '暗海晶石', { tex: { all: 'dark_prismarine' },   hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('sea_lantern', '海晶灯', { tex: { all: 'sea_lantern' }, hardness: 0.5, emissive: 1, light: 15 });
registerBlock('glowstone',   '荧石',   { tex: { all: 'glowstone' },   hardness: 0.5, emissive: 1, light: 15 });

registerBlock('diamond',  '钻石块', { tex: { all: 'diamond' },  hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 3 });
registerBlock('gold',     '金块',   { tex: { all: 'gold' },     hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 3 });
registerBlock('cactus',   '仙人掌', { tex: { all: 'cactus' },   hardness: 0.6 });
registerBlock('obsidian', '黑曜石', { tex: { all: 'obsidian' }, hardness: 5, requiresTool: true, tool: 'pickaxe', minTier: 4 });

/* 岩浆 */
registerBlock('lava', '熔岩', {
  tex: { all: 'lava' }, hardness: 0,
  transparent: true, opaque: false, occludes: false, mergeSame: false,
  solid: false, liquid: true, emissive: 1, light: 15, lightFilter: 1,
});

registerBlock('bedrock',      '基岩',   { tex: { all: 'bedrock' },      hardness: 9999 });
registerBlock('stone_bricks', '石砖',   { tex: { all: 'stone_bricks' }, hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('mossy_stone',  '苔石',   { tex: { all: 'mossy_stone' },  hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('mossy_stone_bricks', '青石砖', {
  tex: { all: 'mossy_stone_bricks' }, hardness: 2,
  requiresTool: true, tool: 'pickaxe', minTier: 1,
});

/* ============ 合成材料 ============ */
registerBlock('stick',       '木棍', { tex: { all: 'stick' },       hardness: 0.1, isItem: true, tag: 'stick' });
registerBlock('coal',        '煤炭', { tex: { all: 'coal' },        hardness: 0.5, isItem: true, tag: 'coal' });
registerBlock('iron_ingot',  '铁锭', { tex: { all: 'iron_ingot' },  hardness: 1, isItem: true, tag: 'iron_ingot' });
registerBlock('copper_ingot','铜锭', { tex: { all: 'copper_ingot' }, hardness: 1, isItem: true, tag: 'copper_ingot' });
registerBlock('gold_ingot',  '金锭', { tex: { all: 'gold_ingot' },  hardness: 1, isItem: true, tag: 'gold_ingot' });
registerBlock('diamond_gem', '钻石', { tex: { all: 'diamond_gem' }, hardness: 1, isItem: true, tag: 'diamond_gem' });
registerBlock('string',      '线',   { tex: { all: 'string' },      hardness: 0.1, isItem: true, tag: 'string' });
registerBlock('arrow',       '箭',   { tex: { all: 'arrow' },       hardness: 0.1, isItem: true, tag: 'arrow' });

/* ============ 矿石 ============ */
registerBlock('coal_ore',    '煤矿石',   { tex: { all: 'coal_ore' },    hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('copper_ore',  '铜矿石',   { tex: { all: 'copper_ore' },  hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 1 });
registerBlock('iron_ore',    '铁矿石',   { tex: { all: 'iron_ore' },    hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 2 });
registerBlock('gold_ore',    '金矿石',   { tex: { all: 'gold_ore' },    hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 3 });
registerBlock('diamond_ore', '钻石矿石', { tex: { all: 'diamond_ore' }, hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 3 });

/* ============ 工作台 / 熔炉 ============ */
registerBlock('crafting_table', '工作台', {
  tex: { top: 'crafting_table_top', side: 'crafting_table_side', bottom: 'oak_planks' },
  hardness: 2.5, tool: 'axe'
});

/* 熔炉：有正面的方块。
   ------------------------------------------------------------
   正面朝 0=北 1=东 2=南 3=西，共 4 个朝向 × 燃烧 / 未燃烧 = 8 个变体。
   只有 base 可放置 / 出现在创造面板；放置时按"正面朝玩家"选变体，
   燃烧时由 items-logic 换成 _lit 变体（炉口发橙红光 + 照亮周围）。 */
const FURNACE_DIR_SUFFIX = ['', '_e', '_s', '_w'];

function defFurnace(name, label, dir, lit){
  return registerBlock(name, label, {
    tex: {
      top: 'furnace_top', side: 'furnace_side', bottom: 'furnace_top',
      front: lit ? 'furnace_front_lit' : 'furnace_front',
    },
    frontDir: dir,
    orientDir: dir,
    orientBase: 'furnace',
    hardness: 2.5, requiresTool: true, tool: 'pickaxe', minTier: 1,
    interactive: 'furnace',
    hidden: name !== 'furnace',
    placeable: name === 'furnace',
    light: lit ? 13 : 0,
  });
}

for (let d = 0; d < 4; d++){
  defFurnace('furnace' + FURNACE_DIR_SUFFIX[d], '熔炉', d, false);
  defFurnace('furnace' + FURNACE_DIR_SUFFIX[d] + '_lit', '熔炉（燃烧）', d, true);
}

/* 火把：木棍 + 火头。发光 14（方块发光上限，15 留给以后的功能）。 */
registerBlock('torch', '火把', {
  tex: { all: 'torch_stick' },
  icon: 'torch',
  hardness: 0.1,
  emissive: 1, light: 14,
  opaque: false, occludes: false, solid: false,
  category: 'functional',
  model: { boxes: [
    { x0: 7, y0: 0, z0: 7, x1: 9, y1: 10, z1: 9,
      tex: { all: 'torch_stick' } },
    { x0: 6, y0: 10, z0: 6, x1: 10, y1: 15, z1: 10,
      tex: { all: 'torch_flame' } },
  ] },
});

/* ============ 工具 ============ */
const MAT_TIER  = { wood: 1, stone: 2, copper: 2, gold: 2, iron: 3, diamond: 4 };
const MAT_DUR   = { wood: 59, stone: 131, copper: 180, gold: 32, iron: 250, diamond: 1561 };
/* 挖掘倍率整体下调：铁镐/铁斧不再过快，保持逐级提升 */
const MAT_SPEED = { wood: 1.8, stone: 2.6, copper: 3.4, gold: 9, iron: 4.5, diamond: 6 };
/* 近战伤害：空手 0.5，剑最高 5.5 */
const MAT_ATK = {
  sword:   { wood: 2.0, stone: 3.0, copper: 3.5, gold: 3.0, iron: 4.5, diamond: 5.5 },
  axe:     { wood: 1.5, stone: 2.5, copper: 2.5, gold: 2.5, iron: 3.0, diamond: 3.5 },
  pickaxe: { wood: 0.75, stone: 1.25, copper: 1.25, gold: 1.25, iron: 1.75, diamond: 2.25 },
  shovel:  { wood: 0.75, stone: 1.25, copper: 1.25, gold: 1.25, iron: 1.75, diamond: 2.25 },
  hoe:     { wood: 0.5, stone: 1.0, copper: 1.0, gold: 1.0, iron: 1.25, diamond: 1.5 },
};
const MAT_LABEL = { wood: '木', stone: '石', copper: '铜', gold: '金', iron: '铁', diamond: '钻石' };

function defTool(name, label, opts, extra){
  return registerBlock(name, label, {
    tex: { all: name }, hardness: 0.1, isItem: true,
    toolType: opts.toolType, material: opts.material,
    speed: opts.speed, tier: opts.tier, durability: opts.durability,
    attack: opts.attack || 0,
    maxStack: 1, tag: 'tool',
    ...(extra || {})
  });
}

for (const mat of ['wood', 'stone', 'copper', 'gold', 'iron', 'diamond']){
  defTool(`${mat}_pickaxe`, `${MAT_LABEL[mat]}镐`,
    { toolType: 'pickaxe', material: mat, speed: MAT_SPEED[mat], tier: MAT_TIER[mat], durability: MAT_DUR[mat], attack: MAT_ATK.pickaxe[mat] });
  defTool(`${mat}_axe`, `${MAT_LABEL[mat]}斧`,
    { toolType: 'axe', material: mat, speed: MAT_SPEED[mat], tier: MAT_TIER[mat], durability: MAT_DUR[mat], attack: MAT_ATK.axe[mat] });
  defTool(`${mat}_sword`, `${MAT_LABEL[mat]}剑`,
    { toolType: 'sword', material: mat, speed: 1.5, tier: MAT_TIER[mat], durability: MAT_DUR[mat], attack: MAT_ATK.sword[mat] });
  defTool(`${mat}_shovel`, `${MAT_LABEL[mat]}锹`,
    { toolType: 'shovel', material: mat, speed: MAT_SPEED[mat], tier: MAT_TIER[mat], durability: MAT_DUR[mat], attack: MAT_ATK.shovel[mat] });
  defTool(`${mat}_hoe`, `${MAT_LABEL[mat]}锄`,
    { toolType: 'hoe', material: mat, speed: 1.5, tier: MAT_TIER[mat], durability: MAT_DUR[mat], attack: MAT_ATK.hoe[mat] });
}

defTool('shears', '剪刀', { toolType: 'shears', material: 'iron', speed: 6, tier: 1, durability: 238 });
defTool('bow',      '弓',   { toolType: 'bow', material: 'wood', speed: 1, tier: 0, durability: 384 });
defTool('iron_bow', '铁弓', { toolType: 'bow', material: 'iron', speed: 1, tier: 0, durability: 500 });
/* 石头法杖：右键发射石块，耐久消耗快（每次 5 点） */
defTool('stone_staff', '石头法杖',
  { toolType: 'staff', material: 'stone', speed: 1, tier: 0, durability: 90, attack: 1.5 });

/* ============ 盔甲（铜 / 金 / 铁 / 钻石） ============
   armorSlot 对应角色面板上的四个位置，defense 每点减伤 4%（总上限 80%）。
   全套数值：铜 9（36%） < 金 12（48%） < 铁 15（60%） < 钻石 20（80%）。 */
function defArmor(name, label, slot, defense){
  return registerBlock(name, label, {
    tex: { all: name }, hardness: 0.1, isItem: true, maxStack: 1,
    tag: 'armor', armorSlot: slot, defense,
  });
}
const ARMOR_SLOTS = [
  ['helmet', '头盔', 'head'],
  ['chestplate', '胸甲', 'chest'],
  ['leggings', '护腿', 'legs'],
  ['boots', '靴子', 'feet'],
];
const ARMOR_MATERIALS = [
  ['copper',  '铜', [1, 4, 3, 1]],
  ['gold',    '金', [2, 5, 4, 1]],
  ['iron',    '铁', [2, 6, 5, 2]],
  ['diamond', '钻石', [3, 8, 6, 3]],
  ['ancient', '远古石', [4, 9, 7, 4]],
];
for (const [mat, matLabel, defenses] of ARMOR_MATERIALS){
  ARMOR_SLOTS.forEach(([suffix, slotLabel, slot], i) => {
    defArmor(`${mat}_${suffix}`, `${matLabel}${slotLabel}`, slot, defenses[i]);
  });
}

/* ============ 桶（4 种） ============ */
defTool('bucket', '铁桶',
  { toolType: 'bucket', material: 'iron', speed: 1, tier: 1, durability: 0 },
  { bucketType: 'empty', maxStack: 16 });
defTool('water_bucket', '水桶',
  { toolType: 'bucket', material: 'iron', speed: 1, tier: 1, durability: 0 },
  { bucketType: 'water' });
defTool('lava_bucket', '岩浆桶',
  { toolType: 'bucket', material: 'iron', speed: 1, tier: 1, durability: 0 },
  { bucketType: 'lava' });
defTool('fish_bucket', '鱼桶',
  { toolType: 'bucket', material: 'iron', speed: 1, tier: 1, durability: 0 },
  { bucketType: 'fish' });

/* ============================================================
   花草与水草
   ============================================================ */
function defPlant(name, label, tex, extra){
  return registerBlock(name, label, {
    tex: { all: tex },
    hardness: 0.02,
    cross: true, solid: false,
    opaque: false, occludes: false, mergeSame: false,
    requiresTool: false, tool: null,
    ...(extra || {})
  });
}

defPlant('dandelion',   '蒲公英', 'dandelion');
defPlant('poppy',       '虞美人', 'poppy');
defPlant('cornflower',  '矢车菊', 'cornflower');
defPlant('tulip',       '郁金香', 'tulip');
defPlant('oxeye_daisy', '滨菊',   'oxeye_daisy');
defPlant('allium',      '绒球葱', 'allium');

defPlant('tall_grass',  '高草',   'tall_grass', { tint: 'grass' });
defPlant('fern',        '蕨',     'fern',       { tint: 'grass' });

defPlant('double_grass',     '高草丛',   'double_grass',     { tint: 'grass' });
defPlant('double_grass_top', '高草丛顶', 'double_grass_top', { placeable: false, tint: 'grass' });
defPlant('double_fern',      '大型蕨',   'double_fern',      { tint: 'grass' });
defPlant('double_fern_top',  '大型蕨顶', 'double_fern_top',  { placeable: false, tint: 'grass' });

defPlant('seagrass', '海草', 'seagrass', { waterPlant: true });
defPlant('kelp',     '海带', 'kelp',     { waterPlant: true });

/* ============ 魔法豆子 / 发光植物 ============ */
/* 魔法草：外观和高草接近，但叶尖发光，夜晚有微弱照明（方块光 6） */
defPlant('magic_grass', '魔法草', 'magic_grass', { emissive: 1, light: 6 });
/* 发光树苗：魔法豆子蓄力投掷后落地生成，光照 15，3 分钟后自动消失 */
defPlant('glow_sapling', '发光树苗', 'glow_sapling', { emissive: 1, light: 15, placeable: false });
/* 光粒：发光箭矢落地留下的小光点，只提供光照，不可放置 */
registerBlock('glow_light', '光粒', {
  tex: { all: 'glow_light' },
  hardness: 0,
  emissive: 1, light: 15,
  opaque: false, occludes: false, solid: false,
  placeable: false,
  model: { boxes: [
    { x0: 6, y0: 5, z0: 6, x1: 10, y1: 9, z1: 10, tex: { all: 'glow_light' } },
  ] },
});

/* 魔法豆子：可种植（长出魔法草），也可蓄力投掷 */
registerBlock('magic_bean', '魔法豆子', {
  tex: { all: 'magic_bean' }, hardness: 0.1,
  isItem: true, tag: 'magic', maxStack: 64,
});
/* 发光箭矢：箭 + 魔法豆子合成，落地发光，命中实体高亮 */
registerBlock('glow_arrow', '发光箭矢', {
  tex: { all: 'glow_arrow' }, hardness: 0.1,
  isItem: true, tag: 'arrow', maxStack: 64,
});

/* ---------- 树苗 ---------- */
defPlant('sapling', '树苗', 'sapling');

registerBlock('lily_pad', '睡莲', {
  tex: { all: 'lily_pad' }, hardness: 0.02,
  heightRatio: 1/16, flatRender: true,
  opaque: false, occludes: false, mergeSame: false,
  solid: true,
  waterSurface: true
});

/* ============================================================
   羊毛 / 食物 / 木炭
   ============================================================ */
registerBlock('wool', '羊毛', { tex: { all: 'wool' }, hardness: 0.8, tag: 'wool' });

registerBlock('charcoal', '木炭', { tex: { all: 'charcoal' }, hardness: 0.5, isItem: true, tag: 'coal' });

function defFood(name, label, tex, food, saturation){
  return registerBlock(name, label, {
    tex: { all: tex }, hardness: 0.2, isItem: true, tag: 'food',
    food, saturation
  });
}
defFood('raw_beef',       '生牛肉', 'raw_beef',       3, 1.8);
defFood('cooked_beef',    '熟牛肉', 'cooked_beef',    8, 12.8);
defFood('raw_mutton',     '生羊肉', 'raw_mutton',     2, 1.2);
defFood('cooked_mutton',  '熟羊肉', 'cooked_mutton',  6, 9.6);
defFood('raw_chicken',    '生鸡肉', 'raw_chicken',    2, 1.2);
defFood('cooked_chicken', '熟鸡肉', 'cooked_chicken', 6, 7.2);
defFood('raw_fish',       '生鱼肉', 'raw_fish',       2, 0.4);
defFood('cooked_fish',    '熟鱼肉', 'cooked_fish',    5, 6.0);
defFood('raw_pork',       '生猪肉', 'raw_pork',       3, 1.8);
defFood('cooked_pork',    '熟猪肉', 'cooked_pork',    8, 12.8);

/* ============================================================
   半砖与阶梯
   ============================================================ */
const STAIR_DIRS  = ['', '_e', '_s', '_w'];
const STAIR_LABEL = ['', '（东）', '（南）', '（西）'];

export const STAIR_VARIANTS = {};

function defStairGroup(baseName, label, tex, opts){
  const ids = [];
  for (let d = 0; d < 4; d++){
    const b = registerBlock(baseName + STAIR_DIRS[d], label + '阶梯' + STAIR_LABEL[d], {
      tex: { all: tex }, hardness: opts.hardness, tool: opts.tool, minTier: opts.minTier || 0,
      requiresTool: !!opts.requiresTool,
      stair: true, stairDir: d, stairBase: baseName,
      opaque: false, occludes: false, mergeSame: false,
      placeable: d === 0
    });
    ids.push(b.id);
  }
  STAIR_VARIANTS[baseName] = ids;
  return ids;
}

function defSlab(name, label, tex, opts){
  return registerBlock(name, label, {
    tex: { all: tex }, hardness: opts.hardness, tool: opts.tool, minTier: opts.minTier || 0,
    requiresTool: !!opts.requiresTool,
    heightRatio: 0.5, slab: true,
    opaque: false, occludes: false, mergeSame: false
  });
}

defSlab('oak_planks_slab', '橡木半砖', 'oak_planks', { hardness: 2, tool: 'axe' });
defStairGroup('oak_planks_stairs', '橡木', 'oak_planks', { hardness: 2, tool: 'axe' });

defSlab('cobble_slab', '圆石半砖', 'cobble', { hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });
defStairGroup('cobble_stairs', '圆石', 'cobble', { hardness: 2, requiresTool: true, tool: 'pickaxe', minTier: 1 });

defSlab('stone_slab', '石头半砖', 'stone', { hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1 });
defStairGroup('stone_stairs', '石头', 'stone', { hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1 });

defSlab('wool_slab', '羊毛半砖', 'wool', { hardness: 0.8 });
defStairGroup('wool_stairs', '羊毛', 'wool', { hardness: 0.8 });

/* ============================================================
   ★ 第一批新方块
   ============================================================ */

/* ---------- 新岩石 ---------- */
registerBlock('deepslate', '深板岩', {
  tex: { all: 'deepslate' },
  hardness: 3, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('granite', '花岗岩', {
  tex: { all: 'granite' },
  hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('diorite', '闪长岩', {
  tex: { all: 'diorite' },
  hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('andesite', '安山岩', {
  tex: { all: 'andesite' },
  hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('basalt', '玄武岩', {
  tex: { all: 'basalt' },
  hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});

/* ---------- 三种新木材 ---------- */
const WOOD_LEAF_COLORS = {
  birch:  [0x9ed86a, 0xc0e88a, 0x76b848],
  jungle: [0x2a6a2a, 0x3a8a3a, 0x1e4e1e],
  acacia: [0x8aae3a, 0xa8c852, 0x6a8a2a],
};

function defWood(name, label){
  registerBlock(`${name}_log`, `${label}原木`, {
    tex: { top: `${name}_log_top`, side: `${name}_log_side`, bottom: `${name}_log_top` },
    hardness: 2, tool: 'axe', tag: 'log',
  });
  registerBlock(`${name}_planks`, `${label}木板`, {
    tex: { all: `${name}_planks` },
    hardness: 2, tool: 'axe', tag: 'planks',
  });
  registerBlock(`${name}_leaves`, `${label}树叶`, {
    tex: { all: `${name}_leaves` }, hardness: 0.2,
    isLeaves: true,
    opaque: false, occludes: false, mergeSame: false,
    leafColors: WOOD_LEAF_COLORS[name],
    tool: 'shears', tint: 'foliage',
    lightFilter: 1,
  });
}

defWood('birch',  '白桦');
defWood('jungle', '丛林');
defWood('acacia', '金合欢');

/* ---------- 藤蔓 / 蘑菇 ---------- */
registerBlock('vine', '藤蔓', {
  tex: { all: 'vine' }, hardness: 0.2,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
  requiresTool: false, tool: 'shears',
});
registerBlock('red_mushroom', '红蘑菇', {
  tex: { all: 'red_mushroom' }, hardness: 0.02,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
});
registerBlock('brown_mushroom', '棕蘑菇', {
  tex: { all: 'brown_mushroom' }, hardness: 0.02,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
});
registerBlock('mushroom_block_red', '红蘑菇块', {
  tex: { all: 'mushroom_block_red' },
  hardness: 0.4, tool: 'axe',
});
registerBlock('mushroom_block_brown', '棕蘑菇块', {
  tex: { all: 'mushroom_block_brown' },
  hardness: 0.4, tool: 'axe',
});

/* ============================================================
   ★ 第二批新方块
   ============================================================ */

/* ---------- 新岩石 ---------- */
registerBlock('limestone', '石灰岩', {
  tex: { all: 'limestone' },
  hardness: 1.5, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('marble', '大理石', {
  tex: { all: 'marble' },
  hardness: 1.8, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});
registerBlock('terracotta', '陶瓦', {
  tex: { all: 'terracotta' },
  hardness: 1.2, requiresTool: true, tool: 'pickaxe', minTier: 1,
});
registerBlock('red_sand', '红沙', {
  tex: { all: 'red_sand' }, hardness: 0.5, tool: 'shovel',
});
registerBlock('red_sandstone', '红砂岩', {
  tex: { all: 'red_sandstone' },
  hardness: 0.8, requiresTool: true, tool: 'pickaxe', minTier: 1,
});
registerBlock('loess', '黄土', {
  tex: { all: 'loess' }, hardness: 0.6, tool: 'shovel',
});
registerBlock('blackstone', '黑石', {
  tex: { all: 'blackstone' },
  hardness: 1.6, requiresTool: true, tool: 'pickaxe', minTier: 1, tag: 'stone',
});

/* ---------- 冰 ---------- */
registerBlock('packed_ice', '浮冰', {
  tex: { all: 'packed_ice' }, hardness: 0.5,
  transparent: true, opaque: false, occludes: true, mergeSame: true,
  tool: 'pickaxe', minTier: 1,
});
registerBlock('blue_ice', '蓝冰', {
  tex: { all: 'blue_ice' }, hardness: 1.2,
  transparent: true, opaque: false, occludes: true, mergeSame: true,
  tool: 'pickaxe', minTier: 1,
});

/* ---------- 岩浆块 ---------- */
registerBlock('magma_block', '岩浆块', {
  tex: { all: 'magma_block' }, hardness: 0.8,
  emissive: 1, light: 6,
  requiresTool: true, tool: 'pickaxe', minTier: 1,
});

/* ---------- 苔藓 ---------- */
registerBlock('moss_block', '苔藓块', {
  tex: { all: 'moss_block' }, hardness: 0.4, tool: 'shovel',
});
registerBlock('moss_carpet', '苔藓地毯', {
  tex: { all: 'moss_carpet' }, hardness: 0.1,
  heightRatio: 1/16, flatRender: true,
  opaque: false, occludes: false, mergeSame: false,
  solid: false,
});

/* ---------- 枯木 / 甘蔗 / 竹子 ---------- */
registerBlock('dead_bush', '枯木', {
  tex: { all: 'dead_bush' }, hardness: 0.02,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
});
registerBlock('sugar_cane', '甘蔗', {
  tex: { all: 'sugar_cane' }, hardness: 0.02,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
});
registerBlock('bamboo', '竹子', {
  tex: { all: 'bamboo' }, hardness: 0.3,
  cross: true, solid: false,
  opaque: false, occludes: false, mergeSame: false,
  tool: 'axe',
});

/* ---------- 雪层 ---------- */
registerBlock('snow_layer', '雪层', {
  tex: { all: 'snow_layer' }, hardness: 0.1,
  heightRatio: 1/8, slab: true,
  /* ★ 其他所有 slab 都是 opaque:false / occludes:false / mergeSame:false，
     就这里漏了：默认 opaque=true 会让这层 1/8 高的雪当成实心方块，
     既挡天光（雪下面一格直接变全黑），又会在网格里剔掉下面方块的顶面。 */
  opaque: false, occludes: false, mergeSame: false,
  tool: 'shovel',
});

/* ---------- 红树木材 ---------- */
function defWoodMangrove(){
  registerBlock('mangrove_log', '红树原木', {
    tex: { top: 'mangrove_log_top', side: 'mangrove_log_side', bottom: 'mangrove_log_top' },
    hardness: 2, tool: 'axe', tag: 'log',
  });
  registerBlock('mangrove_planks', '红树木板', {
    tex: { all: 'mangrove_planks' },
    hardness: 2, tool: 'axe', tag: 'planks',
  });
  registerBlock('mangrove_leaves', '红树叶', {
    tex: { all: 'mangrove_leaves' }, hardness: 0.2,
    isLeaves: true,
    opaque: false, occludes: false, mergeSame: false,
    leafColors: [0x3a8a5a, 0x4aa86a, 0x2a6a42],
    tool: 'shears', tint: 'foliage',
    lightFilter: 1,
  });
  registerBlock('mangrove_root', '红树根', {
    tex: { all: 'mangrove_root' },
    hardness: 1.5, tool: 'axe',
  });
}
defWoodMangrove();

/* ============================================================
   箱子（方块实体）
   ------------------------------------------------------------
   注册在末尾，保证前面所有内置方块的 id 不变（老存档的
   blocks.json 里存的是数字 id，中间插一个方块会让它们全部错位）。
   interactive: 'chest' → main.js 右键打开箱子界面。
   ============================================================ */
registerBlock('chest', '箱子', {
  tex: { top: 'chest_top', side: 'chest_side', bottom: 'chest_top' },
  hardness: 2.5, tool: 'axe',
  interactive: 'chest',
  /* ★ 动态模型：不烘焙进区块，由 chest-visuals.js 实时绘制，
     这样箱盖才能像 MC 一样平滑开合。part:'lid' 的盒子挂在铰链上旋转。 */
  dynamic: true,
  model: { boxes: [
    { x0: 1, y0: 0, z0: 1, x1: 15, y1: 8, z1: 15, part: 'body',
      tex: { side: 'chest_side', top: 'chest_top', bottom: 'chest_side' } },
    { x0: 1, y0: 8, z0: 1, x1: 15, y1: 15, z1: 15, part: 'lid',
      tex: { side: 'chest_side', top: 'chest_top', bottom: 'chest_side' } },
    /* 金属锁扣：跟着箱盖一起抬起来 */
    { x0: 6.5, y0: 8, z0: 14.2, x1: 9.5, y1: 11, z1: 15.8, part: 'lid',
      tex: { all: 'chest_latch' } },
  ] },
});

/* ============================================================
   ★ M5：未知方块（占位）
   ============================================================ */
registerBlock('unknown_block', '未知方块', {
  tex: { all: 'unknown_block' },
  hardness: 0.5,
  tool: 'pickaxe',
});

/* ============================================================
   魔法方块
   ============================================================ */
registerBlock('magic_ore', '魔法矿石', {
  tex: { all: 'magic_ore' }, hardness: 3, requiresTool: true,
  tool: 'pickaxe', minTier: 2, tag: 'stone', category: 'magic',
});
registerBlock('magic_crystal', '魔法水晶', {
  tex: { all: 'magic_crystal' }, hardness: 0.5,
  isItem: true, maxStack: 1, durability: 100, icon: 'magic_crystal_icon', category: 'magic',
});
registerBlock('magic_pulse_core', '脉冲核心', {
  tex: { all: 'magic_pulse_core' }, hardness: 1.0,
  isItem: true, maxStack: 64, icon: 'magic_pulse_core', category: 'magic',
});
registerBlock('magic_crystal_block', '魔法水晶块', {
  tex: { all: 'magic_crystal_block' }, hardness: 2.0,
  category: 'magic',
});
registerBlock('magic_pedestal', '展台', {
  tex: { side: 'magic_pedestal_wood', top: 'magic_pedestal_top', bottom: 'magic_pedestal_wood' },
  icon: 'magic_pedestal_top',
  hardness: 2.0, interactive: 'pedestal', category: 'misc',
  opaque: false, occludes: false, solid: true,
  /* ★ MC 风格方块模型：0~16 整数坐标，木框 + 玻璃罩，和普通方块同批渲染 */
  model: {
    boxes: [
      { x0: 0, y0: 0, z0: 0, x1: 16, y1: 2, z1: 16,
        tex: { all: 'magic_pedestal_wood' } },
      { x0: 3, y0: 2, z0: 3, x1: 13, y1: 3, z1: 13,
        tex: { side: 'magic_pedestal_wood', top: 'magic_pedestal_top' } },
      { x0: 1, y0: 2, z0: 1, x1: 3, y1: 14, z1: 3,
        tex: { all: 'magic_pedestal_wood' } },
      { x0: 13, y0: 2, z0: 1, x1: 15, y1: 14, z1: 3,
        tex: { all: 'magic_pedestal_wood' } },
      { x0: 1, y0: 2, z0: 13, x1: 3, y1: 14, z1: 15,
        tex: { all: 'magic_pedestal_wood' } },
      { x0: 13, y0: 2, z0: 13, x1: 15, y1: 14, z1: 15,
        tex: { all: 'magic_pedestal_wood' } },
      { x0: 0, y0: 14, z0: 0, x1: 16, y1: 16, z1: 16,
        tex: { side: 'magic_pedestal_wood', top: 'magic_pedestal_top', bottom: 'magic_pedestal_wood' } },
      /* 玻璃罩：1px 内缩，走透明批次 */
      { x0: 3, y0: 2, z0: 1, x1: 13, y1: 14, z1: 2,
        tex: { all: 'magic_pedestal_glass' }, alpha: true },
      { x0: 3, y0: 2, z0: 14, x1: 13, y1: 14, z1: 15,
        tex: { all: 'magic_pedestal_glass' }, alpha: true },
      { x0: 1, y0: 2, z0: 3, x1: 2, y1: 14, z1: 13,
        tex: { all: 'magic_pedestal_glass' }, alpha: true },
      { x0: 14, y0: 2, z0: 3, x1: 15, y1: 14, z1: 13,
        tex: { all: 'magic_pedestal_glass' }, alpha: true },
    ],
  },
});
registerBlock('magic_dust', '魔法粉末', {
  tex: { all: 'magic_dust_off' }, hardness: 0.2,
  heightRatio: 1/16, flatRender: true,
  opaque: false, occludes: false, mergeSame: false, solid: false,
  category: 'magic',
});
registerBlock('magic_dust_on', '魔法粉末', {
  tex: { all: 'magic_dust_on' }, hardness: 0.2,
  heightRatio: 1/16, flatRender: true,
  opaque: false, occludes: false, mergeSame: false, solid: false,
  hidden: true, placeable: false, category: 'magic',
});

/* 魔法火把：类似红石火把的恒定弱电源（0.2），会发光 */
registerBlock('magic_torch', '魔法火把', {
  tex: { all: 'magic_torch_stick' },
  icon: 'magic_torch_stick',
  hardness: 0.2,
  emissive: 1, light: 14,
  opaque: false, occludes: false, solid: false,
  category: 'magic',
  model: { boxes: [
    { x0: 7, y0: 0, z0: 7, x1: 9, y1: 10, z1: 9,
      tex: { all: 'magic_torch_stick' } },
    { x0: 6, y0: 10, z0: 6, x1: 10, y1: 15, z1: 10,
      tex: { all: 'magic_torch_tip' }, alpha: true },
  ] },
});

/* ============================================================
   动力元件（魔法网络电源 / 门）
   ============================================================ */
/* 拉杆：拉动一次输出 0.1 强度，持续 4 秒；拉杆本体不阻挡通行 */
registerBlock('magic_lever', '拉杆', {
  tex: { all: 'magic_lever_stick' },
  icon: 'magic_lever_stick',
  hardness: 0.4, interactive: 'lever', category: 'magic',
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 6, y0: 0, z0: 6, x1: 10, y1: 2, z1: 10,
      tex: { all: 'magic_lever_base' } },
    { x0: 7, y0: 2, z0: 7, x1: 9, y1: 12, z1: 9,
      tex: { all: 'magic_lever_stick' } },
  ] },
});
registerBlock('magic_lever_on', '拉杆（已拉动）', {
  tex: { all: 'magic_lever_stick' },
  icon: 'magic_lever_stick',
  hardness: 0.4, interactive: 'lever', category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 6, y0: 0, z0: 6, x1: 10, y1: 2, z1: 10,
      tex: { all: 'magic_lever_base' } },
    { x0: 7, y0: 2, z0: 7, x1: 15, y1: 4, z1: 9,
      tex: { all: 'magic_lever_stick' } },
  ] },
});

/* 按钮：每次按压输出 0.1 强度，持续 1 秒 */
registerBlock('magic_button', '按钮', {
  tex: { all: 'magic_button_top' },
  icon: 'magic_button_top',
  hardness: 0.3, interactive: 'button', category: 'magic',
  opaque: false, occludes: false, solid: false,
  buttonOff: 'magic_button', buttonOn: 'magic_button_on',
  model: { boxes: [
    { x0: 5, y0: 0, z0: 5, x1: 11, y1: 2, z1: 11,
      tex: { all: 'magic_button_base' } },
    { x0: 6, y0: 2, z0: 6, x1: 10, y1: 4, z1: 10,
      tex: { all: 'magic_button_top' } },
  ] },
});
registerBlock('magic_button_on', '按钮（按下）', {
  tex: { all: 'magic_button_top' },
  icon: 'magic_button_top',
  hardness: 0.3, interactive: 'button', category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  buttonOff: 'magic_button', buttonOn: 'magic_button_on',
  model: { boxes: [
    { x0: 5, y0: 0, z0: 5, x1: 11, y1: 2, z1: 11,
      tex: { all: 'magic_button_base' } },
    { x0: 6, y0: 1, z0: 6, x1: 10, y1: 2.5, z1: 10,
      tex: { all: 'magic_button_top' } },
  ] },
});

/* 压力板：玩家站上去时输出 0.1 强度（可踩入，不阻挡） */
registerBlock('magic_pressure_plate', '压力板', {
  tex: { all: 'magic_plate_top' },
  icon: 'magic_plate_top',
  hardness: 0.2, category: 'magic',
  opaque: false, occludes: false, solid: false, mergeSame: false,
  plateOff: 'magic_pressure_plate', plateOn: 'magic_pressure_plate_on',
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 1, z1: 16,
      tex: { all: 'magic_plate_base' } },
    { x0: 1, y0: 1, z0: 1, x1: 15, y1: 2, z1: 15,
      tex: { all: 'magic_plate_top' } },
  ] },
});
registerBlock('magic_pressure_plate_on', '压力板（按下）', {
  tex: { all: 'magic_plate_top' },
  hardness: 0.2, category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false, mergeSame: false,
  plateOff: 'magic_pressure_plate', plateOn: 'magic_pressure_plate_on',
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 1, z1: 16,
      tex: { all: 'magic_plate_base' } },
    { x0: 1, y0: 1, z0: 1, x1: 15, y1: 1.5, z1: 15,
      tex: { all: 'magic_plate_top' } },
  ] },
});

/* 门：关门=沿 Z 的薄板 + 实心碰撞；开门=沿 X 的薄板 + 可穿过 */
registerBlock('magic_door', '门', {
  tex: { all: 'magic_door' },
  icon: 'magic_door',
  hardness: 1.0, interactive: 'door', category: 'magic',
  opaque: false, occludes: true, solid: true,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 16, z1: 3,
      tex: { all: 'magic_door' } },
  ] },
});
registerBlock('magic_door_open', '门（开启）', {
  tex: { all: 'magic_door' },
  icon: 'magic_door',
  hardness: 1.0, interactive: 'door', category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 3, y1: 16, z1: 16,
      tex: { all: 'magic_door' } },
  ] },
});
/* 铁门：不能用手直接开关，只能由魔法机关驱动 */
registerBlock('iron_door', '铁门', {
  tex: { all: 'iron_door' },
  icon: 'iron_door',
  hardness: 2.5, interactive: 'iron_door', category: 'functional',
  requiresTool: true, tool: 'pickaxe', minTier: 1,
  opaque: false, occludes: true, solid: true,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 16, z1: 3,
      tex: { all: 'iron_door' } },
  ] },
});
registerBlock('iron_door_open', '铁门（开启）', {
  tex: { all: 'iron_door' },
  icon: 'iron_door',
  hardness: 2.5, interactive: 'iron_door', category: 'functional',
  requiresTool: true, tool: 'pickaxe', minTier: 1,
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 3, y1: 16, z1: 16,
      tex: { all: 'iron_door' } },
  ] },
});
registerBlock('iron_door_top', '铁门（上半）', {
  tex: { all: 'iron_door' },
  icon: 'iron_door',
  hardness: 2.5, interactive: 'iron_door', category: 'functional',
  requiresTool: true, tool: 'pickaxe', minTier: 1,
  hidden: true, placeable: false,
  opaque: false, occludes: true, solid: true,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 16, z1: 3,
      tex: { all: 'iron_door' } },
  ] },
});
registerBlock('iron_door_open_top', '铁门（开启·上半）', {
  tex: { all: 'iron_door' },
  icon: 'iron_door',
  hardness: 2.5, interactive: 'iron_door', category: 'functional',
  requiresTool: true, tool: 'pickaxe', minTier: 1,
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 3, y1: 16, z1: 16,
      tex: { all: 'iron_door' } },
  ] },
});

/* 门的上半格：真实两格高的门由「下半 + 上半」两个方块组成。
   注意：必须追加在所有旧方块之后，避免旧存档里的数字 id 发生偏移。 */
registerBlock('magic_door_top', '门（上半）', {
  tex: { all: 'magic_door' },
  icon: 'magic_door',
  hardness: 1.0, interactive: 'door', category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: true, solid: true,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 16, z1: 3,
      tex: { all: 'magic_door' } },
  ] },
});
registerBlock('magic_door_open_top', '门（开启·上半）', {
  tex: { all: 'magic_door' },
  icon: 'magic_door',
  hardness: 1.0, interactive: 'door', category: 'magic',
  hidden: true, placeable: false,
  opaque: false, occludes: false, solid: false,
  model: { boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 3, y1: 16, z1: 16,
      tex: { all: 'magic_door' } },
  ] },
});

/* ============================================================
   木质按钮 / 压力板
   ------------------------------------------------------------
   7 种木板各一套，登记在注册表末尾，不影响旧方块的数字 id。
   通电状态通过 powerOn=0.1 接入现有的魔法动力网络（等价于红石）。
   ============================================================ */
const WOOD_KINDS = [
  ['oak',      '橡木', 'oak_planks'],
  ['spruce',   '云杉', 'spruce_planks'],
  ['sakura',   '樱花', 'sakura_planks'],
  ['mangrove', '红树', 'mangrove_planks'],
  ['birch',    '白桦', 'birch_planks'],
  ['jungle',   '丛林', 'jungle_planks'],
  ['acacia',   '金合欢', 'acacia_planks'],
];

for (const [w, label, plankTex] of WOOD_KINDS){
  const btnOff = `${w}_button`;
  const btnOn  = `${w}_button_on`;
  const plOff  = `${w}_pressure_plate`;
  const plOn   = `${w}_pressure_plate_on`;

  const btnBoxes = (pressed) => ({ boxes: [
    { x0: 5, y0: 0, z0: 5, x1: 11, y1: 2, z1: 11, tex: { all: plankTex } },
    { x0: 6, y0: 2, z0: 6, x1: 10, y1: pressed ? 2.5 : 4, z1: 10,
      tex: { all: plankTex } },
  ] });
  const plateBoxes = (pressed) => ({ boxes: [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 1, z1: 16, tex: { all: plankTex } },
    { x0: 1, y0: 1, z0: 1, x1: 15, y1: pressed ? 1.5 : 2, z1: 15,
      tex: { all: plankTex } },
  ] });

  registerBlock(btnOff, `${label}按钮`, {
    tex: { all: plankTex }, icon: plankTex,
    hardness: 0.4, tool: 'axe', category: 'functional',
    interactive: 'button',
    opaque: false, occludes: false, solid: false,
    buttonOff: btnOff, buttonOn: btnOn,
    model: btnBoxes(false),
  });
  registerBlock(btnOn, `${label}按钮（按下）`, {
    tex: { all: plankTex }, icon: plankTex,
    hardness: 0.4, tool: 'axe', category: 'functional',
    interactive: 'button',
    hidden: true, placeable: false,
    opaque: false, occludes: false, solid: false,
    buttonOff: btnOff, buttonOn: btnOn, powerOn: 0.1,
    model: btnBoxes(true),
  });

  registerBlock(plOff, `${label}压力板`, {
    tex: { all: plankTex }, icon: plankTex,
    hardness: 0.3, tool: 'axe', category: 'functional',
    opaque: false, occludes: false, solid: false, mergeSame: false,
    plateOff: plOff, plateOn: plOn,
    model: plateBoxes(false),
  });
  registerBlock(plOn, `${label}压力板（按下）`, {
    tex: { all: plankTex }, icon: plankTex,
    hardness: 0.3, tool: 'axe', category: 'functional',
    hidden: true, placeable: false,
    opaque: false, occludes: false, solid: false, mergeSame: false,
    plateOff: plOff, plateOn: plOn, powerOn: 0.1,
    model: plateBoxes(true),
  });
}

/* ============================================================
   ★ 床：木框 + 被子 + 枕头，占一格、可站上去（0.5625 高）
   ------------------------------------------------------------
   夜里右键睡觉 → 直接跳到清晨并设置重生点。
   ============================================================ */
registerBlock('bed', '床', {
  tex: { all: 'bed_top' },
  icon: 'bed_top',
  hardness: 0.4, tool: 'axe', category: 'functional',
  interactive: 'bed',
  opaque: false, occludes: false, solid: true, mergeSame: false,
  heightRatio: 9 / 16,
  model: { boxes: [
    { x0: 1, y0: 0, z0: 1, x1: 15, y1: 3, z1: 15, tex: { all: 'oak_planks' } },
    { x0: 1, y0: 3, z0: 1, x1: 15, y1: 7, z1: 15, tex: { all: 'bed_top' } },
    { x0: 3, y0: 7, z0: 2, x1: 13, y1: 9, z1: 6,  tex: { all: 'wool' } },
  ] },
});

/* ============================================================
   ★ 冻结注册表 → 导出 B / BLOCKS
   ============================================================ */
const { byName, byId } = freezeBlocks();

export const BLOCKS = byId;

export const B = {};
for (const [k, v] of byName) B[k] = v;

/* ============================================================
   熔炉燃料（方块表冻结后单独赋值，不影响注册）
   ============================================================ */
const FUEL_SECONDS = {
  oak_log: 15, spruce_log: 15, sakura_log: 15,
  oak_planks: 15, spruce_planks: 15, sakura_planks: 15,
  oak_planks_slab: 7.5, oak_planks_stairs: 15,
  stick: 5, crafting_table: 15,
  coal: 80, charcoal: 80
};
for (const [n, v] of Object.entries(FUEL_SECONDS)){
  if (B[n]) B[n].fuel = v;
}
for (const b of BLOCKS){
  if (b && b.tag === 'tool' && b.material === 'wood') b.fuel = 10;
}