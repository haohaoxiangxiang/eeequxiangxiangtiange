/* ============================================================
   world-core.js —— 群系 / 流体 / 水花 / 区块磁盘缓存
   ------------------------------------------------------------
★ 合并自 world 下的 4 个中等文件（约 49KB）：
     biome-registry.js 群系注册表与查询
     fluid.js          流体寻路、无限水、模拟距离
     splash.js         入水水花 + 气泡粒子
     chunk-db.js       区块二进制磁盘缓存（打包上传 / 预取）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from '../vendor/three.module.js';
import { getBlockWorld, setBlockWorld, isWorldBlockLoaded, getFluidLevel, setFluidLevel, getFluidSource, setFluidSource, getFluidFalling, setFluidFalling, getTerrainSource, setOnFluidWake, setOnChunkFluidReady, setRecording, isRecording, chunks, chunkKey } from './terrain.js';

import { BLOCKS, B } from './blocks.js';
import { CHH, Y_MIN, CS, COL_H, getActiveDimension } from '../core/engine-core.js';
import { FLAGS } from '../worker/pool.js';

import { WorkerPool } from '../worker/pool.js';
import { playSFX } from '../audio/audio.js';

import { scene } from '../render/render-core.js';
import { emitCancellable } from '../core/engine-core.js';


/* =================================================================
   biome-registry.js
   ================================================================= */
/* ============================================================
   biome-registry.js —— 群系注册表
   ------------------------------------------------------------
   ★ 每个群系带 terrain 字段：决定该群系的地形个性
     ampScale    幅度缩放（默认 1）
     baseOffset  基准高度偏移（默认 0）
     freqScale   频率缩放（默认 1）
     type        地形类型：default/plateau/dunes/swamp/ocean/flat
     step        plateau 专用台阶高度

   ★ 新增 grassColor / foliageColor：
     用于草方块、树叶、花草的顶点染色。
     未配置的群系会自动 fallback 到平原的绿色。
   ============================================================ */

const _biomes = new Map();
const _byName = new Map();

let _nextId = 16;
let _listCache = null;

const DEFAULT = {
  label: '',
  surface: 'grass',
  subsurface: 'dirt',
  underwater: 'sand',
  stone: 'stone',
  useSandstone: false,
  treeDensity: 0,
  treeTypes: [],
  plants: [],
  features: [],
  fog: null,
  sky: null,
  color: null,
  onDecorate: null,
  climate: null,
  weight: 1.0,
  terrain: null,
  /* ★ 颜色配置 */
  grassColor: 0x91bd59,
  foliageColor: 0x77ab2f,
};

const DEFAULT_TERRAIN = {
  ampScale: 1.0,
  baseOffset: 0,
  freqScale: 1.0,
  type: 'default',
  step: 8,
};

function registerBiome(name, cfg){
  if (typeof name !== 'string' || !name) return null;
  if (_byName.has(name)) return _byName.get(name);
  cfg = cfg || {};

  const id = (typeof cfg.id === 'number') ? cfg.id : _nextId++;
  if (_biomes.has(id)) return null;

  const biome = Object.assign({}, DEFAULT, cfg, {
    id, name, label: cfg.label || name,
  });
  if (!Array.isArray(biome.treeTypes)) biome.treeTypes = [];
  if (!Array.isArray(biome.plants))    biome.plants    = [];
  if (!Array.isArray(biome.features))  biome.features  = [];
  biome.terrain = Object.assign({}, DEFAULT_TERRAIN, biome.terrain || {});

  _biomes.set(id, biome);
  _byName.set(name, biome);
  if (id >= _nextId) _nextId = id + 1;
  _listCache = null;
  return biome;
}

function getBiome(idOrName){
  if (typeof idOrName === 'string') return _byName.get(idOrName) || null;
  return _biomes.get(idOrName) || null;
}
function getBiomeByName(name){ return _byName.get(name) || null; }
function getBiomeById(id){ return _biomes.get(id) || null; }

function listBiomes(){
  if (!_listCache) _listCache = Array.from(_biomes.values());
  return _listCache;
}

function getBiomeCount(){ return _biomes.size; }
function peekNextBiomeId(){ return _nextId; }

function listBiomesSerializable(){
  const out = [];
  for (const b of _biomes.values()){
    out.push({
      id: b.id, name: b.name, label: b.label,
      surface: b.surface, subsurface: b.subsurface,
      underwater: b.underwater, stone: b.stone,
      useSandstone: b.useSandstone,
      treeDensity: b.treeDensity,
      treeTypes: b.treeTypes.slice(),
      plants: Array.isArray(b.plants)
        ? b.plants.map(p => ({ type: p.type, density: p.density }))
        : [],
      features: b.features.slice(),
      color: b.color, sky: b.sky, fog: b.fog,
      climate: b.climate ? {
        temp: b.climate.temp.slice(),
        hum:  b.climate.hum.slice(),
      } : null,
      weight: b.weight,
      terrain: b.terrain,
      grassColor: b.grassColor,
      foliageColor: b.foliageColor,
    });
  }
  return out;
}

function clearAllBiomes(){
  _biomes.clear();
  _byName.clear();
  _nextId = 0;
  _listCache = null;
}

/* ============================================================
   内置群系
   ============================================================ */

/* ---------- 海洋 ---------- */
registerBiome('ocean', {
  id: 0, label: '海洋',
  surface: 'sand', subsurface: 'sand', underwater: 'sand',
  color: 0x1c4e8c,
  grassColor: 0x8eb971,
  foliageColor: 0x71a74d,
  terrain: { ampScale: 0.4, baseOffset: -6, freqScale: 0.5, type: 'default' },
});

/* ---------- 沙滩 ---------- */
registerBiome('beach', {
  id: 1, label: '沙滩',
  surface: 'sand', subsurface: 'sand', underwater: 'sand',
  color: 0xdcd0a0,
  grassColor: 0x8eb971,
  foliageColor: 0x71a74d,
  terrain: { ampScale: 0.6, baseOffset: -1, freqScale: 1, type: 'default' },
});

/* ---------- 平原 ---------- */
registerBiome('plains', {
  id: 2, label: '平原',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.002,
  treeTypes: ['oak'],
  plants: [
    { type: 'dandelion',   density: 0.020 },
    { type: 'poppy',       density: 0.020 },
    { type: 'oxeye_daisy', density: 0.020 },
    { type: 'tall_grass',  density: 0.22  },
  ],
  color: 0x78b45c,
  grassColor: 0x8ac94e,
  foliageColor: 0x70b82a,
  climate: { temp: [0.30, 0.78], hum: [0.28, 0.58] },
  weight: 2.0,
  terrain: { ampScale: 0.5, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 森林 ---------- */
registerBiome('forest', {
  id: 3, label: '森林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.055,
  treeTypes: ['oak'],
  plants: [
    { type: 'dandelion',   density: 0.025 },
    { type: 'poppy',       density: 0.025 },
    { type: 'cornflower',  density: 0.025 },
    { type: 'tall_grass',  density: 0.30  },
  ],
  features: ['petals'],
  color: 0x408240,
  grassColor: 0x72c850,
  foliageColor: 0x53b62a,
  climate: { temp: [0.30, 0.78], hum: [0.42, 0.78] },
  weight: 2.0,
  terrain: { ampScale: 0.8, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 白桦林 ---------- */
registerBiome('birch_forest', {
  id: 5, label: '白桦林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.050,
  treeTypes: ['birch'],
  plants: [
    { type: 'tall_grass', density: 0.22 },
    { type: 'dandelion',  density: 0.06 },
  ],
  color: 0x88b860,
  grassColor: 0x88bb67,
  foliageColor: 0x6ba941,
  climate: { temp: [0.28, 0.60], hum: [0.40, 0.78] },
  weight: 1.2,
  terrain: { ampScale: 0.8, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 樱花林 ---------- */
registerBiome('sakura', {
  id: 4, label: '樱花林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.048,
  treeTypes: ['sakura'],
  plants: [
    { type: 'tulip',       density: 0.10 },
    { type: 'allium',      density: 0.10 },
    { type: 'oxeye_daisy', density: 0.10 },
    { type: 'tall_grass',  density: 0.18 },
  ],
  features: ['petals'],
  color: 0xe6a8c8,
  grassColor: 0x91bd59,
  foliageColor: 0xffb7c5,  // ★ 粉色树叶
  climate: { temp: [0.52, 0.75], hum: [0.50, 0.82] },
  weight: 0.6,
  terrain: { ampScale: 1.0, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 沼泽 ---------- */
registerBiome('swamp', {
  id: 6, label: '沼泽',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.040,
  treeTypes: ['oak'],
  plants: [
    { type: 'tall_grass', density: 0.15 },
    { type: 'fern',       density: 0.22 },
  ],
  features: ['lily_pad'],
  color: 0x4a6a3a,
  grassColor: 0x6a7039,    // ★ 偏暗的沼泽绿
  foliageColor: 0x6a7039,
  climate: { temp: [0.42, 0.75], hum: [0.72, 1.00] },
  weight: 0.8,
  terrain: { ampScale: 0.7, baseOffset: -1, freqScale: 1, type: 'swamp' },
});

/* ---------- 针叶林 ---------- */
registerBiome('taiga', {
  id: 7, label: '针叶林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.060,
  treeTypes: ['spruce'],
  plants: [
    { type: 'fern',       density: 0.20 },
    { type: 'tall_grass', density: 0.10 },
  ],
  color: 0x3d6b48,
  grassColor: 0x86b783,
  foliageColor: 0x68a464,
  climate: { temp: [0.13, 0.34], hum: [0.35, 1.00] },
  weight: 1.0,
  terrain: { ampScale: 1.0, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 雪原 ---------- */
registerBiome('snow', {
  id: 8, label: '雪原',
  surface: 'snow', subsurface: 'dirt',
  treeDensity: 0.022,
  treeTypes: ['spruce'],
  plants: [{ type: 'tall_grass', density: 0.05 }],
  color: 0xe6f0f8,
  grassColor: 0x80b497,    // ★ 寒冷的青绿
  foliageColor: 0x60a17b,
  climate: { temp: [0.00, 0.16], hum: [0.25, 1.00] },
  weight: 1.0,
  terrain: { ampScale: 0.7, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 沙漠 ---------- */
registerBiome('desert', {
  id: 9, label: '沙漠',
  surface: 'sand', subsurface: 'sand', underwater: 'sand',
  useSandstone: true,
  features: ['cactus'],
  plants: [{ type: 'dead_bush', density: 0.02 }],
  color: 0xe4ca80,
  grassColor: 0xbfb755,    // ★ 枯黄
  foliageColor: 0xaea42a,
  climate: { temp: [0.70, 1.00], hum: [0.00, 0.32] },
  weight: 1.0,
  terrain: { ampScale: 0.8, baseOffset: 0, freqScale: 1.2, type: 'dunes' },
});

/* ---------- 稀树草原 ---------- */
registerBiome('savanna', {
  id: 10, label: '稀树草原',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.008,
  treeTypes: ['acacia'],
  plants: [{ type: 'tall_grass', density: 0.35 }],
  color: 0xb0a24c,
  grassColor: 0xbfb755,    // ★ 干燥的黄绿
  foliageColor: 0xaea42a,
  climate: { temp: [0.55, 0.85], hum: [0.10, 0.48] },
  weight: 1.0,
  terrain: { ampScale: 0.7, baseOffset: 2, freqScale: 1, type: 'default' },
});

/* ---------- 丛林 ---------- */
registerBiome('jungle', {
  id: 11, label: '丛林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.110,
  treeTypes: ['jungle'],
  plants: [
    { type: 'fern',       density: 0.35 },
    { type: 'tall_grass', density: 0.30 },
    { type: 'bamboo',     density: 0.06 },
  ],
  color: 0x2a7a3a,
  grassColor: 0x59c93c,    // ★ 鲜艳的热带绿
  foliageColor: 0x30bb0b,
  climate: { temp: [0.72, 1.00], hum: [0.52, 1.00] },
  weight: 0.6,
  terrain: { ampScale: 1.2, baseOffset: 2, freqScale: 1, type: 'default' },
});

/* ---------- 荒地 ---------- */
registerBiome('badlands', {
  id: 12, label: '荒地',
  surface: 'red_sand', subsurface: 'terracotta', stone: 'terracotta',
  useSandstone: true,
  features: ['cactus'],
  plants: [{ type: 'dead_bush', density: 0.02 }],
  color: 0xa06030,
  grassColor: 0x90814d,    // ★ 土黄色
  foliageColor: 0x9e814d,
  climate: { temp: [0.58, 1.00], hum: [0.00, 0.32] },
  weight: 0.7,
  terrain: { ampScale: 1.0, baseOffset: 6, freqScale: 1, type: 'plateau', step: 6 },
});

/* ---------- 红树林 ---------- */
registerBiome('mangrove', {
  id: 13, label: '红树林',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0.060,
  treeTypes: ['mangrove'],
  color: 0x4a8a5a,
  grassColor: 0x6a7039,
  foliageColor: 0x8db127,
  climate: { temp: [0.70, 1.00], hum: [0.62, 1.00] },
  weight: 0.5,
  terrain: { ampScale: 0.3, baseOffset: -1, freqScale: 1, type: 'swamp' },
});

/* ---------- 蘑菇岛 ---------- */
registerBiome('mushroom', {
  id: 14, label: '蘑菇岛',
  surface: 'grass', subsurface: 'dirt',
  treeDensity: 0,
  plants: [
    { type: 'red_mushroom',   density: 0.30 },
    { type: 'brown_mushroom', density: 0.30 },
  ],
  color: 0x9a7aa0,
  grassColor: 0x55c93f,
  foliageColor: 0x2bbb0f,
  terrain: { ampScale: 1.2, baseOffset: 0, freqScale: 1, type: 'default' },
});

/* ---------- 河流 ---------- */
registerBiome('river', {
  id: 15, label: '河流',
  surface: 'sand', subsurface: 'sand', underwater: 'sand',
  color: 0x3a6fa0,
  grassColor: 0x8eb971,
  foliageColor: 0x71a74d,
  terrain: { ampScale: 0.4, baseOffset: -2, freqScale: 1, type: 'default' },
});

/* =================================================================
   fluid.js
   ================================================================= */
/* ============================================================
   fluid.js —— 流体系统（水 / 岩浆）· MC 式寻路 + 无限水 + 模拟距离
   ------------------------------------------------------------
   核心行为（对齐 Minecraft）：
     ① 无限水：水平两侧同种源头 → 升格为源头
     ② 源头永远满格
     ③ 非源头供给：四邻最大液位 - 1，或上方有水=8
     ④ 下方可填充 → 只往下
     ⑤ 坡度优先扩散

   性能：
     · 单帧处理上限 fluidConfig.maxPerFrame
     · 单帧升级上限 fluidConfig.promotePerFrame
     · 推演期间 setRecording(false)
     · ★ 模拟距离过滤
     · ★ 跨区块写入后标记邻居 chunk 脏
   ============================================================ */




/* ============================================================
   常量
   ============================================================ */
const FLUID_MAX_LEVEL = 8;

/* ★ 液体流动参数（G.setFluidConfig 可调，单位：秒 / 格） */
const DEFAULT_FLUID_CONFIG = Object.freeze({
  flowDelay: 0.22,
  recheckDelay: 0.35,
  maxPerFrame: 48,
  promotePerFrame: 16,
  maxPending: 3000,
});
const fluidConfig = { ...DEFAULT_FLUID_CONFIG };

function setFluidConfig(partial){
  if (!partial || typeof partial !== 'object') return { ...fluidConfig };
  for (const k of Object.keys(DEFAULT_FLUID_CONFIG)){
    const v = partial[k];
    if (typeof v === 'number' && Number.isFinite(v) && v >= 0){
      fluidConfig[k] = v;
    }
  }
  return { ...fluidConfig };
}

function getFluidConfig(){
  return { ...fluidConfig };
}

function resetFluidConfig(){
  Object.assign(fluidConfig, DEFAULT_FLUID_CONFIG);
  return getFluidConfig();
}

const SLOPE_MAX  = 4;
const SLOPE_NONE = SLOPE_MAX + 1;

const DIRS = [
  [ 1,  0],
  [-1,  0],
  [ 0,  1],
  [ 0, -1],
];

/* ============================================================
   待处理队列
   ============================================================ */
const pending = new Map();
let simTime = 0;
let promoteBudget = 0;

function cellKey(x, y, z){ return x + ',' + y + ',' + z; }

function wakeFluid(x, y, z, delay){
  if (y < Y_MIN || y >= CHH) return;
  const k = cellKey(x, y, z);
  const t = simTime + (delay === undefined ? fluidConfig.flowDelay : delay);

  const cur = pending.get(k);
  if (cur){
    if (t < cur.t) cur.t = t;
    return;
  }
  if (pending.size >= fluidConfig.maxPending) return;
  pending.set(k, { x, y, z, t });
}

function wakeNeighbors(x, y, z, delay){
  wakeFluid(x, y + 1, z, delay);
  wakeFluid(x, y - 1, z, delay);
  wakeFluid(x + 1, y, z, delay);
  wakeFluid(x - 1, y, z, delay);
  wakeFluid(x, y, z + 1, delay);
  wakeFluid(x, y, z - 1, delay);
}

/* ============================================================
   水花事件
   ============================================================ */
const splashListeners = [];
function onFluidSplash(cb){
  if (typeof cb === 'function') splashListeners.push(cb);
}
function fireSplash(x, y, z, strength){
  for (let i = 0; i < splashListeners.length; i++){
    try { splashListeners[i](x, y, z, strength); }
    catch (e){}
  }
}

/* ============================================================
   ★ 跨区块脏标记
   ------------------------------------------------------------
   流体写入某一格后，跨区块边界的邻居 chunk 需要重建
   （否则水面 / 侧面剔除会留着旧几何）。
   每次写入只需要标记 3×3 范围内的 chunk。
   ============================================================ */
function markNeighborChunksDirty(wx, wz){
  const cx = Math.floor(wx / CS);
  const cz = Math.floor(wz / CS);
  for (let dx = -1; dx <= 1; dx++){
    for (let dz = -1; dz <= 1; dz++){
      const c = chunks.get(chunkKey(cx + dx, cz + dz));
      if (c) c.dirty = true;
    }
  }
}

/* ============================================================
   基础工具
   ============================================================ */

function canReplace(nid, fluidId){
  if (nid === 0) return true;
  if (nid === fluidId) return false;
  const blk = BLOCKS[nid];
  if (!blk) return false;
  if (blk.liquid) return false;
  if (blk.solid)  return false;
  return true;
}

function computeSupply(x, y, z, id){
  const aboveId = getBlockWorld(x, y + 1, z);
  if (aboveId === id && getFluidLevel(x, y + 1, z) > 0) return FLUID_MAX_LEVEL;

  let best = 0;
  let nl;

  if (getBlockWorld(x + 1, y, z) === id){
    nl = getFluidLevel(x + 1, y, z); if (nl > best) best = nl;
  }
  if (getBlockWorld(x - 1, y, z) === id){
    nl = getFluidLevel(x - 1, y, z); if (nl > best) best = nl;
  }
  if (getBlockWorld(x, y, z + 1) === id){
    nl = getFluidLevel(x, y, z + 1); if (nl > best) best = nl;
  }
  if (getBlockWorld(x, y, z - 1) === id){
    nl = getFluidLevel(x, y, z - 1); if (nl > best) best = nl;
  }

  return best > 0 ? best - 1 : 0;
}

function placeFluid(x, y, z, id, level, isSrc, falling){
  if (y < Y_MIN || y >= CHH) return;
  if (!isWorldBlockLoaded(x, y, z)) return;

  setBlockWorld(x, y, z, id);
  setFluidLevel(x, y, z, level);
  if (isSrc)   setFluidSource(x, y, z, 1);
  if (falling) setFluidFalling(x, y, z, 1);

  markNeighborChunksDirty(x, z);   // ★
}

function drain(x, y, z){
  if (!isWorldBlockLoaded(x, y, z)) return;
  setBlockWorld(x, y, z, 0);
  markNeighborChunksDirty(x, z);   // ★
}

/* ============================================================
   无限水：单侧源头判定
   ============================================================ */
function isSourceAt(x, y, z, id){
  if (!isWorldBlockLoaded(x, y, z)) return false;
  if (getBlockWorld(x, y, z) !== id) return false;
  return getFluidSource(x, y, z) === 1 || getTerrainSource(x, y, z) === 1;
}

/* ============================================================
   水 / 岩浆反应
   ------------------------------------------------------------
   水与岩浆接触时让岩浆凝固：
     · 岩浆源 → 黑曜石
     · 流动岩浆 → 石头
   水本身保持不动，之后继续按流体规则流动。
   ============================================================ */
const FLUID_NEIGHBORS = [
  [ 1, 0, 0], [-1, 0, 0],
  [ 0, 1, 0], [ 0,-1, 0],
  [ 0, 0, 1], [ 0, 0,-1],
];

function solidifyLava(x, y, z){
  const waterId = B.water ? B.water.id : 0;
  const lavaId = B.lava ? B.lava.id : 0;
  if (!waterId || !lavaId) return false;
  if (getBlockWorld(x, y, z) !== lavaId) return false;

  const target = isSourceAt(x, y, z, lavaId)
    ? (B.obsidian ? B.obsidian.id : 0)
    : (B.stone ? B.stone.id : 0);
  if (!target) return false;

  setBlockWorld(x, y, z, target);
  markNeighborChunksDirty(x, z);
  wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
  return true;
}

/* 返回 true 表示当前格（岩浆）已变成固体，调用方应停止推演 */
function tryWaterLavaReaction(x, y, z, id){
  const waterId = B.water ? B.water.id : 0;
  const lavaId = B.lava ? B.lava.id : 0;
  if (!waterId || !lavaId) return false;

  let hit = false;

  if (id === lavaId){
    for (let i = 0; i < 6; i++){
      const d = FLUID_NEIGHBORS[i];
      if (getBlockWorld(x + d[0], y + d[1], z + d[2]) === waterId){
        hit = solidifyLava(x, y, z);
        break;
      }
    }
    return hit;
  }

  if (id === waterId){
    for (let i = 0; i < 6; i++){
      const d = FLUID_NEIGHBORS[i];
      const nx = x + d[0], ny = y + d[1], nz = z + d[2];
      if (getBlockWorld(nx, ny, nz) === lavaId) solidifyLava(nx, ny, nz);
    }
  }
  return false;
}

function tryPromoteToSource(x, y, z, id){
  if (promoteBudget <= 0){
    wakeFluid(x, y, z, fluidConfig.recheckDelay);
    return false;
  }

  if (isSourceAt(x - 1, y, z, id) && isSourceAt(x + 1, y, z, id)) { /* X */ }
  else if (isSourceAt(x, y, z - 1, id) && isSourceAt(x, y, z + 1, id)) { /* Z */ }
  else return false;

  promoteBudget--;

  const restore = !isRecording();
  if (restore) setRecording(true);
  try {
    setFluidSource(x, y, z, 1);
    setFluidLevel(x, y, z, FLUID_MAX_LEVEL);
  } finally {
    if (restore) setRecording(false);
  }
  markNeighborChunksDirty(x, z);   // ★
  return true;
}

/* ============================================================
   坡度距离
   ============================================================ */
function slopeDistance(x, y, z, dx, dz, id){
  for (let i = 1; i <= SLOPE_MAX; i++){
    const nx = x + dx * i;
    const nz = z + dz * i;

    if (!isWorldBlockLoaded(nx, y, nz)) return SLOPE_NONE;

    const nid = getBlockWorld(nx, y, nz);
    if (nid !== 0 && nid !== id){
      const nblk = BLOCKS[nid];
      if (nblk && (nblk.solid || nblk.liquid)) return SLOPE_NONE;
    }

    if (y - 1 >= Y_MIN){
      const belowId = getBlockWorld(nx, y - 1, nz);
      if (canReplace(belowId, id)) return i;
    }
  }
  return SLOPE_NONE;
}

/* ============================================================
   核心：单格推演
   ============================================================ */
function stepCell(x, y, z){
  if (y < Y_MIN || y >= CHH) return;
  if (!isWorldBlockLoaded(x, y, z)) return;

  const id = getBlockWorld(x, y, z);
  if (id === 0) return;
  const blk = BLOCKS[id];
  if (!blk || !blk.liquid) return;

  /* ★ 水碰到岩浆：岩浆凝固成黑曜石/石头 */
  if (tryWaterLavaReaction(x, y, z, id)) return;

  let isSrc     = getFluidSource(x, y, z)   === 1;
  let isTerrain = getTerrainSource(x, y, z) === 1;
  let level     = getFluidLevel(x, y, z);
  const startLevel = level;

  /* ① 落地检测 */
  if (getFluidFalling(x, y, z)){
    const by = y - 1;
    const bId = (by >= Y_MIN) ? getBlockWorld(x, by, z) : -1;
    if (bId !== -1 && bId !== 0 && bId !== id){
      setFluidFalling(x, y, z, 0);
      fireSplash(x + 0.5, y + 0.9, z + 0.5, 0.85);
    }
  }
  const falling = getFluidFalling(x, y, z) === 1;

  /* ② 无限水 */
  if (!isSrc && !isTerrain && !falling){
    if (tryPromoteToSource(x, y, z, id)){
      isSrc = true;
      level = FLUID_MAX_LEVEL;
      wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
    }
  }

  /* ③ 供给计算 */
  if (isSrc || isTerrain){
    if (level !== FLUID_MAX_LEVEL){
      setFluidLevel(x, y, z, FLUID_MAX_LEVEL);
      level = FLUID_MAX_LEVEL;
    }
  } else if (falling){
    const aboveId = getBlockWorld(x, y + 1, z);
    const aboveLv = (aboveId === id) ? getFluidLevel(x, y + 1, z) : 0;
    if (aboveLv === 0){
      drain(x, y, z);
      wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
      return;
    }
    if (level !== FLUID_MAX_LEVEL){
      setFluidLevel(x, y, z, FLUID_MAX_LEVEL);
      level = FLUID_MAX_LEVEL;
    }
  } else {
    const next = computeSupply(x, y, z, id);
    if (next <= 0){
      drain(x, y, z);
      wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
      return;
    }
    if (next !== level){
      setFluidLevel(x, y, z, next);
      level = next;
    }
  }

  /* ④ 竖直流动 */
  const belowY = y - 1;
  if (belowY >= Y_MIN){
    const belowId = getBlockWorld(x, belowY, z);

    if (canReplace(belowId, id)){
      placeFluid(x, belowY, z, id, FLUID_MAX_LEVEL, false, true);
      wakeFluid(x, belowY, z, fluidConfig.flowDelay);
      if (level !== startLevel) wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
      return;
    }

    if (belowId === id){
      if (!getFluidSource(x, belowY, z) && !getTerrainSource(x, belowY, z)){
        const bl = getFluidLevel(x, belowY, z);
        if (bl < FLUID_MAX_LEVEL){
          setFluidLevel(x, belowY, z, FLUID_MAX_LEVEL);
          setFluidFalling(x, belowY, z, 1);
          wakeFluid(x, belowY, z, fluidConfig.recheckDelay);
        }
      }
      if (level !== startLevel) wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
      return;
    }
  }

  /* ⑤ 水平扩散（坡度优先） */
  if (level > 1){
    const spread = level - 1;

    const slopes = [SLOPE_NONE, SLOPE_NONE, SLOPE_NONE, SLOPE_NONE];
    let minSlope = SLOPE_NONE;

    for (let d = 0; d < 4; d++){
      const s = slopeDistance(x, y, z, DIRS[d][0], DIRS[d][1], id);
      slopes[d] = s;
      if (s < minSlope) minSlope = s;
    }

    if (minSlope === SLOPE_NONE){
      for (let d = 0; d < 4; d++){
        spreadTo(x + DIRS[d][0], y, z + DIRS[d][1], id, spread);
      }
    } else {
      for (let d = 0; d < 4; d++){
        if (slopes[d] === minSlope){
          spreadTo(x + DIRS[d][0], y, z + DIRS[d][1], id, spread);
        }
      }
    }
  }

  if (level !== startLevel) wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
}

function spreadTo(nx, y, nz, id, spread){
  if (spread <= 0) return;
  if (y < Y_MIN || y >= CHH) return;
  if (!isWorldBlockLoaded(nx, y, nz)) return;

  /* ★ 可取消：mod 可以拦住某一格/某一方向的扩散 */
  if (emitCancellable('fluid.spread:before', nx, y, nz, id, spread)) return;

  const nid = getBlockWorld(nx, y, nz);

  if (canReplace(nid, id)){
    placeFluid(nx, y, nz, id, spread, false, false);
    wakeFluid(nx, y, nz, fluidConfig.flowDelay);
    return;
  }
  if (nid !== id) return;
  if (getFluidSource(nx, y, nz) || getTerrainSource(nx, y, nz)) return;

  const cur = getFluidLevel(nx, y, nz);
  if (cur >= spread) return;

  setFluidLevel(nx, y, nz, spread);
  markNeighborChunksDirty(nx, nz);   // ★
  wakeFluid(nx, y, nz, fluidConfig.recheckDelay);
}

/* ============================================================
   每帧更新
   ============================================================ */
function updateFluid(dt, playerPos, simBlocks){
  if (!(dt > 0)) return;
  simTime += dt;
  if (pending.size === 0) return;

  const rangeBlocks = Math.max(2, Math.min(32, simBlocks || 8));
  const rangeUnits  = rangeBlocks * 16;
  const rangeSq     = rangeUnits * rangeUnits;
  const px = playerPos ? playerPos.x : 0;
  const pz = playerPos ? playerPos.z : 0;

  const due = [];
  let budget = fluidConfig.maxPerFrame;

  for (const [k, e] of pending){
    if (e.t > simTime) continue;

    if (playerPos){
      const dx = e.x - px;
      const dz = e.z - pz;
      if (dx * dx + dz * dz > rangeSq) continue;
    }

    due.push({ k, x: e.x, y: e.y, z: e.z, t: e.t });
    if (--budget <= 0) break;
  }
  if (due.length === 0) return;

  due.sort((a, b) => b.y - a.y);

  promoteBudget = fluidConfig.promotePerFrame;

  setRecording(false);
  try {
    for (let i = 0; i < due.length; i++){
      const e = due[i];
      if (!pending.has(e.k)) continue;
      pending.delete(e.k);

      /* ★ 可取消：拦截整个格子的这次流动（mod 可做"冻结水体"） */
      if (emitCancellable('fluid.tick:before', e.x, e.y, e.z, getBlockWorld(e.x, e.y, e.z))) continue;

      try {
        stepCell(e.x, e.y, e.z);
      } catch (err){
        /* 单格失败不影响其他格 */
      }
    }
  } finally {
    setRecording(true);
  }
}

/* ============================================================
   对外：诊断 / 重置
   ============================================================ */
function getActiveFluidCount(){ return pending.size; }
function getPendingCount(){ return pending.size; }

function resetFluid(){
  pending.clear();
  simTime = 0;
  promoteBudget = 0;
}

function createSource(x, y, z, id){
  if (y < Y_MIN || y >= CHH) return false;
  if (!isWorldBlockLoaded(x, y, z)) return false;
  const blk = BLOCKS[id];
  if (!blk || !blk.liquid) return false;

  placeFluid(x, y, z, id, FLUID_MAX_LEVEL, true, false);
  wakeFluid(x, y, z, 0);
  wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
  return true;
}

function removeSource(x, y, z){
  if (y < Y_MIN || y >= CHH) return false;
  const id = getBlockWorld(x, y, z);
  if (id === 0) return false;
  const blk = BLOCKS[id];
  if (!blk || !blk.liquid) return false;

  drain(x, y, z);
  wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
  return true;
}

/* ============================================================
   ★ 区块载入后唤醒水体
   ------------------------------------------------------------
   流体队列只会因为「方块被写 / 邻块变化」而入队。自然生成或 mod
   生成器直接写进 chunk.blocks 的水体，从来没进过队列 —— 表现就是
   「山顶的水悬在半空不流，玩家碰一下才突然开始流」。
   区块 ready 时扫一遍，把上方或四侧暴露的液体入队，让它们按正常
   流体规则向下 / 向外流动。完全被包围的水（海底等）不入队，开销很小。
   ============================================================ */
function wakeChunkFluids(chunk){
  if (!chunk || !chunk.blocks || !chunk.fluid) return;
  const blocks = chunk.blocks;
  const bx = chunk.cx * CS, bz = chunk.cz * CS;
  const minY = chunk.minY != null ? Math.max(Y_MIN, chunk.minY) : Y_MIN;
  const maxY = chunk.maxY != null ? Math.min(CHH - 1, chunk.maxY) : CHH - 1;
  const LAYER = CS * CS;

  for (let y = maxY; y >= minY; y--){
    for (let z = 0; z < CS; z++){
      for (let x = 0; x < CS; x++){
        const i = (((y - Y_MIN) * CS) + z) * CS + x;
        const id = blocks[i];
        if (id === 0) continue;
        const blk = BLOCKS[id];
        /* 只唤醒水：自然岩浆瀑布不在本次修复范围，扫描也更省。 */
        if (!blk || !blk.liquid || blk.name !== 'water') continue;

        let exposed = false;

        /* 上方是空气 / 花草 / 世界顶部 → 可以往下落或向外流 */
        const aboveId = (y + 1 < CHH) ? blocks[i + LAYER] : 0;
        const aboveBlk = BLOCKS[aboveId];
        if (!aboveBlk || !aboveBlk.solid) exposed = true;

        if (!exposed){
          /* 四侧暴露：水平邻居不是同类液体、且不是固体 */
          const wx = bx + x, wz = bz + z;
          const nbs = [
            x === 0      ? getBlockWorld(wx - 1, y, wz) : blocks[i - 1],
            x === CS - 1 ? getBlockWorld(wx + 1, y, wz) : blocks[i + 1],
            z === 0      ? getBlockWorld(wx, y, wz - 1) : blocks[i - CS],
            z === CS - 1 ? getBlockWorld(wx, y, wz + 1) : blocks[i + CS],
          ];
          for (let n = 0; n < 4; n++){
            const nid = nbs[n];
            if (nid === id) continue;
            const nb = BLOCKS[nid];
            if (!nb || !nb.solid){ exposed = true; break; }
          }
        }

        if (exposed) wakeFluid(bx + x, y, bz + z, fluidConfig.flowDelay);
      }
    }
  }
}

/* ============================================================
   挂接 terrain.js 的方块变化通知
   ============================================================ */
/* ★ 合并成单文件后模块初始化顺序变了：这里执行时 terrain.js 的
   onFluidWakeCb 可能还没初始化（循环依赖 TDZ）。延后一拍再挂。 */
queueMicrotask(() => {
  try {
    setOnFluidWake((x, y, z) => {
      wakeFluid(x, y, z, fluidConfig.recheckDelay);
      wakeNeighbors(x, y, z, fluidConfig.recheckDelay);
    });
    setOnChunkFluidReady(wakeChunkFluids);
  } catch(e){ console.warn('[fluid] 挂接方块变化通知失败:', e); }
});

/* =================================================================
   splash.js
   ================================================================= */
/* ============================================================
   splash.js —— 水花 / 泡泡 / 岩浆火花粒子（像素风）
   ------------------------------------------------------------
   · 三种粒子池：water（像素水点）/ bubble（像素泡泡）/ lava（岩浆）
   · 池化 Sprite，复用不 GC
   · 纹理全部像素风（NearestFilter，无 mipmap，无插值）
   · 订阅 fluid.js 的 onFluidSplash 事件（落差下落）
   · 岩浆火花由 main.js 扫描触发
   ============================================================ */







const GRAVITY      = 20;      // 水/岩浆粒子下落加速度
const BUBBLE_RISE  = 3.5;     // 泡泡上浮速度（每秒 +3.5 世界单位）

const POOLS = {
  water:  { active: [], pool: [], tex: null, max: 256 },
  bubble: { active: [], pool: [], tex: null, max: 128 },
  lava:   { active: [], pool: [], tex: null, max: 96  }
};

/* ============================================================
   ★ 像素纹理
   ============================================================ */

/**
 * 水粒子：2x2 全填充的方块，纯色浅蓝。
 * Sprite scale 决定它显示多大 —— 看起来就是一个"像素点"。
 */
function makeWaterTex(){
  const S = 2;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(180, 225, 255, 1)';
  ctx.fillRect(0, 0, S, S);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  return t;
}

/**
 * 泡泡：8x8 环形像素轮廓
 *
 *   ..####..
 *   .#....#.
 *   #......#
 *   #......#
 *   #......#
 *   #......#
 *   .#....#.
 *   ..####..
 *
 * 左上角加一个白色高光像素，看起来像光打在泡泡上。
 */
function makeBubbleTex(){
  const S = 8;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');

  const pattern = [
    '..####..',
    '.#....#.',
    '#......#',
    '#......#',
    '#......#',
    '#......#',
    '.#....#.',
    '..####..',
  ];

  /* 主体：偏白偏蓝 */
  ctx.fillStyle = 'rgba(220, 240, 255, 0.95)';
  for (let y = 0; y < S; y++){
    const row = pattern[y];
    for (let x = 0; x < S; x++){
      if (row[x] === '#') ctx.fillRect(x, y, 1, 1);
    }
  }

  /* 左上角高光 */
  ctx.fillStyle = 'rgba(255, 255, 255, 1)';
  ctx.fillRect(2, 1, 1, 1);
  ctx.fillRect(1, 2, 1, 1);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  return t;
}

/**
 * 岩浆火花：4x4 像素块
 *   外圈橙红 → 内圈亮黄 → 中心白
 */
function makeLavaTex(){
  const S = 4;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');

  ctx.fillStyle = 'rgba(255, 120, 30, 1)';
  ctx.fillRect(0, 0, S, S);

  ctx.fillStyle = 'rgba(255, 220, 120, 1)';
  ctx.fillRect(1, 1, 2, 2);

  ctx.fillStyle = 'rgba(255, 255, 200, 1)';
  ctx.fillRect(1, 1, 1, 1);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  return t;
}

function ensureTex(kind){
  const p = POOLS[kind];
  if (!p.tex){
    if (kind === 'lava')        p.tex = makeLavaTex();
    else if (kind === 'bubble') p.tex = makeBubbleTex();
    else                        p.tex = makeWaterTex();
  }
  return p.tex;
}

/* ============================================================
   粒子池
   ============================================================ */
function createParticle(kind){
  const mat = new THREE.SpriteMaterial({
    map: ensureTex(kind),
    transparent: true,
    depthWrite: false,
    fog: true
  });
  const mesh = new THREE.Sprite(mat);
  mesh.visible = false;
  scene.add(mesh);
  return {
    kind,
    mesh,
    vel: new THREE.Vector3(),
    life: 0,
    maxLife: 1,
    baseScale: 0.1,
    wobblePhase: Math.random() * 6.28,
    wasInWater: false
  };
}

function acquire(kind){
  const p = POOLS[kind];
  if (p.pool.length > 0) return p.pool.pop();
  if (p.active.length + p.pool.length >= p.max) return null;
  return createParticle(kind);
}

function release(kind, item){
  item.mesh.visible = false;
  POOLS[kind].pool.push(item);
}

function emit(kind, x, y, z, count, opts){
  const p = POOLS[kind];
  for (let i = 0; i < count; i++){
    const item = acquire(kind);
    if (!item) return;
    item.mesh.position.set(
      x + (Math.random() - 0.5) * opts.spread,
      y + Math.random() * 0.15,
      z + (Math.random() - 0.5) * opts.spread
    );
    item.vel.set(
      (Math.random() - 0.5) * opts.hVel,
      opts.minVy + Math.random() * opts.vyRange,
      (Math.random() - 0.5) * opts.hVel
    );
    item.maxLife = opts.minLife + Math.random() * opts.lifeRange;
    item.life = item.maxLife;
    item.baseScale = opts.minScale + Math.random() * opts.scaleRange;
    item.mesh.scale.setScalar(item.baseScale);
    item.mesh.material.opacity = 1;
    item.mesh.visible = true;
    item.wobblePhase = Math.random() * 6.28;
    item.wasInWater = false;
    p.active.push(item);
  }
}

/* ============================================================
   工具：判断坐标是否在水里（泡泡出水破裂用）
   ============================================================ */
function isWaterAt(x, y, z){
  const id = getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z));
  if (id === 0) return false;
  const b = BLOCKS[id];
  return !!(b && b.name === 'water');
}

/* ============================================================
   对外：水花 / 泡泡 / 岩浆
   ============================================================ */

/** 水花：像素水点四散飞溅 */
function spawnSplash(x, y, z, strength){
  const s = Math.max(0.4, Math.min(2.5, strength || 1));
  emit('water', x, y, z, Math.round(4 + s * 5), {
    spread: 0.6,
    hVel: 2 + s * 2,
    minVy: 1.5,
    vyRange: 1.5 + s * 1.6,
    minLife: 0.45,
    lifeRange: 0.45,
    minScale: 0.09,
    scaleRange: 0.05
  });
}

/**
 * 泡泡：从水下往上浮，到水面炸掉。
 * count 不传默认 1 个。
 */
function spawnBubble(x, y, z, count){
  const n = count === undefined ? 1 : count;
  emit('bubble', x, y, z, n, {
    spread: 0.5,
    hVel: 0.3,
    minVy: -0.3,
    vyRange: 0.6,
    minLife: 1.6,
    lifeRange: 1.8,
    minScale: 0.14,
    scaleRange: 0.08
  });
}

/** 岩浆火花 */
function spawnLavaSpark(x, y, z, strength){
  const s = Math.max(0.3, Math.min(1.5, strength || 1));
  emit('lava', x, y, z, Math.round(1 + s * 2), {
    spread: 0.4,
    hVel: 1.2 + s * 1.2,
    minVy: 1.8,
    vyRange: 1.8 + s * 1.2,
    minLife: 0.5,
    lifeRange: 0.6,
    minScale: 0.08,
    scaleRange: 0.05
  });
}

/* ============================================================
   每帧更新
   ============================================================ */
function updateSplash(dt){
  /* ---- 水 + 岩浆：受重力下落 ---- */
  for (const kind of ['water', 'lava']){
    const p = POOLS[kind];
    for (let i = p.active.length - 1; i >= 0; i--){
      const item = p.active[i];
      item.life -= dt;
      if (item.life <= 0){
        p.active.splice(i, 1);
        release(kind, item);
        continue;
      }
      item.vel.y -= GRAVITY * dt;
      item.mesh.position.x += item.vel.x * dt;
      item.mesh.position.y += item.vel.y * dt;
      item.mesh.position.z += item.vel.z * dt;

      const t = item.life / item.maxLife;
      item.mesh.material.opacity = t < 0.7 ? (t / 0.7) : 1;
      item.mesh.scale.setScalar(item.baseScale * (0.5 + t * 0.5));
    }
  }

  /* ---- 泡泡：上浮 + 摆动 + 出水炸掉 ---- */
  {
    const p = POOLS.bubble;
    for (let i = p.active.length - 1; i >= 0; i--){
      const item = p.active[i];
      item.life -= dt;
      if (item.life <= 0){
        p.active.splice(i, 1);
        release('bubble', item);
        continue;
      }

      /* 上浮 + 水平摆动 */
      item.wobblePhase += dt * 4;
      const wobbleX = Math.sin(item.wobblePhase) * 0.3;
      const wobbleZ = Math.cos(item.wobblePhase * 0.7) * 0.3;

      item.mesh.position.x += (item.vel.x + wobbleX) * dt;
      item.mesh.position.y += (BUBBLE_RISE + item.vel.y) * dt;
      item.mesh.position.z += (item.vel.z + wobbleZ) * dt;

      /* 出水检测：曾经在水里、现在不在水里 → 提前破裂 */
      const pos = item.mesh.position;
      const nowInWater = isWaterAt(pos.x, pos.y, pos.z);
      if (nowInWater){
        item.wasInWater = true;
      } else if (item.wasInWater){
        /* 出水 → 寿命直接归零，让下面的淡出逻辑接管 */
        item.life = Math.min(item.life, 0.12);
      }

      /* 淡入淡出：中间最亮，两头透明 */
      const t = item.life / item.maxLife;
      const fade = t < 0.2 ? t / 0.2 : (t > 0.85 ? (1 - t) / 0.15 : 1);
      item.mesh.material.opacity = Math.max(0, Math.min(1, fade)) * 0.9;

      /* 略微长大 */
      item.mesh.scale.setScalar(item.baseScale * (0.8 + (1 - t) * 0.4));
    }
  }
}

function clearSplash(){
  for (const kind of ['water', 'bubble', 'lava']){
    const p = POOLS[kind];
    for (const item of p.active) release(kind, item);
    p.active.length = 0;
  }
}

/* ============================================================
   自动订阅流体事件（落差下落）
   ============================================================ */
onFluidSplash((x, y, z, s) => {
  spawnSplash(x, y, z, s);
  /* 水花里夹带 1~3 个泡泡，看起来更活 */
  spawnBubble(x, y, z, 1 + Math.floor(Math.random() * 3));
  playSFX('water.fall');
});

/* =================================================================
   chunk-db.js
   ================================================================= */
/* ============================================================
   chunk-db.js —— 区块磁盘缓存（bundle 批量版）
   ------------------------------------------------------------
   ★ 本轮优化：
     · 队列攒到 BUNDLE_SIZE 个，打包成 bundle，一次 HTTP PUT
     · 32 个 chunk → 1 次 HTTP 往返（之前 32 次）
     · gzip 仍然每 chunk 独立（worker 池并行），保持读取兼容
     · FLUSH_INTERVAL 2000ms → 200ms（不再"等半天才写"）
     · 服务端拆包后写 `<cx>_<cz>.bin.gz`，读取端完全不变
   ============================================================ */




const MAGIC = [0x33, 0x44, 0x4D, 0x43];   // "3DMC"（单 chunk 文件）
const BUNDLE_MAGIC = [0x33, 0x44, 0x4D, 0x32]; // "3DM2"（bundle）
const VERSION = 1;
const HEADER_SIZE = 24;

const BUNDLE_SIZE = 32;                     // ★ 一次打包多少个 chunk

let WRITE_QUEUE_MAX      = 64;
let FLUSH_THRESHOLD      = 8;
let MAX_CONCURRENT_WRITE = 1;               // ★ bundle 一次只有 1 个在飞
const FLUSH_INTERVAL_MS  = 200;             // ★ 2000 → 200
const LOAD_TIMEOUT_MS    = 2000;

let _saveId  = null;
let _enabled = true;

const _queue = [];
let _flushTimer = null;
let _flushing = false;
let _inflight = 0;
let _written  = 0;
let _dropped  = 0;
let _failed   = 0;

let _onChunkPersisted = null;

/* ============================================================
   压缩 worker 池
   ============================================================ */
let _storagePool = null;
let _storagePoolFailed = false;

function _getStoragePool(){
  if (_storagePoolFailed) return null;
  if (_storagePool) return _storagePool;
  if (!FLAGS.workerEnabled) return null;

  try {
    _storagePool = new WorkerPool(
      new URL('../worker/storage-worker.js', import.meta.url).href,
      2
    );
    console.log('[chunk-db] 压缩 worker 池已启动 (×2)');
  } catch(e){
    console.warn('[chunk-db] 压缩 worker 池创建失败，降级主线程:', e);
    _storagePoolFailed = true;
    return null;
  }
  return _storagePool;
}

async function _gzipMain(data){
  const cs = new CompressionStream('gzip');
  const w  = cs.writable.getWriter();
  w.write(data);
  w.close();
  const ab = await new Response(cs.readable).arrayBuffer();
  return new Uint8Array(ab);
}

async function _gunzipMain(data){
  const ds = new DecompressionStream('gzip');
  const w  = ds.writable.getWriter();
  w.write(data);
  w.close();
  const ab = await new Response(ds.readable).arrayBuffer();
  return new Uint8Array(ab);
}

async function _gzip(data){
  const pool = _getStoragePool();
  if (!pool) return _gzipMain(data);
  try {
    const res = await pool.post('gzip', { data }, [data.buffer]);
    if (res.error) throw new Error(res.error);
    return res.data;
  } catch(e){
    console.warn('[chunk-db] gzip worker 失败，本块跳过:', e);
    return null;
  }
}

async function _gunzip(data){
  const pool = _getStoragePool();
  if (!pool) return _gunzipMain(data);
  try {
    const res = await pool.post('gunzip', { data }, [data.buffer]);
    if (res.error) throw new Error(res.error);
    return res.data;
  } catch(e){
    console.warn('[chunk-db] gunzip worker 失败，返回 null:', e);
    return null;
  }
}

/* ============================================================
   路径工具
   ============================================================ */
function _chunkPath(cx, cz, dim){
  const d = dim || getActiveDimension();
  const sub = (d === 'overworld') ? 'chunks' : `dims/${d}/chunks`;
  return `/api/saves/${encodeURIComponent(_saveId)}/${sub}/${cx}_${cz}.bin.gz`;
}

function _bundlePath(){
  return `/api/saves/${encodeURIComponent(_saveId)}/chunks/bundle`;
}

/* ============================================================
   配置接口
   ============================================================ */
function setChunkDbSaveId(id){
  if (_saveId === id) return;
  _saveId = id || null;
  _queue.length = 0;
}

function setDiskCacheEnabled(on){ _enabled = !!on; }
function getDiskCacheEnabled(){ return _enabled; }
function hasSaveId(){ return !!_saveId; }

function setOnChunkPersisted(fn){ _onChunkPersisted = fn; }

function getSaveQueueStats(){
  return {
    pending: _queue.length,
    saving:  _inflight,
    written: _written,
    dropped: _dropped,
    failed:  _failed,
    disabled: !_enabled || !_saveId,
  };
}

async function clearDiskCache(){
  _queue.length = 0;
  _written = _dropped = _failed = 0;
  if (_flushTimer){ clearTimeout(_flushTimer); _flushTimer = null; }
}

/* ============================================================
   运行时调参
   ============================================================ */
function setWriteQueueMax(n){
  const v = Math.floor(Number(n));
  if (!isFinite(v)) return WRITE_QUEUE_MAX;
  WRITE_QUEUE_MAX = Math.max(2, Math.min(128, v));
  FLUSH_THRESHOLD = Math.max(BUNDLE_SIZE, Math.floor(WRITE_QUEUE_MAX / 4));
  return WRITE_QUEUE_MAX;
}
function getWriteQueueMax(){ return WRITE_QUEUE_MAX; }

function setMaxConcurrentWrite(n){
  const v = Math.floor(Number(n));
  if (!isFinite(v)) return MAX_CONCURRENT_WRITE;
  /* bundle 模式下 1 就够，多了反而争抢 */
  MAX_CONCURRENT_WRITE = Math.max(1, Math.min(2, v));
  return MAX_CONCURRENT_WRITE;
}
function getMaxConcurrentWrite(){ return MAX_CONCURRENT_WRITE; }

/* ============================================================
   编码 / 解码
   ============================================================ */
function encodeChunk(chunk){
  if (!chunk || !chunk.blocks) return null;

  const blocks = chunk.blocks;
  const fluid  = chunk.fluid;
  const topY   = chunk.topY;

  const blocksLen = blocks.length;
  const fluidLen  = fluid ? fluid.length : 0;
  const topYLen   = topY  ? topY.length  : 0;

  const total = HEADER_SIZE + blocksLen + fluidLen + topYLen * 2;
  const buf  = new Uint8Array(total);
  const view = new DataView(buf.buffer);
  let o = 0;

  buf[o++] = MAGIC[0]; buf[o++] = MAGIC[1];
  buf[o++] = MAGIC[2]; buf[o++] = MAGIC[3];
  view.setUint16(o, VERSION, true); o += 2;
  view.setUint16(o, CHH,     true); o += 2;
  view.setInt16 (o, chunk.minY || 0, true); o += 2;
  view.setInt16 (o, chunk.maxY || 0, true); o += 2;
  view.setUint32(o, blocksLen, true); o += 4;
  view.setUint32(o, fluidLen,  true); o += 4;
  view.setUint32(o, topYLen,   true); o += 4;

  buf.set(blocks, o); o += blocksLen;
  if (fluidLen){ buf.set(fluid, o); o += fluidLen; }
  if (topYLen){
    for (let i = 0; i < topYLen; i++){
      view.setInt16(o, topY[i], true);
      o += 2;
    }
  }
  return buf;
}

function decodeChunk(buf){
  if (!buf || buf.length < HEADER_SIZE) return null;

  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let o = 0;

  if (buf[o++] !== MAGIC[0] || buf[o++] !== MAGIC[1] ||
      buf[o++] !== MAGIC[2] || buf[o++] !== MAGIC[3]) return null;

  const version = view.getUint16(o, true); o += 2;
  if (version !== VERSION) return null;

  const chh = view.getUint16(o, true); o += 2;
  if (chh !== CHH) return null;

  const minY = view.getInt16(o, true); o += 2;
  const maxY = view.getInt16(o, true); o += 2;
  const blocksLen = view.getUint32(o, true); o += 4;
  const fluidLen  = view.getUint32(o, true); o += 4;
  const topYLen   = view.getUint32(o, true); o += 4;

  const expectedBlocks = CS * CS * COL_H;
  if (blocksLen !== expectedBlocks) return null;
  if (fluidLen !== 0 && fluidLen !== expectedBlocks) return null;

  const blocks = new Uint8Array(blocksLen);
  blocks.set(buf.subarray(o, o + blocksLen));
  o += blocksLen;

  const fluid = new Uint8Array(expectedBlocks);
  if (fluidLen){
    fluid.set(buf.subarray(o, o + fluidLen));
    o += fluidLen;
  }

  const topY = new Int16Array(topYLen);
  for (let i = 0; i < topYLen; i++){
    topY[i] = view.getInt16(o, true);
    o += 2;
  }

  return { blocks, fluid, topY, minY, maxY };
}

/* ============================================================
   写盘：入队 + bundle flush
   ============================================================ */
function queueSaveChunk(chunk, dim){
  if (!_enabled || !_saveId) return false;

  const buf = encodeChunk(chunk);
  if (!buf) return false;

  while (_queue.length >= WRITE_QUEUE_MAX){
    _queue.shift();
    _dropped++;
  }

  const lockedDim = dim || getActiveDimension();

  _queue.push({
    cx: chunk.cx,
    cz: chunk.cz,
    buf,
    dim: lockedDim,
  });

  /* ★ 攒够 FLUSH_THRESHOLD 立即 flush，否则 200ms 后自动 */
  if (_queue.length >= FLUSH_THRESHOLD){
    _flush();
  } else {
    _scheduleFlush();
  }
  return true;
}

function _scheduleFlush(){
  if (_flushTimer) return;
  _flushTimer = setTimeout(() => {
    _flushTimer = null;
    _flush();
  }, FLUSH_INTERVAL_MS);
}

function _flush(){
  if (_flushing) return;
  if (_queue.length === 0) return;
  _flushing = true;

  try {
    while (_queue.length > 0 && _inflight < MAX_CONCURRENT_WRITE){
      /* ★ 一次取最多 BUNDLE_SIZE 个 */
      const bundle = _queue.splice(
        0, Math.min(BUNDLE_SIZE, _queue.length)
      );
      _inflight++;
      _writeBundle(bundle).finally(() => {
        _inflight--;
        if (_queue.length > 0) _flush();
      });
    }
  } finally {
    _flushing = false;
  }
}

/* ============================================================
   写 bundle
   ------------------------------------------------------------
   Bundle 格式：
     [4] magic "3DM2"
     [2] version = 1
     [2] count
     for each chunk:
       [4] cx (int32)
       [4] cz (int32)
       [1] dimLen
       [dimLen] dimName (utf8)
       [4] dataLen
       [dataLen] compressedChunkData (gzip, 原样从 _gzip 拿)
   ============================================================ */
async function _writeBundle(items){
  try {
    /* ① 所有 chunk 并行 gzip */
    const compressed = await Promise.all(
      items.map(item => _gzip(item.buf))
    );

    /* ② 先过滤出真正成功的 chunk
       ------------------------------------------------------------
       之前 header.count 写的是 items.length，但 gzip 失败会被 continue
       跳过，导致 header 声明数 > 实际数据 → 服务端按 count 循环读越界。
       更糟的是 _onChunkPersisted 遍历 items 而不是成功的那批，
       让"没写盘的 chunk"也被回调"已持久化"，terrain.js 里会因此删掉
       它的 edits 记录 —— 下次加载时区块从磁盘读不到、edits 也没了，
       玩家改过的方块直接消失。
       这里统一改成 valid 列表，header / 写入 / 回调全部以它为准。 */
    const encoder = new TextEncoder();
    const valid = [];
    for (let i = 0; i < items.length; i++){
      const c = compressed[i];
      if (!c){ _failed++; continue; }
      const item = items[i];
      const dimBytes = encoder.encode(item.dim);
      const dimLen = dimBytes.length;
      if (dimLen > 255 || c.length > 0xFFFFFFFF){ _failed++; continue; }
      valid.push({ item, data: c, dimBytes, dimLen });
    }

    if (valid.length === 0) return;

    /* ③ 写 header —— count = valid.length（就是实际打包数） */
    const parts = [];
    const header = new Uint8Array(8);
    header[0] = BUNDLE_MAGIC[0];
    header[1] = BUNDLE_MAGIC[1];
    header[2] = BUNDLE_MAGIC[2];
    header[3] = BUNDLE_MAGIC[3];
    const hview = new DataView(header.buffer);
    hview.setUint16(4, 1, true);
    hview.setUint16(6, valid.length, true);
    parts.push(header);

    /* ④ 写每个有效项 */
    for (const { item, data, dimBytes, dimLen } of valid){
      const itemHeader = new Uint8Array(4 + 4 + 1 + dimLen + 4);
      const iview = new DataView(itemHeader.buffer);
      iview.setInt32(0, item.cx, true);
      iview.setInt32(4, item.cz, true);
      itemHeader[8] = dimLen;
      itemHeader.set(dimBytes, 9);
      iview.setUint32(9 + dimLen, data.length, true);
      parts.push(itemHeader);
      parts.push(data);
    }

    /* ⑤ 合并 */
    let totalLen = 0;
    for (const p of parts) totalLen += p.length;
    const buf = new Uint8Array(totalLen);
    let off = 0;
    for (const p of parts){
      buf.set(p, off);
      off += p.length;
    }

    /* ⑥ 一次 HTTP PUT */
    const r = await fetch(_bundlePath(), {
      method: 'PUT',
      body: buf,
      headers: { 'Content-Type': 'application/octet-stream' },
    });

    if (r.ok){
      _written += valid.length;
      if (_onChunkPersisted){
        /* 只对真正写盘的 chunk 回调 —— 失败的 chunk 的 edits 必须保留，
           下次 unload 时重试写盘才有数据可用 */
        for (const { item } of valid){
          try { _onChunkPersisted(item.cx, item.cz, item.dim); }
          catch(e){}
        }
      }
    } else {
      _failed += valid.length;
    }
  } catch (e){
    _failed += items.length;
    console.warn('[chunk-db] bundle 写盘失败:', e);
  }
}

async function flushSaveQueue(){
  while (_inflight > 0 || _queue.length > 0){
    _flush();
    await new Promise(r => setTimeout(r, 50));
  }
  return true;
}

/* ============================================================
   读盘（不变）
   ============================================================ */
async function loadChunkFromDisk(cx, cz, dim){
  if (!_enabled || !_saveId) return null;

  const lockedDim = dim || getActiveDimension();

  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), LOAD_TIMEOUT_MS);
    let r;
    try {
      r = await fetch(_chunkPath(cx, cz, lockedDim), {
        method: 'GET',
        signal: ctrl.signal,
      });
    } finally {
      clearTimeout(timer);
    }
    if (!r.ok) return null;

    const compressed = new Uint8Array(await r.arrayBuffer());
    const raw = await _gunzip(compressed);
    if (!raw) return null;

    return decodeChunk(raw);
  } catch (e){
    return null;
  }
}

/* =================================================================
   re-export
   ================================================================= */
export {
  DEFAULT_TERRAIN,
  registerBiome,
  getBiome,
  getBiomeByName,
  getBiomeById,
  listBiomes,
  getBiomeCount,
  peekNextBiomeId,
  listBiomesSerializable,
  clearAllBiomes,
  FLUID_MAX_LEVEL,
  setFluidConfig,
  getFluidConfig,
  resetFluidConfig,
  wakeFluid,
  onFluidSplash,
  updateFluid,
  getActiveFluidCount,
  getPendingCount,
  resetFluid,
  createSource,
  removeSource,
  spawnSplash,
  spawnBubble,
  spawnLavaSpark,
  updateSplash,
  clearSplash,
  setChunkDbSaveId,
  setDiskCacheEnabled,
  getDiskCacheEnabled,
  hasSaveId,
  setOnChunkPersisted,
  getSaveQueueStats,
  clearDiskCache,
  setWriteQueueMax,
  getWriteQueueMax,
  setMaxConcurrentWrite,
  getMaxConcurrentWrite,
  encodeChunk,
  decodeChunk,
  queueSaveChunk,
  flushSaveQueue,
  loadChunkFromDisk
};
