/* ============================================================
   weather.js —— 天气系统（晴/阴/雨/暴雨 + 降雪 + 积雪 + 融化）
   ------------------------------------------------------------
   状态机：CLEAR → CLOUDY → RAIN → STORM 之间按权重随机切换
   强度：平滑插值（每秒最多变 0.5）
   降水形态：玩家位置附近温度 < 0.20 → 雪，否则雨
   地面效果 —— 两套触发，别搞混（这是最容易误解的地方）：
     ★ A. 自然积雪/融雪：只看温度，和天气状态无关
         温度 < 0.08  → 地表积雪、水面结冰（晴天也铺）
         温度 > 0.30  → 融雪；  温度 > 0.40 → 融冰
     ★ B. 下雪积雪：只有正在降水时才铺
         state ∈ {rain, storm} 且 强度 > 0.2 且 温度 < 0.20
     而"飘雪粒子"是另一套：只由 getSnowFactor(玩家所在处温度) 决定，
     天气是晴的时候哪都不会有粒子。
   铺雪时机：
     · 区块一加载就【一次性铺好】applyWeatherGroundToChunk()，不参与慢慢堆
     · 已经加载着的区块：tickWeatherGround() 每 0.8s 更新一次
       （玩家周围 24 格立即响应 + 远处按时间预算轮流扫）
   序列化：{ state, intensity, remaining, seed }
   ============================================================ */

import * as THREE from 'three';
import { emit, CS, CHH, Y_MIN, SEA_LEVEL } from './../core/engine-core.js';
import {
  getBlockWorld, setBlockWorld, getTerrainTopY,
  getSkyLightAt, chunks, setOnChunkReady,
} from './terrain.js';
import { BLOCKS, B } from './blocks.js';
import { scene } from './../render/render-core.js';

export const WEATHER = {
  CLEAR:  'clear',
  CLOUDY: 'cloudy',
  RAIN:   'rain',
  STORM:  'storm',
};

/* 温度阈值（和 world-gen.js 雪层/冰生成保持一致） */
export const TEMP_THRESHOLDS = {
  SNOW:         0.20,   /* 低于此值降水形态是雪 */
  SNOW_ACCUM:   0.20,   /* 低于此值积雪 */
  EXTREME_COLD: 0.08,   /* 低于此值冰雪强制覆盖（不管天气） */
  MELT_SNOW:    0.30,   /* 高于此值融雪 */
  MELT_ICE:     0.40,   /* 高于此值融冰 */
};

const DUR = {
  clear:  [90, 200],
  cloudy: [30, 90],
  rain:   [40, 120],
  storm:  [20, 60],
};

const NEXT = {
  clear:  [[WEATHER.CLOUDY, 0.35], [WEATHER.CLEAR,  0.65]],
  cloudy: [[WEATHER.CLEAR,  0.40], [WEATHER.RAIN,   0.45], [WEATHER.CLOUDY, 0.15]],
  rain:   [[WEATHER.CLOUDY, 0.35], [WEATHER.STORM,  0.20], [WEATHER.RAIN,   0.45]],
  storm:  [[WEATHER.RAIN,   0.75], [WEATHER.CLOUDY, 0.25]],
};

const TARGET_INTENSITY = {
  clear: 0, cloudy: 0.35, rain: 0.7, storm: 1.0,
};

/* ---------- 状态 ---------- */
let _state = WEATHER.CLEAR;
let _targetIntensity = 0;
let _intensity = 0;
let _remaining = 0;
let _weatherSeed = 0;
let _initialized = false;
let _tempFn = null;

/* ---------- 对外查询 ---------- */
export function getWeatherState(){ return _state; }
export function getWeatherIntensity(){ return _intensity; }
export function isPrecipitating(){
  return (_state === WEATHER.RAIN || _state === WEATHER.STORM) && _intensity > 0.1;
}
export function setWeatherTempFn(fn){
  if (typeof fn === 'function') _tempFn = fn;
}

/* ---------- 状态机 ---------- */
function _pickNext(){
  const table = NEXT[_state] || [[WEATHER.CLEAR, 1]];
  let r = Math.random();
  for (const [st, p] of table){
    if (r < p) return st;
    r -= p;
  }
  return WEATHER.CLEAR;
}

export function setWeather(state, opts){
  const s = String(state || '').toLowerCase();
  if (!DUR[s]) return false;
  if (_state === s) return true;
  const old = _state;
  _state = s;
  _targetIntensity = TARGET_INTENSITY[s];
  const range = DUR[s];
  _remaining = range[0] + Math.random() * (range[1] - range[0]);
  if (!opts || opts.silent !== true) emit('weather.change', old, s);
  return true;
}

export function initWeather(cfg){
  if (cfg && typeof cfg === 'object'
      && cfg.state && DUR[cfg.state]){
    _state = cfg.state;
    _targetIntensity = TARGET_INTENSITY[_state];
    _intensity = (typeof cfg.intensity === 'number') ? cfg.intensity : _targetIntensity;
    _remaining = (typeof cfg.remaining === 'number' && cfg.remaining > 0)
      ? cfg.remaining : 120;
    _weatherSeed = (cfg.seed | 0) || (Math.random() * 1e9 | 0);
  } else {
    _state = WEATHER.CLEAR;
    _targetIntensity = 0;
    _intensity = 0;
    _remaining = 100 + Math.random() * 60;
    _weatherSeed = Math.random() * 1e9 | 0;
  }
  _initialized = true;
}

export function serializeWeather(){
  return {
    state: _state,
    intensity: Math.round(_intensity * 1000) / 1000,
    remaining: Math.round(_remaining),
    seed: _weatherSeed,
  };
}

/* ---------- 每帧推进 ---------- */
export function tickWeather(dt){
  if (!_initialized) return;
  const d = Number(dt);
  if (!(d > 0)) return;

  const rate = 0.5;
  const diff = _targetIntensity - _intensity;
  if (Math.abs(diff) < 0.01){
    _intensity = _targetIntensity;
  } else {
    _intensity += Math.sign(diff) * Math.min(Math.abs(diff), rate * d);
  }

  _remaining -= d;
  if (_remaining <= 0){
    setWeather(_pickNext());
  }
}

/* ---------- 地面效果：近场立即响应 + 远处轮流扫 ---------- */
let _groundTimer = 0;
const GROUND_INTERVAL   = 0.8;   /* 秒 */
const GROUND_RADIUS     = 24;    /* ① 玩家周围这个半径内：立即响应 */
const MAX_CHANGES       = 200;   /*    近场每次最多改多少块方块 */
const SWEEP_BUDGET_MS   = 3;     /* ② 远处扫掠每次最多花多少毫秒（自适应设备） */
let _sweepChunk = 0;             /*    扫到第几个 chunk */
let _sweepCol   = 0;             /*    该 chunk 里扫到第几列（0..255，可跨 tick 续扫） */

/**
 * 处理一个 xz 位置的地表天气效果，返回改了几块。
 * ★ 这里只按【温度 + 是否在下雪】决定，不看玩家在哪 ——
 *   以前整个逻辑只跑在玩家半径 24 的圆盘里，所以"站着不动雪就停在
 *   脚下那一圈，往前走才在眼前刷出来"。现在远处由 _sweepPass 补上。
 */
function _groundColumn(wx, wz, py, maxDy, ctx){
  const { snowId, iceId, waterId, isSnowing, T, tempFn, put } = ctx;
  let n = 0;

  /* 水面结冰 / 融冰 */
  if (iceId && waterId && Math.abs(SEA_LEVEL - py) < 30){
    const seaId = getBlockWorld(wx, SEA_LEVEL, wz);
    if (seaId === waterId){
      if (tempFn(wx, SEA_LEVEL, wz) < T.EXTREME_COLD){
        put(wx, SEA_LEVEL, wz, iceId); n++;
      }
    } else if (seaId === iceId){
      if (tempFn(wx, SEA_LEVEL, wz) > T.MELT_ICE){
        put(wx, SEA_LEVEL, wz, waterId); n++;
      }
    }
  }

  /* 陆地积雪 / 融雪 */
  if (!snowId) return n;

  const topY = getTerrainTopY(wx, wz);        /* 未加载 → -1 */
  if (topY < 0) return n;
  if (maxDy !== null && Math.abs(topY - py) > maxDy) return n;

  const surfaceId = getBlockWorld(wx, topY, wz);
  if (!surfaceId) return n;
  const surfaceBlk = BLOCKS[surfaceId];
  if (!surfaceBlk) return n;
  if (surfaceBlk.name === 'water' || surfaceBlk.name === 'ice') return n;
  if (!surfaceBlk.solid && !surfaceBlk.flatRender) return n;
  if (surfaceBlk.name === 'snow_layer') return n;

  const aboveY = topY + 1;
  if (aboveY >= CHH) return n;

  const aboveId = getBlockWorld(wx, aboveY, wz);
  const surfTemp = tempFn(wx, aboveY, wz);

  /* 融雪 */
  if (aboveId === snowId){
    if (surfTemp > T.MELT_SNOW){
      put(wx, aboveY, wz, 0); n++;
    }
    return n;
  }

  /* 积雪：上方是空气 */
  if (aboveId !== 0) return n;
  const shouldSnow = (surfTemp < T.EXTREME_COLD)
                  || (isSnowing && surfTemp < T.SNOW_ACCUM);
  if (shouldSnow){
    put(wx, aboveY, wz, snowId); n++;
  }
  return n;
}

/* ① 玩家周围：优先处理，保证眼前立刻有反应 */
function _nearPass(px, py, pz, ctx){
  const R = GROUND_RADIUS, R2 = R * R;
  let changes = 0;
  for (let dx = -R; dx <= R && changes < MAX_CHANGES; dx++){
    for (let dz = -R; dz <= R && changes < MAX_CHANGES; dz++){
      if (dx * dx + dz * dz > R2) continue;
      changes += _groundColumn(px + dx, pz + dz, py, 40, ctx);
    }
  }
  return changes;
}

/* ② 已加载的 chunk 轮流扫一遍：让远处的地表跟着天气走，
      不再"走到哪铺到哪"。
      用【时间预算】而不是固定条数：慢设备上少扫一点，快设备上多扫一点，
      每 0.8 秒最多花 SWEEP_BUDGET_MS 毫秒，扫到哪记在哪，下次接着扫。 */
function _sweepPass(py, ctx){
  let list;
  try { list = Array.from(chunks.values()); } catch(e){ return 0; }
  const n = list.length;
  if (!n) return 0;
  if (_sweepChunk >= n){ _sweepChunk = 0; _sweepCol = 0; }

  let changes = 0;
  const deadline = performance.now() + SWEEP_BUDGET_MS;
  let guard = 0;                         /* 防止 performance.now 精度太粗时死循环 */
  while (guard++ < 600 && performance.now() < deadline){
    const c = list[_sweepChunk % n];
    if (!c || !c.blocks || !c.blocks.length){
      _sweepChunk = (_sweepChunk + 1) % n;
      _sweepCol = 0;
      continue;
    }
    const bx = c.cx * CS, bz = c.cz * CS;
    changes += _groundColumn(bx + (_sweepCol & 15), bz + (_sweepCol >> 4), py, 80, ctx);

    _sweepCol++;
    if (_sweepCol >= CS * CS){
      _sweepCol = 0;
      _sweepChunk = (_sweepChunk + 1) % n;
    }
  }
  return changes;
}

/**
 * ★ 把一个区块的地表天气效果【一次性】铺好。
 * 区块刚加载时调用 —— 不参与"慢慢堆"。
 * 成本：256 列判断（绝大多数是空转），远小于区块本身的地形生成。
 */
export function applyWeatherGroundToChunk(chunk){
  if (!_initialized || !_tempFn) return 0;
  if (!chunk || !chunk.blocks || !chunk.ready) return 0;

  const snowId  = B.snow_layer ? B.snow_layer.id : 0;
  const iceId   = B.ice ? B.ice.id : 0;
  const waterId = B.water ? B.water.id : 0;
  if (!snowId && !iceId) return 0;

  const T = TEMP_THRESHOLDS;
  const isSnowing = (_state === WEATHER.RAIN || _state === WEATHER.STORM)
                 && _intensity > 0.2;

  /* ★ 区块刚生成、还没网格化：直接写数组，不走 setBlockWorld。
     积雪/结冰都只发生在"空气↔雪层""水↔冰"之间，两者挡光属性相同，
     所以光照完全不用重算；省掉 256 次 setBlockWorld 的固定开销。 */
  const put = (wx, wy, wz, id) => {
    if (wy < Y_MIN || wy >= CHH) return;
    if ((wx >> 4) !== chunk.cx || (wz >> 4) !== chunk.cz){   /* 保险：跨区块就退回正常接口 */
      setBlockWorld(wx, wy, wz, id, { noRecord: true });
      return;
    }
    const li = (((wy - Y_MIN) * CS) + (wz & 15)) * CS + (wx & 15);
    if (chunk.blocks[li] === id) return;
    chunk.blocks[li] = id;
    if (wy + 1 > chunk.maxY) chunk.maxY = Math.min(CHH - 1, wy + 1);
    chunk.dirty = true;
  };

  const ctx = { snowId, iceId, waterId, isSnowing, T, tempFn: _tempFn, put };
  /* 没有玩家位置：用这个区块自己的地表高度当参考，不做"离玩家太远就跳过"的限制 */
  const refY = (chunk.maxY != null && chunk.maxY > 0) ? chunk.maxY : SEA_LEVEL;

  const bx = chunk.cx * CS, bz = chunk.cz * CS;
  let n = 0;
  for (let lz = 0; lz < CS; lz++){
    for (let lx = 0; lx < CS; lx++){
      n += _groundColumn(bx + lx, bz + lz, refY, null, ctx);
    }
  }
  return n;
}

/* 区块一 ready 就铺好（terrain 通过回调调过来，避免循环 import） */
setOnChunkReady(applyWeatherGroundToChunk);

export function tickWeatherGround(dt, playerPos){
  if (!_initialized || !_tempFn) return;
  _groundTimer += dt;
  if (_groundTimer < GROUND_INTERVAL) return;
  _groundTimer = 0;

  const snowId  = B.snow_layer ? B.snow_layer.id : 0;
  const iceId   = B.ice ? B.ice.id : 0;
  const waterId = B.water ? B.water.id : 0;
  if (!snowId && !iceId) return;

  const T = TEMP_THRESHOLDS;
  const isSnowing = (_state === WEATHER.RAIN || _state === WEATHER.STORM)
                 && _intensity > 0.2;

  const ctx = {
    snowId, iceId, waterId, isSnowing, T, tempFn: _tempFn,
    put: (wx, wy, wz, id) => setBlockWorld(wx, wy, wz, id, { noRecord: true }),
  };
  const px = Math.floor(playerPos.x);
  const py = Math.floor(playerPos.y);
  const pz = Math.floor(playerPos.z);

  _nearPass(px, py, pz, ctx);
  _sweepPass(py, ctx);
}

/* ============================================================
   粒子渲染：雨 / 雪
   ============================================================ */
const MAX_RAIN = 400;
const MAX_SNOW = 300;
const PRADIUS = 16;
const PHEIGHT = 20;

let _rainPool = [];
let _snowPool = [];
let _particleInited = false;
let _rainPtr = 0, _snowPtr = 0;
let _rainAccum = 0, _snowAccum = 0;

function _makeRainTex(){
  const c = document.createElement('canvas');
  c.width = 2; c.height = 6;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(170, 210, 255, 0.85)';
  g.fillRect(0, 0, 2, 6);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  return t;
}

function _makeSnowTex(){
  const S = 4;
  const c = document.createElement('canvas');
  c.width = S; c.height = S;
  const g = c.getContext('2d');
  const pat = ['.##.', '####', '####', '.##.'];
  g.fillStyle = 'rgba(240, 248, 255, 1)';
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++)
      if (pat[y][x] === '#') g.fillRect(x, y, 1, 1);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  return t;
}

function _ensureParticles(){
  if (_particleInited) return;
  _particleInited = true;
  const rainTex = _makeRainTex();
  const snowTex = _makeSnowTex();
  for (let i = 0; i < MAX_RAIN; i++){
    const mat = new THREE.SpriteMaterial({
      map: rainTex, transparent: true, depthWrite: false, fog: true, opacity: 0,
    });
    const sp = new THREE.Sprite(mat);
    sp.visible = false;
    sp.scale.set(0.06, 0.35, 1);
    scene.add(sp);
    _rainPool.push({ sp, active: false, x: 0, y: 0, z: 0 });
  }
  for (let i = 0; i < MAX_SNOW; i++){
    const mat = new THREE.SpriteMaterial({
      map: snowTex, transparent: true, depthWrite: false, fog: true, opacity: 0,
    });
    const sp = new THREE.Sprite(mat);
    sp.visible = false;
    sp.scale.set(0.12, 0.12, 1);
    scene.add(sp);
    _snowPool.push({ sp, active: false, x: 0, y: 0, z: 0, phase: 0 });
  }
}

function _spawnRain(cx, cy, cz, strength){
  const n = _rainPool.length;
  for (let i = 0; i < n; i++){
    const p = _rainPool[_rainPtr];
    _rainPtr = (_rainPtr + 1) % n;
    if (p.active) continue;
    const ang = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * PRADIUS;
    p.x = cx + Math.cos(ang) * r;
    p.z = cz + Math.sin(ang) * r;
    p.y = cy + PHEIGHT + Math.random() * 4;
    /* 生成点必须见得到天：封闭洞穴里不会凭空下雨 */
    if (getSkyLightAt(p.x, p.y, p.z) < 12) continue;
    p.sp.position.set(p.x, p.y, p.z);
    p.sp.material.opacity = 0.55 + strength * 0.35;
    p.sp.visible = true;
    p.active = true;
    return;
  }
}

function _spawnSnow(cx, cy, cz, strength){
  const n = _snowPool.length;
  for (let i = 0; i < n; i++){
    const p = _snowPool[_snowPtr];
    _snowPtr = (_snowPtr + 1) % n;
    if (p.active) continue;
    const ang = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * PRADIUS;
    p.x = cx + Math.cos(ang) * r;
    p.z = cz + Math.sin(ang) * r;
    p.y = cy + PHEIGHT + Math.random() * 4;
    if (getSkyLightAt(p.x, p.y, p.z) < 12) continue;
    p.phase = Math.random() * 6.28;
    p.sp.position.set(p.x, p.y, p.z);
    p.sp.material.opacity = 0.7 + strength * 0.25;
    p.sp.visible = true;
    p.active = true;
    return;
  }
}

/** 雨雪是否被方块挡住（固体或液体表面都算落地） */
function _blocksPrecip(x, y, z){
  const def = BLOCKS[getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z))];
  if (!def) return false;
  return !!(def.solid || def.liquid);
}

/**
 * 每帧更新粒子。
 * @param dt
 * @param playerPos
 * @param snowFactor 0=全雨，1=全雪（由 main.js 按玩家位置温度计算）
 */
export function updateWeatherRender(dt, playerPos, snowFactor){
  _ensureParticles();

  const cx = playerPos.x, cy = playerPos.y, cz = playerPos.z;

  if (!isPrecipitating()){
    for (const p of _rainPool){
      if (!p.active) continue;
      p.sp.material.opacity *= 0.88;
      if (p.sp.material.opacity < 0.02){ p.active = false; p.sp.visible = false; }
    }
    for (const p of _snowPool){
      if (!p.active) continue;
      p.sp.material.opacity *= 0.88;
      if (p.sp.material.opacity < 0.02){ p.active = false; p.sp.visible = false; }
    }
    return;
  }

  const sf = Math.max(0, Math.min(1, snowFactor || 0));
  const rainStrength = _intensity * (1 - sf);
  const snowStrength = _intensity * sf;

  _rainAccum += (140 * rainStrength) * dt;
  const rc = Math.floor(_rainAccum);
  _rainAccum -= rc;
  for (let i = 0; i < rc; i++) _spawnRain(cx, cy, cz, rainStrength);

  _snowAccum += (90 * snowStrength) * dt;
  const sc = Math.floor(_snowAccum);
  _snowAccum -= sc;
  for (let i = 0; i < sc; i++) _spawnSnow(cx, cy, cz, snowStrength);

  const RAIN_SPEED = 24;
  const SNOW_SPEED = 1.5;
  const bottom = cy - PHEIGHT;

  for (const p of _rainPool){
    if (!p.active) continue;
    const prevY = p.y;
    p.y -= RAIN_SPEED * dt;
    /* 撞到方块/水面就消失：雨不再穿过屋顶和地面 */
    if (p.y < bottom ||
        _blocksPrecip(p.x, p.y, p.z) ||
        _blocksPrecip(p.x, (prevY + p.y) * 0.5, p.z)){
      p.active = false; p.sp.visible = false; continue;
    }
    p.sp.position.set(p.x, p.y, p.z);
  }

  for (const p of _snowPool){
    if (!p.active) continue;
    const prevY = p.y;
    p.phase += dt * 2;
    p.y -= SNOW_SPEED * dt;
    p.x += Math.sin(p.phase) * 0.4 * dt;
    p.z += Math.cos(p.phase * 0.7) * 0.4 * dt;
    if (p.y < bottom ||
        _blocksPrecip(p.x, p.y, p.z) ||
        _blocksPrecip(p.x, (prevY + p.y) * 0.5, p.z)){
      p.active = false; p.sp.visible = false; continue;
    }
    p.sp.position.set(p.x, p.y, p.z);
  }
}

/**
 * 玩家周围雨雪混合系数：0=雨，1=雪
 * 温度越低越偏雪；SNOW 阈值上下 0.05 之间线性过渡
 */
export function getSnowFactor(playerTemp){
  const T = TEMP_THRESHOLDS;
  if (playerTemp <= T.SNOW - 0.05) return 1;
  if (playerTemp >= T.SNOW + 0.05) return 0;
  return (T.SNOW + 0.05 - playerTemp) / 0.10;
}
