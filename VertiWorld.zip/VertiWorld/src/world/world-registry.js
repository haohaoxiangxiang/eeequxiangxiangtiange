/* ============================================================
   world-registry.js —— 方块 / 维度 / 创造分类 / 树叶 注册表
   ------------------------------------------------------------
★ 合并自 4 个 5~6KB 的注册表类文件（合起来约 22KB）：
     blocks-registry.js     方块注册器（buildBlk / 运行时注册 / 冻结）
     dimension-registry.js  维度注册（每个维度一套存档目录）
     creative-categories.js 创造面板分类（含 mod 自注册）
     leaves.js              树叶衰减与落叶粒子
   blocks.js（23KB，纯方块数据表）与 biome-registry.js（11KB）保持独立。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from '../vendor/three.module.js';
import {
  getActiveDimension as _getActive,
  setActiveDimensionGlobal as _setActiveGlobal,
  isValidDimensionId,
} from './../core/engine-core.js';
import { BLOCKS } from './blocks.js';
import { TEX } from './textures.js';
import { getBlockWorld } from './terrain.js';
import { scene } from './../render/render-core.js';


/* =================================================================
   blocks-registry.js
   ================================================================= */
/* ============================================================
   blocks-registry.js —— 方块注册表
   ============================================================ */

let _frozen = false;
const _byId = [];
const _byName = new Map();

let _runtimeMode = false;
const _registerListeners = [];

function enableRuntimeRegistration(){
  _runtimeMode = true;
  console.log('[blocks] 运行时注册已开启');
}

function isRuntimeMode(){ return _runtimeMode; }

function onBlockRegistered(fn){
  if (typeof fn === 'function') _registerListeners.push(fn);
}
function offBlockRegistered(fn){
  const i = _registerListeners.indexOf(fn);
  if (i >= 0) _registerListeners.splice(i, 1);
}

function buildBlk(name, label, opts) {
  const id = _byId.length;

  let tiles;
  if (opts.noTex) {
    tiles = [0, 0, 0, 0, 0, 0];
  } else {
    const t = opts.tex || {};
    const sideTex = t.side !== undefined ? t.side : t.all;
    const topTex  = t.top  !== undefined ? t.top  : (t.all !== undefined ? t.all : t.side);
    const botTex  = t.bottom !== undefined ? t.bottom : (t.all !== undefined ? t.all : t.side);
    const s  = TEX[sideTex];
    const tp = TEX[topTex];
    const bt = TEX[botTex];
    if (s === undefined || tp === undefined || bt === undefined) {
      console.warn(`[blocks] "${name}" 贴图名未注册（side=${sideTex} top=${topTex} bottom=${botTex}）`);
    }
    tiles = [s | 0, s | 0, tp | 0, bt | 0, s | 0, s | 0];

    /* ★ 正面贴图：tex.front + frontDir（0=北 -Z, 1=东 +X, 2=南 +Z, 3=西 -X）。
       面序号顺序是 [+X, -X, +Y, -Y, +Z, -Z]，用来做熔炉这类有正面的方块。 */
    if (t.front !== undefined){
      const fi = TEX[t.front];
      if (fi === undefined){
        console.warn(`[blocks] "${name}" 正面贴图未注册（front=${t.front}）`);
      } else {
        const fd = (((opts.frontDir | 0) % 4) + 4) % 4;
        tiles[[5, 0, 4, 1][fd]] = fi | 0;
      }
    }
  }

  /* ★ 方块模型：用 0~16 的整数坐标盒子列表描述非整方块形状，
     和 MC 的 block model 一样吃图集 UV、方块光照与 AO。
     box.tex 写法与方块 tex 相同（all / side / top / bottom），alpha 的盒子进透明批次。 */
  let model = null;
  if (opts.model && Array.isArray(opts.model.boxes)){
    const clamp16 = v => Math.max(0, Math.min(16, Number(v) || 0));
    model = {
      boxes: opts.model.boxes.map(b => {
        const t = b.tex || {};
        const all = t.all;
        const sideN = t.side !== undefined ? t.side : all;
        const topN  = t.top  !== undefined ? t.top  : (all !== undefined ? all : sideN);
        const botN  = t.bottom !== undefined ? t.bottom : (all !== undefined ? all : sideN);
        const s = TEX[sideN], tp = TEX[topN], bt = TEX[botN];
        if (s === undefined || tp === undefined || bt === undefined){
          console.warn(`[blocks] "${name}" 模型贴图名未注册（side=${sideN} top=${topN} bottom=${botN}）`);
        }
        return {
          x0: clamp16(b.x0), y0: clamp16(b.y0), z0: clamp16(b.z0),
          x1: clamp16(b.x1), y1: clamp16(b.y1), z1: clamp16(b.z1),
          tiles: [s | 0, s | 0, tp | 0, bt | 0, s | 0, s | 0],
          alpha: !!b.alpha,
          /* ★ 动态模型的分组标记（箱子盖等） */
          part: b.part === 'lid' ? 'lid' : 'body',
        };
      }).filter(b => b.x1 > b.x0 && b.y1 > b.y0 && b.z1 > b.z0),
    };
  }

  return {
    id, name, label,
    tiles,
    model,

    opaque:   opts.opaque   !== false,
    occludes: opts.occludes !== undefined ? !!opts.occludes : (opts.opaque !== false),
    mergeSame: opts.mergeSame !== undefined ? !!opts.mergeSame : true,

    solid:       opts.solid !== false,
    transparent: !!opts.transparent,
    liquid:      !!opts.liquid,
    heightRatio: opts.heightRatio !== undefined ? opts.heightRatio : 1,
    flatRender:  !!opts.flatRender,
    isLeaves:    !!opts.isLeaves,
    leafColors:  opts.leafColors || null,

    hardness:     opts.hardness !== undefined ? opts.hardness : 1,
    requiresTool: !!opts.requiresTool,
    tool:         opts.tool || null,
    minTier:      opts.minTier || 0,

    emissive: opts.emissive || 0,
    light: opts.light | 0,
    lightFilter: opts.lightFilter | 0,

    tag:    opts.tag    || null,
    isItem: !!opts.isItem,
    density:     opts.density !== undefined ? opts.density : 1.2,
    friction:    opts.friction !== undefined ? opts.friction : 0.6,
    restitution: opts.restitution !== undefined ? opts.restitution : 0.0,

    toolType: opts.toolType || null,
    material: opts.material || null,
    speed:    opts.speed || 1,
    tier:     opts.tier  || 0,
    durability: opts.durability || 0,
    maxStack: opts.maxStack !== undefined ? opts.maxStack : 64,

    /* ★ 盔甲：armorSlot = head/chest/legs/feet，defense 每点减伤 4% */
    armorSlot: opts.armorSlot || null,
    defense:   opts.defense || 0,

    cross:    !!opts.cross,
    slab:     !!opts.slab,
    stair:    !!opts.stair,

    /* ★ 不渲染（但方块本身、碰撞、数据、交互全部保留）
       用于"3D 模型方块"——用 attachVisual 画模型，方块本体不画 */
    invisible: !!opts.invisible,
    /* ★ 动态模型：不烘焙进区块网格，由渲染层实时绘制（箱子盖动画等） */
    dynamic: !!opts.dynamic,
    stairDir: opts.stairDir !== undefined ? opts.stairDir : -1,
    stairBase: opts.stairBase || null,

    /* ★ 朝向方块（熔炉这类有正面的方块）：
       orientBase 指向掉落 / 放置时使用的基准方块名，
       orientDir  是这个变体正面朝向（同 frontDir 约定）。 */
    orientDir:  opts.orientDir  !== undefined ? (opts.orientDir | 0) : -1,
    orientBase: opts.orientBase || null,
    frontDir:   opts.frontDir   !== undefined ? (opts.frontDir | 0) : -1,

    interactive: opts.interactive || null,

    /* ★ 动力元件（魔法按钮/压力板 + 木质按钮/压力板）
       powerOn  通电时输出给魔法粉尘的强度（0 = 不通电）
       buttonOff/buttonOn  按钮的两种状态方块名
       plateOff/plateOn    压力板的两种状态方块名 */
    powerOn:   opts.powerOn || 0,
    buttonOff: opts.buttonOff || null,
    buttonOn:  opts.buttonOn  || null,
    plateOff:  opts.plateOff  || null,
    plateOn:   opts.plateOn   || null,

    food:       opts.food || 0,
    saturation: opts.saturation || 0,
    fuel:       opts.fuel || 0,
    placeable:  opts.placeable !== false,

    bucketType:   opts.bucketType || null,
    waterPlant:   !!opts.waterPlant,
    waterSurface: !!opts.waterSurface,

    // ★ 新增：群系染色
    tint: opts.tint || null,

    /* ★ 物品图标（背包/快捷栏/掉落物用）
       不填就取"顶面"贴图（tiles[2]）。
       模型方块（面透明、里面挂 3D 模型）必须填这个，否则图标是空的。 */
    icon: (opts.icon && TEX[opts.icon] !== undefined) ? (TEX[opts.icon] | 0) : null,

    /* ★ 创造面板分类：mod 可以用 category:'xxx' 指定自己的分类
       （xxx 由 registerCreativeCategory 注册）；不填就自动归类。
       hidden:true 则不出现在创造面板里 */
    category: opts.category || null,
    hidden: !!opts.hidden,

    source: opts.source || (_frozen ? 'mod' : 'builtin'),
  };
}

function registerBlock(name, label, opts) {
  if (_frozen && !_runtimeMode) {
    console.warn(`[blocks] 注册已冻结，拒绝 "${name}"`);
    return null;
  }
  if (typeof name !== 'string' || !name) {
    console.warn('[blocks] 非法方块名', name);
    return null;
  }
  if (_byName.has(name)) {
    console.warn(`[blocks] 方块名 "${name}" 重复注册，忽略`);
    return _byName.get(name);
  }

  const blk = buildBlk(name, label, opts || {});
  _byId.push(blk);
  _byName.set(name, blk);

  if (_frozen && _runtimeMode){
    for (let i = 0; i < _registerListeners.length; i++){
      try { _registerListeners[i](blk); }
      catch(e){ console.error('[blocks] 注册回调出错', e); }
    }
  }
  return blk;
}

function freezeBlocks() {
  _frozen = true;
  return { byName: _byName, byId: _byId };
}

function getBlockByName(name) { return _byName.get(name) || null; }
function getBlockById(id) { return _byId[id] || null; }
function getAllBlocks() { return _byId; }
function isBlocksFrozen() { return _frozen; }
function getBlockCount(){ return _byId.length; }

/* =================================================================
   dimension-registry.js
   ================================================================= */
/* ============================================================
   dimension-registry.js —— 维度注册表
   ------------------------------------------------------------
   每个维度 = 一个独立的世界：
     · 独立的生成器（generator id）
     · 独立的 chunk 命名空间（terrain.js 用）
     · 独立的存档目录（saves/<sid>/chunks/ 或 saves/<sid>/dims/<id>/chunks/）
     · 独立的玩家位置（player.posByDim）

   overworld 永远存在，内置。

   mod 用 G.registerDimension(id, cfg) 追加。

   cfg 字段（全部可选）：
     name           显示名
     generator      生成器 id（默认同 id，或 'vanilla'）
     skyPreset      天空预设（传给 sky.js 的 setSkyPreset）
     biomeFog       群系雾（传给 sky.js 的 setBiomeFog）
     gravity        重力倍率（1.0 = 主世界）
     timeScale      时间流速倍率（0 = 冻结）
     fixedTime      固定时间 0~1（null = 正常昼夜）
     seaLevel       海平面 y（默认同全局 SEA_LEVEL）
     yMin           底部 y（默认同全局 Y_MIN）
     chunkH         顶部 y（默认同全局 CHH）
     portal         传送门配置（预留）
   ============================================================ */


const _dims = new Map();

/* ============================================================
   ★ 内置主世界
   ============================================================ */
_dims.set('overworld', {
  id: 'overworld',
  name: '主世界',
  generator: null,       // null = 跟随当前存档的 worldType
  skyPreset: null,
  biomeFog: null,
  gravity: 1.0,
  timeScale: 1.0,
  fixedTime: null,
  seaLevel: null,        // null = 用全局
  yMin: null,
  chunkH: null,
  portal: null,
  builtin: true,
});

/* ============================================================
   注册
   ============================================================ */
function registerDimension(id, cfg){
  if (!isValidDimensionId(id)){
    console.warn('[dim] 非法 id:', id);
    return null;
  }
  if (id === 'overworld'){
    console.warn('[dim] overworld 是内置维度，不能覆盖');
    return _dims.get('overworld');
  }
  if (_dims.has(id)){
    console.warn(`[dim] "${id}" 已存在，忽略`);
    return _dims.get(id);
  }

  cfg = cfg || {};
  const dim = {
    id,
    name:      cfg.name      || id,
    generator: cfg.generator || 'vanilla',
    skyPreset: cfg.skyPreset || null,
    biomeFog:  cfg.biomeFog  || null,
    gravity:   cfg.gravity   !== undefined ? cfg.gravity   : 1.0,
    timeScale: cfg.timeScale !== undefined ? cfg.timeScale : 1.0,
    fixedTime: cfg.fixedTime !== undefined ? cfg.fixedTime : null,
    seaLevel:  cfg.seaLevel  !== undefined ? cfg.seaLevel  : null,
    yMin:      cfg.yMin      !== undefined ? cfg.yMin      : null,
    chunkH:    cfg.chunkH    !== undefined ? cfg.chunkH    : null,
    portal:    cfg.portal    || null,
    builtin:   false,
  };

  _dims.set(id, dim);
  console.log(`[dim] 注册维度: ${id} (${dim.name}) · generator=${dim.generator}`);
  return dim;
}

/* ============================================================
   查询
   ============================================================ */
function getDimension(id){
  return _dims.get(id) || null;
}

function hasDimension(id){
  return _dims.has(id);
}

function listDimensions(){
  return Array.from(_dims.values()).map(d => ({
    id: d.id,
    name: d.name,
    generator: d.generator,
    builtin: !!d.builtin,
  }));
}

function getDimensionCount(){
  return _dims.size;
}

/* ============================================================
   切换
   ------------------------------------------------------------
   只改全局态。真正的"世界卸载 / 加载"由 main.js 的
   switchDimension 流程负责（它会调 terrain / player / sky）。
   ============================================================ */
function getActiveDimensionId(){
  return _getActive();
}

function getActiveDimension(){
  return _dims.get(_getActive()) || _dims.get('overworld');
}

/**
 * 只改全局 activeDimension 标记。
 * **不要直接调用**——请用 main.js 暴露的 G.switchDimension(id)。
 * 直接用会导致 chunk / player / sky 状态不同步。
 */
function setActiveDimensionId(id){
  if (!_dims.has(id)){
    console.warn(`[dim] setActive: 不存在 "${id}"`);
    return false;
  }
  return _setActiveGlobal(id);
}

/* ============================================================
   校验 / 工具
   ============================================================ */
function isValidId(id){
  return isValidDimensionId(id);
}

/** 哪些维度 id 会落在子目录里（overworld 用根 chunks/） */
function isSubdirDimension(id){
  return id !== 'overworld';
}

/**
 * 拿某个维度的存档目录相对路径。
 *   overworld → 'chunks'
 *   其它      → 'dims/<id>/chunks'
 */
function getDimensionChunkDir(id){
  return isSubdirDimension(id) ? `dims/${id}/chunks` : 'chunks';
}

/** 拿某个维度的 log 目录相对路径（未来加） */
function getDimensionLogDir(id){
  return isSubdirDimension(id) ? `dims/${id}/logs` : 'logs';
}

/* =================================================================
   creative-categories.js
   ================================================================= */
/* ============================================================
   creative-categories.js —— 创造物品分类注册表
   ------------------------------------------------------------
   目的：
     · 创造面板不再是一条几百格的超长列表，而是按分类分页
     · 原版方块自动归类；mod 方块可以用 block 选项里的
       category: 'xxx' 指定，也可以自己注册一个新分类
     · mod 注册新分类后，创造面板会多出一个 tab，
       mod 的物品就落在自己的 tab 里（给 mod 留位置）
   ------------------------------------------------------------
   mod 用法：
       G.registerCreativeCategory({
         id: 'raft_machines',      // 唯一 id（不要和内置的重复）
         label: '轮机',            // tab 上显示的字
         icon: 'oak_planks',       // 可选：用哪个方块当图标
         order: 70,                // 可选：排序，越小越靠前
       });
       G.registerBlock('steam_pipe', '蒸汽管', { ..., category: 'raft_machines' });
   ============================================================ */


/* 内置分类（order 越小越靠前） */
const BUILTIN = [
  { id: 'building',   label: '建筑',  order: 10, icon: 'stone' },
  { id: 'nature',     label: '自然',  order: 20, icon: 'oak_leaves' },
  { id: 'material',   label: '材料',  order: 30, icon: 'iron_ingot' },
  { id: 'functional', label: '功能',  order: 40, icon: 'crafting_table' },
  { id: 'tools',      label: '工具',  order: 50, icon: 'iron_pickaxe' },
  { id: 'food',       label: '食物',  order: 60, icon: 'cooked_beef' },
  { id: 'misc',       label: '其他',  order: 900, icon: 'unknown_block' },
];

const cats = new Map();          /* id -> { id, label, icon, order, builtin, source } */
const listeners = [];

for (const c of BUILTIN){
  cats.set(c.id, { ...c, builtin: true, source: 'core' });
}

function _notify(){
  for (const fn of listeners){
    try { fn(); } catch(e){ console.error('[creative] 分类变更回调出错:', e); }
  }
}

/** 订阅分类变化（mod 后注册分类时刷新 UI 用） */
function onCreativeCategoryChange(fn){
  if (typeof fn === 'function') listeners.push(fn);
  return () => {
    const i = listeners.indexOf(fn);
    if (i >= 0) listeners.splice(i, 1);
  };
}

/**
 * 注册一个创造分类。
 * @param {{id:string,label:string,icon?:string,order?:number,source?:string}} def
 */
function registerCreativeCategory(def){
  if (!def || typeof def.id !== 'string' || !def.id){
    console.warn('[creative] registerCreativeCategory 需要 id');
    return null;
  }
  if (cats.has(def.id)){
    const old = cats.get(def.id);
    if (old.builtin){
      console.warn(`[creative] 分类 "${def.id}" 是内置分类，拒绝覆盖`);
      return old;
    }
    /* 允许 mod 覆盖自己注册过的同 id 分类 */
    const merged = { ...old, ...def, builtin: false };
    cats.set(def.id, merged);
    _notify();
    return merged;
  }
  const rec = {
    id: def.id,
    label: def.label || def.id,
    icon: def.icon || null,
    order: Number.isFinite(def.order) ? def.order : 500,
    builtin: false,
    source: def.source || 'mod',
  };
  cats.set(rec.id, rec);
  _notify();
  return rec;
}

function hasCreativeCategory(id){ return cats.has(id); }

function getCreativeCategory(id){ return cats.get(id) || null; }

/** 按 order 排序返回所有分类 */
function listCreativeCategories(){
  return Array.from(cats.values())
    .sort((a, b) => (a.order - b.order) || a.id.localeCompare(b.id));
}

/* ============================================================
   方块归类
   ============================================================ */
const RE_NATURE = /(log|leaves|sapling|flower|dandelion|poppy|cornflower|tulip|allium|daisy|grass|fern|kelp|seagrass|lily_pad|vine|bamboo|sugar_cane|dead_bush|cactus|mushroom|petals|moss_carpet|roots?)/;
const RE_BUILDING = /(planks|_slab|_stair|brick|glass|wool|prismarine|terracotta|ice|snow|stone|cobble|sand|dirt|clay|gravel|deepslate|granite|diorite|andesite|basalt|limestone|marble|blackstone|loess|moss_block|mushroom_block|glowstone|lantern|obsidian|bedrock|concrete)/;
const RE_MATERIAL = /(^coal$|^charcoal$|_ore$|_ingot$|_gem$|^stick$|^bucket$|_bucket$)/;

/**
 * 一个方块属于哪个创造分类。
 * 优先用方块自己的 category（mod 指定），否则按 tag / name 猜一个。
 */
function classifyBlock(blk){
  if (!blk) return 'misc';
  if (blk.category && cats.has(blk.category)) return blk.category;

  if (blk.food > 0 || blk.tag === 'food') return 'food';
  if (blk.tag === 'tool' || blk.durability > 0 || blk.bucketType || blk.toolType) return 'tools';
  if (blk.interactive) return 'functional';

  const n = String(blk.name || '');

  if (RE_MATERIAL.test(n)) return 'material';

  /* 矿物类方块（煤/铁/金/钻矿） */
  if (/ore/.test(n)) return 'material';

  if (RE_NATURE.test(n)) return 'nature';
  if (blk.liquid) return 'building';
  if (RE_BUILDING.test(n)) return 'building';

  if (blk.tag === 'stone' || blk.tag === 'planks' || blk.tag === 'log') return 'building';
  if (blk.tag === 'wool') return 'building';
  if (blk.tag === 'coal' || blk.tag === 'iron_ingot' ||
      blk.tag === 'gold_ingot' || blk.tag === 'diamond_gem' || blk.tag === 'stick'){
    return 'material';
  }
  return 'misc';
}

/**
 * 把所有可放置方块按分类分好。
 * @returns {{ byCat: Map<string, number[]>, total: number }}
 */
const _CREATIVE_HIDDEN = new Set(['water', 'lava', 'unknown_block']);

function buildCreativeIndex(){
  const byCat = new Map();
  let total = 0;
  for (let id = 1; id < BLOCKS.length; id++){
    const blk = BLOCKS[id];
    if (!blk) continue;
    if (blk.placeable === false) continue;
    if (blk.hidden) continue;
    if (_CREATIVE_HIDDEN.has(blk.name)) continue;
    const cat = classifyBlock(blk);
    if (!byCat.has(cat)) byCat.set(cat, []);
    byCat.get(cat).push(id);
    total++;
  }
  return { byCat, total };
}

/* =================================================================
   leaves.js
   ================================================================= */
/* ============================================================
   leaves.js —— 落叶飘落效果
   ------------------------------------------------------------
   · 用 THREE.Sprite 显示 5x7 像素风叶子
   · 玩家附近随机生成
   · ★ 已回退到 Three.js 版本
   ============================================================ */





const leaves = [];
let enabled = true;

function setFallingLeavesEnabled(v){ enabled = v; }
function isFallingLeavesEnabled(){ return enabled; }
function getLeafCount(){ return leaves.length; }

/* ============================================================
   叶子纹理（5×7 像素风 · 斜向）
   ============================================================ */
const leafTexCache = {};

function getLeafCanvasTexture(colors){
  const key = colors.join(',');
  if (leafTexCache[key]) return leafTexCache[key];

  const SHAPE = [
    '00001',
    '00011',
    '00121',
    '01121',
    '11211',
    '12110',
    '21100',
  ];
  const W = 5;
  const H = SHAPE.length;

  const c = document.createElement('canvas');
  c.width  = W;
  c.height = H;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, W, H);

  const c1 = (colors && colors[1] !== undefined) ? colors[1] : 0x78b848;
  const c2 = (colors && colors[2] !== undefined) ? colors[2] : 0x4c8c28;

  const hex = v => '#' + (v >>> 0).toString(16).padStart(6, '0');

  for (let y = 0; y < H; y++){
    const row = SHAPE[y];
    for (let x = 0; x < W; x++){
      const ch = row[x];
      if (ch === '0') continue;
      if (ch === '1')      ctx.fillStyle = hex(c1);
      else if (ch === '2') ctx.fillStyle = hex(c2);
      else continue;
      ctx.fillRect(x, y, 1, 1);
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;

  leafTexCache[key] = tex;
  return tex;
}

function createLeafSprite(colors){
  const mat = new THREE.SpriteMaterial({
    map: getLeafCanvasTexture(colors),
    transparent: true,
    depthWrite: false,
    opacity: 0.95,
  });
  const sp = new THREE.Sprite(mat);
  sp.scale.set(0.22, 0.31, 1);   // 5:7 比例
  return sp;
}

/* ============================================================
   生成单颗落叶
   ============================================================ */
function spawnLeaf(x, y, z, leafBlock){
  if (!enabled) return;
  const colors = leafBlock.leafColors || [0x58a63a, 0x6ec24a, 0x3e7a28];
  const d = {
    pos: new THREE.Vector3(x, y, z),
    vel: new THREE.Vector3(
      (Math.random() - 0.5) * 0.4,
      -0.4 - Math.random() * 0.4,
      (Math.random() - 0.5) * 0.4
    ),
    age: 0,
    life: 6 + Math.random() * 4,
    fadeAt: 0.7,
    rot: Math.random() * Math.PI * 2,
    rotSpeed: (Math.random() - 0.5) * 1.5,
    mesh: createLeafSprite(colors),
  };
  d.mesh.position.copy(d.pos);
  d.mesh.material.rotation = d.rot;
  scene.add(d.mesh);
  leaves.push(d);
}

/* ============================================================
   玩家附近随机尝试生成落叶
   ============================================================ */
let spawnTimer = 0;
const SPAWN_INTERVAL = 0.18;
const SPAWN_ATTEMPTS = 40;
const SPAWN_RADIUS = 14;

function trySpawnLeaves(dt, playerPos){
  if (!enabled) return;
  spawnTimer += dt;
  if (spawnTimer < SPAWN_INTERVAL) return;
  spawnTimer = 0;

  for (let i = 0; i < SPAWN_ATTEMPTS; i++){
    const ang = Math.random() * Math.PI * 2;
    const r = Math.random() * SPAWN_RADIUS;
    const dx = Math.cos(ang) * r;
    const dz = Math.sin(ang) * r;
    const x = Math.floor(playerPos.x + dx);
    const z = Math.floor(playerPos.z + dz);

    for (let dy = 5; dy >= -1; dy--){
      const y = Math.floor(playerPos.y + dy);
      const id = getBlockWorld(x, y, z);
      if (id === 0) continue;
      const blk = BLOCKS[id];
      if (blk && blk.isLeaves){
        if (hash2i2(x, y, z) < 0.6){
          spawnLeaf(
            x + 0.5 + (Math.random() - 0.5) * 0.6,
            y + Math.random() * 0.4,
            z + 0.5 + (Math.random() - 0.5) * 0.6,
            blk
          );
        }
        break;
      }
      if (dy < -1) break;
    }
  }
}

function hash2i2(x, y, z){
  let h = Math.imul(x|0, 374761393)
        ^ Math.imul(y|0, 668265263)
        ^ Math.imul(z|0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/* ============================================================
   每帧更新
   ============================================================ */
function updateLeaves(dt){
  for (let i = leaves.length - 1; i >= 0; i--){
    const d = leaves[i];
    d.age += dt;
    if (d.age > d.life){
      scene.remove(d.mesh);
      if (d.mesh.material) d.mesh.material.dispose();
      leaves.splice(i, 1);
      continue;
    }

    // 水平漂移
    d.vel.x += (Math.random() - 0.5) * 0.6 * dt;
    d.vel.z += (Math.random() - 0.5) * 0.6 * dt;
    d.vel.x *= 0.96;
    d.vel.z *= 0.96;

    d.pos.x += d.vel.x * dt;
    d.pos.y += d.vel.y * dt;
    d.pos.z += d.vel.z * dt;

    // 落地
    const below = getBlockWorld(
      Math.floor(d.pos.x),
      Math.floor(d.pos.y - 0.05),
      Math.floor(d.pos.z)
    );
    if (below !== 0){
      d.vel.y = 0;
      d.vel.x *= 0.9;
      d.vel.z *= 0.9;
    }

    // 淡出
    const t = d.age / d.life;
    d.mesh.material.opacity = t < d.fadeAt
      ? 0.95
      : 0.95 * (1 - (t - d.fadeAt) / (1 - d.fadeAt));

    d.rot += d.rotSpeed * dt;
    d.mesh.material.rotation = d.rot;
    d.mesh.position.copy(d.pos);
  }
}

/* ============================================================
   清理
   ============================================================ */
function clearLeaves(){
  for (const d of leaves){
    scene.remove(d.mesh);
    if (d.mesh.material) d.mesh.material.dispose();
  }
  leaves.length = 0;
}

/* =================================================================
   re-export
   ================================================================= */
export {
  enableRuntimeRegistration, isRuntimeMode, onBlockRegistered, offBlockRegistered, registerBlock, freezeBlocks, getBlockByName, getBlockById, getAllBlocks, isBlocksFrozen, getBlockCount, registerDimension, getDimension, hasDimension, listDimensions, getDimensionCount, getActiveDimensionId, getActiveDimension, setActiveDimensionId, isValidId, isSubdirDimension, getDimensionChunkDir, getDimensionLogDir, onCreativeCategoryChange, registerCreativeCategory, hasCreativeCategory, getCreativeCategory, listCreativeCategories, classifyBlock, buildCreativeIndex, setFallingLeavesEnabled, isFallingLeavesEnabled, getLeafCount, spawnLeaf, trySpawnLeaves, updateLeaves, clearLeaves
};
