/* ============================================================
   terrain-params.js —— 地形参数（样条 + 参数表 + 内置生成器元数据）
   ------------------------------------------------------------
★ 合并自 3 个小文件（合起来约 12KB，都在描述"地形长什么样"）：
     spline.js     三次 Hermite 样条（MC 式参数映射）
     params.js     各处噪声/高度参数表
     generators.js 内置世界类型的 UI 元数据（label/desc/hidden/options）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import { fbm, clamp } from '../../core/runtime.js';

/* =================================================================
   spline.js
   ================================================================= */
/* ============================================================
   spline.js —— 三次 Hermite 样条
   ------------------------------------------------------------
   MC 用它做参数映射：把 [0,1] 的噪声值映射到任意输出曲线。

   控制点格式：[x, y, derivative]
     x            输入（必须递增）
     y            输出
     derivative   该点的斜率（影响相邻段形状）

   用法：
     const s = new CubicSpline([
       [0.0, -50, 0],
       [0.4,   0, 1],
       [0.7,  20, 0.3],
       [1.0, 120, 0],
     ]);
     s.apply(0.55);   // → 平滑插值输出
   ============================================================ */

class CubicSpline {
  constructor(points){
    if (!points || points.length < 2){
      throw new Error('[spline] 至少需要 2 个控制点');
    }
    /* 深拷贝 + 排序 */
    this.points = points
      .map(p => [p[0], p[1], p[2] !== undefined ? p[2] : 0])
      .sort((a, b) => a[0] - b[0]);
  }

  apply(x){
    const pts = this.points;

    /* 边界外：线性外推 */
    if (x <= pts[0][0]) return pts[0][1];
    if (x >= pts[pts.length - 1][0]) return pts[pts.length - 1][1];

    /* 找区间 */
    let i = 0;
    for (let k = 1; k < pts.length; k++){
      if (x < pts[k][0]){ i = k - 1; break; }
    }

    const [x0, y0, d0] = pts[i];
    const [x1, y1, d1] = pts[i + 1];

    const dx = x1 - x0;
    const t  = (x - x0) / dx;

    /* Hermite 基函数 */
    const t2 = t * t;
    const t3 = t2 * t;
    const h00 =  2 * t3 - 3 * t2 + 1;
    const h10 =        t3 - 2 * t2 + t;
    const h01 = -2 * t3 + 3 * t2;
    const h11 =        t3 -     t2;

    return h00 * y0
         + h10 * dx * d0
         + h01 * y1
         + h11 * dx * d1;
  }
}

/* ============================================================
   便捷构造函数：只有 [x, y] 时自动算导数
   ------------------------------------------------------------
   切线估计：中心差分（Monotone cubic 的思路简化版）
   ============================================================ */
function spline2D(points){
  const p = points.map(pt => [pt[0], pt[1], 0]);
  p.sort((a, b) => a[0] - b[0]);

  for (let i = 0; i < p.length; i++){
    if (i === 0){
      const slope = (p[1][1] - p[0][1]) / (p[1][0] - p[0][0]);
      p[i][2] = slope;
    } else if (i === p.length - 1){
      const slope = (p[i][1] - p[i-1][1]) / (p[i][0] - p[i-1][0]);
      p[i][2] = slope;
    } else {
      const slope = (p[i+1][1] - p[i-1][1]) / (p[i+1][0] - p[i-1][0]);
      p[i][2] = slope;
    }
  }
  return new CubicSpline(p);
}

/* =================================================================
   params.js
   ================================================================= */
/* ============================================================
   params.js —— 世界核心参数系统
   ------------------------------------------------------------
   ★ 本轮改动（A3）：
     · humidity 增加可选 cont 参数
       调用方已算过 continentalness 时直接传入，省一次 4+2 octave fbm
       不传时内部自己算，保持向后兼容
   ============================================================ */



/* ============================================================
   样条定义
   ============================================================ */

/* continentalness:
   0.28 → 0.00  深海
   0.36 → 0.20  海洋
   0.42 → 0.50  海岸
   0.50 → 0.80  陆地
   0.60 → 1.00  深内陆 */
const SPLINE_CONT = [
  [0.28, 0.00],
  [0.36, 0.20],
  [0.42, 0.50],
  [0.50, 0.80],
  [0.60, 1.00],
];

/* erosion:
   0.28 → 0.00  极陡峭
   0.36 → 0.20  陡峭
   0.42 → 0.50  中等
   0.52 → 0.80  平坦
   0.62 → 1.00  极平坦 */
const SPLINE_ERO = [
  [0.28, 0.00],
  [0.36, 0.20],
  [0.42, 0.50],
  [0.52, 0.80],
  [0.62, 1.00],
];

/* temperature / humidity：线性拉伸 */
const SPLINE_TEMP = [[0.20, 0.05], [0.80, 0.95]];
const SPLINE_HUM  = [[0.28, 0.00], [0.72, 1.00]];

/* 季节 / 海拔 / 雪 参数 */
const SEASON_AMP = 0.10;    /* 季节温度偏移幅度 +/-0.10 */
const LAPSE_RATE = 0.0015;  /* 每升高一格温度下降量 */
const SNOW_TEMP  = 0.20;    /* 雪层生成阈值（温度低于此值才有积雪） */


/* ============================================================
   主入口
   ============================================================ */
function createParamSystem(cfg){
  const SEED = (cfg.seed | 0);
  const SEA_LEVEL = cfg.SEA_LEVEL;
  const Y_MIN = cfg.Y_MIN;
  const CHH = cfg.CHH;

  const splineCont = spline2D(SPLINE_CONT);
  const splineEro  = spline2D(SPLINE_ERO);
  const splineTemp = spline2D(SPLINE_TEMP);
  const splineHum  = spline2D(SPLINE_HUM);

  /* ------------------------------------------------------------
     continentalness
     ------------------------------------------------------------
     large 波长 ~3333 格（主大陆尺度）
     mid   波长 ~1250 格（中尺度起伏）
     mid 权重 0.30
     ------------------------------------------------------------ */
  function continentalness(wx, wz){
    const large = fbm(wx * 0.00030, wz * 0.00030, 4, SEED + 1);
    const mid   = fbm(wx * 0.00080, wz * 0.00080, 2, SEED + 11);
    const raw = large + (mid - 0.5) * 0.30;
    return clamp(splineCont.apply(raw), 0, 1);
  }

  /* ------------------------------------------------------------
     erosion
     ------------------------------------------------------------ */
  function erosion(wx, wz){
    const large = fbm(wx * 0.0003, wz * 0.0003, 4, SEED + 2);
    const mid   = fbm(wx * 0.0012, wz * 0.0012, 2, SEED + 12);
    const raw = large + (mid - 0.5) * 0.15;
    return clamp(splineEro.apply(raw), 0, 1);
  }

  /* ------------------------------------------------------------
     peaksValleys：ridged noise
     ------------------------------------------------------------ */
  function peaksValleys(wx, wz){
    let sum = 0, amp = 1, f = 1, norm = 0;
    for (let i = 0; i < 5; i++){
      let n = fbm(
        wx * 0.0006 * f,
        wz * 0.0006 * f,
        1,
        SEED + 100 + i * 137
      );
      n = 1 - Math.abs(n * 2 - 1);
      n = n * n;
      sum += n * amp;
      norm += amp;
      amp *= 0.5;
      f *= 2;
    }
    return clamp(sum / norm, 0, 1);
  }

  /* ------------------------------------------------------------
     temperature
     ------------------------------------------------------------ */
  /* 季节相位：0=春分，0.25=夏至，0.5=秋分，0.75=冬至 */
  let _seasonPhase = (typeof cfg.seasonPhase === 'number' && isFinite(cfg.seasonPhase))
    ? ((cfg.seasonPhase % 1) + 1) % 1
    : 0;

  function setSeasonPhase(p){
    if (!isFinite(p)) return _seasonPhase;
    _seasonPhase = ((p % 1) + 1) % 1;
    return _seasonPhase;
  }
  function getSeasonPhase(){ return _seasonPhase; }
  function seasonOffset(){
    return Math.sin(_seasonPhase * Math.PI * 2) * SEASON_AMP;
  }

  /* 基础温度：fbm + spline，原逻辑一字不动 */
  function temperatureBase(wx, wz){
    const large = fbm(wx * 0.00045, wz * 0.00045, 3, SEED + 3);
    const small = fbm(wx * 0.0020,  wz * 0.0020,  2, SEED + 13);
    const raw = large + (small - 0.5) * 0.12;
    return clamp(splineTemp.apply(raw), 0, 1);
  }

  /* 完整温度 = 基础温度 + 海拔冷却 + 季节偏移，最后 clamp 一次 */
  function temperatureAt(wx, wy, wz){
    const y = (typeof wy === 'number' && isFinite(wy)) ? wy : SEA_LEVEL;
    const base = temperatureBase(wx, wz);
    const altCool = y > SEA_LEVEL ? -(y - SEA_LEVEL) * LAPSE_RATE : 0;
    return clamp(base + altCool + seasonOffset(), 0, 1);
  }

  /* 兼容旧接口：等价于海平面处的温度 */
  function temperature(wx, wz){
    return temperatureAt(wx, SEA_LEVEL, wz);
  }

  /* ------------------------------------------------------------
     humidity
     ------------------------------------------------------------
     ★ A3：cont 可选
       调用方（biomeBlendAt）已经算过 continentalness 时，
       直接传 cont，避免重复调 4+2 octave fbm
       不传时内部自己算，向后兼容
     ------------------------------------------------------------ */
  function humidity(wx, wz, cont){
    const large = fbm(wx * 0.00055, wz * 0.00055, 3, SEED + 4);
    const small = fbm(wx * 0.0018,  wz * 0.0018,  2, SEED + 14);
    const raw = large + (small - 0.5) * 0.12;
    const base = clamp(splineHum.apply(raw), 0, 1);

    const c = (cont !== undefined) ? cont : continentalness(wx, wz);
    const dryFactor = 1 - smoothstep01(0.6, 1.0, c) * 0.18;
    return clamp(base * dryFactor, 0, 1);
  }

  /* ------------------------------------------------------------
     depth
     ------------------------------------------------------------ */
  function depth(wy){
    if (wy <= SEA_LEVEL){
      return -1 + (wy - Y_MIN) / (SEA_LEVEL - Y_MIN);
    }
    return (wy - SEA_LEVEL) / (CHH - SEA_LEVEL);
  }

  return {
    continentalness,
    erosion,
    peaksValleys,
    temperature,
    temperatureBase,
    temperatureAt,
    setSeasonPhase,
    getSeasonPhase,
    seasonOffset,
    humidity,
    depth,
    SEA_LEVEL, Y_MIN, CHH, SEED,
    SEASON_AMP, LAPSE_RATE, SNOW_TEMP,
  };
}

/* ============================================================
   工具
   ============================================================ */
function smoothstep01(a, b, x){
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}

/* =================================================================
   generators.js
   ================================================================= */
/* ============================================================
   generators.js —— 内置生成器元数据
   ------------------------------------------------------------
   这里**只有 UI 元数据**（label / icon / desc / hidden）。
   真实地形逻辑在 world-gen.js + density.js + params.js。

   terrain.js 启动时会把这里的条目注册进 generator-registry，
   供菜单的"创建世界"对话框列出可选类型。

   注意：不要在这里写 heightAt / biomeAt —— 那些字段在
   generator-registry 里已经废弃，真实地形由 world-gen 内部
   按 worldType 分派。
   ============================================================ */

/* ============================================================
   ★ options —— 每个世界类型自己的创建选项
   ------------------------------------------------------------
   以前创建界面只有一个"最高区块"滑条，所有类型共用，而且超平坦明明
   用不到它还照样显示。现在改成【每个类型声明自己有哪些选项】：

     options: [
       { key:'height', kind:'height' },              // 内置：现有的最高区块滑条
       { key:'sea', kind:'range', label:'海平面',
         min:32, max:120, step:1, def:62 },
       { key:'islands', kind:'toggle', label:'生成岛屿', def:true },
       { key:'note', kind:'text', label:'备注', def:'' },
     ]

   没写 options 的类型 = 没有任何选项（比如超平坦，高度对它没意义）。
   不写 options 字段本身（undefined）表示"用默认的 height 滑条"。

   mod 也可以在自己 registerGenerator 时带上 options，创建界面会照着渲染。
   ============================================================ */

const DEFAULT_OPTIONS = [{ key: 'height', kind: 'height' }];

const BUILTIN_GENERATORS = {

  flat: {
    label: '超平坦',
    icon:  '▭',
    desc:  '无限平坦地表，适合建造',
    /* ★ 空数组 = 这个模式没有可调选项：平坦世界的高度没有意义 */
    options: [],
  },

  vanilla: {
    label: '普通',
    icon:  '▲',
    desc:  '平原 · 丘陵 · 少量山地，适合游玩',
    options: DEFAULT_OPTIONS,
  },

  realistic: {
    label: '真实地形',
    icon:  '⛰',
    desc:  '高山 · 高原 · 大河，适合观景',
    hidden: true,
    options: DEFAULT_OPTIONS,
  },
};

/* =================================================================
   re-export
   ================================================================= */
export {
  CubicSpline, spline2D, createParamSystem, BUILTIN_GENERATORS
};
