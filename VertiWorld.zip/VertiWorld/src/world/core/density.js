/* ============================================================
   density.js —— 3D 密度场 + 洞穴群系
   ------------------------------------------------------------
   ★ 本轮改动：洞穴位置提升
     · CAVE_SURFACE_GUARD_T 0.05 → 0.025（保护层减半）
     · CAVE_SURFACE_FADE_T  0.15 → 0.10
     · wSpag: smoothstep(0.01, 0.06) → smoothstep(0.005, 0.03)
     · wCheese: smoothstep(0.15, 0.35) → smoothstep(0.10, 0.25)
   ============================================================ */

import { fbm, fbm3, clamp, hash2i } from './../../core/runtime.js';
import { spline2D } from './terrain-params.js';
import { riverValue } from './../world-meta.js';

const SPLINE_BASE_HEIGHT = [
  [0.00, -60], [0.30, -25], [0.42, 0], [0.55, 8],
  [0.75, 18],  [1.00, 30],
];

const SPLINE_AMPLITUDE = [
  [0.00, 8],
  [0.30, 15],
  [0.50, 22],
  [0.70, 30],
  [1.00, 40],
];

const SPLINE_ROUGHNESS_AMP = [
  [0.00, 120],
  [0.25, 95],
  [0.45, 68],
  [0.60, 42],
  [0.72, 26],
  [0.85, 16],
  [0.92, 6],
  [1.00, 3],
];

const SPLINE_DETAIL = [
  [0.00, 0.5],
  [0.30, 0.8],
  [0.50, 1.3],
  [0.70, 2.0],
  [0.85, 2.8],
  [1.00, 3.5],
];

const REGION_RUGGED_FREQ = 0.0006;
const REGION_RUGGED_LOW  = 0.45;
const REGION_RUGGED_HIGH = 0.65;

const RIVER_CORE       = 0.030;
const RIVER_BLEND      = 0.060;
const RIVER_BED        = -2;
const RIVER_MAX_DEPTH  = 5;
const RIVER_FADE_TOP   = 30;

const SURF3D_AMP  = 8;
const SURF3D_FXZ  = 0.010;
const SURF3D_FY   = 0.020;

const CLIFF_FREQ   = 0.0018;
const CLIFF_LOW    = 0.62;
const CLIFF_HIGH   = 0.74;

const CAVE_ENABLED = true;

const CAVE_REGION_FREQ = 0.0018;
const CAVE_SIZE_MIN    = 0.35;
const CAVE_SIZE_MAX    = 1.75;

const CAVE_MASK2D_FREQ = 0.0030;
const CAVE_MASK2D_MIN  = 0.20;

/* ★ 保护层减半 */
const CAVE_SURFACE_GUARD_T = 0.025;
const CAVE_SURFACE_FADE_T  = 0.10;

const LOOSENESS_FREQ       = 0.002;
const LOOSE_OPEN_THRESHOLD = 0.93;
const LOOSE_OPEN_CHANCE    = 0.60;

const CAVE_BOTTOM_GUARD = 14;
const CAVE_BOTTOM_FADE  = 8;

const CAVE_UG_FADE_START = 4;
const CAVE_UG_FADE_WIDTH = 12;

const CAVE_TYPE_FREQ   = 0.0020;
const CAVE_BIAS_FREQ   = 0.0012;
const CAVE_SIZE_FREQ   = 0.0010;

const CAVE_BIAS_MIN     = 0.4;
const CAVE_BIAS_MAX     = 2.0;
const CAVE_SIZECAP_MIN  = 0.4;
const CAVE_SIZECAP_MAX  = 1.10;

const CHEESE_FREQ_XZ = 0.0065;
const CHEESE_FREQ_Y  = 0.0070;
const CHEESE_TH_BASE = 0.42;
const CHEESE_TH_DEEP = 0.45;

const CHEESE_HOLLOW_FREQ     = 0.0018;
const CHEESE_WEIRDNESS_FREQ  = 0.0010;
const CHEESE_SIZE_VAR_FREQ   = 0.0006;
const CHEESE_DETAIL_FREQ_MUL = 2.2;

const CHEESE_ENV_FREQ        = 0.012;
const CHEESE_ENV_CENTER_FREQ = 0.010;

const CHEESE_PILLAR_FREQ_XZ = 0.028;
const CHEESE_PILLAR_FREQ_Y  = 0.065;
const CHEESE_PILLAR_TH_LOW  = 0.46;
const CHEESE_PILLAR_TH_HIGH = 0.58;

const CHEESE_CLUSTER_FREQ = 0.0035;
const CHEESE_CLUSTER_TH   = 0.32;

const SPAG_FREQ    = 0.018;
const SPAG_FREQ_Y  = 0.032;
const SPAG_THICKNESS = 0.09;

const SPAG_BAND_FREQ = 0.0025;

function caveWeightsFromSize(sizeScale){
  const t = clamp(
    (sizeScale - CAVE_SIZE_MIN) / (CAVE_SIZE_MAX - CAVE_SIZE_MIN),
    0, 1
  );
  return {
    wCheese: 0.40 + t * t * 0.60,
    wSpag:   1.00 - t * 0.30,
  };
}

const DEFAULT_MOD = {
  ampScale: 1, baseOffset: 0, freqScale: 1,
  typeW: { default: 1 }, step: 8,
};

export function createDensityField(params, cfg){
  const SEED = (cfg.seed | 0);
  const SEA_LEVEL = cfg.SEA_LEVEL;
  const Y_MIN = cfg.Y_MIN !== undefined ? cfg.Y_MIN : -46;
  const CHH   = cfg.CHH   !== undefined ? cfg.CHH   : 400;

  const splineBase         = spline2D(SPLINE_BASE_HEIGHT);
  const splineAmp          = spline2D(SPLINE_AMPLITUDE);
  const splineRoughnessAmp = spline2D(SPLINE_ROUGHNESS_AMP);
  const splineDetail       = spline2D(SPLINE_DETAIL);

  const WORLD_USABLE_DEPTH = Math.max(80, CHH - Y_MIN);
  const WORLD_SCALE = WORLD_USABLE_DEPTH / 480;
  const FREQ_MUL = 1 / WORLD_SCALE;

  let _ugEnabled = false;
  let _ugTop = 0;
  let _ugBot = 0;

  function mountainMask(wx, wz, ero, cont){
    if (cont < 0.42) return 0;
    const zone = fbm(wx * 0.0012, wz * 0.0012, 2, SEED + 700);
    const zMask = smoothstep01(0.45, 0.58, zone);
    const eMask = 1 - smoothstep01(0.30, 0.60, ero);
    const landMask = smoothstep01(0.42, 0.45, cont);
    return zMask * eMask * landMask;
  }

  function plateau(surfaceRel, step){
    const base = Math.floor(surfaceRel / step) * step;
    const frac = surfaceRel - base;
    const smooth = smoothstep01(0.55, 0.95, frac / step);
    return base + smooth * step;
  }

  function dunes(wx, wz){
    const phase = fbm(wx * 0.005, wz * 0.005, 2, SEED + 400) * 10;
    return Math.sin(wx * 0.045 + phase) * 3
         + Math.sin(wz * 0.038 + phase * 1.3) * 2;
  }

  function loosenessAt(wx, wz, ero){
    const looseN = fbm(
      wx * LOOSENESS_FREQ * FREQ_MUL,
      wz * LOOSENESS_FREQ * FREQ_MUL,
      2, SEED + 7000
    );
    return clamp(0.4 * ero + 0.6 * looseN, 0, 1);
  }

  function caveProfileAt(wx, wz, ero){
    const typeN = fbm(
      wx * CAVE_TYPE_FREQ * FREQ_MUL,
      wz * CAVE_TYPE_FREQ * FREQ_MUL,
      2, SEED + 9000
    );
    const typeBias = smoothstep01(0.35, 0.65, typeN);

    const biasN = fbm(
      wx * CAVE_BIAS_FREQ * FREQ_MUL,
      wz * CAVE_BIAS_FREQ * FREQ_MUL,
      2, SEED + 9501
    );
    const densityBias = CAVE_BIAS_MIN + biasN * (CAVE_BIAS_MAX - CAVE_BIAS_MIN);

    const sizeCapN = fbm(
      wx * CAVE_SIZE_FREQ * FREQ_MUL,
      wz * CAVE_SIZE_FREQ * FREQ_MUL,
      2, SEED + 9502
    );
    const rawSizeCap = 1.5 - densityBias * 0.5 + sizeCapN * 0.3;
    const sizeCap = clamp(rawSizeCap, CAVE_SIZECAP_MIN, CAVE_SIZECAP_MAX);

    const sizeScale = CAVE_SIZE_MIN + typeBias * (CAVE_SIZE_MAX - CAVE_SIZE_MIN);
    const weights = caveWeightsFromSize(sizeScale);

    let biomeHint;
    if (typeBias > 0.65)      biomeHint = 'cheese';
    else if (typeBias > 0.35) biomeHint = 'mixed';
    else                      biomeHint = 'spaghetti';

    const _2d = {
      cluster:  fbm(
        wx * CHEESE_CLUSTER_FREQ * FREQ_MUL,
        wz * CHEESE_CLUSTER_FREQ * FREQ_MUL,
        2, SEED + 3500
      ),
      envN:     fbm(
        wx * CHEESE_ENV_FREQ * FREQ_MUL,
        wz * CHEESE_ENV_FREQ * FREQ_MUL,
        2, SEED + 7000
      ),
      centerN:  fbm(
        wx * CHEESE_ENV_CENTER_FREQ * FREQ_MUL,
        wz * CHEESE_ENV_CENTER_FREQ * FREQ_MUL,
        2, SEED + 7001
      ),
      hollowN:  fbm(
        wx * CHEESE_HOLLOW_FREQ * FREQ_MUL,
        wz * CHEESE_HOLLOW_FREQ * FREQ_MUL,
        2, SEED + 3600
      ),
      weirdN:   fbm(
        wx * CHEESE_WEIRDNESS_FREQ * FREQ_MUL,
        wz * CHEESE_WEIRDNESS_FREQ * FREQ_MUL,
        2, SEED + 5000
      ),
      sizeVarN: fbm(
        wx * CHEESE_SIZE_VAR_FREQ * FREQ_MUL,
        wz * CHEESE_SIZE_VAR_FREQ * FREQ_MUL,
        2, SEED + 6000
      ),
      mask2d:   fbm(
        wx * CAVE_MASK2D_FREQ * FREQ_MUL,
        wz * CAVE_MASK2D_FREQ * FREQ_MUL,
        3, SEED + 3100
      ),
      bandN:    fbm(
        wx * SPAG_BAND_FREQ * FREQ_MUL,
        wz * SPAG_BAND_FREQ * FREQ_MUL,
        3, SEED + 4500
      ),
      openN:    fbm(wx * 0.08, wz * 0.08, 1, SEED + 7100),
    };

    return {
      typeBias, densityBias, sizeCap, sizeScale,
      wCheese: weights.wCheese,
      wSpag:   weights.wSpag,
      biomeHint,
      looseness: loosenessAt(wx, wz, ero),
      ero,
      _2d,
    };
  }

  function sampleColumn(wx, wz, mod){
    mod = mod || DEFAULT_MOD;

    const cont = params.continentalness(wx, wz);
    const ero  = params.erosion(wx, wz);
    const pv   = params.peaksValleys(wx, wz);

    const baseH         = splineBase.apply(cont) + mod.baseOffset;
    const roughnessAmp  = splineRoughnessAmp.apply(ero);
    const detailIntensity = splineDetail.apply(pv);
    const amp           = splineAmp.apply(ero) * mod.ampScale;

    const mMask = mountainMask(wx, wz, ero, cont);

    const regionN = fbm(
      wx * REGION_RUGGED_FREQ * FREQ_MUL,
      wz * REGION_RUGGED_FREQ * FREQ_MUL,
      2, SEED + 5000
    );
    const regionBoost = smoothstep01(REGION_RUGGED_LOW, REGION_RUGGED_HIGH, regionN);

    /* Domain warp */
    const warpAmp = Math.min(80, roughnessAmp * 1.0);
    const warpX = (fbm(wx * 0.0028, wz * 0.0028, 2, SEED + 880) - 0.5) * warpAmp;
    const warpZ = (fbm(wx * 0.0028, wz * 0.0028, 2, SEED + 881) - 0.5) * warpAmp;
    const wxW = wx + warpX;
    const wzW = wz + warpZ;

    /* 分层 rolling */
    const rollingLow  = fbm(wxW * 0.0020, wzW * 0.0020, 2, SEED + 300);
    const rollingMid  = fbm(wxW * 0.0070, wzW * 0.0070, 3, SEED + 301);
    const rollingHigh = fbm(wxW * 0.0200, wzW * 0.0200, 2, SEED + 302);

    const rollingN = (rollingLow - 0.5) * 1.00
                   + (rollingMid - 0.5) * 0.45
                   + (rollingHigh - 0.5) * 0.18;

    const rolling = rollingN * roughnessAmp * (1 + regionBoost * 0.5) / 1.63;

    /* 折叠 ridge */
    const ridgeRaw = fbm(wxW * 0.0035, wzW * 0.0035, 3, SEED + 710);
    let ridgeFold = 1 - Math.abs(ridgeRaw * 2 - 1);
    ridgeFold = ridgeFold * ridgeFold;
    const ridgeActive = 1 - smoothstep01(0.30, 0.60, ero);
    const ridgeAmp = roughnessAmp * 0.40 * ridgeActive;
    const ridge = (ridgeFold - 0.5) * ridgeAmp;

    /* 中频细节 */
    const detailN = fbm(wxW * 0.014, wzW * 0.014, 3, SEED + 720);
    const detailAmp = roughnessAmp * 0.12 * detailIntensity;
    const detail = (detailN - 0.5) * detailAmp;

    /* 微细节 */
    const microN = fbm(wx * 0.045, wz * 0.045, 2, SEED + 730);
    const microAmp = roughnessAmp * 0.04 * detailIntensity;
    const micro = (microN - 0.5) * microAmp;

    let surfaceRel = baseH + rolling + ridge + detail + micro;

    const w = mod.typeW || { default: 1 };

    const wPlat = w.plateau || 0;
    if (wPlat > 0){
      const plat = plateau(surfaceRel, mod.step || 8);
      surfaceRel = surfaceRel * (1 - wPlat) + plat * wPlat;
    }

    const wDune = w.dunes || 0;
    if (wDune > 0) surfaceRel += dunes(wx, wz) * wDune;

    const wSwamp = w.swamp || 0;
    if (wSwamp > 0){
      const cap = baseH + 1;
      if (surfaceRel > cap){
        const compressed = cap + (surfaceRel - cap) * 0.3;
        surfaceRel = surfaceRel * (1 - wSwamp) + compressed * wSwamp;
      }
    }

    const wOcean = w.ocean || 0;
    if (wOcean > 0){
      surfaceRel = surfaceRel * (1 - wOcean) + baseH * wOcean;
    }

    const wFlat = w.flat || 0;
    if (wFlat > 0){
      const rollingOnly = surfaceRel - baseH - ridge;
      surfaceRel = baseH + ridge + rollingOnly * (1 - wFlat);
    }

    if (cont > 0.52){
      const floor = baseH - 2;
      if (surfaceRel < floor) surfaceRel = floor;
    }

    if (cont > 0.42){
      const rv = riverValue(wx, wz, SEED);
      const widthNoise = fbm(wx * 0.0003, wz * 0.0003, 2, SEED + 1500);
      const widthScale = 0.6 + widthNoise * 1.2;
      const localBlend = RIVER_BLEND * widthScale;
      const localCore  = RIVER_CORE  * widthScale;

      if (rv < localBlend){
        const t = clamp(
          (rv - localCore) / Math.max(0.001, localBlend - localCore),
          0, 1
        );
        const smoothT = t * t * (3 - 2 * t);
        const depthFactor = Math.max(0,
          (RIVER_FADE_TOP - surfaceRel) / RIVER_FADE_TOP
        );
        const depth = depthFactor * RIVER_MAX_DEPTH;
        const targetBed = Math.max(RIVER_BED, surfaceRel - depth);
        if (targetBed < surfaceRel){
          surfaceRel = surfaceRel * smoothT + targetBed * (1 - smoothT);
        }
      }
    }

    const cliffN = fbm(wx * CLIFF_FREQ, wz * CLIFF_FREQ, 3, SEED + 850);
    const cliffMask = smoothstep01(CLIFF_LOW, CLIFF_HIGH, cliffN);
    const cliffAmount = 0.30 + 0.55 * mMask;
    const effectiveAmp = Math.max(3, amp * (1 - cliffMask * cliffAmount));

    const surfaceY = SEA_LEVEL + surfaceRel;
    const caveProfile = caveProfileAt(wx, wz, ero);

    return {
      wx, wz, mod,
      surfaceY,
      amp: effectiveAmp,
      mMask,
      cont,
      detailIntensity,
      caveProfile,
    };
  }

  function caveZoneAt(wx, wz){
    const typeN = fbm(
      wx * CAVE_TYPE_FREQ * FREQ_MUL,
      wz * CAVE_TYPE_FREQ * FREQ_MUL,
      2, SEED + 9000
    );
    if (typeN < 0.35) return 'spaghetti';
    if (typeN > 0.65) return 'cheese';
    return 'mixed';
  }

  function spagBandAt(bandN, t){
    const bandCenter = 0.08 + bandN * 0.42;
    const halfH = 0.14 + bandN * 0.10;
    const dist = Math.abs(t - bandCenter);
    return 1 - smoothstep01(halfH * 0.7, halfH, dist);
  }

  function _caveGate(wx, wy, wz, surfaceY, caveProfile){
    const usableDepth = Math.max(1, surfaceY - Y_MIN);
    const depth = surfaceY - wy;
    if (depth <= 0) return null;

    const t = depth / usableDepth;

    const looseness = caveProfile.looseness || 0.5;
    let surfaceFade;
    if (looseness > LOOSE_OPEN_THRESHOLD){
      const openN = caveProfile._2d.openN;
      if (openN < LOOSE_OPEN_CHANCE){
        surfaceFade = 1.0;
      } else {
        surfaceFade = smoothstep01(0, 0.02, t);
      }
    } else {
      surfaceFade = smoothstep01(
        CAVE_SURFACE_GUARD_T,
        CAVE_SURFACE_GUARD_T + CAVE_SURFACE_FADE_T,
        t
      );
    }
    if (surfaceFade < 0.01) return null;

    const ugFade = _ugEnabled
      ? smoothstep01(
          _ugTop + CAVE_UG_FADE_START,
          _ugTop + CAVE_UG_FADE_START + CAVE_UG_FADE_WIDTH,
          wy
        )
      : 1;
    if (ugFade < 0.01) return null;

    let bottomFade = 1;
    if (!_ugEnabled){
      bottomFade = smoothstep01(
        Y_MIN + CAVE_BOTTOM_GUARD,
        Y_MIN + CAVE_BOTTOM_GUARD + CAVE_BOTTOM_FADE,
        wy
      );
      if (bottomFade < 0.01) return null;
    }

    /* ★ wSpag / wCheese 都提前 */
    const wSpag = smoothstep01(0.005, 0.03, t)
                * (1 - smoothstep01(0.70, 0.95, t));
    const wCheese = smoothstep01(0.10, 0.25, t)
                  * (1 - smoothstep01(0.70, 0.88, t));

    if (wSpag < 0.01 && wCheese < 0.01) return null;

    const mask2d = caveProfile._2d.mask2d;
    let maskThreshold;
    if (depth < 30)      maskThreshold = 0.03;
    else if (depth < 70) maskThreshold = 0.06;
    else                 maskThreshold = CAVE_MASK2D_MIN;
    if (mask2d < maskThreshold) return null;

    const typeBias = caveProfile.typeBias;
    const smoothType = smoothstep01(0.30, 0.70, typeBias);
    const zoneMulCheese = 0.35 + smoothType * 0.65;
    const zoneMulSpag   = 0.35 + (1 - smoothType) * 0.65;

    const ero = caveProfile.ero !== undefined ? caveProfile.ero : 0.5;
    const richnessMod = 0.6 + ero * 0.7;

    const fade = ugFade * bottomFade * richnessMod;

    return {
      depth, t, usableDepth,
      surfaceFade, fade,
      wCheese, wSpag,
      zoneMulCheese, zoneMulSpag,
    };
  }

  function computeCheese(wx, wy, wz, depth, sizeScale, wCheese, caveProfile, surfaceFade, usableDepth, surfaceY){
    if (wCheese < 0.01 || caveProfile.wCheese < 0.05) return 0;

    const c2d = caveProfile._2d;

    const clusterGate = smoothstep01(
      CHEESE_CLUSTER_TH, CHEESE_CLUSTER_TH + 0.15, c2d.cluster
    );
    if (clusterGate < 0.01) return 0;

    const allow = wCheese * clusterGate
                * caveProfile.wCheese * surfaceFade;
    if (allow < 0.01) return 0;

    const baseTh = CHEESE_TH_BASE + (CHEESE_TH_DEEP - CHEESE_TH_BASE)
                 * clamp((depth - 40) / 200, 0, 1);
    const sizeAdj  = (sizeScale - 1.0) * 0.10;
    const allowAdj = (1 - allow) * 0.10;
    const th = baseTh - sizeAdj + allowAdj;

    const fx = CHEESE_FREQ_XZ * FREQ_MUL;
    const fy = CHEESE_FREQ_Y  * FREQ_MUL;

    const envHalfHeight = (4 + Math.pow(c2d.envN, 2.5) * 30) * caveProfile.sizeCap;
    const envCenterY = surfaceY - usableDepth * (0.20 + c2d.centerN * 0.60);

    const dY = Math.abs(wy - envCenterY);
    if (dY > envHalfHeight * 1.15) return 0;

    const verticalGate = 1 - smoothstep01(envHalfHeight * 0.55, envHalfHeight, dY);
    if (verticalGate < 0.01) return 0;

    const baseN = fbm3(wx * fx, wy * fy, wz * fx, 3, SEED + 3001);
    if (baseN < th - 0.20) return 0;

    const hollowness = smoothstep01(0.40, 0.65, c2d.hollowN);
    const weirdness  = smoothstep01(0.55, 0.75, c2d.weirdN);
    const sizeVariation = c2d.sizeVarN;

    let detailN = 0;
    if (hollowness > 0.15){
      const dfx = fx * CHEESE_DETAIL_FREQ_MUL;
      const dfy = fy * CHEESE_DETAIL_FREQ_MUL;
      detailN = fbm3(wx * dfx, wy * dfy, wz * dfx, 2, SEED + 3002) - 0.5;
    }

    const thN = fbm3(wx * 0.005, wy * 0.005, wz * 0.005, 2, SEED + 3060) - 0.5;

    let thAdjust = 0;
    thAdjust -= hollowness * 0.05;
    thAdjust += (1 - weirdness) * 0.05;
    const biasAdj = (caveProfile.densityBias - 1.0) * 0.08;
    const thFinal = th - biasAdj + thAdjust + thN * 0.08;

    const combined = baseN + detailN * hollowness * 0.20;

    const softEdgeWidth = 0.09 * (0.7 + sizeVariation * 0.6);
    let cheese = smoothstep01(thFinal, thFinal + softEdgeWidth, combined);

    cheese *= verticalGate;

    if (cheese > 0.05 && cheese < 0.85){
      const edge = 1 - Math.abs(cheese - 0.5) * 2;
      const erode = fbm3(wx * 0.06, wy * 0.06, wz * 0.06, 2, SEED + 3070);
      const erodeThreshold = 0.35 + (1 - weirdness) * 0.15;
      if (erode < erodeThreshold){
        cheese *= (1 - edge * 0.6);
      }
    }

    if (cheese > 0.35){
      const warpX = (fbm3(wx * 0.010, wy * 0.008, wz * 0.010, 2, SEED + 4010) - 0.5) * 3.0;
      const warpZ = (fbm3(wx * 0.010, wy * 0.008, wz * 0.010, 2, SEED + 4011) - 0.5) * 3.0;

      const pillarN = fbm3(
        (wx + warpX) * CHEESE_PILLAR_FREQ_XZ,
        wy * CHEESE_PILLAR_FREQ_Y,
        (wz + warpZ) * CHEESE_PILLAR_FREQ_XZ,
        3, SEED + 3001
      );

      const pillarMask = smoothstep01(
        CHEESE_PILLAR_TH_LOW, CHEESE_PILLAR_TH_HIGH, pillarN
      );
      cheese *= (1 - pillarMask * 0.85);
    }

    cheese = Math.min(1, cheese * 1.4);
    return cheese;
  }

  function computeSpaghetti(wx, wy, wz, caveProfile){
    const fx = SPAG_FREQ * FREQ_MUL;
    const fy = SPAG_FREQ_Y * FREQ_MUL;

    const spagA = fbm3(wx * fx, wy * fy, wz * fx, 3, SEED + 1001) - 0.5;
    const spagB = fbm3(wx * fx, wy * fy, wz * fx, 3, SEED + 7723) - 0.5;

    const dA = Math.abs(spagA);
    const dB = Math.abs(spagB);
    const dMax = dA > dB ? dA : dB;

    const thickness = SPAG_THICKNESS * caveProfile.sizeCap;

    if (dMax >= thickness) return 0;

    return 1 - smoothstep01(thickness * 0.6, thickness, dMax);
  }

  function cheeseStrengthAt(wx, wy, wz, surfaceY, caveProfile){
    if (typeof surfaceY !== 'number' || !isFinite(surfaceY)) return 0;
    if (!caveProfile) return 0;

    const gate = _caveGate(wx, wy, wz, surfaceY, caveProfile);
    if (!gate) return 0;

    if (gate.wCheese < 0.01 || caveProfile.wCheese < 0.05) return 0;

    const c = computeCheese(
      wx, wy, wz, gate.depth, caveProfile.sizeScale,
      gate.wCheese, caveProfile, gate.surfaceFade,
      gate.usableDepth, surfaceY
    ) * gate.zoneMulCheese;

    return c * gate.fade;
  }

  function spaghettiStrengthAt(wx, wy, wz, surfaceY, caveProfile){
    if (typeof surfaceY !== 'number' || !isFinite(surfaceY)) return 0;
    if (!caveProfile) return 0;

    const gate = _caveGate(wx, wy, wz, surfaceY, caveProfile);
    if (!gate) return 0;

    if (gate.wSpag < 0.01 || caveProfile.wSpag < 0.05) return 0;

    let bandW = 1;
    if (gate.t > 0.05) bandW = spagBandAt(caveProfile._2d.bandN, gate.t);
    if (bandW < 0.01) return 0;

    const spagLocal = computeSpaghetti(wx, wy, wz, caveProfile);
    if (spagLocal < 0.01) return 0;

    const biasMul = Math.sqrt(caveProfile.densityBias);
    const gateVal = Math.sqrt(
      bandW * gate.wSpag * caveProfile.wSpag * gate.zoneMulSpag
    ) * Math.min(1, biasMul);

    return spagLocal * gateVal * gate.surfaceFade * gate.fade;
  }

  function caveStrengthAt(wx, wy, wz, surfaceY, caveProfile){
    const c = cheeseStrengthAt(wx, wy, wz, surfaceY, caveProfile);
    const s = spaghettiStrengthAt(wx, wy, wz, surfaceY, caveProfile);
    return Math.max(c, s * 0.85);
  }

  function densityAtY(wy, col, includeCaves){
    if (includeCaves === undefined) includeCaves = true;

    const wx = col.wx, wz = col.wz;
    const mMask = col.mMask;
    const amp = col.amp;
    const surfaceY = col.surfaceY;
    const detailIntensity = col.detailIntensity || 0.5;

    const surf3D = fbm3(
      wx * SURF3D_FXZ, wy * SURF3D_FY, wz * SURF3D_FXZ,
      3, SEED + 800
    ) - 0.5;

    const ridge3D = fbm3(
      wx * 0.006, wy * 0.010, wz * 0.006,
      3, SEED + 750
    );
    const ridgeFolded = 1 - Math.abs(ridge3D * 2 - 1);

    const surf3DAmp = SURF3D_AMP * (0.5 + detailIntensity * 1.2);
    const ridgeAmp = 20 * (0.2 + detailIntensity * 1.5);
    const ridgeOffset = (ridgeFolded - 0.5) * ridgeAmp * mMask;

    const yRel = wy - surfaceY - surf3D * 2 * surf3DAmp - ridgeOffset;
    const vertical = -yRel / amp;

    const n3 = fbm3(wx * 0.05, wy * 0.05, wz * 0.05, 2, SEED + 50) - 0.5;
    const detail = n3 * 0.15 * detailIntensity;

    const nearSurface = 1 - smoothstep01(0, 10, Math.abs(yRel));

    const cliffPerturb = (fbm3(wx * 0.028, wy * 0.055, wz * 0.028, 3, SEED + 760) - 0.5)
                       * 12 * detailIntensity * nearSurface * mMask;

    const microDetail = (fbm3(wx * 0.12, wy * 0.12, wz * 0.12, 2, SEED + 770) - 0.5)
                      * 0.08 * (0.5 + detailIntensity * 2.0) * mMask;

    const base = vertical + detail + cliffPerturb + microDetail;

    if (!CAVE_ENABLED || !includeCaves) return base;

    const lo = col.caveProfile ? (col.caveProfile.looseness || 0.5) : 0.5;
    const usableDepth = Math.max(1, surfaceY - Y_MIN);
    const t = (surfaceY - wy) / usableDepth;

    if (lo > LOOSE_OPEN_THRESHOLD){
      if (t < 0.005) return base;
    } else {
      if (t < CAVE_SURFACE_GUARD_T) return base;
    }

    if (!_ugEnabled && wy <= Y_MIN + CAVE_BOTTOM_GUARD) return base;

    const cave = caveStrengthAt(wx, wy, wz, surfaceY, col.caveProfile);

    if (cave <= 0.10) return base;
    if (cave > 0.35) return -2;

    const k = (cave - 0.10) / 0.25;
    return base * (1 - k) - k * 2;
  }

  function setUndergroundRange(enabled, top, bot){
    _ugEnabled = !!enabled;
    _ugTop = top;
    _ugBot = bot;
  }

  function undergroundDensityAt(wx, wy, wz){
    if (!_ugEnabled) return 1;
    if (wy >= _ugTop) return 1;

    const ceilN = fbm(wx * 0.005, wz * 0.005, 2, SEED + 6100);
    const ceilY = _ugTop - 0.5 - ceilN * 3;
    if (wy >= ceilY) return 1;

    const lakeN = fbm(wx * 0.0045, wz * 0.0045, 2, SEED + 6500);
    const lakeAmount = smoothstep01(0.62, 0.68, lakeN);

    const dryN = fbm(wx * 0.006, wz * 0.006, 2, SEED + 6400);
    const dryFloor = -70 + dryN * 12;

    const lakeFloorN = fbm(wx * 0.012, wz * 0.012, 2, SEED + 6501);
    const wetFloor = -74 - lakeFloorN * 4;

    let floorY = dryFloor * (1 - lakeAmount) + wetFloor * lakeAmount;

    const maxFloor = ceilY - 5;
    if (floorY > maxFloor) floorY = maxFloor;

    if (wy <= floorY) return 1;

    let rock = -(wy - floorY) / 4;

    const pillarBodyN = fbm(wx * 0.035, wz * 0.035, 2, SEED + 6200);
    const pillarEdgeN = fbm(wx * 0.15, wz * 0.15, 1, SEED + 6201) - 0.5;
    if (pillarBodyN + pillarEdgeN * 0.18 > 0.64) return 1;

    const distToCeil = ceilY - wy;
    if (distToCeil < 5){
      const tt = smoothstep01(0, 5, distToCeil);
      rock = rock * tt + 1 * (1 - tt);
    }

    return rock;
  }

  function caveDetailAt(wx, wy, wz, surfaceY, caveProfile){
    const empty = {
      total: 0, cheese: 0, spaghetti: 0, canyon: 0, fissure: 0,
      looseness: 0, sizeScale: 0, biomeHint: '?', depth: 0,
      ugRock: 1, inUG: false,
      typeBias: 0, densityBias: 1, sizeCap: 1,
    };
    if (!caveProfile) return empty;

    const usableDepth = Math.max(1, surfaceY - Y_MIN);
    const depth = surfaceY - wy;
    const t = depth / usableDepth;

    const base = {
      total: 0, cheese: 0, spaghetti: 0, canyon: 0, fissure: 0,
      looseness: caveProfile.looseness,
      sizeScale: caveProfile.sizeScale,
      biomeHint: caveProfile.biomeHint,
      depth,
      ugRock: 1,
      inUG: false,
      typeBias: caveProfile.typeBias,
      densityBias: caveProfile.densityBias,
      sizeCap: caveProfile.sizeCap,
    };

    if (_ugEnabled && wy < _ugTop + CAVE_UG_FADE_START) {
      base.inUG = true;
      base.ugRock = undergroundDensityAt(wx, wy, wz);
      return base;
    }

    if (t < CAVE_SURFACE_GUARD_T) return base;
    if (!_ugEnabled && wy <= Y_MIN + CAVE_BOTTOM_GUARD) return base;

    const cheese = cheeseStrengthAt(wx, wy, wz, surfaceY, caveProfile);
    const spaghetti = spaghettiStrengthAt(wx, wy, wz, surfaceY, caveProfile);

    return {
      ...base,
      total: Math.max(cheese, spaghetti * 0.85),
      cheese, spaghetti,
    };
  }

  function densityAt(wx, wy, wz, mod, includeCaves){
    const col = sampleColumn(wx, wz, mod);
    return densityAtY(wy, col, includeCaves);
  }

  return {
    densityAt,
    sampleColumn,
    densityAtY,
    caveStrengthAt,
    cheeseStrengthAt,
    spaghettiStrengthAt,
    caveProfileAt,
    caveZoneAt,
    caveDetailAt,
    undergroundDensityAt,
    setUndergroundRange,
  };
}

function smoothstep01(a, b, x){
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}