/* ============================================================
   world-gen.js —— 地形生成 + 装饰
   ------------------------------------------------------------
   ★ 累积改动：
     · 3D 插值（2×4×2 网格）：地形密度 + cheese 网格化
     · 动态土层厚度：2~6 格，受群系和高程影响
     · 土台阶修复：cave 挖空地表后下方方块替换成群系表面
     · 沙滩填充：beach 群系 h~h-4 空隙填沙
     · B3：_plantSeagrass 检查水底实心
     · slope 极速优化：直接用 topY 查表，不再调用 4 次 heightAt
     · 新增 quickHeightAt 供 worm 起点使用
     · 修复：海洋填充时更新 chunk.maxY，解决海面不渲染的元老级 Bug
     · ★ 导出 params / biomeBlendAt / terrainModAt（preview 用）
     · ★ _tryIceberg 全新重写：dome/peak/multi 三种形状
     · ★ 移除交界随机网格化，改用 tintMap 平滑染色
   ============================================================ */

import { CS, BIOME, WORLD_TYPE } from './../../core/engine-core.js';
import {
  hash2i, fbm, fbm3, vnoise, vnoise3, smoothstep, clamp,
} from './../../core/runtime.js';
import { getBiome, listBiomes } from './../world-core.js';
import { BLOCKS } from './../blocks.js';
import { createParamSystem }    from './terrain-params.js';
import { createDensityField }   from './density.js';
import { createSurfaceRules }   from './carvers.js';
import { riverValue }           from './../world-meta.js';
import { generateOres }         from './carvers.js';
import { carveWorms }           from './carvers.js';
import { carveCanyons }         from './carvers.js';
import {
  LOST_CITY_RADIUS, LOST_CITY_HOUSE_R, LOST_CITY_HOUSES,
  findLostCity as _findLostCityAt,
  houseIndexAt, isPlaza, isOuterWall,
  cityChestPoints, cityBedPoints,
} from './lost-city.js';

/* ============================================================
   常量
   ============================================================ */
const FL_SRC  = 0x10;
const FL_TSRC = 0x20;

const MAX_CROSS_WRITES = 512;

const ICE_TEMP   = 0.16;
const ICE_CELL   = 128;
const ICE_CHANCE = 0.45;

const BLEND_MIX_K = 0.5;

const DEFAULT_TERRAIN = {
  ampScale: 1, baseOffset: 0, freqScale: 1,
  type: 'default', step: 8,
};

export function createWorldGen(blockIds, cfg){
  const SEED           = cfg.seed | 0;
  const WORLD_TYPE_V   = cfg.worldType || WORLD_TYPE.VANILLA;
  const GEN_HOOK       = cfg.generator || null;  /* ★ mod 生成器钩子 */
  const SEA_LEVEL      = cfg.SEA_LEVEL;
  const CHH            = cfg.CHH;
  const Y_MIN          = cfg.Y_MIN;
  const COL_H          = CHH - Y_MIN;

  const terrainCeiling = (typeof cfg.terrainCeiling === 'function')
    ? cfg.terrainCeiling
    : () => Math.max(SEA_LEVEL + 30, Math.floor(CHH * 0.85));

  const _idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;

  /* ============================================================
     子系统
     ============================================================ */
  const params = createParamSystem({
    seed: SEED, SEA_LEVEL, Y_MIN, CHH,
  });

  const density = createDensityField(params, {
    seed: SEED, SEA_LEVEL, Y_MIN, CHH,
  });

  const surfaceRules = createSurfaceRules(blockIds, {
    seed: SEED, SEA_LEVEL,
  });

  /* ============================================================
     地心世界范围
     ============================================================ */
  const UG_BOT = Y_MIN + 1;
  const UG_TOP = Y_MIN + 28;
  const UG_ENABLED = (UG_TOP - UG_BOT) >= 15 && (SEA_LEVEL - UG_TOP) >= 20;

  density.setUndergroundRange(UG_ENABLED, UG_TOP, UG_BOT);

  if (UG_ENABLED){
    console.log(`[world-gen] 地心世界: ${UG_BOT} ~ ${UG_TOP} (${UG_TOP - UG_BOT} 格)`);
  } else {
    console.log(`[world-gen] 世界太浅 (${CHH})，跳过地心世界`);
  }

  /* ============================================================
     heightAt（完整版，供装饰和神殿使用）
     ============================================================ */
  function heightAt(wx, wz){
    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      return SEA_LEVEL + 4;
    }

    /* ★ mod 覆盖：heightAt 钩子返回数字就优先用 */
    if (GEN_HOOK && typeof GEN_HOOK.heightAt === 'function'){
      try {
        const h = GEN_HOOK.heightAt(wx, wz, { seed: SEED, SEA_LEVEL, Y_MIN, CHH });
        if (typeof h === 'number' && isFinite(h)) return h;
      } catch(e){ console.warn('[world-gen] mod heightAt 出错:', e); }
    }

    const mod = terrainModAt(wx, wz);
    const col = density.sampleColumn(wx, wz, mod);

    let lo = Y_MIN;
    let hi = CHH - 1;

    if (density.densityAtY(hi, col, false) > 0) return hi;
    if (density.densityAtY(lo, col, false) <= 0) return lo;

    for (let i = 0; i < 12; i++){
      const mid = (lo + hi) >> 1;
      if (density.densityAtY(mid, col, false) > 0) lo = mid;
      else hi = mid;
    }
    return lo;
  }

  /* ============================================================
     quickHeightAt（快速估算版，供 worm 起点使用）
     ============================================================ */
  function quickHeightAt(wx, wz){
    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      return SEA_LEVEL + 4;
    }
    const mod = terrainModAt(wx, wz);
    const col = density.sampleColumn(wx, wz, mod);

    let lo = Y_MIN, hi = CHH - 1;
    if (density.densityAtY(hi, col, false) > 0) return hi;
    if (density.densityAtY(lo, col, false) <= 0) return lo;

    for (let i = 0; i < 6; i++){
      const mid = (lo + hi) >> 1;
      if (density.densityAtY(mid, col, false) > 0) lo = mid;
      else hi = mid;
    }
    return lo;
  }

  function rangeDist(v, range){
    if (v < range[0]) return range[0] - v;
    if (v > range[1]) return v - range[1];
    return 0;
  }

  /* ============================================================
     biomeBlendAt
     ============================================================ */
  const SEA_LINE      = 0.42;
  const BLEND_HALF    = 0.02;
  const LAND_BLEND_START = 0.44;
  const LAND_BLEND_END   = 0.48;

  function biomeBlendAt(wx, wz, h){
    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      return { primary: BIOME.PLAINS, secondary: BIOME.PLAINS, mix: 0 };
    }

    const cont = params.continentalness(wx, wz);

    /* ① 海洋 */
    if (cont < SEA_LINE ||
        (h !== undefined && h < SEA_LEVEL - 1 && cont < 0.50)){

      let mix = 0;
      if (cont > SEA_LINE - BLEND_HALF){
        mix = clamp((cont - (SEA_LINE - BLEND_HALF)) / BLEND_HALF, 0, 1) * 0.5;
      }
      return { primary: BIOME.OCEAN, secondary: BIOME.BEACH, mix };
    }

    /* ② 河流 */
    if (h !== undefined && h < SEA_LEVEL + 10){
      const rv = riverValue(wx, wz, SEED);
      const widthNoise = fbm(wx * 0.0003, wz * 0.0003, 2, SEED + 1500);
      const widthScale = 0.6 + widthNoise * 1.2;
      if (rv < 0.06 * widthScale){
        return { primary: BIOME.RIVER, secondary: BIOME.RIVER, mix: 0 };
      }
    }

    /* ③ 海滩 */
    if (cont < LAND_BLEND_END && h !== undefined && h < SEA_LEVEL + 8){
      if (cont < SEA_LINE + BLEND_HALF){
        const mix = clamp((SEA_LINE + BLEND_HALF - cont) / BLEND_HALF, 0, 1) * 0.5;
        return { primary: BIOME.BEACH, secondary: BIOME.OCEAN, mix };
      }

      if (cont > LAND_BLEND_START){
        const temp = params.temperatureAt(wx, h, wz);
        const hum  = params.humidity(wx, wz, cont);
        let landBiome = BIOME.PLAINS;
        let bestScore = -Infinity;
        const biomes = listBiomes();

        for (let i = 0; i < biomes.length; i++){
          const b = biomes[i];
          if (!b.climate) continue;
          const dt = rangeDist(temp, b.climate.temp);
          const dh = rangeDist(hum,  b.climate.hum);
          const d2 = dt * dt + dh * dh;
          if (d2 > 0.15) continue;
          const wField = fbm(wx * 0.0008, wz * 0.0008, 2, SEED + 5000 + b.id * 137);
          const w = b.weight !== undefined ? b.weight : 1;
          const score = wField * w - d2 * 12;
          if (score > bestScore){ bestScore = score; landBiome = b.id; }
        }

        const t = clamp(
          (cont - LAND_BLEND_START) / (LAND_BLEND_END - LAND_BLEND_START), 0, 1
        );
        if (t < 0.5){
          return { primary: BIOME.BEACH, secondary: landBiome, mix: t * 2 * 0.5 };
        } else {
          return { primary: landBiome, secondary: BIOME.BEACH, mix: (1 - t) * 2 * 0.5 };
        }
      }
      return { primary: BIOME.BEACH, secondary: BIOME.BEACH, mix: 0 };
    }

    const temp = params.temperatureAt(wx, h, wz);
    const hum  = params.humidity(wx, wz, cont);

    /* ④ 稀有蘑菇岛 */
    const rare = fbm(wx * 0.002, wz * 0.002, 2, SEED + 999);
    if (rare > 0.92 && temp > 0.4 && temp < 0.7){
      return { primary: BIOME.MUSHROOM, secondary: BIOME.MUSHROOM, mix: 0 };
    }

    /* ⑤ 气候匹配 top-2 */
    const biomes = listBiomes();
    let best1 = { id: BIOME.PLAINS, score: -Infinity };
    let best2 = { id: BIOME.PLAINS, score: -Infinity };

    for (let i = 0; i < biomes.length; i++){
      const b = biomes[i];
      if (!b.climate) continue;

      const dt = rangeDist(temp, b.climate.temp);
      const dh = rangeDist(hum,  b.climate.hum);
      const d2 = dt * dt + dh * dh;
      if (d2 > 0.15) continue;

      const s1 = fbm(wx * 0.0008, wz * 0.0008, 2, SEED + 5000 + b.id * 137);
      const s2 = fbm(wx * 0.0030, wz * 0.0030, 2, SEED + 6000 + b.id * 137);
      const s3 = fbm(wx * 0.0100, wz * 0.0100, 2, SEED + 7000 + b.id * 137);
      const wField = s1 * 0.5 + s2 * 0.3 + s3 * 0.2;
      const w = b.weight !== undefined ? b.weight : 1;
      const perturb = fbm(wx * 0.005, wz * 0.005, 2, SEED + 11000 + b.id * 137);
      /* 极端气候命中时给 bonus，让沙漠/丛林/雪原不被平原/森林抢走 */
      let extremeBonus = 0;
      if (b.name === 'desert' && temp > 0.70 && hum < 0.40) extremeBonus = 0.6;
      if (b.name === 'jungle' && temp > 0.72 && hum > 0.32) extremeBonus = 0.6;
      if (b.name === 'snow'   && temp < 0.16)                 extremeBonus = 0.20;
      const score = wField * w - d2 * 12 + (perturb - 0.5) * 0.5 + extremeBonus;

      if (score > best1.score){
        best2 = best1;
        best1 = { id: b.id, score };
      } else if (score > best2.score){
        best2 = { id: b.id, score };
      }
    }

    let mix = 0;
    if (best2.score > -Infinity){
      const gap = best1.score - best2.score;
      const edgeNoise = fbm(wx * 0.008, wz * 0.008, 2, SEED + 8888) - 0.5;
      const gapAdj = gap + edgeNoise * 0.4;
      mix = clamp(0.5 - gapAdj * BLEND_MIX_K, 0, 0.5);
    }

    return { primary: best1.id, secondary: best2.id, mix };
  }

  function biomeAt(wx, wz, h){
    if (GEN_HOOK && typeof GEN_HOOK.biomeAt === 'function'){
      try {
        const b = GEN_HOOK.biomeAt(wx, wz, h, { seed: SEED, SEA_LEVEL, Y_MIN, CHH });
        if (typeof b === 'number' && b >= 0) return b;
      } catch(e){ console.warn('[world-gen] mod biomeAt 出错:', e); }
    }
    return biomeBlendAt(wx, wz, h).primary;
  }

  /* ============================================================
     ★ 新增：获取该位置混合后的群系颜色
     ============================================================ */
  function getBiomeColors(wx, wz, h) {
    const surfaceY = (typeof h === 'number' && isFinite(h)) ? h : SEA_LEVEL;
    const blend = biomeBlendAt(wx, wz, surfaceY);
    const b1 = getBiome(blend.primary);
    const b2 = getBiome(blend.secondary);

    // 未配置的群系给 0xffffff，这样乘上去对原贴图毫无影响
    const g1 = b1 && b1.grassColor !== undefined ? b1.grassColor : 0xffffff;
    const g2 = b2 && b2.grassColor !== undefined ? b2.grassColor : 0xffffff;
    const f1 = b1 && b1.foliageColor !== undefined ? b1.foliageColor : 0xffffff;
    const f2 = b2 && b2.foliageColor !== undefined ? b2.foliageColor : 0xffffff;

    const w1 = 1 - blend.mix;
    const w2 = blend.mix;

    const mixCol = (c1, c2) => {
      const r = ((c1 >> 16) & 255) * w1 + ((c2 >> 16) & 255) * w2;
      const g = ((c1 >> 8) & 255) * w1 + ((c2 >> 8) & 255) * w2;
      const b = (c1 & 255) * w1 + (c2 & 255) * w2;
      return (Math.floor(r) << 16) | (Math.floor(g) << 8) | Math.floor(b);
    };

    let grass   = mixCol(g1, g2);
    let foliage = mixCol(f1, f2);

    /* 温度调制：冷 -> 偏枯黄，热 -> 偏干燥黄绿 */
    const temp  = params.temperatureAt(wx, surfaceY, wz);
    const coldF = 1 - smoothstep(0.05, 0.35, temp);
    const hotF  = smoothstep(0.65, 0.95, temp);
    const rMul  = 1 + coldF * 0.20 + hotF * 0.12;
    const gMul  = 1 - coldF * 0.12;
    const bMul  = 1 - coldF * 0.30 - hotF * 0.15;

    const modCol = (c) => {
      const r = Math.max(0, Math.min(255, Math.floor(((c >> 16) & 255) * rMul)));
      const g = Math.max(0, Math.min(255, Math.floor(((c >>  8) & 255) * gMul)));
      const b = Math.max(0, Math.min(255, Math.floor(( c        & 255) * bMul)));
      return (r << 16) | (g << 8) | b;
    };

    return { grass: modCol(grass), foliage: modCol(foliage) };
  }

  /* ============================================================
     terrainModAt
     ============================================================ */
  function terrainModAt(wx, wz){
    const blend = biomeBlendAt(wx, wz);
    const b1 = getBiome(blend.primary);
    const b2 = getBiome(blend.secondary);

    const m1 = (b1 && b1.terrain) || DEFAULT_TERRAIN;
    const m2 = (b2 && b2.terrain) || DEFAULT_TERRAIN;

    const w1 = 1 - blend.mix;
    const w2 = blend.mix;

    const ampScale   = m1.ampScale   * w1 + m2.ampScale   * w2;
    const baseOffset = m1.baseOffset * w1 + m2.baseOffset * w2;
    const freqScale  = m1.freqScale  * w1 + m2.freqScale  * w2;

    const typeW = {};
    typeW[m1.type] = (typeW[m1.type] || 0) + w1;
    typeW[m2.type] = (typeW[m2.type] || 0) + w2;

    return { ampScale, baseOffset, freqScale, typeW, step: m1.step || 8 };
  }

  /* ============================================================
     findTemple
     ============================================================ */
  let _templePos      = cfg.templePos || null;
  let _templeComputed = !!cfg.templePos;

  function findTemple(){
    if (_templeComputed) return _templePos;
    _templeComputed = true;
    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      _templePos = { x: 60, z: 60 };
      return _templePos;
    }
    for (let r = 48; r < 420; r += 16){
      for (let a = 0; a < 24; a++){
        const ang = a * Math.PI / 12;
        const x = Math.round(Math.cos(ang) * r);
        const z = Math.round(Math.sin(ang) * r);
        if (heightAt(x, z) < SEA_LEVEL - 9){
          _templePos = { x, z };
          return _templePos;
        }
      }
    }
    _templePos = null;
    return null;
  }

  /* ============================================================
     findLostCity —— 丛林中的失落古城（种子确定性）
     ============================================================ */
  let _lostCityPos = cfg.lostCityPos || null;
  let _lostCityComputed = !!cfg.lostCityPos;

  function findLostCity(){
    if (_lostCityComputed) return _lostCityPos;
    _lostCityComputed = true;
    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      _lostCityPos = null;
      return null;
    }
    _lostCityPos = _findLostCityAt(SEED, SEA_LEVEL, heightAt, biomeAt, getBiome);
    return _lostCityPos;
  }

  /* ============================================================
     _genTerrain —— 3D 插值版 + slope 极速查表
     ============================================================ */
  function _genTerrain(chunk){
    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const blocks = chunk.blocks;
    const fluid  = chunk.fluid;
    const topY   = chunk.topY;
    let maxY = Y_MIN;
    let minY = CHH - 1;

    const ID_BEDROCK = blockIds.bedrock;
    const ID_WATER   = blockIds.water;
    const ID_STONE   = blockIds.stone;
    const ID_ICE     = blockIds.ice;
    const ID_LAVA    = blockIds.lava;
    const ID_DIRT    = blockIds.dirt;

    /* ---------- ① 第一遍：cols + topY ---------- */
    const cols = new Array(CS * CS);
    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        const wx = bx + x, wz = bz + z;
        const mod = terrainModAt(wx, wz);
        const col = density.sampleColumn(wx, wz, mod);
        cols[z * CS + x] = col;

        let lo = Y_MIN, hi = CHH - 1;
        let h;
        if (density.densityAtY(hi, col, false) > 0){
          h = hi;
        } else if (density.densityAtY(lo, col, false) <= 0){
          h = lo;
        } else {
          for (let i = 0; i < 12; i++){
            const mid = (lo + hi) >> 1;
            if (density.densityAtY(mid, col, false) > 0) lo = mid;
            else hi = mid;
          }
          h = lo;
        }
        topY[z * CS + x] = h;
      }
    }

    /* ---------- ② 2×4×2 网格 ---------- */
    const GX = 2, GY = 4, GZ = 2;
    const NX = (CS / GX) + 1;                          // 9
    const NZ = (CS / GZ) + 1;                          // 9
    const NY = Math.ceil((CHH - 1 - Y_MIN) / GY) + 2;  // CHH=400 → 122

    const gridDensity = new Float32Array(NX * NY * NZ);
    const gridCheese  = new Float32Array(NX * NY * NZ);

    for (let ix = 0; ix < NX; ix++){
      const wx = bx + ix * GX;
      for (let iz = 0; iz < NZ; iz++){
        const wz = bz + iz * GZ;
        const mod = terrainModAt(wx, wz);
        const col = density.sampleColumn(wx, wz, mod);
        const surfaceY = col.surfaceY;
        const caveProfile = col.caveProfile;

        for (let iy = 0; iy < NY; iy++){
          const y = Y_MIN + iy * GY;
          const sampleY = Math.min(y, CHH - 1);

          const d = density.densityAtY(sampleY, col, false);
          gridDensity[(ix * NY + iy) * NZ + iz] = d;

          const cs = density.cheeseStrengthAt(wx, sampleY, wz, surfaceY, caveProfile);
          gridCheese[(ix * NY + iy) * NZ + iz] = cs;
        }
      }
    }

    function triLerp(arr, ix0, iy0, iz0, tx, ty, tz){
      const ix1 = ix0 + 1, iy1 = iy0 + 1, iz1 = iz0 + 1;
      const i000 = (ix0 * NY + iy0) * NZ + iz0;
      const i001 = (ix0 * NY + iy0) * NZ + iz1;
      const i010 = (ix0 * NY + iy1) * NZ + iz0;
      const i011 = (ix0 * NY + iy1) * NZ + iz1;
      const i100 = (ix1 * NY + iy0) * NZ + iz0;
      const i101 = (ix1 * NY + iy0) * NZ + iz1;
      const i110 = (ix1 * NY + iy1) * NZ + iz0;
      const i111 = (ix1 * NY + iy1) * NZ + iz1;

      const c00 = arr[i000] + (arr[i100] - arr[i000]) * tx;
      const c01 = arr[i001] + (arr[i101] - arr[i001]) * tx;
      const c10 = arr[i010] + (arr[i110] - arr[i010]) * tx;
      const c11 = arr[i011] + (arr[i111] - arr[i011]) * tx;

      const c0 = c00 + (c10 - c00) * ty;
      const c1 = c01 + (c11 - c01) * ty;

      return c0 + (c1 - c0) * tz;
    }

    /* ---------- ③ 逐格插值 + 组装 ---------- */
    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        const ix0 = Math.min(Math.floor(x / GX), NX - 2);
        const iz0 = Math.min(Math.floor(z / GZ), NZ - 2);
        const tx = (x - ix0 * GX) / GX;
        const tz = (z - iz0 * GZ) / GZ;

        const col = cols[z * CS + x];
        const caveProfile = col.caveProfile;
        const surfaceY = col.surfaceY;
        const h = topY[z * CS + x];

        const wx = bx + x, wz = bz + z;

        for (let y = h; y > Y_MIN; y--){
          const iy0 = Math.min(Math.floor((y - Y_MIN) / GY), NY - 2);
          const ty = ((y - Y_MIN) - iy0 * GY) / GY;

          const d = triLerp(gridDensity, ix0, iy0, iz0, tx, ty, tz);
          const cheese = triLerp(gridCheese, ix0, iy0, iz0, tx, ty, tz);
          const spaghetti = density.spaghettiStrengthAt(wx, y, wz, surfaceY, caveProfile);
          const cave = Math.max(cheese, spaghetti * 0.85);

          let solid;
          if (cave <= 0.10){
            solid = d > 0;
          } else if (cave > 0.35){
            solid = false;
          } else {
            const k = (cave - 0.10) / 0.25;
            solid = (d * (1 - k) - k * 2) > 0;
          }

          const i = _idx(x, y, z);

          if (UG_ENABLED && y < UG_TOP){
            solid = density.undergroundDensityAt(wx, y, wz) > 0;
          }

          if (!solid && UG_ENABLED && y < UG_TOP && y <= Y_MIN + 9){
            blocks[i] = ID_LAVA;
            fluid[i]  = 8 | FL_SRC | FL_TSRC;
          } else {
            blocks[i] = solid ? ID_STONE : 0;
          }
          if (y < minY) minY = y;
        }

        if (h < SEA_LEVEL){
          for (let y = h + 1; y <= SEA_LEVEL; y++){
            const i = _idx(x, y, z);
            if (blocks[i] === 0){
              blocks[i] = ID_WATER;
              fluid[i]  = 8 | FL_SRC | FL_TSRC;
            }
          }
          if (SEA_LEVEL > maxY) maxY = SEA_LEVEL;
        }

        const iBase = _idx(x, Y_MIN, z);
        blocks[iBase] = ID_BEDROCK;

        if (h > maxY) maxY = h;
      }
    }

    /* ---------- ④ 第二遍：地表规则 + 动态土层 ---------- */
    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        const wx = bx + x, wz = bz + z;
        const h = topY[z * CS + x];
        const underwater = h < SEA_LEVEL;

        const rv = riverValue(wx, wz, SEED);
        const widthNoise = fbm(wx * 0.0003, wz * 0.0003, 2, SEED + 1500);
        const widthScale = 0.6 + widthNoise * 1.2;

        const blend = biomeBlendAt(wx, wz, h);
        const hookBiome = biomeAt(wx, wz, h);
        const biomeId = getBiome(hookBiome) ? hookBiome : blend.primary; // ★ 不做随机替换，直接用主群系
        let slope = 0;
        if (!underwater && h > SEA_LEVEL + 30){
          const hN = topY[Math.max(0, z - 2) * CS + x];
          const hS = topY[Math.min(CS - 1, z + 2) * CS + x];
          const hW = topY[z * CS + Math.max(0, x - 2)];
          const hE = topY[z * CS + Math.min(CS - 1, x + 2)];
          slope = Math.max(
            Math.abs(h - hN), Math.abs(h - hS),
            Math.abs(h - hW), Math.abs(h - hE)
          );
        }

        const r = surfaceRules.rulesFor({
          wx, wz, surfaceY: h, biomeId, rv, widthScale,
          isUnderwater: underwater, slope,
        });

        const iSurf = _idx(x, h, z);
        const surfId = blocks[iSurf];
        if (surfId !== ID_BEDROCK && surfId !== 0 && surfId !== ID_WATER){
          blocks[iSurf] = r.surface;
        }

        const thickN      = fbm(wx * 0.008, wz * 0.008, 2, SEED + 900);
        const thickJitter = hash2i(wx, wz, SEED + 901) - 0.5;

        const alt = h - SEA_LEVEL;
        let biomeMod = 0;
        if (biomeId === 9 || biomeId === 1 || biomeId === 0){
          biomeMod = -1;
        } else if (biomeId === 6 || biomeId === 11){
          biomeMod = 1;
        } else if (biomeId === 8){
          biomeMod = -1;
        } else if (alt > 60){
          biomeMod = -1;
        }

        let soilDepth = Math.floor(
          2 + thickN * 3 + thickJitter * 1.5 + biomeMod
        );
        if (soilDepth < 1) soilDepth = 1;
        if (soilDepth > 6) soilDepth = 6;

        let exposed = (surfId === 0 || surfId === ID_WATER);
        for (let dy = 1; dy <= soilDepth; dy++){
          const y = h - dy;
          if (y <= Y_MIN) break;
          const iSub = _idx(x, y, z);
          const subId = blocks[iSub];

          if (subId === ID_BEDROCK || subId === 0 || subId === ID_WATER){
            exposed = true;
            continue;
          }

          if (exposed){
            if (subId === ID_STONE || subId === ID_DIRT){
              blocks[iSub] = r.surface;
            }
            exposed = false;
          } else {
            if (subId === ID_STONE){
              blocks[iSub] = r.subsurface;
            }
          }
        }

        if (biomeId === 1){
          for (let dy = 0; dy <= 4; dy++){
            const y = h - dy;
            if (y <= Y_MIN) break;
            const iFill = _idx(x, y, z);
            if (blocks[iFill] === 0){
              blocks[iFill] = blockIds.sand;
            }
          }
        }

        if (underwater && ID_ICE){
          const t = params.temperatureAt(wx, SEA_LEVEL, wz);
          if (t < ICE_TEMP){
            const iTop = _idx(x, SEA_LEVEL, z);
            if (blocks[iTop] === ID_WATER){
              blocks[iTop] = ID_ICE;
              fluid[iTop]  = 0;
            }
          }
        }
      }
    }

    chunk.minY = Math.max(Y_MIN + 2, minY);
    chunk.maxY = Math.min(CHH - 1, maxY + 2);
    chunk.templeDone = false;
  }

  /* ============================================================
     地下岩石变种
     ------------------------------------------------------------
     ★ 在地表规则、洞穴、矿脉生成之后执行，只替换"仍然是石头"的方块：
       不会覆盖泥土/沙子/矿脉，也不会改变洞穴形状。
     ★ 用 8×8×8 的 3D 噪声网格 + 三线性插值，避免逐格采样拖慢生成。
     ============================================================ */
  function _applyStoneVariants(chunk){
    const ids = {
      stone: blockIds.stone,
      deepslate: blockIds.deepslate,
      granite: blockIds.granite,
      diorite: blockIds.diorite,
      andesite: blockIds.andesite,
      limestone: blockIds.limestone,
      marble: blockIds.marble,
      loess: blockIds.loess,
      blackstone: blockIds.blackstone,
      basalt: blockIds.basalt,
    };
    if (!ids.stone || !ids.deepslate) return;

    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const blocks = chunk.blocks;
    const topY = chunk.topY;

    const SG  = 8;
    const SNX = Math.ceil(CS / SG) + 1;
    const SNZ = SNX;
    const SNY = Math.ceil((CHH - 1 - Y_MIN) / SG) + 1;
    const NF  = 6;
    const scales = [0.042, 0.047, 0.052, 0.040, 0.068, 0.058];
    const fields = [];

    for (let k = 0; k < NF; k++){
      const arr = new Float32Array(SNX * SNY * SNZ);
      const s = scales[k];
      const sd = SEED + 21000 + k * 977;
      for (let ix = 0; ix < SNX; ix++){
        const wx = bx + ix * SG;
        for (let iz = 0; iz < SNZ; iz++){
          const wz = bz + iz * SG;
          for (let iy = 0; iy < SNY; iy++){
            const wy = Y_MIN + iy * SG;
            arr[(ix * SNY + iy) * SNZ + iz] =
              vnoise3(wx * s, wy * s, wz * s, sd);
          }
        }
      }
      fields.push(arr);
    }

    function sampleField(arr, ix0, iy0, iz0, tx, ty, tz){
      const ix1 = ix0 + 1, iy1 = iy0 + 1, iz1 = iz0 + 1;
      const i000 = (ix0 * SNY + iy0) * SNZ + iz0;
      const i001 = (ix0 * SNY + iy0) * SNZ + iz1;
      const i010 = (ix0 * SNY + iy1) * SNZ + iz0;
      const i011 = (ix0 * SNY + iy1) * SNZ + iz1;
      const i100 = (ix1 * SNY + iy0) * SNZ + iz0;
      const i101 = (ix1 * SNY + iy0) * SNZ + iz1;
      const i110 = (ix1 * SNY + iy1) * SNZ + iz0;
      const i111 = (ix1 * SNY + iy1) * SNZ + iz1;

      const c00 = arr[i000] + (arr[i100] - arr[i000]) * tx;
      const c01 = arr[i001] + (arr[i101] - arr[i001]) * tx;
      const c10 = arr[i010] + (arr[i110] - arr[i010]) * tx;
      const c11 = arr[i011] + (arr[i111] - arr[i011]) * tx;

      const c0 = c00 + (c10 - c00) * ty;
      const c1 = c01 + (c11 - c01) * ty;
      return c0 + (c1 - c0) * tz;
    }

    for (let x = 0; x < CS; x++){
      const ix0 = Math.min(Math.floor(x / SG), SNX - 2);
      const tx  = (x - ix0 * SG) / SG;

      for (let z = 0; z < CS; z++){
        const iz0 = Math.min(Math.floor(z / SG), SNZ - 2);
        const tz  = (z - iz0 * SG) / SG;

        const h = topY[z * CS + x];
        const wx = bx + x, wz = bz + z;
        /* 深板岩顶界：2 ~ 9 格之间逐列抖动 */
        const deepTop = 2 + Math.floor(hash2i(wx, wz, SEED + 13000) * 8);
        const loessTop = h - 5;
        const loessBot = h - 20;

        for (let y = Math.min(h - 5, CHH - 2); y > Y_MIN + 1; y--){
          const i = _idx(x, y, z);
          if (blocks[i] !== ids.stone) continue;

          /* 深层整层深板岩 */
          if (y < deepTop){
            blocks[i] = ids.deepslate;
            continue;
          }

          const iy0 = Math.min(Math.floor((y - Y_MIN) / SG), SNY - 2);
          const ty  = ((y - Y_MIN) - iy0 * SG) / SG;

          /* ---- 花岗岩 / 闪长岩 / 安山岩：中层斑块 ---- */
          if (ids.granite &&
              sampleField(fields[0], ix0, iy0, iz0, tx, ty, tz) > 0.74){
            blocks[i] = ids.granite; continue;
          }
          if (ids.diorite &&
              sampleField(fields[1], ix0, iy0, iz0, tx, ty, tz) > 0.74){
            blocks[i] = ids.diorite; continue;
          }
          if (ids.andesite &&
              sampleField(fields[2], ix0, iy0, iz0, tx, ty, tz) > 0.73){
            blocks[i] = ids.andesite; continue;
          }

          /* ---- 石灰岩：中浅层 ---- */
          if (ids.limestone && y > 4 && y < 80 &&
              sampleField(fields[3], ix0, iy0, iz0, tx, ty, tz) > 0.72){
            blocks[i] = ids.limestone; continue;
          }

          /* ---- 大理石：深层稀有 ---- */
          if (ids.marble && y < 30 &&
              sampleField(fields[4], ix0, iy0, iz0, tx, ty, tz) > 0.80){
            blocks[i] = ids.marble; continue;
          }

          /* ---- 玄武岩 / 黑石：深层 ---- */
          if (y < 22 &&
              sampleField(fields[5], ix0, iy0, iz0, tx, ty, tz) > 0.77){
            if (ids.basalt){ blocks[i] = ids.basalt; continue; }
          }
          if (ids.blackstone && y < 12 &&
              sampleField(fields[5], ix0, iy0, iz0, tx, ty, tz) < 0.16){
            blocks[i] = ids.blackstone; continue;
          }

          /* ---- 黄土：近地表沉积层 ---- */
          if (ids.loess && y >= loessBot && y <= loessTop &&
              sampleField(fields[5], ix0, iy0, iz0, tx, ty, tz) < 0.26){
            blocks[i] = ids.loess; continue;
          }
        }
      }
    }
  }

  /* ============================================================
     _setGen / _getGen
     ============================================================ */
  function _setGen(chunk, crossWrites, lx, ly, lz, id){
    if (ly < Y_MIN + 1 || ly >= CHH - 1) return;
    if (lx >= 0 && lx < CS && lz >= 0 && lz < CS){
      chunk.blocks[_idx(lx, ly, lz)] = id;
      if (ly + 1 > chunk.maxY) chunk.maxY = Math.min(CHH - 1, ly + 1);
      return;
    }
    if (crossWrites.length >= MAX_CROSS_WRITES) return;
    const wx = chunk.cx * CS + lx, wz = chunk.cz * CS + lz;
    crossWrites.push({
      cx: wx >> 4, cz: wz >> 4,
      ix: _idx(wx & 15, ly, wz & 15),
      id, ly,
    });
  }

  function _getGen(chunk, lx, ly, lz){
    if (ly < Y_MIN || ly >= CHH) return 0;
    if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return 0;
    return chunk.blocks[_idx(lx, ly, lz)];
  }

  /* ============================================================
     种树
     ============================================================ */
  function _plantTree(chunk, crossWrites, lx, ly, lz, treeType, wx, wz){
    const rnd = n => hash2i(wx + n * 7, wz - n * 13, 999 + n + SEED);
    let logId, leafId, trunkH, treeScale = 1, leafR, leafRY;

    if (treeType === 'sakura'){
      logId = blockIds.sakura_log; leafId = blockIds.sakura_leaves;
      trunkH = 4 + Math.floor(rnd(1) * 2); leafR = 3.0; leafRY = 1.5;
    } else if (treeType === 'spruce'){
      logId = blockIds.spruce_log; leafId = blockIds.spruce_leaves;
      trunkH = 6 + Math.floor(rnd(2) * 4); leafR = 2.3; leafRY = 2.0; treeScale = 0.85;
    } else if (treeType === 'birch'){
      logId = blockIds.birch_log; leafId = blockIds.birch_leaves;
      trunkH = 5 + Math.floor(rnd(3) * 3); leafR = 2.0; leafRY = 1.6;
    } else if (treeType === 'jungle'){
      logId = blockIds.jungle_log; leafId = blockIds.jungle_leaves;
      trunkH = 8 + Math.floor(rnd(4) * 6); leafR = 3.4; leafRY = 2.4;
    } else if (treeType === 'acacia'){
      logId = blockIds.acacia_log; leafId = blockIds.acacia_leaves;
      trunkH = 4 + Math.floor(rnd(5) * 2); leafR = 3.2; leafRY = 1.0;
    } else if (treeType === 'mangrove'){
      logId = blockIds.mangrove_log; leafId = blockIds.mangrove_leaves;
      trunkH = 4 + Math.floor(rnd(6) * 3); leafR = 2.6; leafRY = 1.4;
    } else {
      logId = blockIds.oak_log; leafId = blockIds.oak_leaves;
      trunkH = 4 + Math.floor(rnd(3) * 3); leafR = 2.3; leafRY = 2.0;
    }

    if (!logId || !leafId) return;

    for (let i = 0; i < trunkH; i++){
      if (_getGen(chunk, lx, ly + i, lz) !== 0) return;
    }
    for (let i = 0; i < trunkH; i++){
      _setGen(chunk, crossWrites, lx, ly + i, lz, logId);
    }

    if (treeType === 'mangrove' && blockIds.mangrove_root){
      const rootCount = 3 + Math.floor(rnd(7) * 3);
      for (let i = 0; i < rootCount; i++){
        const ang = rnd(10 + i) * Math.PI * 2;
        const len = 2 + Math.floor(rnd(20 + i) * 3);
        for (let s = 1; s <= len; s++){
          const rx = lx + Math.round(Math.cos(ang) * s);
          const rz = lz + Math.round(Math.sin(ang) * s);
          const ry = ly - 1 + Math.round(Math.sin(s * 0.4) * 0.8);
          if (ry < Y_MIN + 1 || ry >= CHH - 1) break;
          const cur = _getGen(chunk, rx, ry, rz);
          if (cur !== 0 && cur !== blockIds.water && cur !== blockIds.dirt) break;
          _setGen(chunk, crossWrites, rx, ry, rz, blockIds.mangrove_root);
        }
      }
    }

    const top = ly + trunkH - 1;
    const R  = leafR * treeScale;
    const RY = leafRY * treeScale;

    for (let dx = -4; dx <= 4; dx++){
      for (let dz = -4; dz <= 4; dz++){
        for (let dy = -2; dy <= 4; dy++){
          const d = Math.sqrt(
            (dx * dx) / (R * R) +
            (dy * dy) / ((RY + 0.4) * (RY + 0.4)) +
            (dz * dz) / (R * R)
          );
          if (d > 1.05) continue;
          if (Math.abs(dx) >= 4 && Math.abs(dz) >= 4) continue;
          if (_getGen(chunk, lx + dx, top + dy, lz + dz) === 0){
            _setGen(chunk, crossWrites, lx + dx, top + dy, lz + dz, leafId);
          }
        }
      }
    }

    /* ---- 丛林藤蔓：从树冠底面垂挂（参考 MC 丛林） ---- */
    if (treeType === 'jungle' && blockIds.vine){
      const vineId = blockIds.vine;
      for (let dx = -4; dx <= 4; dx++){
        for (let dz = -4; dz <= 4; dz++){
          for (let dy = -2; dy <= 4; dy++){
            const yy = top + dy;
            if (_getGen(chunk, lx + dx, yy, lz + dz) !== leafId) continue;
            if (_getGen(chunk, lx + dx, yy - 1, lz + dz) !== 0) continue;
            const vr = hash2i(wx + dx * 31, wz + dz * 17 + yy * 7, 1510 + SEED);
            if (vr > 0.12) continue;
            const len = 1 + Math.floor(
              hash2i(wx + dx * 13, wz + dz * 29, 1511 + SEED) * 4
            );
            for (let k = 1; k <= len; k++){
              if (_getGen(chunk, lx + dx, yy - k, lz + dz) !== 0) break;
              _setGen(chunk, crossWrites, lx + dx, yy - k, lz + dz, vineId);
            }
          }
        }
      }
    }
  }

  /* ============================================================
     神殿
     ============================================================ */
  function _placeTemple(chunk, crossWrites){
    if (!_templePos || chunk.templeDone) return;
    chunk.templeDone = true;

    const bx0 = chunk.cx * CS, bx1 = bx0 + CS - 1;
    const bz0 = chunk.cz * CS, bz1 = bz0 + CS - 1;
    const tx0 = _templePos.x - 9, tx1 = _templePos.x + 9;
    const tz0 = _templePos.z - 9, tz1 = _templePos.z + 9;
    if (bx1 < tx0 || bx0 > tx1 || bz1 < tz0 || bz0 > tz1) return;

    const ox = _templePos.x - chunk.cx * CS;
    const oz = _templePos.z - chunk.cz * CS;
    const baseY = Math.max(Y_MIN + 3,
      Math.floor(heightAt(_templePos.x, _templePos.z)));

    const S = (lx, ly, lz, id) => _setGen(chunk, crossWrites, lx, ly, lz, id);

    for (let dx = -9; dx <= 9; dx++){
      for (let dz = -9; dz <= 9; dz++){
        const lx = ox + dx, lz = oz + dz;
        S(lx, baseY - 1, lz, blockIds.prismarine_bricks);
        S(lx, baseY,     lz, blockIds.prismarine_bricks);
        const edge = (Math.abs(dx) === 9 || Math.abs(dz) === 9);
        const corner = (Math.abs(dx) >= 8 && Math.abs(dz) >= 8);
        if (edge && !corner){
          for (let dy = 1; dy <= 8; dy++){
            if (dy >= 3 && dy <= 6 && (dx === 0 || dz === 0)) continue;
            S(lx, baseY + dy, lz, blockIds.prismarine);
          }
        }
        if (corner){
          for (let dy = 1; dy <= 11; dy++)
            S(lx, baseY + dy, lz, blockIds.dark_prismarine);
          S(lx, baseY + 12, lz, blockIds.sea_lantern);
        }
      }
    }
    for (let dx = -9; dx <= 9; dx++)
      for (let dz = -9; dz <= 9; dz++)
        S(ox + dx, baseY + 9, oz + dz, blockIds.dark_prismarine);
    for (let dx = -4; dx <= 4; dx++)
      for (let dz = -4; dz <= 4; dz++)
        if (Math.abs(dx) === 4 || Math.abs(dz) === 4)
          for (let dy = 1; dy <= 5; dy++)
            S(ox + dx, baseY + dy, oz + dz, blockIds.prismarine_bricks);
    for (let dx = -3; dx <= 3; dx++)
      for (let dz = -3; dz <= 3; dz++)
        S(ox + dx, baseY + 6, oz + dz, blockIds.dark_prismarine);

    S(ox, baseY + 1, oz, blockIds.sea_lantern);
    S(ox, baseY + 2, oz, blockIds.prismarine);
    S(ox, baseY + 3, oz, blockIds.gold);
    S(ox, baseY + 4, oz, blockIds.prismarine);
    S(ox, baseY + 5, oz, blockIds.sea_lantern);

    [[-7,-7],[7,-7],[-7,7],[7,7]].forEach(([dx, dz]) => {
      S(ox + dx, baseY + 8, oz + dz, blockIds.sea_lantern);
    });

    chunk.maxY = Math.min(CHH - 1, baseY + 14);
  }

  /* ============================================================
     冰山（全新重写）
     ============================================================ */
  function _placeIcebergs(chunk, crossWrites){
    const iceId = blockIds.ice;
    if (!iceId) return;

    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const c0x = Math.floor((bx - ICE_CELL) / ICE_CELL);
    const c0z = Math.floor((bz - ICE_CELL) / ICE_CELL);
    const c1x = Math.floor((bx + CS + ICE_CELL) / ICE_CELL);
    const c1z = Math.floor((bz + CS + ICE_CELL) / ICE_CELL);

    for (let ccx = c0x; ccx <= c1x; ccx++){
      for (let ccz = c0z; ccz <= c1z; ccz++){
        _tryIceberg(chunk, ccx, ccz, iceId);
      }
    }
  }

  function _tryIceberg(chunk, ccx, ccz, iceId){
    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const packedId    = blockIds.packed_ice || iceId;
    const snowLayerId = blockIds.snow_layer;
    const waterId     = blockIds.water;

    const cellSeed = SEED + ccx * 73856093 + ccz * 19349663;

    if (hash2i(ccx, ccz, 9001 + cellSeed) > ICE_CHANCE) return;

    const px = (ccx + 0.20 + hash2i(ccx, ccz, 9002 + cellSeed) * 0.60) * ICE_CELL;
    const pz = (ccz + 0.20 + hash2i(ccx, ccz, 9003 + cellSeed) * 0.60) * ICE_CELL;

    const radius = 10 + hash2i(ccx, ccz, 9005 + cellSeed) * 22;
    const maxH   =  8 + hash2i(ccx, ccz, 9006 + cellSeed) * 14;

    const R = radius + 6;
    if (px + R < bx || px - R > bx + CS) return;
    if (pz + R < bz || pz - R > bz + CS) return;

    if (params.temperatureAt(px, SEA_LEVEL, pz) >= ICE_TEMP) return;

    const typeRnd = hash2i(ccx, ccz, 9004 + cellSeed);
    const shape = typeRnd < 0.60 ? 'dome'
                : typeRnd < 0.85 ? 'peak'
                : 'multi';

    const edgeAmp  = 0.12 + hash2i(ccx, ccz, 9010 + cellSeed) * 0.18;
    const edgeSeed = cellSeed + 500;

    const numPeaks = (shape === 'multi')
      ? 2 + Math.floor(hash2i(ccx, ccz, 9011 + cellSeed) * 3)
      : 0;
    const peakList = [];
    for (let i = 0; i < numPeaks; i++){
      const ang = hash2i(ccx, ccz, 9020 + i * 7 + cellSeed) * Math.PI * 2;
      const rr  = hash2i(ccx, ccz, 9030 + i * 7 + cellSeed) * radius * 0.55;
      const hMul = 0.4 + hash2i(ccx, ccz, 9040 + i * 7 + cellSeed) * 0.5;
      peakList.push({
        x: px + Math.cos(ang) * rr,
        z: pz + Math.sin(ang) * rr,
        hMul,
      });
    }

    const baseDepth = 4 + hash2i(ccx, ccz, 9050 + cellSeed) * 5;

    const lx0 = Math.max(0, Math.floor(px - R) - bx);
    const lx1 = Math.min(CS - 1, Math.ceil(px + R) - bx);
    const lz0 = Math.max(0, Math.floor(pz - R) - bz);
    const lz1 = Math.min(CS - 1, Math.ceil(pz + R) - bz);

    for (let lz = lz0; lz <= lz1; lz++){
      for (let lx = lx0; lx <= lx1; lx++){
        const wx = bx + lx + 0.5;
        const wz = bz + lz + 0.5;
        const dx = wx - px;
        const dz = wz - pz;
        const dRaw = Math.hypot(dx, dz);

        const ang = Math.atan2(dz, dx);
        const angNoise = fbm(
          Math.cos(ang) * 6 + cellSeed * 0.0001,
          Math.sin(ang) * 6 + cellSeed * 0.0002,
          3, edgeSeed
        );
        const localR = radius * (1 + (angNoise - 0.5) * edgeAmp * 2);

        if (dRaw > localR + 1) continue;

        const localTop = chunk.topY[lz * CS + lx];
        if (localTop > SEA_LEVEL - 1) continue;
        const surfB = chunk.blocks[_idx(lx, SEA_LEVEL, lz)];
        if (surfB !== waterId && surfB !== iceId) continue;

        const t = dRaw / localR;

        let h = 0;
        if (shape === 'dome'){
          h = Math.sqrt(Math.max(0, 1 - t * t)) * maxH;
        } else if (shape === 'peak'){
          h = Math.pow(Math.max(0, 1 - t), 1.6) * maxH;
        } else {
          h = Math.sqrt(Math.max(0, 1 - t * t)) * maxH * 0.8;
          for (const pk of peakList){
            const pdx = wx - pk.x;
            const pdz = wz - pk.z;
            const pd  = Math.hypot(pdx, pdz);
            const bumpR = radius * 0.32;
            if (pd < bumpR){
              h += Math.pow(1 - pd / bumpR, 2) * maxH * 0.35 * pk.hMul;
            }
          }
        }

        if (h < 0.85) continue;
        const hInt = Math.floor(h);

        for (let dy = 0; dy < hInt; dy++){
          const y = SEA_LEVEL + dy;
          if (y >= CHH - 1) break;
          const cur = chunk.blocks[_idx(lx, y, lz)];
          if (cur !== 0 && cur !== waterId && cur !== iceId) break;

          const relH = dy / hInt;
          let placeId = iceId;
          if (dy === hInt - 1 && hInt >= 2){
            placeId = snowLayerId || packedId;
          } else if (relH > 0.40){
            placeId = packedId;
          }

          chunk.blocks[_idx(lx, y, lz)] = placeId;
          if (y + 1 > chunk.maxY){
            chunk.maxY = Math.min(CHH - 1, y + 1);
          }
        }

        const subDepth = Math.floor(baseDepth * Math.sqrt(Math.max(0, 1 - t * t)));
        for (let dy = 1; dy <= subDepth; dy++){
          const y = SEA_LEVEL - dy;
          if (y <= localTop) break;
          const cur = chunk.blocks[_idx(lx, y, lz)];
          if (cur !== waterId) break;
          chunk.blocks[_idx(lx, y, lz)] = packedId;
        }
      }
    }
  }

  /* ============================================================
     花草
     ============================================================ */
  function _plantPlants(chunk, _unused){
    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const topY = chunk.topY;
    const grassId = blockIds.grass;
    const snowId  = blockIds.snow;

    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        const h = topY[z * CS + x];
        if (h <= SEA_LEVEL) continue;

        const wx = bx + x, wz = bz + z;
        const surf = chunk.blocks[_idx(x, h, z)];
        if (surf !== grassId && surf !== snowId) continue;
        if (chunk.blocks[_idx(x, h + 1, z)] !== 0) continue;

        const blend = biomeBlendAt(wx, wz, h);
        const hookBiome = biomeAt(wx, wz, h);
        const biomeId = getBiome(hookBiome) ? hookBiome : blend.primary;

        const bcfg = getBiome(biomeId);
        if (!bcfg || !bcfg.plants.length) continue;

        const bio = fbm(wx * 0.0055, wz * 0.0055, 2, 880 + SEED);
        const k = smoothstep(0.32, 0.68, bio);
        if (k < 0.02) continue;

        for (const p of bcfg.plants){
          const rate = (p.density || 0) * k;
          if (rate <= 0) continue;
          if (hash2i(wx, wz, 891 + SEED + (p.type.length * 7)) > rate) continue;
          const blkId = blockIds[p.type];
          if (!blkId) continue;

          const isDouble = p.type === 'double_grass' || p.type === 'double_fern';
          if (isDouble){
            if (h + 2 >= CHH) continue;
            if (chunk.blocks[_idx(x, h + 2, z)] !== 0) continue;
            chunk.blocks[_idx(x, h + 1, z)] = blkId;
            const topName = p.type === 'double_grass'
              ? 'double_grass_top' : 'double_fern_top';
            if (blockIds[topName]){
              chunk.blocks[_idx(x, h + 2, z)] = blockIds[topName];
            }
          } else {
            chunk.blocks[_idx(x, h + 1, z)] = blkId;
          }
          break;
        }
      }
    }
  }

  /* ============================================================
     甘蔗（水边，参考 MC）
     ============================================================ */
  function _plantSugarCane(chunk){
    const caneId = blockIds.sugar_cane;
    if (!caneId) return;

    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const topY = chunk.topY;
    const blocks = chunk.blocks;
    const waterId = blockIds.water;
    const grassId = blockIds.grass;
    const sandId  = blockIds.sand;
    const dirtId  = blockIds.dirt;

    for (let x = 1; x < CS - 1; x++){
      for (let z = 1; z < CS - 1; z++){
        const h = topY[z * CS + x];
        /* 只在水面附近的水岸 */
        if (h < SEA_LEVEL - 2 || h > SEA_LEVEL + 2) continue;
        if (h + 4 >= CHH) continue;

        const surf = blocks[_idx(x, h, z)];
        if (surf !== grassId && surf !== sandId && surf !== dirtId) continue;
        if (blocks[_idx(x, h + 1, z)] !== 0) continue;

        /* 四邻必须紧挨水面（同层或低一层，兼容略高于水面的河岸） */
        const nearWater =
          blocks[_idx(x + 1, h, z)] === waterId ||
          blocks[_idx(x - 1, h, z)] === waterId ||
          blocks[_idx(x, h, z + 1)] === waterId ||
          blocks[_idx(x, h, z - 1)] === waterId ||
          blocks[_idx(x + 1, h - 1, z)] === waterId ||
          blocks[_idx(x - 1, h - 1, z)] === waterId ||
          blocks[_idx(x, h - 1, z + 1)] === waterId ||
          blocks[_idx(x, h - 1, z - 1)] === waterId;
        if (!nearWater) continue;

        const wx = bx + x, wz = bz + z;
        /* 寒冷水域不长甘蔗 */
        if (params.temperatureAt(wx, h, wz) < 0.28) continue;

        /* 沙岸略稀，草岸成丛 */
        const p = surf === sandId ? 0.10 : 0.20;
        if (hash2i(wx, wz, 6100 + SEED) > p) continue;

        const ch = 1 + Math.floor(hash2i(wx, wz, 6101 + SEED) * 3);
        for (let i = 1; i <= ch; i++){
          if (h + i >= CHH - 1) break;
          if (blocks[_idx(x, h + i, z)] !== 0) break;
          blocks[_idx(x, h + i, z)] = caneId;
        }
      }
    }
  }

  /* ============================================================
     _plantSeagrass（B3 修复）
     ============================================================ */
  function _plantSeagrass(chunk){
    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const topY = chunk.topY;
    const waterId = blockIds.water;

    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        const h = topY[z * CS + x];
        if (h >= SEA_LEVEL - 1) continue;
        const wx = bx + x, wz = bz + z;
        const bed = fbm(wx * 0.014, wz * 0.014, 2, 800 + SEED);
        const density = smoothstep(0.42, 0.72, bed) * 0.55;
        if (density < 0.02) continue;
        if (hash2i(wx, wz, 801 + SEED) > density) continue;

        const i1 = _idx(x, h + 1, z);
        if (chunk.blocks[i1] !== waterId) continue;

        const i0 = _idx(x, h, z);
        const bedId = chunk.blocks[i0];
        if (bedId === 0 || bedId === waterId) continue;

        chunk.blocks[i1] = blockIds.seagrass;

        if (hash2i(wx, wz, 802 + SEED) < 0.25){
          const tallH = 1 + Math.floor(hash2i(wx, wz, 803 + SEED) * 3);
          for (let k = 1; k <= tallH; k++){
            const y = h + 1 + k;
            if (y >= SEA_LEVEL) break;
            const i2 = _idx(x, y, z);
            if (chunk.blocks[i2] !== waterId) break;
            chunk.blocks[i2] = blockIds.kelp;
          }
        }
      }
    }
  }

  /* ============================================================
     _decorate
     ============================================================ */
  function _decorate(chunk, crossWrites){
    if (chunk.decorated) return;
    chunk.decorated = true;

    _placeTemple(chunk, crossWrites);

    if (WORLD_TYPE_V === WORLD_TYPE.FLAT){
      if (hash2i(chunk.cx, chunk.cz, 555) < 0.25){
        const cx0 = chunk.cx * CS + 8, cz0 = chunk.cz * CS + 8;
        const h = Math.floor(heightAt(cx0, cz0));
        if (h + 8 < CHH){
          _plantTree(chunk, crossWrites, 8, h + 1, 8, 'oak', cx0, cz0);
        }
      }
      chunk.maxY = Math.min(CHH - 1, chunk.maxY + 12);
      return;
    }

    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const topY = chunk.topY;

    for (let x = 1; x < CS - 1; x++){
      for (let z = 1; z < CS - 1; z++){
        const wx = bx + x, wz = bz + z;
        const h = topY[z * CS + x];
        if (h <= SEA_LEVEL) continue;

        const surfaceId = chunk.blocks[_idx(x, h, z)];
        if (surfaceId !== blockIds.grass &&
            surfaceId !== blockIds.snow  &&
            surfaceId !== blockIds.sand) continue;

        const blend = biomeBlendAt(wx, wz, h);
        const hookBiome = biomeAt(wx, wz, h);
        const primaryBiomeId = getBiome(hookBiome) ? hookBiome : blend.primary;
        const bcfg = getBiome(primaryBiomeId); // ★ 主群系（可被 mod 覆盖）
        if (!bcfg) continue;

        const r = hash2i(wx, wz, 777 + SEED);

        /* ---- 树 ---- */
        if (bcfg.treeTypes.length > 0){
          const bcfg1 = getBiome(primaryBiomeId);
          const bcfg2 = getBiome(blend.secondary);

          const d1 = bcfg1 ? (bcfg1.treeDensity || 0) : 0;
          const d2 = bcfg2 ? (bcfg2.treeDensity || 0) : d1;
          const t = smoothstep(0.25, 0.50, blend.mix);
          const treeDensity = d1 * (1 - t) + d2 * t;

          if (treeDensity > 0 && r < treeDensity){
            let treeTypes = bcfg1 && bcfg1.treeTypes.length
              ? bcfg1.treeTypes
              : bcfg.treeTypes;

            if (bcfg2 && bcfg2.treeTypes.length > 0 && blend.mix > 0.35){
              const z1 = fbm(wx * 0.0025, wz * 0.0025, 2, SEED + 9001);
              const z2 = fbm(wx * 0.0080, wz * 0.0080, 2, SEED + 9002);
              const zone = z1 * 0.6 + z2 * 0.4;
              if (zone < blend.mix * blend.mix){
                treeTypes = bcfg2.treeTypes;
              }
            }

            const ti = Math.floor(hash2i(wx, wz, 779 + SEED) * treeTypes.length);
            const treeType = treeTypes[ti] || 'oak';
            _plantTree(chunk, crossWrites, x, h + 1, z, treeType, wx, wz);
            continue;
          }
        }

        /* ---- 仙人掌 ---- */
        if (bcfg.features.includes('cactus')){
          if (chunk.blocks[_idx(x, h + 1, z)] !== 0) continue;
          if (r < 0.012){
            const ch = 1 + Math.floor(hash2i(wx, wz, 778) * 3);
            for (let i = 0; i < ch; i++){
              if (chunk.blocks[_idx(x, h + 1 + i, z)] !== 0) break;
              chunk.blocks[_idx(x, h + 1 + i, z)] = blockIds.cactus;
            }
          }
          continue;
        }

        /* ---- 花瓣 ---- */
        if (bcfg.features.includes('petals')){
          const p = hash2i(wx, wz, 781 + SEED);
          const thresh = bcfg.name === 'sakura' ? 0.16 : 0.02;
          if (p < thresh){
            if (chunk.blocks[_idx(x, h + 1, z)] === 0){
              chunk.blocks[_idx(x, h + 1, z)] = blockIds.petals;
            }
          }
        }

        /* ---- 雪层（纯温度驱动：越高越冷，温度越低越易积雪） ---- */
        if (blockIds.snow_layer){
          const snowT = params.temperatureAt(wx, h, wz);
          if (snowT < 0.20){
            /* 温度从 0.20 降到 0 时，概率从 0 线性升到 0.85 */
            const snowP = (0.20 - snowT) / 0.20 * 0.85;
            if (hash2i(wx, wz, 791 + SEED) < snowP){
              if (chunk.blocks[_idx(x, h + 1, z)] === 0){
                chunk.blocks[_idx(x, h + 1, z)] = blockIds.snow_layer;
              }
            }
          }
        }
      }
    }

    chunk.maxY = Math.min(CHH - 1, chunk.maxY + 12);

    _placeIcebergs(chunk, crossWrites);

    _plantPlants(chunk);
    _plantSugarCane(chunk);
    _plantSeagrass(chunk);

    /* ★ 失落古城：最后写入，覆盖树木与植被 */
    _placeLostCity(chunk, crossWrites);

    /* ★ mod onDecorate：在内置装饰完成后再追加 */
    if (GEN_HOOK && typeof GEN_HOOK.onDecorate === 'function'){
      try {
        GEN_HOOK.onDecorate(chunk, crossWrites, {
          blockIds,
          cfg: { seed: SEED, SEA_LEVEL, Y_MIN, CHH, CS, COL_H },
          helpers: _makeGenHelpers(chunk),
        });
      } catch(e){
        console.error('[world-gen] mod onDecorate 出错:', e);
      }
    }
  }

  /* ============================================================
     失落古城：丛林中的破损迷宫 + 四座房屋 + 中央广场
     ============================================================ */
  function _cityMat(wx, wz, salt, mossyBias){
    const r = hash2i(wx, wz, SEED + salt);
    if (r < 0.10) return blockIds.cobble;
    if (r < 0.10 + mossyBias) return blockIds.mossy_stone_bricks;
    if (r < 0.14 + mossyBias) return blockIds.mossy_stone;
    return blockIds.stone_bricks;
  }

  function _placeLostCity(chunk, crossWrites){
    const pos = findLostCity();
    if (!pos || chunk.lostCityDone) return;
    chunk.lostCityDone = true;

    const bx0 = chunk.cx * CS, bz0 = chunk.cz * CS;
    const bx1 = bx0 + CS - 1, bz1 = bz0 + CS - 1;
    const cx = pos.x, cz = pos.z, baseY = pos.baseY;
    const R = LOST_CITY_RADIUS;
    if (bx1 < cx - R || bx0 > cx + R || bz1 < cz - R || bz0 > cz + R) return;

    const S = (wx, wy, wz, id) => {
      const lx = wx - bx0, lz = wz - bz0;
      if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return;
      _setGen(chunk, crossWrites, lx, wy, lz, id);
    };

    const x0 = Math.max(bx0, cx - R), x1 = Math.min(bx1, cx + R);
    const z0 = Math.max(bz0, cz - R), z1 = Math.min(bz1, cz + R);

    for (let x = x0; x <= x1; x++){
      for (let z = z0; z <= z1; z++){
        const dx = x - cx, dz = z - cz;
        const adx = Math.abs(dx), adz = Math.abs(dz);

        /* 清空结构空间（树木、花草、山体凸起） */
        for (let y = baseY + 1; y <= baseY + 28; y++) S(x, y, z, 0);

        /* 地面 */
        const fr = hash2i(x, z, SEED + 81);
        let floor = blockIds.stone_bricks;
        if (fr < 0.16) floor = blockIds.cobble;
        else if (fr < 0.36) floor = blockIds.mossy_stone_bricks;
        else if (fr < 0.42) floor = blockIds.mossy_stone;
        S(x, baseY, z, floor);
        for (let d = 1; d <= 3; d++) S(x, baseY - d, z, blockIds.stone);

        /* 外城墙（四个门洞 + 破损顶部） */
        if (isOuterWall(dx, dz)){
          if (hash2i(x, z, SEED + 83) >= 0.12){
            const wh = 4 + Math.floor(hash2i(x, z, SEED + 82) * 5);
            for (let y = baseY + 1; y <= baseY + wh; y++){
              if (y > baseY + 3 && hash2i(x, z, y + SEED + 99) < 0.18) continue;
              S(x, y, z, _cityMat(x, z, 84, 0.28));
            }
          }
          continue;
        }

        /* 中央广场：空旷 + 四根残柱 + 地面碎石 */
        if (isPlaza(dx, dz)){
          if (adx === 7 && adz === 7){
            for (let y = baseY + 1; y <= baseY + 5; y++)
              S(x, y, z, hash2i(x, y, z + SEED) < 0.5
                ? blockIds.mossy_stone_bricks : blockIds.stone_bricks);
            S(x, baseY + 6, z, blockIds.mossy_stone);
          } else if (adx + adz > 2 && hash2i(x, z, SEED + 85) < 0.015){
            S(x, baseY + 1, z, blockIds.cobble);
          }
          continue;
        }

        /* 四座破损房屋 */
        const hi = houseIndexAt(dx, dz);
        if (hi >= 0){
          const ox = LOST_CITY_HOUSES[hi][0];
          const oz = LOST_CITY_HOUSES[hi][1];
          const lx = dx - ox, lz = dz - oz;
          const onWall = Math.abs(lx) === LOST_CITY_HOUSE_R ||
                         Math.abs(lz) === LOST_CITY_HOUSE_R;

          if (onWall){
            let door = false;
            if (ox > 0 && lx === -LOST_CITY_HOUSE_R && Math.abs(lz) <= 1) door = true;
            if (ox < 0 && lx ===  LOST_CITY_HOUSE_R && Math.abs(lz) <= 1) door = true;
            if (oz > 0 && lz === -LOST_CITY_HOUSE_R && Math.abs(lx) <= 1) door = true;
            if (oz < 0 && lz ===  LOST_CITY_HOUSE_R && Math.abs(lx) <= 1) door = true;

            if (!door){
              const wh = 3 + Math.floor(hash2i(x, z, SEED + 86) * 3);
              for (let y = baseY + 1; y <= baseY + wh; y++){
                if (y > baseY + 2 && hash2i(x, z, y + SEED + 87) < 0.22) continue;
                S(x, y, z, _cityMat(x, z, 88, 0.30));
              }
              /* 墙面垂下的藤蔓 */
              if (hash2i(x, z, SEED + 89) < 0.18){
                const vy = baseY + 2 + Math.floor(hash2i(x, z, SEED + 90) * 2);
                for (let k = 0; k < 3; k++){
                  if (hash2i(x, z, SEED + 91 + k) < 0.45) break;
                  S(x, vy - k, z, blockIds.vine);
                }
              }
            }
          }

          /* 残缺屋顶 */
          if (Math.abs(lx) <= LOST_CITY_HOUSE_R &&
              Math.abs(lz) <= LOST_CITY_HOUSE_R &&
              hash2i(x, z, SEED + 92) < 0.45){
            S(x, baseY + 4, z, hash2i(x, z, SEED + 93) < 0.35
              ? blockIds.mossy_stone_bricks : blockIds.stone_bricks);
          }
          continue;
        }

        /* 迷宫墙体：5 格网格，随机缺门形成破损迷宫 */
        if ((adx % 5 === 0 || adz % 5 === 0) &&
            hash2i(x, z, SEED + 94) > 0.34){
          const wh = 2 + Math.floor(hash2i(x, z, SEED + 95) * 3);
          for (let y = baseY + 1; y <= baseY + wh; y++){
            if (y === baseY + wh && hash2i(x, z, y + SEED + 96) < 0.35) continue;
            S(x, y, z, _cityMat(x, z, 97, 0.26));
          }
        } else if (hash2i(x, z, SEED + 98) < 0.012){
          S(x, baseY + 1, z, blockIds.cobble);
        }
      }
    }

    /* 房屋宝箱与床（固定点位，主线程据此填充战利品） */
    for (const c of cityChestPoints(cx, cz, baseY)){
      S(c.x, c.y - 1, c.z, blockIds.mossy_stone_bricks);
      S(c.x, c.y, c.z, blockIds.chest);
    }
    for (const b of cityBedPoints(cx, cz, baseY)){
      S(b.x, b.y, b.z, blockIds.bed);
    }
  }

  /* ============================================================
     genChunkData
     ============================================================ */
  function genChunkData(cx, cz){
    const size = CS * CS * COL_H;
    const blocks = new Uint8Array(size);
    const fluid  = new Uint8Array(size);
    const topY   = new Int16Array(CS * CS);

    const chunk = {
      cx, cz, blocks, fluid, topY,
      minY: CHH, maxY: 0,
      decorated: false, templeDone: false,
    };

    /* ★ mod 生成器完全接管：
       如果 GEN_HOOK.onGenerate 返回 true，跳过所有内置生成。
       mod 自己负责填 chunk.blocks / chunk.fluid / chunk.topY，
       并设置 chunk.minY / chunk.maxY。 */
    let handledByMod = false;
    if (GEN_HOOK && typeof GEN_HOOK.onGenerate === 'function'){
      try {
        const helpers = _makeGenHelpers(chunk);
        handledByMod = !!GEN_HOOK.onGenerate({
          cx, cz, chunk,
          blockIds,
          cfg: { seed: SEED, SEA_LEVEL, Y_MIN, CHH, CS, COL_H },
          helpers,
        });
      } catch(e){
        console.error('[world-gen] mod onGenerate 出错，回退内置生成:', e);
        handledByMod = false;
        /* 清空（避免 mod 写了一半的数据污染内置路径） */
        chunk.blocks.fill(0);
        chunk.fluid.fill(0);
        chunk.topY.fill(0);
        chunk.minY = CHH;
        chunk.maxY = 0;
        chunk.decorated = false;
      }
    }

    if (!handledByMod){
      _genTerrain(chunk);
      carveWorms(chunk, blockIds, { seed: SEED, SEA_LEVEL, Y_MIN, CHH, quickHeightAt });
      carveCanyons(chunk, blockIds, { seed: SEED, SEA_LEVEL, Y_MIN, CHH });
      generateOres(chunk, blockIds, {
        seed: SEED, CHH, Y_MIN, SEA_LEVEL, terrainCeiling,
        UG_BOT, UG_TOP, UG_ENABLED,
      });
      /* ★ 岩石变种：放在矿脉之后，只替换剩余石头 */
      _applyStoneVariants(chunk);
    }

    /* ★ onChunkGen：在内置地形（地形/洞穴/矿脉）之后、植被装饰之前调用，
       用来做“在原版地形上加东西”。完全接管请用 onGenerate。 */
    if (!handledByMod && GEN_HOOK && typeof GEN_HOOK.onChunkGen === 'function'){
      try {
        GEN_HOOK.onChunkGen({
          cx, cz, chunk, blockIds,
          cfg: { seed: SEED, SEA_LEVEL, Y_MIN, CHH, CS, COL_H },
          helpers: _makeGenHelpers(chunk),
        });
      } catch(e){
        console.error('[world-gen] mod onChunkGen 出错:', e);
      }
    }

    const crossWrites = [];
    _decorate(chunk, crossWrites);

    /* ★ 液体补全：mod 的 onGenerate / onChunkGen / onDecorate 如果只写了
       chunk.blocks 而没写 fluid，液位会是 0 —— 流体系统会把它当成枯竭水
       立即排空，更不会主动流动（山顶放水不流下来的根源）。
       这里统一补成「满液位源头」；内置生成的海/湖本来就带液位，不受影响。 */
    for (let i = 0; i < blocks.length; i++){
      const id = blocks[i];
      if (id === 0) continue;
      const blk = BLOCKS[id];
      if (!blk || !blk.liquid) continue;
      if ((fluid[i] & 0x0F) === 0) fluid[i] = 8 | FL_SRC;
    }

    /* ★ 生成染色表 */
    const tintMapGrass = new Uint32Array(CS * CS);
    const tintMapFoliage = new Uint32Array(CS * CS);
    const bx = cx * CS, bz = cz * CS;

    for (let x = 0; x < CS; x++) {
      for (let z = 0; z < CS; z++) {
        const h = topY[z * CS + x];
        const c = getBiomeColors(bx + x, bz + z, h);
        tintMapGrass[z * CS + x] = c.grass;
        tintMapFoliage[z * CS + x] = c.foliage;
      }
    }

    return {
      cx, cz, blocks, fluid, topY,
      minY: chunk.minY, maxY: chunk.maxY, crossWrites,
      tintMapGrass,
      tintMapFoliage,
    };
  }

  /* ★ 给 mod 的 helpers：安全读写本 chunk 内的方块 */
  function _makeGenHelpers(chunk){
    const _idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;
    return {
      setBlock(lx, ly, lz, id){
        if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return false;
        if (ly < Y_MIN || ly >= CHH) return false;
        chunk.blocks[_idx(lx, ly, lz)] = id | 0;
        if (ly < chunk.minY) chunk.minY = ly;
        if (ly + 1 > chunk.maxY) chunk.maxY = Math.min(CHH - 1, ly + 1);
        return true;
      },
      getBlock(lx, ly, lz){
        if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return 0;
        if (ly < Y_MIN || ly >= CHH) return 0;
        return chunk.blocks[_idx(lx, ly, lz)];
      },
      setFluid(lx, ly, lz, level, isSource){
        if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return false;
        if (ly < Y_MIN || ly >= CHH) return false;
        const i = _idx(lx, ly, lz);
        chunk.fluid[i] = (level & 0x0F) | (isSource ? 0x10 : 0);
        return true;
      },
      fillBox(x0, y0, z0, x1, y1, z1, id){
        for (let y = Math.max(Y_MIN, y0); y <= Math.min(CHH - 1, y1); y++)
          for (let z = Math.max(0, z0); z <= Math.min(CS - 1, z1); z++)
            for (let x = Math.max(0, x0); x <= Math.min(CS - 1, x1); x++)
              chunk.blocks[_idx(x, y, z)] = id | 0;
      },
      setTopY(lx, lz, h){
        if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return;
        chunk.topY[lz * CS + lx] = h | 0;
      },
    };
  }

  return {
    heightAt,
    biomeAt,
    biomeBlendAt,
    getBiomeColors,
    terrainModAt,
    findTemple,
    findLostCity,
    genChunkData,
    get cfg(){ return cfg; },
    get density(){ return density; },
    get params(){ return params; },
  };
}