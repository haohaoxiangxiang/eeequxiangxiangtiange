/* ============================================================
   carvers.js —— 地形雕刻与找矿（矿脉 / 地表规则 / 峡谷 / 蠕虫洞）
   ------------------------------------------------------------
★ 合并自 4 个 world/core 文件（合起来约 36KB，都是"往地形里挖东西"的步骤）：
     oregen.js        矿脉分布
     surface-rules.js 地表规则（陡坡/高山/雪线用什么方块）
     canyon-carver.js 峡谷雕刻
     worm-carver.js   蠕虫洞（3D 噪声隧道，替代老的 cave.js）
   调用顺序由 world-gen.js 决定，这里只是把实现放一起。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import { CS } from './../../core/engine-core.js';
import { fbm3, smoothstep } from './../../core/runtime.js';
import { getBiome } from './../world-core.js';
import { hash2i, fbm, clamp } from './../../core/runtime.js';


/* =================================================================
   oregen.js
   ================================================================= */
/* ============================================================
   oregen.js —— 矿脉生成（纯计算，无副作用）
   ------------------------------------------------------------
   ★ 本轮优化（A5）：
     · 删除 placeVein 里的 visited Set
     · 依赖 blocks[_idx] !== stoneId 判定重复（挖过就变 oreId）
     · 省掉矿脉生成时所有字符串分配 + Set 哈希
   ============================================================ */


const ORE_SPECS = [
  { block: 'coal_ore',    fMin: 0.05, fBest: 0.42, fMax: 0.80, minSize: 4, maxSize: 17, baseVeins: 12, seed: 1001 },
  { block: 'copper_ore',  fMin: 0.04, fBest: 0.32, fMax: 0.72, minSize: 4, maxSize: 14, baseVeins: 10, seed: 1006 },
  { block: 'iron_ore',    fMin: 0.04, fBest: 0.26, fMax: 0.58, minSize: 4, maxSize: 10, baseVeins: 8,  seed: 1002 },
  { block: 'gold_ore',    fMin: 0.03, fBest: 0.13, fMax: 0.26, minSize: 1, maxSize: 6,  baseVeins: 2,  seed: 1003 },
  { block: 'diamond_ore', fMin: 0.02, fBest: 0.07, fMax: 0.16, minSize: 1, maxSize: 6,  baseVeins: 1,  seed: 1004 },
];

function oreConfigs(cfg){
  const ceil = cfg.terrainCeiling
    ? cfg.terrainCeiling()
    : Math.max(cfg.SEA_LEVEL + 30, Math.floor(cfg.CHH * 0.85));

  const span = Math.max(40, ceil - cfg.Y_MIN);
  const veinScale = Math.min(2.0, Math.max(1, Math.sqrt(span / 76)));

  return ORE_SPECS.map(spec => ({
    block: spec.block,
    minY:  cfg.Y_MIN + Math.max(1, Math.floor(spec.fMin  * span)),
    bestY: cfg.Y_MIN + Math.max(2, Math.floor(spec.fBest * span)),
    maxY:  cfg.Y_MIN + Math.max(3, Math.floor(spec.fMax  * span)),
    minSize: spec.minSize,
    maxSize: spec.maxSize,
    veinsPerChunk: Math.min(48, Math.round(spec.baseVeins * veinScale)),
    seed: spec.seed,
  }));
}

function createRNG(seed){
  let s = (seed >>> 0) || 1;
  return function(){
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function triangularRandom(min, max, mode, rng){
  const u = rng();
  const c = (mode - min) / (max - min);
  if (u < c) return min + Math.sqrt(u * (max - min) * (mode - min));
  return max - Math.sqrt((1 - u) * (max - min) * (max - mode));
}

function generateOres(chunk, blockIds, cfg){
  const CHH    = cfg.CHH;
  const Y_MIN  = cfg.Y_MIN;
  const stoneId = blockIds.stone;

  if (!stoneId) return;

  const _idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;

  const blocks = chunk.blocks;
  const specs = oreConfigs(cfg);

  /* ★ 魔法矿石只生成在地心层（UG_BOT ~ UG_TOP），不再跟随地表矿脉分布 */
  if (cfg.UG_ENABLED && blockIds.magic_ore){
    const ugBot = cfg.UG_BOT + 1;
    const ugTop = cfg.UG_TOP - 1;
    if (ugTop - ugBot >= 2){
      specs.push({
        block: 'magic_ore',
        minY: ugBot,
        bestY: ugBot + Math.floor((ugTop - ugBot) * 0.55),
        maxY: ugTop,
        minSize: 1,
        maxSize: 4,
        veinsPerChunk: 10,
        seed: 1005,
      });
    }
  }

  function placeVein(startX, startY, startZ, size, oreId, rng){
    const cells = [];

    function tryPlace(x, y, z){
      if (x < 0 || x >= CS || z < 0 || z >= CS) return false;
      if (y < Y_MIN + 1 || y >= CHH - 1) return false;
      /* ★ A5：删掉 visited，依赖 blocks 判定重复
         第一次挖后 blocks[_idx] 就是 oreId，不再等于 stoneId */
      if (blocks[_idx(x, y, z)] !== stoneId) return false;
      blocks[_idx(x, y, z)] = oreId;
      cells.push([x, y, z]);
      return true;
    }

    if (!tryPlace(startX, startY, startZ)) return;

    const dirs = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
    let attempts = 0;
    const maxAttempts = size * 8;

    while (cells.length < size && attempts < maxAttempts){
      attempts++;
      const base = cells[Math.floor(rng() * cells.length)];
      const dir = dirs[Math.floor(rng() * 6)];
      tryPlace(base[0] + dir[0], base[1] + dir[1], base[2] + dir[2]);
    }
  }

  for (const spec of specs){
    const oreId = blockIds[spec.block];
    if (!oreId) continue;

    for (let i = 0; i < spec.veinsPerChunk; i++){
      const seed = spec.seed * 1000003
                 + chunk.cx * 73856093
                 + chunk.cz * 19349663
                 + i * 83492791;
      const rng = createRNG(seed);

      const y = Math.floor(
        triangularRandom(spec.minY, spec.maxY, spec.bestY, rng)
      );
      if (y < Y_MIN + 1 || y >= CHH - 1) continue;

      const x = Math.floor(rng() * CS);
      const z = Math.floor(rng() * CS);
      const size = Math.floor(
        spec.minSize + rng() * (spec.maxSize - spec.minSize + 1)
      );

      placeVein(x, y, z, size, oreId, rng);
    }
  }
}

/* =================================================================
   surface-rules.js
   ================================================================= */
/* ============================================================
   surface-rules.js —— 地表规则系统
   ------------------------------------------------------------
   ★ 本轮修复：
     · 陡坡表面按群系决定（沙漠=砂岩，恶地=陶瓦，雪原=雪）
     · ALT_STONE_LOW 60 → 100（只有高山才用纯石头）
     · slope 2.0~3.5 是过渡带，用噪声遮蔽
       → 避免"石边 → 悬崖"硬切
   ============================================================ */



const ALT_STONE_LOW    = 100;   // ★ 60 → 100
const ALT_SNOW_LINE    = 130;
const SNOW_LINE_JITTER = 40;

const SLOPE_SOFT = 2.0;         // ★ 新增：过渡带起点
const SLOPE_HARD = 3.5;         // ★ 新增：完全陡坡

function createSurfaceRules(blockIds, cfg){
  const SEA_LEVEL = cfg.SEA_LEVEL;
  const SEED      = cfg.seed | 0;

  /* ★ 陡坡表面按群系决定 */
  function cliffSurfaceFor(biomeName, alt, ID_STONE){
    if (biomeName === 'desert')
      return blockIds.sandstone || blockIds.sand || ID_STONE;
    if (biomeName === 'badlands')
      return blockIds.terracotta
          || blockIds.red_sandstone
          || blockIds.red_sand
          || ID_STONE;
    if (biomeName === 'snow')
      return blockIds.snow || ID_STONE;
    if (biomeName === 'ocean' || biomeName === 'beach')
      return blockIds.sand || ID_STONE;

    /* 森林/平原/其他：高海拔才用石头，否则用草 */
    if (alt > ALT_STONE_LOW)
      return ID_STONE;
    return blockIds.grass || ID_STONE;
  }

  function rulesFor(ctx){
    const { wx, wz, surfaceY, biomeId, isUnderwater, slope } = ctx;

    const alt  = surfaceY - SEA_LEVEL;
    const bcfg = getBiome(biomeId);
    const biomeName = bcfg ? bcfg.name : null;

    const ID_SAND   = blockIds.sand;
    const ID_STONE  = blockIds.stone;
    const ID_DIRT   = blockIds.dirt;
    const ID_SNOW   = blockIds.snow;
    const ID_GRASS  = blockIds.grass;

    /* ① 深海床 */
    if (biomeId === 0 && surfaceY < SEA_LEVEL - 3){
      return mk(ID_SAND, ID_SAND, ID_STONE);
    }

    /* ② 河流水床 */
    if (biomeId === 15){
      return mk(ID_SAND, ID_SAND, ID_STONE);
    }

    /* ③ 雪线 */
    if (!isUnderwater && alt > ALT_STONE_LOW && ID_SNOW){
      const jit = (fbm(wx * 0.003, wz * 0.003, 2, SEED + 600) - 0.5)
                * SNOW_LINE_JITTER * 2;
      if (alt > ALT_SNOW_LINE + jit){
        return mk(ID_SNOW, ID_SNOW, ID_STONE);
      }
    }

    /* ④ 陡坡：slope 2.0~3.5 是过渡带，用噪声遮蔽
       避免"一圈石边围住悬崖" */
    if (!isUnderwater && slope > SLOPE_SOFT){
      /* slope 越高，暴露阈值越低（slope 2.0→0.5，slope 3.5→0） */
      const slopeT = clamp(
        (slope - SLOPE_SOFT) / (SLOPE_HARD - SLOPE_SOFT), 0, 1
      );
      const exposeThreshold = 0.5 - slopeT * 0.5;

      /* 噪声决定这个位置是否"完全暴露" */
      const exposeN = fbm(wx * 0.06, wz * 0.06, 2, SEED + 950);

      if (exposeN > exposeThreshold){
        const cliffSurf = cliffSurfaceFor(biomeName, alt, ID_STONE);
        /* 沙漠/恶地：悬崖整体是砂岩/陶瓦 */
        /* 其他群系：悬崖表面是群系表面，次表面是泥土 */
        const cliffSub = (biomeName === 'desert' || biomeName === 'badlands')
          ? cliffSurf
          : (blockIds.dirt || cliffSurf);
        return mk(cliffSurf, cliffSub, ID_STONE);
      }
    }

    /* ⑤ 群系默认 */
    const surface    = biomeSurface(bcfg, isUnderwater, ID_GRASS, ID_SAND);
    const subsurface = biomeSubsurface(bcfg, isUnderwater, ID_DIRT, ID_SAND);
    return mk(surface, subsurface, ID_STONE);
  }

  function biomeSurface(bcfg, underwater, ID_GRASS, ID_SAND){
    if (!bcfg) return underwater ? ID_SAND : ID_GRASS;
    if (underwater) return blockIds[bcfg.underwater] || ID_SAND;
    return blockIds[bcfg.surface] || ID_GRASS;
  }

  function biomeSubsurface(bcfg, underwater, ID_DIRT, ID_SAND){
    if (!bcfg) return ID_DIRT;
    if (underwater) return blockIds[bcfg.underwater] || ID_SAND;
    return blockIds[bcfg.subsurface] || ID_DIRT;
  }

  function mk(surface, subsurface, deep){
    return { surface, subsurface, deepSubsurface: deep };
  }

  return { rulesFor };
}

/* =================================================================
   canyon-carver.js
   ================================================================= */
/* ============================================================
   canyon-carver.js —— 峡谷雕刻器
   ------------------------------------------------------------
   ★ 本轮修复（B2）：
     · carveCanyons 开头算一次 trueSurface（worm 挖过后的真实地表）
     · carveCanyonPath 用 trueSurface 替代 topY
     · 避免 canyon 用旧地表判断 maxY 导致的错位
   ============================================================ */


function cy_mulberry32(a) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function cy_smoothstep01(a, b, x) {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

/* ============================================================
   参数
   ============================================================ */
const CANYON_CELL     = 128;
const CANYON_PROB     = 0.45;

const LEN_MIN         = 90;
const LEN_MAX         = 140;
const STEP            = 2;

const RADIUS_MIN      = 2.5;
const RADIUS_MAX      = 5.5;

const DEPTH_MIN       = 40;
const DEPTH_MAX       = 70;
const DEPTH_START     = 30;

const PIERCE_CHANCE   = 0.20;
const PIERCE_REL      = 0.30;
const PIERCE_WINDOW   = 0.35;

const SURFACE_KEEP    = 6;
const BOTTOM_KEEP     = 8;

/* ============================================================
   ★ B2：真实地表扫描
   ------------------------------------------------------------
   从 topY 开始向下，找到第一个非空气、非水的方块
   和 worm-carver.js 的 trueSurface 逻辑一致
   ============================================================ */
function computeTrueSurface(chunk, blockIds, Y_MIN, CHH_){
  const { blocks, topY } = chunk;
  const WATER = blockIds.water;
  const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;
  const trueSurface = new Int16Array(CS * CS);

  for (let lz = 0; lz < CS; lz++){
    for (let lx = 0; lx < CS; lx++){
      let y = topY ? topY[lz * CS + lx] : CHH_ - 1;
      while (y > Y_MIN + 1){
        const bid = blocks[idx(lx, y, lz)];
        if (bid !== 0 && bid !== WATER) break;
        y--;
      }
      trueSurface[lz * CS + lx] = y;
    }
  }
  return trueSurface;
}

/* ============================================================
   单 cell 的 canyon 模拟
   ============================================================ */
function simCanyonInCell(seed, gx, gz, SEA_LEVEL, Y_MIN){
  const rng = cy_mulberry32(
    seed + gx * 73856093 + gz * 19349663 + 0xCAFE
  );

  if (rng() > CANYON_PROB) return null;

  const startX = gx * CANYON_CELL + 20 + rng() * (CANYON_CELL - 40);
  const startZ = gz * CANYON_CELL + 20 + rng() * (CANYON_CELL - 40);
  const startY = SEA_LEVEL - DEPTH_START - rng() * 20;

  const lenBlocks = LEN_MIN + rng() * (LEN_MAX - LEN_MIN);
  const steps     = Math.max(20, Math.floor(lenBlocks / STEP));

  const baseRadius = RADIUS_MIN + rng() * (RADIUS_MAX - RADIUS_MIN);
  const targetDepth = DEPTH_MIN + rng() * (DEPTH_MAX - DEPTH_MIN);
  const pierceSurface = rng() < PIERCE_CHANCE;

  let yaw = rng() * Math.PI * 2;
  let smoothYaw = 0;

  const path = [];
  const radii = [];

  let x = startX, y = startY, z = startZ;

  for (let s = 0; s <= steps; s++){
    const t = s / steps;
    path.push({ x, y, z });

    const endFade = cy_smoothstep01(0, 0.08, t)
                  * cy_smoothstep01(0, 0.08, 1 - t);
    const midVar = 0.85 + Math.sin(t * Math.PI * 3.3) * 0.10;
    radii.push(baseRadius * endFade * midVar);

    smoothYaw += ((rng() - 0.5) * 0.25 - smoothYaw) * 0.35;
    yaw += smoothYaw;

    let targetY;
    if (pierceSurface && t > PIERCE_REL && t < PIERCE_REL + PIERCE_WINDOW){
      const edge = Math.sin((t - PIERCE_REL) / PIERCE_WINDOW * Math.PI);
      targetY = SEA_LEVEL + 6 - (1 - edge) * 40;
    } else {
      targetY = startY - targetDepth * t * 0.4;
    }

    const yLowBound = Y_MIN + BOTTOM_KEEP + 6;
    if (targetY < yLowBound) targetY = yLowBound;
    if (targetY > SEA_LEVEL + 4) targetY = SEA_LEVEL + 4;

    y += (targetY - y) * 0.15;

    x += Math.cos(yaw) * STEP;
    z += Math.sin(yaw) * STEP;
  }

  let aabbMinX = Infinity, aabbMaxX = -Infinity;
  let aabbMinZ = Infinity, aabbMaxZ = -Infinity;
  for (const p of path){
    if (p.x < aabbMinX) aabbMinX = p.x;
    if (p.x > aabbMaxX) aabbMaxX = p.x;
    if (p.z < aabbMinZ) aabbMinZ = p.z;
    if (p.z > aabbMaxZ) aabbMaxZ = p.z;
  }
  const PAD = baseRadius * 2;
  aabbMinX -= PAD; aabbMaxX += PAD;
  aabbMinZ -= PAD; aabbMaxZ += PAD;

  return {
    path, radii, baseRadius, pierceSurface,
    aabb: { minX: aabbMinX, maxX: aabbMaxX, minZ: aabbMinZ, maxZ: aabbMaxZ },
  };
}

/* ============================================================
   ★ carveCanyonPath —— 用 trueSurface 替代 topY
   ============================================================ */
function carveCanyonPath(chunk, canyon, blockIds, Y_MIN, SEA_LEVEL, CHH_, trueSurface){
  const { cx, cz, blocks } = chunk;
  const bx = cx * CS, bz = cz * CS;
  const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;

  const diggable = new Set();
  if (blockIds.stone)  diggable.add(blockIds.stone);
  if (blockIds.dirt)   diggable.add(blockIds.dirt);
  if (blockIds.grass)  diggable.add(blockIds.grass);
  if (blockIds.sand)   diggable.add(blockIds.sand);
  if (blockIds.gravel) diggable.add(blockIds.gravel);
  if (blockIds.sandstone) diggable.add(blockIds.sandstone);
  if (blockIds.red_sand)  diggable.add(blockIds.red_sand);
  if (diggable.size === 0) return;

  const { path, radii, pierceSurface } = canyon;

  for (let s = 0; s < path.length; s++){
    const p = path[s];
    const wx = Math.floor(p.x);
    const wy = Math.floor(p.y);
    const wz = Math.floor(p.z);
    const lx = wx - bx, lz = wz - bz;

    const localRadius = radii[s];
    if (localRadius <= 0.4) continue;

    const rSq = localRadius * localRadius;
    const iR = Math.ceil(localRadius) + 1;

    for (let ox = -iR; ox <= iR; ox++){
      for (let oz = -iR; oz <= iR; oz++){
        const tlx = lx + ox;
        const tlz = lz + oz;
        if (tlx < 0 || tlx >= CS || tlz < 0 || tlz >= CS) continue;

        /* ★ B2：用真实地表 */
        const surfY = trueSurface[tlz * CS + tlx];
        const maxY = pierceSurface ? surfY + 1 : surfY - SURFACE_KEEP;

        for (let oy = -iR; oy <= iR; oy++){
          if (ox * ox + oy * oy + oz * oz > rSq) continue;
          const tly = wy + oy;

          if (tly <= Y_MIN + BOTTOM_KEEP) continue;
          if (tly >= CHH_ - 1) continue;
          if (tly > maxY) continue;

          const i = idx(tlx, tly, tlz);
          if (diggable.has(blocks[i])){
            blocks[i] = 0;
            if (tly < chunk.minY) chunk.minY = tly;
          }
        }
      }
    }
  }
}

/* ============================================================
   主入口
   ============================================================ */
function carveCanyons(chunk, blockIds, cfg){
  const { cx, cz } = chunk;
  const { seed, SEA_LEVEL, Y_MIN } = cfg;
  const CHH_ = cfg.CHH;

  if (!CHH_){
    console.warn('[canyon] cfg.CHH 缺失，跳过');
    return;
  }

  const bx = cx * CS, bz = cz * CS;
  const chunkMinX = bx, chunkMaxX = bx + CS;
  const chunkMinZ = bz, chunkMaxZ = bz + CS;

  /* ★ B2：worm 已经挖过，先算真实地表 */
  const trueSurface = computeTrueSurface(chunk, blockIds, Y_MIN, CHH_);

  const RANGE = 2;
  const cellMinX = Math.floor(bx / CANYON_CELL) - RANGE;
  const cellMaxX = Math.floor((bx + CS) / CANYON_CELL) + RANGE;
  const cellMinZ = Math.floor(bz / CANYON_CELL) - RANGE;
  const cellMaxZ = Math.floor((bz + CS) / CANYON_CELL) + RANGE;

  for (let gx = cellMinX; gx <= cellMaxX; gx++){
    for (let gz = cellMinZ; gz <= cellMaxZ; gz++){
      const canyon = simCanyonInCell(seed, gx, gz, SEA_LEVEL, Y_MIN);
      if (!canyon) continue;

      const aabb = canyon.aabb;
      if (aabb.maxX < chunkMinX || aabb.minX > chunkMaxX) continue;
      if (aabb.maxZ < chunkMinZ || aabb.minZ > chunkMaxZ) continue;

      carveCanyonPath(chunk, canyon, blockIds, Y_MIN, SEA_LEVEL, CHH_, trueSurface);
    }
  }
}

/* =================================================================
   worm-carver.js
   ================================================================= */
/* ============================================================
   worm-carver.js —— 蠕虫洞穴（地下 + 入口）
   ------------------------------------------------------------
   ★ 累积改动：
     · 主 worm 起点跟随实际地表高度（quickHeightAt）
       山地从 y=105 出发，平原从 y=50 出发
     · canEmerge 不受浅层预算限制
     · canEmerge 在浅层有向上推力（pitch >= 0.20）
     · carvePath 对 canEmerge 放宽 trueSurface 保护（+2 格）
     · 非 emerge 起点 SEA_LEVEL - 25 以下
     · 非 emerge 分层强制下潜 + 12 步浅层预算
     · 入口蠕虫概率 10%，每 chunk 尝试 2 次
     · 入口条件放宽（海边允许）
     · 入口蠕虫用路点式 + 线段连续挖掘
   ============================================================ */



function wm_mulberry32(a) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}

function wm_smoothstep01(a, b, x){
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

function pitchLimitFor(y, SEA_LEVEL){
  if (y > SEA_LEVEL - 5)  return 0.35;
  if (y > SEA_LEVEL - 40) return 0.40;
  return 0.50;
}

/* ============================================================
   simChunkWorms
   ★ 起点跟随实际地表高度（quickHeightAt）
   ============================================================ */
function simChunkWorms(seed, ncx, ncz, SEA_LEVEL, Y_MIN, quickHeightAt) {
  const rng = wm_mulberry32(seed + ncx * 73856093 + ncz * 19349663);

  if (rng() > 0.65) return [];

  const wormCount = rng() > 0.40 ? 1 : 2;
  const worms = [];

  for (let w = 0; w < wormCount; w++) {
    let x = ncx * CS + rng() * CS;
    let z = ncz * CS + rng() * CS;

    /* ★ 起点 XZ 的实际地表高度 */
    const localSurfY = quickHeightAt
      ? quickHeightAt(Math.floor(x), Math.floor(z))
      : SEA_LEVEL;

    const canEmerge = rng() < 0.30;

    /* ★ 起点基于实际地表，不再固定 SEA_LEVEL */
    const START_TOP = Math.max(
      Y_MIN + 35,
      canEmerge ? localSurfY - 5 : localSurfY - 15
    );
    const START_BOT = Math.max(Y_MIN + 30, START_TOP - 40);
    const span = Math.max(10, START_TOP - START_BOT);
    let y = START_TOP - rng() * span;

    let yaw = rng() * Math.PI * 2;
    let pitch = (rng() - 0.5) * 0.3;
    const maxSteps = 60 + Math.floor(rng() * 50);
    const baseRadius = 2.5 + rng() * 1.0;

    const start = { x, y, z };
    const path = [{ x, y, z }];
    const radiusMuls = [1.0];

    let shallowSteps = 0;
    const MAX_SHALLOW_STEPS = 12;

    for (let s = 0; s < maxSteps; s++) {
      yaw += (rng() - 0.5) * 0.4;
      pitch += (rng() - 0.5) * 0.2;

      const lim = pitchLimitFor(y, SEA_LEVEL);
      pitch = Math.max(-lim, Math.min(lim, pitch));

      if (s < maxSteps * 0.5 && rng() < 0.08) {
        pitch -= 0.20;
        pitch = Math.max(-lim, Math.min(lim, pitch));
      }

      /* ★ 非 emerge：分层强制下潜 */
      if (!canEmerge) {
        if (y > SEA_LEVEL + 5) {
          pitch = Math.min(pitch, -0.40);
        } else if (y > SEA_LEVEL - 10) {
          pitch = Math.min(pitch, -0.20);
        } else if (y > SEA_LEVEL - 25) {
          pitch = Math.min(pitch, -0.08);
        }
      } else {
        /* ★ canEmerge：浅层向上推 */
        if (y > SEA_LEVEL - 15) {
          pitch = Math.max(pitch, 0.20);
        } else if (y > SEA_LEVEL - 30) {
          pitch = Math.max(pitch, 0.08);
        }
      }

      x += Math.cos(yaw) * Math.cos(pitch);
      y += Math.sin(pitch);
      z += Math.sin(yaw) * Math.cos(pitch);

      /* ★ 浅层预算：仅对非 emerge 生效 */
      if (!canEmerge) {
        if (y > SEA_LEVEL - 10) {
          shallowSteps++;
          if (shallowSteps > MAX_SHALLOW_STEPS) break;
        } else {
          shallowSteps = Math.max(0, shallowSteps - 2);
        }
      }

      const swell = fbm3(x * 0.025, y * 0.025, z * 0.025, 2, seed + 998);
      const jitter = fbm3(x * 0.06, y * 0.06, z * 0.06, 1, seed + 999);
      const radiusMul = 1 + (swell - 0.5) * 1.2 + (jitter - 0.5) * 0.5;

      path.push({ x, y, z });
      radiusMuls.push(radiusMul);

      if (s > maxSteps * 0.6) {
        const endN = fbm3(x * 0.03, y * 0.03, z * 0.03, 2, seed + 1000);
        const p = (s - maxSteps * 0.6) / (maxSteps * 0.4);
        const threshold = 0.20 + p * 0.25;
        if (endN < threshold) break;
      }
    }

    let aabbMinX = Infinity, aabbMaxX = -Infinity;
    let aabbMinZ = Infinity, aabbMaxZ = -Infinity;
    for (const p of path) {
      if (p.x < aabbMinX) aabbMinX = p.x;
      if (p.x > aabbMaxX) aabbMaxX = p.x;
      if (p.z < aabbMinZ) aabbMinZ = p.z;
      if (p.z > aabbMaxZ) aabbMaxZ = p.z;
    }
    const PAD = 6;
    aabbMinX -= PAD; aabbMaxX += PAD;
    aabbMinZ -= PAD; aabbMaxZ += PAD;

    worms.push({
      ncx, ncz, w,
      seed, canEmerge,
      start,
      end: path[path.length - 1],
      path,
      radiusMuls,
      baseRadius,
      aabb: { minX: aabbMinX, maxX: aabbMaxX, minZ: aabbMinZ, maxZ: aabbMaxZ },
    });
  }
  return worms;
}

/* ============================================================
   carvePath
   ============================================================ */
function carvePath(blocks, worm, bx, bz, idx, Y_MIN, CHH_, blockIds, trueSurface) {
  const { path, radiusMuls, baseRadius, seed, canEmerge } = worm;
  const total = path.length;
  const START_FADE_STEPS = 4;
  const END_FADE_STEPS = 12;

  const STONE = blockIds.stone;
  const DIRT  = blockIds.dirt;
  const GRASS = blockIds.grass;
  const SAND    = blockIds.sand;
  const GRAVEL  = blockIds.gravel;
  const CLAY    = blockIds.clay;
  const SNOW    = blockIds.snow;

  for (let s = 0; s < total; s++) {
    const p = path[s];
    const wy = Math.floor(p.y);
    const wx = Math.floor(p.x);
    const wz = Math.floor(p.z);
    const lx = wx - bx;
    const lz = wz - bz;

    const startFade = Math.min(1, s / START_FADE_STEPS);
    const remaining = total - s;
    const endFade = remaining >= END_FADE_STEPS
      ? 1.0
      : wm_smoothstep01(0, END_FADE_STEPS, remaining);
    const taper = startFade * endFade;

    const headBulb = Math.exp(-(s * s) / 9) * 0.4;
    const tailBulb = Math.exp(-(remaining * remaining) / 16) * 0.3;

    const taperNoise = 0.7
      + fbm3(p.x * 0.04, p.y * 0.04, p.z * 0.04, 2, seed + 1001) * 0.6;

    const localRadius = baseRadius * radiusMuls[s]
                      * taper * taperNoise
                      * (1 + headBulb + tailBulb);
    if (localRadius <= 0.3) continue;

    const rSq = localRadius * localRadius;
    const iR = Math.ceil(localRadius) + 1;

    for (let ox = -iR; ox <= iR; ox++) {
      for (let oy = -iR; oy <= iR; oy++) {
        for (let oz = -iR; oz <= iR; oz++) {
          if (ox * ox + oy * oy + oz * oz > rSq) continue;
          const tlx = lx + ox;
          const tly = wy + oy;
          const tlz = lz + oz;
          if (tlx < 0 || tlx >= CS || tlz < 0 || tlz >= CS) continue;
          if (tly <= Y_MIN + 10 || tly >= CHH_ - 1) continue;

          const surfY = trueSurface[tlz * CS + tlx];

          /* ★ canEmerge 允许挖到地表以上 2 格 */
          if (canEmerge) {
            if (tly > surfY + 2) continue;
          } else {
            if (tly > surfY) continue;
          }

          const i = idx(tlx, tly, tlz);
          const bid = blocks[i];

          const isStone = (bid === STONE);
          const isDirt  = (bid === DIRT || bid === GRASS);
          const isSoftSurface = (
            bid === SAND || bid === GRAVEL ||
            bid === CLAY || bid === SNOW
          );

          if (isStone || isDirt || isSoftSurface) {
            blocks[i] = 0;
            if (tly < worm.chunkMinY) worm.chunkMinY = tly;
          }
        }
      }
    }
  }
}

/* ============================================================
   连接隧道
   ============================================================ */
function carveTunnel(blocks, from, to, bx, bz, idx, Y_MIN, CHH_, blockIds) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const dz = to.z - from.z;
  const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
  if (dist < 1e-3) return;

  const steps = Math.ceil(dist);
  const radius = 2.0;
  const rSq = radius * radius;
  const iR = Math.ceil(radius) + 1;

  const STONE  = blockIds.stone;
  const DIRT   = blockIds.dirt;
  const GRASS  = blockIds.grass;
  const SAND   = blockIds.sand;
  const GRAVEL = blockIds.gravel;

  for (let s = 0; s <= steps; s++) {
    const t = s / steps;
    const wx = Math.floor(from.x + dx * t);
    const wy = Math.floor(from.y + dy * t);
    const wz = Math.floor(from.z + dz * t);
    const lx = wx - bx;
    const lz = wz - bz;

    for (let ox = -iR; ox <= iR; ox++) {
      for (let oy = -iR; oy <= iR; oy++) {
        for (let oz = -iR; oz <= iR; oz++) {
          if (ox * ox + oy * oy + oz * oz > rSq) continue;
          const tlx = lx + ox;
          const tly = wy + oy;
          const tlz = lz + oz;
          if (tlx < 0 || tlx >= CS || tlz < 0 || tlz >= CS) continue;
          if (tly <= Y_MIN + 10 || tly >= CHH_ - 1) continue;
          const i = idx(tlx, tly, tlz);
          const bid = blocks[i];
          if (bid === STONE || bid === DIRT || bid === GRASS ||
              bid === SAND || bid === GRAVEL) {
            blocks[i] = 0;
          }
        }
      }
    }
  }
}

/* ============================================================
   主入口
   ============================================================ */
function carveWorms(chunk, blockIds, cfg) {
  const { cx, cz, blocks, topY } = chunk;
  const { seed, SEA_LEVEL, Y_MIN, quickHeightAt } = cfg;
  const CHH_ = cfg.CHH;

  if (!CHH_) {
    console.warn('[worm] cfg.CHH 缺失，跳过');
    return;
  }

  const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;
  const bx = cx * CS;
  const bz = cz * CS;

  const WATER = blockIds.water;
  const trueSurface = new Int16Array(CS * CS);
  for (let lz = 0; lz < CS; lz++) {
    for (let lx = 0; lx < CS; lx++) {
      let y = topY ? topY[lz * CS + lx] : CHH_ - 1;
      while (y > Y_MIN + 1) {
        const bid = blocks[idx(lx, y, lz)];
        if (bid !== 0 && bid !== WATER) break;
        y--;
      }
      trueSurface[lz * CS + lx] = y;
    }
  }

  const allWorms = [];
  for (let ndx = -2; ndx <= 2; ndx++) {
    for (let ndz = -2; ndz <= 2; ndz++) {
      const worms = simChunkWorms(
        seed, cx + ndx, cz + ndz,
        SEA_LEVEL, Y_MIN, quickHeightAt
      );
      for (const w of worms) {
        w.chunkMinY = CHH_;
        allWorms.push(w);
      }
    }
  }

  const chunkMinX = bx, chunkMaxX = bx + CS;
  const chunkMinZ = bz, chunkMaxZ = bz + CS;
  for (const w of allWorms) {
    const aabb = w.aabb;
    if (aabb.maxX < chunkMinX || aabb.minX > chunkMaxX) continue;
    if (aabb.maxZ < chunkMinZ || aabb.minZ > chunkMaxZ) continue;
    carvePath(blocks, w, bx, bz, idx, Y_MIN, CHH_, blockIds, trueSurface);
  }

  const CONNECT_DIST = 22;
  for (const w of allWorms) {
    let nearest = null;
    let nearestD2 = CONNECT_DIST * CONNECT_DIST;

    for (const other of allWorms) {
      if (other === w) continue;
      const dx = other.end.x - w.end.x;
      const dy = other.end.y - w.end.y;
      const dz = other.end.z - w.end.z;
      const d2 = dx*dx + dy*dy + dz*dz;
      if (d2 < nearestD2) {
        nearestD2 = d2;
        nearest = other;
      }
    }

    if (nearest) {
      const fx = w.end.x, fz = w.end.z;
      const tx = nearest.end.x, tz = nearest.end.z;
      const minX = Math.min(fx, tx), maxX = Math.max(fx, tx);
      const minZ = Math.min(fz, tz), maxZ = Math.max(fz, tz);
      if (maxX < chunkMinX || minX > chunkMaxX) continue;
      if (maxZ < chunkMinZ || minZ > chunkMaxZ) continue;
      carveTunnel(blocks, w.end, nearest.end, bx, bz, idx, Y_MIN, CHH_, blockIds);
    }
  }

  _carveEntrances(chunk, blockIds, cfg, trueSurface);
}

/* ============================================================
   入口蠕虫（概率 10%，每 chunk 尝试 2 次）
   ============================================================ */
function _carveEntrances(chunk, blockIds, cfg, trueSurface){
  const { seed } = cfg;
  const { cx, cz } = chunk;

  const rng = wm_mulberry32(seed + cx * 73856093 + cz * 19349663 + 0x1E4A);

  const ATTEMPTS = 2;
  for (let attempt = 0; attempt < ATTEMPTS; attempt++) {
    if (rng() > 0.10) continue;
    _tryCarveOneEntrance(chunk, blockIds, cfg, trueSurface, rng);
  }
}

function _tryCarveOneEntrance(chunk, blockIds, cfg, trueSurface, rng){
  const { cx, cz, blocks, topY } = chunk;
  const { seed, SEA_LEVEL, Y_MIN } = cfg;
  const CHH_ = cfg.CHH;

  if (!topY) return;

  const bx = cx * CS;
  const bz = cz * CS;
  const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;

  const endLx = 6 + Math.floor(rng() * (CS - 12));
  const endLz = 6 + Math.floor(rng() * (CS - 12));

  let endSurfY = topY[endLz * CS + endLx];
  let scanY = endSurfY;
  while (scanY > Y_MIN + 20) {
    if (blocks[idx(endLx, scanY, endLz)] !== 0) break;
    scanY--;
  }
  endSurfY = scanY;

  if (endSurfY <= Y_MIN + 20) return;
  if (endSurfY < SEA_LEVEL - 3) return;
  if (endSurfY > CHH_ - 20) return;
  if (endSurfY + 2 >= CHH_ - 1) return;
  if (blocks[idx(endLx, endSurfY + 1, endLz)] !== 0) return;
  if (blocks[idx(endLx, endSurfY + 2, endLz)] !== 0) return;

  const depth = 30 + rng() * 25;
  const angle = rng() * Math.PI * 2;
  const hDist = 2 + rng() * 4;

  const startLx = endLx + Math.cos(angle) * hDist;
  const startLz = endLz + Math.sin(angle) * hDist;
  let startY = endSurfY - depth;

  if (startLx < 3 || startLx >= CS - 3) return;
  if (startLz < 3 || startLz >= CS - 3) return;

  if (startY < Y_MIN + 25) startY = Y_MIN + 25;

  if (blocks[idx(Math.floor(startLx), Math.floor(startY), Math.floor(startLz))] === 0) return;

  const diggable = new Set();
  if (blockIds.stone)  diggable.add(blockIds.stone);
  if (blockIds.dirt)   diggable.add(blockIds.dirt);
  if (blockIds.grass)  diggable.add(blockIds.grass);
  if (blockIds.sand)   diggable.add(blockIds.sand);
  if (blockIds.gravel) diggable.add(blockIds.gravel);
  if (blockIds.clay)   diggable.add(blockIds.clay);
  if (blockIds.snow)   diggable.add(blockIds.snow);
  if (blockIds.ice)    diggable.add(blockIds.ice);
  if (blockIds.packed_ice) diggable.add(blockIds.packed_ice);

  if (diggable.size === 0) return;

  const baseRadius = 2.8 + rng() * 0.6;

  const carveSphere = (cx0, cy0, cz0, radius) => {
    const rSq = radius * radius;
    const iR = Math.ceil(radius) + 1;
    const wx = Math.floor(cx0);
    const wy = Math.floor(cy0);
    const wz = Math.floor(cz0);
    const lx = wx - bx;
    const lz = wz - bz;
    if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return;

    for (let ox = -iR; ox <= iR; ox++) {
      for (let oy = -iR; oy <= iR; oy++) {
        for (let oz = -iR; oz <= iR; oz++) {
          if (ox * ox + oy * oy + oz * oz > rSq) continue;
          const tlx = lx + ox;
          const tly = wy + oy;
          const tlz = lz + oz;
          if (tlx < 0 || tlx >= CS || tlz < 0 || tlz >= CS) continue;
          if (tly <= Y_MIN + 14 || tly >= CHH_ - 1) continue;

          const i = idx(tlx, tly, tlz);
          const bid = blocks[i];

          if (diggable.has(bid)) {
            blocks[i] = 0;
            if (tly < chunk.minY) chunk.minY = tly;

            if (tly + 1 < CHH_ - 1) {
              const aboveI = idx(tlx, tly + 1, tlz);
              const aboveId = blocks[aboveI];
              if (aboveId === blockIds.sand && blockIds.sandstone) {
                blocks[aboveI] = blockIds.sandstone;
              } else if (aboveId === blockIds.gravel && blockIds.stone) {
                blocks[aboveI] = blockIds.stone;
              }
            }
          }
        }
      }
    }
  };

  carveSphere(startLx, startY, startLz, baseRadius * 1.8);

  for (let dy = 0; dy < 15; dy++) {
    const extendY = startY - dy;
    if (extendY < Y_MIN + 15) break;
    const r = baseRadius * (1.1 - dy / 15 * 0.4);
    carveSphere(startLx, extendY, startLz, r);
  }

  const NUM_WAYPOINTS = 8;
  const waypoints = [];
  for (let i = 0; i <= NUM_WAYPOINTS; i++) {
    const t = i / NUM_WAYPOINTS;
    const baseX = startLx + (endLx - startLx) * t;
    const baseY = startY + (endSurfY + 1 - startY) * t;
    const baseZ = startLz + (endLz - startLz) * t;

    const noiseAmp = (i === 0 || i === NUM_WAYPOINTS) ? 0 : 1.2;
    const noiseX = (fbm3(baseX * 0.15, baseY * 0.15, baseZ * 0.15, 2, seed + 4000) - 0.5) * noiseAmp;
    const noiseY = (fbm3(baseX * 0.15, baseY * 0.15, baseZ * 0.15, 2, seed + 4001) - 0.5) * noiseAmp * 0.4;
    const noiseZ = (fbm3(baseX * 0.15, baseY * 0.15, baseZ * 0.15, 2, seed + 4002) - 0.5) * noiseAmp;

    waypoints.push({
      x: baseX + noiseX,
      y: baseY + noiseY,
      z: baseZ + noiseZ,
    });
  }

  for (let i = 0; i < waypoints.length - 1; i++) {
    const p1 = waypoints[i];
    const p2 = waypoints[i + 1];
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const dz = p2.z - p1.z;
    const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
    const steps = Math.max(1, Math.ceil(dist / 0.4));

    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const cx0 = p1.x + dx * t;
      const cy0 = p1.y + dy * t;
      const cz0 = p1.z + dz * t;

      const globalT = (i + t) / (waypoints.length - 1);
      let radiusMul = 1.0;
      if (globalT < 0.15) {
        radiusMul = 0.7 + globalT / 0.15 * 0.3;
      } else if (globalT > 0.85) {
        radiusMul = 1.0 + (globalT - 0.85) / 0.15 * 0.5;
      }

      carveSphere(cx0, cy0, cz0, baseRadius * radiusMul);
    }
  }
}

/* =================================================================
   re-export
   ================================================================= */
export {
  generateOres, createSurfaceRules, carveCanyons, carveWorms
};
