/* ============================================================
   lost-city.js —— 失落古城的确定性布局（主线程与 Worker 共用）
   ------------------------------------------------------------
   只做纯数学/坐标推导，不碰 DOM、不写方块。
   世界生成按区块裁剪写入；主线程用它定位宝箱、床与 Boss。
   ============================================================ */

import { hash2i } from '../../core/runtime.js';

export const LOST_CITY_RADIUS = 26;   // 外城墙半宽
export const LOST_CITY_WALL_H = 8;    // 标准墙高
export const LOST_CITY_PLAZA = 9;     // 中央广场半宽

/* 四座破损房屋中心相对偏移 */
export const LOST_CITY_HOUSES = [
  [-16, -16], [16, -16], [16, 16], [-16, 16],
];

/* 单座房屋半宽（9x9，从 -4..4） */
export const LOST_CITY_HOUSE_R = 4;

/* ============================================================
   选址：从世界原点向外找一块丛林高地
   ============================================================ */
export function findLostCity(seed, seaLevel, heightAt, biomeAt, getBiome){
  for (let ring = 144; ring <= 760; ring += 48){
    const count = Math.max(12, Math.round(ring / 24));
    const phase = hash2i(ring, 7, seed + 9311) * Math.PI * 2;
    for (let i = 0; i < count; i++){
      const ang = phase + (i / count) * Math.PI * 2;
      const x = Math.round(Math.cos(ang) * ring);
      const z = Math.round(Math.sin(ang) * ring);
      const h = Math.floor(heightAt(x, z));
      if (!(h > seaLevel + 4)) continue;
      const b = getBiome(biomeAt(x, z, h));
      if (!b || b.name !== 'jungle') continue;
      return { x, z, baseY: h };
    }
  }
  return null;
}

/* ============================================================
   布局判定（给世界生成用）
   ============================================================ */
export function houseIndexAt(dx, dz){
  for (let i = 0; i < LOST_CITY_HOUSES.length; i++){
    const ox = LOST_CITY_HOUSES[i][0];
    const oz = LOST_CITY_HOUSES[i][1];
    if (Math.abs(dx - ox) <= LOST_CITY_HOUSE_R &&
        Math.abs(dz - oz) <= LOST_CITY_HOUSE_R) return i;
  }
  return -1;
}

export function isPlaza(dx, dz){
  return Math.abs(dx) <= LOST_CITY_PLAZA && Math.abs(dz) <= LOST_CITY_PLAZA;
}

/* 外城墙：留四个门洞 */
export function isOuterWall(dx, dz){
  const ring = Math.abs(dx) === LOST_CITY_RADIUS || Math.abs(dz) === LOST_CITY_RADIUS;
  if (!ring) return false;
  if (Math.abs(dx) <= 2 && Math.abs(dz) === LOST_CITY_RADIUS) return false;
  if (Math.abs(dz) <= 2 && Math.abs(dx) === LOST_CITY_RADIUS) return false;
  return true;
}

/* ============================================================
   固定点位：房屋宝箱 / 床 / Boss 中心
   ============================================================ */
export function cityChestPoints(cx, cz, baseY){
  const out = [];
  for (const [ox, oz] of LOST_CITY_HOUSES){
    out.push({ x: cx + ox + 2, y: baseY + 1, z: cz + oz + 2, kind: 'house' });
  }
  return out;
}

export function cityBedPoints(cx, cz, baseY){
  const out = [];
  for (const [ox, oz] of LOST_CITY_HOUSES){
    out.push({ x: cx + ox - 2, y: baseY + 1, z: cz + oz - 1 });
  }
  return out;
}

export function cityBossPoint(cx, cz, baseY){
  return { x: cx, y: baseY + 1, z: cz };
}
