/* ============================================================
   mesh-builder.js —— 区块网格几何构建（纯计算）
   ------------------------------------------------------------
   · 贪心网格（侧面 + 顶底面）+ AO
   · 十字草、楼梯、液体、树叶、自发光、透明分组
   · 群系染色：tintMapGrass / tintMapFoliage（0xRRGGBB，索引 z*CS+x）
   · 出口 buildChunkGeometry 返回【打包格式】：
       { O|E|T|L|C: { vbuf, ibuf, vcount, icount } }
     顶点交织步长 15 = 位置(3) 法线(3) 颜色(3) UV(2) uvRect(4)
     与 chunk.js 的 _mkFromPacked / terrain-worker.js 的 transfer 对齐
   ------------------------------------------------------------
   ★ 2025-10-28 恢复：原文件曾被 main.js 的内容覆盖（两份 .bak 同样是
     main.js 副本），导致 chunk.js / terrain-worker.js 导入
     buildChunkGeometry 失败，整个 ES 模块图链接中断、main.js 从未执行
     —— 表现就是"卡在开始界面、点什么都没反应"。
     本文件在 10-05 版本基础上恢复，并按当前调用方的约定改成打包输出。

   不 import：textures / blocks / render / THREE
   所有外部依赖从 input 参数来。
   ============================================================ */

import { CS } from './../../core/engine-core.js';

const CROSS_NY = 0.62;
const FLUID_MAX_LV = 8;

let _curSky = null;
let _curExtSky = null;
let _curExtBlock = null;
let _curMinY = 0;
let _curMaxY = 0;
let _curBlock = null;
let _curYMin = 0;
let _curCHH = 400;
let _curBx = 0;
let _curBz = 0;

/* 跨 chunk 查询：由 chunk.js 注入 getWorldLightFn */
let _getWorldLight = null;
export function setMeshLightResolver(fn){
  _getWorldLight = fn;
}

/* 面外侧采样：返回 0-15 的光照 */
function _faceLight(lx, y, lz, nx, ny, nz){
  if (ny >= _curCHH) return 15;
  if (ny < _curYMin) return 0;

  /* 如果落在带边框的数组范围内，直接查 (包含了跨区块的数据) */
  if (_curExtSky && nx >= -1 && nx <= CS && nz >= -1 && nz <= CS && ny >= _curMinY - 1 && ny <= _curMaxY + 1){
    const CS2 = CS + 2;
    const i = (((ny - _curMinY + 1) * CS2) + (nz + 1)) * CS2 + (nx + 1);
    const s = _curExtSky[i] || 0;
    const b = _curExtBlock ? (_curExtBlock[i] || 0) : 0;
    return s > b ? s : b;
  }

  /* 极端越界情况，直接返回 15 (天空) */
  return 15;
}

/* 光照等级 → 顶点亮度。
   ★ 下限从 0.05 降到 0.012：0.05 是**线性**值，经 sRGB 输出后约等于
   24% 的显示亮度 —— 这就是"白天进洞一片中灰、光源毫无意义"的原因。
   0.012 线性 ≈ 6% 显示亮度，才是"不放火把就是黑的"。
   顶端仍归一化到 1.0（15 级光照不变），所以野外亮度不受影响。
   注意：这只影响烘焙进顶点色的**静态**光照；火把这类动态光走的是
   着色器里独立的"未烘焙反照率"通道，不会被这个下限压暗。 */
function _lightBright(lv){
  if (lv <= 0) return 0.012;
  return 0.012 + Math.pow(lv / 15, 1.3) * 0.988;
}

export const FACES = [
  { n: [1,0,0], verts: [
      {p:[1,0,0],uv:[0,0],a:[1,-1,0],b:[1,0,-1]},
      {p:[1,1,0],uv:[0,1],a:[1,1,0], b:[1,0,-1]},
      {p:[1,1,1],uv:[1,1],a:[1,1,0], b:[1,0,1]},
      {p:[1,0,1],uv:[1,0],a:[1,-1,0],b:[1,0,1]}]},
  { n: [-1,0,0], verts: [
      {p:[0,0,1],uv:[0,0],a:[-1,-1,0],b:[-1,0,1]},
      {p:[0,1,1],uv:[0,1],a:[-1,1,0], b:[-1,0,1]},
      {p:[0,1,0],uv:[1,1],a:[-1,1,0], b:[-1,0,-1]},
      {p:[0,0,0],uv:[1,0],a:[-1,-1,0],b:[-1,0,-1]}]},
  { n: [0,1,0], verts: [
      {p:[0,1,1],uv:[0,0],a:[-1,1,0],b:[0,1,1]},
      {p:[1,1,1],uv:[1,0],a:[1,1,0], b:[0,1,1]},
      {p:[1,1,0],uv:[1,1],a:[1,1,0], b:[0,1,-1]},
      {p:[0,1,0],uv:[0,1],a:[-1,1,0],b:[0,1,-1]}]},
  { n: [0,-1,0], verts: [
      {p:[0,0,0],uv:[0,0],a:[-1,-1,0],b:[0,-1,-1]},
      {p:[1,0,0],uv:[1,0],a:[1,-1,0], b:[0,-1,-1]},
      {p:[1,0,1],uv:[1,1],a:[1,-1,0], b:[0,-1,1]},
      {p:[0,0,1],uv:[0,1],a:[-1,-1,0],b:[0,-1,1]}]},
  { n: [0,0,1], verts: [
      {p:[0,0,1],uv:[0,0],a:[-1,0,1],b:[0,-1,1]},
      {p:[1,0,1],uv:[1,0],a:[1,0,1], b:[0,-1,1]},
      {p:[1,1,1],uv:[1,1],a:[1,0,1], b:[0,1,1]},
      {p:[0,1,1],uv:[0,1],a:[-1,0,1],b:[0,1,1]}]},
  { n: [0,0,-1], verts: [
      {p:[1,0,0],uv:[0,0],a:[1,0,-1], b:[0,-1,-1]},
      {p:[0,0,0],uv:[1,0],a:[-1,0,-1],b:[0,-1,-1]},
      {p:[0,1,0],uv:[1,1],a:[-1,0,-1],b:[0,1,-1]},
      {p:[1,1,0],uv:[0,1],a:[1,0,-1], b:[0,1,-1]}]}
];

export function emptyGroup(){
  return { p: [], n: [], c: [], b: [], u: [], r: [], i: [] };
}

/* ============================================================
   ★ 打包：列式数组 → worker / _mkFromPacked 需要的交织格式
   步长 16 = 位置(3) 法线(3) 颜色(3) UV(2) uvRect(4) 方块光(1)
   最后一路 aBlock 是方块光亮度，用于夜里/洞穴里给火把、荧石
   周围补足亮度：场景光是天光驱动会随昼夜变暗，方块光必须独立。
   ============================================================ */
export const PACKED_STRIDE = 16;

export function packGroup(g){
  if (!g) return null;
  const vcount = g.p.length / 3;
  if (!vcount) return null;

  const vbuf = new Float32Array(vcount * PACKED_STRIDE);
  for (let i = 0; i < vcount; i++){
    const o = i * PACKED_STRIDE, p3 = i * 3, u2 = i * 2, r4 = i * 4;
    vbuf[o     ] = g.p[p3];      vbuf[o +  1] = g.p[p3 + 1];  vbuf[o +  2] = g.p[p3 + 2];
    vbuf[o +  3] = g.n[p3];      vbuf[o +  4] = g.n[p3 + 1];  vbuf[o +  5] = g.n[p3 + 2];
    vbuf[o +  6] = g.c[p3];      vbuf[o +  7] = g.c[p3 + 1];  vbuf[o +  8] = g.c[p3 + 2];
    vbuf[o +  9] = g.u[u2];      vbuf[o + 10] = g.u[u2 + 1];
    vbuf[o + 11] = g.r[r4];      vbuf[o + 12] = g.r[r4 + 1];
    vbuf[o + 13] = g.r[r4 + 2];  vbuf[o + 14] = g.r[r4 + 3];
    vbuf[o + 15] = g.b ? (g.b[i] || 0) : 0;
  }
  return { vbuf, ibuf: new Uint32Array(g.i), vcount, icount: g.i.length };
}

/* 方块光（0-15）→ 顶点亮度（0-1）。0 保持 0，避免黑暗处被补亮。 */
function _blockBright(lv){
  if (!lv || lv <= 0) return 0;
  return Math.pow(lv / 15, 1.25);
}

/* 面外侧方块光，供 pushQuad / pushCross 这类只拿世界坐标的路径用 */
function _blockBrightWorld(wx, wy, wz){
  if (!_curExtBlock) return 0;
  const lx = Math.floor(wx) - _curBx;
  const lz = Math.floor(wz) - _curBz;
  const y = Math.floor(wy);
  if (lx < -1 || lx > CS || lz < -1 || lz > CS) return 0;
  if (y < _curMinY - 1 || y > _curMaxY + 1) return 0;
  const CS2 = CS + 2;
  const i = (((y - _curMinY + 1) * CS2) + (lz + 1)) * CS2 + (lx + 1);
  return _blockBright(_curExtBlock[i] || 0);
}

export function pushQuad(target, pts, n, uvR, bright, tint){
  const start = target.p.length / 3;
  const uvs = [[0,0],[1,0],[1,1],[0,1]];
  const uvW = uvR.u1 - uvR.u0, uvH = uvR.v1 - uvR.v0;
  const cx = (pts[0][0] + pts[1][0] + pts[2][0] + pts[3][0]) * 0.25;
  const cy = (pts[0][1] + pts[1][1] + pts[2][1] + pts[3][1]) * 0.25;
  const cz = (pts[0][2] + pts[1][2] + pts[2][2] + pts[3][2]) * 0.25;
  const bl = _blockBrightWorld(cx + n[0] * 0.5, cy + n[1] * 0.5, cz + n[2] * 0.5);
  for (let vi = 0; vi < 4; vi++){
    target.p.push(pts[vi][0], pts[vi][1], pts[vi][2]);
    target.n.push(n[0], n[1], n[2]);
    target.u.push(uvs[vi][0], uvs[vi][1]);
    if (tint){
      target.c.push(bright * tint[0], bright * tint[1], bright * tint[2]);
    } else {
      target.c.push(bright, bright, bright);
    }
    target.b.push(bl);
    target.r.push(uvR.u0, uvR.v0, uvW, uvH);
  }
  target.i.push(start, start + 1, start + 2, start, start + 2, start + 3);
}

/* 从图集 UV 矩形中按比例取子区域。
   台阶/半砖的每个面只应取贴图对应的一半，而不是把整张贴图压进半个面。 */
export function subUvRect(r, u0, v0, u1, v1){
  const w = r.u1 - r.u0, h = r.v1 - r.v0;
  return {
    u0: r.u0 + w * u0, u1: r.u0 + w * u1,
    v0: r.v0 + h * v0, v1: r.v0 + h * v1,
  };
}

/* 植物用的稳定位置哈希（不依赖外部模块） */
function _crossHash(x, z, seed){
  let n = Math.imul(x + 374761393, 668265263)
        ^ Math.imul(z + 1274126177, 374761393)
        ^ Math.imul(seed + 1, 2246822519);
  n = Math.imul(n ^ (n >>> 13), 2246822519);
  n = Math.imul(n ^ (n >>> 17), 3266489917);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

export function pushCross(target, wx, y, wz, uvR, blk, tint){
  const h = blk.heightRatio || 1;
  const isDouble = blk.name && blk.name.indexOf('double_') === 0;
  const isKelp = blk.name === 'kelp';
  /* 每株植物有自己的高度/位置微差（海带除外，避免茎断开）：
     同位置的上下半株用同一个哈希，所以双格高植物接缝不会错位。 */
  let hMul = 1, ox = 0, oz = 0;
  if (!isKelp){
    ox = (_crossHash(wx, wz, 0x51ed) - 0.5) * 0.22;
    oz = (_crossHash(wx, wz, 0x7a11) - 0.5) * 0.22;
    if (!isDouble) hMul = 0.84 + _crossHash(wx, wz, 0x2f3d) * 0.30;
  }
  const y0 = y, y1 = y + h * hMul;
  const A = 0.146;
  const faces = [
    [[A, A], [1 - A, 1 - A]],
    [[1 - A, A], [A, 1 - A]]
  ];
  const uvW = uvR.u1 - uvR.u0, uvH = uvR.v1 - uvR.v0;
  for (const [[ax, az], [bx, bz]] of faces){
    let nx = bz - az, nz = -(bx - ax);
    const nl = Math.hypot(nx, nz) || 1;
    nx /= nl; nz /= nl;

    const quad = [
      [ax, y0, az], [bx, y0, bz], [bx, y1, bz], [ax, y1, az]
    ];
    for (const flip of [false, true]){
      const start = target.p.length / 3;
      const order = flip ? [1, 0, 3, 2] : [0, 1, 2, 3];
      for (const vi of order){
        const v = quad[vi];
        target.p.push(wx + ox + v[0], v[1], wz + oz + v[2]);
        const s = flip ? -1 : 1;
        target.n.push(nx * s * (1 - CROSS_NY), CROSS_NY, nz * s * (1 - CROSS_NY));
        const uu = (vi === 0 || vi === 3) ? 0 : 1;
        const vv = (vi >= 2) ? 1 : 0;
        target.u.push(uu, vv);
        if (tint) target.c.push(tint[0], tint[1], tint[2]);
        else target.c.push(1, 1, 1);
        target.b.push(_blockBrightWorld(wx + ox + v[0], v[1], wz + oz + v[2]));
        target.r.push(uvR.u0, uvR.v0, uvW, uvH);
      }
      target.i.push(start, start + 1, start + 2, start, start + 2, start + 3);
    }
  }
}

export function pushStair(target, wx, y, wz, uvRectTable, blk, opaqueAt){
  const d = blk.stairDir | 0;
  const t = blk.tiles;
  const side = uvRectTable[t[0]], top = uvRectTable[t[2]], bot = uvRectTable[t[3]];

  /* 上层台阶占的半格（和 stairDir 的方向约定保持一致）
     d=0：上层在 -Z 半格，踢面朝 +Z；d=2 相反；d=1 / d=3 沿 X 轴。 */
  const up = [
    { x0: 0,   x1: 1,   z0: 0,   z1: 0.5 },
    { x0: 0.5, x1: 1,   z0: 0,   z1: 1   },
    { x0: 0,   x1: 1,   z0: 0.5, z1: 1   },
    { x0: 0,   x1: 0.5, z0: 0,   z1: 1   }
  ][d] || { x0: 0, x1: 1, z0: 0, z1: 0.5 };

  const X0 = wx + up.x0, X1 = wx + up.x1;
  const Z0 = wz + up.z0, Z1 = wz + up.z1;
  const YB = y, YM = y + 0.5, YT = y + 1;

  const solid = (nx, ny, nz) => (opaqueAt ? opaqueAt(nx, ny, nz) : 0);
  const shZ = 0.92, shX = 0.874, shUp = 0.9;

  /* ★ 台阶的每个面只有半格高，只取贴图对应的一半：
     下层用下半张、上层用上半张，木纹/石纹才是连续的，
     否则整张贴图被压进半格，纹理密度翻倍，看起来就像一块块木板拼的。 */
  const sideLow  = subUvRect(side, 0, 0,   1, 0.5);
  const sideHigh = subUvRect(side, 0, 0.5, 1, 1);
  const topUp =
      up.x0 === 0.5 ? subUvRect(top, 0.5, 0,   1,   1)     /* 上层在 +X */
    : up.x1 === 0.5 ? subUvRect(top, 0,   0,   0.5, 1)     /* 上层在 -X */
    : up.z1 === 0.5 ? subUvRect(top, 0,   0.5, 1,   1)     /* 上层在 -Z */
                    : subUvRect(top, 0,   0,   1,   0.5);  /* 上层在 +Z */
  const topLow =
      up.x0 === 0.5 ? subUvRect(top, 0,   0,   0.5, 1)
    : up.x1 === 0.5 ? subUvRect(top, 0.5, 0,   1,   1)
    : up.z1 === 0.5 ? subUvRect(top, 0,   0,   1,   0.5)
                    : subUvRect(top, 0,   0.5, 1,   1);

  /* ---- 下层：整格 1×1 的半高部分 ---- */
  if (!solid(wx, y, wz + 1))
    pushQuad(target, [[wx,YB,wz+1],[wx+1,YB,wz+1],[wx+1,YM,wz+1],[wx,YM,wz+1]], [0,0,1],  sideLow, shZ);
  if (!solid(wx, y, wz - 1))
    pushQuad(target, [[wx+1,YB,wz],[wx,YB,wz],[wx,YM,wz],[wx+1,YM,wz]],       [0,0,-1], sideLow, shZ);
  if (!solid(wx + 1, y, wz))
    pushQuad(target, [[wx+1,YB,wz+1],[wx+1,YB,wz],[wx+1,YM,wz],[wx+1,YM,wz+1]], [1,0,0],  sideLow, shX);
  if (!solid(wx - 1, y, wz))
    pushQuad(target, [[wx,YB,wz],[wx,YB,wz+1],[wx,YM,wz+1],[wx,YM,wz]],       [-1,0,0], sideLow, shX);
  if (!solid(wx, y - 1, wz))
    pushQuad(target, [[wx,YB,wz],[wx+1,YB,wz],[wx+1,YB,wz+1],[wx,YB,wz+1]],   [0,-1,0], bot, 0.7);

  /* 下层露出的踏面（上层台阶补集）—— 必须朝上，否则会透视 */
  if (d === 0){
    pushQuad(target, [[wx,YM,wz+1],[wx+1,YM,wz+1],[wx+1,YM,wz+0.5],[wx,YM,wz+0.5]], [0,1,0], topLow, 1);
  } else if (d === 2){
    pushQuad(target, [[wx,YM,wz+0.5],[wx+1,YM,wz+0.5],[wx+1,YM,wz],[wx,YM,wz]],     [0,1,0], topLow, 1);
  } else if (d === 1){
    pushQuad(target, [[wx,YM,wz+1],[wx+0.5,YM,wz+1],[wx+0.5,YM,wz],[wx,YM,wz]],     [0,1,0], topLow, 1);
  } else {
    pushQuad(target, [[wx+0.5,YM,wz+1],[wx+1,YM,wz+1],[wx+1,YM,wz],[wx+0.5,YM,wz]], [0,1,0], topLow, 1);
  }

  /* ---- 上层：半格外露的三个侧面 + 内侧踢面 ---- */
  if (d === 0){
    if (!solid(wx, y, wz - 1))
      pushQuad(target, [[wx+1,YM,wz],[wx,YM,wz],[wx,YT,wz],[wx+1,YT,wz]], [0,0,-1], sideHigh, shUp);
    if (!solid(wx - 1, y, wz))
      pushQuad(target, [[wx,YM,Z0],[wx,YM,Z1],[wx,YT,Z1],[wx,YT,Z0]], [-1,0,0], sideHigh, shUp);
    if (!solid(wx + 1, y, wz))
      pushQuad(target, [[wx+1,YM,Z1],[wx+1,YM,Z0],[wx+1,YT,Z0],[wx+1,YT,Z1]], [1,0,0], sideHigh, shUp);
    /* 踢面朝 +Z */
    pushQuad(target, [[wx,YM,Z1],[wx+1,YM,Z1],[wx+1,YT,Z1],[wx,YT,Z1]], [0,0,1], sideHigh, shUp);
  } else if (d === 2){
    if (!solid(wx, y, wz + 1))
      pushQuad(target, [[wx,YM,wz+1],[wx+1,YM,wz+1],[wx+1,YT,wz+1],[wx,YT,wz+1]], [0,0,1], sideHigh, shUp);
    if (!solid(wx - 1, y, wz))
      pushQuad(target, [[wx,YM,Z0],[wx,YM,Z1],[wx,YT,Z1],[wx,YT,Z0]], [-1,0,0], sideHigh, shUp);
    if (!solid(wx + 1, y, wz))
      pushQuad(target, [[wx+1,YM,Z1],[wx+1,YM,Z0],[wx+1,YT,Z0],[wx+1,YT,Z1]], [1,0,0], sideHigh, shUp);
    /* 踢面朝 -Z */
    pushQuad(target, [[wx+1,YM,Z0],[wx,YM,Z0],[wx,YT,Z0],[wx+1,YT,Z0]], [0,0,-1], sideHigh, shUp);
  } else if (d === 1){
    if (!solid(wx + 1, y, wz))
      pushQuad(target, [[wx+1,YM,wz+1],[wx+1,YM,wz],[wx+1,YT,wz],[wx+1,YT,wz+1]], [1,0,0], sideHigh, shUp);
    if (!solid(wx, y, wz - 1))
      pushQuad(target, [[X1,YM,wz],[X0,YM,wz],[X0,YT,wz],[X1,YT,wz]], [0,0,-1], sideHigh, shUp);
    if (!solid(wx, y, wz + 1))
      pushQuad(target, [[X0,YM,wz+1],[X1,YM,wz+1],[X1,YT,wz+1],[X0,YT,wz+1]], [0,0,1], sideHigh, shUp);
    /* 踢面朝 -X */
    pushQuad(target, [[X0,YM,wz],[X0,YM,wz+1],[X0,YT,wz+1],[X0,YT,wz]], [-1,0,0], sideHigh, shUp);
  } else {
    if (!solid(wx - 1, y, wz))
      pushQuad(target, [[wx,YM,wz],[wx,YM,wz+1],[wx,YT,wz+1],[wx,YT,wz]], [-1,0,0], sideHigh, shUp);
    if (!solid(wx, y, wz - 1))
      pushQuad(target, [[X1,YM,wz],[X0,YM,wz],[X0,YT,wz],[X1,YT,wz]], [0,0,-1], sideHigh, shUp);
    if (!solid(wx, y, wz + 1))
      pushQuad(target, [[X0,YM,wz+1],[X1,YM,wz+1],[X1,YT,wz+1],[X0,YT,wz+1]], [0,0,1], sideHigh, shUp);
    /* 踢面朝 +X */
    pushQuad(target, [[X1,YM,wz+1],[X1,YM,wz],[X1,YT,wz],[X1,YT,wz+1]], [1,0,0], sideHigh, shUp);
  }

  /* 上层顶面（朝上） */
  if (!solid(wx, y + 1, wz))
    pushQuad(target, [[X0,YT,Z1],[X1,YT,Z1],[X1,YT,Z0],[X0,YT,Z0]], [0,1,0], topUp, 1);
}

function aoEqual(a, b){
  return a[0] === b[0] && a[1] === b[1] && a[2] === b[2] && a[3] === b[3];
}
function aoSimilar(a, b){
  return Math.abs(a[0]-b[0]) <= 1
      && Math.abs(a[1]-b[1]) <= 1
      && Math.abs(a[2]-b[2]) <= 1
      && Math.abs(a[3]-b[3]) <= 1;
}

/* ============================================================
   出口
   ============================================================ */
export function buildChunkGeometry(input){
  const {
    cx, cz, blocks,
    minY: chunkMinY, maxY: chunkMaxY,
    blockTable, uvRectTable,
    leafAlpha, crossCull,
    getBlockAt, getFluidLevel, isLoaded,
    Y_MIN, CHH,
    tintMapGrass, tintMapFoliage,
    tintMapMagic,                          // ★ 魔法粉末动态颜色
    skyLight, blockLight,
    extSkyLight, extBlockLight,
    waterMode,
  } = input;

  const bx = cx * CS, bz = cz * CS;
  
  const maxY = Math.min(CHH - 1, chunkMaxY + 1);
  const minY = chunkMinY != null ? Math.max(Y_MIN, chunkMinY) : Y_MIN;

  _curSky = skyLight || null;
  _curBlock = blockLight || null;
  _curExtSky = extSkyLight || null;
  _curExtBlock = extBlockLight || null;
  _curMinY = minY;
  _curMaxY = maxY;
  _curYMin = Y_MIN;
  _curCHH = CHH;
  _curBx = bx;
  _curBz = bz;

  const O = emptyGroup();
  const E = emptyGroup();
  const T = emptyGroup();
  const L = emptyGroup();
  const C = emptyGroup();

  /* ★ 修复：兼容 _solidTiles / solidTiles */
  function tilesFor(blk){
    if (!blk.isLeaves) return blk.tiles;
    if (leafAlpha) return blk.tiles;
    const solid = blk._solidTiles || blk.solidTiles;
    return solid || blk.tiles;
  }

  function targetFor(blk){
    if (blk.cross)       return C;
    if (blk.isLeaves)    return L;
    if (blk.transparent) return T;
    if (blk.emissive > 0) return E;
    return O;
  }

  /* ★ 群系染色：tintMap 为 Uint32Array(CS*CS)，索引 z*CS+x，值 0xRRGGBB */
  function tintRawAt(blk, wx, wz){
    if (!blk || !blk.tint) return 0;
    let map;
    if (blk.tint === 'grass')        map = tintMapGrass;
    else if (blk.tint === 'foliage') map = tintMapFoliage;
    else if (blk.tint === 'magic')   map = tintMapMagic;
    else return 0;
    if (!map) return 0;
    const lx = wx - bx, lz = wz - bz;
    if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return 0;
    return map[lz * CS + lx] | 0;
  }
  /* 0 = 不染 · 1 = 只染顶面（草方块）· 2 = 六面全染（树叶/十字草） */
  function tintModeFor(blk){
    if (!blk || !blk.tint) return 0;
    if (blk.cross || blk.isLeaves) return 2;
    if (blk.tint === 'foliage') return 2;
    if (blk.tint === 'magic')   return 2;   // ★ 六面全染
    return 1;
  }
  /* ★ sRGB → 线性：顶点色在 Three.js 里是线性空间的，
     hex 颜色 0xRRGGBB 却是 sRGB 的，直接当线性用会被输出编码二次提亮，
     导致染色后偏白偏灰。这里手动做 sRGB 解码。 */
  function srgbToLinear(c){
    return c < 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  }
  function rgbOf(raw){
    if (!raw) return null;
    return [
      srgbToLinear(((raw >> 16) & 255) / 255),
      srgbToLinear(((raw >> 8) & 255) / 255),
      srgbToLinear((raw & 255) / 255)
    ];
  }

  /* ------------------------------------------------------------
     ★ 贪心合并用的"量化染色"
     ------------------------------------------------------------
     群系颜色是逐列连续插值的（biomeBlendAt 的 mix 是浮点），
     所以相邻两格的 tint 几乎永不相等。如果直接拿精确值当合并判据，
     一整片 16×16 的草顶会退化成 256 个独立四边形（实测 1004 顶点，
     理想 30 上下）——几何量直接爆炸 20 倍以上。

     这里把每通道量化到 31 级（步长 8/255）：相邻列只要颜色差小于
     1/32 就能合并，而真实群系边界（差值远大于此）仍会正确断开。
     视觉上 31 级的差异在贴图调制后无法分辨。
     ------------------------------------------------------------ */
  function tintQuantAt(blk, wx, wz){
    const raw = tintRawAt(blk, wx, wz);
    if (!raw) return 0;
    return (((raw >> 19) & 0x1F) << 10) |
           (((raw >> 11) & 0x1F) << 5)  |
            ((raw >>  3) & 0x1F);
  }
  function rgbOfQuant(q){
    if (!q) return null;
    return [
      srgbToLinear(((q >> 10) & 31) / 31),
      srgbToLinear(((q >> 5) & 31) / 31),
      srgbToLinear((q & 31) / 31)
    ];
  }
  function tintForFace(blk, wx, wz, faceIdx){
    const mode = tintModeFor(blk);
    if (!mode) return null;
    if (mode === 1 && faceIdx === 3) return null;
    const raw = tintRawAt(blk, wx, wz);
    if (!raw && blk.tint === 'magic') return rgbOf(0x808088);   // ★ 兜底灰色
    return rgbOf(raw);
  }

  function shouldDraw(self, other){
    if (!other || other.id === 0) return true;
    /* ★ invisible 方块视为空气：不遮挡、不需要剔除 */
    if (other.invisible) return true;
    if (other.occludes) return false;

    if (!leafAlpha && self.isLeaves && other.isLeaves && self.id === other.id){
      return false;
    }
    if (self.id === other.id && self.mergeSame) return false;
    return true;
  }

  function canGreedy(blk){
    if (blk.dynamic) return false;
    if (blk.model) return false;
    if (blk.cross || blk.stair || blk.liquid || blk.heightRatio !== 1) return false;
    if (blk.isLeaves) return !leafAlpha;
    return true;
  }

  const blkAt = (wx, wy, wz) => {
    if (wy < Y_MIN || wy >= CHH) return 0;
    const lx = wx - bx, lz = wz - bz;
    if (lx >= 0 && lx < CS && lz >= 0 && lz < CS){
      return blocks[(((wy - Y_MIN) * CS) + lz) * CS + lx];
    }
    return getBlockAt(wx, wy, wz);
  };

  const waterId = (() => {
    for (let i = 0; i < blockTable.length; i++){
      const b = blockTable[i];
      if (b && b.name === 'water') return b.id;
    }
    return 0;
  })();

  function fluidLvAt(wx, wy, wz, id){
    if (wy < Y_MIN || wy >= CHH) return -1;
    if (blkAt(wx, wy, wz) !== id) return -1;
    const lv = getFluidLevel(wx, wy, wz);
    return lv > 0 ? lv : -1;
  }
  function sameLiquid(bid, id){
    if (bid === id) return true;
    if (id === waterId){
      const b = blockTable[bid];
      if (b && b.waterPlant) return true;
    }
    return false;
  }
  function opaqueAt(wx, wy, wz){
    const i = blkAt(wx, wy, wz);
    if (i === 0) return false;
    const b = blockTable[i];
    return !!(b && b.occludes);
  }
  function cornerHeightAt(vx, vy, vz, id){
    let best = 0;
    for (let dx = -1; dx <= 0; dx++){
      for (let dz = -1; dz <= 0; dz++){
        const lv = fluidLvAt(vx + dx, vy, vz + dz, id);
        if (lv > best) best = lv;
      }
    }
    if (best === 0) return 0.125;
    return Math.max(0.125, best / FLUID_MAX_LV);
  }

  function pushLiquidLocal(target, wx, y, wz, blk){
    const id = blk.id;
    const ch = [
      cornerHeightAt(wx,     y, wz,     id),
      cornerHeightAt(wx + 1, y, wz,     id),
      cornerHeightAt(wx + 1, y, wz + 1, id),
      cornerHeightAt(wx,     y, wz + 1, id),
    ];
    const uvSide = uvRectTable[blk.tiles[0]];
    const uvTop  = uvRectTable[blk.tiles[2]];
    const uvBot  = uvRectTable[blk.tiles[3]];

    if (isLoaded(wx, y + 1, wz)){
      const aboveId = blkAt(wx, y + 1, wz);
      if (!sameLiquid(aboveId, id) && !opaqueAt(wx, y + 1, wz)){
        pushQuad(target, [
          [wx,     y + ch[0], wz    ],
          [wx,     y + ch[3], wz + 1],
          [wx + 1, y + ch[2], wz + 1],
          [wx + 1, y + ch[1], wz    ]
        ], [0, 1, 0], uvTop, 1.0);
      }
    }
    if (isLoaded(wx, y - 1, wz)){
      const belowId = blkAt(wx, y - 1, wz);
      if (!sameLiquid(belowId, id) && !opaqueAt(wx, y - 1, wz)){
        pushQuad(target, [
          [wx,     y, wz    ],
          [wx + 1, y, wz    ],
          [wx + 1, y, wz + 1],
          [wx,     y, wz + 1]
        ], [0, -1, 0], uvBot, 0.72);
      }
    }

    function drawSide(nx, ny, nz){
      if (!isLoaded(nx, ny, nz)) return false;
      const nid = blkAt(nx, ny, nz);
      if (sameLiquid(nid, id)) return false;
      return !opaqueAt(nx, ny, nz);
    }

    if (drawSide(wx + 1, y, wz)){
      pushQuad(target, [
        [wx + 1, y,         wz    ],
        [wx + 1, y + ch[1], wz    ],
        [wx + 1, y + ch[2], wz + 1],
        [wx + 1, y,         wz + 1]
      ], [1, 0, 0], uvSide, 0.86);
    }
    if (drawSide(wx - 1, y, wz)){
      pushQuad(target, [
        [wx, y,         wz    ],
        [wx, y,         wz + 1],
        [wx, y + ch[3], wz + 1],
        [wx, y + ch[0], wz    ]
      ], [-1, 0, 0], uvSide, 0.86);
    }
    if (drawSide(wx, y, wz + 1)){
      pushQuad(target, [
        [wx,     y,         wz + 1],
        [wx + 1, y,         wz + 1],
        [wx + 1, y + ch[2], wz + 1],
        [wx,     y + ch[3], wz + 1]
      ], [0, 0, 1], uvSide, 0.86);
    }
    if (drawSide(wx, y, wz - 1)){
      pushQuad(target, [
        [wx + 1, y,         wz],
        [wx,     y,         wz],
        [wx,     y + ch[0], wz],
        [wx + 1, y + ch[1], wz]
      ], [0, 0, -1], uvSide, 0.86);
    }
  }

  const CS2 = CS + 2;
  const Hc  = maxY - minY + 3;
  const opqCache = new Uint8Array(CS2 * CS2 * Hc);
  const opqIdx = (lx, y, lz) =>
    (((y - minY + 1) * CS2 + (lz + 1)) * CS2 + (lx + 1));

  for (let y = minY - 1; y <= maxY + 1; y++){
    if (y < Y_MIN || y >= CHH) continue;
    for (let lz = -1; lz <= CS; lz++){
      for (let lx = -1; lx <= CS; lx++){
        const id = blkAt(bx + lx, y, bz + lz);
        opqCache[opqIdx(lx, y, lz)] =
          (id !== 0 && blockTable[id] && blockTable[id].occludes) ? 1 : 0;
      }
    }
  }

  const opq = (wx, wy, wz) => {
    if (wy < Y_MIN || wy >= CHH) return 0;
    const lx = wx - bx, lz = wz - bz;
    if (lx < -1 || lx > CS || lz < -1 || lz > CS ||
        wy < minY - 1 || wy > maxY + 1){
      const id = blkAt(wx, wy, wz);
      return (id !== 0 && blockTable[id] && blockTable[id].occludes) ? 1 : 0;
    }
    return opqCache[opqIdx(lx, wy, lz)];
  };

  /* ============================================================
     ★ 方块模型（MC block model 风格）
     boxes 用 0~16 的整数坐标；每个面取图集 UV、采样邻格光照 + AO。
     alpha 盒子进透明批次（玻璃），其余进不透明批次。
     ============================================================ */
  const _MODEL_SHADE = [0.92, 0.92, 1.0, 0.7, 0.86, 0.86]; // +X -X +Y -Y +Z -Z

  function pushModel(wx, y, wz, blk){
    const boxes = blk.model.boxes;
    for (let bi = 0; bi < boxes.length; bi++){
      const box = boxes[bi];
      const target = box.alpha ? T : O;
      const X0 = box.x0 / 16, X1 = box.x1 / 16;
      const Y0 = box.y0 / 16, Y1 = box.y1 / 16;
      const Z0 = box.z0 / 16, Z1 = box.z1 / 16;
      const lx = wx - bx, lz = wz - bz;

      for (let f = 0; f < 6; f++){
        const face = FACES[f];
        const onBoundary =
          (f === 0 && box.x1 === 16) || (f === 1 && box.x0 === 0) ||
          (f === 2 && box.y1 === 16) || (f === 3 && box.y0 === 0) ||
          (f === 4 && box.z1 === 16) || (f === 5 && box.z0 === 0);

        /* 只剔除贴在方块边界、且外面被实心方块遮住的面 */
        if (onBoundary){
          const nid = blkAt(wx + face.n[0], y + face.n[1], wz + face.n[2]);
          const nb = blockTable[nid];
          if (nb && nb.occludes) continue;
        }

        const uvR = uvRectTable[box.tiles[f]] || uvRectTable[box.tiles[0]];
        if (!uvR) continue;
        /* 侧面按盒子实际像素尺寸取子 UV，避免 2px 厚板把 16px 贴图压成条纹；
           玻璃与顶/底面保持整张贴图，边框和图案才完整。 */
        let su = 16, sv = 16;
        if (!box.alpha && f !== 2 && f !== 3){
          if (f < 2){ su = box.z1 - box.z0; sv = box.y1 - box.y0; }
          else      { su = box.x1 - box.x0; sv = box.y1 - box.y0; }
        }
        const uvW = (uvR.u1 - uvR.u0) * (su / 16);
        const uvH = (uvR.v1 - uvR.v0) * (sv / 16);
        const start = target.p.length / 3;

        const nlx = onBoundary ? lx + face.n[0] : lx;
        const nly = onBoundary ? y  + face.n[1] : y;
        const nlz = onBoundary ? lz + face.n[2] : lz;
        const lv = _lightBright(_faceLight(lx, y, lz, nlx, nly, nlz));

        for (let vi = 0; vi < 4; vi++){
          const fv = face.verts[vi];
          target.p.push(
            wx + (fv.p[0] ? X1 : X0),
            y  + (fv.p[1] ? Y1 : Y0),
            wz + (fv.p[2] ? Z1 : Z0)
          );
          target.n.push(face.n[0], face.n[1], face.n[2]);
          target.u.push(fv.uv[0], fv.uv[1]);

          let aoF = 1;
          if (onBoundary){
            const s1 = opq(wx + fv.a[0], y + fv.a[1], wz + fv.a[2]);
            const s2 = opq(wx + fv.b[0], y + fv.b[1], wz + fv.b[2]);
            const cc = opq(
              wx + fv.a[0] + fv.b[0] - face.n[0],
              y  + fv.a[1] + fv.b[1] - face.n[1],
              wz + fv.a[2] + fv.b[2] - face.n[2]
            );
            const ao = (s1 && s2) ? 0 : 3 - (s1 + s2 + cc);
            aoF = 0.45 + 0.55 * (ao / 3);
          }
          const bF = aoF * _MODEL_SHADE[f] * lv;
          target.c.push(bF, bF, bF);
          target.b.push(_blockBrightWorld(bx + nlx, nly, bz + nlz));
          target.r.push(uvR.u0, uvR.v0, uvW, uvH);
        }
        target.i.push(start, start + 1, start + 2, start, start + 2, start + 3);
      }
    }
  }

  function greedySideFace(isX, fixedVal, dir){
    const N = CS;
    const H = maxY - minY + 1;
    const W = N;
    const faceIdx = isX ? (dir > 0 ? 0 : 1) : (dir > 0 ? 4 : 5);
    const face = FACES[faceIdx];
    const mask = new Array(H * W).fill(null);

    for (let v = 0; v < H; v++){
      const y = minY + v;
      for (let u = 0; u < W; u++){
        const x = isX ? fixedVal : u;
        const z = isX ? u : fixedVal;

        const id = blocks[(((y - Y_MIN) * CS) + z) * CS + x];
        if (id === 0) continue;
        const blk = blockTable[id];
        if (!blk || blk.invisible) continue;   /* ★ invisible 不渲染 */
        if (!canGreedy(blk)) continue;

        const wx = bx + x, wz = bz + z;
        const nx = isX ? wx + dir : wx;
        const nz = isX ? wz : wz + dir;
        const nid = blkAt(nx, y, nz);
        if (!shouldDraw(blk, blockTable[nid])) continue;

        const ao4 = [0, 0, 0, 0];
        for (let vi = 0; vi < 4; vi++){
          const fv = face.verts[vi];
          const s1 = opq(wx + fv.a[0], y + fv.a[1], wz + fv.a[2]);
          const s2 = opq(wx + fv.b[0], y + fv.b[1], wz + fv.b[2]);
          const cc = opq(
            wx + fv.a[0] + fv.b[0] - face.n[0],
            y  + fv.a[1] + fv.b[1] - face.n[1],
            wz + fv.a[2] + fv.b[2] - face.n[2]
          );
          ao4[vi] = (s1 && s2) ? 0 : 3 - (s1 + s2 + cc);
        }
        const _nlx = isX ? (dir > 0 ? x + 1 : x - 1) : x;
        const _nlz = isX ? z : (dir > 0 ? z + 1 : z - 1);
        mask[v * W + u] = { id, uvIdx: tilesFor(blk)[faceIdx], ao4,
                            tintV: tintQuantAt(blk, wx, wz),
                            skyL: _faceLight(x, y, z, _nlx, y, _nlz) };
      }
    }

    const used = new Uint8Array(H * W);
    for (let v = 0; v < H; v++){
      for (let u = 0; u < W; u++){
        const i = v * W + u;
        const cell = mask[i];
        if (!cell || used[i]) continue;

        let w = 1;
        while (u + w < W){
          const j = v * W + (u + w);
          const m = mask[j];
          if (!m || used[j]) break;
          if (m.id !== cell.id || m.uvIdx !== cell.uvIdx ||
              m.tintV !== cell.tintV || m.skyL !== cell.skyL ||
              !aoSimilar(cell.ao4, m.ao4)) break;
          w++;
        }
        let h = 1;
        outer: while (v + h < H){
          for (let du = 0; du < w; du++){
            const j = (v + h) * W + (u + du);
            const m = mask[j];
            if (!m || used[j]) break outer;
            if (m.id !== cell.id || m.uvIdx !== cell.uvIdx ||
                m.tintV !== cell.tintV || m.skyL !== cell.skyL ||
                !aoSimilar(cell.ao4, m.ao4)) break outer;
          }
          h++;
        }
        for (let dv = 0; dv < h; dv++)
          for (let du = 0; du < w; du++)
            used[(v + dv) * W + (u + du)] = 1;

        const blk = blockTable[cell.id];
        const target = targetFor(blk);
        const uR = uvRectTable[cell.uvIdx];
        const uvW = uR.u1 - uR.u0, uvH = uR.v1 - uR.v0;

        const aoAvg = (cell.ao4[0] + cell.ao4[1] + cell.ao4[2] + cell.ao4[3]) / 4;
        const aoF = 0.45 + 0.55 * (aoAvg / 3);
        const bright = aoF * _lightBright(cell.skyL) * 0.95;

        const _tmode = tintModeFor(blk);
        /* ★ 五面全绿：mode 1 侧面也染 */
        const _rawTintVal = rgbOfQuant(cell.tintV);
        const tint = (_tmode === 2 || _tmode === 1) ? _rawTintVal : null;

        const start = target.p.length / 3;
        const y0 = minY + v, y1 = y0 + h;

        if (isX){
          const z0 = bz + u, z1 = z0 + w;
          const wx = bx + fixedVal + (dir > 0 ? 1 : 0);
          if (dir > 0){
            target.p.push(wx, y0, z0,  wx, y1, z0,  wx, y1, z1,  wx, y0, z1);
            target.n.push(1,0,0, 1,0,0, 1,0,0, 1,0,0);
            target.u.push(0,0,  0,h,  w,h,  w,0);
          } else {
            target.p.push(wx, y0, z1,  wx, y1, z1,  wx, y1, z0,  wx, y0, z0);
            target.n.push(-1,0,0, -1,0,0, -1,0,0, -1,0,0);
            target.u.push(0,0,  0,h,  w,h,  w,0);
          }
        } else {
          const x0 = bx + u, x1 = x0 + w;
          const wz = bz + fixedVal + (dir > 0 ? 1 : 0);
          if (dir > 0){
            target.p.push(x0, y0, wz,  x1, y0, wz,  x1, y1, wz,  x0, y1, wz);
            target.n.push(0,0,1, 0,0,1, 0,0,1, 0,0,1);
            target.u.push(0,0,  w,0,  w,h,  0,h);
          } else {
            target.p.push(x1, y0, wz,  x0, y0, wz,  x0, y1, wz,  x1, y1, wz);
            target.n.push(0,0,-1, 0,0,-1, 0,0,-1, 0,0,-1);
            target.u.push(0,0,  w,0,  w,h,  0,h);
          }
        }
        /* 面外侧的方块光：天光会随昼夜变暗，方块光必须单独留一路 */
        const gb = _blockBrightWorld(
          isX ? (bx + fixedVal + (dir > 0 ? 0.5 : -0.5)) : (bx + u + w * 0.5),
          (y0 + y1) * 0.5,
          isX ? (bz + u + w * 0.5) : (bz + fixedVal + (dir > 0 ? 0.5 : -0.5))
        );
        if (tint){
          for (let k = 0; k < 4; k++)
            target.c.push(bright * tint[0], bright * tint[1], bright * tint[2]);
        } else {
          target.c.push(bright,bright,bright, bright,bright,bright,
                        bright,bright,bright, bright,bright,bright);
        }
        for (let k = 0; k < 4; k++) target.b.push(gb);
        for (let k = 0; k < 4; k++) target.r.push(uR.u0, uR.v0, uvW, uvH);
        target.i.push(start, start+1, start+2, start, start+2, start+3);

      }
    }
  }

  function greedyYFace(y, dir){
    const N = CS;
    const mask = new Array(N * N).fill(null);
    const faceIdx = dir > 0 ? 2 : 3;
    const face = FACES[faceIdx];

    for (let z = 0; z < N; z++){
      for (let x = 0; x < N; x++){
        const id = blocks[(((y - Y_MIN) * CS) + z) * CS + x];
        if (id === 0) continue;
        const blk = blockTable[id];
        if (!blk || blk.invisible) continue;   /* ★ invisible 不渲染 */
        if (!canGreedy(blk)) continue;

        const wx = bx + x, wz = bz + z;
        const nid = blkAt(wx, y + dir, wz);
        if (!shouldDraw(blk, blockTable[nid])) continue;

        const ao4 = [0, 0, 0, 0];
        for (let vi = 0; vi < 4; vi++){
          const fv = face.verts[vi];
          const s1 = opq(wx + fv.a[0], y + fv.a[1], wz + fv.a[2]);
          const s2 = opq(wx + fv.b[0], y + fv.b[1], wz + fv.b[2]);
          const cc = opq(
            wx + fv.a[0] + fv.b[0] - face.n[0],
            y  + fv.a[1] + fv.b[1] - face.n[1],
            wz + fv.a[2] + fv.b[2] - face.n[2]
          );
          ao4[vi] = (s1 && s2) ? 0 : 3 - (s1 + s2 + cc);
        }
        mask[z * N + x] = { id, uvIdx: tilesFor(blk)[faceIdx], ao4,
                            tintV: tintQuantAt(blk, wx, wz),
                            skyL: _faceLight(x, y, z, x, y + dir, z) };
      }
    }

    const used = new Uint8Array(N * N);
    for (let z = 0; z < N; z++){
      for (let x = 0; x < N; x++){
        const i = z * N + x;
        const cell = mask[i];
        if (!cell || used[i]) continue;

        let w = 1;
        while (x + w < N){
          const j = z * N + (x + w);
          const m = mask[j];
          if (!m || used[j]) break;
          if (m.id !== cell.id || m.uvIdx !== cell.uvIdx ||
              m.tintV !== cell.tintV || m.skyL !== cell.skyL ||
              !aoEqual(cell.ao4, m.ao4)) break;
          w++;
        }
        let h = 1;
        outer: while (z + h < N){
          for (let dx = 0; dx < w; dx++){
            const j = (z + h) * N + (x + dx);
            const m = mask[j];
            if (!m || used[j]) break outer;
            if (m.id !== cell.id || m.uvIdx !== cell.uvIdx ||
                m.tintV !== cell.tintV || m.skyL !== cell.skyL ||
                !aoEqual(cell.ao4, m.ao4)) break outer;
          }
          h++;
        }
        for (let dz = 0; dz < h; dz++)
          for (let dx = 0; dx < w; dx++)
            used[(z + dz) * N + (x + dx)] = 1;

        const blk = blockTable[cell.id];
        const target = targetFor(blk);
        const uR = uvRectTable[cell.uvIdx];
        const uvW = uR.u1 - uR.u0, uvH = uR.v1 - uR.v0;

        const aoAvg = (cell.ao4[0] + cell.ao4[1] + cell.ao4[2] + cell.ao4[3]) / 4;
        const aoF = 0.45 + 0.55 * (aoAvg / 3);
        const bright = ((dir > 0) ? aoF : 0.7) * _lightBright(cell.skyL);

        const _tmode = tintModeFor(blk);
        const tint = (_tmode === 2 || (_tmode === 1 && dir > 0))
          ? rgbOfQuant(cell.tintV) : null;

        const start = target.p.length / 3;
        const wx0 = bx + x, wx1 = bx + x + w;
        const wz0 = bz + z, wz1 = bz + z + h;
        const wy = y + (dir > 0 ? 1 : 0);

        if (dir > 0){
          target.p.push(wx0, wy, wz0, wx0, wy, wz1, wx1, wy, wz1, wx1, wy, wz0);
          target.n.push(0,1,0, 0,1,0, 0,1,0, 0,1,0);
          target.u.push(0,0, 0,h, w,h, w,0);
        } else {
          target.p.push(wx0, wy, wz0, wx1, wy, wz0, wx1, wy, wz1, wx0, wy, wz1);
          target.n.push(0,-1,0, 0,-1,0, 0,-1,0, 0,-1,0);
          target.u.push(0,0, w,0, w,h, 0,h);
        }
        const gb = _blockBrightWorld(
          bx + x + w * 0.5,
          wy + (dir > 0 ? 0.5 : -0.5),
          bz + z + h * 0.5
        );
        if (tint){
          for (let k = 0; k < 4; k++)
            target.c.push(bright * tint[0], bright * tint[1], bright * tint[2]);
        } else {
          target.c.push(bright,bright,bright, bright,bright,bright,
                        bright,bright,bright, bright,bright,bright);
        }
        for (let k = 0; k < 4; k++) target.b.push(gb);
        for (let k = 0; k < 4; k++) target.r.push(uR.u0, uR.v0, uvW, uvH);
        target.i.push(start, start+1, start+2, start, start+2, start+3);
      }
    }
  }

  for (let x = 0; x < CS; x++){
    greedySideFace(true,  x, +1);
    greedySideFace(true,  x, -1);
  }
  for (let z = 0; z < CS; z++){
    greedySideFace(false, z, +1);
    greedySideFace(false, z, -1);
  }

  for (let y = minY; y <= maxY; y++){
    greedyYFace(y, +1);
    greedyYFace(y, -1);

    for (let z = 0; z < CS; z++){
      for (let x = 0; x < CS; x++){
        const id = blocks[(((y - Y_MIN) * CS) + z) * CS + x];
        if (id === 0) continue;
        const blk = blockTable[id];
        if (!blk) continue;
        if (blk.invisible) continue;   /* ★ invisible 不渲染 */
        if (blk.dynamic) continue;     /* ★ 动态模型交给 chest-visuals 实时绘制 */
        if (canGreedy(blk)) continue;

        const target = targetFor(blk);
        const wx = bx + x, wz = bz + z;

        if (blk.model){
          pushModel(wx, y, wz, blk);
          continue;
        }

        if (blk.cross){
          if (crossCull && crossCull.enabled && !blk.waterPlant &&
              crossCull.playerY - y > crossCull.dy){
            continue;
          }
          const cr = uvRectTable[tilesFor(blk)[0]];
          const _tf = tintForFace(blk, wx, wz, 2);
          const _lv = _faceLight(x, y, z, x, y, z);
          const _bf = _lightBright(_lv);
          const _tfL = _tf ? [_tf[0]*_bf, _tf[1]*_bf, _tf[2]*_bf] : [_bf,_bf,_bf];
          pushCross(C, wx, y, wz, cr, blk, _tfL);
          continue;
        }

        if (blk.stair){
          pushStair(target, wx, y, wz, uvRectTable, blk, opq);
          continue;
        }

        if (blk.liquid){
          if (waterMode === 'none' && blk.name === 'water') continue;
          const lv = getFluidLevel(wx, y, wz);
          if (lv > 0) pushLiquidLocal(target, wx, y, wz, blk);
          continue;
        }

        /* ★ 魔法粉末：极小偏移无缝对接 + 双向渲染 */
        if (blk.name === 'magic_dust' || blk.name === 'magic_dust_on') {
            const target = O; 
            
            const uR = uvRectTable[tilesFor(blk)[0]];
            const uvW = uR.u1 - uR.u0, uvH = uR.v1 - uR.v0;
            
            const _lv = _faceLight(x, y, z, x, y + 1, z);
            const _bF = _lightBright(_lv);
            const cr = _bF, cg = _bF, cb = _bF;
            
            const yOffset = y + 0.0625 + 0.002; 
            const xMin = 0.4375, xMax = 0.5625;
            const zMin = 0.4375, zMax = 0.5625;
            const IN = 0.001; // ★ 极微小偏移，肉眼看无缝，且不会被相邻实体方块遮挡
            
            // 统一的双面三角形渲染
            const pushDoubleSidedQuad = (p1, p2, p3, p4, nx, ny, nz) => {
                const start = target.p.length / 3;
                target.p.push(
                    wx+p1[0], p1[1], wz+p1[2], wx+p2[0], p2[1], wz+p2[2],
                    wx+p3[0], p3[1], wz+p3[2], wx+p4[0], p4[1], wz+p4[2]
                );
                target.n.push(nx,ny,nz, nx,ny,nz, nx,ny,nz, nx,ny,nz);
                target.u.push(0,0, 0,1, 1,1, 1,0);
                target.c.push(cr, cg, cb, cr, cg, cb, cr, cg, cb, cr, cg, cb);
                const _gb = _blockBrightWorld(
                    wx + (p1[0] + p2[0] + p3[0] + p4[0]) * 0.25 + nx * 0.5,
                    (p1[1] + p2[1] + p3[1] + p4[1]) * 0.25 + ny * 0.5,
                    wz + (p1[2] + p2[2] + p3[2] + p4[2]) * 0.25 + nz * 0.5
                );
                for (let k = 0; k < 4; k++) target.b.push(_gb);
                for (let k = 0; k < 4; k++) target.r.push(uR.u0, uR.v0, uvW, uvH);
                target.i.push(start, start+1, start+2, start, start+2, start+3);
                target.i.push(start, start+2, start+1, start, start+3, start+2);
            };
            
            const isDust = (nid) => {
                if (nid === 0) return false;
                const nb = blockTable[nid];
                return nb && (nb.name === 'magic_dust' || nb.name === 'magic_dust_on');
            };
            
            // 中心点
            pushDoubleSidedQuad([xMin, yOffset, zMin], [xMax, yOffset, zMin], [xMax, yOffset, zMax], [xMin, yOffset, zMax], 0, 1, 0);
            
            // -Z (North)
            if (isDust(blkAt(wx, y, wz - 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMax, yOffset, zMin], [xMax, yOffset, IN], [xMin, yOffset, IN], 0, 1, 0);
            } else if (isDust(blkAt(wx, y + 1, wz - 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMax, yOffset, zMin], [xMax, yOffset, IN], [xMin, yOffset, IN], 0, 1, 0);
                pushDoubleSidedQuad([xMin, yOffset, IN], [xMax, yOffset, IN], [xMax, yOffset + 1, IN], [xMin, yOffset + 1, IN], 0, 0, -1);
            } else if (isDust(blkAt(wx, y - 1, wz - 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMax, yOffset, zMin], [xMax, yOffset, IN], [xMin, yOffset, IN], 0, 1, 0);
            }
            
            // +Z (South)
            if (isDust(blkAt(wx, y, wz + 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMax], [xMax, yOffset, zMax], [xMax, yOffset, 1 - IN], [xMin, yOffset, 1 - IN], 0, 1, 0);
            } else if (isDust(blkAt(wx, y + 1, wz + 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMax], [xMax, yOffset, zMax], [xMax, yOffset, 1 - IN], [xMin, yOffset, 1 - IN], 0, 1, 0);
                pushDoubleSidedQuad([xMin, yOffset, 1 - IN], [xMax, yOffset, 1 - IN], [xMax, yOffset + 1, 1 - IN], [xMin, yOffset + 1, 1 - IN], 0, 0, 1);
            } else if (isDust(blkAt(wx, y - 1, wz + 1))) {
                pushDoubleSidedQuad([xMin, yOffset, zMax], [xMax, yOffset, zMax], [xMax, yOffset, 1 - IN], [xMin, yOffset, 1 - IN], 0, 1, 0);
            }
            
            // -X (West)
            if (isDust(blkAt(wx - 1, y, wz))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMin, yOffset, zMax], [IN, yOffset, zMax], [IN, yOffset, zMin], 0, 1, 0);
            } else if (isDust(blkAt(wx - 1, y + 1, wz))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMin, yOffset, zMax], [IN, yOffset, zMax], [IN, yOffset, zMin], 0, 1, 0);
                pushDoubleSidedQuad([IN, yOffset, zMin], [IN, yOffset, zMax], [IN, yOffset + 1, zMax], [IN, yOffset + 1, zMin], 1, 0, 0);
            } else if (isDust(blkAt(wx - 1, y - 1, wz))) {
                pushDoubleSidedQuad([xMin, yOffset, zMin], [xMin, yOffset, zMax], [IN, yOffset, zMax], [IN, yOffset, zMin], 0, 1, 0);
            }
            
            // +X (East)
            if (isDust(blkAt(wx + 1, y, wz))) {
                pushDoubleSidedQuad([xMax, yOffset, zMin], [xMax, yOffset, zMax], [1 - IN, yOffset, zMax], [1 - IN, yOffset, zMin], 0, 1, 0);
            } else if (isDust(blkAt(wx + 1, y + 1, wz))) {
                pushDoubleSidedQuad([xMax, yOffset, zMin], [xMax, yOffset, zMax], [1 - IN, yOffset, zMax], [1 - IN, yOffset, zMin], 0, 1, 0);
                pushDoubleSidedQuad([1 - IN, yOffset, zMin], [1 - IN, yOffset, zMax], [1 - IN, yOffset + 1, zMax], [1 - IN, yOffset + 1, zMin], -1, 0, 0);
            } else if (isDust(blkAt(wx + 1, y - 1, wz))) {
                pushDoubleSidedQuad([xMax, yOffset, zMin], [xMax, yOffset, zMax], [1 - IN, yOffset, zMax], [1 - IN, yOffset, zMin], 0, 1, 0);
            }
            
            continue;
        }

        const hR = blk.heightRatio;
        const tiles = tilesFor(blk);
        for (let f = 0; f < 6; f++){
          const face = FACES[f];
          const nid = blkAt(wx + face.n[0], y + face.n[1], wz + face.n[2]);
          if (!shouldDraw(blk, blockTable[nid])) continue;

          const uvR = uvRectTable[tiles[f]];
          const uvW = uvR.u1 - uvR.u0, uvH = uvR.v1 - uvR.v0;
          /* ★ 半高方块（半砖、雪层）的侧面只取贴图下半段，
             而不是把整张贴图压进半格高——否则木纹/石纹密度翻倍。 */
          const sliceH = (hR !== 1 && f !== 2 && f !== 3) ? Math.min(1, hR) : 1;
          const start = target.p.length / 3;

          for (let vi = 0; vi < 4; vi++){
            const fv = face.verts[vi];
            const yLocal = fv.p[1] * hR;
            target.p.push(wx + fv.p[0], y + yLocal, wz + fv.p[2]);
            target.n.push(face.n[0], face.n[1], face.n[2]);
            target.u.push(fv.uv[0], fv.uv[1]);

            const s1 = opq(wx + fv.a[0], y + fv.a[1], wz + fv.a[2]);
            const s2 = opq(wx + fv.b[0], y + fv.b[1], wz + fv.b[2]);
            const cc = opq(
              wx + fv.a[0] + fv.b[0] - face.n[0],
              y  + fv.a[1] + fv.b[1] - face.n[1],
              wz + fv.a[2] + fv.b[2] - face.n[2]
            );
            const ao = (s1 && s2) ? 0 : 3 - (s1 + s2 + cc);
            const aoF = 0.45 + 0.55 * (ao / 3);
            const ftint = tintForFace(blk, wx, wz, f);
            const _nL = _lightBright(_faceLight(x, y, z, x + face.n[0], y + face.n[1], z + face.n[2]));
            const _bF = aoF * _nL;
            const _gb = _blockBrightWorld(bx + x + face.n[0], y + face.n[1], bz + z + face.n[2]);
            if (ftint){
              target.c.push(_bF * ftint[0], _bF * ftint[1], _bF * ftint[2]);
            } else {
              target.c.push(_bF, _bF, _bF);
            }
            target.b.push(_gb);
            target.r.push(uvR.u0, uvR.v0, uvW, uvH * sliceH);
          }
          target.i.push(start, start+1, start+2, start, start+2, start+3);
        }
      }
    }
  }

  /* ★ 返回打包格式，worker 与主线程共用 */
  return {
    O: packGroup(O),
    E: packGroup(E),
    T: packGroup(T),
    L: packGroup(L),
    C: packGroup(C),
  };
}