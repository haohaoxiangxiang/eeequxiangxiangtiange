import * as THREE from '../vendor/three.module.js';
/* ★ 打破循环依赖：不从 engine-core.js import atlas 常量。
   engine-core.js 顶层 IIFE 触发 render-core.js → textures.js 求值，
   而那时 engine-core.js 自己的 ATLAS_COLS 还在 TDZ，直接崩。
   这里本地复制一份读取逻辑（和 engine-core.js 的 _readAtlasCols 一致）。 */
function _readAtlasColsLocal(){
  try {
    if (typeof window !== 'undefined' && window.__ATLAS_CONFIG__){
      const c = Number(window.__ATLAS_CONFIG__.cols);
      if (isFinite(c) && c >= 8 && c <= 512) return Math.floor(c);
    }
  } catch(e){}
  return 32;
}
const ATLAS_TILE = 32;
const ATLAS_COLS = _readAtlasColsLocal();
const ATLAS_SIZE = ATLAS_TILE * ATLAS_COLS;
const TEX_INNER = 16;
const TEX_PAD = 8;
import { clamp, hash2i, fbm } from './../core/runtime.js';

/* ★ atlas 总容量（32×32=1024） */
const ATLAS_TOTAL = ATLAS_COLS * ATLAS_COLS;

/* ★ Worker 兼容：Worker 里没有 document，atlasCanvas/actx 用假对象占位 */
const IS_WORKER = (typeof document === 'undefined');

export const atlasCanvas = IS_WORKER
  ? { width: 0, height: 0, getContext: function(){ return null; } }
  : document.createElement('canvas');
if (!IS_WORKER){
  atlasCanvas.width = atlasCanvas.height = ATLAS_SIZE;
}
const actx = IS_WORKER ? null : atlasCanvas.getContext('2d');

export const TEX = {};
let texCounter = 0;

/* ============================================================
   ★ 临时测试开关（已关闭）
   ============================================================ */
const __VOID_TEST = false;
const __VOID_TEX = () => [0, 0, 0, 0];
function __maybeVoid(fn){ return __VOID_TEST ? __VOID_TEX : fn; }

/* ============================================================
   透明像素颜色扩散
   ============================================================ */
function expandTransparentEdges(data, S, iterations){
  const tmp = new Uint8ClampedArray(data.length);
  const filled = new Uint8Array(S * S);
  for (let p = 0; p < S * S; p++){
    filled[p] = data[p * 4 + 3] > 0 ? 1 : 0;
  }

  for (let iter = 0; iter < iterations; iter++){
    tmp.set(data);
    const nextFilled = new Uint8Array(filled);

    for (let y = 0; y < S; y++){
      for (let x = 0; x < S; x++){
        const p = y * S + x;
        if (filled[p]) continue;

        let r = 0, g = 0, b = 0, n = 0;
        for (let dy = -1; dy <= 1; dy++){
          for (let dx = -1; dx <= 1; dx++){
            if (dx === 0 && dy === 0) continue;
            const nx = x + dx, ny = y + dy;
            if (nx < 0 || nx >= S || ny < 0 || ny >= S) continue;
            const np = ny * S + nx;
            if (!filled[np]) continue;

            const ni = np * 4;
            r += tmp[ni]; g += tmp[ni + 1]; b += tmp[ni + 2];
            n++;
          }
        }
        if (n > 0){
          const i = p * 4;
          data[i]     = Math.round(r / n);
          data[i + 1] = Math.round(g / n);
          data[i + 2] = Math.round(b / n);
          nextFilled[p] = 1;
        }
      }
    }
    filled.set(nextFilled);
  }
}

/* ============================================================
   ★ alpha=0 → 1
   ------------------------------------------------------------
   blitToAtlas 用 drawImage 混合，源 alpha=0 时目标不变
   （atlas 初始透明黑）→ 洞变成黑色。alpha 改成 1 后能正常写入。
   ============================================================ */
function fixZeroAlpha(data){
  for (let i = 3; i < data.length; i += 4){
    if (data[i] === 0) data[i] = 1;
  }
}

/* ============================================================
   blitToAtlas
   ============================================================ */
function blitToAtlas(srcCanvas, idxn){
  const S = TEX_INNER;
  const colI = idxn % ATLAS_COLS;
  const rowI = Math.floor(idxn / ATLAS_COLS);
  const ox = colI * ATLAS_TILE + TEX_PAD;
  const oy = rowI * ATLAS_TILE + TEX_PAD;

  actx.drawImage(srcCanvas, ox, oy);

  actx.drawImage(srcCanvas, 0,   0,   S, 1, ox,          oy - TEX_PAD, S, TEX_PAD);
  actx.drawImage(srcCanvas, 0,   S-1, S, 1, ox,          oy + S,       S, TEX_PAD);
  actx.drawImage(srcCanvas, 0,   0,   1, S, ox - TEX_PAD, oy,          TEX_PAD, S);
  actx.drawImage(srcCanvas, S-1, 0,   1, S, ox + S,       oy,          TEX_PAD, S);
  actx.drawImage(srcCanvas, 0,   0,   1, 1, ox-TEX_PAD,  oy-TEX_PAD,  TEX_PAD, TEX_PAD);
  actx.drawImage(srcCanvas, S-1, 0,   1, 1, ox+S,        oy-TEX_PAD,  TEX_PAD, TEX_PAD);
  actx.drawImage(srcCanvas, 0,   S-1, 1, 1, ox-TEX_PAD,  oy+S,        TEX_PAD, TEX_PAD);
  actx.drawImage(srcCanvas, S-1, S-1, 1, 1, ox+S,        oy+S,        TEX_PAD, TEX_PAD);
}

/* ============================================================
   手动生成有限层 mipmap
   ============================================================ */
function buildMipmaps(canvas, maxLevel){
  const mips = [canvas];
  let src = canvas;
  for (let lv = 1; lv <= maxLevel; lv++){
    const w = Math.max(1, src.width  >> 1);
    const h = Math.max(1, src.height >> 1);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, w, h);
    mips.push(c);
    src = c;
  }
  return mips;
}

/* ============================================================
   ★ atlas 刷新调度
   ============================================================ */
const _atlasListeners = [];
let _atlasFlushScheduled = false;
let _atlasReady = false;

export function onAtlasChanged(fn){
  if (typeof fn === 'function') _atlasListeners.push(fn);
}

function _scheduleAtlasFlush(){
  if (!_atlasReady) return;
  if (_atlasFlushScheduled) return;
  _atlasFlushScheduled = true;
  queueMicrotask(() => {
    _atlasFlushScheduled = false;

    if (!IS_WORKER){
      atlasTexture.mipmaps = buildMipmaps(atlasCanvas, 3);
      atlasTexture.needsUpdate = true;
    }

    if (typeof window !== 'undefined' && window.__atlasNoMip__){
      window.__atlasNoMip__.needsUpdate = true;
    }

    for (let i = 0; i < _atlasListeners.length; i++){
      try { _atlasListeners[i](); }
      catch(e){ console.error('[textures] atlas 回调出错', e); }
    }
    console.log('[textures] atlas 已刷新（used =', texCounter, '/', ATLAS_TOTAL, '）');
  });
}

/* ============================================================
   纹理注册
   ============================================================ */

export function registerTex(name, fn){
  if (texCounter >= ATLAS_TOTAL){
    console.warn(`[textures] atlas 已满 (${ATLAS_TOTAL})，拒绝 "${name}"`);
    return -1;
  }
  const idxn = texCounter++;
  if (IS_WORKER){
    /* ★ Worker 里只登记索引，不画 canvas —— 但 TEX[name] 数字必须和
       主线程一致，否则 blocks.js 的 tiles 会错位，贴图对不上 */
    TEX[name] = idxn;
    return idxn;
  }
  const S = TEX_INNER;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      const col = fn(x, y, S) || [255, 0, 255, 255];
      const i = (y * S + x) * 4;
      d[i]   = clamp(col[0] | 0, 0, 255);
      d[i+1] = clamp(col[1] | 0, 0, 255);
      d[i+2] = clamp(col[2] | 0, 0, 255);
      d[i+3] = col[3] === undefined ? 255 : clamp(col[3] | 0, 0, 255);
    }
  }
  expandTransparentEdges(d, S, S);
  fixZeroAlpha(d);
  ctx.putImageData(img, 0, 0);
  blitToAtlas(c, idxn);
  TEX[name] = idxn;
  _scheduleAtlasFlush();
  return idxn;
}

export function registerCanvasTex(name, drawFn){
  if (texCounter >= ATLAS_TOTAL){
    console.warn(`[textures] atlas 已满 (${ATLAS_TOTAL})，拒绝 "${name}"`);
    return -1;
  }
  const idxn = texCounter++;
  if (IS_WORKER){
    TEX[name] = idxn;
    return idxn;
  }
  const S = TEX_INNER;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, S, S);
  drawFn(ctx, S);
  const imgData = ctx.getImageData(0, 0, S, S);
  expandTransparentEdges(imgData.data, S, S);
  fixZeroAlpha(imgData.data);
  ctx.putImageData(imgData, 0, 0);
  blitToAtlas(c, idxn);
  TEX[name] = idxn;
  _scheduleAtlasFlush();
  return idxn;
}

export function registerTexRuntime(name, drawFn){
  if (TEX[name] !== undefined){
    console.log(`[textures] "${name}" 已存在，复用 idx=${TEX[name]}`);
    return TEX[name];
  }
  const idx = registerCanvasTex(name, drawFn);
  if (idx >= 0) _scheduleAtlasFlush();
  return idx;
}

export function getAtlasUsage(){
  return {
    used: texCounter,
    total: ATLAS_TOTAL,
    free: ATLAS_TOTAL - texCounter,
    cols: ATLAS_COLS,
  };
}

/* ============================================================
   基础方块（注意：草方块已改为灰白，待群系染色）
   ============================================================ */
registerTex('grass_top', (x, y) => {
  /* ★ 纯色块 + 细微细节：主灰度 240~250，3% 单像素暗点 */
  const base = 240;
  const d = hash2i(x, y, 11);
  let v = base + d * 10;
  if (hash2i(x, y, 12) > 0.97) v -= 22;
  if (hash2i(x, y, 13) > 0.995) v -= 10;
  return [v, v, v];
});

/* ★ MC 风格：grass_side 只画泥土（不染），
   草的部分交给独立的 grass_side_overlay（下方新增）。 */
registerTex('grass_side', (x, y) => {
  /* ★ 纯色块：跟 grass_top 完全一致，无上下分层 */
  const base = 240;
  const d = hash2i(x, y, 21);
  let v = base + d * 10;
  if (hash2i(x, y, 22) > 0.97) v -= 22;
  if (hash2i(x, y, 23) > 0.995) v -= 10;
  return [v, v, v];
});

registerTex('dirt', (x, y) => {
  const n = hash2i(x, y, 31) * 0.6 + fbm(x * 0.5, y * 0.5, 2, 33) * 0.4;
  return [112 + n * 52, 80 + n * 40, 52 + n * 28];
});
registerCanvasTex('stone', (ctx, S) => {
  /* ★ 石头（竖线特征版）
     1) 底色：低频 fbm 大块 + 高频像素颗粒 + 少量暗点/亮点
     2) 竖线：22 根 1~4px 高的短竖线（85% 宽 1px / 15% 宽 2px）
        30% 是亮线（+8），70% 是暗线（-12）
  */
  const v_buf = new Float32Array(S * S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const blockN = fbm(x * 0.102, y * 0.102, 2, 74632) - 0.5;
    const fine = (hash2i(x, y, 74633) - 0.5) * 6;
    let v = 154 + blockN * 3.5 + fine;
    if (hash2i(x, y, 74634) > 0.92) v -= 9;    // 8% 暗点
    if (hash2i(x, y, 74635) > 0.97) v += 5;    // 3% 亮点
    v_buf[y * S + x] = v;
  }
  /* 竖线 */
  for (let i = 0; i < 22; i++){
    const sx = Math.floor(hash2i(i, 0, 74642) * S);
    const sy = Math.floor(hash2i(i, 1, 74642) * (S - 4));
    const len = 1 + Math.floor(hash2i(i, 2, 74642) * 4);
    const width = (hash2i(i, 3, 74642) > 0.85) ? 2 : 1;
    const bright = hash2i(i, 4, 74642) < 0.30;
    const amt = bright ? 8 : -12;
    for (let k = 0; k < len; k++) for (let dw = 0; dw < width; dw++){
      const px = sx + dw, py = sy + k;
      if (px < 0 || px >= S || py < 0 || py >= S) continue;
      v_buf[py * S + px] += amt;
    }
  }
  /* 转 ImageData */
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let i = 0; i < S * S; i++){
    const v = v_buf[i];
    d[i * 4]     = Math.max(0, Math.min(255, Math.round(v)));
    d[i * 4 + 1] = Math.max(0, Math.min(255, Math.round(v + 2)));
    d[i * 4 + 2] = Math.max(0, Math.min(255, Math.round(v + 4)));
    d[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
});
registerCanvasTex('cobble', (ctx, S) => {
  /* ★ 不规则鹅卵石：3×3 抖动种子 + 环形（toroidal）距离，
     石块之间只留 1px 左右的暗缝，平铺不会出现接缝。
     原来的 6 个大 Voronoi 胞 + 2.4px 宽灰缝，远看像"灰泥里的云"。 */
  const N = 3, cell = S / N, jitter = S * 0.15;
  const seeds = [];
  for (let gy = 0; gy < N; gy++) for (let gx = 0; gx < N; gx++){
    const i = gy * N + gx;
    seeds.push([
      (gx * cell + cell / 2 + (hash2i(i, 0, 16015) - 0.5) * 2 * jitter + S) % S,
      (gy * cell + cell / 2 + (hash2i(i, 1, 16015) - 0.5) * 2 * jitter + S) % S,
    ]);
  }
  const img = ctx.createImageData(S, S); const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    let best = Infinity, second = Infinity, bi = 0;
    for (let i = 0; i < seeds.length; i++){
      let dx = Math.abs(x - seeds[i][0]), dy = Math.abs(y - seeds[i][1]);
      if (dx > S / 2) dx = S - dx;
      if (dy > S / 2) dy = S - dy;
      const dd = Math.sqrt(dx * dx + dy * dy);
      if (dd < best){ second = best; best = dd; bi = i; }
      else if (dd < second) second = dd;
    }
    const gap = second - best;
    const i4 = (y * S + x) * 4;
    if (gap < 0.5){
      /* 石缝 */
      const v = 46 + hash2i(x, y, 16016) * 10;
      d[i4] = v; d[i4 + 1] = v + 1; d[i4 + 2] = v + 4;
    } else {
      /* 石块：每块独立基色 + 左上高光 / 边缘压暗 + 细颗粒 */
      let dx = x - seeds[bi][0], dy = y - seeds[bi][1];
      if (dx > S / 2) dx -= S; else if (dx < -S / 2) dx += S;
      if (dy > S / 2) dy -= S; else if (dy < -S / 2) dy += S;
      const hl = Math.max(-1, Math.min(1, (-dx * 0.5 + dy * 0.65) / 3.8));
      const edge = Math.max(0, 1 - (gap - 0.5) / 2.2);
      const px = (hash2i(x, y, 16019) - 0.5) * 14;
      const base = 126 + hash2i(bi, 0, 16018) * 30;
      const v = base + hl * 9 + px - edge * 12;
      d[i4] = v; d[i4 + 1] = v + 1; d[i4 + 2] = v + 5;
    }
    d[i4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
});
registerTex('sand', (x, y) => {
  const n = hash2i(x, y, 61) * 0.6 + fbm(x * 0.8, y * 0.8, 2, 62) * 0.4;
  return [218 + n * 30, 202 + n * 32, 148 + n * 36];
});
registerTex('sandstone', (x, y) => {
  const band = y % 5 === 0 ? -22 : 0;
  const n = hash2i(x, y, 61) * 0.6 + fbm(x * 0.5, y * 0.35, 2, 63) * 0.4;
  return [212 + n * 26 + band, 196 + n * 28 + band, 144 + n * 32 + band];
});
registerTex('gravel', (x, y) => {
  /* ★ 砂砾：原石头的碎颗粒样式（hash + 高频 fbm） */
  const n = hash2i(x, y, 41) * 0.5 + fbm(x * 0.6, y * 0.6, 3, 43) * 0.5;
  return [118 + n * 44, 120 + n * 44, 126 + n * 44];
});
registerTex('clay', (x, y) => {
  const n = hash2i(x, y, 81) * 0.6 + fbm(x * 0.6, y * 0.6, 2, 82) * 0.4;
  return [156 + n * 26, 162 + n * 26, 174 + n * 26];
});

/* 三种原木 */
registerTex('oak_log_side', (x, y) => {
  const bark = fbm(x * 0.7, y * 0.08, 3, 91);
  const n = hash2i(x, Math.floor(y / 2), 92);
  return [130 + bark * 45 + n * 12, 92 + bark * 32 + n * 8, 52 + bark * 22 + n * 6];
});
registerTex('spruce_log_side', (x, y) => {
  const bark = fbm(x * 0.9, y * 0.06, 3, 121);
  const n = hash2i(x, Math.floor(y / 3), 122);
  return [72 + bark * 30 + n * 10, 48 + bark * 22 + n * 8, 32 + bark * 18 + n * 6];
});
registerTex('sakura_log_side', (x, y) => {
  const bark = fbm(x * 0.7, y * 0.08, 3, 141);
  const n = hash2i(x, Math.floor(y / 2), 142);
  return [118 + bark * 40 + n * 10, 86 + bark * 32 + n * 8, 82 + bark * 30 + n * 6];
});
registerTex('oak_log_top', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 1.7) * 0.5 + 0.5;
  const n = hash2i(x, y, 95) * 0.2;
  return [148 + ring * 42 + n * 14, 108 + ring * 32 + n * 12, 68 + ring * 22 + n * 10];
});
registerTex('spruce_log_top', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 2.4) * 0.5 + 0.5;
  const n = hash2i(x, y, 125) * 0.2;
  return [96 + ring * 28 + n * 10, 66 + ring * 20 + n * 8, 44 + ring * 14 + n * 6];
});
registerTex('sakura_log_top', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 1.9) * 0.5 + 0.5;
  const n = hash2i(x, y, 145) * 0.2;
  return [158 + ring * 34 + n * 12, 118 + ring * 30 + n * 10, 106 + ring * 26 + n * 8];
});

/* 三种木板 */
registerTex('oak_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [110, 80, 48];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 111);
  return [182 + n * 40, 136 + n * 32, 82 + n * 22];
});
registerTex('spruce_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [68, 46, 30];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 131);
  return [118 + n * 32, 80 + n * 26, 48 + n * 18];
});
registerTex('sakura_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [148, 112, 110];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 161);
  return [206 + n * 24, 172 + n * 22, 168 + n * 20];
});

/* ============================================================
   三种树叶：改为高亮灰白，交由群系染色
   ============================================================ */

registerTex('oak_leaves', (x, y) => {
  const edge = Math.min(x, y, 27 - x, 27 - y);
  if (edge < 1 && hash2i(x, y, 105) < 0.45) return [0, 0, 0, 0];
  if (hash2i(x, y, 106) < 0.10) return [0, 0, 0, 0];
  /* ★ 纯色块 + 细微细节 */
  const base = 240;
  const d = hash2i(x, y, 101);
  let v = base + d * 10;
  if (hash2i(x, y, 102) > 0.97) v -= 22;
  if (hash2i(x, y, 103) > 0.995) v -= 12;
  return [v, v, v];
});
registerTex('oak_leaves_solid', (x, y) => {
  const n = fbm(x * 0.38, y * 0.38, 3, 101);
  const n2 = hash2i(x, y, 102);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

registerTex('spruce_leaves', (x, y) => {
  const edge = Math.min(x, y, 27 - x, 27 - y);
  if (edge < 1 && hash2i(x, y, 135) < 0.50) return [0, 0, 0, 0];
  if (hash2i(x, y, 136) < 0.12) return [0, 0, 0, 0];
  /* ★ 纯色块 + 细微细节（略暗，针叶） */
  const base = 232;
  const d = hash2i(x, y, 131);
  let v = base + d * 12;
  if (hash2i(x, y, 132) > 0.96) v -= 24;
  if (hash2i(x, y, 133) > 0.995) v -= 12;
  return [v, v, v];
});
registerTex('spruce_leaves_solid', (x, y) => {
  const n = fbm(x * 0.38, y * 0.38, 3, 131);
  const n2 = hash2i(x, y, 132);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

registerTex('sakura_leaves', (x, y) => {
  const edge = Math.min(x, y, 27 - x, 27 - y);
  if (edge < 1 && hash2i(x, y, 155) < 0.40) return [0, 0, 0, 0];
  if (hash2i(x, y, 156) < 0.08) return [0, 0, 0, 0];
  /* ★ 纯色块 + 细微细节（更亮，粉） */
  const base = 245;
  const d = hash2i(x, y, 151);
  let v = base + d * 10;
  if (hash2i(x, y, 152) > 0.97) v -= 20;
  if (hash2i(x, y, 153) > 0.995) v -= 10;
  return [v, v, v];
});
registerTex('sakura_leaves_solid', (x, y) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 151);
  const n2 = hash2i(x, y, 152);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

/* ============================================================
   其他方块
   ============================================================ */
registerTex('petals', (x, y) => {
  const n = hash2i(x, y, 161);
  const g = fbm(x * 0.4, y * 0.4, 2, 162);
  if (n < 0.22) return [248, 176, 202];
  if (n < 0.30) return [255, 214, 228];
  return [54 + g * 44, 118 + g * 66, 44 + g * 40];
});
registerTex('glass', (x, y, S) => {
  const edge = (x < 1 || x > S - 2 || y < 1 || y > S - 2);
  if (edge) return [208, 232, 244, 210];
  const g = fbm(x * 0.25, y * 0.25, 2, 171);
  return [222 + g * 18, 240 + g * 15, 250 + g * 5, 55];
});
registerTex('water', (x, y) => {
  const n = fbm(x * 0.3, y * 0.3, 3, 181);
  const w = Math.sin((x + y) * 0.32 + n * 5) * 0.5 + 0.5;
  return [36 + n * 38, 92 + n * 58 + w * 18, 196 + n * 50, 245];
});
registerTex('ice', (x, y) => {
  const n = fbm(x * 0.4, y * 0.4, 3, 191);
  return [172 + n * 48, 212 + n * 38, 240 + n * 14, 205];
});
registerTex('lava', (x, y) => {
  const n = fbm(x * 0.4, y * 0.4, 3, 301);
  const h = Math.sin((x + y) * 0.35 + n * 7) * 0.5 + 0.5;
  return [190 + h * 65, 52 + h * 150, 16 + h * 34];
});
registerTex('snow', (x, y) => {
  const n = hash2i(x, y, 201) * 0.5 + fbm(x * 0.5, y * 0.5, 2, 202) * 0.5;
  return [228 + n * 26, 234 + n * 22, 244 + n * 12];
});

/* 海晶石系列 */
registerTex('prismarine', (x, y) => {
  const n = fbm(x * 0.5, y * 0.5, 3, 211);
  const n2 = hash2i(x, y, 212) * 0.3;
  return [58 + n * 66 + n2 * 16, 148 + n * 72, 138 + n * 64];
});
registerTex('prismarine_bricks', (x, y, S) => {
  const bw = Math.max(4, Math.round(S / 3));
  const bh = Math.max(3, Math.round(S / 4.5));
  const bx = Math.floor(x / bw), by = Math.floor(y / bh);
  const off = (by % 2) * Math.floor(bw / 2);
  if ((x + off) % bw === 0 || y % bh === 0) return [36, 104, 100];
  const n = hash2i(bx, by, 221);
  return [84 + n * 46, 172 + n * 54, 156 + n * 48];
});
registerTex('dark_prismarine', (x, y) => {
  const n = fbm(x * 0.6, y * 0.6, 3, 231);
  return [26 + n * 32, 62 + n * 44, 62 + n * 44];
});
registerTex('sea_lantern', (x, y, S) => {
  const cw = Math.max(2, Math.round(S / 5.5));
  const cx = Math.floor(x / cw), cy = Math.floor(y / cw);
  const on = (cx + cy) % 2 === 0;
  const n = hash2i(x, y, 241) * 0.2;
  return on ? [204 + n * 30, 250, 226 + n * 20] : [128 + n * 30, 220 + n * 24, 202 + n * 24];
});
registerTex('glowstone', (x, y) => {
  const n = hash2i(x, y, 251);
  const n2 = fbm(x * 0.7, y * 0.7, 2, 252);
  return [216 + n * 38, 172 + n2 * 70 + n * 30, 68 + n2 * 70 + n * 40];
});

registerTex('diamond', (x, y) => {
  const n = fbm(x * 0.6, y * 0.6, 2, 261);
  const spark = hash2i(x, y, 262) > 0.90 ? 110 : 0;
  return [56 + n * 54 + spark, 196 + n * 58 + spark, 196 + n * 52 + spark];
});
registerTex('gold', (x, y) => {
  const n = fbm(x * 0.6, y * 0.6, 2, 271);
  const s = hash2i(x, y, 272) > 0.9 ? 70 : 0;
  return [226 + n * 28 + s, 174 + n * 52 + s, 36 + n * 42 + s * 0.6];
});
registerTex('cactus', (x, y, S) => {
  const n = hash2i(x, y, 281);
  const sp = Math.max(2, Math.round(S / 4));
  if (x % sp === 1 && y % sp === 1) return [232, 234, 196];
  return [44 + n * 42, 112 + n * 62, 56 + n * 34];
});
registerTex('obsidian', (x, y) => {
  const n = fbm(x * 0.7, y * 0.7, 3, 291);
  const s = hash2i(x, y, 292) > 0.94 ? 52 : 0;
  return [22 + n * 28 + s, 14 + n * 22 + s * 0.6, 38 + n * 42 + s];
});
registerTex('bedrock', (x, y, S) => {
  const c = Math.max(1, Math.round(S / 9));
  const n = hash2i(Math.floor(x / c), Math.floor(y / c), 311);
  const n2 = hash2i(x, y, 312);
  return [38 + n * 52 + n2 * 16, 38 + n * 52 + n2 * 16, 44 + n * 52 + n2 * 16];
});
registerTex('stone_bricks', (x, y, S) => {
  const bh = Math.max(3, Math.round(S / 4));
  const bw = bh * 2;
  const by = Math.floor(y / bh);
  const off = (by % 2) * Math.floor(bw / 2);
  if ((x + off) % bw === 0 || y % bh === 0) return [92, 92, 98];
  const n = hash2i(Math.floor(x / bw), by, 321);
  return [126 + n * 34, 126 + n * 34, 132 + n * 34];
});
/* 青石砖：石砖 + 苔藓覆层 */
registerTex('mossy_stone_bricks', (x, y, S) => {
  const bh = Math.max(3, Math.round(S / 4));
  const bw = bh * 2;
  const by = Math.floor(y / bh);
  const off = (by % 2) * Math.floor(bw / 2);
  const moss = fbm(x * 0.26, y * 0.26, 2, 341);
  const n = hash2i(Math.floor(x / bw), by, 321);
  if ((x + off) % bw === 0 || y % bh === 0){
    const m = 62 - moss * 26;
    return [m * 0.9, m, m * 0.86];
  }
  const base = 118 + n * 30;
  const green = moss * 58;
  return [base * (1 - moss * 0.5), base * (1 - moss * 0.12) + green, base * (1 - moss * 0.55)];
});
registerTex('mossy_stone', (x, y, S) => {
  const c = Math.max(2, Math.round(S / 4));
  const n = hash2i(Math.floor(x / c), Math.floor(y / c), 331);
  const moss = fbm(x * 0.3, y * 0.3, 2, 332);
  const base = 112 + n * 36;
  return [base * (1 - moss * 0.68), base * (1 - moss * 0.15) + moss * 34, base * (1 - moss * 0.78)];
});

/* 合成材料 */
registerTex('stick', (x, y, S) => {
  const c = (S - 1) / 2;
  const k = S / 28;
  const inStick = Math.abs(x - c) < k * (3 + Math.sin(y / k * 0.4) * 0.8);
  if (!inStick) return [0, 0, 0, 0];
  const n = hash2i(x, y, 401);
  return [130 + n * 40, 90 + n * 30, 50 + n * 20];
});
registerTex('coal', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.hypot(x - c, y - c);
  if (d > S * 11 / 28) return [0, 0, 0, 0];
  const n = hash2i(x, y, 411);
  return [26 + n * 30, 26 + n * 30, 30 + n * 30];
});
registerTex('iron_ingot', (x, y, S) => {
  const k = S / 28;
  if (x < 6 * k || x > 21 * k || y < 10 * k || y > 19 * k) return [0, 0, 0, 0];
  const n = hash2i(x, y, 421);
  return [188 + n * 40, 188 + n * 40, 196 + n * 40];
});
registerTex('copper_ingot', (x, y, S) => {
  const k = S / 28;
  if (x < 6 * k || x > 21 * k || y < 10 * k || y > 19 * k) return [0, 0, 0, 0];
  const n = hash2i(x, y, 425);
  return [196 + n * 40, 108 + n * 34, 54 + n * 26];
});
registerTex('gold_ingot', (x, y, S) => {
  const k = S / 28;
  if (x < 6 * k || x > 21 * k || y < 10 * k || y > 19 * k) return [0, 0, 0, 0];
  const n = hash2i(x, y, 431);
  return [226 + n * 30, 174 + n * 50, 36 + n * 40];
});
registerTex('diamond_gem', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.abs(x - c) + Math.abs(y - c);
  if (d > S * 10 / 28) return [0, 0, 0, 0];
  const n = hash2i(x, y, 441);
  const spark = hash2i(x, y, 442) > 0.85 ? 60 : 0;
  return [56 + n * 54 + spark, 196 + n * 58 + spark, 196 + n * 52 + spark];
});

/* 线 / 箭 */
registerCanvasTex('string', (ctx, S) => {
  const s = S / 16;
  ctx.save(); ctx.scale(s, s);
  ctx.strokeStyle = '#e8e8e0'; ctx.lineWidth = 1.1; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(4, 2.5); ctx.quadraticCurveTo(10, 7, 5, 13.5); ctx.stroke();
  ctx.strokeStyle = '#c8c8c0'; ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.moveTo(5.5, 2.8); ctx.quadraticCurveTo(11.5, 7.2, 6.5, 13); ctx.stroke();
  ctx.restore();
});
registerCanvasTex('arrow', (ctx, S) => {
  const s = S / 16;
  ctx.save(); ctx.scale(s, s);
  ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(2.5, 13.5); ctx.lineTo(12.5, 3.5); ctx.stroke();
  ctx.fillStyle = '#c8c8d4'; ctx.strokeStyle = '#8a8a98'; ctx.lineWidth = 0.5;
  ctx.beginPath(); ctx.moveTo(15, 1); ctx.lineTo(10.5, 3); ctx.lineTo(13, 5.5);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = '#e8e8e8'; ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.moveTo(2.5, 10.2); ctx.lineTo(5.8, 13.5); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(4.2, 8.5); ctx.lineTo(7.5, 11.8); ctx.stroke();
  ctx.restore();
});

/* 矿石 */
/* [ores-split] oreTex 工厂已删除（4 种矿石已独立） */
registerCanvasTex('coal_ore', (ctx, S) => {
  const spotColor = [20, 20, 24];
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    if (hash2i(x, y, 44) > 0.97) v += 10;
    let isBlob = false;
    for (let i = 0; i < 5; i++){
      const cx = 2 + hash2i(i, 0, 76791) * 12;
      const cy = 2 + hash2i(i, 1, 76791) * 12;
      const r = 2.38 * (0.6 + hash2i(i, 2, 76791) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 76891 + i) - 0.5) * 1.305;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const bright = 1.097 - t * 0.433;
        const pn = (hash2i(x, y, 76991 + i) - 0.5) * 34.554;
        const i4 = (y * S + x) * 4;
        d[i4]     = Math.max(0, Math.min(255, Math.round(spotColor[0] * bright + pn)));
        d[i4 + 1] = Math.max(0, Math.min(255, Math.round(spotColor[1] * bright + pn)));
        d[i4 + 2] = Math.max(0, Math.min(255, Math.round(spotColor[2] * bright + pn)));
        d[i4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      const i4 = (y * S + x) * 4;
      d[i4]     = Math.max(0, Math.min(255, Math.round(v)));
      d[i4 + 1] = Math.max(0, Math.min(255, Math.round(v + 1)));
      d[i4 + 2] = Math.max(0, Math.min(255, Math.round(v + 5)));
      d[i4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});
registerCanvasTex('iron_ore', (ctx, S) => {
  const spotColor = [180, 130, 90];
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    if (hash2i(x, y, 44) > 0.97) v += 10;
    let isBlob = false;
    for (let i = 0; i < 6; i++){
      const cx = 2 + hash2i(i, 0, 51363) * 12;
      const cy = 2 + hash2i(i, 1, 51363) * 12;
      const r = 1.865 * (0.6 + hash2i(i, 2, 51363) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 51463 + i) - 0.5) * 1.132;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const bright = 1.347 - t * 0.363;
        const pn = (hash2i(x, y, 51563 + i) - 0.5) * 54.628;
        const i4 = (y * S + x) * 4;
        d[i4]     = Math.max(0, Math.min(255, Math.round(spotColor[0] * bright + pn)));
        d[i4 + 1] = Math.max(0, Math.min(255, Math.round(spotColor[1] * bright + pn)));
        d[i4 + 2] = Math.max(0, Math.min(255, Math.round(spotColor[2] * bright + pn)));
        d[i4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      const i4 = (y * S + x) * 4;
      d[i4]     = Math.max(0, Math.min(255, Math.round(v)));
      d[i4 + 1] = Math.max(0, Math.min(255, Math.round(v + 1)));
      d[i4 + 2] = Math.max(0, Math.min(255, Math.round(v + 5)));
      d[i4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});
registerCanvasTex('copper_ore', (ctx, S) => {
  const spotColor = [206, 116, 58];
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    if (hash2i(x, y, 44) > 0.97) v += 10;
    let isBlob = false;
    for (let i = 0; i < 7; i++){
      const cx = 2 + hash2i(i, 0, 61741) * 12;
      const cy = 2 + hash2i(i, 1, 61741) * 12;
      const r = 2.12 * (0.6 + hash2i(i, 2, 61741) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 61841 + i) - 0.5) * 1.22;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const bright = 1.24 - t * 0.42;
        const pn = (hash2i(x, y, 61941 + i) - 0.5) * 42.18;
        const i4 = (y * S + x) * 4;
        d[i4]     = Math.max(0, Math.min(255, Math.round(spotColor[0] * bright + pn)));
        d[i4 + 1] = Math.max(0, Math.min(255, Math.round(spotColor[1] * bright + pn)));
        d[i4 + 2] = Math.max(0, Math.min(255, Math.round(spotColor[2] * bright + pn)));
        d[i4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      const i4 = (y * S + x) * 4;
      d[i4]     = Math.max(0, Math.min(255, Math.round(v)));
      d[i4 + 1] = Math.max(0, Math.min(255, Math.round(v + 1)));
      d[i4 + 2] = Math.max(0, Math.min(255, Math.round(v + 5)));
      d[i4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});
registerCanvasTex('gold_ore', (ctx, S) => {
  const spotColor = [230, 190, 50];
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    if (hash2i(x, y, 44) > 0.97) v += 10;
    let isBlob = false;
    for (let i = 0; i < 9; i++){
      const cx = 2 + hash2i(i, 0, 70586) * 12;
      const cy = 2 + hash2i(i, 1, 70586) * 12;
      const r = 2.694 * (0.6 + hash2i(i, 2, 70586) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 70686 + i) - 0.5) * 1.411;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const bright = 1.452 - t * 0.669;
        const pn = (hash2i(x, y, 70786 + i) - 0.5) * 28.144;
        const i4 = (y * S + x) * 4;
        d[i4]     = Math.max(0, Math.min(255, Math.round(spotColor[0] * bright + pn)));
        d[i4 + 1] = Math.max(0, Math.min(255, Math.round(spotColor[1] * bright + pn)));
        d[i4 + 2] = Math.max(0, Math.min(255, Math.round(spotColor[2] * bright + pn)));
        d[i4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      const i4 = (y * S + x) * 4;
      d[i4]     = Math.max(0, Math.min(255, Math.round(v)));
      d[i4 + 1] = Math.max(0, Math.min(255, Math.round(v + 1)));
      d[i4 + 2] = Math.max(0, Math.min(255, Math.round(v + 5)));
      d[i4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});
registerCanvasTex('diamond_ore', (ctx, S) => {
  const spotColor = [100, 230, 230];
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    if (hash2i(x, y, 44) > 0.97) v += 10;
    let isBlob = false;
    for (let i = 0; i < 7; i++){
      const cx = 2 + hash2i(i, 0, 40986) * 12;
      const cy = 2 + hash2i(i, 1, 40986) * 12;
      const r = 1.463 * (0.6 + hash2i(i, 2, 40986) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 41086 + i) - 0.5) * 0.932;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const bright = 1.179 - t * 0.37;
        const pn = (hash2i(x, y, 41186 + i) - 0.5) * 52.064;
        const i4 = (y * S + x) * 4;
        d[i4]     = Math.max(0, Math.min(255, Math.round(spotColor[0] * bright + pn)));
        d[i4 + 1] = Math.max(0, Math.min(255, Math.round(spotColor[1] * bright + pn)));
        d[i4 + 2] = Math.max(0, Math.min(255, Math.round(spotColor[2] * bright + pn)));
        d[i4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      const i4 = (y * S + x) * 4;
      d[i4]     = Math.max(0, Math.min(255, Math.round(v)));
      d[i4 + 1] = Math.max(0, Math.min(255, Math.round(v + 1)));
      d[i4 + 2] = Math.max(0, Math.min(255, Math.round(v + 5)));
      d[i4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});

/* 工作台 */
registerTex('crafting_table_top', (x, y, S) => {
  if (x === 0 || y === 0 || x === S - 1 || y === S - 1) return [80, 60, 40];
  const mid = Math.floor(S / 2);
  if (x === mid || y === mid) return [100, 76, 50];
  const n = hash2i(x, y, 541);
  return [156 + n * 30, 118 + n * 24, 72 + n * 18];
});
registerTex('crafting_table_side', (x, y, S) => {
  const topH = Math.max(3, Math.round(S * 6 / 28));
  if (y < topH){
    const n = hash2i(x, y, 541);
    return [156 + n * 30, 118 + n * 24, 72 + n * 18];
  }
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [80, 60, 40];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 111);
  const y0 = Math.round(S * 10 / 28), y1 = Math.round(S * 22 / 28);
  const x0 = Math.round(S * 8 / 28),  x1 = Math.round(S * 20 / 28);
  if (y > y0 && y < y1 && x > x0 && x < x1){
    return [170 + n * 30, 130 + n * 24, 80 + n * 18];
  }
  return [140 + n * 40, 100 + n * 30, 60 + n * 22];
});

/* 熔炉 */
registerTex('furnace_side', (x, y) => {
  const g = hash2i(x, y, 481);
  const n = fbm(x * 0.45, y * 0.45, 2, 482);
  return [104 + n * 40 + g * 10, 104 + n * 38 + g * 10, 108 + n * 36 + g * 10];
});
registerTex('furnace_top', (x, y, S) => {
  const g = hash2i(x, y, 483);
  const c = (S - 1) / 2;
  const d = Math.hypot(x - c, y - c);
  if (d < S * 6 / 28) return [58 + g * 22, 56 + g * 20, 60 + g * 22];
  const n = fbm(x * 0.45, y * 0.45, 2, 484);
  return [108 + n * 38 + g * 10, 108 + n * 36 + g * 10, 112 + n * 34 + g * 10];
});
registerTex('furnace_front', (x, y, S) => {
  const g = hash2i(x, y, 485);
  const n = fbm(x * 0.45, y * 0.45, 2, 486);
  const k = S / 28;
  if (x > 5 * k && x < 23 * k && y > 12 * k && y < 26 * k){
    const inner = (x > 7 * k && x < 21 * k && y > 14 * k && y < 24 * k);
    if (inner) return [32 + g * 16, 26 + g * 12, 24 + g * 12];
    return [62 + g * 20, 58 + g * 18, 58 + g * 20];
  }
  return [104 + n * 40 + g * 10, 104 + n * 38 + g * 10, 108 + n * 36 + g * 10];
});
/* 熔炉（燃烧中）：同一个炉口，内部是橙红色火光 */
registerTex('furnace_front_lit', (x, y, S) => {
  const g = hash2i(x, y, 487);
  const n = fbm(x * 0.45, y * 0.45, 2, 488);
  const k = S / 28;
  if (x > 5 * k && x < 23 * k && y > 12 * k && y < 26 * k){
    const inner = (x > 7 * k && x < 21 * k && y > 14 * k && y < 24 * k);
    if (inner){
      /* 火焰从炉底往上舔：越靠下越亮，每列高度带一点随机跳动 */
      const col = Math.floor(x / k);
      const top = 14 * k + hash2i(col, 0, 489) * 3 * k;
      const t = Math.max(0, Math.min(1, (y - top) / Math.max(1, 24 * k - top)));
      const flick = hash2i(x, y, 490) * 0.18;
      return [
        Math.min(255, 205 + t * 50 + flick * 60),
        Math.min(255, 70 + t * 150 + flick * 50),
        Math.min(255, 18 + t * 52 + flick * 20),
      ];
    }
    return [62 + g * 20, 58 + g * 18, 58 + g * 20];
  }
  return [104 + n * 40 + g * 10, 104 + n * 38 + g * 10, 108 + n * 36 + g * 10];
});

/* 火把
   ------------------------------------------------------------
   模型是个 2×10 的木棍 + 4×5 的火头，贴图会被按箱子尺寸裁切取样，
   所以两张图都画满整格，保证任何子区域取出来都是正确的颜色。 */
registerTex('torch_stick', (x, y) => {
  const n = hash2i(x, y, 491);
  const grain = ((x + y) % 4 === 0) ? 0.80 : 1;
  return [(152 + n * 22) * grain, (106 + n * 16) * grain, (58 + n * 12) * grain, 255];
});
/* 物品栏图标：带火苗的火把剪影（模型贴图另用上面两张） */
registerTex('torch', (x, y, S) => {
  const k = S / 16;
  const px = x / k, py = y / k;
  const n = hash2i(x, y, 493);
  /* 火苗（以 7.5, 3.2 为圆心） */
  const dx = px - 7.5, dy = py - 3.2;
  const d = Math.sqrt(dx * dx + dy * dy * 1.15);
  if (d < 1.7) return [255, 248, 214, 255];
  if (d < 2.9) return [255, 205 + n * 30, 80, 255];
  if (d < 4.1) return [240, 120 + n * 40, 24, 255];
  /* 木棍 */
  if (px >= 6.8 && px <= 9.2 && py >= 6 && py <= 15){
    return [150 + n * 20, 104 + n * 14, 56 + n * 10, 255];
  }
  return [0, 0, 0, 0];
});
registerTex('torch_flame', (x, y, S) => {
  const n = hash2i(x, y, 492);
  /* 底部橙红 → 顶部亮黄，加一点跳动的噪点 */
  const t = y / Math.max(1, S - 1);
  return [
    Math.min(255, 226 + t * 26 + n * 16),
    Math.min(255, 96 + t * 120 + n * 30),
    Math.min(255, 22 + t * 48 + n * 16),
    255,
  ];
});

/* 箱子
   ------------------------------------------------------------
   chest_side 只画木板 + 边框，锁扣改由 chest_latch 的独立小模型绘制，
   这样开箱时金属扣能跟着箱盖一起动。 */
registerTex('chest_side', (x, y, S) => {
  const k = S / 28;
  /* 左右深色木框 + 上下包边 */
  if (x < 2 * k || x > S - 1 - 2 * k) return [76, 52, 32];
  if (y < k || y > S - 1 - k) return [86, 58, 36];

  /* 竖向木板纹 */
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(x / pw);
  if (x % pw === 0) return [92, 62, 38];
  const n = fbm(y * 0.35, x * 0.9, 2, 491);
  /* 上亮下暗的轻微渐变，让木板更有厚度感 */
  const grad = 1.0 - (y / S) * 0.10;
  return [(150 + n * 34 + plank * 3) * grad,
          (104 + n * 28 + plank * 3) * grad,
          (58 + n * 20) * grad];
});
registerTex('chest_top', (x, y, S) => {
  const k = S / 28;
  if (x < 2 * k || y < 2 * k || x > S - 1 - 2 * k || y > S - 1 - 2 * k){
    return [76, 52, 32];
  }
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [92, 62, 38];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 493);
  const grad = 1.0 - (x / S) * 0.06;
  return [(154 + n * 32) * grad, (108 + n * 26) * grad, (62 + n * 20) * grad];
});
/* 金属锁扣贴图（银色锭面 + 深色锁孔） */
registerTex('chest_latch', (x, y, S) => {
  const k = S / 28;
  const edge = (x < 2 * k || x > S - 1 - 2 * k || y < k || y > S - 1 - k);
  if (edge) return [58, 58, 66];
  const g = hash2i(x, y, 494);
  /* 左上高光，右下阴影 */
  const hi = (x * 0.5 + y * 0.5 < S * 0.42) ? 26 : 0;
  const lo = (x * 0.5 + y * 0.5 > S * 0.62) ? 22 : 0;
  const v = 178 + g * 30 + hi - lo;
  const cx = Math.floor(S / 2), cy = S * 0.58;
  const d = Math.abs(x - cx) + Math.abs(y - cy);
  if (d < S * 0.13) return [46 + g * 16, 46 + g * 14, 52 + g * 14];  /* 锁孔 */
  return [v, v + 4, v + 10];
});

/* 羊毛 / 木炭 */
registerTex('wool', (x, y) => {
  const g = fbm(x * 0.5, y * 0.5, 3, 471);
  const n = hash2i(x, y, 472);
  const v = 226 + g * 24 + n * 8;
  return [v, v * 0.985, v * 0.94];
});

/* ★ 床：红色被子顶面（绗缝线 + 轻微布纹），四周压暗一圈 */
registerTex('bed_top', (x, y) => {
  const n = hash2i(x, y, 731);
  let r = 172 + n * 14, g = 48 + n * 10, b = 56 + n * 10;
  if (x === 0 || y === 0 || x === 15 || y === 15){ r *= 0.76; g *= 0.76; b *= 0.76; }
  if (y % 5 === 0 && y > 2){ r *= 0.9; g *= 0.88; b *= 0.88; }
  if (x % 7 === 3 && y > 2 && y < 14){ r *= 0.92; }
  return [r, g, b];
});
registerTex('charcoal', (x, y, S) => {
  const g = hash2i(x, y, 461);
  const c = (S - 1) / 2;
  const d = Math.hypot((x - c) / (S * 0.39), (y - c) / (S * 0.36));
  if (d > 1.0) return [0, 0, 0, 0];
  const sh = 0.7 + g * 0.85;
  return [40 * sh + g * 18, 38 * sh + g * 16, 42 * sh + g * 18];
});

/* ============================================================
   水草 / 陆地草 / 花草
   ============================================================ */
function grassCluster(seed, palette, tStart, tEnd){
  const [colA, colB, colC] = palette;
  return (x, y, S) => {
    const cx = (S - 1) / 2;
    const ty = 1 - y / (S - 1);
    const t  = tStart + (tEnd - tStart) * ty;
    const k = S / 28;
    for (let i = 0; i < 6; i++){
      const r1 = hash2i(i, 11, seed);
      const r2 = hash2i(i, 22, seed);
      const r3 = hash2i(i, 33, seed);
      const r4 = hash2i(i, 44, seed);
      const r5 = hash2i(i, 55, seed);
      const x0 = cx + (r1 - 0.5) * S * 0.82;
      const drift = (r2 - 0.5) * S * 0.22;
      const top = 0.60 + r4 * 0.37;
      if (t > top) continue;
      const tt = t / top;
      const px = x0 + drift * tt;
      const wobble = Math.sin(tt * Math.PI + r5 * 6.28) * 0.30 * k;
      const width = (1.1 + r3 * 0.45) * k * (1 - tt * 0.60);
      const d = Math.abs(x - px - wobble);
      if (d >= width) continue;
      const g = hash2i(x, y, seed + i * 37);
      const c = g < 0.33 ? colA : (g < 0.70 ? colB : colC);
      const edge = 1 - d / width;
      const sh = 0.72 + g * 0.16 + edge * 0.20;
      return [c[0] * sh, c[1] * sh, c[2] * sh];
    }
    return [0, 0, 0, 0];
  };
}

function grassBlades(seed, palette, tStart, tEnd){
  const [colA, colB, colC] = palette;
  return (x, y, S) => {
    const cx = (S - 1) / 2;
    const ty = 1 - y / (S - 1);
    const t  = tStart + (tEnd - tStart) * ty;
    /* 9 根草叶：每根一个确定色调 + 连续明暗，避免逐像素跳色变成碎点 */
    for (let i = 0; i < 9; i++){
      const r1 = hash2i(i, 11, seed);
      const r2 = hash2i(i, 22, seed);
      const r3 = hash2i(i, 33, seed);
      const r4 = hash2i(i, 44, seed);
      const x0 = cx + (r1 - 0.5) * S * 0.94;
      const top = 0.40 + r4 * 0.58;
      if (t > top) continue;
      const tt = t / top;
      const amp = (r2 - 0.5) * S * 0.46;
      const bend = amp * Math.sin(Math.PI * Math.pow(tt, 1.2));
      const px = x0 + bend;
      /* 用像素宽度而不是 k 宽度，并保底 1px，避免弯折时某一行
         一根像素都没有、贴图变成一串断点 */
      const w0 = 1.30 + r3 * 0.55;
      const width = Math.max(0.95, w0 * (1 - tt * 0.72));
      const d = Math.abs(x - px);
      if (d >= width) continue;
      const base = (i % 3 === 0) ? colA : (i % 3 === 1 ? colB : colC);
      const edge = 1 - d / width;
      const g = hash2i(x, y, seed + i * 37);
      /* 根部暗、尖端亮，叶缘略暗，形成有厚度的叶片 */
      const sh = 0.70 + tt * 0.32 + edge * 0.10 + (g - 0.5) * 0.10;
      return [base[0] * sh, base[1] * sh, base[2] * sh];
    }
    return [0, 0, 0, 0];
  };
}

/* 海带：一条贯穿上下的宽茎带 + 两片错开的小叶尖。
   弯曲与宽度在贴图上下边缘归零/一致，所以叠几格也始终对齐、不会断开。 */
function kelpSprite(seed){
  return (x, y, S) => {
    const k = S / 28;
    const cx = (S - 1) / 2;
    const t = y / (S - 1);
    const bend = Math.sin(t * Math.PI * 2) * 1.25 * k;
    const sx = cx + bend;
    const g = hash2i(x, y, seed);

    const stalkW = (1.9 + 0.6 * Math.sin(t * Math.PI)) * k;
    if (Math.abs(x - sx) < stalkW){
      const edge = 1 - Math.abs(x - sx) / stalkW;
      const sh = 0.66 + edge * 0.26 + (g - 0.5) * 0.06;
      return [58 * sh, 118 * sh, 54 * sh];
    }

    /* 两条短叶尖错开挂在茎上，增加海带的辨识度，又不至于每格都像树枝 */
    for (let i = 0; i < 2; i++){
      const ly = 0.30 + i * 0.42;
      const side = (i % 2 === 0) ? 1 : -1;
      const bx = sx, by = ly * (S - 1);
      const len = (8.5 - i * 0.6) * k;
      const tx = bx + side * len;
      const ty = by - (0.20 + i * 0.02) * (S - 1);
      const vx = tx - bx, vy = ty - by;
      const wx = x - bx, wy = y - by;
      const L2 = vx * vx + vy * vy;
      if (L2 < 0.0001) continue;
      const u = (wx * vx + wy * vy) / L2;
      if (u < 0 || u > 1) continue;
      const px = bx + vx * u, py = by + vy * u;
      const dist = Math.hypot(x - px, y - py);
      const hw = (2.1 - i * 0.15) * k * Math.sin(Math.PI * Math.pow(u, 0.65));
      if (dist < hw){
        const edge = 1 - dist / hw;
        const sh = 0.62 + u * 0.24 + edge * 0.16 + (g - 0.5) * 0.08;
        return [62 * sh, 126 * sh, 56 * sh];
      }
    }
    return [0, 0, 0, 0];
  };
}

/* 海草：短、密、亮绿，没有贯穿茎，和海带明显区分 */
const SEAGRASS_PAL = [[62, 176, 104], [92, 202, 126], [46, 142, 82]];

// 水草调色板保留原色（或稍微调亮），陆地草使用高亮灰白色
const SEA_PAL  = [[42,122,68],[58,148,86],[36,102,56]];
const GRAY_PAL = [[200, 200, 200], [240, 240, 240], [160, 160, 160]];

registerTex('tall_grass',       __maybeVoid(grassBlades(411, GRAY_PAL, 0.00, 0.92)));
registerTex('fern',             __maybeVoid(grassBlades(412, GRAY_PAL, 0.00, 0.88)));
registerTex('double_grass',     __maybeVoid(grassBlades(411, GRAY_PAL, 0.00, 0.50)));
registerTex('double_grass_top', __maybeVoid(grassBlades(411, GRAY_PAL, 0.50, 1.00)));
registerTex('double_fern',      __maybeVoid(grassBlades(412, GRAY_PAL, 0.00, 0.50)));
registerTex('double_fern_top',  __maybeVoid(grassBlades(412, GRAY_PAL, 0.50, 1.00)));

registerTex('seagrass', __maybeVoid(grassBlades(431, SEAGRASS_PAL, 0.00, 0.72)));
registerTex('kelp',     __maybeVoid(kelpSprite(432)));

function flowerSprite(o){
  const petal = o.petal, petal2 = o.petal2 || o.petal, core = o.core;
  const seed = o.seed, lobes = o.lobes || 5;
  return (x, y, S) => {
    const g = hash2i(x, y, seed);
    const cx = (S - 1) / 2;
    const cy = S * 0.28;
    const k = S / 28;
    const dx = x - cx, dy = y - cy;
    const d = Math.sqrt(dx * dx + dy * dy);

    /* 花心：内暗外亮，避免糊成一粒色块 */
    if (d < 2.1 * k){
      const sh = 0.78 + g * 0.20 + (d < 1.0 * k ? -0.10 : 0.08);
      return [core[0] * sh, core[1] * sh, core[2] * sh];
    }

    /* 花瓣：带缺口的星形 + 边缘压暗 + 受光侧提亮 */
    const ang = Math.atan2(dy, dx);
    const rr = (3.9 + Math.cos(ang * lobes) * 2.45 + Math.cos(ang * 3 + 0.7) * 0.45) * k;
    if (d < rr){
      const edge = rr - d;
      if (edge < 0.55 * k){
        const c = petal2;
        const sh = 0.62 + g * 0.14;
        return [c[0] * sh, c[1] * sh, c[2] * sh];
      }
      const c = (g < 0.5 ? petal : petal2);
      const lit = (dx * -0.45 + dy * -0.9) > 0 ? 0.16 : 0;
      const sh = 0.86 + g * 0.22 + lit;
      return [c[0] * sh, c[1] * sh, c[2] * sh];
    }

    /* 花茎：轻微弯曲，底部更暗 */
    const bend = Math.sin((y / S) * Math.PI * 0.9) * 0.8 * k;
    const stemX = cx + bend;
    if (Math.abs(x - stemX) < 0.85 * k && y > cy && y < S){
      const sh = 0.72 + g * 0.18 + (y > S * 0.7 ? -0.10 : 0);
      return [58 * sh, 122 * sh, 46 * sh];
    }

    /* 两片叶子 */
    for (let i = 0; i < 2; i++){
      const ly = S * (0.55 + i * 0.15);
      const side = (i === 0) ? -1 : 1;
      const along = (x - stemX) * side;
      const len = (4.6 - i * 0.8) * k;
      if (y > ly && y < ly + 3.0 * k && along > 0.5 * k && along < len){
        const u = along / len;
        const sh = 0.70 + g * 0.16 + (1 - u) * 0.12;
        return [52 * sh, 116 * sh, 44 * sh];
      }
    }
    return [0, 0, 0, 0];
  };
}

registerTex('dandelion',   __maybeVoid(flowerSprite({ seed:401, lobes:6, petal:[246,214,58],  petal2:[228,182,34], core:[252,240,150] })));
registerTex('poppy',       __maybeVoid(flowerSprite({ seed:402, lobes:5, petal:[212,58,50],   petal2:[176,36,34],  core:[248,214,96] })));
registerTex('cornflower',  __maybeVoid(flowerSprite({ seed:403, lobes:6, petal:[92,120,224],  petal2:[64,88,190],  core:[186,200,248] })));
registerTex('tulip',       __maybeVoid(flowerSprite({ seed:404, lobes:4, petal:[232,120,64],  petal2:[204,86,44],  core:[246,196,120] })));
registerTex('oxeye_daisy', __maybeVoid(flowerSprite({ seed:405, lobes:8, petal:[242,244,236], petal2:[214,218,210],core:[248,206,64] })));
registerTex('allium',      __maybeVoid(flowerSprite({ seed:406, lobes:7, petal:[168,96,206],  petal2:[136,68,176], core:[212,168,238] })));

function saplingSprite(seed){
  const TRUNK = [[96, 64, 36], [120, 84, 48], [76, 50, 28]];
  const LEAF  = [[50, 118, 54], [68, 150, 70], [38, 94, 44]];
  return (x, y, S) => {
    const g = hash2i(x, y, seed);
    const cx = (S - 1) / 2;
    const k = S / 28;
    const trunkW = (0.9 + g * 0.12) * k;
    /* 树干：从树冠下方一直延伸到底部 */
    if (Math.abs(x - cx) < trunkW && y > S * 0.40){
      const c = TRUNK[g < 0.33 ? 0 : (g < 0.68 ? 1 : 2)];
      return [c[0], c[1], c[2]];
    }
    /* 顶部树冠：椭圆 + 少量锯齿边缘 */
    const dx = (x - cx) / (6.4 * k);
    const dy = (y - S * 0.28) / (5.0 * k);
    const d = dx * dx + dy * dy;
    if (d < 1 + (g - 0.5) * 0.18){
      const c = LEAF[g < 0.33 ? 0 : (g < 0.68 ? 1 : 2)];
      const sh = 0.82 + g * 0.30;
      return [c[0] * sh, c[1] * sh, c[2] * sh];
    }
    return [0, 0, 0, 0];
  };
}

registerTex('sapling', __maybeVoid(saplingSprite(413)));

registerCanvasTex('lily_pad', (ctx, S) => {
  const c = S / 2;
  for (let y = 0; y < S; y++){
    for (let x = 0; x < S; x++){
      const dx = x - c + 0.5, dy = y - c + 0.5;
      const d = Math.hypot(dx, dy);
      const ang = Math.atan2(dy, dx);
      const notch = Math.abs(ang - Math.PI / 2) < 0.42;
      if (d < S * 0.46 && !notch){
        const g = hash2i(x, y, 421);
        const rim = d > S * 0.36 ? 16 : 0;
        ctx.fillStyle = `rgb(${44 + g*22 + rim},${104 + g*34 + rim},${40 + g*20 + rim})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }
});

/* ============================================================
   工具图标
   ============================================================ */
const MAT_COLORS = {
  wood:    { main: '#a87038', dark: '#6a4418', light: '#c89058', edge: '#8a5420' },
  stone:   { main: '#909090', dark: '#5a5a5a', light: '#b8b8b8', edge: '#6a6a6a' },
  copper:  { main: '#c87a3c', dark: '#7a4a20', light: '#e8a060', edge: '#9a5a28' },
  iron:    { main: '#d0d0d8', dark: '#808090', light: '#e8e8f0', edge: '#9a9aaa' },
  diamond: { main: '#5ee0e0', dark: '#2a8a8a', light: '#9af0f0', edge: '#3ab0b0' },
  gold:    { main: '#f0d040', dark: '#a08010', light: '#ffe888', edge: '#c0a020' },
  ancient: { main: '#8a99a2', dark: '#4a565e', light: '#c2d0d8', edge: '#65727a' },
};

function drawHandle(ctx){
  ctx.strokeStyle = '#7a4a1e'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(3.5, 13.5); ctx.lineTo(10, 7); ctx.stroke();
  ctx.strokeStyle = '#a06a2e'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.moveTo(3.5, 12.9); ctx.lineTo(9.7, 6.6); ctx.stroke();
}

function drawToolIcon(ctx, S, material, type){
  const s = S / 16;
  ctx.save(); ctx.scale(s, s);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const mc = MAT_COLORS[material];
  if (type === 'pickaxe'){
    drawHandle(ctx, mc);
    ctx.fillStyle = mc.main; ctx.strokeStyle = mc.dark; ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(2, 6.5); ctx.quadraticCurveTo(5, 3.5, 8.5, 3);
    ctx.quadraticCurveTo(12, 3.5, 15, 6.5);
    ctx.quadraticCurveTo(12, 5.5, 8.5, 5.5);
    ctx.quadraticCurveTo(5, 5.5, 2, 6.5);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = mc.light; ctx.lineWidth = 0.6;
    ctx.beginPath(); ctx.moveTo(3, 6); ctx.quadraticCurveTo(6, 4, 8.5, 3.8); ctx.stroke();
  } else if (type === 'axe'){
    drawHandle(ctx, mc);
    ctx.fillStyle = mc.main; ctx.strokeStyle = mc.dark; ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(7.5, 2.5); ctx.quadraticCurveTo(13.5, 1, 15, 5.5);
    ctx.quadraticCurveTo(15, 8.5, 11, 9.5);
    ctx.lineTo(8, 6.5); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = mc.light; ctx.lineWidth = 0.6;
    ctx.beginPath(); ctx.moveTo(9, 3.2); ctx.quadraticCurveTo(13, 2.5, 14, 5); ctx.stroke();
  } else if (type === 'sword'){
    ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(3, 14); ctx.lineTo(6.5, 10); ctx.stroke();
    ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(3, 14); ctx.lineTo(6.5, 10); ctx.stroke();
    ctx.strokeStyle = mc.dark; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(5, 12); ctx.lineTo(9.5, 7.5); ctx.stroke();
    ctx.fillStyle = mc.main; ctx.strokeStyle = mc.dark; ctx.lineWidth = 0.6;
    ctx.beginPath();
    ctx.moveTo(8, 8.5); ctx.lineTo(15.5, 0.8); ctx.lineTo(16, 2.2);
    ctx.lineTo(9.5, 9.8); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = mc.light; ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(9, 8.4); ctx.lineTo(15.2, 1.6); ctx.stroke();
  } else if (type === 'shovel'){
    drawHandle(ctx, mc);
    ctx.fillStyle = mc.main; ctx.strokeStyle = mc.dark; ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(7, 2.5); ctx.lineTo(13.5, 2.5); ctx.lineTo(14.5, 6.5);
    ctx.quadraticCurveTo(10.2, 8.5, 6, 6.5);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = mc.light; ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(8, 3.3); ctx.lineTo(13, 3.3); ctx.stroke();
  } else if (type === 'hoe'){
    drawHandle(ctx, mc);
    ctx.fillStyle = mc.main; ctx.strokeStyle = mc.dark; ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(7.5, 2); ctx.lineTo(15, 2); ctx.lineTo(15.5, 4.2);
    ctx.lineTo(8, 5.2); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(14.2, 4); ctx.lineTo(14.8, 6.5); ctx.lineTo(13, 6.8);
    ctx.lineTo(12.8, 4.6); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = mc.light; ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(8.5, 2.6); ctx.lineTo(14.5, 2.6); ctx.stroke();
  }
  ctx.restore();
}

function drawShearsIcon(ctx, S){
  const s = S / 16;
  ctx.save(); ctx.scale(s, s); ctx.lineCap = 'round';
  ctx.strokeStyle = '#c8c8d8'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(3, 3.5); ctx.lineTo(12.5, 12); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(12.5, 3.5); ctx.lineTo(3, 12); ctx.stroke();
  ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.arc(2.8, 2.8, 1.6, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.arc(12.7, 2.8, 1.6, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = '#666';
  ctx.beginPath(); ctx.arc(7.7, 7.7, 1.2, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function drawBucketIcon(ctx, S, fillStyle, hasFish){
  const s = S / 16;
  ctx.save(); ctx.scale(s, s);
  ctx.fillStyle = '#b0b0c0'; ctx.strokeStyle = '#666678'; ctx.lineWidth = 0.7;
  ctx.beginPath();
  ctx.moveTo(3.5, 5.5); ctx.lineTo(12.5, 5.5); ctx.lineTo(11, 14);
  ctx.lineTo(5, 14); ctx.closePath(); ctx.fill(); ctx.stroke();
  if (fillStyle){
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(3.5, 5.5); ctx.lineTo(12.5, 5.5); ctx.lineTo(11, 14);
    ctx.lineTo(5, 14); ctx.closePath(); ctx.clip();
    ctx.fillStyle = fillStyle; ctx.fillRect(3, 6.2, 10, 8);
    ctx.restore();
  }
  if (hasFish){
    ctx.fillStyle = '#2f86c9';
    ctx.beginPath(); ctx.ellipse(7.8, 10.4, 2.1, 1.1, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(9.7, 10.4); ctx.lineTo(11.3, 9.4); ctx.lineTo(11.3, 11.4);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#101418';
    ctx.beginPath(); ctx.arc(6.8, 10.2, 0.28, 0, Math.PI * 2); ctx.fill();
  }
  ctx.fillStyle = '#d8d8e8'; ctx.fillRect(3.5, 5.5, 9, 1.2);
  ctx.strokeStyle = '#8888a0'; ctx.lineWidth = 0.6;
  ctx.beginPath(); ctx.moveTo(4, 9); ctx.lineTo(12, 9); ctx.stroke();
  ctx.strokeStyle = '#666678'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.arc(8, 5.5, 4.5, Math.PI, 0, false); ctx.stroke();
  ctx.restore();
}

const TOOL_MATS = ['wood', 'stone', 'copper', 'iron', 'diamond', 'gold'];
const TOOL_TYPES = ['pickaxe', 'axe', 'sword', 'shovel', 'hoe'];
for (const mat of TOOL_MATS){
  for (const t of TOOL_TYPES){
    registerCanvasTex(`${mat}_${t}`, (ctx, S) => drawToolIcon(ctx, S, mat, t));
  }
}
registerCanvasTex('shears', (ctx, S) => drawShearsIcon(ctx, S));

/* ---- 盔甲图标（铜 / 金 / 铁 / 钻石） ---- */
function _armorMetal(ctx, S, material){
  const mc = MAT_COLORS[material] || MAT_COLORS.iron;
  ctx.scale(S / 16, S / 16);
  ctx.lineWidth = 0.8;
  ctx.strokeStyle = mc.dark;
  return mc;
}
function drawHelmetIcon(ctx, S, material){
  const mc = _armorMetal(ctx, S, material);
  ctx.fillStyle = mc.main;
  ctx.beginPath();
  ctx.moveTo(3, 9);
  ctx.quadraticCurveTo(3, 2.5, 8, 2.5);
  ctx.quadraticCurveTo(13, 2.5, 13, 9);
  ctx.lineTo(13, 12);
  ctx.lineTo(10.5, 12);
  ctx.lineTo(10.5, 8.5);
  ctx.lineTo(5.5, 8.5);
  ctx.lineTo(5.5, 12);
  ctx.lineTo(3, 12);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = mc.light;
  ctx.fillRect(5, 4.2, 6, 1.1);
}
function drawChestplateIcon(ctx, S, material){
  const mc = _armorMetal(ctx, S, material);
  ctx.fillStyle = mc.main;
  ctx.beginPath();
  ctx.moveTo(5, 2.5); ctx.lineTo(2.5, 4.5); ctx.lineTo(3.5, 8);
  ctx.lineTo(5, 7.5); ctx.lineTo(5, 13.5); ctx.lineTo(11, 13.5);
  ctx.lineTo(11, 7.5); ctx.lineTo(12.5, 8); ctx.lineTo(13.5, 4.5);
  ctx.lineTo(11, 2.5); ctx.lineTo(9.5, 4.5); ctx.lineTo(6.5, 4.5);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = mc.light;
  ctx.beginPath(); ctx.moveTo(8, 5); ctx.lineTo(8, 13); ctx.stroke();
}
function drawLeggingsIcon(ctx, S, material){
  const mc = _armorMetal(ctx, S, material);
  ctx.fillStyle = mc.main;
  ctx.beginPath();
  ctx.moveTo(4.5, 2.5); ctx.lineTo(11.5, 2.5);
  ctx.lineTo(11.5, 7); ctx.lineTo(10, 13.5); ctx.lineTo(8.2, 13.5);
  ctx.lineTo(8, 8.5); ctx.lineTo(8, 13.5); ctx.lineTo(6, 13.5);
  ctx.lineTo(4.5, 7); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = mc.light;
  ctx.beginPath(); ctx.moveTo(4.8, 4); ctx.lineTo(11.2, 4); ctx.stroke();
}
function drawBootsIcon(ctx, S, material){
  const mc = _armorMetal(ctx, S, material);
  ctx.fillStyle = mc.main;
  for (const x of [2.5, 8.5]){
    ctx.beginPath();
    ctx.moveTo(x, 3); ctx.lineTo(x + 4.2, 3); ctx.lineTo(x + 4.2, 10);
    ctx.lineTo(x + 5, 13); ctx.lineTo(x + 2.2, 13); ctx.lineTo(x + 2.2, 7);
    ctx.lineTo(x, 7); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  ctx.fillStyle = mc.light;
  ctx.fillRect(3, 4, 3.2, 1);
  ctx.fillRect(9, 4, 3.2, 1);
}
for (const mat of ['copper', 'gold', 'iron', 'diamond', 'ancient']){
  registerCanvasTex(`${mat}_helmet`,     (ctx, S) => drawHelmetIcon(ctx, S, mat));
  registerCanvasTex(`${mat}_chestplate`, (ctx, S) => drawChestplateIcon(ctx, S, mat));
  registerCanvasTex(`${mat}_leggings`,   (ctx, S) => drawLeggingsIcon(ctx, S, mat));
  registerCanvasTex(`${mat}_boots`,      (ctx, S) => drawBootsIcon(ctx, S, mat));
}

/* ---- 石头法杖 ---- */
function drawStoneStaffIcon(ctx, S){
  ctx.scale(S / 16, S / 16);
  ctx.lineCap = 'round';
  /* 杖身 */
  ctx.strokeStyle = '#6b4a24'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(4.5, 14.5); ctx.lineTo(10, 6.5); ctx.stroke();
  ctx.strokeStyle = '#9a6a34'; ctx.lineWidth = 0.7;
  ctx.beginPath(); ctx.moveTo(4.8, 14); ctx.lineTo(9.8, 7); ctx.stroke();
  /* 杖头石块 */
  ctx.fillStyle = '#8d949c'; ctx.strokeStyle = '#4d545c'; ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(10, 2.2); ctx.lineTo(13.4, 4); ctx.lineTo(13, 7.4);
  ctx.lineTo(9.6, 7.2); ctx.lineTo(8.2, 4.4); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#c2ccd4';
  ctx.fillRect(9.9, 3.3, 2.1, 0.9);
  /* 裂纹 */
  ctx.strokeStyle = '#5c646c'; ctx.lineWidth = 0.55;
  ctx.beginPath(); ctx.moveTo(11.1, 4.4); ctx.lineTo(11.7, 6.2); ctx.stroke();
}
registerCanvasTex('stone_staff', (ctx, S) => drawStoneStaffIcon(ctx, S));

/* ---- 弓 ---- */
function drawBowIcon(ctx, S, material){
  const s = S / 16;
  ctx.save(); ctx.scale(s, s);
  const mc = MAT_COLORS[material];
  ctx.lineCap = 'round';
  /* 弓臂 */
  ctx.strokeStyle = mc.dark; ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.arc(3, 8, 6.6, -Math.PI * 0.62, Math.PI * 0.62); ctx.stroke();
  ctx.strokeStyle = mc.main; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.arc(3, 8, 6.2, -Math.PI * 0.58, Math.PI * 0.58); ctx.stroke();
  /* 弦 */
  ctx.strokeStyle = '#e8e8e8'; ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.moveTo(6.6, 2.1); ctx.lineTo(6.6, 13.9); ctx.stroke();
  /* 箭 */
  ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.moveTo(6.4, 8); ctx.lineTo(14, 8); ctx.stroke();
  ctx.fillStyle = mc.light;
  ctx.beginPath(); ctx.moveTo(15.5, 8); ctx.lineTo(12.8, 6.5); ctx.lineTo(12.8, 9.5);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}
registerCanvasTex('bow',      (ctx, S) => drawBowIcon(ctx, S, 'wood'));
registerCanvasTex('iron_bow', (ctx, S) => drawBowIcon(ctx, S, 'iron'));
registerCanvasTex('bucket',       (ctx, S) => drawBucketIcon(ctx, S, null,      false));
registerCanvasTex('water_bucket', (ctx, S) => drawBucketIcon(ctx, S, '#3a7bd5', false));
registerCanvasTex('lava_bucket',  (ctx, S) => drawBucketIcon(ctx, S, '#e06010', false));
registerCanvasTex('fish_bucket',  (ctx, S) => drawBucketIcon(ctx, S, '#3a7bd5', true));

/* ============================================================
   食物
   ============================================================ */
function meatIcon(base, seed, fat){
  return (x, y, S) => {
    const g = hash2i(x, y, seed);
    const c = (S - 1) / 2;
    const dx = (x - c) / (S * 0.40), dy = (y - c) / (S * 0.32);
    const d = Math.sqrt(dx * dx + dy * dy);
    if (d > 1.0) return [0, 0, 0, 0];
    if (d > 0.86) return [base[0] * 0.55, base[1] * 0.5, base[2] * 0.5];
    const sh = 0.86 + g * 0.30;
    let col = [base[0] * sh, base[1] * sh, base[2] * sh];
    if (fat && ((x * 2 + y * 3 + seed) % 11 < 2)) col = [238, 226, 210];
    if (dx < -0.2 && dy < -0.15 && d < 0.66) col = col.map(v => Math.min(255, v * 1.22));
    return col;
  };
}
registerTex('raw_beef',      meatIcon([196, 62, 66],  441, true));
registerTex('cooked_beef',   meatIcon([132, 72, 38],  442, false));
registerTex('raw_mutton',    meatIcon([216, 96, 96],  443, true));
registerTex('cooked_mutton', meatIcon([148, 84, 46],  444, false));
registerTex('raw_chicken',   meatIcon([238, 178, 158],445, false));
registerTex('cooked_chicken',meatIcon([190, 138, 74], 446, false));
registerTex('raw_pork',      meatIcon([232, 138, 148],447, true));
registerTex('cooked_pork',   meatIcon([176, 106, 62], 448, false));

function fishIcon(body, seed){
  return (x, y, S) => {
    const g = hash2i(x, y, seed);
    const c = (S - 1) / 2;
    const dx = (x - c) / (S * 0.42), dy = (y - c) / (S * 0.24);
    const d = Math.abs(dx) + Math.abs(dy);
    if (d > 1.0){
      if (dx > 0.72 && Math.abs(dy) < 0.62 && (dx + Math.abs(dy) * 1.3) < 1.5){
        return [body[0] * 0.82, body[1] * 0.82, body[2] * 0.82];
      }
      return [0, 0, 0, 0];
    }
    const sh = 0.86 + g * 0.30;
    let col = [body[0] * sh, body[1] * sh, body[2] * sh];
    if (dy < -0.30) col = col.map(v => Math.min(255, v * 1.2));
    if (dy > 0.42) col = col.map(v => v * 0.78);
    return col;
  };
}
registerTex('raw_fish',    fishIcon([152, 186, 206], 451));
registerTex('cooked_fish', fishIcon([198, 158, 96],  452));

/* 未知方块 */
registerTex('unknown_block', (x, y) => {
  const cx = Math.floor(x / 2);
  const cy = Math.floor(y / 2);
  const isPink = (cx + cy) % 2 === 0;
  if (isPink){
    const n = hash2i(x, y, 9001);
    return [240 + n * 15, 60 + n * 40, 180 + n * 50];
  }
  const n = hash2i(x, y, 9002);
  return [26 + n * 20, 16 + n * 15, 34 + n * 20];
});

/* ============================================================
   ★ 第一批新方块贴图
   ============================================================ */

/* ---------- 白桦：米白皮 + 黑色横斑 ---------- */
registerTex('birch_log_side', (x, y) => {
  const n = fbm(x * 0.4, y * 0.15, 2, 1801);
  const speck = hash2i(x, Math.floor(y / 2), 1802);
  const eyeBand = Math.abs(Math.sin(y * 0.55 + x * 0.15)) < 0.22;
  if (eyeBand && hash2i(Math.floor(x / 3), Math.floor(y / 2), 1803) < 0.40){
    const d = 28 + speck * 38;
    return [d, d - 2, d - 6];
  }
  const base = 216 + (n * 0.3 + speck * 0.7) * 32;
  return [base, base * 0.99, base * 0.93];
});
registerTex('birch_log_top', (x, y, S) => {
  const c = (S - 1) / 2, d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 1.9) * 0.5 + 0.5;
  const n = hash2i(x, y, 1805) * 0.2;
  return [196 + ring * 40 + n * 14, 182 + ring * 36 + n * 12, 156 + ring * 30 + n * 10];
});
registerTex('birch_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [158, 138, 100];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 1806);
  return [210 + n * 32, 188 + n * 28, 138 + n * 24];
});
registerTex('birch_leaves', (x, y, S) => {
  const n = fbm(x * 0.38, y * 0.38, 3, 1811);
  const n2 = hash2i(x, y, 1812);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  const edge = Math.min(x, y, S - 1 - x, S - 1 - y);
  if (edge < 1 && hash2i(x, y, 1813) < 0.45) return [v, v, v, 0];
  if (hash2i(x, y, 1814) < 0.10) return [v, v, v, 0];
  return [v, v, v];
});
registerTex('birch_leaves_solid', (x, y) => {
  const n = fbm(x * 0.38, y * 0.38, 3, 1811);
  const n2 = hash2i(x, y, 1812);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

/* ---------- 丛林：灰棕皮 + 灰绿苔藓斑 ---------- */
registerTex('jungle_log_side', (x, y) => {
  const n = fbm(x * 0.7, y * 0.08, 3, 1821);
  const moss = fbm(x * 0.35, y * 0.35, 2, 1824);
  if (moss > 0.58){
    const m = (moss - 0.58) * 2.5;
    return [86 - m * 34, 66 + m * 8, 48 - m * 20];
  }
  const h = hash2i(x, Math.floor(y / 2), 1822);
  return [86 + n * 30 + h * 10, 66 + n * 22 + h * 8, 48 + n * 16 + h * 6];
});
registerTex('jungle_log_top', (x, y, S) => {
  const c = (S - 1) / 2, d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 2.1) * 0.5 + 0.5;
  const n = hash2i(x, y, 1825) * 0.2;
  return [110 + ring * 32 + n * 12, 86 + ring * 26 + n * 10, 62 + ring * 20 + n * 8];
});
registerTex('jungle_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [86, 52, 32];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 1826);
  return [152 + n * 36, 96 + n * 30, 58 + n * 22];
});
registerTex('jungle_leaves', (x, y, S) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 1831);
  const n2 = hash2i(x, y, 1832);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  const edge = Math.min(x, y, S - 1 - x, S - 1 - y);
  if (edge < 1 && hash2i(x, y, 1833) < 0.35) return [v, v, v, 0];
  if (hash2i(x, y, 1834) < 0.06) return [v, v, v, 0];
  return [v, v, v];
});
registerTex('jungle_leaves_solid', (x, y) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 1831);
  const n2 = hash2i(x, y, 1832);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

/* ---------- 金合欢：橙红皮 + 斜纹分层 ---------- */
registerTex('acacia_log_side', (x, y) => {
  const diag = Math.sin((x + y * 2.5) * 0.55) * 0.5 + 0.5;
  const n = fbm(x * 0.5, y * 0.2, 2, 1841);
  const v = diag * 0.5 + n * 0.5;
  return [168 * (0.70 + v * 0.55), 90 * (0.70 + v * 0.55), 48 * (0.70 + v * 0.55)];
});
registerTex('acacia_log_top', (x, y, S) => {
  const c = (S - 1) / 2, d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 1.6) * 0.5 + 0.5;
  const n = hash2i(x, y, 1845) * 0.2;
  return [158 + ring * 38 + n * 14, 88 + ring * 26 + n * 10, 48 + ring * 18 + n * 8];
});
registerTex('acacia_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [128, 66, 34];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 1846);
  return [190 + n * 34, 104 + n * 28, 52 + n * 20];
});
registerTex('acacia_leaves', (x, y, S) => {
  const n = fbm(x * 0.40, y * 0.40, 3, 1851);
  const n2 = hash2i(x, y, 1852);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  const edge = Math.min(x, y, S - 1 - x, S - 1 - y);
  if (edge < 1 && hash2i(x, y, 1853) < 0.40) return [v, v, v, 0];
  if (hash2i(x, y, 1854) < 0.09) return [v, v, v, 0];
  return [v, v, v];
});
registerTex('acacia_leaves_solid', (x, y) => {
  const n = fbm(x * 0.40, y * 0.40, 3, 1851);
  const n2 = hash2i(x, y, 1852);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});

/* ---------- 新岩石 ---------- */
registerTex('deepslate', (x, y) => {
  /* ★ 深板岩：深灰底 + 低频斑块 + 竖向纹路 + 少量浅色矿点/暗裂隙。
     原来只有高频 fbm + 白噪声，16px 下几乎是一块均匀的黑噪点。 */
  const b  = fbm(x * 0.16, y * 0.2, 2, 1911);
  const gr = fbm(x * 0.55, y * 0.12, 1, 1914);   /* 单层即 vnoise，做竖向纹路 */
  const h  = hash2i(x, y, 1912);
  let v = 44 + b * 32 + gr * 12 + h * 4;
  if (hash2i(x >> 1, y >> 1, 1916) > 0.86) v += 9;   /* 浅色小块 */
  if (hash2i(x, y >> 1, 1913) > 0.95) v -= 15;       /* 细裂隙 */
  return [v - 3, v, v + 6];
});
registerTex('granite', (x, y) => {
  const n = fbm(x * 0.5, y * 0.5, 3, 1911);
  const h = hash2i(x, y, 1912);
  const v = n * 30 + h * 10;
  return [172 + v, 138 + v, 128 + v];
});
registerTex('diorite', (x, y) => {
  const n = fbm(x * 0.5, y * 0.5, 3, 1921);
  const h = hash2i(x, y, 1922);
  const v = 195 + n * 22 + (h > 0.88 ? -80 : 0);
  return [v, v, v + 4];
});
registerTex('andesite', (x, y) => {
  const n = fbm(x * 0.5, y * 0.5, 3, 1931);
  const h = hash2i(x, y, 1932);
  const v = 138 + n * 28 + h * 10;
  return [v, v, v + 2];
});
registerTex('basalt', (x, y, S) => {
  const col = Math.floor(x / Math.max(2, Math.round(S / 5)));
  const colNoise = hash2i(col, 0, 1941);
  const n = fbm(x * 0.15, y * 0.6, 2, 1942);
  const h = hash2i(x, y, 1943);
  const v = 32 + colNoise * 20 + n * 14 + h * 8;
  return [v, v - 2, v + 6];
});

/* ---------- 藤蔓 ---------- */
registerTex('vine', (x, y, S) => {
  const cx = (S - 1) / 2;
  const wobble = Math.sin(y * 0.6) * 1.5;
  if (Math.abs(x - cx) >= 2 + wobble * 0.3) return [0, 0, 0, 0];
  const g = hash2i(x, y, 1953);
  const leaf = hash2i(Math.floor(x / 2), Math.floor(y / 3), 1952);
  if (leaf < 0.15) return [58 + g * 30, 122 + g * 46, 42 + g * 24];
  return [32 + g * 24, 78 + g * 36, 28 + g * 18];
});

/* ---------- 蘑菇 ---------- */
registerTex('red_mushroom', (x, y, S) => {
  const c = (S - 1) / 2, capCY = S * 0.38, capR = S * 0.38;
  const d = Math.hypot(x - c, y - capCY);
  const g = hash2i(x, y, 1961);
  if (d < capR){
    if (hash2i(Math.floor(x / 3), Math.floor(y / 3), 1962) < 0.28)
      return [242, 232, 228];
    return [200 + g * 30, 46 + g * 20, 44 + g * 20];
  }
  if (y > capCY && Math.abs(x - c) < S * 0.12)
    return [232 + g * 20, 220 + g * 20, 200 + g * 20];
  return [0, 0, 0, 0];
});
registerTex('brown_mushroom', (x, y, S) => {
  const c = (S - 1) / 2, capCY = S * 0.38, capR = S * 0.36;
  const d = Math.hypot(x - c, y - capCY);
  const g = hash2i(x, y, 1971);
  if (d < capR){
    const n = fbm(x * 0.4, y * 0.4, 2, 1972);
    return [148 + n * 36 + g * 12, 104 + n * 30, 66 + n * 20];
  }
  if (y > capCY && Math.abs(x - c) < S * 0.10)
    return [218 + g * 20, 202 + g * 20, 178 + g * 20];
  return [0, 0, 0, 0];
});
registerTex('mushroom_block_red', (x, y) => {
  const g = hash2i(x, y, 1981);
  if (hash2i(Math.floor(x / 4), Math.floor(y / 4), 1982) < 0.30){
    const v = 236 + g * 20;
    return [v, v - 8, v - 12];
  }
  return [176 + g * 30, 60 + g * 20, 54 + g * 20];
});
registerTex('mushroom_block_brown', (x, y) => {
  const g = hash2i(x, y, 1991);
  const n = fbm(x * 0.35, y * 0.35, 2, 1992);
  return [144 + n * 30 + g * 10, 100 + n * 24, 62 + n * 18];
});

/* ============================================================
   ★ 第二批新方块贴图
   ============================================================ */

/* ---------- 石灰岩 / 大理石 ---------- */
registerTex('limestone', (x, y) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 2101);
  const h = hash2i(x, y, 2102);
  const v = 196 + n * 30 + h * 8;
  return [v, v - 6, v - 24];
});
registerTex('marble', (x, y, S) => {
  const vein = Math.abs(fbm(x * 0.28, y * 0.18, 2, 2111) - 0.5) < 0.055;
  const n = fbm(x * 0.35, y * 0.35, 3, 2112);
  if (vein){
    const d = 128 + n * 34;
    return [d, d + 4, d + 12];
  }
  const v = 226 + n * 22;
  return [v, v - 2, v - 10];
});

/* ---------- 陶瓦：橙红条纹 ---------- */
registerTex('terracotta', (x, y) => {
  const n = fbm(x * 0.6, y * 0.6, 3, 2121);
  const h = hash2i(x, y, 2122);
  const v = 0.82 + n * 0.36;
  const band = Math.abs(y % 5) < 1 ? -22 : 0;
  return [152 * v + band, 78 * v + band, 52 * v + band];
});

/* ---------- 红沙 / 红砂岩 / 黄土 ---------- */
registerTex('red_sand', (x, y) => {
  const n = hash2i(x, y, 2131) * 0.6 + fbm(x * 0.8, y * 0.8, 2, 2132) * 0.4;
  return [188 + n * 44, 96 + n * 34, 52 + n * 26];
});
registerTex('red_sandstone', (x, y) => {
  const band = y % 5 === 0 ? -22 : 0;
  const n = hash2i(x, y, 2131) * 0.6 + fbm(x * 0.5, y * 0.35, 2, 2133) * 0.4;
  return [180 + n * 32 + band, 88 + n * 24 + band, 48 + n * 20 + band];
});
registerTex('loess', (x, y) => {
  const n = hash2i(x, y, 2141) * 0.6 + fbm(x * 0.5, y * 0.5, 3, 2142) * 0.4;
  return [186 + n * 32, 158 + n * 30, 106 + n * 30];
});

/* ---------- 红树 ---------- */
registerTex('mangrove_log_side', (x, y) => {
  const n = fbm(x * 0.6, y * 0.1, 3, 2151);
  const h = hash2i(x, Math.floor(y / 2), 2152);
  return [92 + n * 32 + h * 12, 62 + n * 24 + h * 8, 48 + n * 18 + h * 6];
});
registerTex('mangrove_log_top', (x, y, S) => {
  const c = (S - 1) / 2, d = Math.hypot(x - c, y - c) / S * 28;
  const ring = Math.sin(d * 2.2) * 0.5 + 0.5;
  const n = hash2i(x, y, 2155) * 0.2;
  return [96 + ring * 30 + n * 12, 68 + ring * 22 + n * 10, 52 + ring * 16 + n * 8];
});
registerTex('mangrove_planks', (x, y, S) => {
  const pw = Math.max(3, Math.round(S / 4));
  const plank = Math.floor(y / pw);
  if (y % pw === 0) return [72, 44, 32];
  const n = fbm(x * 0.35, (y + plank * pw) * 0.9, 2, 2156);
  return [140 + n * 34, 92 + n * 28, 62 + n * 20];
});
registerTex('mangrove_leaves', (x, y, S) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 2161);
  const n2 = hash2i(x, y, 2162);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  const edge = Math.min(x, y, S - 1 - x, S - 1 - y);
  if (edge < 1 && hash2i(x, y, 2163) < 0.42) return [v, v, v, 0];
  if (hash2i(x, y, 2164) < 0.08) return [v, v, v, 0];
  return [v, v, v];
});
registerTex('mangrove_leaves_solid', (x, y) => {
  const n = fbm(x * 0.42, y * 0.42, 3, 2161);
  const n2 = hash2i(x, y, 2162);
  const v = 240 + n * 15 + n2 * 5;  /* ★ 鲜艳度 */
  return [v, v, v];
});
registerTex('mangrove_root', (x, y) => {
  const n = fbm(x * 0.7, y * 0.7, 3, 2171);
  const h = hash2i(x, y, 2172);
  const v = 86 + n * 32 + h * 12;
  return [v, v * 0.72, v * 0.60];
});

/* ---------- 冰 ---------- */
registerTex('packed_ice', (x, y) => {
  const n = fbm(x * 0.35, y * 0.35, 3, 2181);
  const crack = Math.abs(fbm(x * 0.15, y * 0.22, 2, 2182) - 0.5) < 0.035;
  if (crack){
    const v = 168 + n * 30;
    return [v, v + 14, v + 36];
  }
  const v = 196 + n * 30;
  return [v, v + 12, v + 30];
});
registerTex('blue_ice', (x, y) => {
  const n = fbm(x * 0.32, y * 0.32, 3, 2191);
  const v = 118 + n * 42;
  return [v * 0.55, v * 0.95, v + 46];
});

/* ---------- 岩浆块 / 黑石 ---------- */
registerTex('magma_block', (x, y, S) => {
  const n = fbm(x * 0.45, y * 0.45, 3, 2201);
  const crack = Math.abs(fbm(x * 0.28, y * 0.28, 2, 2202) - 0.5) < 0.09;
  if (crack){
    const g = hash2i(x, y, 2203);
    return [238 + g * 16, 118 + g * 48, 24 + g * 30];
  }
  const v = 62 + n * 30;
  return [v, v * 0.7, v * 0.6];
});
registerTex('blackstone', (x, y, S) => {
  const col = Math.floor(x / Math.max(2, Math.round(S / 5)));
  const cN = hash2i(col, 0, 2211);
  const n = fbm(x * 0.14, y * 0.6, 2, 2212);
  const h = hash2i(x, y, 2213);
  const v = 24 + cN * 18 + n * 14 + h * 8;
  return [v, v + 2, v + 6];
});

/* ---------- 苔藓 ---------- */
registerTex('moss_block', (x, y) => {
  const n = fbm(x * 0.55, y * 0.55, 3, 2221);
  const h = hash2i(x, y, 2222);
  const v = 0.7 + n * 0.5;
  return [62 * v + h * 14, 118 * v + h * 20, 52 * v + h * 10];
});
registerTex('moss_carpet', (x, y, S) => {
  const c = (S - 1) / 2;
  const d = Math.max(Math.abs(x - c), Math.abs(y - c)) / c;
  if (d > 0.92) return [0, 0, 0, 0];
  const n = fbm(x * 0.55, y * 0.55, 3, 2221);
  const h = hash2i(x, y, 2222);
  const v = 0.7 + n * 0.5;
  return [62 * v + h * 14, 118 * v + h * 20, 52 * v + h * 10];
});

/* ---------- 枯木 / 甘蔗 / 竹子 ---------- */
registerTex('dead_bush', (x, y, S) => {
  const cx = (S - 1) / 2;
  const ty = 1 - y / (S - 1);
  const k = S / 28;
  for (let i = 0; i < 5; i++){
    const r1 = hash2i(i, 11, 2231);
    const r2 = hash2i(i, 22, 2232);
    const r3 = hash2i(i, 33, 2233);
    const x0 = cx + (r1 - 0.5) * S * 0.82;
    const top = 0.55 + r3 * 0.42;
    if (ty > top) continue;
    const tt = ty / top;
    const bend = (r2 - 0.5) * S * 0.9 * Math.sin(Math.PI * Math.pow(tt, 1.5));
    const px = x0 + bend;
    const w = 1.0 * k * (1 - tt * 0.65);
    if (Math.abs(x - px) < w){
      const g = hash2i(x, y, 2234 + i);
      const v = 106 + g * 30;
      return [v, v * 0.72, v * 0.44];
    }
  }
  return [0, 0, 0, 0];
});
registerTex('sugar_cane', (x, y, S) => {
  const cx = (S - 1) / 2;
  if (Math.abs(x - cx) >= 1.4 * (S / 28)) return [0, 0, 0, 0];
  const g = hash2i(x, Math.floor(y / 3), 2241);
  if (y % 4 === 0) return [80 + g * 16, 128 + g * 24, 62 + g * 16];
  return [136 + g * 22, 176 + g * 30, 88 + g * 18];
});
registerTex('bamboo', (x, y, S) => {
  const cx = (S - 1) / 2;
  const k = S / 28;
  if (Math.abs(x - cx) >= 1.6 * k) return [0, 0, 0, 0];
  const seg = Math.floor(y / 5);
  const g = hash2i(seg, 0, 2251);
  if (y % 5 === 0) return [64 + g * 20, 96 + g * 22, 40 + g * 16];
  return [110 + g * 30, 154 + g * 34, 62 + g * 20];
});

/* ---------- 雪层 ---------- */
registerTex('snow_layer', (x, y) => {
  const n = hash2i(x, y, 2261) * 0.5 + fbm(x * 0.5, y * 0.5, 2, 2262) * 0.5;
  return [230 + n * 24, 236 + n * 20, 248 + n * 12];
});

/* ============================================================
   魔法方块贴图
   ============================================================ */
registerCanvasTex('magic_ore', (ctx, S) => {
  /* 石头底 + 紫水晶矿脉斑点 */
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
    const bn = fbm(x * 0.12, y * 0.12, 2, 41) - 0.5;
    const fi = (hash2i(x, y, 42) - 0.5) * 12;
    let v = 128 + bn * 6 + fi;
    if (hash2i(x, y, 43) > 0.95) v -= 12;
    let isBlob = false;
    for (let i = 0; i < 6; i++){
      const cx = 2 + hash2i(i, 0, 88001) * 12;
      const cy = 2 + hash2i(i, 1, 88001) * 12;
      const r = 2.0 * (0.6 + hash2i(i, 2, 88001) * 0.8);
      const dx = x - cx, dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const nz = (fbm(x * 0.6, y * 0.6, 2, 88101 + i) - 0.5) * 1.2;
      if (dist + nz < r){
        const t = Math.min(1, (dist + nz) / r);
        const pn = (hash2i(x, y, 88201 + i) - 0.5) * 40;
        d[(y * S + x) * 4]     = Math.max(0, Math.min(255, 170 * (1 - t * 0.4) + pn));
        d[(y * S + x) * 4 + 1] = Math.max(0, Math.min(255, 90  * (1 - t * 0.4) + pn));
        d[(y * S + x) * 4 + 2] = Math.max(0, Math.min(255, 220 * (1 - t * 0.3) + pn));
        d[(y * S + x) * 4 + 3] = 255;
        isBlob = true;
        break;
      }
    }
    if (!isBlob){
      d[(y * S + x) * 4]     = Math.max(0, Math.min(255, v));
      d[(y * S + x) * 4 + 1] = Math.max(0, Math.min(255, v + 1));
      d[(y * S + x) * 4 + 2] = Math.max(0, Math.min(255, v + 5));
      d[(y * S + x) * 4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
});

registerCanvasTex('magic_crystal_icon', (ctx, S) => {
  /* 八角水晶轮廓（背包/掉落/准星用） */
  const cx = S / 2, cy = S / 2;
  const g = ctx.createLinearGradient(0, 2, 0, S - 2);
  g.addColorStop(0, 'rgba(220, 170, 255, 1)');
  g.addColorStop(0.5, 'rgba(170, 90, 240, 1)');
  g.addColorStop(1, 'rgba(120, 50, 200, 1)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(cx, 1.5);
  ctx.lineTo(S - 3, cy * 0.75);
  ctx.lineTo(S - 4, S - 3);
  ctx.lineTo(4, S - 3);
  ctx.lineTo(3, cy * 0.75);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(240, 210, 255, 1)';
  ctx.lineWidth = 0.8;
  ctx.stroke();
  /* 高光 */
  ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
  ctx.beginPath();
  ctx.moveTo(cx - 1, 4);
  ctx.lineTo(cx + 1, 4);
  ctx.lineTo(cx, S - 4);
  ctx.closePath();
  ctx.fill();
});



registerCanvasTex('magic_pulse_core', (ctx, S) => {
    const c = S/2;
    const img = ctx.createImageData(S, S);
    const d = img.data;
    for (let y = 0; y < S; y++) {
        for (let x = 0; x < S; x++) {
            const dist = Math.hypot(x - c, y - c);
            const angle = Math.atan2(y - c, x - c);
            const isStar = (Math.abs(Math.cos(angle * 4)) > 0.7 && dist < S*0.4) || dist < S*0.15;
            const i = (y * S + x) * 4;
            if (isStar) {
                const bright = 1 - dist / (S*0.5);
                d[i] = 255;
                d[i+1] = 100 + bright * 155;
                d[i+2] = 50;
                d[i+3] = 255;
            } else {
                d[i+3] = 0;
            }
        }
    }
    ctx.putImageData(img, 0, 0);
});
/* 魔法水晶块：切面宝石质感
   ------------------------------------------------------------
   旧版是逐像素紫色随机噪点，远看就是一团紫沙。
   现在用 Voronoi 切成大块棱面，每个棱面按自己的朝向受光，
   棱线留一道淡紫高光，再撒几粒晶体闪点。 */
registerTex('magic_crystal_block', (x, y, S) => {
  const SEED = 89010;
  /* 棱面种子：几块大切面，避免碎成一片噪点 */
  const seeds = [
    [3.0, 2.5], [10.5, 2.0], [14.8, 7.5],
    [8.0, 8.5], [2.0, 9.5],
    [6.5, 14.5], [12.5, 13.5], [15.5, 15.5],
  ];
  const px = x + 0.5, py = y + 0.5;
  let d1 = 1e9, d2 = 1e9, cell = 0;
  for (let i = 0; i < seeds.length; i++){
    const dx = px - seeds[i][0], dy = py - seeds[i][1];
    const d = dx * dx + dy * dy;
    if (d < d1){ d2 = d1; d1 = d; cell = i; }
    else if (d < d2){ d2 = d; }
  }
  const edge = Math.sqrt(d2) - Math.sqrt(d1);

  /* 每个切面是一块平整的棱面：整块一个亮度，只带极轻微的方向渐变 */
  const a = hash2i(cell, 0, SEED) * Math.PI * 2;
  const dx = px - seeds[cell][0], dy = py - seeds[cell][1];
  const len = Math.hypot(dx, dy) || 1;
  const tilt = (dx * Math.cos(a) + dy * Math.sin(a)) / len;

  let lit = 0.70 + hash2i(cell, 1, SEED) * 0.65;   /* 各切面明暗不同 */
  lit *= 0.88 + (15 - y) * 0.016;                  /* 上面偏亮、下面偏深 */
  lit += tilt * 0.05;                              /* 切面内的轻微倾斜 */
  lit += (hash2i(x, y, SEED + 7) - 0.5) * 0.04;    /* 极细的晶体颗粒 */

  if (edge < 0.7){
    /* 棱线：淡紫高光，不抢主体 */
    const k = 0.90 + (1 - edge / 0.7) * 0.15;
    return [198 * k, 150 * k, 255 * k, 255];
  }
  if (edge < 1.35) lit *= 0.86;                    /* 棱线内侧轻微压暗 */

  /* 稀疏闪点 */
  if (hash2i(x, y, SEED + 31) > 0.994) return [252, 242, 255, 255];

  return [118 * lit + 10, 52 * lit + 6, 208 * lit + 22, 255];
});
registerTex('magic_pedestal', (x, y) => {
  const n = hash2i(x, y, 89011);
  return [120 + n * 30, 90 + n * 20, 60 + n * 10, 255];
});
/* ★ 展台方块模型用的图集贴图（16px 风格，和普通方块同样采样） */
registerTex('magic_pedestal_wood', (x, y) => {
  const n = hash2i(x, y, 89012);
  const seam = (y % 4 === 0) ? 0.62 : 1;
  const edge = (x === 0 || x === 15) ? 0.85 : 1;
  const r = (154 + n * 22) * seam * edge;
  const g = (108 + n * 16) * seam * edge;
  const b = (62 + n * 12) * seam * edge;
  return [r, g, b, 255];
});
registerTex('magic_pedestal_top', (x, y) => {
  const n = hash2i(x, y, 89013);
  let r = 166 + n * 20, g = 116 + n * 15, b = 66 + n * 10;
  if (x < 2 || x > 13 || y < 2 || y > 13){ r *= 0.72; g *= 0.72; b *= 0.72; }
  return [r, g, b, 255];
});
registerTex('magic_pedestal_glass', (x, y) => {
  const edge = (x < 1 || x > 14 || y < 1 || y > 14);
  if (edge) return [196, 228, 242, 205];
  const streak = ((x + y) % 7 === 0);
  return [214, 242, 252, streak ? 95 : 42];
});
registerTex('magic_dust_off', (x, y, S) => {
  const n = hash2i(x, y, 89001);
  return [110 + n * 20, 110 + n * 20, 110 + n * 20, 255];
});
registerTex('magic_dust_on', (x, y, S) => {
  const n = hash2i(x, y, 89001);
  return [200 + n * 40, 100 + n * 40, 255, 255];
});
registerTex('magic_crystal', (x, y, S) => {
  /* 3D 模型不用这个，但 flatRender 兼容需要 */
  return [180, 100, 240, 180];
});
registerTex('magic_torch_stick', (x, y) => {
  const n = hash2i(x, y, 89031);
  const grain = ((x + y) % 5 === 0) ? 0.82 : 1;
  const core = (x >= 6 && x <= 9 && y >= 2 && y <= 11);
  if (core) return [168 + n * 30, 92 + n * 24, 236 + n * 16, 255];
  return [(146 + n * 20) * grain, (102 + n * 16) * grain, (58 + n * 12) * grain, 255];
});
registerTex('magic_torch_tip', (x, y) => {
  const n = hash2i(x, y, 89032);
  const cx = x - 7.5, cy = y - 7.5;
  const d = Math.sqrt(cx * cx + cy * cy);
  if (d < 2.2) return [255, 240, 255, 255];
  if (d < 4.2) return [225 + n * 30, 130 + n * 40, 255, 255];
  return [0, 0, 0, 0];
});

/* ---------- 动力元件贴图（木质 / 石质，不做统一的紫色魔法风） ---------- */
registerTex('magic_lever_base', (x, y) => {
  const n = hash2i(x, y, 89021);
  const edge = (x < 1 || x > 14 || y < 1 || y > 14) ? 0.68 : 1;
  const speck = hash2i(x, y, 89011) > 0.72 ? 1.12 : 1;
  return [(118 + n * 26) * edge * speck, (116 + n * 24) * edge * speck, (110 + n * 22) * edge * speck, 255];
});
registerTex('magic_lever_stick', (x, y) => {
  const n = hash2i(x, y, 89022);
  const grain = ((x + y) % 4 === 0) ? 0.78 : 1;
  /* 顶端一小段铁质握柄 */
  if (y >= 3 && y <= 5) return [126 + n * 18, 128 + n * 18, 134 + n * 20, 255];
  return [(150 + n * 20) * grain, (106 + n * 16) * grain, (62 + n * 12) * grain, 255];
});
registerTex('magic_button_base', (x, y) => {
  const n = hash2i(x, y, 89023);
  const edge = (x < 1 || x > 14 || y < 1 || y > 14) ? 0.66 : 1;
  return [(112 + n * 22) * edge, (108 + n * 20) * edge, (102 + n * 18) * edge, 255];
});
registerTex('magic_button_top', (x, y, S) => {
  const n = hash2i(x, y, 89024);
  const dist = Math.hypot(x - S / 2, y - S / 2);
  /* 外圈石框 + 内圈打磨过的浅色按钮 */
  if (dist > 6.2) return [(96 + n * 16), (94 + n * 14), (90 + n * 12), 255];
  if (dist > 4.6) return [(158 + n * 20), (152 + n * 18), (142 + n * 16), 255];
  return [(190 + n * 22), (184 + n * 20), (172 + n * 18), 255];
});
registerTex('magic_plate_base', (x, y) => {
  const n = hash2i(x, y, 89025);
  const edge = (x < 1 || x > 14 || y < 1 || y > 14) ? 0.62 : 1;
  return [(92 + n * 18) * edge, (90 + n * 16) * edge, (84 + n * 14) * edge, 255];
});
registerTex('magic_plate_top', (x, y, S) => {
  const n = hash2i(x, y, 89026);
  const d = Math.hypot(x - S / 2, y - S / 2);
  /* 石质压力板：外沿略深，中心浅灰石面 */
  if (d > 6.4) return [(104 + n * 18), (102 + n * 16), (96 + n * 14), 255];
  if (d > 5.2) return [(136 + n * 18), (132 + n * 16), (124 + n * 14), 255];
  return [(170 + n * 20), (166 + n * 18), (156 + n * 16), 255];
});
registerTex('magic_door', (x, y) => {
  const n = hash2i(x, y, 89027);
  const plank = (x % 4 === 1) ? 0.8 : 1;
  /* 上下深色木框 + 铁质铰链钉 */
  const band = (y >= 2 && y <= 3) || (y >= 13 && y <= 14);
  if (band) return [96 + n * 22, 62 + n * 16, 38 + n * 10, 255];
  const hinge = (x >= 2 && x <= 4) && (y === 4 || y === 12);
  if (hinge) return [150 + n * 22, 152 + n * 22, 158 + n * 22, 255];
  return [(148 + n * 18) * plank, (104 + n * 14) * plank, (62 + n * 12) * plank, 255];
});
registerTex('iron_door', (x, y, S) => {
  const n = hash2i(x, y, 89031);
  /* 竖向铆接板 + 上下加强带 */
  const seam = (x % 5 === 2);
  const band = (y >= 2 && y <= 3) || (y >= 13 && y <= 14);
  if (band) return [128 + n * 34, 132 + n * 34, 142 + n * 36, 255];
  const rivet = (x % 5 === 3) && ((y % 6) === 3);
  if (rivet) return [206 + n * 24, 210 + n * 24, 220 + n * 26, 255];
  const v = seam ? 0.72 : 1;
  return [(118 + n * 30) * v, (122 + n * 30) * v, (132 + n * 32) * v, 255];
});




/* ============================================================
   魔法豆子 / 发光植物 / 发光箭矢
   ============================================================ */
/* 魔法草：细长草叶，叶尖偏青绿发光 */
registerTex('magic_grass', (x, y) => {
  const n = hash2i(x, y, 89101);
  const blades = [[3, 5], [6, 2], [9, 4], [12, 6]];
  let hit = false;
  for (let i = 0; i < blades.length; i++){
    const bx = blades[i][0], top = blades[i][1];
    if (y >= top && Math.abs(x - bx) < 0.9) hit = true;
  }
  if (!hit) return [0, 0, 0, 0];
  const k = 0.85 + n * 0.3;
  if (y < 7) return [150 * k + 60, 240 * k, 170 * k + 50, 255];
  return [48 * k, 110 * k, 62 * k, 255];
});

/* 发光树苗：小树干 + 几簇发光叶 */
registerTex('glow_sapling', (x, y) => {
  const n = hash2i(x, y, 89102);
  const stem = Math.abs(x - 8) < 1.1 && y >= 8;
  const buds = [[5, 6, 2.4], [11, 5, 2.2], [8, 3, 2.6]];
  let leaf = false;
  for (let i = 0; i < buds.length; i++){
    const dx = x + 0.5 - buds[i][0], dy = y + 0.5 - buds[i][1];
    if (Math.hypot(dx, dy) < buds[i][2]) leaf = true;
  }
  if (!stem && !leaf) return [0, 0, 0, 0];
  if (leaf){
    const k = 0.8 + n * 0.4;
    return [170 * k, 255, 190 * k, 255];
  }
  return [70, 96, 60, 255];
});

/* 光粒：一枚明亮的小光点 */
registerTex('glow_light', (x, y) => {
  const d = Math.hypot(x - 7.5, y - 7.5);
  if (d > 6.5) return [0, 0, 0, 0];
  const k = 1 - d / 6.5;
  return [200 + 55 * k, 240 + 15 * k, 170 + 70 * k, 255];
});

/* 魔法豆子图标 */
registerCanvasTex('magic_bean', (ctx, S) => {
  const s = S / 16;
  ctx.clearRect(0, 0, S, S);
  /* 豆荚 */
  ctx.fillStyle = '#2f7a3f';
  ctx.beginPath();
  ctx.ellipse(8 * s, 10 * s, 4.6 * s, 3.2 * s, -0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#54b866';
  ctx.beginPath();
  ctx.ellipse(8 * s, 9.4 * s, 3.4 * s, 2.1 * s, -0.5, 0, Math.PI * 2);
  ctx.fill();
  /* 发光豆子 */
  for (let i = 0; i < 3; i++){
    const bx = (5.6 + i * 2.4) * s, by = (11 - i * 1.1) * s;
    ctx.fillStyle = 'rgba(170,255,190,0.35)';
    ctx.beginPath(); ctx.arc(bx, by, 2.4 * s, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#c8ffd6';
    ctx.beginPath(); ctx.arc(bx, by, 1.35 * s, 0, Math.PI * 2); ctx.fill();
  }
  /* 小叶柄 */
  ctx.strokeStyle = '#3f8f4c';
  ctx.lineWidth = Math.max(1, s);
  ctx.beginPath();
  ctx.moveTo(9.5 * s, 6.6 * s);
  ctx.quadraticCurveTo(12 * s, 3 * s, 14 * s, 3.4 * s);
  ctx.stroke();
});

/* 发光箭矢图标：普通箭 + 青色发光箭头 */
registerCanvasTex('glow_arrow', (ctx, S) => {
  const s = S / 16;
  ctx.clearRect(0, 0, S, S);
  ctx.strokeStyle = '#8a6a3f';
  ctx.lineWidth = Math.max(1, 1.2 * s);
  ctx.beginPath();
  ctx.moveTo(3.2 * s, 12.8 * s);
  ctx.lineTo(11 * s, 5 * s);
  ctx.stroke();
  /* 羽尾 */
  ctx.fillStyle = '#d8d8d8';
  ctx.beginPath();
  ctx.moveTo(3 * s, 13 * s); ctx.lineTo(5.4 * s, 11.6 * s);
  ctx.lineTo(4.2 * s, 10.4 * s); ctx.lineTo(2 * s, 11.8 * s);
  ctx.closePath(); ctx.fill();
  /* 发光箭头 */
  ctx.fillStyle = 'rgba(170,255,190,0.35)';
  ctx.beginPath(); ctx.arc(11.6 * s, 4.4 * s, 3.4 * s, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#b8ffd0';
  ctx.beginPath();
  ctx.moveTo(13.8 * s, 2.2 * s);
  ctx.lineTo(9.4 * s, 4.2 * s);
  ctx.lineTo(11.8 * s, 6.6 * s);
  ctx.closePath(); ctx.fill();
});


/* ============================================================
   UV / Atlas
   ============================================================ */
export const UVRECT = [];
for (let i = 0; i < ATLAS_TOTAL; i++){
  const tx = (i % ATLAS_COLS) * ATLAS_TILE;
  const ty = Math.floor(i / ATLAS_COLS) * ATLAS_TILE;
  UVRECT.push({
    u0: (tx + TEX_PAD) / ATLAS_SIZE,
    u1: (tx + TEX_PAD + TEX_INNER) / ATLAS_SIZE,
    v0: 1 - (ty + TEX_PAD + TEX_INNER) / ATLAS_SIZE,
    v1: 1 - (ty + TEX_PAD) / ATLAS_SIZE,
  });
}

/* ============================================================
   Atlas 纹理
   ============================================================ */
export const atlasTexture = new THREE.CanvasTexture(atlasCanvas);
atlasTexture.magFilter = THREE.NearestFilter;
atlasTexture.minFilter = THREE.LinearMipmapLinearFilter;
if (!IS_WORKER){
  atlasTexture.mipmaps = buildMipmaps(atlasCanvas, 3);
  atlasTexture.anisotropy = 8;
  atlasTexture.needsUpdate = true;
} else {
  atlasTexture.anisotropy = 1;
}
atlasTexture.generateMipmaps = false;
atlasTexture.colorSpace = THREE.SRGBColorSpace;

_atlasReady = true;

if (typeof window !== 'undefined'){
  window.__atlasCanvas__ = atlasCanvas;
}

export const atlasCanvasEl = atlasCanvas;

console.log(`[textures] atlas 初始化完成：used ${texCounter} / ${ATLAS_TOTAL}（${ATLAS_COLS}×${ATLAS_COLS}）`);
console.log(`[textures] TILE=${ATLAS_TILE} INNER=${TEX_INNER} PAD=${TEX_PAD} · mipmap=4层 · aniso=8 · 双套树叶`);