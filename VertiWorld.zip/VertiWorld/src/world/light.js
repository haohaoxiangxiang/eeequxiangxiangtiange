/* ============================================================
   light.js —— 天空光 + 方块光（0-15）
   ------------------------------------------------------------
   两条路径：

   ① 全量计算  computeChunkLight(chunk)
      新建 / 从磁盘读出的 chunk 用。垂直扫描 + BFS，O(chunk 体积)。

   ② 增量更新  lightOnBlockChange(map, wx, wy, wz)
      ★ 平时放/挖方块走这条。老版本这里是「把 9 个 chunk 全量重算一遍」
        （实测 9 × 29.6ms ≈ 266ms/次，主线程直接卡住），
        而且没有「移除光照」这一步，堵住洞口后光是回不去的（只会残留在
        邻居 chunk 里，表现就是「只变暗一点点」）。
      现在改成标准的两段 BFS：
        · 移除 BFS：把原本依赖这一格光的格子一路抹掉
        · 添加 BFS：再从四周还亮着的格子把光重新灌回来
      只碰受影响的那几百格，跨 chunk 自动传播。

   ⚠ 天光的两条特殊规则（和全量计算保持一致）：
     · 光不向上传播（`isSky && ny > wy` 直接跳过）
     · 从 15 的值【向下】传播时不衰减（所以竖直井里一柱到底都是 15）
   ============================================================ */

import { CS, CHH, Y_MIN } from './../core/engine-core.js';
import { BLOCKS } from './blocks.js';

const MAX = 15;
const LAYER = CS * CS;

/* ★ 光照等级 0~15 里，方块发光只使用 1~14：
   0 保留给"完全不发光"，15 保留给以后的功能（例如自定义强光源）。
   所有发光方块在这里统一收敛，避免某个方块直接写到 15。 */
const EMIT_MIN = 1;
const EMIT_MAX = 14;
function _clampEmit(v){
  if (!(v > 0)) return 0;
  return Math.max(EMIT_MIN, Math.min(EMIT_MAX, v | 0));
}

/* 本地坐标索引（只给全量计算用） */
function _idx(x, y, z) {
  return (((y - Y_MIN) * CS) + z) * CS + x;
}

/* 世界坐标索引：JS 的位运算对负数也成立（-1 >> 4 = -1，-1 & 15 = 15） */
function _widx(wx, wy, wz) {
  return (((wy - Y_MIN) * CS) + (wz & 15)) * CS + (wx & 15);
}

/* 方块属性查表：blockId → 0/1，避免在十几万格的循环里反复做对象属性访问。
   mod 运行时注册新方块会让 BLOCKS.length 变，长度不一致时自动重建。 */
let _tblOpaq = null, _tblFilt = null, _tblEmit = null, _tblLen = -1;
function _ensureTables(){
  const n = BLOCKS.length;
  if (_tblLen === n && _tblOpaq) return;
  _tblOpaq = new Uint8Array(n);
  _tblFilt = new Uint8Array(n);
  _tblEmit = new Uint8Array(n);
  for (let i = 0; i < n; i++){
    const b = BLOCKS[i];
    if (!b) continue;
    _tblOpaq[i] = (b.opaque && !b.transparent) ? 1 : 0;
    _tblFilt[i] = b.lightFilter || 0;
    _tblEmit[i] = _clampEmit(b.light);
  }
  _tblLen = n;
}
function _isOpaque(id){ _ensureTables(); return id < _tblLen ? _tblOpaq[id] : 0; }
function _filterTbl(id){ _ensureTables(); return id < _tblLen ? _tblFilt[id] : 0; }
function _emitTbl(id){ _ensureTables(); return id < _tblLen ? _tblEmit[id] : 0; }

const _ck = (cx, cz) => cx * 100000 + cz;

function _blocked(id){
  const b = BLOCKS[id];
  return !!(b && b.opaque && !b.transparent);
}
function _filterOf(id){
  const b = BLOCKS[id];
  return (b && b.lightFilter) || 0;
}

/* 统计（诊断面板 / 测试用） */
export const lightStats = { fullChunks: 0, incremental: 0, lastCells: 0, maxCells: 0 };
export function resetLightStats(){
  lightStats.fullChunks = 0; lightStats.incremental = 0;
  lightStats.lastCells = 0; lightStats.maxCells = 0;
}

/* =================================================================
   ① 全量计算（新建 / 读盘 chunk）
   ================================================================= */

function _collectBorderSeeds(chunk, arr, isSky, queue, getMap) {
  if (!getMap) return;
  let map = getMap();
  if (!map) return;
  const cx = chunk.cx, cz = chunk.cz;
  const dirs = [
    { dx: 1, dz: 0, selfX: CS - 1, nbrX: 0 },
    { dx: -1, dz: 0, selfX: 0, nbrX: CS - 1 },
    { dx: 0, dz: 1, selfZ: CS - 1, nbrZ: 0 },
    { dx: 0, dz: -1, selfZ: 0, nbrZ: CS - 1 },
  ];
  for (const d of dirs) {
    let nc = null;
    try {
      const ck = (cx + d.dx) * 100000 + (cz + d.dz);
      nc = map.get(ck);
    } catch(e){}
    if (!nc || !nc.blocks) continue;
    const nbrArr = isSky ? nc.skyLight : nc.blockLight;
    if (!nbrArr) continue;
    for (let w = 0; w < CS; w++) {
      for (let y = Y_MIN; y < CHH; y++) {
        let selfLx, selfLz, nbrLx, nbrLz;
        if (d.dx !== 0) { selfLx = d.selfX; selfLz = w; nbrLx = d.nbrX; nbrLz = w; }
        else { selfLx = w; selfLz = d.selfZ; nbrLx = w; nbrLz = d.nbrZ; }
        const nbrI = _idx(nbrLx, y, nbrLz);
        const nbrLight = nbrArr[nbrI] || 0;
        if (nbrLight <= 1) continue;
        const selfI = _idx(selfLx, y, selfLz);
        const nblk = BLOCKS[chunk.blocks[selfI]];
        if (nblk && nblk.opaque && !nblk.transparent) continue;
        const filter = (nblk && nblk.lightFilter) || 0;
        const newL = Math.max(0, nbrLight - 1 - filter);
        if (newL > arr[selfI] && newL > 0) {
          arr[selfI] = newL;
          queue.push(selfI);
        }
      }
    }
  }
}

function _bfsSpreadFrom(chunk, arr, queue, isSky, getMap) {
  let head = 0;
  while (head < queue.length) {
    const i = queue[head++];
    const lv = arr[i];
    if (lv <= 1) continue;

    const y = Math.floor(i / LAYER) + Y_MIN;
    const rem = i % LAYER;
    const z = Math.floor(rem / CS);
    const x = rem % CS;

    for (let d = 0; d < 6; d++) {
      let nx = x, ny = y, nz = z;
      if (d === 0) nx++;
      else if (d === 1) nx--;
      else if (d === 2) ny++;
      else if (d === 3) ny--;
      else if (d === 4) nz++;
      else nz--;

      if (nx < 0 || nx >= CS || nz < 0 || nz >= CS) continue;
      if (ny < Y_MIN || ny >= CHH) continue;
      if (isSky && ny > y) continue;

      const ni = _idx(nx, ny, nz);
      const nblk = BLOCKS[chunk.blocks[ni]];
      if (nblk && nblk.opaque && !nblk.transparent) continue;

      const filter = (nblk && nblk.lightFilter) || 0;
      const nl = Math.max(0, lv - 1 - filter);
      if (nl > arr[ni] && nl > 0) {
        arr[ni] = nl;
        queue.push(ni);
      }
    }
  }
}

function _computeSkyFull(chunk, getMap) {
  const sky = chunk.skyLight;
  sky.fill(0);

  _ensureTables();
  const blocks = chunk.blocks;

  /* 垂直扫描：一柱到底保持 15，遇到挡光方块归零。
     · 查表代替对象属性访问
     · 一旦这一列变成 0 就直接跳出（下面全是 0，fill(0) 已经处理）
     · 顺便记下每列最底部那个亮格（bottom），后面只从"暴露面"起 BFS */
  for (let z = 0; z < CS; z++) {
    for (let x = 0; x < CS; x++) {
      let lv = MAX;
      for (let y = CHH - 1; y >= Y_MIN; y--) {
        const i = _idx(x, y, z);
        const id = blocks[i];
        if (id < _tblLen && _tblOpaq[id]) break;
        if (lv <= 0) break;
        sky[i] = lv;
        const f = id < _tblLen ? _tblFilt[id] : 0;
        if (f > 0) lv = Math.max(0, lv - f);
      }
    }
  }

  /* ★ 只从"暴露面"起 BFS。
     原来是把所有 15 的格子全塞进队列 —— 一个区块有 8 万多格是 15，
     而它们的邻居也全是 15，出去最多变成 14，纯属白跑（实测占 25ms 里的 24ms）。
     这里只挑"有邻居不是 15"的格子：其余格子传播不了任何新东西。
     跨 chunk 的部分仍由 _collectBorderSeeds / propagateChunkLight 负责。 */
  const queue = [];
  const lastY = CHH - 1;
  for (let z = 0; z < CS; z++) {
    for (let y = Y_MIN; y < CHH; y++) {
      const rowBase = ((y - Y_MIN) * CS + z) * CS;
      const upOk = y > Y_MIN, downOk = y < lastY;
      for (let x = 0; x < CS; x++) {
        const i = rowBase + x;
        if (sky[i] !== MAX) continue;
        if ((x > 0      && sky[i - 1] !== MAX) ||
            (x < CS - 1 && sky[i + 1] !== MAX) ||
            (z > 0      && sky[i - CS] !== MAX) ||
            (z < CS - 1 && sky[i + CS] !== MAX) ||
            (upOk       && sky[i - LAYER] !== MAX) ||
            (downOk     && sky[i + LAYER] !== MAX)) {
          queue.push(i);
        }
      }
    }
  }
  _collectBorderSeeds(chunk, sky, true, queue, getMap);
  _bfsSpreadFrom(chunk, sky, queue, true, getMap);
}

function _computeBlockFull(chunk, getMap) {
  const light = chunk.blockLight;
  light.fill(0);

  _ensureTables();
  const blocks = chunk.blocks;
  const queue = [];
  for (let i = 0; i < blocks.length; i++) {
    const id = blocks[i];
    if (id < _tblLen && _tblEmit[id]) {
      light[i] = _tblEmit[id];
      queue.push(i);
    }
  }
  _collectBorderSeeds(chunk, light, false, queue, getMap);
  if (queue.length > 0) _bfsSpreadFrom(chunk, light, queue, false, getMap);
}

/* =================================================================
   ② 增量更新（单个方块变化）
   ================================================================= */

/* 单次更新内的 chunk 缓存：一次改方块最多碰 3×3 个 chunk */
function _chunkCached(map, cache, cx, cz){
  const k = _ck(cx, cz);
  if (cache.has(k)) return cache.get(k);
  let c = null;
  try { c = map.get(k) || null; } catch(e){ c = null; }
  if (c && !c.blocks) c = null;
  cache.set(k, c);
  return c;
}

function _arrOf(c, isSky, make){
  let a = isSky ? c.skyLight : c.blockLight;
  if (!a || a.length !== c.blocks.length){
    if (!make) return null;
    a = new Uint8Array(c.blocks.length);
    if (isSky) c.skyLight = a; else c.blockLight = a;
  }
  return a;
}

function _chunkAtW(map, cache, wx, wz){
  return _chunkCached(map, cache, wx >> 4, wz >> 4);
}

/* 读光（越界 / 未加载 → 0；头顶以上对天光来说是满值） */
function _gl(map, cache, isSky, wx, wy, wz){
  if (wy >= CHH) return isSky ? MAX : 0;
  if (wy < Y_MIN) return 0;
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c) return 0;
  const a = _arrOf(c, isSky, false);
  if (!a) return 0;
  return a[_widx(wx, wy, wz)] || 0;
}

/* 写光；返回是否真的变了。变了就把 chunk 记进 changed（要重建网格） */
function _sl(map, cache, isSky, wx, wy, wz, v, changed){
  if (wy >= CHH || wy < Y_MIN) return false;
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c) return false;
  const a = _arrOf(c, isSky, true);
  if (!a) return false;
  const i = _widx(wx, wy, wz);
  if (a[i] === v) return false;
  a[i] = v;
  if (changed) changed.add(_ck(c.cx, c.cz));
  lightStats.lastCells++;
  return true;
}

/* 读方块 id；返回 -1 表示「读不到」（越界 / chunk 未加载）→ BFS 到此为止 */
function _gb(map, cache, wx, wy, wz){
  if (wy >= CHH || wy < Y_MIN) return -1;
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c) return -1;
  return c.blocks[_widx(wx, wy, wz)];
}

/* 衰减量
   · 天光从 15 竖直向下：不扣每步的 1，只扣【来源格】的 lightFilter
     （和垂直扫描 `lv = lv - blk.lightFilter` 完全一致）
   · 其余情况：每格 -1，再扣【目标格】的 lightFilter
   ⚠ 这里扣"来源"而不是"目标"很关键：岩浆/树叶的格子里存的是过滤【之前】
     的 15，如果扣目标的 filter，光穿过去之后又会变回 15（实测就是这个 bug）。 */
function _decay(isSky, fromLevel, goingDown, srcFilter, tgtFilter){
  if (isSky && goingDown && fromLevel === MAX) return srcFilter;
  return 1 + tgtFilter;
}

const _DX = [1, -1, 0, 0, 0, 0];
const _DY = [0, 0, 1, -1, 0, 0];
const _DZ = [0, 0, 0, 0, 1, -1];

/* 添加 BFS：queue 是扁平数组 wx,wy,wz,...（读它们数组里现有的亮度往外推） */
function _addBfs(map, cache, isSky, q, changed){
  for (let h = 0; h < q.length; h += 3){
    const wx = q[h], wy = q[h + 1], wz = q[h + 2];
    const lv = _gl(map, cache, isSky, wx, wy, wz);
    if (lv <= 1) continue;
    const srcF = _filterOf(_gb(map, cache, wx, wy, wz));
    for (let d = 0; d < 6; d++){
      const nx = wx + _DX[d], ny = wy + _DY[d], nz = wz + _DZ[d];
      if (ny < Y_MIN || ny >= CHH) continue;
      if (isSky && ny > wy) continue;                 /* 天光不上行 */
      const id = _gb(map, cache, nx, ny, nz);
      if (id < 0) continue;                           /* 未加载：不传播 */
      if (_blocked(id)) continue;
      const nl = lv - _decay(isSky, lv, ny < wy, srcF, _filterOf(id));
      if (nl <= 0) continue;
      if (nl > _gl(map, cache, isSky, nx, ny, nz)){
        _sl(map, cache, isSky, nx, ny, nz, nl, changed);
        q.push(nx, ny, nz);
      }
    }
  }
}

/* 移除 BFS：queue 是扁平数组 wx,wy,wz,旧亮度,...
   · 比"来源能给出的"还暗（或刚好相等）→ 说明是它给的，清 0 继续传播
   · 比来源还亮 → 说明它自己是独立光源，塞进 addQ 稍后重新点亮四周 */
function _removeBfs(map, cache, isSky, q, addQ, changed){
  for (let h = 0; h < q.length; h += 4){
    const wx = q[h], wy = q[h + 1], wz = q[h + 2], lv = q[h + 3];
    if (lv <= 0) continue;
    const srcF = _filterOf(_gb(map, cache, wx, wy, wz));
    for (let d = 0; d < 6; d++){
      const nx = wx + _DX[d], ny = wy + _DY[d], nz = wz + _DZ[d];
      if (ny < Y_MIN || ny >= CHH) continue;
      if (isSky && ny > wy) continue;
      const id = _gb(map, cache, nx, ny, nz);
      if (id < 0) continue;
      if (_blocked(id)) continue;
      const nlv = _gl(map, cache, isSky, nx, ny, nz);
      if (nlv <= 0) continue;
      const reach = lv - _decay(isSky, lv, ny < wy, srcF, _filterOf(id));
      if (nlv <= reach){
        _sl(map, cache, isSky, nx, ny, nz, 0, changed);
        q.push(nx, ny, nz, nlv);
      } else {
        addQ.push(nx, ny, nz);
      }
    }
  }
}

/* 播种改动格周围的 6 个邻居（注意：天光的"不上行"只限制传播方向，
   不限制"从哪些邻居取光"，所以正上方也要播种） */
function _seedNeighbors(wx, wy, wz, add){
  for (let d = 0; d < 6; d++){
    const nx = wx + _DX[d], ny = wy + _DY[d], nz = wz + _DZ[d];
    if (ny < Y_MIN || ny >= CHH) continue;
    add.push(nx, ny, nz);
  }
}

/* ---- 方块光 ---- */
function _updateBlockChannel(map, cache, wx, wy, wz, changed){
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c) return;
  const arr = _arrOf(c, false, true);
  if (!arr) return;

  const i = _widx(wx, wy, wz);
  const id = c.blocks[i];
  const blocked = _blocked(id);

  const removal = [];
  const add = [];

  /* 先把这一格自己原本的光拿掉 */
  const cur = arr[i] || 0;
  if (cur > 0){
    arr[i] = 0;
    changed.add(_ck(c.cx, c.cz));
    removal.push(wx, wy, wz, cur);
  }
  if (removal.length) _removeBfs(map, cache, false, removal, add, changed);

  /* ★ 不能加 !blocked —— 荧石 / 海晶灯这类实心方块本身也是光源 */
  if (id > 0){
    const b = BLOCKS[id];
    const emit = _clampEmit(b && b.light);
    if (emit > 0){
      if (arr[i] !== emit){ arr[i] = emit; changed.add(_ck(c.cx, c.cz)); }
      add.push(wx, wy, wz);
    }
  }
  if (!blocked) _seedNeighbors(wx, wy, wz, add);

  if (add.length) _addBfs(map, cache, false, add, changed);
}

/* ---- 天空光 ----
   ★ 天光是两套机制取较大值：
       a) 直射列：自顶向下一柱到底都是 15，穿过半透明方块只减 lightFilter
          （注意【不】减每步的 1 —— 这正是它和普通 BFS 的区别）
       b) 横向 BFS：从所有 15 的格子出发，每步 -1 - lightFilter，且不上行
   只处理"被改动的那一格"是不够的：改一格会改变它下方整列的直射值。
   所以这里显式重算整列直射值再和数组比对，这样增量结果和全量计算逐格一致。 */
function _updateSkyChannel(map, cache, wx, wy, wz, changed){
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c) return;
  _arrOf(c, true, true);

  const removal = [];
  const add = [];
  const col = new Int8Array(CHH - Y_MIN);      /* -1 = 实心格（不写光） */

  /* 1) 整列直射值（和 _computeSkyFull 的垂直扫描完全同一套规则） */
  let lv = MAX;
  for (let y = CHH - 1; y >= Y_MIN; y--){
    const id = _gb(map, cache, wx, y, wz);
    if (id < 0){ lv = 0; col[y - Y_MIN] = 0; continue; }
    if (_blocked(id)){
      col[y - Y_MIN] = -1;
      lv = 0;
    } else {
      col[y - Y_MIN] = lv;
      const f = _filterOf(id);
      if (f > 0) lv = Math.max(0, lv - f);
    }
  }

  /* 2) 变暗的格子先清掉，作为移除 BFS 的种子 */
  for (let y = CHH - 1; y >= Y_MIN; y--){
    const d = col[y - Y_MIN];
    const want = d < 0 ? 0 : d;
    const cur = _gl(map, cache, true, wx, y, wz);
    if (want >= cur) continue;
    _sl(map, cache, true, wx, y, wz, 0, changed);
    removal.push(wx, y, wz, cur);
  }

  /* 3) 移除 BFS（会把依赖这些光的格子一路抹掉） */
  if (removal.length) _removeBfs(map, cache, true, removal, add, changed);

  /* 4) ★ 再补上直射值（必须在移除 BFS 之后！
        放前面的话，刚写好的直射值会被后面的移除 BFS 又清掉，
        结果只剩 BFS 那条少一档的路径 —— 就是差 1 的来源） */
  for (let y = CHH - 1; y >= Y_MIN; y--){
    const d = col[y - Y_MIN];
    const want = d < 0 ? 0 : d;
    if (want <= 0) continue;
    if (want > _gl(map, cache, true, wx, y, wz)){
      _sl(map, cache, true, wx, y, wz, want, changed);
      add.push(wx, y, wz);
    }
  }

  /* 4) 这一格如果现在能透光，就从 6 个邻居把横向的光引进来
        （洞打通了但头顶还是实心，光只能从旁边来，全靠这一步） */
  const id = _gb(map, cache, wx, wy, wz);
  if (id > 0 && !_blocked(id)) _seedNeighbors(wx, wy, wz, add);
  else if (id === 0) _seedNeighbors(wx, wy, wz, add);

  if (add.length) _addBfs(map, cache, true, add, changed);
}

/**
 * ★ 单个方块变化后的增量光照。
 * @param {Function|Map} getMap  返回 chunkMap 的函数（或直接给 Map）
 * @param {number} wx,wy,wz      世界坐标（方块已经写进 blocks 之后调用）
 * @param {Set} [changed]        收集"光真的变了"的 chunkKey，用来标脏重建网格
 * @returns {Set} changed
 */
export function lightOnBlockChange(getMap, wx, wy, wz, changed, oldId){
  changed = changed || new Set();
  if (wy < Y_MIN || wy >= CHH) return changed;

  /* ★ 快速跳过：方块换了但"挡光/过滤/发光"三件事都没变（比如 空气→雪层、
     石头→泥土），光照结果一模一样，一步都不用算。
     批量改方块（积雪、爆炸、fillBox）时这个短路能省掉绝大部分开销。 */
  if (oldId !== undefined && oldId !== null){
    const c0 = (function(){
      try {
        const m = (typeof getMap === 'function') ? getMap() : getMap;
        return m ? m.get(((wx >> 4) * 100000 + (wz >> 4))) : null;
      } catch(e){ return null; }
    })();
    if (c0 && c0.blocks){
      const newId = c0.blocks[_widx(wx, wy, wz)];
      const oldEmit = (BLOCKS[oldId] && BLOCKS[oldId].light) || 0;
      const newEmit = (BLOCKS[newId] && BLOCKS[newId].light) || 0;
      if (_blocked(oldId) === _blocked(newId) &&
          _filterOf(oldId) === _filterOf(newId) &&
          oldEmit === newEmit){
        return changed;
      }
    }
  }
  let map = null;
  try { map = (typeof getMap === 'function') ? getMap() : getMap; } catch(e){ map = null; }
  if (!map) return changed;

  const cache = new Map();
  lightStats.incremental++;
  lightStats.lastCells = 0;

  try {
    _updateSkyChannel(map, cache, wx, wy, wz, changed);
    _updateBlockChannel(map, cache, wx, wy, wz, changed);
  } catch(e){
    console.warn('[light] 增量更新失败，回退全量:', e);
    const c = _chunkAtW(map, cache, wx, wz);
    if (c) computeChunkLight(c, getMap);
  }

  if (lightStats.lastCells > lightStats.maxCells) lightStats.maxCells = lightStats.lastCells;
  return changed;
}

/**
 * ★ 新建 / 读盘后，把本 chunk 边界上的光往 4 个邻居推一次。
 * 以前这里对 8 个邻居各做一次全量重算（9 × 29.6ms），现在只推边界。
 */
export function propagateChunkLight(chunk, getMap){
  const changed = new Set();
  if (!chunk || !chunk.blocks) return changed;
  let map = null;
  try { map = (typeof getMap === 'function') ? getMap() : getMap; } catch(e){ map = null; }
  if (!map) return changed;

  const cache = new Map();
  cache.set(_ck(chunk.cx, chunk.cz), chunk);

  const yMax = Math.min(CHH - 1, (chunk.maxY != null ? chunk.maxY : CHH - 1) + 1);
  const yMin = Math.max(Y_MIN, (chunk.minY != null ? chunk.minY : Y_MIN) - 1);

  const qSky = [], qBlk = [];
  const arS = chunk.skyLight, arB = chunk.blockLight;

  /* 四个方向：自己边界格 → 邻居边界格。只有"能给邻居更亮的"才需要播种
     （跨 chunk 的两个边界格都是 15 是常态，占绝大多数，必须提前滤掉） */
  const DIRS = [ [1, 0], [-1, 0], [0, 1], [0, -1] ];
  for (const [dx, dz] of DIRS){
    const nc = _chunkCached(map, cache, chunk.cx + dx, chunk.cz + dz);
    if (!nc || !nc.blocks) continue;
    const nS = _arrOf(nc, true, false), nB = _arrOf(nc, false, false);
    if (!nS && !nB) continue;

    const myX  = dx === 1 ? CS - 1 : dx === -1 ? 0 : -1;
    const nbrX = dx === 1 ? 0 : dx === -1 ? CS - 1 : -1;
    const myZ  = dz === 1 ? CS - 1 : dz === -1 ? 0 : -1;
    const nbrZ = dz === 1 ? 0 : dz === -1 ? CS - 1 : -1;

    for (let w = 0; w < CS; w++){
      const lx = myX >= 0 ? myX : w,  lz = myZ >= 0 ? myZ : w;
      const nx = nbrX >= 0 ? nbrX : w, nz = nbrZ >= 0 ? nbrZ : w;
      const wx = chunk.cx * CS + lx, wz = chunk.cz * CS + lz;
      for (let y = yMin; y <= yMax; y++){
        const li  = (((y - Y_MIN) * CS) + lz) * CS + lx;
        const nli = (((y - Y_MIN) * CS) + nz) * CS + nx;

        const sl = arS ? (arS[li] || 0) : 0;
        if (sl > 1 && nS && nS[nli] < sl - 1) qSky.push(wx, y, wz);

        const bl = arB ? (arB[li] || 0) : 0;
        if (bl > 1 && nB && nB[nli] < bl - 1) qBlk.push(wx, y, wz);
      }
    }
  }

  try {
    if (qSky.length) _addBfs(map, cache, true,  qSky, changed);
    if (qBlk.length) _addBfs(map, cache, false, qBlk, changed);
  } catch(e){
    console.warn('[light] 边界传播失败:', e);
  }
  return changed;
}

/* =================================================================
   ②.5 临时光源（移动光源注入）
   ------------------------------------------------------------
   移动光源（手持发光物、发光掉落物、飞行中的豆子/箭）在体素光模式下
   并不存在一个真实方块，所以这里临时往 blockLight 里写一格光，
   传播规则与真实光源完全一致（每格 -1、半透明方块扣 lightFilter）。
   ★ 只写方块光通道，天光完全不受影响。
   ★ 必须成对调用：setTempLight 注入，clearTempLight 撤销；
     撤销时先清 0 触发移除 BFS，再恢复这一格方块自身的 emit。
   ================================================================= */

const _tempLightCells = new Map();   /* "wx,wy,wz" -> 当前注入等级 */

function _tempKey(wx, wy, wz){ return wx + ',' + wy + ',' + wz; }

function _readMap(getMap){
  try { return (typeof getMap === 'function') ? getMap() : getMap; }
  catch(e){ return null; }
}

/**
 * 在 (wx,wy,wz) 临时注入一档方块光。
 * @param {Function|Map} getMap  chunkMap 获取函数（或直接给 Map）
 * @param {number} level         1~14
 * @returns {Set} 光真的变了的 chunkKey
 */
export function setTempLight(getMap, wx, wy, wz, level){
  const changed = new Set();
  const map = _readMap(getMap);
  if (!map) return changed;
  if (wy < Y_MIN || wy >= CHH) return changed;

  level = _clampEmit(level | 0);
  if (level <= 0) return clearTempLight(map, wx, wy, wz);

  const cache = new Map();
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c || !c.blocks) return changed;
  const i = _widx(wx, wy, wz);
  const id = c.blocks[i];
  if (_blocked(id)) return changed;              /* 实心格不注入 */

  const arr = _arrOf(c, false, true);
  if (!arr) return changed;

  const key = _tempKey(wx, wy, wz);
  const prev = _tempLightCells.get(key) || 0;
  const emit = id > 0 ? _clampEmit(BLOCKS[id] && BLOCKS[id].light) : 0;
  const want = Math.max(emit, level);

  _tempLightCells.set(key, level);
  if (prev === level && (arr[i] || 0) >= want) return changed;

  const removal = [];
  const add = [];
  const cur = arr[i] || 0;
  if (cur > 0){
    arr[i] = 0;
    changed.add(_ck(c.cx, c.cz));
    removal.push(wx, wy, wz, cur);
  }
  if (removal.length) _removeBfs(map, cache, false, removal, add, changed);

  arr[i] = want;
  changed.add(_ck(c.cx, c.cz));
  add.push(wx, wy, wz);
  _seedNeighbors(wx, wy, wz, add);
  _addBfs(map, cache, false, add, changed);
  return changed;
}

/**
 * 撤销 (wx,wy,wz) 上的临时光，恢复方块自身 emit。
 * @returns {Set} 光真的变了的 chunkKey
 */
export function clearTempLight(getMap, wx, wy, wz){
  const changed = new Set();
  const key = _tempKey(wx, wy, wz);
  if (!_tempLightCells.has(key)) return changed;
  _tempLightCells.delete(key);

  const map = _readMap(getMap);
  if (!map) return changed;
  if (wy < Y_MIN || wy >= CHH) return changed;

  const cache = new Map();
  const c = _chunkAtW(map, cache, wx, wz);
  if (!c || !c.blocks) return changed;
  const arr = _arrOf(c, false, true);
  if (!arr) return changed;

  const i = _widx(wx, wy, wz);
  const id = c.blocks[i];
  const emit = id > 0 ? _clampEmit(BLOCKS[id] && BLOCKS[id].light) : 0;

  const removal = [];
  const add = [];
  const cur = arr[i] || 0;
  if (cur > 0){
    arr[i] = 0;
    changed.add(_ck(c.cx, c.cz));
    removal.push(wx, wy, wz, cur);
  }
  if (removal.length) _removeBfs(map, cache, false, removal, add, changed);

  if (emit > 0){
    arr[i] = emit;
    changed.add(_ck(c.cx, c.cz));
    add.push(wx, wy, wz);
  }
  if (!_blocked(id)) _seedNeighbors(wx, wy, wz, add);
  if (add.length) _addBfs(map, cache, false, add, changed);
  return changed;
}

/** 当前已注入的临时光数量（调试 / 调度器用） */
export function getTempLightCount(){ return _tempLightCells.size; }

/** 换世界时丢弃记录（旧 chunk 已不存在，不要再去写光） */
export function resetTempLights(){ _tempLightCells.clear(); }

/* =================================================================
   对外 API
   ================================================================= */

export function computeChunkLight(chunk, getMap) {
  if (!chunk || !chunk.blocks) return;
  const size = chunk.blocks.length;
  if (!chunk.skyLight || chunk.skyLight.length !== size) chunk.skyLight = new Uint8Array(size);
  if (!chunk.blockLight || chunk.blockLight.length !== size) chunk.blockLight = new Uint8Array(size);

  lightStats.fullChunks++;
  _computeSkyFull(chunk, getMap);
  _computeBlockFull(chunk, getMap);
}

/* 兼容旧接口：外部（mod）想强制重算某个 chunk 时用 */
export function updateLightAt(chunk, lx, ly, lz, getMap) {
  computeChunkLight(chunk, getMap);
}
export function recomputeChunkLight(chunk, getMap) {
  computeChunkLight(chunk, getMap);
}

export function getLightLevel(skyArr, blockArr, lx, y, lz) {
  if (y >= CHH) return 15;
  if (y < Y_MIN) return 0;
  if (!skyArr) return 15;
  if (lx < 0 || lx >= CS || lz < 0 || lz >= CS) return 15;
  const i = _idx(lx, y, lz);
  const s = skyArr[i] || 0;
  const b = blockArr ? (blockArr[i] || 0) : 0;
  return s > b ? s : b;
}
