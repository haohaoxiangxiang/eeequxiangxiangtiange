/* ============================================================
   lost-city-runtime.js —— 失落古城的运行时逻辑
   ------------------------------------------------------------
   · 玩家靠近时填充房屋宝箱（每存档只填一次）
   · 广场中央生成 Boss「故障守卫」
   · Boss 死亡后在广场中央放置宝箱并写入战利品
   ============================================================ */

import { player } from '../player/player-core.js';
import {
  getLostCityPos, getBlockWorld, setBlockWorld,
} from './terrain.js';
import { B } from './blocks.js';
import {
  spawnEntity, animals,
} from '../entities/entities-core.js';
import { setChestItems } from '../items/items-core.js';
import {
  getCurrentSave, readSaveJson, writeSaveJson,
} from '../save/save-core.js';
import { cityChestPoints, cityBossPoint } from './core/lost-city.js';
import { on } from '../core/engine-core.js';
import { toast } from '../ui/ui.js';

const MARKER = 'lost_city.json';
const BOSS_TYPE = 'ruin_guardian';
const ACTIVATE_DIST = 110;

const S = {
  saveId: null,
  loaded: false,
  loading: false,
  marker: null,
  seeded: new Set(),
  acc: 0,
  bossSpawned: false,
};

export function resetLostCityRuntime(){
  S.saveId = null;
  S.loaded = false;
  S.loading = false;
  S.marker = null;
  S.seeded = new Set();
  S.acc = 0;
  S.bossSpawned = false;
}

function ri(n){ return Math.floor(Math.random() * n); }

/* ============================================================
   战利品
   ============================================================ */
function houseLoot(){
  const items = [];
  if (Math.random() < 0.55) items.push({ name: 'copper_ingot', count: 2 + ri(3) });
  if (Math.random() < 0.35) items.push({ name: 'iron_ingot', count: 1 + ri(2) });
  if (Math.random() < 0.30) items.push({ name: 'cooked_pork', count: 1 + ri(2) });
  if (Math.random() < 0.30) items.push({ name: 'torch', count: 2 + ri(3) });
  if (Math.random() < 0.25) items.push({ name: 'arrow', count: 4 + ri(5) });
  if (Math.random() < 0.20) items.push({ name: 'magic_dust', count: 1 + ri(2) });
  if (Math.random() < 0.14) items.push({ name: 'gold_ingot', count: 1 + ri(2) });
  if (Math.random() < 0.07) items.push({ name: 'diamond_gem', count: 1 });
  if (items.length === 0) items.push({ name: 'copper_ingot', count: 2 });
  return items;
}

function bossLoot(){
  const items = [];

  /* 石头法杖：有几率 */
  if (Math.random() < 0.65) items.push({ name: 'stone_staff', count: 1 });

  /* 远古石套：有几率开出 1~3 件 */
  if (Math.random() < 0.75){
    const pieces = ['ancient_helmet', 'ancient_chestplate',
                    'ancient_leggings', 'ancient_boots'];
    for (let i = pieces.length - 1; i > 0; i--){
      const j = ri(i + 1);
      const t = pieces[i]; pieces[i] = pieces[j]; pieces[j] = t;
    }
    const n = 1 + ri(3);
    for (let i = 0; i < n; i++) items.push({ name: pieces[i], count: 1 });
  }

  /* 其它宝物 */
  items.push({ name: 'diamond_gem', count: 2 + ri(3) });
  items.push({ name: 'gold_ingot', count: 3 + ri(5) });
  items.push({ name: 'iron_ingot', count: 4 + ri(6) });
  if (Math.random() < 0.5) items.push({ name: 'magic_dust', count: 2 + ri(4) });
  return items;
}

/* ============================================================
   结构是否已生成（防止旧存档在空地上刷 Boss）
   ============================================================ */
const FLOOR_IDS = new Set([
  B.stone_bricks.id, B.cobble.id, B.mossy_stone_bricks.id, B.mossy_stone.id,
]);

function cityReady(pos){
  const probes = [[0, 0], [8, 0], [-8, 0], [0, 8], [0, -8]];
  let ok = 0;
  for (const [dx, dz] of probes){
    const id = getBlockWorld(pos.x + dx, pos.baseY, pos.z + dz);
    if (FLOOR_IDS.has(id)) ok++;
  }
  return ok >= 3;
}

function hasBoss(){
  for (const a of animals){
    if (a && !a.dead && a.type === BOSS_TYPE) return true;
  }
  return false;
}

/* ============================================================
   存档标记
   ============================================================ */
async function loadMarker(saveId){
  S.loading = true;
  let data = null;
  try { data = await readSaveJson(saveId, MARKER); } catch(e){}
  S.marker = data && typeof data === 'object' ? data : { chests: false, defeated: false };
  S.loading = false;
  S.loaded = true;
}

function saveMarker(){
  const save = getCurrentSave();
  if (!save || !save.id || !S.marker) return;
  try { writeSaveJson(save.id, MARKER, S.marker); } catch(e){}
}

/* ============================================================
   宝箱填充（每个存档只执行一次）
   ============================================================ */
function seedChests(pos){
  if (!S.marker || S.marker.chests) return;
  const pts = cityChestPoints(pos.x, pos.z, pos.baseY);
  for (let i = 0; i < pts.length; i++){
    if (S.seeded.has(i)) continue;
    const c = pts[i];
    S.seeded.add(i);
    setChestItems(c.x, c.y, c.z, houseLoot()).catch(() => {});
  }
  S.marker.chests = true;
  saveMarker();
}

/* ============================================================
   Boss 死亡 → 广场宝箱
   ============================================================ */
function onBossDeath(){
  const save = getCurrentSave();
  const pos = getLostCityPos();
  if (!save || !save.id || !pos) return;

  const y = pos.baseY + 1;
  if (getBlockWorld(pos.x, y, pos.z) !== B.chest.id){
    setBlockWorld(pos.x, y, pos.z, B.chest.id);
  }
  setChestItems(pos.x, y, pos.z, bossLoot()).catch(() => {});

  S.marker = S.marker || { chests: true };
  S.marker.chests = true;
  S.marker.defeated = true;
  saveMarker();
  toast('故障守卫已被击败，广场中央出现了宝箱');
}

/* ============================================================
   初始化 / 每帧调度
   ============================================================ */
export function initLostCityRuntime(){
  on('lostcity.boss.death', onBossDeath);
}

export function updateLostCity(dt){
  S.acc += dt;
  if (S.acc < 1) return;
  S.acc = 0;

  const save = getCurrentSave();
  if (!save || !save.id){ resetLostCityRuntime(); return; }

  const pos = getLostCityPos();
  if (!pos) return;

  if (S.saveId !== save.id){
    resetLostCityRuntime();
    S.saveId = save.id;
  }

  const dx = player.pos.x - pos.x;
  const dz = player.pos.z - pos.z;
  if (dx * dx + dz * dz > ACTIVATE_DIST * ACTIVATE_DIST) return;

  if (!S.loaded){
    if (!S.loading) loadMarker(save.id);
    return;
  }

  if (!cityReady(pos)) return;

  seedChests(pos);

  if (S.marker && S.marker.defeated) return;
  if (S.bossSpawned || hasBoss()) return;

  const home = cityBossPoint(pos.x, pos.z, pos.baseY);
  const boss = spawnEntity(BOSS_TYPE, home.x + 0.5, home.y, home.z + 0.5);
  if (boss){
    S.bossSpawned = true;
    toast('大地震颤……故障守卫苏醒了');
  }
}
