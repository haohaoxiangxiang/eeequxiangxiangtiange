/* ============================================================
   chest-visuals.js —— 箱子的实时 3D 模型 + 开盖动画
   ------------------------------------------------------------
   箱子方块标记了 dynamic:true，不烘焙进区块网格；
   这里按区块扫描/登记箱子坐标，在 Three 场景里画独立的模型：
     · body：箱体
     · lid ：箱盖 + 金属锁扣，挂在背板铰链上绕 X 轴旋转
     · 打开箱子界面时箱盖平滑抬起，关闭时落回
   只依赖公开导出，不参与区块网格构建。
   ============================================================ */

import * as THREE from 'three';
import { CS, CHH, Y_MIN, on } from '../core/engine-core.js';
import { chunkKey, getChunkRaw } from './terrain.js';
import { B } from './blocks.js';
import { UVRECT, atlasTexture } from './textures.js';
import { scene } from '../render/render-core.js';

const CHEST = B.chest;
const CHEST_ID = CHEST ? CHEST.id : -1;

/* 铰链：箱体顶面、背板边缘（模型坐标 0~16） */
const PIVOT_X = 0;
const PIVOT_Y = 8 / 16;
const PIVOT_Z = 1 / 16;
/* 约 96°，MC 风格 */
const OPEN_ANGLE = -Math.PI * 0.535;

const BOX_SHADE = [0.92, 0.92, 1.0, 0.65, 0.86, 0.86];

const material = new THREE.MeshLambertMaterial({
  map: atlasTexture,
  vertexColors: true,
});

/* key "x,y,z" -> { x,y,z, chunkKey, root?, lid?, angle } */
const chests = new Map();
/* 当前已安装网格的区块 key */
const activeChunks = new Set();

/* ============================================================
   几何
   ============================================================ */
function _applyTileUV(geo, tiles){
  const uv = geo.attributes.uv;
  for (let f = 0; f < 6; f++){
    const rect = UVRECT[tiles[f]] || UVRECT[tiles[0]];
    if (!rect) continue;
    const du = rect.u1 - rect.u0, dv = rect.v1 - rect.v0;
    for (let i = 0; i < 4; i++){
      const idx = f * 4 + i;
      const u = uv.getX(idx), v = uv.getY(idx);
      uv.setXY(idx, rect.u0 + u * du, rect.v0 + v * dv);
    }
  }
  uv.needsUpdate = true;
}

function _makeBox(box, pivotX, pivotY, pivotZ){
  const w = (box.x1 - box.x0) / 16;
  const h = (box.y1 - box.y0) / 16;
  const d = (box.z1 - box.z0) / 16;
  const geo = new THREE.BoxGeometry(w, h, d);
  _applyTileUV(geo, box.tiles);

  const count = geo.attributes.position.count;
  const colors = new Float32Array(count * 3);
  for (let f = 0; f < 6; f++){
    const s = BOX_SHADE[f];
    for (let i = 0; i < 4; i++){
      const idx = f * 4 + i;
      colors[idx * 3] = s;
      colors[idx * 3 + 1] = s;
      colors[idx * 3 + 2] = s;
    }
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const cx = ((box.x0 + box.x1) / 2) / 16;
  const cy = ((box.y0 + box.y1) / 2) / 16;
  const cz = ((box.z0 + box.z1) / 2) / 16;
  geo.translate(cx - pivotX, cy - pivotY, cz - pivotZ);
  return geo;
}

/* ============================================================
   光照：沿用区块烘焙的天空光/方块光，避免洞里箱子过亮
   ============================================================ */
function _lightAt(wx, wy, wz, kind){
  const c = getChunkRaw(wx >> 4, wz >> 4);
  if (!c) return 0;
  const src = kind === 'sky' ? c.skyLight : c.blockLight;
  if (!src) return 0;
  if (wy < Y_MIN || wy >= CHH) return 15;
  const lx = wx & 15, lz = wz & 15;
  return src[(((wy - Y_MIN) * CS) + lz) * CS + lx] || 0;
}

function _cacheBrightness(wx, wy, wz){
  const maxOf = (fn) => {
    let m = 0;
    for (const [dx, dy, dz] of [[0,1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[0,0,0]]){
      const v = fn(wx + dx, wy + dy, wz + dz);
      if (v > m) m = v;
    }
    return m;
  };
  const s = maxOf((x, y, z) => _lightAt(x, y, z, 'sky'));
  const b = maxOf((x, y, z) => _lightAt(x, y, z, 'block'));
  const m = Math.max(s, b);
  return 0.05 + Math.pow(m / 15, 1.3) * 0.95;
}

/* ============================================================
   创建/销毁
   ============================================================ */
function _createChest(rec){
  if (!CHEST || !CHEST.model || !CHEST.model.boxes) return;

  const root = new THREE.Group();
  root.name = 'chest-visual';
  root.position.set(rec.x, rec.y, rec.z);

  const lidGroup = new THREE.Group();
  lidGroup.position.set(PIVOT_X, PIVOT_Y, PIVOT_Z);

  /* 用区块烘焙的亮度做顶点色，让箱子也吃到环境光照 */
  const lv = Math.min(1, _cacheBrightness(rec.x, rec.y, rec.z));

  for (const box of CHEST.model.boxes){
    const isLid = box.part === 'lid';
    const geo = _makeBox(box, isLid ? PIVOT_X : 0,
                          isLid ? PIVOT_Y : 0,
                          isLid ? PIVOT_Z : 0);
    const col = geo.attributes.color;
    for (let i = 0; i < col.count; i++){
      col.setXYZ(i, col.getX(i) * lv, col.getY(i) * lv, col.getZ(i) * lv);
    }
    col.needsUpdate = true;

    const mesh = new THREE.Mesh(geo, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    if (isLid) lidGroup.add(mesh);
    else root.add(mesh);
  }
  if (lidGroup.children.length){
    root.add(lidGroup);
  }

  rec.root = root;
  rec.lid = lidGroup;
  rec.angle = 0;
  scene.add(root);
}

function _removeChest(rec){
  if (rec.root){
    scene.remove(rec.root);
    rec.root.traverse(o => {
      if (o.isMesh){
        o.geometry.dispose();
      }
    });
  }
  rec.root = null;
  rec.lid = null;
}

/* ============================================================
   坐标登记 / 扫描
   ============================================================ */
function _addChest(x, y, z){
  if (CHEST_ID < 0) return;
  const key = x + ',' + y + ',' + z;
  if (chests.has(key)) return;
  const ck = chunkKey(x >> 4, z >> 4);
  const rec = { x, y, z, chunkKey: ck, root: null, lid: null, angle: 0 };
  chests.set(key, rec);
  if (activeChunks.has(ck)) _createChest(rec);
}

function _dropChest(x, y, z){
  const key = x + ',' + y + ',' + z;
  const rec = chests.get(key);
  if (!rec) return;
  _removeChest(rec);
  chests.delete(key);
}

function _scanChunk(chunk){
  if (!chunk || !chunk.blocks || chunk._chestScanned) return;
  chunk._chestScanned = true;
  if (CHEST_ID < 0) return;

  const blocks = chunk.blocks;
  const minY = Math.max(Y_MIN, chunk.minY != null ? chunk.minY : Y_MIN);
  const maxY = Math.min(CHH - 1, chunk.maxY != null ? chunk.maxY : CHH - 1);
  const bx = chunk.cx * CS, bz = chunk.cz * CS;

  for (let y = minY; y <= maxY; y++){
    const yBase = (y - Y_MIN) * CS;
    for (let z = 0; z < CS; z++){
      const rowBase = (yBase + z) * CS;
      for (let x = 0; x < CS; x++){
        if (blocks[rowBase + x] === CHEST_ID) _addChest(bx + x, y, bz + z);
      }
    }
  }
}

/* ============================================================
   事件
   ============================================================ */
on('chunk.mesh:install', (chunk) => {
  if (!chunk) return;
  const ck = chunkKey(chunk.cx, chunk.cz);
  activeChunks.add(ck);
  _scanChunk(chunk);
  for (const rec of chests.values()){
    if (rec.chunkKey === ck && rec.root) rec.root.visible = true;
  }
});

on('chunk.mesh:unload', (chunk) => {
  if (!chunk) return;
  const ck = chunkKey(chunk.cx, chunk.cz);
  activeChunks.delete(ck);
  for (const rec of chests.values()){
    if (rec.chunkKey === ck && rec.root) rec.root.visible = false;
  }
});

on('world.blockChanged', (x, y, z, oldId, newId) => {
  if (CHEST_ID < 0) return;
  if (newId === CHEST_ID) _addChest(x, y, z);
  else if (oldId === CHEST_ID) _dropChest(x, y, z);
});

on('world.load', () => _clear());
on('world.leave', () => _clear());

function _clear(){
  for (const rec of chests.values()) _removeChest(rec);
  chests.clear();
  activeChunks.clear();
}

/* ============================================================
   每帧更新
   ============================================================ */
export function updateChestVisuals(dt, openPos){
  /* 懒创建：区块已安装后才建网格 */
  for (const rec of chests.values()){
    if (!rec.root && activeChunks.has(rec.chunkKey)) _createChest(rec);
  }

  const ox = openPos ? openPos.x : NaN;
  const oy = openPos ? openPos.y : NaN;
  const oz = openPos ? openPos.z : NaN;

  const k = 1 - Math.exp(-Math.min(dt, 0.05) * 10);
  for (const rec of chests.values()){
    if (!rec.lid) continue;
    const target = (rec.x === ox && rec.y === oy && rec.z === oz) ? OPEN_ANGLE : 0;
    rec.angle += (target - rec.angle) * k;
    if (Math.abs(rec.angle) < 0.0005 && target === 0) rec.angle = 0;
    rec.lid.rotation.x = rec.angle;
  }
}
