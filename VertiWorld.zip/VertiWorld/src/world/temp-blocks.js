/* ============================================================
   temp-blocks.js —— 限时方块
   ------------------------------------------------------------
   发光树苗（3 分钟）、发光箭矢落地光粒（60 秒）等临时方块。
   到期后如果该格还是当初放的方块才移除，避免误删玩家后来放的方块。
   ============================================================ */

import { setBlockWorld, getBlockWorld } from './terrain.js';
import { on } from '../core/engine-core.js';

const list = [];

export function placeTempBlock(x, y, z, id, seconds){
  try {
    setBlockWorld(x, y, z, id);
  } catch(e){
    return false;
  }
  list.push({ x, y, z, id, until: Date.now() + seconds * 1000 });
  return true;
}

export function updateTempBlocks(){
  if (!list.length) return;
  const now = Date.now();
  for (let i = list.length - 1; i >= 0; i--){
    const t = list[i];
    if (now < t.until) continue;
    try {
      const cur = getBlockWorld(t.x, t.y, t.z);
      if (cur === t.id){
        setBlockWorld(t.x, t.y, t.z, 0);
        list.splice(i, 1);
      } else if (cur !== 0){
        /* 已被玩家换成别的方块：不再管 */
        list.splice(i, 1);
      } else if (now > t.until + 600000){
        /* 区块一直没加载，放弃这条记录，避免无限增长 */
        list.splice(i, 1);
      }
    } catch(e){
      list.splice(i, 1);
    }
  }
}

export function clearTempBlocks(){ list.length = 0; }

on('world.load', clearTempBlocks);
