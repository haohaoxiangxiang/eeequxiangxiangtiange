/* ============================================================
   block-ticks.js —— Mod 方块计划 tick（类似 MC 的 scheduled tick）
   ------------------------------------------------------------
   · 20 TPS，与渲染帧率解耦
   · 只在该方块所在区块已加载时执行（未加载则冻结计时，回来再跑）
   · 同一坐标可挂多个 tick；回调 return true 表示按原间隔继续
   · 单个 tick 内最多执行 256 个回调，卡顿帧最多追 5 tick
   ============================================================ */

import { getActiveDimension } from '../core/engine-core.js';
import { getBlockWorld, isWorldBlockLoaded } from './terrain.js';

const TICK_SEC = 0.05;
const MAX_CALLBACKS_PER_TICK = 256;
const MAX_CATCHUP_TICKS = 5;
const MAX_DELAY_TICKS = 20 * 60 * 10;   /* 10 分钟上限，防手滑 */

let _nextId = 1;
let _tickNo = 0;
let _accum = 0;
const _pending = new Map();   /* id → rec */

/* 返回 tick id；参数非法返回 0 */
export function scheduleBlockTick(x, y, z, delayTicks, fn, opts){
  if (typeof fn !== 'function') return 0;
  const xi = Math.floor(Number(x));
  const yi = Math.floor(Number(y));
  const zi = Math.floor(Number(z));
  if (!Number.isFinite(xi) || !Number.isFinite(yi) || !Number.isFinite(zi)) return 0;

  let delay = Math.round(Number(delayTicks));
  if (!Number.isFinite(delay)) delay = 1;
  delay = Math.max(1, Math.min(delay, MAX_DELAY_TICKS));

  const dim = (opts && typeof opts.dimension === 'string' && opts.dimension)
    ? opts.dimension
    : getActiveDimension();

  const id = _nextId++;
  _pending.set(id, {
    id, x: xi, y: yi, z: zi,
    due: _tickNo + delay,
    interval: delay,
    dim,
    fn,
  });
  return id;
}

export function cancelBlockTick(id){
  return _pending.delete(Number(id));
}

/* 取消某坐标上的全部 tick，返回取消数量（block.break 清理用） */
export function cancelBlockTicksAt(x, y, z, dimension){
  const xi = Math.floor(Number(x));
  const yi = Math.floor(Number(y));
  const zi = Math.floor(Number(z));
  const dim = (typeof dimension === 'string' && dimension)
    ? dimension
    : getActiveDimension();
  let n = 0;
  for (const rec of _pending.values()){
    if (rec.x === xi && rec.y === yi && rec.z === zi && rec.dim === dim){
      _pending.delete(rec.id);
      n++;
    }
  }
  return n;
}

export function clearAllBlockTicks(){
  _pending.clear();
}

export function getPendingBlockTickCount(){
  return _pending.size;
}

function _runDue(){
  const dim = getActiveDimension();
  let budget = MAX_CALLBACKS_PER_TICK;

  /* 快照：回调里再 schedule 不会干扰本次遍历 */
  for (const rec of Array.from(_pending.values())){
    if (budget <= 0) break;
    if (rec.due > _tickNo) continue;
    if (rec.dim !== dim) continue;
    /* 区块没加载就冻结（不推进 due），下次加载后立刻执行 */
    if (!isWorldBlockLoaded(rec.x, rec.y, rec.z)) continue;

    budget--;
    _pending.delete(rec.id);
    const blockId = getBlockWorld(rec.x, rec.y, rec.z);
    let again = false;
    try {
      again = rec.fn({
        x: rec.x, y: rec.y, z: rec.z,
        blockId,
        dimension: rec.dim,
        tick: _tickNo,
        id: rec.id,
      }) === true;
    } catch(e){
      console.error('[block-tick] 回调出错，已取消该 tick:', e);
      again = false;
    }
    if (again){
      rec.due = _tickNo + rec.interval;
      _pending.set(rec.id, rec);
    }
  }
}

export function updateBlockTicks(dt){
  const d = Number(dt);
  if (!Number.isFinite(d) || d <= 0) return;
  _accum += d;
  if (_accum < TICK_SEC) return;

  const steps = Math.floor(_accum / TICK_SEC);
  _accum -= steps * TICK_SEC;

  const run = Math.min(steps, MAX_CATCHUP_TICKS);
  for (let i = 0; i < run; i++){
    _tickNo++;
    _runDue();
  }
}
