/* ============================================================
   pool.js —— Worker 池 + 消息协议 + 特性开关（合并自 3 个文件）
   ------------------------------------------------------------
   合并前是三个小文件：
     · protocol.js  消息类型常量 MSG（200 字节）
     · flags.js     ?worker= / ?meshWorker= / ?saveWorker= 开关
     · pool.js      Worker 池（优先级队列 + 队列上限）
   现在统一从这里导出 { MSG, FLAGS, ... }。

   pool 的原有行为：
     · post() 接受 priority 参数（越小越优先，默认 100）
     · queue 按 priority 升序插入
     · 队列超过 MAX_QUEUE 时踢掉最低优先级任务（队尾）
     · 动态 worker 数量：按核心数 / 内存 / 移动端 / iOS 计算
   ============================================================ */

/* =================================================================
   1. protocol.js —— 消息类型
   ================================================================= */

const MSG = {
  /* 生命周期 */
  INIT:        'init',        // 主→W：blockTable + cfg + biomes
  ADD_BLOCK:   'addBlock',    // 主→W：mod 注册方块

  /* ★ 运行时同步（mod 注册后广播） */
  SYNC_BLOCK_TABLE: 'syncBlockTable',
  SYNC_BIOMES:      'syncBiomes',

  /* 地形生成 */
  GEN_CHUNK:        'genChunk',
  GEN_CHUNK_RESULT: 'genChunkResult',

  /* 网格构建 */
  GEN_MESH:        'genMesh',
  GEN_MESH_RESULT: 'genMeshResult',

  /* 存档压缩 */
  GZIP:   'gzip',
  GUNZIP: 'gunzip',

  /* 通用 */
  PING:  'ping',
  PONG:  'pong',
  ERROR: 'error',
};
/* =================================================================
   2. flags.js —— 特性开关（URL 参数）
   ------------------------------------------------------------
   ?worker=off         禁用所有 Worker，回主线程同步模式
   ?worker=1           强制 worker 数量
   ?meshWorker=off     单独关网格 worker
   ?saveWorker=off     单独关存档 worker
   ?workerDebug=1      打详细日志
   ================================================================= */
function getParam(name){
  if (typeof location === 'undefined') return null;
  try {
    return new URLSearchParams(location.search).get(name);
  } catch(e){ return null; }
}

const _workerRaw = getParam('worker');

const FLAGS = {
  /* 总开关：off → 全部走主线程 */
  workerEnabled: _workerRaw !== 'off',

  /* 单独开关（默认跟总开关） */
  meshWorkerEnabled: getParam('meshWorker') !== 'off' && _workerRaw !== 'off',
  saveWorkerEnabled: getParam('saveWorker') !== 'off' && _workerRaw !== 'off',

  /* 池大小：0 = 自动 */
  workerCount: parseInt(_workerRaw || '0', 10) || 0,

  debug: getParam('workerDebug') === '1',
};

if (FLAGS.debug){
  console.log('[flags]', FLAGS);
}
/* =================================================================
   3. Worker 池
   ================================================================= */
const DEFAULT_TIMEOUT = 300000;
const DEFAULT_PRIORITY = 100;

/* ★ 队列上限改成「按 worker 数量算」而不是写死 48。
   原来写死 48 是照 6~8 个 worker 定的（每个 worker 积压 ~8 个）；
   启动器把 hardwareConcurrency 压到 4 之后池子里只有 3 个 worker，
   48 的积压等于让每个 worker 排队 16 个、并且所有超出预算的请求
   （包括刚被踢掉、下一帧又要重新申请的那些区块）永远抢不到位置，
   形成"踢掉 → 重申请 → 又排在队尾 → 再被踢"的活锁。
   改成 size*8 之后，3 个 worker 就是 24，和生成吞吐是配比的。 */
const QUEUE_PER_WORKER = 8;
const QUEUE_MIN = 12;
const QUEUE_MAX = 64;
function _queueCapFor(size){
  return Math.max(QUEUE_MIN, Math.min(QUEUE_MAX, size * QUEUE_PER_WORKER));
}

/* ============================================================
   动态 worker 数量
   ============================================================ */
function _computeAutoWorkerCount(){
  if (typeof navigator === 'undefined') return 2;

  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory || 4;

  const memCap = mem <= 2 ? 2
               : mem <= 3 ? 3
               : mem <= 4 ? 4
               : mem <= 6 ? 6
               : 8;

  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
                || navigator.maxTouchPoints > 1;

  const isIOS = /iPad|iPhone|iPod/i.test(navigator.userAgent)
             || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  let count;
  if (isMobile){
    count = cores - 1;
    if (count > 6) count = 6;
    if (count < 2) count = 2;
  } else {
    count = cores - 1;
    if (count > 8) count = 8;
    if (count < 2) count = 2;
  }

  if (isIOS) count = Math.min(count, 4);
  count = Math.min(count, memCap);

  return count;
}

export function getAutoWorkerCount(){
  return _computeAutoWorkerCount();
}

/* ============================================================
   WorkerPool
   ============================================================ */
export class WorkerPool {
  constructor(url, size){
    const n = size || FLAGS.workerCount || _computeAutoWorkerCount();
    this.url = url;
    this.size = Math.max(1, n);

    this.workers = [];
    this.idle    = [];
    this.queue   = [];              // 按 priority 升序
    this.pending = new Map();
    this.nextId  = 1;
    this.terminated = false;
    this.maxQueue = _queueCapFor(this.size);

    this.stats = {
      sent: 0, done: 0, failed: 0, timeout: 0, overflow: 0,
      peakQueue: 0, busyTotalMs: 0,
    };

    if (typeof console !== 'undefined'){
      const cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || '?';
      const mem = (typeof navigator !== 'undefined' && navigator.deviceMemory) || '?';
      const mobile = (typeof navigator !== 'undefined')
        ? (/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) ? 'Y' : 'N')
        : '?';
      console.log(
        `[pool] × ${this.size} ` +
        `(cores=${cores}, mem=${mem}GB, mobile=${mobile}, ` +
        `url=${this.url.split('/').pop()})`
      );
    }

    this._spawn();
  }

  _spawn(){
    for (let i = 0; i < this.size; i++){
      let w;
      try {
        w = new Worker(this.url, { type: 'module' });
      } catch(err){
        this._reportWorkerError(
          `Worker #${i} 构造失败（可能不支持 { type:'module' }）: ${err.message || err}`
        );
        try { w = new Worker(this.url); } catch(err2){
          this._reportWorkerError(
            `Worker #${i} 完全不支持: ${err2.message || err2}`
          );
          continue;
        }
      }
      w.onmessage = (e) => this._onMessage(w, e.data);
      w.onerror   = (e) => {
        const info = {
          msg: e.message || '(空，可能 import 阶段失败)',
          file: e.filename || '',
          line: e.lineno || 0,
        };
        console.error(`[pool] worker ${i} error:`, info);
        this._reportWorkerError(
          `Worker #${i} 错误: ${info.msg}`,
          info.file + ':' + info.line
        );
        this._onWorkerError(w, e);
      };
      w.__idx = i;
      w.__booted = false;
      w.__spawnedAt = Date.now();
      w.__failCount = 0;
      this.workers.push(w);
      this.idle.push(w);
    }
    this._startBootProbe();
    if (FLAGS.debug){
      console.log(`[pool] ${this.size} workers ready (${this.url})`);
    }
  }

  _reportWorkerError(msg, stack){
    try {
      if (typeof window !== 'undefined' &&
          typeof window.__err_ui_show__ === 'function'){
        window.__err_ui_show__({
          t: Date.now(),
          tag: 'WORKER',
          name: 'WorkerError',
          message: msg,
          stack: stack || '',
        });
      }
    } catch(e){}
  }

  _startBootProbe(){
    const start = Date.now();
    const check = () => {
      if (this.terminated) return;
      const alive = this.workers.filter(w => w.__booted).length;
      const total = this.workers.length;
      if (total === 0) return;
      if (alive === total){
        console.log(`[pool] ${total}/${total} workers booted ✔`);
        return;
      }
      if (Date.now() - start > 6000){
        console.warn(
          `[pool] ${alive}/${total} workers booted after 6s — import 可能失败`
        );
        this._reportWorkerError(
          `Worker 启动超时: ${alive}/${total} 已就绪。` +
          `请检查 Console 里的 __boot_error 详情`
        );
        return;
      }
      setTimeout(check, 300);
    };
    setTimeout(check, 300);
  }

  _onMessage(w, msg){
    /* ★ boot 消息 & boot 错误：显示到页面错误面板 */
    /* ★ 修：storage-worker.js 发的是 storageWorkerBoot，不是 workerBoot。
       两种都识别，否则 storage pool 的 __booted 永远是 false，
       _startBootProbe 6 秒后误报 "0/2 已就绪"。 */
    if (msg && (msg.type === 'workerBoot' || msg.type === 'storageWorkerBoot')){
      w.__booted = true;
      return;
    }
    if (msg && msg.type === '__boot_error'){
      console.error('[pool] worker boot error:', msg.error, msg.stack);
      this._reportWorkerError(
        'Worker boot 失败: ' + (msg.error || '(unknown)'),
        msg.stack || ''
      );
      return;
    }
    const job = this.pending.get(msg.id);
    if (!job) return;
    this.pending.delete(msg.id);
    clearTimeout(job.timer);

    this.idle.push(w);
    this._pump();

    this.stats.done++;

    if (msg.error){
      this.stats.failed++;
      job.reject(new Error(msg.error));
    } else {
      job.resolve(msg);
    }
  }

  _onWorkerError(w, e){
    console.error('[pool] worker crashed, respawning:', e.message);
    const i = w.__idx;
    try { w.terminate(); } catch(err){}

    if (this.terminated) return;

    /* ★ 失败重试上限：原来无限 respawn 会导致 CPU 打满、堆栈溢出 */
    w.__failCount = (w.__failCount || 0) + 1;
    if (w.__failCount > 3){
      console.error(
        `[pool] worker ${i} 连续失败 ${w.__failCount} 次，放弃 respawn`
      );
      const k = this.idle.indexOf(w);
      if (k >= 0) this.idle.splice(k, 1);
      const wi = this.workers.indexOf(w);
      if (wi >= 0) this.workers.splice(wi, 1);
      return;
    }

    let nw;
    try {
      nw = new Worker(this.url, { type: 'module' });
    } catch(err){
      console.error('[pool] respawn 失败:', err.message);
      return;
    }
    nw.onmessage = (ev) => this._onMessage(nw, ev.data);
    nw.onerror   = (ev) => this._onWorkerError(nw, ev);
    nw.__idx = i;
    nw.__booted = false;
    nw.__spawnedAt = Date.now();
    nw.__failCount = w.__failCount;
    this.workers[i] = nw;

    const k = this.idle.indexOf(w);
    if (k >= 0) this.idle[k] = nw;
    else this.idle.push(nw);
  }

  /* ★ post 支持 priority + 队列上限 */
  post(type, payload, transfer, timeoutMs, priority){
    if (this.terminated){
      return Promise.reject(new Error('[pool] terminated'));
    }
    const prio = (typeof priority === 'number') ? priority : DEFAULT_PRIORITY;

    /* ★ 队列上限：超过上限时踢最低优先级。
       上限按 worker 数量算（见 _queueCapFor），并统计 overflow 次数 ——
       调用方（terrain.js）靠这个计数决定要不要退避，而不是每帧重试。 */
    if (this.queue.length >= this.maxQueue){
      this.stats.overflow++;
      const last = this.queue[this.queue.length - 1];
      if (prio < last.priority){
        /* 新任务优先级更高，踢掉队尾 */
        const dropped = this.queue.pop();
        const dj = this.pending.get(dropped.id);
        if (dj){
          this.pending.delete(dropped.id);
          clearTimeout(dj.timer);
          this.stats.failed++;
          dj.reject(new Error('queue overflow'));
        }
      } else {
        /* 新任务优先级更低，直接拒绝 */
        return Promise.reject(new Error('queue overflow'));
      }
    }

    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const to = timeoutMs || DEFAULT_TIMEOUT;

      const timer = setTimeout(() => {
        const j = this.pending.get(id);
        if (!j) return;
        this.pending.delete(id);
        this.stats.timeout++;
        console.warn(`[pool] task ${type}#${id} timeout after ${to}ms`);
        j.reject(new Error(`worker timeout: ${type}`));
      }, to);

      this.pending.set(id, { resolve, reject, timer, type });

      /* 按 priority 插入（稳定排序：同 priority 保持 FIFO） */
      const entry = { id, type, payload, transfer: transfer || [], priority: prio };
      let lo = 0, hi = this.queue.length;
      while (lo < hi){
        const mid = (lo + hi) >> 1;
        if (this.queue[mid].priority <= prio) lo = mid + 1;
        else hi = mid;
      }
      this.queue.splice(lo, 0, entry);

      if (this.queue.length > this.stats.peakQueue){
        this.stats.peakQueue = this.queue.length;
      }
      this._pump();
    });
  }

  _pump(){
    while (this.queue.length && this.idle.length){
      const job = this.queue.shift();
      const w = this.idle.pop();
      this.stats.sent++;
      try {
        w.postMessage({ id: job.id, type: job.type, ...job.payload },
                      job.transfer);
      } catch(e){
        const j = this.pending.get(job.id);
        if (j){
          this.pending.delete(job.id);
          clearTimeout(j.timer);
        }
        this.idle.push(w);
        this.stats.failed++;
        if (j) j.reject(e);
      }
    }
  }

  broadcast(type, payload){
    if (this.terminated) return;
    for (const w of this.workers){
      try { w.postMessage({ type, ...payload }); }
      catch(e){ console.warn('[pool] broadcast failed:', e); }
    }
  }

  terminate(){
    this.terminated = true;
    for (const w of this.workers){
      try { w.terminate(); } catch(e){}
    }
    for (const [, job] of this.pending){
      clearTimeout(job.timer);
      job.reject(new Error('[pool] terminated'));
    }
    this.pending.clear();
    this.workers = []; this.idle = []; this.queue = [];
    if (FLAGS.debug) console.log('[pool] terminated');
  }

  getStats(){
    return {
      size: this.size,
      queue: this.queue.length,
      idle: this.idle.length,
      pending: this.pending.size,
      ...this.stats,
    };
  }
}

/* ---- 单例 ---- */
let _instance = null;

export function getPool(){
  if (!_instance){
    _instance = new WorkerPool(
      new URL('./terrain-worker.js', import.meta.url).href
    );
  }
  return _instance;
}

export function destroyPool(){
  if (_instance){
    _instance.terminate();
    _instance = null;
  }
}

/* =================================================================
   re-export
   ================================================================= */
export { MSG, FLAGS };
