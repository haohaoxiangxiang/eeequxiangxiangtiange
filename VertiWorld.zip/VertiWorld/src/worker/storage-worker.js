/* ============================================================
   storage-worker.js —— 存档压缩 worker
   ------------------------------------------------------------
   只做两件事：
     · gzip    Uint8Array → 压缩 Uint8Array
     · gunzip  压缩 Uint8Array → 原始 Uint8Array

   CompressionStream / DecompressionStream 是浏览器原生 API，
   比 JS 实现的 gzip 快 5~10 倍。

   输入输出都用 transfer 零拷贝。
   ============================================================ */

async function gzip(data){
  const cs = new CompressionStream('gzip');
  const w  = cs.writable.getWriter();
  w.write(data);
  w.close();
  const ab = await new Response(cs.readable).arrayBuffer();
  return new Uint8Array(ab);
}

async function gunzip(data){
  const ds = new DecompressionStream('gzip');
  const w  = ds.writable.getWriter();
  w.write(data);
  w.close();
  const ab = await new Response(ds.readable).arrayBuffer();
  return new Uint8Array(ab);
}

self.onmessage = async (e) => {
  const msg = e.data || {};
  const id  = msg.id;
  const op  = msg.type;

  try {
    let result;
    if (op === 'gzip')        result = await gzip(msg.data);
    else if (op === 'gunzip') result = await gunzip(msg.data);
    else throw new Error('unknown op: ' + op);

    self.postMessage({ id, data: result }, [result.buffer]);
  } catch (err) {
    self.postMessage({ id, error: err.message || String(err) });
  }
};

self.postMessage({ type: 'storageWorkerBoot' });