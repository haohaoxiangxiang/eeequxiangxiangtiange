/* ============================================================
   mod-host.js —— Mod 宿主门面
   ------------------------------------------------------------
   提供 mod 能访问的稳定 API（__GAME__）。
   整合：
     · 事件总线 / Hook（re-export mod-core）
     · 方块 / 配方 / 熔炼 / 燃料
     · 生成器 / 群系 / 维度 / 天空
     · 实体（含分类上限 + 距离分级）
     · 音效（文件加载 / 播放 / 位置音效）
     · 存档存储 / 世界读写
     · 诊断接口
   ============================================================ */

import * as THREE from 'three';

import { BLOCKS, B } from '../world/blocks.js';
import { player, damage as playerDamage, setMovementConfig as _setMovementConfig, getMovementConfig as _getMovementConfig, resetMovementConfig as _resetMovementConfig } from './../player/player-core.js';
import {
  inventory,
  addItem,
  takeFromSlot,
  notifyInventory,
} from './../items/items-core.js';
import { input } from './../player/player-core.js';
import { camera, scene, renderer } from './../render/render-core.js';
import {
  getBlockWorld,
  setBlockWorld,
  heightAt,
  biomeAt,
  getTerrainTopY,
  getChunkStats,
  isWorldBlockLoaded,
  getBlockData,
  setBlockData,
  removeBlockData,
  getFluidLevel as _getFluidLevel,
  setFluidLevel as _setFluidLevel,
  getFluidSource as _getFluidSource,
  getWorldGenInstance,          /* ★ /locate 命令用 */
} from '../world/terrain.js';
import {
  createSource as _createFluidSource,
  removeSource as _removeFluidSource,
  setFluidConfig as _setFluidConfig,
  getFluidConfig as _getFluidConfig,
  resetFluidConfig as _resetFluidConfig,
  wakeFluid as _wakeFluid,
} from '../world/world-core.js';
import { raycastVoxel } from './../world/world-meta.js';
import { spawnDrop, drops } from './../items/items-logic.js';
import {
  registerStatusEffect as _registerStatusEffect,
  unregisterStatusEffect as _unregisterStatusEffect,
  getStatusEffectType as _getStatusEffectType,
  listStatusEffectTypes as _listStatusEffectTypes,
  applyStatus as _applyStatus,
  removeStatus as _removeStatus,
  clearStatusEffects as _clearStatusEffects,
  hasStatus as _hasStatus,
  getStatus as _getStatus,
  getActiveStatuses as _getActiveStatuses,
  resetStatusEffects as _resetStatusEffects,
} from './../player/status-effects.js';
import {
  CS,
  CHH,
  Y_MIN,
  SEA_LEVEL,
  INV_SIZE,
  STACK_MAX,
} from './engine-core.js';

/* ---- 世界生成层 ---- */
import {
  registerGenerator,
  getGenerator,
  getActiveGenerator,
  getActiveGeneratorId,
  setActiveGenerator,
  listGenerators,
  getGeneratorHeightLimit,
} from './../world/world-meta.js';
import {
  registerBiome,
  getBiome,
  getBiomeByName,
  listBiomes,
} from './../world/world-core.js';
import {
  setSkyPreset,
  getSkyPreset,
  setBiomeFog,
} from '../render/sky.js';

/* ---- 实体层 ---- */
import {
  registerEntity,
  getEntityType,
  hasEntityType,
  listEntityTypes,
  getAllEntityTypes,
  getSpawnableTypes,
  getEntityTypeCount,
  getTypesByCategory,
  spawnEntity,
  removeEntity,
  setEntityLoot,
  damageEntity,
  getEntityAt,
  getAnimalCount,
  animals,             /* ★ 实体列表（只读，给 getEntities / killEntities 用） */
  getWorldApi,
  /* ★ 新增：分类上限 + 距离分级 */
  setEntityCap,
  getEntityCap,
  listEntityCaps,
  getEntityCounts,
  getEntityCountByType,
  setTickDistances,
  getTickDistances,
  /* ★ 连续失败被停用 AI 的实体类型（排障用） */
  listDisabledEntityAi,
} from './../entities/entities-core.js';

/* ---- 维度系统 ---- */
import {
  registerDimension,
  getDimension,
  hasDimension,
  listDimensions,
  getDimensionCount,
  getActiveDimensionId,
  getActiveDimension as _getActiveDimObj,
} from './../world/world-registry.js';

/* ---- 创造面板分类 ---- */
import {
  registerCreativeCategory,
  listCreativeCategories,
  getCreativeCategory,
} from './../world/world-registry.js';

/* ---- 音效 ---- */
import {
  registerSound as _registerSound,
  unregisterSound as _unregisterSound,
  loadSound as _loadSound,
  playSound as _playSound,
  playSoundAt as _playSoundAt,
  stopAllSounds as _stopAllSounds,
} from '../audio/audio.js';

/* ---- 背景音乐 ---- */
import {
  registerMusicTrack as _registerMusicTrack,
  unregisterMusicTrack as _unregisterMusicTrack,
  listMusicTracks as _listMusicTracks,
  setMusicOwner as _setMusicOwner,
  getMusicOwner as _getMusicOwner,
  playMusicById as _playMusicById,
  playMusicUrl as _playMusicUrl,
  stopMusicPlayback as _stopMusicPlayback,
  isMusicPlaying as _isMusicPlaying,
  getCurrentMusicId as _getCurrentMusicId,
  onMusicEnded as _onMusicEnded,
  offMusicEnded as _offMusicEnded,
} from '../audio/audio.js';

/* ---- 事件 / hook（转发 mod-core） ---- */
import {
  on, off, once, emit, emitCancellable, defineHook, getHook, listHooks, isHooked,
  listenerCount, listEvents, clearAllEvents,
} from './engine-core.js';

/* ---- 按键绑定 ---- */
import {
  getAllActions, getBinding, setBinding, resetBindings, keyLabel,
  registerBindingAction, unregisterBindingAction,
  conflictsForCode, actionsForCode,
} from './key-bindings.js';

export {
  on, off, once, emit, emitCancellable,
  defineHook, getHook, listHooks, isHooked,
  listenerCount, listEvents, clearAllEvents,
};

/* ============================================================
   状态
   ============================================================ */
let _extras = null;
let _facade = null;

/* ============================================================
   ★ attachVisual：3D 对象生命周期绑定
   ============================================================ */
const _visuals = new Map(); // "x,y,z" -> { obj, ck }

function _detachVisual(x, y, z, dispose) {
  const key = `${x},${y},${z}`;
  const rec = _visuals.get(key);
  if (!rec) return;
  scene.remove(rec.obj);
  if (dispose) {
    rec.obj.traverse(o => {
      if (o.isMesh) {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
          else o.material.dispose();
        }
      }
    });
  }
  _visuals.delete(key);
}

function _handleBlockChanged(x, y, z, oldId, newId) {
  if (newId === 0) _detachVisual(x, y, z, true);
}

function _handleChunkUnload(chunk) {
  const minX = chunk.cx * 16, maxX = minX + 16;
  const minZ = chunk.cz * 16, maxZ = minZ + 16;
  for (const [key, rec] of _visuals) {
    const [x, , z] = key.split(',').map(Number);
    if (x >= minX && x < maxX && z >= minZ && z < maxZ) {
      scene.remove(rec.obj); // 区块卸载只移出场景，不销毁（区块回来还能用）
    }
  }
}

function _handleChunkInstall(chunk) {
  const minX = chunk.cx * 16, maxX = minX + 16;
  const minZ = chunk.cz * 16, maxZ = minZ + 16;
  for (const [key, rec] of _visuals) {
    const [x, , z] = key.split(',').map(Number);
    if (x >= minX && x < maxX && z >= minZ && z < maxZ) {
      if (!rec.obj.parent) scene.add(rec.obj); // 重新加回场景
    }
  }
}

function _clearAllVisuals() {
  for (const rec of _visuals.values()) {
    scene.remove(rec.obj);
    rec.obj.traverse(o => {
      if (o.isMesh) {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
          else o.material.dispose();
        }
      }
    });
  }
  _visuals.clear();
}
const _installedAt = Date.now();

export const MOD_HOST_API_VERSION = 4;

export function isHostInstalled(){
  return _facade !== null;
}

export function getHost(){
  return _facade;
}

/* ============================================================
   工具：参数化 setBlock / fillBox
   ============================================================ */
function _setBlockByName(x, y, z, name){
  const b = B[name];
  if (!b) return false;
  setBlockWorld(x | 0, y | 0, z | 0, b.id);
  return true;
}

function _fillBox(x1, y1, z1, x2, y2, z2, id){
  const ax = Math.min(x1, x2) | 0, bx = Math.max(x1, x2) | 0;
  const ay = Math.min(y1, y2) | 0, by = Math.max(y1, y2) | 0;
  const az = Math.min(z1, z2) | 0, bz = Math.max(z1, z2) | 0;
  const idn = id | 0;

  const total = (bx - ax + 1) * (by - ay + 1) * (bz - az + 1);
  if (total > 262144){
    console.warn(`[mod-host] fillBox 超限: ${total} 格 (上限 262144)`);
    return false;
  }
  for (let x = ax; x <= bx; x++)
    for (let y = ay; y <= by; y++)
      for (let z = az; z <= bz; z++)
        setBlockWorld(x, y, z, idn);
  return true;
}

/* ============================================================
   门面构造
   ============================================================ */
function buildFacade(){
  const f = {

    /* ================================================
       版本信息
       ================================================ */
    apiVersion: MOD_HOST_API_VERSION,
    get version(){
      return _extras.gameVersion || 'unknown';
    },
    get info(){
      return {
        apiVersion: MOD_HOST_API_VERSION,
        gameVersion: _extras.gameVersion || 'unknown',
        blockCount: BLOCKS.length,
        hookCount: listHooks().length,
        eventCount: listEvents().length,
        generatorCount: listGenerators().length,
        biomeCount: listBiomes().length,
        entityCount: getEntityTypeCount(),
        disabledEntityAi: listDisabledEntityAi(),
        dimensionCount: getDimensionCount(),
        installedAt: _installedAt,
      };
    },

    /* ================================================
       引擎 / 数据
       ================================================ */
    THREE,
    BLOCKS,
    B,

    /* ================================================
       游戏模块引用
       ================================================ */
    player,
    inventory,
    input,
    camera,
    scene,
    renderer,

    /* ================================================
       ★ 按键绑定（automatic 出现在 设置→操作→按键绑定）
       -------------------------------------------------
       G.keybinds.register({
         id: 'mymod.skill',        // 全局唯一 id
         label: '我的技能',         // 设置里显示的名字
         defaultKey: 'KeyK',       // 默认键（可省略 → 未绑定）
         onPress(){ ... },
         onRelease(){ ... },
       })
       玩家可以像原版动作一样在设置里改键；冲突会提示。
       ================================================ */
    keybinds: {
      register(cfg){ return registerBindingAction(cfg); },
      unregister(id){ return unregisterBindingAction(id); },
      list(){
        return getAllActions().map(a => {
          const key = getBinding(a.id) || '';
          return {
            id: a.id, label: a.label, key,
            defaultKey: a.def || '',
            mod: !!a.mod,
            conflict: conflictsForCode(key, a.id),
          };
        });
      },
      getKey(id){ return getBinding(id) || ''; },
      setKey(id, code){ return setBinding(id, code); },
      reset(){ return resetBindings(); },
      conflictsForCode(code, exceptId){ return conflictsForCode(code, exceptId); },
      actionsForCode(code){ return actionsForCode(code); },
      label: keyLabel,
      isDown(id){ return !!input.actions[id]; },
    },

    /* ================================================
       常量（动态读）
       ================================================ */
    get CS(){ return CS; },
    get CHH(){ return CHH; },
    get Y_MIN(){ return Y_MIN; },
    get SEA_LEVEL(){ return SEA_LEVEL; },
    INV_SIZE,
    STACK_MAX,

    /* ================================================
       读世界
       ================================================ */
    getBlock(x, y, z){
      return getBlockWorld(x | 0, y | 0, z | 0);
    },
    /* ★ 区分"空气"和"未加载"
       返回 { id, loaded } —— loaded=false 时 id 无意义 */
    getBlockEx(x, y, z){
      const xi = x | 0, yi = y | 0, zi = z | 0;
      return {
        id: getBlockWorld(xi, yi, zi),
        loaded: isWorldBlockLoaded(xi, yi, zi),
      };
    },
    getBlockName(x, y, z){
      const id = getBlockWorld(x | 0, y | 0, z | 0);
      const b = BLOCKS[id];
      return b ? b.name : 'air';
    },
    heightAt,
    getTerrainHeight(x, z) { return getTerrainTopY(x|0, z|0); },
    biomeAt,

    /* ★ 批量写入：包在这里面的 setBlock 只触发一次网格重建（P0） */
    _batchDepth: 0,
    batch(fn) {
      if (this._batchDepth === 0) {
        // 暂停区块脏标记统一结算，这里利用现有 dirt 机制
        // 只需要调一次 emit('chunk.batch:start')
        emit('chunk.batch:start');
      }
      this._batchDepth++;
      try { fn(); } finally {
        this._batchDepth--;
        if (this._batchDepth === 0) {
          emit('chunk.batch:end');
        }
      }
    },

    setWaterRenderMode(mode){
      if (_extras.setWaterRenderMode) _extras.setWaterRenderMode(mode);
    },

    /* ★ UI 扩展：允许 mod 自己往原版容器里塞 DOM */
    ui: {
      addInventoryWidget(html){
        const ext = document.getElementById('mod-inv-ext');
        if (ext) ext.insertAdjacentHTML('beforeend', html);
      },
      /* ★ UI 安全区：返回各浮动 UI 的屏幕矩形（viewport 像素）
         值为 null 表示该元素不存在（桌面端/关触屏）。 */
      getSafeAreas(){
        const _rect = (sel) => {
          const el = document.querySelector(sel);
          if (!el) return null;
          const r = el.getBoundingClientRect();
          if (r.width === 0 && r.height === 0) return null;
          return {
            left: r.left, top: r.top, right: r.right, bottom: r.bottom,
            w: r.width, h: r.height,
          };
        };
        return {
          joystick: _rect('#stick'),
          sideButtons: _rect('#sidebtns'),
          hotbar: _rect('#hotbar'),
          topBar: _rect('#topbtns'),
          hearts: _rect('#hearts'),
          hunger: _rect('#hunger'),
          viewport: {
            left: 0, top: 0,
            right: window.innerWidth || 1,
            bottom: window.innerHeight || 1,
            w: window.innerWidth || 1,
            h: window.innerHeight || 1,
          },
        };
      },
      addChestWidget(html){
        const ext = document.getElementById('mod-chest-ext');
        if (ext) ext.insertAdjacentHTML('beforeend', html);
      },
      addFurnaceWidget(html){
        const ext = document.getElementById('mod-furnace-ext');
        if (ext) ext.insertAdjacentHTML('beforeend', html);
      }
    },

    /* ★ 3D 对象绑定 */
    attachVisual(x, y, z, obj3d) {
      _detachVisual(x, y, z, true);
      obj3d.position.set(x + 0.5, y, z + 0.5); // 默认居中
      scene.add(obj3d);
      _visuals.set(`${x},${y},${z}`, { obj: obj3d });
    },
    detachVisual(x, y, z) { _detachVisual(x, y, z, true); },

    /* ★ BlockEntity */
    getBlockData(x, y, z){ return getBlockData(x|0, y|0, z|0); },
    setBlockData(x, y, z, data){ setBlockData(x|0, y|0, z|0, data); },
    removeBlockData(x, y, z){ removeBlockData(x|0, y|0, z|0); },

    raycast(maxDist) {
      const camPos = camera.position;
      const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
      return raycastVoxel(camPos, dir, maxDist || 6);
    },
    isWaterAt(x, y, z) { const b = BLOCKS[getBlockWorld(x|0, y|0, z|0)]; return b && b.liquid && b.name === 'water'; },
    isLavaAt(x, y, z) { const b = BLOCKS[getBlockWorld(x|0, y|0, z|0)]; return b && b.liquid && b.name === 'lava'; },
    isSolidAt(x, y, z) { const b = BLOCKS[getBlockWorld(x|0, y|0, z|0)]; return b && b.solid; },
    isLoadedAt(x, y, z) { return isWorldBlockLoaded(x|0, y|0, z|0); },

    /* ★ 流体接口：读液位/源头，写源头 */
    getFluidLevel(x, y, z){ return _getFluidLevel(x|0, y|0, z|0); },
    setFluidLevel(x, y, z, lv){ _setFluidLevel(x|0, y|0, z|0, lv|0); },
    getFluidSource(x, y, z){ return _getFluidSource(x|0, y|0, z|0); },
    createFluidSource(x, y, z, id){ return _createFluidSource(x|0, y|0, z|0, id|0); },
    removeFluidSource(x, y, z){ return _removeFluidSource(x|0, y|0, z|0); },

    /* ★ 液体流动参数：流速 / 复查间隔 / 单帧预算 / 队列上限 */
    setFluidConfig(partial){ return _setFluidConfig(partial); },
    getFluidConfig(){ return _getFluidConfig(); },
    resetFluidConfig(){ return _resetFluidConfig(); },
    /** 把某格重新排进流动队列（配合 fluid.* 事件做延迟/再触发） */
    wakeFluid(x, y, z, delay){ return _wakeFluid(x|0, y|0, z|0, delay); },

    /* ================================================
       写世界
       ================================================ */
    setBlock(x, y, z, id, opts){
      setBlockWorld(x | 0, y | 0, z | 0, id | 0, opts);
    },
    setBlockByName: _setBlockByName,
    fillBox: _fillBox,

    /* ================================================
       物品
       ================================================ */
    addItem,
    takeFromSlot,
    notifyInventory,
    spawnDrop,
    get drops(){ return drops; },

    /* ================================================
       玩家快捷
       ================================================ */
    getPlayer(){ return player; },
    getPos(){
      return {
        x: player.pos.x,
        y: player.pos.y,
        z: player.pos.z,
      };
    },
    /* ★ 当前手持槽（0~8） */
    getHeldSlot(){
      return _extras.getHeldSlot ? _extras.getHeldSlot() : 0;
    },
    /* ★ 准星目标：位置 + 朝向 + 法线
       返回 { pos: {x,y,z}, face: 'top'|'bottom'|'north'|'south'|'east'|'west',
              normal: {x,y,z}, blockId }
       无目标时返回 null。 */
    getLookTarget(maxDist){
      const camPos = camera.position;
      const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
      const hit = raycastVoxel(camPos, dir, maxDist || 6);
      if (!hit) return null;
      let face = 'top';
      if (hit.nx === 1) face = 'east';
      else if (hit.nx === -1) face = 'west';
      else if (hit.ny === 1) face = 'top';
      else if (hit.ny === -1) face = 'bottom';
      else if (hit.nz === 1) face = 'south';
      else if (hit.nz === -1) face = 'north';
      return {
        pos: { x: hit.x, y: hit.y, z: hit.z },
        face,
        normal: { x: hit.nx, y: hit.ny, z: hit.nz },
        blockId: hit.id,
      };
    },
    teleport(x, y, z){
      player.pos.set(+x, +y, +z);
      player.vel.set(0, 0, 0);
    },
    heal(n){
      const amount = Math.max(0, n | 0);
      player.health = Math.min(player.maxHealth, player.health + amount);
      _extras.triggerDamageUI?.();
    },
    setMode(mode){
      if (mode !== 'survival' && mode !== 'creative') return false;
      player.mode = mode;
      player.flying = (mode === 'creative');
      _extras.triggerDamageUI?.();
      emit('player.modeChange', mode);
      return true;
    },
    give(nameOrId, count){
      const id = typeof nameOrId === 'string'
        ? (B[nameOrId] ? B[nameOrId].id : -1)
        : (nameOrId | 0);
      if (id < 0) return false;
      return addItem(id, count || 1);
    },
    damagePlayer(n){
      const amount = Math.max(0, n | 0);
      if (amount <= 0) return;
      playerDamage(amount);
    },

    /* ================================================
       ★ 移动 / 跳跃 / 水中物理参数
       -------------------------------------------------
       可改：walkSpeed sneakSpeed sprintSpeed waterSpeed
             flySpeed flySprintSpeed groundAccel airAccel
             jumpVelocity gravity maxFallSpeed flyingVerticalFactor
             waterGravity waterBuoyancy waterDamping waterMaxSpeed
       单位：格/秒、格/秒²；只接受有限数字。
       ================================================ */
    setMovementConfig(partial){ return _setMovementConfig(partial); },
    getMovementConfig(){ return _getMovementConfig(); },
    resetMovementConfig(){ return _resetMovementConfig(); },

    /* ================================================
       ★ 状态效果：宿主只做计时/堆叠，效果由 mod 回调实现
       -------------------------------------------------
       registerStatusEffect(id, {
         name, duration, maxStacks, tickInterval,
         onApply(player, inst), onTick(player, inst), onRemove(player, inst)
       })
       applyStatus(id, duration?, { stacks, data }?) → inst | null
       removeStatus(id, reason?) / clearStatusEffects(reason?)
       hasStatus / getStatus / getActiveStatuses / listStatusEffectTypes
       ================================================ */
    registerStatusEffect(id, def){ return _registerStatusEffect(id, def); },
    unregisterStatusEffect(id){ return _unregisterStatusEffect(id); },
    getStatusEffectType(id){ return _getStatusEffectType(id); },
    listStatusEffectTypes(){ return _listStatusEffectTypes(); },
    applyStatus(id, duration, opts){ return _applyStatus(id, duration, opts); },
    removeStatus(id, reason){ return _removeStatus(id, reason); },
    clearStatusEffects(reason){ return _clearStatusEffects(reason); },
    hasStatus(id){ return _hasStatus(id); },
    getStatus(id){ return _getStatus(id); },
    getActiveStatuses(){ return _getActiveStatuses(); },
    resetStatusEffects(){ return _resetStatusEffects(); },

    /* ================================================
       事件总线
       ================================================ */
    on,
    off,
    once,
    emit,
    listenerCount,
    listEvents,

    /* ================================================
       Hook
       ================================================ */
    hook: getHook,
    listHooks,
    isHooked,

    /* ================================================
       运行时内容注册（通过 extras 桥接）
       ================================================ */
    registerBlock(...args){
      if (!_extras.registerBlockRuntime) return null;
      return _extras.registerBlockRuntime(...args);
    },
    /** 覆盖方块掉落：spec 可为物品名/数字 id/{name,count,min,max,chance}/数组/null */
    setBlockDrop(name, spec){
      return _extras.setBlockDrop ? _extras.setBlockDrop(name, spec) : false;
    },
    clearBlockDrop(name){
      return _extras.clearBlockDrop ? _extras.clearBlockDrop(name) : false;
    },
    /** 读取箱子内容（Promise<Array>，空槽为 null） */
    getChestItems(...args){
      return _extras.getChestItems ? _extras.getChestItems(...args) : Promise.resolve([]);
    },
    /** 覆盖写入箱子内容，items 支持 [{name|id, count}] */
    setChestItems(...args){
      return _extras.setChestItems ? _extras.setChestItems(...args) : Promise.resolve(false);
    },

    /* ================================================
       ★ 方块计划 tick（20 TPS，类似 MC scheduled tick）
       -------------------------------------------------
       scheduleBlockTick(x, y, z, delay, fn, opts?) → tickId
         · delay 单位是 tick（20 tick = 1 秒），最小 1
         · 只在该坐标所在区块加载时执行；未加载则冻结，回来接着算
         · fn 参数 { x, y, z, blockId, dimension, tick, id }
         · fn return true → 按原间隔继续调度，否则自动结束
         · opts.dimension 默认当前维度
       cancelBlockTick(id) → bool
       cancelBlockTicksAt(x, y, z, dimension?) → 取消数量
       getBlockTickCount() → 待执行数量
       ================================================ */
    scheduleBlockTick(x, y, z, delayTicks, fn, opts){
      return _extras.scheduleBlockTick
        ? _extras.scheduleBlockTick(x, y, z, delayTicks, fn, opts)
        : 0;
    },
    cancelBlockTick(id){
      return _extras.cancelBlockTick ? _extras.cancelBlockTick(id) : false;
    },
    cancelBlockTicksAt(x, y, z, dimension){
      return _extras.cancelBlockTicksAt
        ? _extras.cancelBlockTicksAt(x, y, z, dimension)
        : 0;
    },
    getBlockTickCount(){
      return _extras.getBlockTickCount ? _extras.getBlockTickCount() : 0;
    },
    registerRecipe(...args){
      if (!_extras.registerRecipe) return false;
      return _extras.registerRecipe(...args);
    },
    registerSmelt(...args){
      if (!_extras.registerSmelt) return false;
      return _extras.registerSmelt(...args);
    },
    removeSmelt(...args){
      if (!_extras.removeSmelt) return false;
      return _extras.removeSmelt(...args);
    },
    setFuel(...args){
      if (!_extras.setFuel) return false;
      return _extras.setFuel(...args);
    },
    listRecipes(){
      return _extras.listRecipes ? _extras.listRecipes() : null;
    },
    listSmelts(){
      return _extras.listSmelts ? _extras.listSmelts() : null;
    },
    getAtlasUsage(){
      return _extras.getAtlasUsage ? _extras.getAtlasUsage() : null;
    },

    /* ================================================
       世界生成层
       ================================================ */
    registerGenerator(id, cfg){
      const gen = registerGenerator(id, cfg);
      if (!gen) return null;

      /* 如果 mod 声明了 heightLimits，同步进 constants 表 */
      if (gen.heightLimits && _extras.setHeightLimit){
        _extras.setHeightLimit(
          id,
          gen.heightLimits.def || 400,
          gen.heightLimits.max || 400
        );
      }

      emit('generator.registered', id, gen);
      return gen;
    },
    getGenerator,
    getActiveGenerator,
    getActiveGeneratorId,
    setActiveGenerator(id){
      const ok = setActiveGenerator(id);
      if (ok) emit('generator.activeChanged', id);
      return ok;
    },
    listGenerators,
    getGeneratorHeightLimit,

    registerBiome(name, cfg){
      const b = registerBiome(name, cfg);
      if (b){
        emit('biome.registered', name, b);
        /* ★ 通知 Worker 更新群系表 */
        if (_extras.refreshWorkerBiomes){
          try { _extras.refreshWorkerBiomes(); }
          catch(e){ console.warn('[mod-host] refresh biomes failed:', e); }
        }
      }
      return b;
    },
    getBiome,
    getBiomeByName,
    listBiomes,

    /* ================================================
       天空 / 雾
       ================================================ */
    setSkyPreset(preset){
      setSkyPreset(preset);
      emit('sky.presetChanged', preset);
    },
    getSkyPreset,
    setBiomeFog(fog){
      setBiomeFog(fog);
    },

    /* ================================================
       实体层
       ================================================ */
    registerEntity(id, cfg){
      const t = registerEntity(id, cfg);
      if (t) emit('entity.registered', id, t);
      return t;
    },
    getEntityType,
    hasEntityType,
    listEntityTypes,
    getAllEntityTypes,
    getSpawnableTypes,
    getEntityTypeCount,
    getTypesByCategory,

    spawnEntity(type, x, y, z){
      const e = spawnEntity(type, +x, +y, +z);
      if (e) emit('entity.spawned', e);
      return e;
    },
    removeEntity,
    setEntityLoot,
    damageEntity,
    getEntityAt,
    getAnimalCount,

    /* ================================================
       ★ 批量实体查询 / 击杀
       -------------------------------------------------
       · getEntities()                → 所有存活实体
       · getEntitiesInRange(x,y,z,r)  → 范围内实体
       · killEntitiesInRange(...)     → 范围内全杀（返回个数）
       · killEntitiesOfType(type)     → 全图所有该类型全杀
       opts: { type, category, damage, source }
       ================================================ */
    getEntities(){
      const out = [];
      for (const a of animals){
        if (a && !a.dead) out.push(a);
      }
      return out;
    },

    getEntitiesInRange(x, y, z, radius, opts){
      const r = Math.max(0, Number(radius) || 0);
      const r2 = r * r;
      const o = opts || {};
      const typeFilter = (typeof o.type === 'string') ? o.type : null;
      const catFilter  = (typeof o.category === 'string') ? o.category : null;
      const out = [];
      for (const a of animals){
        if (!a || a.dead || a.dormant) continue;
        if (typeFilter && a.type !== typeFilter) continue;
        if (catFilter && a.category !== catFilter) continue;
        const dx = a.pos.x - x, dy = a.pos.y - y, dz = a.pos.z - z;
        if (dx*dx + dy*dy + dz*dz <= r2) out.push(a);
      }
      return out;
    },

    killEntitiesInRange(x, y, z, radius, opts){
      const o = opts || {};
      const list = this.getEntitiesInRange(x, y, z, radius, o);
      const dmg = (Number(o.damage) > 0) ? Number(o.damage) : 999999;
      const source = o.source || null;
      let n = 0;
      for (const a of list){
        try { damageEntity(a, dmg, source); n++; } catch(e){}
      }
      return n;
    },

    killEntitiesOfType(type, opts){
      if (typeof type !== 'string' || !type) return 0;
      const o = opts || {};
      const dmg = (Number(o.damage) > 0) ? Number(o.damage) : 999999;
      const source = o.source || null;
      const list = animals.slice();
      let n = 0;
      for (const a of list){
        if (!a || a.dead) continue;
        if (a.type !== type) continue;
        try { damageEntity(a, dmg, source); n++; } catch(e){}
      }
      return n;
    },

    /* ★ 分类上限 + 距离分级（mod 可调） */
    setEntityCap(category, cap){
      return setEntityCap(category, cap);
    },
    getEntityCap(category){
      return getEntityCap(category);
    },
    listEntityCaps(){
      return listEntityCaps();
    },
    getEntityCounts(){
      return getEntityCounts();
    },
    getEntityCountByType(typeId){
      return getEntityCountByType(typeId);
    },
    setTickDistances(opts){
      return setTickDistances(opts);
    },
    getTickDistances(){
      return getTickDistances();
    },

    /** AI 用的物理工具集（在 cfg.update 里也作为第 4 个参数传进来） */
    get worldApi(){
      return getWorldApi();
    },

    /* ================================================
       维度系统
       ================================================ */
    registerDimension(id, cfg){
      const d = registerDimension(id, cfg);
      if (d) emit('dimension.registered', id, d);
      return d;
    },
    getDimension,
    hasDimension,
    listDimensions,
    getDimensionCount,
    getActiveDimensionId,
    getActiveDimension: _getActiveDimObj,

    /* ★ 创造面板分类：mod 注册自己的分类，物品就落在自己的 tab 里 */
    registerCreativeCategory(def){
      return registerCreativeCategory({ ...def, source: (def && def.source) || 'mod' });
    },
    listCreativeCategories,
    getCreativeCategory,

    switchDimension(id, opts){
      if (!_extras.switchDimension){
        console.warn('[mod-host] switchDimension 未桥接');
        return false;
      }
      return _extras.switchDimension(id, opts && opts.silent);
    },

    /* ================================================
       音效（文件）
       ================================================ */
    registerSound(name, url, opts){
      return _registerSound(name, url, opts);
    },
    unregisterSound(name){
      return _unregisterSound(name);
    },
    loadSound(name){
      return _loadSound(name);
    },
    playSound(name, opts){
      return _playSound(name, opts);
    },
    playSoundAt(name, x, y, z, opts){
      return _playSoundAt(name, x, y, z, opts);
    },
    stopAllSounds(){
      return _stopAllSounds();
    },

    /* ================================================
       背景音乐
       ----------------------------------------------------------------
       路线一（默认）：registerMusicTrack 注册曲目，交给官方调度——
                玩家在同一区块停留满 1 分钟才随机选一首，歌会完整放完。
       路线二：setMusicOwner('mod') 关闭官方调度，然后自行用
                playMusicUrl / playMusicById / stopMusicPlayback /
                onMusicEnded 控制背景音乐。
       ================================================ */
    registerMusicTrack(def){
      return _registerMusicTrack(def);
    },
    unregisterMusicTrack(id){
      return _unregisterMusicTrack(id);
    },
    listMusicTracks(){
      return _listMusicTracks();
    },
    setMusicOwner(owner){
      return _setMusicOwner(owner);
    },
    getMusicOwner(){
      return _getMusicOwner();
    },
    playMusicById(id){
      return _playMusicById(id);
    },
    playMusicUrl(url, opts){
      return _playMusicUrl(url, opts);
    },
    stopMusicPlayback(sec){
      return _stopMusicPlayback(sec);
    },
    isMusicPlaying(){
      return _isMusicPlaying();
    },
    getCurrentMusicId(){
      return _getCurrentMusicId();
    },
    onMusicEnded(fn){
      return _onMusicEnded(fn);
    },
    offMusicEnded(fn){
      return _offMusicEnded(fn);
    },

    /* ================================================
       存档
       ================================================ */
    get saveId(){
      return _extras.getSaveId ? _extras.getSaveId() : null;
    },
    /** 当前世界种子（只读） */
    getSeed(){
      return _extras.getSeed ? _extras.getSeed() : null;
    },
    /** 当前存档真实世界类型（vanilla / superflat / mod 声明类型） */
    getSaveType(){
      return _extras.getSaveType ? _extras.getSaveType() : null;
    },
    storage(modId){
      if (!_extras.getModStorage) return null;
      return _extras.getModStorage(modId);
    },
    /** 创建世界时玩家给这个世界类型选的选项（没选过就是 {}） */
    getWorldOptions(){
      if (!_extras.getWorldOptions) return {};
      try { return _extras.getWorldOptions() || {}; } catch(e){ return {}; }
    },

    /* 世界生成器实例（含 findTemple / params.temperatureAt） */
    getWorldGen: getWorldGenInstance,

    /* ================================================
       诊断
       ================================================ */
    getChunkStats(){
      if (!_extras.getChunkStats) return null;
      return _extras.getChunkStats();
    },

    /* ================================================
       日志
       ================================================ */
    log: {
      info:  (...a) => console.log('%c[mod]', 'color:#7bd0ff', ...a),
      warn:  (...a) => console.warn('[mod]', ...a),
      error: (...a) => console.error('[mod]', ...a),
    },
  };

  return f;
}

/* ============================================================
   安装入口（main.js 调用一次）
   ------------------------------------------------------------
   extras 字段（缺了不报错，只是对应能力返回 null / false）：

     gameVersion          {string}    BUILD 字符串
     triggerDamageUI      {Function}  player.js 导出
     getSaveId            {Function}  () => currentSave?.id
     getSeed              {Function}  () => worldSeed
     getSaveType          {Function}  () => 存档世界类型
     getModStorage        {Function}  (modId) => storage api
     getChunkStats        {Function}  terrain.js 导出
     setHeightLimit       {Function}  constants.js 导出
     refreshWorkerBiomes  {Function}  同步 biomes 到 Worker

     registerBlockRuntime(name, label, opts, drawFn) → block
     setBlockDrop         (name, spec) → bool
     clearBlockDrop       (name) → bool
     getChestItems        (x,y,z, dim?) → Promise<Array>
     setChestItems        (x,y,z, items, opts?) → Promise<bool>
     scheduleBlockTick    (x,y,z, delay, fn, opts?) → tickId
     cancelBlockTick      (id) → bool
     cancelBlockTicksAt   (x,y,z, dim?) → number
     getBlockTickCount    () → number
     registerRecipe     (recipe, source) → recipe | null
     registerSmelt      (from, to, count, source) → bool
     removeSmelt        (from) → bool
     setFuel            (name, seconds) → bool
     listRecipes        () → { size2, size3, runtimeCount }
     listSmelts         () → [{from, to, count, runtime}]
     getAtlasUsage      () → { used, total, free, cols }

     switchDimension    (dimId) => bool
   ============================================================ */
export function installHost(extras){
  if (_facade){
    console.warn('[mod-host] installHost 重复调用，忽略');
    return _facade;
  }
  _extras = extras || {};
  _facade = buildFacade();

  if (typeof window !== 'undefined'){
    window.__GAME__ = _facade;
  }

  const info = _facade.info;
  console.log(
    `%c[mod-host] ✔ __GAME__ 已挂载`,
    'color:#7bd0ff;font-weight:bold',
    `api v${info.apiVersion} · 方块 ${info.blockCount} · ` +
    `生成器 ${info.generatorCount} · 群系 ${info.biomeCount} · ` +
    `实体 ${info.entityCount} · 维度 ${info.dimensionCount} · ` +
    `hook ${info.hookCount}`
  );

  /* 挂 attachVisual 的自动清理钩子 */
  on('world.blockChanged', _handleBlockChanged);
  on('chunk.mesh:unload', _handleChunkUnload);
  on('chunk.mesh:install', _handleChunkInstall);
  on('world.load', _clearAllVisuals);

  /* 通知所有早期订阅者 */
  emit('host.ready', _facade);

  return _facade;
}

/* ============================================================
   卸载（调试 / 极端场景）
   ============================================================ */
export function uninstallHost(){
  if (typeof window !== 'undefined'){
    delete window.__GAME__;
  }
  _facade = null;
  _extras = null;
  console.log('[mod-host] __GAME__ 已卸载');
}