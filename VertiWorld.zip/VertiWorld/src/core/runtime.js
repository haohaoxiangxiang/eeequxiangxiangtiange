/* ============================================================
   runtime.js —— 引擎基础运行时（Worker 安全版）
   ------------------------------------------------------------
   与原始版本逻辑完全一致，唯一区别是：
   · 所有顶层 window / document 访问都包裹 _HAS_WINDOW / _HAS_DOC
   · 所有运行时可能被 Worker 调到的 window 访问都加 typeof 保护
   · crash-guard 里的 requestAnimationFrame / beforeunload 也包裹

   Worker 里不会有 ReferenceError: window is not defined
   ============================================================ */

const _HAS_WINDOW = (typeof window !== 'undefined');
const _HAS_DOC    = (typeof document !== 'undefined');

/* =================================================================
   1. utils.js
   ================================================================= */
const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);

const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

function hash2i(x, y, seed){
  let h = Math.imul(x | 0, 374761393)
        ^ Math.imul(y | 0, 668265263)
        ^ Math.imul(seed | 0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function vnoise(x, y, seed){
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2i(xi,     yi,     seed);
  const b = hash2i(xi + 1, yi,     seed);
  const c = hash2i(xi,     yi + 1, seed);
  const d = hash2i(xi + 1, yi + 1, seed);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
}

function fbm(x, y, oct, seed){
  let s = 0, amp = 1, f = 1, norm = 0;
  for (let i = 0; i < oct; i++){
    s += amp * vnoise(x * f, y * f, seed + i * 137);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return s / norm;
}

function hash3i(x, y, z, seed){
  let h = Math.imul(x | 0, 374761393)
        ^ Math.imul(y | 0, 668265263)
        ^ Math.imul(z | 0, 1442695041)
        ^ Math.imul(seed | 0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function vnoise3(x, y, z, seed){
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const w = zf * zf * (3 - 2 * zf);

  const c000 = hash3i(xi,     yi,     zi,     seed);
  const c100 = hash3i(xi + 1, yi,     zi,     seed);
  const c010 = hash3i(xi,     yi + 1, zi,     seed);
  const c110 = hash3i(xi + 1, yi + 1, zi,     seed);
  const c001 = hash3i(xi,     yi,     zi + 1, seed);
  const c101 = hash3i(xi + 1, yi,     zi + 1, seed);
  const c011 = hash3i(xi,     yi + 1, zi + 1, seed);
  const c111 = hash3i(xi + 1, yi + 1, zi + 1, seed);

  const x00 = c000 * (1 - u) + c100 * u;
  const x10 = c010 * (1 - u) + c110 * u;
  const x01 = c001 * (1 - u) + c101 * u;
  const x11 = c011 * (1 - u) + c111 * u;

  const y0 = x00 * (1 - v) + x10 * v;
  const y1 = x01 * (1 - v) + x11 * v;

  return y0 * (1 - w) + y1 * w;
}

function fbm3(x, y, z, oct, seed){
  let s = 0, amp = 1, f = 1, norm = 0;
  for (let i = 0; i < oct; i++){
    s += amp * vnoise3(x * f, y * f, z * f, seed + i * 137);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return s / norm;
}

/* =================================================================
   2. env.js
   ================================================================= */
const IS_WORKER =
  typeof WorkerGlobalScope !== 'undefined' &&
  typeof self !== 'undefined' &&
  self instanceof WorkerGlobalScope;

const IS_MAIN = !IS_WORKER;

const TOUCH_KEY = '3dmc_touch_mode';

function detectTouch(){
  if (!IS_MAIN) return false;
  try {
    const saved = localStorage.getItem(TOUCH_KEY);
    if (saved === 'on')  return true;
    if (saved === 'off') return false;
  } catch(e){}
  if (('ontouchstart' in window) ||
      ('ontouchend'   in window) ||
      ('ontouchmove'  in window)) return true;
  if (navigator.maxTouchPoints > 0) return true;
  if (navigator.msMaxTouchPoints > 0) return true;
  if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) return true;
  return false;
}

let IS_TOUCH = detectTouch();

if (IS_MAIN && IS_TOUCH){
  document.body.classList.add('touch');
}

function setTouchMode(mode){
  if (!IS_MAIN) return IS_TOUCH;
  if (mode === 'auto') localStorage.removeItem(TOUCH_KEY);
  else localStorage.setItem(TOUCH_KEY, mode);

  if (mode === 'on')  IS_TOUCH = true;
  else if (mode === 'off') IS_TOUCH = false;
  else IS_TOUCH = detectTouch();

  document.body.classList.toggle('touch', IS_TOUCH);
  return IS_TOUCH;
}

function getTouchMode(){
  if (!IS_MAIN) return 'off';
  const saved = localStorage.getItem(TOUCH_KEY);
  if (saved === 'on' || saved === 'off') return saved;
  return 'auto';
}

function getViewport(){
  if (!IS_MAIN) return { w: 0, h: 0, dpr: 1 };
  return {
    w: window.innerWidth  || 1,
    h: window.innerHeight || 1,
    dpr: window.devicePixelRatio || 1,
  };
}

const HAS_SAB = (() => {
  if (typeof SharedArrayBuffer === 'undefined') return false;
  try {
    new SharedArrayBuffer(8);
    return true;
  } catch(e){
    return false;
  }
})();

if (IS_MAIN){
  console.log(
    `[env] SharedArrayBuffer: ${HAS_SAB ? '✔ 可用' : '✘ 不可用（回退旧路径）'}` +
    (typeof crossOriginIsolated !== 'undefined'
      ? ` · crossOriginIsolated=${crossOriginIsolated}` : '')
  );
}

/* =================================================================
   3. logger.js
   ================================================================= */
const MAX = 500;
const ring = [];
let currentSaveId = null;
let uploadUrl = null;

function setLogSaveId(id){
  currentSaveId = id;
  uploadUrl = id ? `/api/log/${encodeURIComponent(id)}` : null;
}

function fmt(...args){
  return args.map(a => {
    try {
      if (a instanceof Error) return a.stack || a.message;
      if (typeof a === 'object') return JSON.stringify(a).slice(0, 300);
      return String(a);
    } catch(e){ return '[obj]'; }
  }).join(' ');
}

function push(level, tag, args){
  const entry = {
    t: Date.now(),
    lv: level,
    tag: tag || '',
    msg: fmt(...args),
  };
  ring.push(entry);
  if (ring.length > MAX) ring.shift();

  const prefix = ['DEBUG','INFO','WARN','ERROR'][level];
  const line = `[${prefix}] [${tag}] ${entry.msg}`;
  if (level >= 3) console.error(line);
  else if (level === 2) console.warn(line);
  else console.log(line);
}

const log = {
  d: (tag, ...a) => push(0, tag, a),
  i: (tag, ...a) => push(1, tag, a),
  w: (tag, ...a) => push(2, tag, a),
  e: (tag, ...a) => push(3, tag, a),
  dump: () => ring.slice(),
};

/* ★ Worker 安全：顶层 window.addEventListener 全部包裹 */
if (_HAS_WINDOW){
  window.addEventListener('error', e => {
    push(3, 'window.error',
      [e.message, e.filename ? `@${e.filename}:${e.lineno}` : '']);
  }, true);
  window.addEventListener('unhandledrejection', e => {
    const r = e.reason;
    push(3, 'promise', [r && (r.stack || r.message) || r]);
  });
}

function dumpLogText(){
  const lines = ring.map(en => {
    const d = new Date(en.t);
    const hh = String(d.getHours()).padStart(2,'0');
    const mm = String(d.getMinutes()).padStart(2,'0');
    const ss = String(d.getSeconds()).padStart(2,'0');
    const ms = String(d.getMilliseconds()).padStart(3,'0');
    const lv = ['DEBUG','INFO','WARN','ERROR'][en.lv];
    return `${hh}:${mm}:${ss}.${ms} [${lv}] [${en.tag}] ${en.msg}`;
  });
  return lines.join('\n');
}

async function uploadLog(){
  if (!uploadUrl) {
    console.warn('[log] 没有 saveId，无法上传');
    return false;
  }
  try {
    const r = await fetch(uploadUrl, {
      method: 'POST',
      body: dumpLogText(),
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
    return r.ok;
  } catch(e){
    console.warn('[log] upload failed', e);
    return false;
  }
}

/* ★ Worker 安全：自动上传监听也包裹 */
let lastUpload = 0;
if (_HAS_WINDOW){
  window.addEventListener('error', () => {
    const now = Date.now();
    if (now - lastUpload < 5000) return;
    lastUpload = now;
    uploadLog();
  });
  window.addEventListener('unhandledrejection', () => {
    const now = Date.now();
    if (now - lastUpload < 5000) return;
    lastUpload = now;
    uploadLog();
  });
}

/* =================================================================
   4. features.js
   ================================================================= */
const USE_SAB = false;

/* =================================================================
   5. device-profile.js
   ================================================================= */
let _cache = null;

function getDeviceProfile(){
  if (_cache) return _cache;
  _cache = _detect();
  return _cache;
}

function describeProfile(){
  const p = getDeviceProfile();
  return `[device] tier=${p.tier} worker=${p.meshWorker} ` +
         `reason=${p.reason} gpu="${p.gpu}" cores=${p.cores} mem=${p.mem}GB`;
}

function _readGpuName(){
  let gpu = '';
  if (!_HAS_DOC) return gpu;   /* ★ Worker 里没有 document，直接返回空 */
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl')
            || canvas.getContext('experimental-webgl');
    if (gl){
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      if (ext){
        gpu = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
      } else {
        gpu = String(gl.getParameter(gl.RENDERER) || '');
      }
      const lose = gl.getExtension('WEBGL_lose_context');
      if (lose) lose.loseContext();
    }
  } catch(e){}
  return gpu;
}

function _detect(){
  const gpu = _readGpuName();
  const g = gpu.toLowerCase();
  const cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 4;
  const mem   = (typeof navigator !== 'undefined' && navigator.deviceMemory) || 4;

  if (/\bapple m[1-4]\b/.test(g) || /\bm[1-4] (pro|max|ultra)\b/.test(g)){
    return _mk('high', true, 'apple-m-series', gpu, cores, mem);
  }
  if (/\bapple a1[0-9]\b/.test(g) || /\ba1[0-9] pro\b/.test(g)){
    return _mk('high', true, 'apple-a-series', gpu, cores, mem);
  }
  if (/apple gpu/.test(g)){
    return _mk('mid', false, 'apple-unknown-conservative', gpu, cores, mem);
  }
  if (/adreno \(tm\) 830\b/.test(g) || /\badreno 830\b/.test(g)){
    return _mk('high', true, 'adreno-830-flagship', gpu, cores, mem);
  }
  if (/adreno \(tm\) 750\b/.test(g) || /\badreno 750\b/.test(g)){
    return _mk('high', true, 'adreno-750-flagship', gpu, cores, mem);
  }
  if (/adreno \(tm\) 7[0-9]{2}\b/.test(g) || /\badreno 7[0-9]{2}\b/.test(g)){
    return _mk('high', true, 'adreno-7xx-high', gpu, cores, mem);
  }
  if (/adreno \(tm\) 6[0-9]{2}\b/.test(g) || /\badreno 6[0-9]{2}\b/.test(g)){
    return _mk('mid', false, 'adreno-6xx-mid', gpu, cores, mem);
  }
  if (/adreno \(tm\) [1-5][0-9]{2}\b/.test(g) || /\badreno [1-5][0-9]{2}\b/.test(g)){
    return _mk('low', false, 'adreno-low-end', gpu, cores, mem);
  }
  if (/maleoon 910/.test(g)){
    return _mk('mid', false, 'kirin-maleoon-910', gpu, cores, mem);
  }
  if (/g925/.test(g) || /immortalis-g925/.test(g)){
    return _mk('high', true, 'dimensity-9400', gpu, cores, mem);
  }
  if (/g720/.test(g) || /immortalis-g720/.test(g)){
    return _mk('high', true, 'dimensity-9300', gpu, cores, mem);
  }
  if (/immortalis/.test(g)){
    return _mk('high', true, 'immortalis-high', gpu, cores, mem);
  }
  if (/mali-g7[0-9]{2}/.test(g)){
    return _mk('mid', false, 'mali-g7xx-mid', gpu, cores, mem);
  }
  if (/mali-g[5-6][0-9]{2}/.test(g)){
    return _mk('low', false, 'mali-low-end', gpu, cores, mem);
  }
  if (/nvidia|geforce|radeon|intel.*iris|intel.*arc|amd /.test(g)){
    return _mk('high', true, 'desktop-gpu', gpu, cores, mem);
  }
  return _mk('mid', false, 'unknown-conservative', gpu, cores, mem);
}

function _mk(tier, meshWorker, reason, gpu, cores, mem){
  return { tier, meshWorker, reason, gpu, cores, mem };
}

/* =================================================================
   6. crash-guard.js
   ================================================================= */
const KEY = '3dmc_crash_heartbeat';
const UPLOAD_URL_BASE = '/api/log';

let phase = 'idle';
let phaseInfo = '';
let timerId = null;
let saveId = null;
let bootAt = Date.now();
let lastFrameTime = _HAS_WINDOW && performance.now ? performance.now() : Date.now();
let frameCount = 0;
let fps = 0;

const WRITE_MIN_INTERVAL_MS = 4000;

let _snapObj = null;
let _writePending = false;
let _lastWriteAt = 0;

function _flushSnapshot(){
  _writePending = false;
  if (!_snapObj) return;
  if (Date.now() - _lastWriteAt < WRITE_MIN_INTERVAL_MS) return;
  _lastWriteAt = Date.now();
  try { localStorage.setItem(KEY, JSON.stringify(_snapObj)); } catch(e){}
}

function _scheduleFlush(){
  if (_writePending) return;
  if (Date.now() - _lastWriteAt < WRITE_MIN_INTERVAL_MS) return;
  _writePending = true;
  if (typeof requestIdleCallback === 'function'){
    requestIdleCallback(_flushSnapshot, { timeout: WRITE_MIN_INTERVAL_MS });
  } else {
    setTimeout(_flushSnapshot, WRITE_MIN_INTERVAL_MS);
  }
}

function beat(){
  try {
    const now = _HAS_WINDOW && performance.now ? performance.now() : Date.now();
    const dt = (now - lastFrameTime) / 1000;
    lastFrameTime = now;
    frameCount++;
    if (frameCount % 10 === 0){
      fps = Math.round(10 / dt);
    }

    _snapObj = {
      t: Date.now(),
      phase,
      info: phaseInfo,
      fps,
      uptime: Date.now() - bootAt,
      mem: (_HAS_WINDOW && performance.memory && performance.memory.usedJSHeapSize)
        ? Math.round(performance.memory.usedJSHeapSize / 1048576)
        : null,
    };
    _scheduleFlush();
  } catch(e){}
}

function mark(name, info){
  phase = name;
  phaseInfo = info == null ? '' : String(info);
  beat();
}

let frameHook = null;

function initCrashGuard(currentSaveId){
  saveId = currentSaveId || null;
  bootAt = Date.now();

  checkLastCrash();

  if (timerId) clearInterval(timerId);
  timerId = setInterval(beat, 800);

  /* ★ Worker 里没有 window / requestAnimationFrame，到此为止 */
  if (!_HAS_WINDOW || typeof requestAnimationFrame !== 'function') return;

  if (frameHook) cancelAnimationFrame(frameHook);
  const tick = () => {
    frameHook = requestAnimationFrame(tick);
    const now = performance.now();
    const dt = (now - lastFrameTime);
    if (dt >= 1000){
      fps = Math.round(frameCount * 1000 / dt);
      frameCount = 0;
      lastFrameTime = now;
    }
  };
  frameHook = requestAnimationFrame(tick);

  window.addEventListener('beforeunload', () => {
    try {
      localStorage.setItem(KEY, JSON.stringify({
        t: Date.now(), phase: 'clean-exit', info: '', fps: 0, uptime: 0, mem: null,
      }));
    } catch(e){}
  });

  console.log('[crash-guard] 已启动');
}

function checkLastCrash(){
  if (!_HAS_WINDOW) return;
  let raw = null;
  try { raw = localStorage.getItem(KEY); } catch(e){}
  if (!raw) return;

  let snap;
  try { snap = JSON.parse(raw); } catch(e){ return; }

  if (snap && snap.phase === 'clean-exit') return;

  const ago = Date.now() - (snap.t || 0);
  if (ago < 1500) return;

  const report =
    `[CRASH-DETECT] 上次会话异常结束\n` +
    `  距离现在：${Math.round(ago / 1000)} 秒\n` +
    `  最后阶段：${snap.phase}\n` +
    `  阶段信息：${snap.info}\n` +
    `  最后 FPS：${snap.fps}\n` +
    `  已运行：${Math.round((snap.uptime || 0) / 1000)} 秒\n` +
    `  JS 堆内存：${snap.mem != null ? snap.mem + ' MB' : '不可用'}\n` +
    `  UA：${(typeof navigator !== 'undefined' && navigator.userAgent) || ''}\n` +
    `  时间：${new Date().toISOString()}\n`;

  console.error('[crash-guard]', report);

  const upload = () => {
    if (!saveId){
      console.warn('[crash-guard] 无 saveId，跳过上传');
      return;
    }
    fetch(`${UPLOAD_URL_BASE}/${encodeURIComponent(saveId)}`, {
      method: 'POST',
      body: report,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    }).then(r => {
      if (r.ok) console.log('[crash-guard] 崩溃报告已上传');
    }).catch(() => {});
  };
  setTimeout(upload, 3000);

  try { localStorage.removeItem(KEY); } catch(e){}
}

function getFPS(){ return fps; }
function getPhase(){ return phase; }

/* =================================================================
   re-export
   ================================================================= */
export {
  clamp, fbm, fbm3, hash2i, hash3i, smoothstep, vnoise, vnoise3,
  HAS_SAB, IS_MAIN, IS_TOUCH, IS_WORKER, getTouchMode, getViewport, setTouchMode,
  dumpLogText, log, setLogSaveId, uploadLog,
  USE_SAB,
  describeProfile, getDeviceProfile,
  getFPS, getPhase, initCrashGuard, mark,
};