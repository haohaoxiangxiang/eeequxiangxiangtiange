/* ============================================================
   key-bindings.js —— 游戏按键绑定（动作 ↔ 键盘 / 鼠标 / 手柄）
   ------------------------------------------------------------
   · 设置里可以像 MC 的「按键绑定」一样自由改键
   · 允许一个键被多个动作共用（和 MC 一样会提示冲突）
   · mod 可以通过 G.keybinds.register() 注册自己的动作
   · 键位存 localStorage，玩家不用被迫接受 WASD
   · 手柄按标准 Gamepad 布局编号，写成 pad:A / pad:Up 这种
   ============================================================ */
import { emit } from './engine-core.js';

const BIND_KEY = '3dmc_keybinds_v1';

/* 可以改键的游戏动作。def 是默认按键（和原来硬编码的行为一致） */
export const BIND_ACTIONS = [
  { id: 'forward',   label: '前进',      def: 'KeyW' },
  { id: 'back',      label: '后退',      def: 'KeyS' },
  { id: 'left',      label: '左移',      def: 'KeyA' },
  { id: 'right',     label: '右移',      def: 'KeyD' },
  { id: 'jump',      label: '跳跃',      def: 'Space' },
  { id: 'sneak',     label: '潜行',      def: 'ShiftLeft' },
  { id: 'sprint',    label: '疾跑',      def: 'ControlLeft' },
  { id: 'inventory', label: '背包',      def: 'KeyE' },
  { id: 'fly',       label: '飞行切换',  def: 'KeyF' },
  { id: 'resetPos',  label: '复位位置',  def: 'KeyR' },
];

/* 动作 → 游戏内部沿用的规范键码，逐帧逻辑完全不用改 */
const CANONICAL = {
  forward: 'KeyW',
  back:    'KeyS',
  left:    'KeyA',
  right:   'KeyD',
  sprint:  'ControlLeft',
};

/* 标准手柄按钮名（Gamepad.buttons 下标） */
export const PAD_BUTTONS = {
  A: 0, B: 1, X: 2, Y: 3,
  LB: 4, RB: 5, LT: 6, RT: 7,
  Back: 8, Start: 9, L3: 10, R3: 11,
  Up: 12, Down: 13, Left: 14, Right: 15,
};

const PAD_NAMES = [];
for (const [name, idx] of Object.entries(PAD_BUTTONS)) PAD_NAMES[idx] = name;

const KEY_LABELS = {
  Space: '空格', Escape: 'Esc', Backspace: '⌫', Enter: '↵', Tab: 'Tab',
  CapsLock: 'Caps', Backquote: '`', Minus: '-', Equal: '=',
  BracketLeft: '[', BracketRight: ']', Backslash: '\\',
  Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/',
  ShiftLeft: 'Shift', ShiftRight: 'Shift',
  ControlLeft: 'Ctrl', ControlRight: 'Ctrl',
  AltLeft: 'Alt', AltRight: 'Alt',
  MetaLeft: 'Win', MetaRight: 'Win',
  ArrowLeft: '←', ArrowUp: '↑', ArrowDown: '↓', ArrowRight: '→',
  Insert: 'Ins', Delete: 'Del', Home: 'Home', End: 'End',
  PageUp: 'PgUp', PageDown: 'PgDn',
  mouseLeft: '鼠标左键', mouseRight: '鼠标右键',
};

const PAD_LABELS = {
  A: 'A', B: 'B', X: 'X', Y: 'Y',
  LB: 'LB', RB: 'RB', LT: 'LT', RT: 'RT',
  Back: 'Back', Start: 'Start', L3: 'L3', R3: 'R3',
  Up: '↑', Down: '↓', Left: '←', Right: '→',
};

export function keyLabel(code){
  if (!code) return '';
  if (code.indexOf('pad:') === 0){
    const n = code.slice(4);
    return '手柄 ' + (PAD_LABELS[n] || n);
  }
  if (KEY_LABELS[code]) return KEY_LABELS[code];
  if (code.indexOf('Key') === 0) return code.slice(3);
  if (code.indexOf('Digit') === 0) return code.slice(5);
  if (code.indexOf('F') === 1 && /^F\d+$/.test(code)) return code;
  return code;
}

/* ---------------- 存储 ---------------------------- */
function baseDefaults(){
  const out = {};
  for (const a of BIND_ACTIONS) out[a.id] = a.def;
  return out;
}

let bindings = null;

/* mod 运行时注册的动作（不持久化回调，只在本次会话有效） */
const modActions = new Map();

function load(){
  if (bindings) return bindings;
  bindings = baseDefaults();
  try {
    const raw = JSON.parse(localStorage.getItem(BIND_KEY) || 'null');
    if (raw && typeof raw === 'object'){
      for (const k of Object.keys(raw)){
        if (typeof raw[k] === 'string' || raw[k] === null) bindings[k] = raw[k];
      }
    }
  } catch(e){}
  return bindings;
}

function save(){
  try { localStorage.setItem(BIND_KEY, JSON.stringify(bindings)); } catch(e){}
  try { window.dispatchEvent(new CustomEvent('3dmc:keybindings')); } catch(e){}
  try { emit('keybind.changed'); } catch(e){}
}

/* ---------------- 动作表 ---------------------------- */
export function getAllActions(){
  const out = BIND_ACTIONS.slice();
  for (const a of modActions.values()) out.push(a);
  return out;
}

export function getAction(id){
  load();
  const base = BIND_ACTIONS.find(a => a.id === id);
  if (base) return base;
  return modActions.get(id) || null;
}

/* mod 注册自定义动作：
   { id, label, defaultKey, onPress, onRelease }
   返回一个句柄，便于 setKey / unregister。 */
export function registerBindingAction(cfg){
  if (!cfg || typeof cfg.id !== 'string' || !cfg.id) return null;
  const id = cfg.id;
  const def = (typeof cfg.defaultKey === 'string') ? cfg.defaultKey
            : (typeof cfg.def === 'string') ? cfg.def : '';
  load();
  const entry = {
    id,
    label: typeof cfg.label === 'string' && cfg.label ? cfg.label : id,
    def,
    mod: true,
    onPress: typeof cfg.onPress === 'function' ? cfg.onPress : null,
    onRelease: typeof cfg.onRelease === 'function' ? cfg.onRelease : null,
  };
  const existed = modActions.has(id);
  modActions.set(id, entry);
  /* 首次注册才写默认键；重复注册（热重载）保留玩家改过的键 */
  if (!(id in bindings)) bindings[id] = def || null;
  save();
  if (!existed) emit('keybind.registered', id, entry.label);

  const handle = {
    id,
    label: entry.label,
    defaultKey: def,
    get key(){ return getBinding(id); },
    setKey(code){ return setBinding(id, code); },
    unregister(){ return unregisterBindingAction(id); },
  };
  return handle;
}

export function unregisterBindingAction(id){
  const ok = modActions.delete(id);
  if (ok){
    try { window.dispatchEvent(new CustomEvent('3dmc:keybindings')); } catch(e){}
    emit('keybind.unregistered', id);
  }
  return ok;
}

/* ---------------- 读写 ---------------------------- */
export function getBinding(action){
  load();
  return bindings[action] || '';
}

export function getAllBindings(){
  load();
  return { ...bindings };
}

export function setBinding(action, code){
  load();
  if (!getAction(action)) return false;
  bindings[action] = code || null;
  save();
  emit('keybind.changedOne', action, bindings[action]);
  return true;
}

export function resetBindings(){
  bindings = {};
  for (const a of getAllActions()) bindings[a.id] = a.def || null;
  save();
  return { ...bindings };
}

/* 与某个键冲突的其他动作 */
export function conflictsForCode(code, excludeAction){
  if (!code) return [];
  load();
  const out = [];
  for (const a of getAllActions()){
    if (a.id === excludeAction) continue;
    if (bindings[a.id] === code) out.push({ id: a.id, label: a.label, mod: !!a.mod });
  }
  return out;
}

/* 同一个键可能绑了多个动作（允许冲突，全部触发） */
export function actionsForCode(code){
  if (!code) return [];
  load();
  const out = [];
  for (const a of getAllActions()){
    if (bindings[a.id] === code) out.push(a.id);
  }
  return out;
}

export function actionForCode(code){
  const all = actionsForCode(code);
  return all.length ? all[0] : null;
}

/* 动作被按下/松开时通知 mod（内部去重由调用方保证） */
export function runBindingCallback(action, down){
  let fired = false;
  const a = modActions.get(action);
  if (a){
    const fn = down ? a.onPress : a.onRelease;
    if (fn){
      try { fn(); fired = true; }
      catch(e){ console.error('[keybind] mod 回调出错:', action, e); }
    }
  }
  try { emit('keybind.action', action, !!down); } catch(e){}
  return fired;
}

export function canonicalKeyFor(action){
  return CANONICAL[action] || null;
}

/* 物理 / 虚拟手柄按钮 → 绑定用的键码 */
export function padCodeForIndex(idx){
  const name = PAD_NAMES[idx];
  return name ? ('pad:' + name) : null;
}

export function padIndexForCode(code){
  if (!code || code.indexOf('pad:') !== 0) return -1;
  const v = PAD_BUTTONS[code.slice(4)];
  return v === undefined ? -1 : v;
}

export { PAD_NAMES, CANONICAL };
