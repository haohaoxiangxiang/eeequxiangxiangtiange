/* ============================================================
   engine-core.js —— 全局常量 + 事件总线 + 内存策略
   ------------------------------------------------------------
★ 合并自 core 下的 3 个基础件（约 21KB）：
     constants.js  全局常量（CS/CHH/Y_MIN/SEA_LEVEL/INV_SIZE/世界高度表…）
     mod-core.js   事件总线 + Hook 系统（on/emit/defineHook…）
     memory.js     内存上限与 GC 策略（按设备档位决定）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
/* ★ 这里【不要】在顶层 import render-core.js。
   textures.js → engine-core.js → render-core.js → textures.js 是一个环，
   ESM 会先空闲求值 textures.js，此时它从本文件拿到的 ATLAS_COLS 还在 TDZ 里，
   直接 ReferenceError: Cannot access 'ATLAS_COLS' before initialization，
   整个模块图崩掉 → main.js 一行不执行 → 开始界面所有按钮点不动。
   render-core 里的东西（renderer/scene/…）本来就是运行期才用的，
   改成用到时再动态取，环就变成了单向。 */
import { IS_TOUCH } from './runtime.js';




/* =================================================================
   constants.js
   ================================================================= */
/* ============================================================
   constants.js —— 全局常量
   ============================================================ */

/* ★ 触屏相关已搬到 env.js，这里 re-export 保持向后兼容 */
export { IS_TOUCH, setTouchMode, getTouchMode } from './runtime.js';

const CS = 16;

/* ============================================================
   Y 轴设计
   ------------------------------------------------------------
   · 海平面固定 y = 46
   · 地表陆地大约 y = 46 ~ 52
   · 世界顶部 = CHH（创建世界时玩家选的「最高区块」）
   · 世界底部 = Y_MIN = min(-CHH*0.2, -46)（基岩所在）
   ------------------------------------------------------------
   有效 y 范围：[Y_MIN, CHH-1]，总层数 COL_H = CHH - Y_MIN
   idx(x, y, z) 接受「世界 y」（可为负），内部转成存储层
   ============================================================ */
const SEA_LEVEL = 46;

let CHH = 400;            // 世界顶部 y（不含）
let Y_MIN = -46;          // 世界底部 y（基岩所在）
let COL_H = CHH - Y_MIN;  // 总层数

const MIN_WORLD_HEIGHT = 80;
const MAX_WORLD_HEIGHT_NORMAL = 400;
const MAX_WORLD_HEIGHT_REALISTIC = 1000;

const WORLD_HEIGHT_KEY = '3dmc_world_height';

/* ============================================================
   各世界类型的默认/上限高度
   ============================================================ */
const HEIGHT_LIMITS = {
  flat:      { def: 80,   max: 400  },
  vanilla:   { def: 400,  max: 400  },
  realistic: { def: 1000, max: 1000 }
};

/* 世界底部：-CHH*0.2，但不高于 -46（越深越负） */
function computeYMin(chh){
  return Math.min(-Math.floor(chh * 0.2), -46);
}

/* 雪线 / 云线（保留兼容，实际由气候系统决定） */
function snowLine(){
  return SEA_LEVEL + 180;
}

function cloudHeight(){
  return SEA_LEVEL + 180;
}

/* 世界 y ↔ 存储层 0..COL_H-1 的互转 */
const toStoreY = (y) => y - Y_MIN;
const toWorldY = (sy) => sy + Y_MIN;

/* 方块索引：输入世界 y，输出线性数组下标 */
const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;

/* 自然地形生成上限（以上留白给玩家建造） */
function terrainCeiling(){
  return Math.max(SEA_LEVEL + 30, Math.floor(CHH * 0.85));
}

/* ============================================================
   动态高度限制
   ============================================================ */
function getHeightLimit(type){
  return HEIGHT_LIMITS[type] || HEIGHT_LIMITS.vanilla;
}

function setHeightLimit(type, def, max){
  if (typeof type !== 'string' || !type) return false;
  const d = Math.max(MIN_WORLD_HEIGHT, Math.floor(Number(def) || 400));
  const m = Math.max(d, Math.floor(Number(max) || d));
  HEIGHT_LIMITS[type] = { def: d, max: m };
  return true;
}

function removeHeightLimit(type){
  if (type === 'flat' || type === 'vanilla' || type === 'realistic') return false;
  return delete HEIGHT_LIMITS[type];
}

/* ============================================================
   世界高度操作
   ============================================================ */
function clampWorldHeight(h, type){
  const lim = getHeightLimit(type);
  let v = Math.floor(Number(h));
  if (!isFinite(v)) v = lim.def;
  return Math.max(MIN_WORLD_HEIGHT, Math.min(lim.max, v));
}

function getDefaultWorldHeight(type){
  return getHeightLimit(type).def;
}

/* 设置当前世界高度；同步刷新 Y_MIN / COL_H */
function setWorldHeight(h, type){
  CHH = clampWorldHeight(h, type);
  Y_MIN = computeYMin(CHH);
  COL_H = CHH - Y_MIN;
  return CHH;
}

/* 设定值按世界类型记忆在 localStorage（创建界面用） */
function loadSavedWorldHeight(type){
  try {
    const raw = localStorage.getItem(WORLD_HEIGHT_KEY);
    const obj = raw ? JSON.parse(raw) : {};
    if (obj && obj[type] != null) return clampWorldHeight(obj[type], type);
  } catch(e){}
  return getDefaultWorldHeight(type);
}

function saveWorldHeight(type, h){
  try {
    const raw = localStorage.getItem(WORLD_HEIGHT_KEY);
    const obj = raw ? JSON.parse(raw) : {};
    obj[type] = clampWorldHeight(h, type);
    localStorage.setItem(WORLD_HEIGHT_KEY, JSON.stringify(obj));
  } catch(e){}
}

/* ============================================================
   ★ 生物群系 id（必须和 biome-registry.js 严格一致）
   ------------------------------------------------------------
   共 16 个内置群系（0~15）。
   改动这里必须同步改 biome-registry.js 里的 id。
   ============================================================ */
const BIOME = {
  OCEAN:        0,   // 海洋
  BEACH:        1,   // 沙滩
  PLAINS:       2,   // 平原
  FOREST:       3,   // 森林
  SAKURA:       4,   // 樱花林
  BIRCH_FOREST: 5,   // 白桦林
  SWAMP:        6,   // 沼泽
  TAIGA:        7,   // 针叶林
  SNOW:         8,   // 雪原
  DESERT:       9,   // 沙漠
  SAVANNA:     10,   // 稀树草原
  JUNGLE:      11,   // 丛林
  BADLANDS:    12,   // 荒地
  MANGROVE:    13,   // 红树林
  MUSHROOM:    14,   // 蘑菇岛
  RIVER:       15,   // 河流
};

/* ============================================================
   玩家 / 物品常量
   ============================================================ */
const PLAYER_W = 0.6;
const PLAYER_H = 1.8;
const STACK_MAX = 64;
const INV_SIZE = 36;

/* ============================================================
   ★ Atlas 纹理（动态尺寸）
   ------------------------------------------------------------
   优先级：
     ① 服务端注入的 window.__ATLAS_CONFIG__（根据 mod 需求算）
     ② 默认 32×32（无服务端或注入失败时）
   ============================================================ */
function _readAtlasCols(){
  try {
    if (typeof window !== 'undefined' && window.__ATLAS_CONFIG__){
      const c = Number(window.__ATLAS_CONFIG__.cols);
      if (isFinite(c) && c >= 8 && c <= 512){
        return Math.floor(c);
      }
    }
  } catch(e){}
  return 32;
}

const ATLAS_TILE = 32;
const ATLAS_COLS = _readAtlasCols();
const ATLAS_SIZE = ATLAS_TILE * ATLAS_COLS;
const TEX_INNER = 16;
const TEX_PAD = 8;

if (typeof window !== 'undefined'){
  console.log(
    `[atlas] cols=${ATLAS_COLS} size=${ATLAS_SIZE} ` +
    `source=${window.__ATLAS_CONFIG__ ? 'server' : 'default'}`
  );
}

/* ============================================================
   世界类型
   ============================================================ */
const WORLD_TYPE = {
  FLAT: 'flat',
  VANILLA: 'vanilla',
  REALISTIC: 'realistic'
};

/* ============================================================
   ★ 多维度全局状态
   ------------------------------------------------------------
   放在 constants 里是为了让 terrain / chunk-db / player 都能
   import 它，而不用互相 import 成环。
   ============================================================ */
let _activeDimension = 'overworld';

function getActiveDimension(){
  return _activeDimension;
}

function setActiveDimensionGlobal(id){
  if (typeof id !== 'string' || !id) return false;
  _activeDimension = id;
  return true;
}

/* 别名 */
const setActiveDimensionId = setActiveDimensionGlobal;

/* 维度 id 校验规则 */
function isValidDimensionId(id){
  return typeof id === 'string' &&
         id.length > 0 && id.length <= 64 &&
         /^[a-zA-Z0-9_-]+$/.test(id);
}

/* =================================================================
   mod-core.js
   ================================================================= */
/* ============================================================
   mod-core.js —— Mod 内核（纯工具，无游戏依赖）
   ------------------------------------------------------------
   Phase 1.1 改动：
     · before 支持 {cancel:true, value?} 协议（保留 return false 兼容）
     · after 增加第 4 个参数 ctx，提供 ctx.setReturn(v) 修改返回值
     · replace 改成 priority 排序的数组，支持多 mod 叠加与回退
     · 新增 replaceCount / ownReplaceCount 用于诊断

   向后兼容：
     · 旧的 `return false` 拦截行为不变（返回 undefined）
     · 旧的 `after((ret, args, e) => ...)` 三个参数调用方式不变
     · 单个 replace() 行为不变（只是内部从单值变成数组）
   ============================================================ */

/* ============================================================
   ① 事件总线
   ============================================================ */
const _events = new Map();

function on(name, fn){
  if (typeof fn !== 'function') return () => {};
  let set = _events.get(name);
  if (!set){ set = new Set(); _events.set(name, set); }
  set.add(fn);
  return () => set.delete(fn);
}

function off(name, fn){
  const set = _events.get(name);
  if (set) set.delete(fn);
}

function once(name, fn){
  const un = on(name, (...args) => { un(); fn(...args); });
  return un;
}

function emit(name, ...args){
  const set = _events.get(name);
  if (!set || set.size === 0) return;
  const arr = Array.from(set);
  for (let i = 0; i < arr.length; i++){
    try { arr[i](...args); }
    catch(e){ console.error(`[emit] "${name}" handler 出错:`, e); }
  }
}

/**
 * 触发一个可取消的事件。
 * 如果任意一个监听器返回 true，则视为该事件被拦截。
 * @returns {boolean} 是否被拦截
 */
function emitCancellable(name, ...args){
  const set = _events.get(name);
  if (!set || set.size === 0) return false;
  const arr = Array.from(set);
  let cancelled = false;
  for (let i = 0; i < arr.length; i++){
    try { 
      const r = arr[i](...args); 
      if (r === true) cancelled = true; 
    }
    catch(e){ console.error(`[emitCancellable] "${name}" handler 出错:`, e); }
  }
  return cancelled;
}

function listenerCount(name){
  const set = _events.get(name);
  return set ? set.size : 0;
}

function listEvents(){
  return Array.from(_events.keys());
}

function clearAllEvents(){
  _events.clear();
}

/* ============================================================
   ② 函数 hook
   ============================================================ */
const _hooks = new Map();
let _hookHandleSeq = 0;

function defineHook(name, fn){
  if (_hooks.has(name)){
    console.warn(`[hook] "${name}" 已存在，覆盖原实现`);
  }
  const entry = {
    name,
    original: fn,
    current: fn,
    befores: [],
    afters: [],
    replacements: [],
  };
  _hooks.set(name, entry);

  const callable = function(...args){
    const e = _hooks.get(name);
    if (!e) return fn.apply(this, args);

    let cancelled = false;
    let cancelValue;
    const bs = e.befores;
    for (let i = 0; i < bs.length; i++){
      const f = bs[i];
      if (!f) continue;
      try {
        const r = f(args, e);
        if (r === false){
          cancelled = true;
          break;
        }
        if (r && typeof r === 'object' && r.cancel === true){
          cancelled = true;
          if ('value' in r) cancelValue = r.value;
          break;
        }
      } catch(err){
        console.error(`[hook] ${name}.before`, err);
      }
    }

    if (cancelled) return cancelValue;

    let ret = e.current.apply(this, args);

    const as = e.afters;
    for (let i = 0; i < as.length; i++){
      const f = as[i];
      if (!f) continue;
      try {
        const ctx = {
          get value(){ return ret; },
          setReturn(v){ ret = v; },
        };
        f(ret, args, e, ctx);
      } catch(err){
        console.error(`[hook] ${name}.after`, err);
      }
    }
    return ret;
  };
  callable.__hookName = name;
  return callable;
}

function _dropFn(e, key, fn){
  const arr = e[key];
  for (let i = 0; i < arr.length; i++){
    if (arr[i] === fn){ arr[i] = null; return true; }
  }
  return false;
}

function _compactHook(e){
  for (const key of ['befores', 'afters']){
    const arr = e[key];
    if (arr.length < 24) continue;
    let live = 0;
    for (let i = 0; i < arr.length; i++) if (arr[i]) live++;
    if (live * 2 < arr.length) e[key] = arr.filter(Boolean);
  }
}

function getHook(name){
  const e = _hooks.get(name);
  if (!e){
    console.warn(`[hook] 不存在: ${name}`);
    return null;
  }

  const ownB = [], ownA = [];
  const _id = `h${++_hookHandleSeq}`;

  const handle = {
    _id,

    before(fn){
      if (typeof fn !== 'function') return handle;
      e.befores.push(fn); ownB.push(fn); return handle;
    },

    after(fn){
      if (typeof fn !== 'function') return handle;
      e.afters.push(fn); ownA.push(fn); return handle;
    },

    replace(fn, priority){
      if (typeof fn !== 'function') return handle;
      const p = (typeof priority === 'number' && isFinite(priority)) ? priority : 1000;

      for (const r of e.replacements){
        if (r.priority === p && r.owner !== handle){
          console.warn(
            `[hook] "${name}".replace 同优先级冲突 (priority=${p})：` +
            `${r.owner._id} vs ${_id}，后者覆盖前者`
          );
        }
      }

      e.replacements.push({ fn, priority: p, owner: handle });
      e.replacements.sort((a, b) => b.priority - a.priority);
      e.current = e.replacements[0].fn;
      return handle;
    },

    remove(fn){
      for (const [arr, key] of [[ownB, 'befores'], [ownA, 'afters']]){
        const i = arr.indexOf(fn);
        if (i >= 0){ arr.splice(i, 1); _dropFn(e, key, fn); }
      }
      return handle;
    },

    restore(){
      for (const fn of ownB) _dropFn(e, 'befores', fn);
      for (const fn of ownA) _dropFn(e, 'afters', fn);
      ownB.length = 0; ownA.length = 0;

      e.replacements = e.replacements.filter(r => r.owner !== handle);
      e.current = e.replacements.length ? e.replacements[0].fn : e.original;

      _compactHook(e);
      return handle;
    },

    get original(){ return e.original; },
    get current(){ return e.current; },
    get beforeCount(){ let n = 0; for (const f of e.befores) if (f) n++; return n; },
    get afterCount(){ let n = 0; for (const f of e.afters) if (f) n++; return n; },
    get ownBeforeCount(){ return ownB.length; },
    get ownAfterCount(){ return ownA.length; },
    get replaceCount(){ return e.replacements.length; },
    get ownReplaceCount(){
      let n = 0;
      for (const r of e.replacements) if (r.owner === handle) n++;
      return n;
    },
  };
  return handle;
}

function listHooks(){
  return Array.from(_hooks.keys());
}

function isHooked(name){
  return _hooks.has(name);
}

/* =================================================================
   memory.js
   ================================================================= */
/* ============================================================
   memory.js —— 内存上限 / GPU 信息 / 诊断事件监听
   ------------------------------------------------------------
   从 main.js 拆出：
     · 内存状态（_memState）与 __getMemoryLimit 等全局暴露
     · GPU_NAME 探测 + __gpuInfo() 完整快照
     · window resize / error / unhandledrejection / pagehide
       / visibilitychange 五个诊断监听
     · 内存滑条占位初始化（现在隐藏）

   ★ 修复：
     · getGPUInfo 里的 gl.getParameter(MAX_TEXTURE_SIZE) 会
       在部分安卓驱动上触发 GPU 同步 → 缓存结果，只查一次
   ============================================================ */



/* ============================================================
   内存状态
   ============================================================ */
const _memState = { profile: null, limitMB: 0 };

/**
 * 应用内存上限。
 * @param {number} limitMB
 * @param {object|null} profile
 */
function applyMemoryLimit(limitMB, profile){
  if (profile) _memState.profile = profile;
  _memState.limitMB = Math.max(100, Math.round(limitMB || 0));
}

function getMemoryState(){ return _memState; }

/* ============================================================
   惰性取用 render-core（避免顶层循环依赖，见文件头说明）
   ============================================================ */
let _renderCore = null;
function _rc(){
  _renderCore = _renderCore || _renderCorePromise;
  return _renderCore;
}
/* ★ 惰性加载：不要在模块求值过程中立刻 import render-core。
   原来的 IIFE 会触发 render-core.js → textures.js 求值，
   而那时 engine-core.js 还没跑完，textures.js 从本文件拿到的
   ATLAS_COLS 是 TDZ，整条模块图崩。改成本函数，只有真正用到的
   地方主动调用时才发起 import。 */
let _renderCorePromise = null;
function _loadRenderCore(){
  if (_renderCore) return Promise.resolve(_renderCore);
  if (!_renderCorePromise){
    _renderCorePromise = import('../render/render-core.js').then(m => {
      _renderCore = m;
      return m;
    });
  }
  return _renderCorePromise;
}
/* 同步取用的兜底（首次调用时若还没加载完，就先拿一个占位对象） */
function _rcNow(){
  return _renderCore || {
    renderer: { getContext(){ throw new Error('render-core 尚未加载'); }, domElement: {}, shadowMap: {}, info: {} },
    scene: { children: [] },
    getPixelRatioNow: () => 1,
    getUserScale: () => 1,
    MAX_DRAW_PIXELS: 0,
  };
}

/* ============================================================
   GPU 探测
   ============================================================ */
/* ★ 改成惰性求值：原来顶层立刻调 renderer.getContext()，
   合并后 engine-core ← render-core 的循环依赖会在初始化时 TDZ 崩。 */
let _gpuNameCache = null;
function _getGpuName(){
  if (_gpuNameCache !== null) return _gpuNameCache;
  try {
    const gl = _rcNow().renderer.getContext();
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext){
      return String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '') +
             ' / ' + String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) || '');
    }
    return String(gl.getParameter(gl.RENDERER) || '') + ' / ' +
           String(gl.getParameter(gl.VENDOR) || '');
  } catch(e){ return 'unavailable'; }
}
function GPU_NAMEget(){ return _getGpuName(); }

/* ============================================================
   ★ MAX_TEXTURE_SIZE 缓存
   ------------------------------------------------------------
   在部分安卓驱动上，gl.getParameter(MAX_TEXTURE_SIZE) 会触发
   GPU 同步，每次调用 1~10ms。诊断面板 / 崩溃上报里每次都查
   就会造成规律性的主线程卡顿（站着不动更明显）。

   MAX_TEXTURE_SIZE 是设备常量，查一次就够。
   ============================================================ */
let _maxTexCache = null;
function _getMaxTex(gl){
  if (_maxTexCache === null){
    try {
      _maxTexCache = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    } catch(e){
      _maxTexCache = 0;
    }
  }
  return _maxTexCache;
}

/**
 * 完整 GPU / 画布 / 平台快照。
 * 被诊断模块和调试面板共同使用。
 */
function getGPUInfo(){
  try {
    const gl = _rcNow().renderer.getContext();
    const dbw = gl.drawingBufferWidth, dbh = gl.drawingBufferHeight;
    const px = dbw * dbh;
    return {
      pr: Math.round(_R.getPixelRatioNow() * 100) / 100,
      scale: _R.getUserScale(),
      dpr: window.devicePixelRatio || 1,
      canvas: _R.renderer.domElement.width + 'x' + _R.renderer.domElement.height,
      buf: dbw + 'x' + dbh,
      bufMpx: Math.round(px / 1e4) / 100,
      fbMB: Math.round(px * 8 / 1048576),
      fbMBx3: Math.round(px * 8 * 3 / 1048576),
      cap: Math.round(_R.MAX_DRAW_PIXELS / 1e4) / 100,
      lost: gl.isContextLost ? gl.isContextLost() : false,
      maxTex: _getMaxTex(gl),                 // ★ 走缓存
      resizes: window.__resizeCount || 0,
      sceneKids: _R.scene.children.length,
      shadow: _R.renderer.shadowMap.enabled ? (window.__shadowSize || 0) : 0,
      ua: (navigator.userAgent || '').slice(0, 140),
      screen: (screen.width || 0) + 'x' + (screen.height || 0),
      inner: window.innerWidth + 'x' + window.innerHeight,
      gpu: _getGpuName(),
      soft: /swiftshader|llvmpipe|softwarerasterizer|software|basic render|mesa offscreen/i.test(_getGpuName()),
      touch: navigator.maxTouchPoints || 0,
      platform: (navigator.platform || '') + '|' +
        ((navigator.userAgentData && navigator.userAgentData.mobile) ? 'mobile' : 'nomobile'),
      devMem: navigator.deviceMemory || 0,
      cores: navigator.hardwareConcurrency || 0,
      heapLimitMB: (performance && performance.memory && performance.memory.jsHeapSizeLimit)
        ? Math.round(performance.memory.jsHeapSizeLimit / 1048576) : 0,
    };
  } catch(e){ return { err: String((e && e.message) || e) }; }
}

/* ============================================================
   全局暴露（diagnostics.js 会通过 window 直接调）
   ============================================================ */
if (typeof window !== 'undefined'){
  window.__getMemoryLimit = () => _memState.limitMB;
  window.__isStopGenerate = () => !!window.__memStopGenerate;
  window.__rendererInfo   = () => _rcNow().renderer.info;
  window.__gpuInfo        = getGPUInfo;
}

/* ============================================================
   诊断事件监听
   ============================================================ */
/* ★ Worker 兼容：Worker 里没有 window / document，诊断监听全部跳过 */
if (typeof window !== 'undefined' && typeof document !== 'undefined'){
  window.addEventListener('resize', () => {
    try {
      const g = getGPUInfo();
      _reportNowLazy('resize', {
        buf: g.buf, fbMB: g.fbMB, resizes: g.resizes, pr: g.pr,
      });
    } catch(e){}
  });

  window.addEventListener('error', (e) => {
    try {
      _reportNowLazy('JS_ERROR', {
        msg: String(e.message || '').slice(0, 160),
        at: (e.filename || '') + ':' + (e.lineno || 0),
      });
    } catch(err){}
  }, true);

  window.addEventListener('unhandledrejection', (e) => {
    try {
      const r = e.reason;
      _reportNowLazy('PROMISE', {
        msg: String((r && (r.stack || r.message)) || r).slice(0, 160),
      });
    } catch(err){}
  });

  window.addEventListener('pagehide', () => {
    try { _reportNowLazy('pagehide'); } catch(e){}
  });

  document.addEventListener('visibilitychange', () => {
    try {
      if (document.hidden) _reportNowLazy('hidden');
      else _reportNowLazy('visible');
    } catch(e){}
  });
}

/* ============================================================
   内存滑条（目前隐藏）
   ============================================================ */
let _memorySliderInitialized = false;
function initMemorySlider(){
  if (_memorySliderInitialized) return;
  _memorySliderInitialized = true;
  const wrap = document.getElementById('setMemoryWrap');
  if (wrap) wrap.style.display = 'none';
}

/* ★ reportNow 来自 diagnostics.js，而 diagnostics 又依赖 terrain/world → 和本文件
   构成循环依赖。改为惰性取用，模块初始化阶段不再触达。 */
let _reportNow = null;
function _reportNowLazy(...args){
  if (!_reportNow){
    try { _reportNow = globalThis.__reportNow__ || null; } catch(e){}
    if (!_reportNow) return;
  }
  try { _reportNow(...args); } catch(e){}
}

/* =================================================================
   re-export
   ================================================================= */
export {
  CS,
  SEA_LEVEL,
  CHH,
  Y_MIN,
  COL_H,
  MIN_WORLD_HEIGHT,
  MAX_WORLD_HEIGHT_NORMAL,
  MAX_WORLD_HEIGHT_REALISTIC,
  HEIGHT_LIMITS,
  computeYMin,
  snowLine,
  cloudHeight,
  toStoreY,
  toWorldY,
  idx,
  terrainCeiling,
  getHeightLimit,
  setHeightLimit,
  removeHeightLimit,
  clampWorldHeight,
  getDefaultWorldHeight,
  setWorldHeight,
  loadSavedWorldHeight,
  saveWorldHeight,
  BIOME,
  PLAYER_W,
  PLAYER_H,
  STACK_MAX,
  INV_SIZE,
  ATLAS_TILE,
  ATLAS_COLS,
  ATLAS_SIZE,
  TEX_INNER,
  TEX_PAD,
  WORLD_TYPE,
  getActiveDimension,
  setActiveDimensionGlobal,
  setActiveDimensionId,
  isValidDimensionId,
  on,
  off,
  once,
  emit,
  emitCancellable,
  listenerCount,
  listEvents,
  clearAllEvents,
  defineHook,
  getHook,
  listHooks,
  isHooked,
  applyMemoryLimit,
  getMemoryState,
  getGPUInfo,
  initMemorySlider
};
