/* ============================================================
   diagnostics.js —— 把运行状态持续写到服务器，崩溃后还能看
   ------------------------------------------------------------
   为什么需要它：
   手机上控制台复制不出来；Tab 被系统 OOM 杀掉时 window.onerror
   根本不会触发，日志里什么都没有。
   所以这里改成**每 2 秒主动往服务器写一行状态**，并记录峰值 ——
   就算进程被杀，最后一行也已经在磁盘上了。

   写入：POST /api/diag/<saveId> → saves/<saveId>/logs/diag.txt（追加）

   这些时刻会立刻补一条：
     · WebGL 上下文丢失 / 恢复（显存出问题的第一征兆）
     · window error / unhandledrejection
     · 页面隐藏 / 关闭
   ============================================================ */

import { getChunkStats, getEditCount } from '../world/terrain.js';
import { getActiveFluidCount } from './../world/world-core.js';
import { getAnimalCount } from './../entities/entities-core.js';
import { getLeafCount } from './../world/world-registry.js';
import { getDropCount } from './../items/items-logic.js';
import { getFPS, getPhase } from './runtime.js';

/* 改代码时请手动改这个串，方便确认浏览器加载的是哪一版 */
export const BUILD = 'V0.0.0';

const REPORT_MS = 2000;
const MAX_LINE = 700;

let saveId = null;
let timer = null;
let session = Date.now();
let startedAt = Date.now();
let inFlight = 0;
let sent = 0;
let dropped = 0;
const MAX_INFLIGHT = 3;
let ctxLost = false;

const peak = {
  chunkMB: 0, geometries: 0, textures: 0, programs: 0,
  heapMB: 0, leaves: 0, animals: 0, fluid: 0, draws: 0, triangles: 0,
  fbMB: 0, resizes: 0, kids: 0,
};

const mb = v => Math.round((v || 0) * 10) / 10;

/** 收集一份状态快照 */
let _fpsPrevT = NaN;
let _fpsPrevFrames = 0;

export function snapshot(extra){
  const s = {
    build: BUILD,
    session,
    up: Math.round((Date.now() - startedAt) / 1000),
    fps: getFPS(),
    phase: getPhase(),
  };

  /* ★ fps 修正：getFPS() 读的是 crash-guard 的内部变量，而 crash-guard
     的 initCrashGuard() 从来没有被调用过 —— 所以它恒为 0，
     历史 diag 日志里每一行的 fps 都是 0（等于这个字段一直是废的）。
     这里改用游戏主循环的帧计数器差值自己算。 */
  try {
    const nowMs = performance.now();
    const fc = (typeof window !== 'undefined' && window.__frameCount) ? window.__frameCount : 0;
    if (s.__prevT !== undefined){ /* noop */ }
    if (typeof _fpsPrevT === 'number' && nowMs > _fpsPrevT){
      const dt = (nowMs - _fpsPrevT) / 1000;
      const df = fc - _fpsPrevFrames;
      if (dt >= 0.2 && df >= 0) s.fps = Math.round(df / dt);
    }
    _fpsPrevT = nowMs;
    _fpsPrevFrames = fc;
  } catch(e){}

  try {
    const cs = getChunkStats();
    s.chunkMB   = mb(cs.residentMB);
    s.budgetMB  = Math.round(cs.budgetMB);
    s.chunks    = cs.active;
    s.meshMB    = mb(cs.meshMB);
    s.evicted   = cs.evicted;
    if (s.chunkMB > peak.chunkMB) peak.chunkMB = s.chunkMB;
  } catch(e){ s.chunkErr = String((e && e.message) || e); }

  try { s.edits   = getEditCount(); } catch(e){}
  try { s.fluid   = getActiveFluidCount(); if (s.fluid > peak.fluid) peak.fluid = s.fluid; } catch(e){}
  try { s.animals = getAnimalCount();      if (s.animals > peak.animals) peak.animals = s.animals; } catch(e){}
  try { s.leaves  = getLeafCount();        if (s.leaves > peak.leaves) peak.leaves = s.leaves; } catch(e){}
  try { s.drops   = getDropCount(); } catch(e){}

  if (typeof performance !== 'undefined' && performance.memory){
    s.heapMB = mb(performance.memory.usedJSHeapSize / 1048576);
    if (s.heapMB > peak.heapMB) peak.heapMB = s.heapMB;
  }

  /* 帧存活：frames 不涨=主线程卡死；tick 间隔变大=越来越慢；
     tick 突然停住而服务器时间戳也停=进程被杀。 */
  try {
    if (typeof window !== 'undefined'){
      s.frames = window.__frameCount || 0;
      s.maxGapMs = window.__frameMaxGap || 0;
    }
  } catch(e){}

  /* ★ 图形侧内存：帧缓冲/上下文/resize 次数。
     这块 JS 侧看不到，却是"整个浏览器被系统杀掉"的头号嫌疑。 */
  try {
    const g = (typeof window !== 'undefined' && window.__gpuInfo)
      ? window.__gpuInfo() : null;
    if (g){
      s.pr     = g.pr;
      s.buf    = g.buf;
      s.fbMB   = g.fbMB;
      s.fbMBx3 = g.fbMBx3;
      s.resizes = g.resizes;
      s.kids   = g.sceneKids;
      s.maxTex = g.maxTex;
      s.lost   = g.lost;
      s.scale  = g.scale;
      s.dpr    = g.dpr;
      s.ua     = g.ua;
      s.screen = g.screen;
      s.inner  = g.inner;
      s.gpu    = g.gpu;
      s.soft   = g.soft;
      s.touch  = g.touch;
      s.platform = g.platform;
      s.devMem = g.devMem;
      s.cores  = g.cores;
      s.heapLimitMB = g.heapLimitMB;
      if (g.fbMB > (peak.fbMB || 0)) peak.fbMB = g.fbMB;
      if (g.resizes > (peak.resizes || 0)) peak.resizes = g.resizes;
      if (g.sceneKids > (peak.kids || 0)) peak.kids = g.sceneKids;
    }
  } catch(e){ s.gpuErr = String((e && e.message) || e); }

  /* three 渲染器统计：几何体/纹理/程序数一直涨 = 显存泄漏 */
  try {
    const info = (typeof window !== 'undefined' && window.__rendererInfo)
      ? window.__rendererInfo() : null;
    if (info){
      s.geo   = info.memory.geometries;
      s.tex   = info.memory.textures;
      s.prog  = info.programs ? info.programs.length : 0;
      s.draws = info.render.calls;
      s.tris  = info.render.triangles;
      if (s.geo   > peak.geometries) peak.geometries = s.geo;
      if (s.tex   > peak.textures)   peak.textures   = s.tex;
      if (s.prog  > peak.programs)   peak.programs   = s.prog;
      if (s.draws > peak.draws)      peak.draws      = s.draws;
      if (s.tris  > peak.triangles)  peak.triangles  = s.tris;
    }
  } catch(e){}

  if (extra) for (const k in extra) s[k] = extra[k];

  s.peak = {
    chunkMB: Math.round(peak.chunkMB),
    heapMB:  Math.round(peak.heapMB),
    fbMB:    peak.fbMB || 0,
    resizes: peak.resizes || 0,
    kids:    peak.kids || 0,
    geo:   peak.geometries,
    tex:   peak.textures,
    prog:  peak.programs,
    draws: peak.draws,
    fluid: peak.fluid,
    leaves: peak.leaves,
  };
  return s;
}

function send(kind, extra){
  if (!saveId) return;
  /* 允许少量并发：只让一个请求在飞的话，CTX_LOST / JS_ERROR 这类
     关键时刻的上报会被正在进行的 tick 吞掉，那就白做了。
     但仍然限流，避免把主线程压住。 */
  if (inFlight >= MAX_INFLIGHT){ dropped++; return; }
  inFlight++;
  let line;
  try {
    const s = snapshot(extra);
    /* k 放最前面，并且把超长字符串先截短 ——
       否则最后那步整体截断会把"这是哪条事件"给切掉。 */
    const payload = { k: kind };
    for (const key in s){
      let v = s[key];
      if (typeof v === 'string' && v.length > 180) v = v.slice(0, 180) + '\u2026';
      payload[key] = v;
    }
    line = JSON.stringify(payload);
    if (line.length > MAX_LINE) line = line.slice(0, MAX_LINE) + '\u2026}';
  } catch(e){
    line = JSON.stringify({ build: BUILD, k: kind, err: 'snapshot failed: ' + ((e && e.message) || e) });
  }

  fetch('/api/diag/' + encodeURIComponent(saveId), {
    method: 'POST',
    body: line,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  }).then(() => { sent++; }).catch(() => {}).finally(() => { inFlight--; });
}

/* ============================================================
   对外接口
   ============================================================ */

export function startDiagnostics(id, canvas){
  saveId = id || null;
  session = Date.now();
  startedAt = session;
  sent = 0;
  ctxLost = false;

  if (timer) clearInterval(timer);
  if (!saveId) return;

  send('start');
  timer = setInterval(() => send('tick'), REPORT_MS);

  installWebGLWatch(canvas);
}

export function stopDiagnostics(reason){
  if (timer){ clearInterval(timer); timer = null; }
  if (saveId) send('stop', { why: reason || '' });
  saveId = null;
}

export function reportNow(kind, extra){ send(kind || 'event', extra); }

/** WebGL 上下文丢失 = 显存出问题的典型信号 */
export function installWebGLWatch(canvas){
  if (!canvas || !canvas.addEventListener) return;
  canvas.addEventListener('webglcontextlost', (e) => {
    ctxLost = true;
    try { e.preventDefault(); } catch(err){}
    send('CTX_LOST', { fatal: true });
  }, false);
  canvas.addEventListener('webglcontextrestored', () => {
    send('CTX_RESTORED');
  }, false);
}

export function hasContextLoss(){ return ctxLost; }
export function getSentCount(){ return sent; }
export function getDroppedCount(){ return dropped; }

/* ★ 供 engine-core.js 惰性取用（避免 engine-core ↔ diagnostics 循环依赖） */
if (typeof window !== 'undefined') window.__reportNow__ = reportNow;
