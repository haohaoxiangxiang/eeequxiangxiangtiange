/* ============================================================
   main.js —— 入口：UI 装配、主循环、挖掘/放置、Mod 宿主
   ------------------------------------------------------------
   ★ 已完全清理自研引擎残留，回归纯 Three.js
   ============================================================ */

import * as THREE from 'three';

import {
  IS_TOUCH, WORLD_TYPE, CS, ATLAS_SIZE,
  clampWorldHeight, getHeightLimit,
  loadSavedWorldHeight, saveWorldHeight,
  setHeightLimit,
} from './core/engine-core.js';
import { cycleViewMode, VIEW_NAMES } from './player/view-mode.js';
import {
  initPlayerAvatar, updatePlayerAvatar, renderCharPreview,
} from './player/avatar.js';
import { clamp } from './core/runtime.js';

import { BLOCKS, B, STAIR_VARIANTS } from './world/blocks.js';
import { getGenerator, getDeclaredWorldType } from './world/world-meta.js';
import {
  getBlockWorld, setBlockWorld, heightAt, biomeAt,
  getBlockData, setBlockData, removeBlockData,
  getChunkDecorated, setFluidLevel, setFluidSource, getFluidSource,
  getChunkStats, refreshWorkerBlockTables, refreshWorkerBiomes,
  getDensityField, worldTemperatureAt,
  setSeasonPhase, getSeasonPhase, getWorldConfig,
} from './world/terrain.js';
import { getSaveQueueStats } from './world/world-core.js';
import { updateChunks, rebuildAllChunks, buildMesh,
         getEffectiveRenderDist,
         setCrossCullEnabled, isCrossCullEnabled,
         setCrossCullDistance, getCrossCullDistance,
         setMeshWorkerEnabled, setWaterRenderMode } from './world/chunk.js';
import { raycastVoxel } from './world/world-meta.js';

import { renderer, camera, scene, tickShadow, getDynPatchStatus } from './render/render-core.js';
import { updateSky, skyMesh, renderCloudPass } from './render/sky.js';
import { renderFrame } from './render/bloom.js';

import { player, updatePlayer, setOnDamage, spawn, triggerDamageUI }
  from './player/player-core.js';
import {
  input, initMouseLock, initTouchGestures, initJoystick, initTouchButtons,
  consumeMouseState, consumeFlyToggle,
} from './player/player-core.js';
import { updateStatusEffects, clearStatusEffects } from './player/status-effects.js';
import {
  inventory, takeFromSlot, notifyInventory, addItem,
} from './items/items-core.js';
import { spawnDrop, updateDrops, drops, getGlowDropSources } from './items/items-logic.js';
import { updateBow, updateArrows, clearArrows, getGlowArrowSources } from './items/bow.js';
import {
  updateStaff, updateStoneProjectiles, clearStoneProjectiles,
} from './items/staff.js';
import {
  updateMagicBean, updateBeanProjectiles, clearBeanProjectiles, getBeanLightSources,
} from './items/magic-bean.js';
import { updateTempBlocks } from './world/temp-blocks.js';
import {
  updateDynamicLights, isLightSourceBlock, isDynamicLightEnabled,
  notifyFrameTime, resetDynamicLights, getDynamicLightStatus,
} from './render/dynamic-light.js';
import { updateHighlights, clearHighlights } from './entities/highlight.js';
import { trySpawnLeaves, updateLeaves } from './world/world-registry.js';
import { updateFluid, createSource } from './world/world-core.js';
import {
  updateSplash, spawnSplash, spawnLavaSpark, spawnBubble,
} from './world/world-core.js';
import {
  curSlot, setCurSlot, updateHearts, updateBreath, toast, toggleInv,
  isInvOpen, isSettingsOpen, isPauseOpen, initUI,
  openFurnace, isFurnaceOpen, renderFurnace, tryEat,
  openChest, isChestOpen, closeChest, isChestOpenAt, getOpenChestPos,
  updateHunger, updateBlockInfo, describeToolRequirement, updateArmor,
} from './ui/ui.js';
import { updateChestVisuals } from './world/chest-visuals.js';
import { updateFurnaces, removeFurnace } from './items/items-logic.js';
import { removeChest, getChestItems, setChestItems } from './items/items-core.js';
import {
  updateAnimals, getAnimalAt, damageAnimal, setEntityLoot,
  captureFish, setSimDistance, spawnFishAt,
} from './entities/entities-core.js';
import {
  initAudio, playSFX, startMusic, setListenerSource, updateMusicScheduler,
} from './audio/audio.js';
import { updateCaveAmbience } from './audio/ambience.js';
import { trySleep } from './player/bed.js';
import { updateHostileMobs, tryRepairGolem } from './entities/hostile.js';
import {
  initLostCityRuntime, updateLostCity, resetLostCityRuntime,
} from './world/lost-city-runtime.js';

import {
  tickWeather, tickWeatherGround, updateWeatherRender,
  getSnowFactor, setWeatherTempFn,
  initWeather, setWeather, getWeatherState, WEATHER,
} from './world/weather.js';
/* 调试接口 __whySnow() 要用到 TEMP_THRESHOLDS / getWeatherIntensity */
import * as __weatherMod from './world/weather.js';

import { initMagic, updateMagic, pullLever, pressButton, toggleDoor } from './world/magic.js';
import { initTouchControls } from './ui/touch-controls.js';
import { initSaplings, updateSaplings } from './world/saplings.js';
import {
  updateBlockTicks, scheduleBlockTick, cancelBlockTick,
  cancelBlockTicksAt, clearAllBlockTicks, getPendingBlockTickCount,
} from './world/block-ticks.js';
import { initMenu } from './ui/menu.js';
import { updateChunkDebug } from './render/chunk-debug.js';
import { importModpackFile } from './ui/ui-panel.js';
import { log } from './core/runtime.js';
import {
  startDiagnostics, stopDiagnostics, reportNow, BUILD,
} from './core/diagnostics.js';
import { toggleFullscreen } from './ui/ui-panel.js';

import {
  applyMemoryLimit, initMemorySlider, getMemoryState, getGPUInfo,
} from './core/engine-core.js';
import {
  initSettings, getRenderDist, getSimDist,
} from './ui/settings.js';
import {
  initWorldSave, setWorldHeightInput,
  startNewWorld, loadExistingWorld,
  persistCurrentWorld,
  switchDimension,
  getCurrentSave,
} from './save/save-core.js';

/* ★ 群系标签 */
import { getBiome } from './world/world-core.js';

/* Mod 宿主 */
import { installHost, on, emit, emitCancellable, isHostInstalled } from './core/mod-host.js';
import {
  enableRuntimeRegistration,
  onBlockRegistered,
  registerBlock as registerBlockRaw,
} from './world/world-registry.js';
import {
  registerTexRuntime,
  getAtlasUsage,
  onAtlasChanged,
} from './world/textures.js';
import {
  addRuntimeRecipe,
  listRecipes,
} from './items/items-logic.js';
import {
  addSmeltRecipe,
  removeSmeltRecipe,
  setFuelSeconds,
  listSmeltRecipes,
} from './items/items-logic.js';
import { getModStorage } from './save/save-core.js';

/* 维度系统 */
import {
  registerDimension,
  getDimension,
  hasDimension,
  listDimensions,
  getDimensionCount,
  getActiveDimensionId,
} from './world/world-registry.js';

/* 缺失 mod 警告 */
import { getLastLoadResult } from './save/save-core.js';

/* ============================================================
   ★ 性能探针 & 复用对象（防 GC）
   ============================================================ */
window.__prof = { sky: 0, player: 0, fluid: 0, chunks: 0, drops: 0, hud: 0, meshes: 0 };

/* ★ 地震镜头震动 */
let quakeT = 0, quakeDur = 0.55, quakeAmp = 0.16;

const _tmpCamDir = new THREE.Vector3();

/* ★ 触点模式：屏幕落点 → 世界射线（设置里「触屏瞄准」= 触点时使用） */
const _screenRaycaster = new THREE.Raycaster();
const _screenNdc = new THREE.Vector2();
function screenRay(pt){
  const rect = renderer.domElement.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  _screenNdc.set(
    ((pt.x - rect.left) / rect.width) * 2 - 1,
    -((pt.y - rect.top) / rect.height) * 2 + 1
  );
  _screenRaycaster.setFromCamera(_screenNdc, camera);
  return _screenRaycaster.ray;
}

const _mineHitInfo = {};
const _useHitInfo = {};

/* ============================================================
   DOM
   ============================================================ */
const menuEl = document.getElementById('menu');
const uiEl   = document.getElementById('ui');
const loadingEl      = document.getElementById('loading');
const loadingFillEl  = document.getElementById('loadingFill');
const loadingTextEl  = document.getElementById('loadingText');
const loadingStageEl = document.getElementById('loadingStage');

/* ============================================================
   Atlas 设备兼容性检测
   ============================================================ */
function checkAtlasCompatibility(){
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2')
            || c.getContext('webgl')
            || c.getContext('experimental-webgl');
    if (!gl){
      console.warn('[atlas] 无法获取 WebGL 上下文，跳过尺寸检测');
      return;
    }

    const max = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    try {
      const lose = gl.getExtension('WEBGL_lose_context');
      if (lose) lose.loseContext();
    } catch(e){}

    console.log(
      `[atlas] 设备上限 MAX_TEXTURE_SIZE=${max}, ` +
      `本项目 atlas=${ATLAS_SIZE}`
    );

    if (ATLAS_SIZE > max){
      const msg =
        `纹理图集尺寸超出设备能力上限：\n` +
        `  配置尺寸：${ATLAS_SIZE}（${ATLAS_SIZE / 32}×${ATLAS_SIZE / 32} 格）\n` +
        `  设备上限：${max}\n\n` +
        `这通常是因为已启用的 mod 太多。\n` +
        `请减少 mod 数量，或在世界设置里禁用部分 mod 后重试。`;
      console.error('[atlas]', msg);
      alert(msg);
      throw new Error('atlas texture size exceeds device limit');
    }
  } catch(e){
    if (e && e.message && e.message.includes('exceeds')){
      throw e;
    }
    console.warn('[atlas] 检测过程出错:', e);
  }
}

/* ============================================================
   创建世界对话框
   ============================================================ */
const createDialog = document.getElementById('createDialog');
const typeGrid     = document.getElementById('typeGrid');
let selectedType = WORLD_TYPE.VANILLA;

let worldHeightInput = 400;
const heightInput   = document.getElementById('worldHeight');
const heightValEl   = document.getElementById('heightVal');
const terrainValEl  = document.getElementById('terrainVal');
const heightTipEl   = document.getElementById('heightTip');

function updateHeightLabels(){
  const v = clampWorldHeight(parseInt(heightInput.value, 10), selectedType);
  worldHeightInput = v;
  setWorldHeightInput(v);
  heightValEl.textContent = String(v);
  terrainValEl.textContent = String(Math.max(36, v - 80));
  const lim = getHeightLimit(selectedType);
  heightTipEl.textContent = v >= lim.max
    ? '已是该类型上限，最吃性能'
    : (v <= 100 ? '世界较浅，适合流畅优先' : '上限越高世界越深，越吃性能');
}

function refreshHeightUI(){
  if (!typeGrid.querySelector(`[data-type="${selectedType}"]`)){
    const first = typeGrid.querySelector('.type-card:not(.disabled)')
               || typeGrid.querySelector('.type-card');
    if (first && !first.classList.contains('disabled')){
      typeGrid.querySelectorAll('.type-card').forEach(c => c.classList.remove('active'));
      first.classList.add('active');
      selectedType = first.dataset.type;
    }
  }
  const lim = getHeightLimit(selectedType);
  heightInput.max = String(lim.max);
  heightInput.min = '80';
  heightInput.value = String(clampWorldHeight(loadSavedWorldHeight(selectedType), selectedType));
  updateHeightLabels();
}
window.__refreshHeightUI = refreshHeightUI;

/* ============================================================
   ★ 世界类型：折叠成一行 + 弹窗选择 + 每类型自己的选项
   ------------------------------------------------------------
   原来的三张大卡片占掉了创建对话框近一半高度，而且所有类型共用同一个
   "最高区块"滑条 —— 超平坦根本用不到它。现在：
     · 创建界面只留一行摘要按钮，点开才弹完整列表
     · 每个类型的可调项由它自己在 generator 配置里声明（options），
       超平坦声明空数组 → 高度滑条直接隐藏，对话框更矮
     · mod 通过 manifest 的 worldTypes 或运行时 registerGenerator 加进来的
       类型会出现在同一个列表里（见 ui/menu.js）
   ============================================================ */
const typeDlg      = document.getElementById('worldTypeDialog');
const typePickBtn  = document.getElementById('worldTypeBtn');
const typePickIcon = document.getElementById('worldTypeIcon');
const typePickName = document.getElementById('worldTypeName');
const typePickDesc = document.getElementById('worldTypeDesc');
const typeOptsEl   = document.getElementById('typeOptions');
const worldHeightField = document.getElementById('worldHeightField');

/* 每个类型自己选项的当前值：type -> { key: value } */
const _typeOptionValues = Object.create(null);

/* ★ 兜底用的选项 = 【普通模式】的选项。
   mod 不改、不声明 options，就自动跟普通模式一致；想改成别的就在自己
   的 worldTypes / registerGenerator 里写 options；写空数组 [] 表示
   这个模式没有可调项（超平坦就是这样把高度滑条去掉的）。 */
function fallbackOptions(){
  const v = getGenerator(WORLD_TYPE.VANILLA);
  if (v && Array.isArray(v.options)) return v.options;
  return [{ key: 'height', kind: 'height' }];
}

/* 取某个世界类型的选项：运行时注册 > mod 声明 > 普通模式兜底 */
function optionsOf(type){
  const g = getGenerator(type);
  if (g){
    if (g.options === undefined || g.options === null) return fallbackOptions();
    return Array.isArray(g.options) ? g.options : fallbackOptions();
  }
  const d = getDeclaredWorldType(type);
  if (d){
    if (d.options === undefined || d.options === null) return fallbackOptions();
    return Array.isArray(d.options) ? d.options : fallbackOptions();
  }
  return fallbackOptions();
}

function updateTypeSummary(){
  const g = getGenerator(selectedType) || getDeclaredWorldType(selectedType);
  let label = g && g.label, icon = g && g.icon, desc = g && g.desc;

  /* 注册表里没有（比如还没加载的 mod 类型）→ 用列表里那一行的文案兜底 */
  if (!label){
    const card = typeGrid.querySelector(`[data-type="${selectedType}"]`);
    if (card){
      label = (card.querySelector('.type-pick-name, .type-name') || {}).textContent || selectedType;
      icon  = (card.querySelector('.type-icon') || {}).textContent || '■';
      desc  = (card.querySelector('.type-desc') || {}).textContent || '';
    } else {
      label = selectedType; icon = '■'; desc = '';
    }
  }
  if (typePickIcon) typePickIcon.textContent = icon || '■';
  if (typePickName) typePickName.textContent = label || selectedType;
  if (typePickDesc) typePickDesc.textContent = desc || '';
}

/* 渲染当前类型的选项；height 那一项映射到已有的高度滑条上 */
function renderTypeOptions(){
  const opts = optionsOf(selectedType);
  const hasHeight = opts.some(o => o && o.kind === 'height');

  if (worldHeightField) worldHeightField.style.display = hasHeight ? '' : 'none';
  if (heightTipEl)      heightTipEl.style.display      = hasHeight ? '' : 'none';

  if (!typeOptsEl) return;
  typeOptsEl.innerHTML = '';

  /* 记住旧值 → 换类型不丢用户输入 */
  for (const o of opts){
    if (!o || o.kind === 'height' || !o.key) continue;
    const store = _typeOptionValues[selectedType] || (_typeOptionValues[selectedType] = {});
    if (store[o.key] === undefined) store[o.key] = (o.def !== undefined ? o.def : '');
    const val = store[o.key];

    const row = document.createElement('div');
    row.className = 'type-opt';

    if (o.kind === 'toggle'){
      row.innerHTML = `<label class="type-opt-toggle"><input type="checkbox"><span></span></label>`;
      const cb = row.querySelector('input');
      row.querySelector('span').textContent = o.label || o.key;
      cb.checked = !!val;
      cb.addEventListener('change', () => { store[o.key] = cb.checked; });
    } else if (o.kind === 'range'){
      const min = (o.min ?? 0), max = (o.max ?? 100), step = (o.step ?? 1);
      row.innerHTML = `<span><span class="type-opt-label"></span> <b class="type-opt-val" style="color:#9ec8ff"></b></span>`
                    + `<input type="range" min="${min}" max="${max}" step="${step}">`;
      const rng = row.querySelector('input');
      const labEl = row.querySelector('.type-opt-label');
      const valEl = row.querySelector('.type-opt-val');
      labEl.textContent = o.label || o.key;
      rng.value = String(val);
      valEl.textContent = String(val);
      rng.addEventListener('input', () => {
        store[o.key] = Number(rng.value);
        valEl.textContent = rng.value;
      });
    } else {
      row.innerHTML = `<span></span><input type="text">`;
      row.querySelector('span').textContent = o.label || o.key;
      const inp = row.querySelector('input');
      inp.value = String(val);
      inp.addEventListener('input', () => { store[o.key] = inp.value; });
    }
    typeOptsEl.appendChild(row);
  }
}

function refreshTypeUI(){
  updateTypeSummary();
  renderTypeOptions();
  refreshHeightUI();
}

if (typePickBtn && typeDlg){
  typePickBtn.addEventListener('click', () => typeDlg.classList.add('show'));
}
const btnTypeClose = document.getElementById('btnTypeClose');
if (btnTypeClose && typeDlg){
  btnTypeClose.addEventListener('click', () => typeDlg.classList.remove('show'));
}
/* 列表被重建（mod 运行时注册了生成器）→ 刷新摘要和选项 */
window.addEventListener('worldTypeListChanged', () => refreshTypeUI());

/* 初始渲染一次：menu.js 构建列表的时机可能早于上面的监听器 */
if (typePickBtn) refreshTypeUI();
if (typeDlg) typeDlg.classList.remove('show');

/* 供 menu.js 打开创建对话框时刷新（类型列表/选项可能已变） */
window.__refreshTypeUI = refreshTypeUI;
window.__getCreateDialogOptions = () => {
  const out = {};
  for (const t of Object.keys(_typeOptionValues)){
    out[t] = { ..._typeOptionValues[t] };
  }
  return out;
};

heightInput.addEventListener('input', updateHeightLabels);
heightInput.addEventListener('change', () => {
  saveWorldHeight(selectedType, worldHeightInput);
  updateHeightLabels();
});

typeGrid.addEventListener('click', (e) => {
  const card = e.target.closest('.type-card');
  if (!card) return;

  /* mod 声明的类型但宿主 API 版本不够 → 不让选，提示原因 */
  if (card.classList.contains('disabled')){
    const why = card.title || '当前不可用';
    if (typeof toast === 'function') toast(why); else console.warn('[create] ' + why);
    return;
  }

  typeGrid.querySelectorAll('.type-card').forEach(c => c.classList.remove('active'));
  card.classList.add('active');
  selectedType = card.dataset.type;

  /* ★ mod 提供的类型 → 自动把这个 mod（及其依赖）勾进"选择 Mod"，
     否则建出来的世界类型是它、但生成器没人注册。 */
  if (card.dataset.mod && typeof window.__addCreateDialogMod === 'function'){
    window.__addCreateDialogMod(card.dataset.mod);
  }

  if (typeDlg) typeDlg.classList.remove('show');
  refreshTypeUI();
});

document.getElementById('btnCancel').addEventListener('click', () => {
  createDialog.classList.remove('show');
});

let creatingWorld = false;
document.getElementById('btnOk').addEventListener('click', async () => {
  if (creatingWorld) return;
  creatingWorld = true;
  const btnOk = document.getElementById('btnOk');
  const oldText = btnOk.textContent;
  btnOk.textContent = '创建中...';
  btnOk.disabled = true;

  const name = document.getElementById('worldName').value.trim() || '新的世界';
  const seed = document.getElementById('worldSeed').value.trim();
  saveWorldHeight(selectedType, worldHeightInput);
  createDialog.classList.remove('show');

  const ok = await startNewWorld(name, selectedType, seed);
  if (ok) enterGame();

  btnOk.textContent = oldText;
  btnOk.disabled = false;
  creatingWorld = false;
});

/* ============================================================
   菜单
   ============================================================ */
initMenu({
  onEnter: async (meta) => {
    try {
      await loadExistingWorld(meta);
    } catch(e){
      console.error('[save] load failed', e);
      toast('载入失败：' + (e.message || e));
      return;
    }
    enterGame();
  },
});

/* ============================================================
   预加载
   ============================================================ */
let loadingMode = false;
let loadingState = null;
let gameStarted = false;

/* ★ r187: 异步预编译着色器
   ------------------------------------------------------------
   以前进入世界的第一帧要现场编译 4 个方块材质 + 阴影/深度变体
   （PCFSoftShadowMap 还要多一套 depth program），手机上首帧常见
   100~300ms 的顿挫，低端机更夸张。compileAsync 走
   KHR_parallel_shader_compile，把编译摊到若干帧里、不阻塞主线程。
   浏览器没有这个扩展时 three 内部退化成同步编译并立即 resolve，
   行为等同于不调用，所以这里不需要额外判断能力位。
   只做一次：材质全局共享，编过一次后续新区块直接复用。 */
let _precompiled = false;
function precompileShaders(){
  if (_precompiled || !renderer || !scene || !camera) return;
  _precompiled = true;
  try {
    if (typeof renderer.compileAsync !== 'function') return;
    const p = renderer.compileAsync(scene, camera);
    if (p && typeof p.then === 'function'){
      p.then(() => { window.__precompileDone = true; })
       .catch(e => console.warn('[main] compileAsync 失败(不影响运行):', e && e.message));
    }
  } catch(e){
    console.warn('[main] compileAsync 抛错(不影响运行):', e && e.message);
  }
}

function enterGame(silent){
  /* 应用存档里记录的季节相位（老存档没这个字段就归零） */
  try {
    const _cs = getCurrentSave();
    const _sp = (_cs && typeof _cs.seasonPhase === 'number') ? _cs.seasonPhase : 0;
    setSeasonPhase(_sp);
    _seasonAccum = 0;
  } catch(e){}
  menuEl.style.display = 'none';
  if (!silent) loadingEl.classList.remove('hidden');
  if (!silent) {
    loadingTextEl.textContent = '正在生成世界...';
    if (loadingStageEl) loadingStageEl.textContent = '';
    loadingFillEl.style.width = '0%';
  }

  const pcx = Math.floor(player.pos.x / CS);
  const pcz = Math.floor(player.pos.z / CS);
  const R = getRenderDist();

  const queue = [];
  for (let dx = -R; dx <= R; dx++){
    for (let dz = -R; dz <= R; dz++){
      const d2 = dx * dx + dz * dz;
      if (d2 > R * R + R) continue;
      queue.push({ cx: pcx + dx, cz: pcz + dz, d: d2 });
    }
  }
  queue.sort((a, b) => a.d - b.d);

  loadingState = {
    silent: !!silent,
    phase: 'submit',
    queue,
    jobs: queue.slice(),
    total: queue.length,
    submitted: 0,
    ready: 0,
  };
  loadingMode = true;
  gameStarted = false;
}

function updateLoading(){
  if (!loadingState) return;

  if (loadingState.phase === 'submit'){
    let budget = 8;
    while (budget > 0 && loadingState.queue.length > 0){
      const job = loadingState.queue.shift();
      getChunkDecorated(job.cx, job.cz);
      loadingState.submitted++;
      budget--;
    }

    const p = loadingState.submitted / Math.max(1, loadingState.total);
    loadingFillEl.style.width = (p * 100).toFixed(1) + '%';

    if (loadingState.queue.length === 0){
      loadingState.phase = 'wait';
      loadingState.ready = 0;
      if (loadingStageEl) loadingStageEl.textContent = '等待 Worker 生成...';
    }
    return;
  }

  if (loadingState.phase === 'wait'){
    let budget = 4;
    let done = 0;

    for (const job of loadingState.jobs){
      if (job.done) { done++; continue; }
      const c = getChunkDecorated(job.cx, job.cz);

      if (!c || !c.ready) continue;

      if (!c.mesh || c.dirty) buildMesh(c);
      job.done = true;
      done++;

      if (--budget <= 0) break;
    }

    loadingState.ready = done;
    const p = done / Math.max(1, loadingState.total);
    loadingFillEl.style.width = (p * 100).toFixed(1) + '%';
    loadingTextEl.textContent = `生成中 ${done}/${loadingState.total}`;

    if (done >= loadingState.total){
      loadingMode = false;
      if (!loadingState || !loadingState.silent) loadingEl.classList.add('hidden');
      uiEl.style.display = 'block';
      gameStarted = true;
      /* 首批区块网格已经装进场景，这时候预编译最划算：
         材质从这里开始就是最终形态，不会因为场景里还没有
         使用该材质的对象而漏编。异步进行，不阻塞进世界。 */
      precompileShaders();
      try { startMusic(); } catch(e){}
      const cs = getCurrentSave();
      toast('已进入世界：' + (cs ? cs.name : ''));
      emit('world.enter', cs);

      setTimeout(() => {
        try {
          const r = getLastLoadResult();
          if (r.failed.length > 0){
            toast(`${r.failed.length} 个 Mod 加载失败，可在暂停菜单查看`);
            console.warn('[main] 加载失败的 mod:', r.failed);
          }
        } catch(e){}
        _showMissingModsWarning(cs).catch(() => {});
      }, 1800);
    }
    return;
  }
}

/* ============================================================
   检查"曾用过但现在未加载"的 mod
   ============================================================ */
async function _showMissingModsWarning(save){
  if (!save) return;
  const used = Array.isArray(save.usedMods) ? save.usedMods : [];
  const enabled = new Set(Array.isArray(save.plugins) ? save.plugins : []);
  const missing = used.filter(id => !enabled.has(id));
  if (missing.length === 0) return;

  let modNameMap = new Map();
  try {
    const r = await fetch('/api/mods');
    if (r.ok){
      const arr = await r.json();
      if (Array.isArray(arr)){
        for (const m of arr) modNameMap.set(m.id, m.name || m.id);
      }
    }
  } catch(e){}

  const names = missing.map(id => modNameMap.get(id) || id);

  try {
    const m = await import('./ui/mod-panel/index.js');
    if (typeof m.showMissingModsWarning === 'function'){
      m.showMissingModsWarning({
        worldName: save.name || '这个存档',
        missingIds: missing,
        missingNames: names,
      });
    }
  } catch(e){
    console.warn('[main] 显示缺失 mod 警告失败:', e);
    alert(
      `这个存档曾用过 ${missing.length} 个 mod，现在没有加载：\n` +
      names.join('、') + '\n\n' +
      `它们添加的方块会显示为"未知方块"。`
    );
  }
}

/* ============================================================
   初始化
   ============================================================ */
initMouseLock();
initTouchGestures();
initJoystick();
initTouchButtons();
initTouchControls();
initUI();

(function initAudioOnGesture(){
  const kick = () => {
    initAudio();
    window.removeEventListener('pointerdown', kick);
    window.removeEventListener('keydown', kick);
    window.removeEventListener('touchstart', kick);
  };
  window.addEventListener('pointerdown', kick, { once: false });
  window.addEventListener('keydown', kick, { once: false });
  window.addEventListener('touchstart', kick, { once: false });
})();

setOnDamage((health, maxHealth) => {
  updateHearts(health, maxHealth, player.mode);
  playSFX('hurt');
  const dEl = document.getElementById('damage');
  dEl.style.opacity = '0.85';
  setTimeout(() => dEl.style.opacity = '0', 120);
});

/* 全屏按钮（游戏内左上角已移除，保留主菜单 / 存档选择页） */
(function initFullscreen(){
  const btnMenu  = document.getElementById('btnFullscreenMenu');
  const btnMenu2 = document.getElementById('btnFullscreenMenu2');
  const onClick = () => toggleFullscreen();

  if (btnMenu)  btnMenu.addEventListener('click', onClick);
  if (btnMenu2) btnMenu2.addEventListener('click', onClick);
})();

function applyHint(){ /* 已移除 */ }

/* ============================================================
   调试面板（带防抖防卡顿版本）
   ============================================================ */
let _dbgTimer = 0;
let _dbgFrames = 0;
let _dbgFpsAccum = 0;
let _dbgLastRenderMs = 0;
let _smoothFrameMs = 16;
let _dbgChunksMs = 0;
let _dbgLogicMs = 0;
let _frameStart = 0;

/* ============================================================
   ★ 每帧网格安装预算（自适应，不写死设备）
   ------------------------------------------------------------
   以前：_smoothFrameMs < 16 ? 1 : 0 —— 完全不看机器能力，
         快机永远只装 1 个（加载慢），慢机永远 1 个或 0 个。
   现在：先从"最快帧"学习显示器的刷新间隔（60Hz≈16.7ms、
         90Hz≈11.1ms、120Hz≈8.3ms），再按实测平滑帧时间
         相对该目标的余量决定本帧能做几个。
         目标随设备/刷新率自动变化，不需要任何机型判断。
   ============================================================ */
let _frameTargetMs = 16.7;   /* 学习到的刷新间隔估计（初始按 60Hz） */

function _learnFrameTarget(frameMs){
  if (frameMs <= 0) return;
  if (frameMs < _frameTargetMs) _frameTargetMs = frameMs;  /* 立刻跟到更快 */
  else _frameTargetMs += 0.02;                             /* 缓慢回升 */
  if (_frameTargetMs < 6.9)  _frameTargetMs = 6.9;         /* 144Hz 上限 */
  if (_frameTargetMs > 34)   _frameTargetMs = 34;          /* 30Hz 下限 */
}

function _pickChunkBudget(){
  if (_smoothFrameMs > _frameTargetMs * 1.9)  return 1;  /* 明显卡顿：只做最少 */
  if (_smoothFrameMs > _frameTargetMs * 1.35) return 2;  /* 略有超支：收敛 */
  return 3;                                             /* 有余量：正常加载 */
}

/* 调试面板每 0.25s 刷一次 26 个字段。以前每次都 getElementById
   + 无条件写 textContent/classList —— 后者会让浏览器反复失效样式。
   这里缓存元素引用，并在值真的变了才写。 */
const _setTextEls  = new Map();
const _setTextPrev = new Map();

function _setText(id, val, cls){
  let el = _setTextEls.get(id);
  if (el === undefined){
    el = document.getElementById(id) || null;
    _setTextEls.set(id, el);
  }
  if (!el) return;

  const prev = _setTextPrev.get(id);
  if (prev !== undefined && prev.v === val && prev.c === cls) return;
  _setTextPrev.set(id, { v: val, c: cls });

  if (el.textContent !== val) el.textContent = val;
  if (cls !== undefined){
    el.classList.toggle('warn', cls === 'warn');
    el.classList.toggle('bad',  cls === 'bad');
  }
}

// ★ 防抖缓存
let _hudCacheBiome = '?';
let _hudLastX = 0;
let _hudLastZ = 0;

let _dbgPanelEl;   /* 缓存引用：每帧 getElementById 是白花钱 */
function updateDebugPanel(dt){
  if (_dbgPanelEl === undefined){
    _dbgPanelEl = document.getElementById('debugPanel') || null;
  }
  const panel = _dbgPanelEl;
  if (!panel || panel.style.display === 'none') return;

  _dbgFrames++;
  _dbgFpsAccum += dt;

  _dbgTimer += dt;
  if (_dbgTimer < 0.25) return;
  _dbgTimer = 0;

  const fps = _dbgFpsAccum > 0 ? Math.round(_dbgFrames / _dbgFpsAccum) : 0;
  _dbgFrames = 0;
  _dbgFpsAccum = 0;

  _setText('dbgFPS', String(fps), fps < 30 ? 'bad' : fps < 50 ? 'warn' : undefined);

  const mem = getMemoryState();
  if (performance && performance.memory){
    const used  = performance.memory.usedJSHeapSize / 1048576;
    const limit = mem.limitMB || 0;
    const ratio = limit > 0 ? used / limit : 0;
    _setText('dbgMem', used.toFixed(0) + ' MB',
      ratio > 0.85 ? 'bad' : ratio > 0.7 ? 'warn' : undefined);
    _setText('dbgLimit', limit ? limit + ' MB' : '-');
  } else {
    _setText('dbgMem', 'N/A');
    _setText('dbgLimit', '-');
  }

  _setText('dbgS', mem.profile ? (mem.profile.S + ' MB') : '-');

  _setText('dbgPos',
    `${player.pos.x.toFixed(1)} ${player.pos.y.toFixed(1)} ${player.pos.z.toFixed(1)}`);

  // ★ 移入的 HUD 信息（带距离防抖）
  const _hdx = player.pos.x - _hudLastX;
  const _hdz = player.pos.z - _hudLastZ;
  if (_hudCacheBiome === '?' || (_hdx * _hdx + _hdz * _hdz) > 64) {
    _hudLastX = player.pos.x;
    _hudLastZ = player.pos.z;
    try {
      const h = Math.floor(heightAt(player.pos.x, player.pos.z));
      const biomeId = biomeAt(player.pos.x, player.pos.z, h);
      const biomeCfg = getBiome(biomeId);
      _hudCacheBiome = biomeCfg ? biomeCfg.label : ('#' + biomeId);
    } catch(e) { _hudCacheBiome = '计算失败'; }
  }
  
  _setText('dbgMode', player.mode === 'survival' ? '生存' : '创造');
  _setText('dbgBiome', _hudCacheBiome);
  
  const statusStr = [
    player.flying ? '飞行' : '',
    player.inWater ? '游泳' : '',
    player.sprinting ? '疾跑' : '',
    player.sneaking ? '潜行' : ''
  ].filter(Boolean).join(' ') || '正常';
  _setText('dbgStatus', statusStr);

  const ccx = Math.floor(player.pos.x / CS);
  const ccz = Math.floor(player.pos.z / CS);
  _setText('dbgChunk', `${ccx}, ${ccz}`);

  try {
    const cs = getChunkStats();
    _setText('dbgActive', String(cs.active), cs.active > 500 ? 'warn' : undefined);
    _setText('dbgPrefetch', String(cs.prefetching));

    const r = cs.residentMB;
    _setText('dbgChunkMB',
      `${r.toFixed(0)} MB（方块${cs.blocksMB.toFixed(0)}+网格${cs.meshMB.toFixed(0)}）· 释放${cs.evicted}`,
      r > 400 ? 'bad' : r > 250 ? 'warn' : undefined);

    const effR = getEffectiveRenderDist();
    _setText('dbgViewR',
      effR ? `${effR}（设置 ${getRenderDist()}）` : `设置 ${getRenderDist()}`,
      effR && effR < getRenderDist() ? 'warn' : undefined);
  } catch(e){
    _setText('dbgActive', '-');
    _setText('dbgPrefetch', '-');
    _setText('dbgChunkMB', '-');
    _setText('dbgViewR', '-');
  }

  try {
    const ds = getSaveQueueStats();
    _setText('dbgDisk', `${ds.pending} + ${ds.saving}`,
      ds.pending > 10 ? 'warn' : undefined);
  } catch(e){
    _setText('dbgDisk', '-');
  }

  _setText('dbgRender',
    `渲${_dbgLastRenderMs.toFixed(1)} 块${_dbgChunksMs.toFixed(1)} 逻${_dbgLogicMs.toFixed(1)}`,
    _dbgLastRenderMs + _dbgChunksMs > 20 ? 'bad'
      : _dbgLastRenderMs + _dbgChunksMs > 12 ? 'warn' : undefined);

  _setText('dbgCrossCull',
    isCrossCullEnabled() ? `${getCrossCullDistance()} 格` : '关',
    !isCrossCullEnabled() ? 'warn' : undefined);

  _setText('dbgStop', window.__memStopGenerate ? '暂停生成' : '正常',
    window.__memStopGenerate ? 'warn' : undefined);

  _setText('dbgBuild', BUILD);

  /* ★ Phase 1.3 移动端友好：F3 面板显示 Mod 警告数 + 一键点开状态面板 */
  try {
    if (typeof window !== 'undefined' && !window.__dbgModWarnBound){
      window.__dbgModWarnBound = true;
      const el = document.getElementById('dbgModWarn');
      if (el){
        el.style.pointerEvents = 'auto';
        el.style.cursor = 'pointer';
        el.style.textDecoration = 'underline dotted';
        el.addEventListener('click', () => {
          import('./ui/mod-panel/index.js')
            .then(m => m.openModStatus())
            .catch(e => console.warn('[dbg] 打开 Mod 状态失败:', e));
        });
      }
    }
    const r = getLastLoadResult();
    const nw = (r && r.warnings && r.warnings.length) || 0;
    const nf = (r && r.failed && r.failed.length) || 0;
    const txt = nf > 0 ? `${nf} 失败`
              : nw > 0 ? `${nw} 警告`
              : '正常';
    _setText('dbgModWarn', txt, nf > 0 ? 'bad' : nw > 0 ? 'warn' : undefined);
  } catch(e){ _setText('dbgModWarn', '-'); }

  _setText('dbgCaveType', '已禁用');
  _setText('dbgCavePower', '-');
  _setText('dbgCaveInfo', '-');

  try {
    const g = getGPUInfo();
    _setText('dbgGpuName', g ? String(g.gpu).slice(0, 46) : '-',
      g && g.soft ? 'bad' : undefined);
  } catch(e){ _setText('dbgGpuName', '-'); }

  try {
    const info = renderer.info;
    const g = getGPUInfo();
    const fb = g ? `${g.fbMB}MB` : '?';
    const buf = g ? g.buf : '?';
    _setText('dbgGPU',
      `帧缓冲${fb}(${buf}) 几何${info.memory.geometries} 纹${info.memory.textures} 绘${info.render.calls}`,
      (g && g.fbMB > 80) ? 'bad' : (g && g.fbMB > 40) ? 'warn' : undefined);
  } catch(e){
    _setText('dbgGPU', '-');
  }

  /* ★ 动态光诊断（不需要开发者工具就能看到）
     这一行回答三个问题：
       ① 注入有没有跑到  →  C=编译次数  O=opaque锚点命中  F=雾补偿命中
       ② 光源数据有没有传 →  N=喂进uniform个数  s=手持/飞行光源  p=已放置光源
       ③ 整个数据通路通不通 → 点这一行切三态（见文件下方 click 处理）
     判断方法：
       · C=0        → onBeforeCompile 根本没被调用
       · O=0        → 调用了但锚点没命中（three 版本变了）
       · N=0        → 身边没光源（手持发光物 + 半径 10 内已放置光源都算）
       · N>0 但 r0=0 → setDynamicLightUniforms 没写进去（真 bug）
       · r0>0 且画面无变化 → 程序没重编（缓存键/needsUpdate 问题） */
  try {
    const st = getDynamicLightStatus();
    const ps = getDynPatchStatus();
    const u = st && st.uniforms;
    const slots = u && u.slots ? u.slots : [];
    const s0 = slots[0] || { range: 0, color: [0,0,0] };
    const s1 = slots[1] || { range: 0 };
    const fd = (st && st.feed) || { srcN: 0, placedN: 0, listN: 0, nearestN: 0, writeN: 0, err: '' };
    /* ★ 数字格式化：NaN / undefined 必须显示出来，不能都折成 0.0 ——
       之前 r0 一直显示 0.0，到底"没写进去"还是"写进去是 NaN"看不出来。 */
    const f1 = (v) => {
      const n = Number(v);
      if (Number.isFinite(n)) return n.toFixed(1);
      if (n === undefined) return 'undef';
      return String(n);
    };
    let txt = `${st ? st.mode : '?'}/${st ? st.path : '?'} ` +
              `C${ps.compiled} O${ps.octxHit} F${ps.fogHit} ` +
              `N${fd.listN} s${fd.srcN} p${fd.placedN} ` +
              `n${fd.nearestN} w${fd.writeN} ` +
              `r0=${f1(s0.range)} r1=${f1(s1.range)}`;
    if (u && u.probe > 0.5) txt += ' PROBE';
    if (window.__dynSelfTest) txt += ' SELFTEST';
    if (ps.lastErr) txt += ' ERR:' + ps.lastErr.slice(0, 40);
    if (fd.err) txt += ' E2:' + String(fd.err).slice(0, 40);
    let cls;
    if (ps.compiled === 0) cls = 'bad';
    else if (ps.octxHit === 0) cls = 'bad';
    /* N>0 却 r0=0：数据没写进 uniform，这才是真故障 */
    else if (fd.listN > 0 && !(s0.range > 0)) cls = 'bad';
    /* 身边没光源：正常，只是当前看不到光 */
    else if (!(s0.range > 0) && st && st.path === 'point') cls = 'warn';
    _setText('dbgDynLight', txt, cls);
  } catch(e){
    _setText('dbgDynLight', 'err:' + String(e && e.message || e).slice(0, 40), 'bad');
  }
}

/* ★ 点一下 HUD 的「动态光」行 = 循环切换三种诊断态。
   手机上没有开发者工具，这是唯一不依赖 F12 的开关。
     off      正常：不给任何额外光源
     PROBE    着色器把动态光强制成满强度白光（_dyn = vec3(1.0)）
              → 画面整体发白 = 注入确实在活着的程序里
     SELFTEST 在相机位置合成一个虚拟火把喂进 uniform
              → 地面/墙面出现一圈火把光晕 = 数据到 uniform 的整条路通
   三种态组合起来，能把这轮"代码全对但没效果"的悬案一次定死：
     PROBE 亮、SELFTEST 也亮  → 管线全通，问题在光源检测（s/p 一直是 0）
     PROBE 亮、SELFTEST 不亮  → uniform 写入或视空间变换有问题
     PROBE 不亮                → 注入不在当前 program 里（缓存键问题） */
if (typeof document !== 'undefined'){
  document.addEventListener('DOMContentLoaded', () => {
    const el = document.getElementById('dbgDynLight');
    if (!el) return;
    el.style.cursor = 'pointer';
    const LABEL = ['正常', '动态光探针：开（画面整体应变白）', '动态光自检：开（脚下应出现火把光晕）'];
    const next = () => {
      /* 0=正常 1=PROBE 2=SELFTEST */
      const cur = window.__dynProbe ? 1 : (window.__dynSelfTest ? 2 : 0);
      const nxt = (cur + 1) % 3;
      window.__dynProbe = (nxt === 1);
      window.__dynSelfTest = (nxt === 2);
      return nxt;
    };
    const apply = () => {
      const n = next();
      toast(LABEL[n]);
    };
    el.title = '点一下：循环切换 正常 / 探针 / 自检';
    el.addEventListener('click', apply);
  });
}

/* ============================================================
   岩浆粒子
   ============================================================ */
let lavaScanTimer = 0;
const LAVA_SCAN_INTERVAL = 0.25;
const LAVA_SCAN_R = 8;
const lavaSurfaces = [];

function scanLavaSurfaces(playerPos){
  lavaSurfaces.length = 0;
  const px = Math.floor(playerPos.x);
  const py = Math.floor(playerPos.y);
  const pz = Math.floor(playerPos.z);
  for (let dx = -LAVA_SCAN_R; dx <= LAVA_SCAN_R; dx++){
    for (let dz = -LAVA_SCAN_R; dz <= LAVA_SCAN_R; dz++){
      for (let dy = -4; dy <= 4; dy++){
        const x = px + dx, y = py + dy, z = pz + dz;
        const id = getBlockWorld(x, y, z);
        if (!id) continue;
        const b = BLOCKS[id];
        if (!b || b.name !== 'lava') continue;
        if (getBlockWorld(x, y + 1, z) === 0) lavaSurfaces.push([x, y, z]);
      }
    }
  }
}

function updateLavaParticles(dt){
  lavaScanTimer += dt;
  if (lavaScanTimer >= LAVA_SCAN_INTERVAL){
    lavaScanTimer = 0;
    scanLavaSurfaces(player.pos);
    if (lavaSurfaces.length > 0) playSFX('lava.sizzle');
  }
  if (lavaSurfaces.length === 0) return;
  const tries = Math.min(2, lavaSurfaces.length);
  for (let i = 0; i < tries; i++){
    if (Math.random() < 0.45){
      const s = lavaSurfaces[Math.floor(Math.random() * lavaSurfaces.length)];
      spawnLavaSpark(
        s[0] + 0.5 + (Math.random() - 0.5) * 0.6, s[1] + 1.0,
        s[2] + 0.5 + (Math.random() - 0.5) * 0.6,
        0.4 + Math.random() * 0.6
      );
    }
  }
}

/* ============================================================
   玩家吐泡泡
   ============================================================ */
let bubbleTimer = 0;
function tryPlayerBubbles(dt){
  if (!player.breathActive){ bubbleTimer = 0; return; }
  bubbleTimer += dt;
  if (bubbleTimer < 0.4) return;
  bubbleTimer = 0;
  const eyeH = player.sneaking ? 1.42 : 1.62;
  spawnBubble(
    player.pos.x + (Math.random() - 0.5) * 0.3,
    player.pos.y + eyeH,
    player.pos.z + (Math.random() - 0.5) * 0.3,
    1
  );
}

/* ============================================================
   高亮
   ============================================================ */
const hlGeo = new THREE.BoxGeometry(1.004, 1.004, 1.004);
const hlEdges = new THREE.EdgesGeometry(hlGeo);
const hlMat = new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.5 });
const hlMesh = new THREE.LineSegments(hlEdges, hlMat);
hlMesh.visible = false;
scene.add(hlMesh);

const progGeo = new THREE.BoxGeometry(1.02, 1.02, 1.02);
const progMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.18 });
const progMesh = new THREE.Mesh(progGeo, progMat);
progMesh.visible = false;
scene.add(progMesh);

/* ============================================================
   工具逻辑
   ============================================================ */
const INTERACT_REACH = 6;
const MINE_REACH = 4;

function getHeldItem(){ return inventory[curSlot] || null; }

function getHeldTool(){
  const s = getHeldItem();
  if (!s) return null;
  const blk = BLOCKS[s.id];
  if (!blk || !blk.toolType) return null;
  return { type: blk.toolType, material: blk.material, speed: blk.speed, tier: blk.tier };
}

/* 近战伤害：空手 0.5，工具按材质/种类取 attack */
const FIST_DAMAGE = 0.5;
function getHeldAttack(){
  const s = getHeldItem();
  if (!s) return FIST_DAMAGE;
  const blk = BLOCKS[s.id];
  if (!blk) return FIST_DAMAGE;
  return blk.attack > 0 ? blk.attack : FIST_DAMAGE;
}

function evaluateMining(block, tool){
  if (block.isLeaves){
    if (tool && tool.type === 'shears') return { willDrop: true, speed: tool.speed };
    return { willDrop: false, speed: 1 };
  }
  const hasCorrectType = tool && block.tool && tool.type === block.tool;
  const minTier = block.minTier || 0;
  if (minTier > 0){
    const tier = tool ? tool.tier : 0;
    if (!hasCorrectType || tier < minTier) return { willDrop: false, speed: 0.2 };
    return { willDrop: true, speed: tool.speed };
  }
  if (block.tool){
    if (hasCorrectType) return { willDrop: true, speed: tool.speed };
    return { willDrop: true, speed: 1 };
  }
  return { willDrop: true, speed: 1 };
}

/* ============================================================
   挖掘 / 放置
   ============================================================ */
let miningTarget = null;
let mineProgress = 0;
let mineCooldown = 0;
/* ★ 挖掘后冷却：防止创造模式挖穿到后面的方块 */
let digCooldown = 0;

function consumeToolDurability(isCorrectTool){
  const slot = inventory[curSlot];
  if (!slot) return;
  const blk = BLOCKS[slot.id];
  if (!blk || !blk.durability) return;
  if (slot.durability === undefined){
    slot.durability = blk.durability;
    slot.maxDurability = blk.durability;
  }
  slot.durability -= isCorrectTool ? 1 : 2;
  if (slot.durability <= 0){
    inventory[curSlot] = null;
    toast('工具已损坏');
  }
  notifyInventory();
}

const DROP_OVERRIDE = { stone: 'cobble', magic_ore: 'magic_crystal', magic_dust_on: 'magic_dust',
  /* 拉杆的按下态是隐藏变体，掉落回普通拉杆 */
  magic_lever_on: 'magic_lever' };

/* ★ mod 掉落表：blockName -> spec | (ctx) => spec
   spec 可以是：
     'itemName' / 数字 id
     { name:'item', count?:n, min?, max?, chance? }
     [{ ... }, ...]
     null → 不掉落
   返回 null 表示覆盖为“无掉落”，返回 undefined 才回退默认。 */
const MOD_DROP_RULES = new Map();

function setBlockDrop(name, spec){
  if (typeof name !== 'string' || !name) return false;
  if (spec === undefined) return MOD_DROP_RULES.delete(name);
  MOD_DROP_RULES.set(name, spec);
  return true;
}

function clearBlockDrop(name){
  return MOD_DROP_RULES.delete(name);
}

function _dropEntryId(entry){
  if (entry == null) return 0;
  if (typeof entry === 'number') return entry;
  if (typeof entry === 'string') return B[entry] ? B[entry].id : 0;
  if (typeof entry === 'object'){
    if (entry.id != null) return entry.id;
    if (entry.name && B[entry.name]) return B[entry.name].id;
  }
  return 0;
}

function _normalizeDropSpec(spec){
  if (spec == null) return [];
  if (Array.isArray(spec)) return spec;
  return [spec];
}

function spawnConfiguredDrops(x, y, z, blk){
  const rule = MOD_DROP_RULES.get(blk.name);
  if (rule === undefined){
    spawnDrop(x, y, z, dropIdFor(blk), 1);
    return;
  }

  let spec;
  try {
    spec = typeof rule === 'function'
      ? rule({ x, y, z, name: blk.name, block: blk, tool: getHeldTool(), mode: player.mode })
      : rule;
  } catch(e){
    console.warn('[drops] 掉落规则执行失败:', blk.name, e);
    return;
  }

  if (spec === undefined){
    spawnDrop(x, y, z, dropIdFor(blk), 1);
    return;
  }

  for (const entry of _normalizeDropSpec(spec)){
    const id = _dropEntryId(entry);
    if (!id) continue;
    const chance = (entry && entry.chance != null) ? Number(entry.chance) : 1;
    if (chance < 1 && Math.random() > chance) continue;

    let count = 1;
    if (entry && typeof entry === 'object'){
      if (entry.count != null) count = Math.max(1, Math.floor(entry.count));
      else if (entry.max != null || entry.min != null){
        const min = Math.max(1, Math.floor(entry.min != null ? entry.min : entry.max));
        const max = Math.max(min, Math.floor(entry.max != null ? entry.max : min));
        count = min + Math.floor(Math.random() * (max - min + 1));
      }
    }
    if (!spawnDrop(x, y, z, id, count)){
      if (!addItem(id, count)) break;
    }
  }
}

function dropIdFor(blk){
  if (blk.stair && blk.stairBase){
    const base = B[blk.stairBase];
    if (base) return base.id;
  }
  /* 朝向方块（熔炉等）：掉落统一回到基准方块 */
  if (blk.orientBase){
    const base = B[blk.orientBase];
    if (base) return base.id;
  }
  /* 按钮/压力板的按下态：掉落回未按下的本体，避免隐藏变体进背包 */
  if (blk.buttonOff && B[blk.buttonOff]) return B[blk.buttonOff].id;
  if (blk.plateOff && B[blk.plateOff]) return B[blk.plateOff].id;
  const over = DROP_OVERRIDE[blk.name];
  if (over !== undefined){
    const fid = (B[over] ? B[over].id : null);
    if (fid !== null) return fid;
  }
  return blk.id;
}

function digSoundFor(blk){
  if (blk.isLeaves || blk.cross || blk.name === 'grass' || blk.name === 'dirt') return 'dig.grass';
  if (blk.tag === 'log' || blk.tag === 'planks' || blk.name === 'crafting_table') return 'dig.wood';
  if (blk.name === 'sand' || blk.name === 'gravel' || blk.name === 'clay') return 'dig.sand';
  if (blk.name === 'glass' || blk.transparent) return 'dig.glass';
  return 'dig.stone';
}

function computeChain(x, y, z, blk){
  const chain = [{ x, y, z }];
  const upName = {
    'double_grass': 'double_grass_top',
    'double_fern':  'double_fern_top',
    'kelp':         'kelp'
  }[blk.name];
  if (upName){
    let cy = y + 1;
    while (true){
      const cid = getBlockWorld(x, cy, z);
      const cb = BLOCKS[cid];
      if (!cb || cb.name !== upName) break;
      chain.push({ x, y: cy, z });
      cy++;
    }
  }
  const downName = {
    'double_grass_top': 'double_grass',
    'double_fern_top':  'double_fern'
  }[blk.name];
  if (downName){
    let cy = y - 1;
    while (true){
      const cid = getBlockWorld(x, cy, z);
      const cb = BLOCKS[cid];
      if (!cb || cb.name !== downName) break;
      chain.push({ x, y: cy, z });
      cy--;
    }
  }
  return chain;
}

const _DOOR_TOP_OF = {
  magic_door: 'magic_door_top',
  magic_door_open: 'magic_door_open_top',
  iron_door: 'iron_door_top',
  iron_door_open: 'iron_door_open_top',
};
const _DOOR_BOTTOM_OF = {
  magic_door_top: 'magic_door',
  magic_door_open_top: 'magic_door_open',
  iron_door_top: 'iron_door',
  iron_door_open_top: 'iron_door_open',
};

function breakBlock(x, y, z, willDrop){
  const id = getBlockWorld(x, y, z);
  if (id === 0) return;
  const blk = BLOCKS[id];
  if (blk.hardness >= 9999) return;

  /* 门的上下半格是一个整体：点到上半格时改挖下半格，掉落只算一次 */
  if (_DOOR_BOTTOM_OF[blk.name]){
    const lowId = getBlockWorld(x, y - 1, z);
    const lowBlk = lowId ? BLOCKS[lowId] : null;
    if (lowBlk && lowBlk.name === _DOOR_BOTTOM_OF[blk.name]) return breakBlock(x, y - 1, z, willDrop);
  }

  /* ★ 可取消：mod 在 block.break 里 return true 即可阻止破坏。
     必须放在任何容器内容取出 / 连锁清除之前 —— 否则取消时状态已经被改过了。
     创造模式原本发 false，这里统一成实际掉落语义。 */
  const willDropEff = (player.mode === 'creative') ? false : willDrop;
  if (emitCancellable('block.break', x, y, z, id, willDropEff)) return;

  if (blk.interactive === 'furnace'){
    const st = removeFurnace(x, y, z);
    if (st){
      for (const s of [st.input, st.fuel, st.output]){
        if (s && s.count > 0 && s.id != null){
          spawnDrop(x + 0.5, y + 0.6, z + 0.5, s.id, s.count);
        }
      }
    }
  }

  /* ★ 箱子：内容全部掉落，并删掉它在存档里的那个文件。
     读盘是异步的（本会话没打开过的箱子要先读文件），所以掉落稍后到。
     —— 修复：
      ① 如果正在看着这个箱子，先关面板再删。否则 chest.js 已经把记录
         移出内存了，玩家还在面板里搬东西 = 往虚空里搬，挖掉之后东西就没了。
      ② 掉落用 spawnDrop 的返回值判断：掉落物没能生成（没贴图 / 被 mod 拦掉）
         就直接塞回背包，绝不静默吞掉。 */
  if (blk.name === 'magic_pedestal') {
    const data = getBlockData(x, y, z);
    if (data && data.item) {
        const targetBlk = B[data.item];
        if (targetBlk) {
            // 安全掉落：水晶在展台里有消耗，原版掉落不支持传meta，所以直接进背包
            if (data.item === 'magic_crystal') {
                const meta = { durability: data.dur || 100, maxDurability: 100 };
                if (!addItem(targetBlk.id, 1, meta)) {
                    spawnDrop(x + 0.5, y + 0.6, z + 0.5, targetBlk.id, 1);
                }
            } else {
                spawnDrop(x + 0.5, y + 0.6, z + 0.5, targetBlk.id, 1);
            }
        }
    }
    removeBlockData(x, y, z);
  }
  if (blk.interactive === 'chest'){
    if (isChestOpenAt(x, y, z)){ try { closeChest(); } catch(e){} }
    removeChest(x, y, z).then(items => {
      for (const s of items){
        if (!s || !(s.count > 0) || s.id == null) continue;
        if (!spawnDrop(x + 0.5, y + 0.6, z + 0.5, s.id, s.count)){
          if (!addItem(s.id, s.count)) toast('背包已满，箱子里的物品丢失');
        }
      }
    }).catch(e => console.warn('[chest] 破坏箱子失败:', e && e.message));
  }

  const chain = computeChain(x, y, z, blk);
  /* 门：只有在正上方确实是门的上半格时，才连同上半格一起拆掉 */
  const doorTopName = _DOOR_TOP_OF[blk.name];
  if (doorTopName){
    const aboveId = getBlockWorld(x, y + 1, z);
    const aboveBlk = aboveId ? BLOCKS[aboveId] : null;
    if (aboveBlk && aboveBlk.name === doorTopName) chain.push({ x, y: y + 1, z });
  }
  for (const p of chain) setBlockWorld(p.x, p.y, p.z, 0);

  /* ★ 创造模式：不掉落、不耗耐久。block.break 已在上方发出（可取消）。 */
  if (player.mode === 'creative'){
    return;
  }

  const tool = getHeldTool();
  const isCorrect = tool && blk.tool && tool.type === blk.tool
                    && (blk.minTier === 0 || tool.tier >= blk.minTier);

  if (willDrop){
    if (blk.name === 'double_grass_top'){
      spawnDrop(x + 0.5, y + 0.5, z + 0.5, B.double_grass.id, 1);
    } else if (blk.name === 'double_fern_top'){
      spawnDrop(x + 0.5, y + 0.5, z + 0.5, B.double_fern.id, 1);
    } else if (blk.name === 'kelp'){
      for (const p of chain) spawnDrop(p.x + 0.5, p.y + 0.5, p.z + 0.5, B.kelp.id, 1);
    } else if (blk.name === 'magic_door_open'){
      /* 开着的门掉落正常门 */
      spawnDrop(x + 0.5, y + 0.5, z + 0.5, B.magic_door.id, 1);
    } else if (blk.name === 'iron_door_open'){
      spawnDrop(x + 0.5, y + 0.5, z + 0.5, B.iron_door.id, 1);
    } else {
      spawnConfiguredDrops(x + 0.5, y + 0.5, z + 0.5, blk);
    }
    /* 树叶额外掉树苗（10%）：否则树苗没有任何获取途径 */
    if (blk.isLeaves && B.sapling && Math.random() < 0.10){
      spawnDrop(x + 0.5, y + 0.5, z + 0.5, B.sapling.id, 1);
    }
    playSFX(digSoundFor(blk));
  }
  consumeToolDurability(!!isCorrect);
}

function tryMine(dt, target){
  if (!target){ miningTarget = null; mineProgress = 0; return; }
  const blk = BLOCKS[target.id];
  const tool = getHeldTool();
  const eval_ = evaluateMining(blk, tool);

  const key = target.x + ',' + target.y + ',' + target.z;
  if (!miningTarget || miningTarget.key !== key){
    miningTarget = { key, x: target.x, y: target.y, z: target.z };
    mineProgress = 0;
  }
  const hardness = Math.max(0.12, blk.hardness);
  const speed = (player.mode === 'creative') ? 22 : eval_.speed;
  mineProgress += dt * speed;

  if (mineProgress >= hardness){
    breakBlock(target.x, target.y, target.z, eval_.willDrop);
    mineProgress = 0;
    miningTarget = null;
    /* ★ 挖掉后冷却：
       · 创造 150ms：移动视角时不会一帧挖穿后面的方块
       · 生存 50ms：本来就要挖很久，几乎无感 */
    digCooldown = (player.mode === 'creative') ? 0.15 : 0.05;
  }
}

function canSupport(plantBlk, sx, sy, sz){
  const below = BLOCKS[getBlockWorld(sx, sy, sz)];
  if (!below) return false;
  if (plantBlk.waterPlant) return !!below.liquid;
  return !!below.solid;
}

function stairVariantFor(stairId){
  const blk = BLOCKS[stairId];
  if (!blk || !blk.stair) return stairId;
  const group = STAIR_VARIANTS[blk.stairBase];
  if (!group) return stairId;
  const fx = -Math.sin(player.yaw), fz = -Math.cos(player.yaw);
  let d;
  if (Math.abs(fx) > Math.abs(fz)) d = fx > 0 ? 1 : 3;
  else                             d = fz > 0 ? 2 : 0;
  return group[d] !== undefined ? group[d] : stairId;
}

/* 朝向方块（熔炉）：正面朝向玩家 —— 玩家往哪看，正面就朝反方向。
   视线方向 0=北 1=东 2=南 3=西，正面方向 = 视线 + 2。 */
function orientVariantFor(blockId){
  const blk = BLOCKS[blockId];
  if (!blk || !blk.orientBase) return blockId;
  const fx = -Math.sin(player.yaw), fz = -Math.cos(player.yaw);
  let look;
  if (Math.abs(fx) > Math.abs(fz)) look = fx > 0 ? 1 : 3;
  else                             look = fz > 0 ? 2 : 0;
  const dir = (look + 2) & 3;
  const v = B[blk.orientBase + ['', '_e', '_s', '_w'][dir]];
  return v ? v.id : blockId;
}

/* ============================================================
   桶
   ============================================================ */
function replaceHeldBucket(newName){
  const newBlk = B[newName];
  if (!newBlk) return;
  const slot = inventory[curSlot];
  if (!slot) return;
  if (slot.count === 1){
    inventory[curSlot] = { id: newBlk.id, count: 1 };
  } else {
    takeFromSlot(curSlot, 1);
    addItem(newBlk.id, 1);
  }
  notifyInventory();
  playSFX('pop');
}

function tryBucketAction(type, hit){
  if (type === 'empty'){
    const id = getBlockWorld(hit.x, hit.y, hit.z);
    const blk = BLOCKS[id];
    if (!blk) return;
    if (getFluidSource(hit.x, hit.y, hit.z) !== 1) return;
    if (blk.name === 'water'){
      setBlockWorld(hit.x, hit.y, hit.z, 0);
      replaceHeldBucket('water_bucket');
      playSFX('splash');
      spawnSplash(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5, 0.5);
    } else if (blk.name === 'lava'){
      setBlockWorld(hit.x, hit.y, hit.z, 0);
      replaceHeldBucket('lava_bucket');
      playSFX('splash');
    }
    return;
  }

  const hitBlk = BLOCKS[hit.id];
  let px = hit.x + hit.nx, py = hit.y + hit.ny, pz = hit.z + hit.nz;
  if (hitBlk && hitBlk.liquid){ px = hit.x; py = hit.y; pz = hit.z; }
  const existing = getBlockWorld(px, py, pz);
  const existingBlk = BLOCKS[existing];
  if (existing !== 0 && (!existingBlk || !existingBlk.liquid)) return;

  if (type === 'water'){
    createSource(px, py, pz, B.water.id);
    replaceHeldBucket('bucket');
    playSFX('splash');
    spawnSplash(px + 0.5, py + 0.5, pz + 0.5, 0.5);
  } else if (type === 'lava'){
    createSource(px, py, pz, B.lava.id);
    replaceHeldBucket('bucket');
    playSFX('splash');
  } else if (type === 'fish'){
    createSource(px, py, pz, B.water.id);
    spawnFishAt(px + 0.5, py + 0.5, pz + 0.5);
    replaceHeldBucket('bucket');
    playSFX('splash');
    spawnSplash(px + 0.5, py + 0.5, pz + 0.5, 0.6);
  }
}

function tryPlace(target){
  const hitBlk = BLOCKS[target.id];
  if (hitBlk && hitBlk.name === 'crafting_table'){ toggleInv('crafting_table'); return; }
  if (hitBlk && hitBlk.interactive === 'furnace'){ openFurnace(target.x, target.y, target.z); return; }
  if (hitBlk && hitBlk.interactive === 'pedestal'){
    const data = getBlockData(target.x, target.y, target.z);
    const slot = inventory[curSlot];
    const heldBlk = slot ? BLOCKS[slot.id] : null;

    if (heldBlk && (heldBlk.name === 'magic_crystal' || heldBlk.name === 'magic_crystal_block' || heldBlk.name === 'magic_pulse_core')) {
        if (data && data.item) return; // 里面有东西，不能放
        const meta = { item: heldBlk.name };
        if (heldBlk.name === 'magic_crystal') {
            meta.dur = slot.durability !== undefined ? slot.durability : 100;
        } else if (heldBlk.name === 'magic_crystal_block') {
            meta.dur = (slot.meta && typeof slot.meta.dur === 'number')
                ? slot.meta.dur
                : (slot.durability !== undefined ? slot.durability : 100);
        } else if (heldBlk.name === 'magic_pulse_core') {
            meta.chargeTime = 2; // 默认 2 秒
            meta._pulseState = { energy: 0, timer: 0, firing: 0 };
        }
        setBlockData(target.x, target.y, target.z, meta);
        takeFromSlot(curSlot, 1);
        emit('magic.pedestalUpdated', target.x, target.y, target.z);
        playSFX('place');
    } else if (!heldBlk && data && data.item) {
        // 空手右键
        if (data.item === 'magic_pulse_core') {
            // 调整时间 2 -> 4 -> 6 -> 8 -> 10 -> 2
            let t = data.chargeTime || 2;
            t += 2;
            if (t > 10) t = 2;
            data.chargeTime = t;
            setBlockData(target.x, target.y, target.z, data);
            if (typeof toast === 'function') toast(`脉冲蓄能周期调整为 ${t} 秒`);
        } else {
            // 取出物品
            const itemId = B[data.item].id;
            const meta = data.item === 'magic_crystal'
                ? { durability: data.dur, maxDurability: 100 }
                : (data.item === 'magic_crystal_block' ? { dur: data.dur } : {});
            addItem(itemId, 1, meta);
            removeBlockData(target.x, target.y, target.z);
            emit('magic.pedestalUpdated', target.x, target.y, target.z);
            playSFX('pop');
        }
    }
    return;
  }
  if (hitBlk && hitBlk.interactive === 'chest'){
    openChest(target.x, target.y, target.z); return;
  }
  if (hitBlk && hitBlk.interactive === 'bed'){
    trySleep(target.x, target.y, target.z); return;
  }
  if (hitBlk && hitBlk.interactive === 'lever'){
    pullLever(target.x, target.y, target.z);
    playSFX('click');
    return;
  }
  if (hitBlk && hitBlk.interactive === 'button'){
    pressButton(target.x, target.y, target.z);
    playSFX('click');
    return;
  }
  if (hitBlk && hitBlk.interactive === 'door'){
    toggleDoor(target.x, target.y, target.z);
    playSFX('click');
    return;
  }

  /* 铁门：不能用手开关，只能由魔法机关驱动 */
  if (hitBlk && hitBlk.interactive === 'iron_door'){
    toast('铁门只能由魔法机关开启');
    playSFX('click');
    return;
  }

  // ★ 新增：触发 block.interact 事件
  if (emitCancellable('block.interact', target.x, target.y, target.z, target.id, target.nx, target.ny, target.nz)) {
    return;
  }

  const slot = inventory[curSlot];
  if (!slot || slot.count <= 0) return;
  const blk = BLOCKS[slot.id];
  if (blk.isItem) return;

  if (blk.waterSurface){
    const tId  = getBlockWorld(target.x, target.y, target.z);
    const tBlk = BLOCKS[tId];
    let ty = target.y;
    if (tBlk && tBlk.liquid) ty = target.y + 1;
    const curId = getBlockWorld(target.x, ty, target.z);
    if (curId !== 0) return;
    const belowBlk = BLOCKS[getBlockWorld(target.x, ty - 1, target.z)];
    if (!belowBlk || belowBlk.name !== 'water') return;
    if (emitCancellable('block.place', target.x, ty, target.z, slot.id)) return;
    setBlockWorld(target.x, ty, target.z, slot.id);
    if (player.mode !== 'creative') takeFromSlot(curSlot, 1);
    playSFX('place');
    return;
  }

  if (blk.waterPlant){
    let px = target.x, py = target.y, pz = target.z;
    const tId  = getBlockWorld(px, py, pz);
    const tBlk = BLOCKS[tId];
    if (tBlk && tBlk.solid){
      px = target.x + target.nx; py = target.y + target.ny; pz = target.z + target.nz;
    } else if (tBlk && tBlk.name === 'water'){
      while (py - 1 > -500){
        const belowId = getBlockWorld(px, py - 1, pz);
        const belowBlk = BLOCKS[belowId];
        if (!belowBlk || belowBlk.name !== 'water') break;
        py--;
      }
    } else return;

    const curId = getBlockWorld(px, py, pz);
    const curBlk = BLOCKS[curId];
    if (!curBlk || curBlk.name !== 'water') return;

    if (emitCancellable('block.place', px, py, pz, slot.id)) return;
    setBlockWorld(px, py, pz, slot.id);
    if (player.mode !== 'creative') takeFromSlot(curSlot, 1);
    playSFX('place');
    return;
  }

  let wx = target.x + target.nx;
  let wy = target.y + target.ny;
  let wz = target.z + target.nz;
  if (hitBlk && hitBlk.liquid && blk.liquid){ wx = target.x; wy = target.y; wz = target.z; }

  if (blk.cross){
    if (!canSupport(blk, wx, wy - 1, wz)) return;
    const cur0 = getBlockWorld(wx, wy, wz);
    const cb0 = BLOCKS[cur0];
    if (cur0 !== 0 && !cb0.liquid) return;
    if (emitCancellable('block.place', wx, wy, wz, slot.id)) return;
    setBlockWorld(wx, wy, wz, slot.id);
    const upperName = blk.name === 'double_grass' ? 'double_grass_top'
                    : blk.name === 'double_fern'  ? 'double_fern_top'
                    : null;
    if (upperName && B[upperName]){
      const upId = getBlockWorld(wx, wy + 1, wz);
      if (upId === 0) setBlockWorld(wx, wy + 1, wz, B[upperName].id);
    }
    if (player.mode !== 'creative') takeFromSlot(curSlot, 1);
    playSFX('place');
    return;
  }

  const existing = getBlockWorld(wx, wy, wz);
  const eb = BLOCKS[existing];
  if (existing !== 0){
    if (!eb.liquid) return;
    if (blk.liquid && eb.id === slot.id && getFluidSource(wx, wy, wz) === 1) return;
  }

  const placeH = blk.slab ? 0.5 : 1.0;
  if (blk.solid){
    const hw = 0.3, px = player.pos.x, py = player.pos.y, pz = player.pos.z;
    if (wx + 1 > px - hw && wx < px + hw &&
        wy + placeH > py && wy < py + 1.8 &&
        wz + 1 > pz - hw && wz < pz + hw) return;
  }

  /* 门：一次放下两格高（下半 + 上半），上半格必须为空 */
  const doorTopId = (blk.name === 'magic_door' && B.magic_door_top)
    ? B.magic_door_top.id
    : (blk.name === 'iron_door' && B.iron_door_top ? B.iron_door_top.id : 0);
  if (doorTopId){
    if (getBlockWorld(wx, wy + 1, wz) !== 0) return;
    let facing0 = 0;
    const fx = -Math.sin(player.yaw), fz = -Math.cos(player.yaw);
    if (Math.abs(fx) > Math.abs(fz)) facing0 = fx > 0 ? 1 : 3;
    else                             facing0 = fz > 0 ? 2 : 0;
    if (emitCancellable('block.place', wx, wy, wz, slot.id, facing0)) return;
    if (emitCancellable('block.place', wx, wy + 1, wz, doorTopId, facing0)) return;
    setBlockWorld(wx, wy, wz, slot.id);
    setBlockData(wx, wy, wz, { facing: facing0 });
    setBlockWorld(wx, wy + 1, wz, doorTopId);
    if (player.mode !== 'creative') takeFromSlot(curSlot, 1);
    playSFX('place');
    return;
  }

  const placeId = blk.stair ? stairVariantFor(slot.id) : orientVariantFor(slot.id);

  /* ★ block.place 可取消：在真正写世界之前询问 mod */
  let facing = 0;
  if (!blk.liquid) {
    const fx = -Math.sin(player.yaw), fz = -Math.cos(player.yaw);
    if (Math.abs(fx) > Math.abs(fz)) facing = fx > 0 ? 1 : 3;
    else                             facing = fz > 0 ? 2 : 0;
  }
  if (emitCancellable('block.place', wx, wy, wz, slot.id, facing)) return;

  if (blk.liquid){
    createSource(wx, wy, wz, placeId);
  } else {
    setBlockWorld(wx, wy, wz, placeId);
    setBlockData(wx, wy, wz, { facing });
  }
  if (player.mode !== 'creative') takeFromSlot(curSlot, 1);
  playSFX('place');
}

/* ============================================================
   主循环
   ============================================================ */
let lastT = performance.now();

function applyInput(dt){
  consumeMouseState();
  const yd = input.yawDelta || 0, pd = input.pitchDelta || 0;
  if (yd || pd){
    player.yaw += yd; player.pitch += pd;
    player.pitch = clamp(player.pitch, -Math.PI / 2 + 0.01, Math.PI / 2 - 0.01);
    input.yawDelta = 0; input.pitchDelta = 0;
  }
  if (input.wheelDelta){
    setCurSlot((curSlot + input.wheelDelta + 9) % 9);
    input.wheelDelta = 0;
  }
  if (input.selectSlot >= 0){
    setCurSlot(input.selectSlot); input.selectSlot = -1;
  }
  if (consumeFlyToggle()){
    if (player.mode === 'creative'){
      player.flying = !player.flying;
      player.vel.y = 0;
      toast(player.flying ? '✦ 飞行开启' : '✦ 飞行关闭');
    }
  }
  if (input.cycleView){
    input.cycleView = false;
    const m = cycleViewMode();
    toast('视角：' + VIEW_NAMES[m]);
  }
  if (input.toggleInv){
    input.toggleInv = false;
    /* ★ 箱子/熔炉开着时 ESC 先关它们，而不是再开一个背包 */
    if (isChestOpen()) closeChest();
    else toggleInv();
  }
  if (input.resetPos){
    input.resetPos = false;
    player.pos.set(spawn.x + 0.5, Math.floor(heightAt(spawn.x, spawn.z)) + 2.5, spawn.z + 0.5);
    player.vel.set(0, 0, 0);
  }
}

/* ============================================================
   季节推进
   ------------------------------------------------------------
   一季 = SEASON_PERIOD_SEC 秒真实时间（整周期 = 4 倍该值）。
   不产生任何 UI / 日志 —— 玩家只能通过雪线变化、草/叶颜色、
   新生成区块的群系变化来察觉。
   ============================================================ */
const SEASON_PERIOD_SEC = 60 * 15;   /* 一季 15 分钟 */
let _seasonAccum = 0;

function tickSeason(dt){
  const cs = getCurrentSave();
  if (!cs) return;
  _seasonAccum += dt;
  if (_seasonAccum < 0.5) return;    /* 0.5s 推进一次就够 */
  const adv = _seasonAccum / SEASON_PERIOD_SEC;
  _seasonAccum = 0;
  const cur = (typeof cs.seasonPhase === 'number') ? cs.seasonPhase : 0;
  const next = (cur + adv) % 1;
  cs.seasonPhase = next;
  try { setSeasonPhase(next); } catch(e){}
}

function animateBody(){
  _frameStart = performance.now();
  const now = performance.now();
  let dt = (now - lastT) / 1000;
  lastT = now;
  dt = Math.min(dt, 0.05);

  emit('game.tick', dt);
  try { updateMagic(dt); } catch(e){}

  if (loadingMode){ tickShadow(now); updateLoading(); renderer.render(scene, camera); return; }
  if (!gameStarted){ tickShadow(now); renderer.render(scene, camera); return; }

  const _renderDist = getRenderDist();
  const simBlocks = Math.min(getSimDist(), _renderDist);

  let _t0 = performance.now();
  applyInput(dt);
  tickSeason(dt);
  try { updateChunkDebug(player.pos, getRenderDist()); } catch(e){}

  /* 天气推进 */
  try {
    tickWeather(dt);
    tickWeatherGround(dt, player.pos);
    const _pTemp = worldTemperatureAt(player.pos.x, player.pos.y + 1, player.pos.z);
    updateWeatherRender(dt, player.pos, getSnowFactor(_pTemp));
  } catch(e){ /* 天气失败不影响主循环 */ }
  
  updateSky(dt, _renderDist);
  window.__prof.sky = performance.now() - _t0;

  _t0 = performance.now();
  updatePlayer(dt, input);
  window.__prof.player = performance.now() - _t0;

  /* ★ 地震镜头震动 */
  if (quakeT > 0){
    quakeT = Math.max(0, quakeT - dt);
    const amp = quakeAmp * (quakeT / Math.max(0.001, quakeDur));
    camera.position.x += (Math.random() - 0.5) * amp;
    camera.position.y += (Math.random() - 0.5) * amp * 0.7;
    camera.position.z += (Math.random() - 0.5) * amp;
  }

  /* ★ 失落古城：宝箱填充 / Boss 唤醒 */
  try { updateLostCity(dt); } catch(e){ console.error('[lost-city] 更新出错:', e); }

  /* ★ 第三人称玩家实体 + 背包角色面板预览 */
  try { updatePlayerAvatar(); } catch(e){}
  try { renderCharPreview(); } catch(e){}

  /* ★ 背景音乐：同一区块连续停留 60 秒且当前无歌时随机播放一首 */
  try {
    updateMusicScheduler(dt,
      getActiveDimensionId() + ':' +
      Math.floor(player.pos.x / CS) + ',' +
      Math.floor(player.pos.z / CS));
  } catch(e){}

  /* ★ 洞穴环境音：进入封闭洞穴时淡入低频空气声 + 滴水回音 */
  try { updateCaveAmbience(dt, player.pos); } catch(e){}

  /* ★ 状态效果计时（回调由 mod 提供） */
  updateStatusEffects(dt);

  /* ★ 挖掘冷却递减 */
  if (digCooldown > 0) digCooldown = Math.max(0, digCooldown - dt);

  _t0 = performance.now();
  updateFluid(dt, player.pos, simBlocks);
  updateLavaParticles(dt);
  updateSplash(dt);
  tryPlayerBubbles(dt);
  skyMesh.position.copy(camera.position);
  window.__prof.fluid = performance.now() - _t0;

  _t0 = performance.now();
  /* ★ 本帧还剩多少毫秒可以花：刷新间隔 − 本帧已用时间。
     区块层用它决定这一帧敢不敢多做一点，而不是用写死的 2ms/3ms。 */
  const _frameHeadroomMs = Math.max(0.3, _frameTargetMs - (performance.now() - _frameStart));
  updateChunks(player.pos, player.yaw, _renderDist, IS_TOUCH, _pickChunkBudget(), _frameHeadroomMs);
  const _tChunks1 = performance.now();
  /* ★ 必须立刻结算：下面 _t0 会被"实体更新"重新赋值，
     原来的 _dbgChunksMs = _tChunks1 - _t0 实际上减的是两个相邻时刻，
     结果恒为 0（偶尔负数），F3 的「块」一直是个假数字。 */
  _dbgChunksMs = _tChunks1 - _t0;
  window.__prof.chunks = _dbgChunksMs;
  
  /* ★ 细分探针：这 13ms 到底是谁吃的，一次测清 */
  const _p0 = performance.now();
  updateDrops(dt, player.pos, simBlocks);
  const _p1 = performance.now();
  updateAnimals(dt, player.pos);
  try { updateHostileMobs(dt, player.pos); } catch(e){ console.error('[hostile] update 出错:', e); }
  updateArrows(dt);
  updateStoneProjectiles(dt);
  updateBeanProjectiles(dt);
  updateTempBlocks();
  updateHighlights(dt);

  /* ★ 移动光源：手持发光物品 + 发光掉落物 + 飞行中的豆子/发光箭
     关闭时直接跳过，不构造任何数组（避免每帧无谓 GC） */
  if (isDynamicLightEnabled()){
    try {
      const _hs = inventory[curSlot];
      const _hb = _hs ? BLOCKS[_hs.id] : null;
      const _src = [];
      if (isLightSourceBlock(_hb)){
        _src.push({
          /* ★ 光源高度：原来放在 camera.position.y - 0.2，也就是眼睛下方
             0.2 格 ≈ 脚上 1.42 格（头部高度），所以"头顶比脚下亮"。
             MC 的手持光源是跟着玩家所在的方块走的，压在身体中段更合理：
             这里取脚上约 0.8 格（眼睛下方 0.85），地面和墙面亮度就平衡了。 */
          pos: { x: camera.position.x, y: camera.position.y - 0.85, z: camera.position.z },
          blk: _hb,
        });
      }
      _src.push(...getGlowDropSources());
      _src.push(...getGlowArrowSources());
      _src.push(...getBeanLightSources());
      updateDynamicLights(camera.position, _src);
    } catch(e){ console.error('[dynamic-light] 更新出错:', e); }
  }
  const _p2 = performance.now();
  updateFurnaces(dt);
  updateChestVisuals(dt, getOpenChestPos());
  const _p3 = performance.now();
  trySpawnLeaves(dt, player.pos);
  updateLeaves(dt);
  try { updateSaplings(dt, player.pos); } catch(e){}
  try { updateBlockTicks(dt); } catch(e){ console.error('[block-tick] 更新出错:', e); }
  const _p4 = performance.now();
  updateBreath(player.breath, player.breathActive, player.mode);
  updateHunger(player.hunger, player.maxHunger, player.mode);
  /* ★ 护甲值条：内部自己从 player.armor 汇总防御，带脏检查，空手时零开销 */
  updateArmor(player.mode);
  const _p5 = performance.now();

  window.__prof.pDrop    = _p1 - _p0;
  window.__prof.pAnimal  = _p2 - _p1;
  window.__prof.pFurnace = _p3 - _p2;
  window.__prof.pLeaf    = _p4 - _p3;
  window.__prof.pHud     = _p5 - _p4;
  window.__prof.drops    = _p4 - _p0;

  const _tLogic1 = performance.now();
  window.__prof.entities = _tLogic1 - _p0;

  if (isFurnaceOpen()) renderFurnace();

  _tmpCamDir.set(0, 0, -1).applyQuaternion(camera.quaternion);
  const camDir = _tmpCamDir;
  const slotNow = inventory[curSlot];
  const heldNow = slotNow ? BLOCKS[slotNow.id] : null;
  const isBucket    = !!(heldNow && heldNow.bucketType);
  const isWaterItem = !!(heldNow && (heldNow.waterPlant || heldNow.waterSurface));
  const hit = raycastVoxel(camera.position, camDir, INTERACT_REACH, isBucket || isWaterItem);
  const uiOpen = isInvOpen() || isSettingsOpen() || isPauseOpen() ||
                 isFurnaceOpen() || isChestOpen();

  if (hit && !uiOpen){
    const hb = BLOCKS[hit.id];
    const tool = getHeldTool();
    const canHarv = !hb.tool || (tool && tool.type === hb.tool &&
                    (hb.minTier === 0 || tool.tier >= hb.minTier));
    updateBlockInfo(hb, canHarv);
  } else updateBlockInfo(null);

  /* ★ 触屏短按：准星模式（默认）用 tap 按屏幕中心判定；
     触点模式用 tapScreen 按手指落点判定 */
  const tapScreenPt = input.tapScreen;
  input.tapScreen = null;
  const mineScreenPt = input.mineScreen;
  const tapNow = input.tap;
  input.tap = false;

  const wantMine = input.mouseLeft || input.mine || input.uiMine;
  let mineHit = null, attacked = null;
  if (wantMine){
    let origin = camera.position, dir = camDir;
    if (mineScreenPt){
      const r = screenRay(mineScreenPt);
      if (r){ origin = r.origin; dir = r.direction; }
    }
    mineHit = raycastVoxel(origin, dir, MINE_REACH);
    attacked = getAnimalAt(origin, dir, MINE_REACH, _mineHitInfo);
    /* 方块挡在实体前面 → 不打实体 */
    if (attacked && mineHit && mineHit.dist < _mineHitInfo.t - 0.02) attacked = null;
  }
  if (attacked && !uiOpen){
    if (mineCooldown <= 0){ damageAnimal(attacked, getHeldAttack()); playSFX('hurt'); mineCooldown = 0.4; }
    miningTarget = null; mineProgress = 0;
  } else if (wantMine && mineHit && !uiOpen && digCooldown <= 0){
    /* ★ digCooldown > 0 时跳过挖掘（冷却中） */
    tryMine(dt, mineHit);
  } else {
    /* 冷却中或没目标：重置进度，但保留 miningTarget 以便 UI 显示 */
    if (!wantMine || digCooldown <= 0){
      miningTarget = null;
      mineProgress = 0;
    }
  }

  let rawUse = !!(input.mouseRight || input.place || input.uiUse || tapNow);
  let useHit = hit;
  let useEntity = null;
  if (tapScreenPt){
    /* 触点模式：按手指落点找方块 / 实体 */
    rawUse = true;
    const r = screenRay(tapScreenPt);
    if (r){
      useHit = raycastVoxel(r.origin, r.direction, INTERACT_REACH, isBucket || isWaterItem);
      useEntity = getAnimalAt(r.origin, r.direction, INTERACT_REACH, _useHitInfo);
      if (useEntity && useHit && useHit.dist < _useHitInfo.t - 0.02) useEntity = null;
    } else {
      useHit = null;
    }
  } else if (tapNow){
    /* 准星模式：准星指着实体 → 优先攻击实体，而不是在方块上放置 */
    useEntity = getAnimalAt(camera.position, camDir, INTERACT_REACH, _useHitInfo);
    if (useEntity && useHit && useHit.dist < _useHitInfo.t - 0.02) useEntity = null;
  }
  input.place = false;
  const bowHandled = updateBow(dt, rawUse, uiOpen, inventory[curSlot])
                  || updateStaff(dt, rawUse, uiOpen, inventory[curSlot], curSlot)
                  || updateMagicBean(dt, rawUse, uiOpen, inventory[curSlot], curSlot, useHit);
  const heldSlot = inventory[curSlot];
  const heldBlk = heldSlot ? BLOCKS[heldSlot.id] : null;
  const btype = heldBlk && heldBlk.bucketType;
  /* 空桶点鱼 → 捞鱼；其他情况点到实体一律攻击 */
  const tapFish = !!(useEntity && useEntity.type === 'fish' && btype === 'empty');
  if (!bowHandled && useEntity && !uiOpen && mineCooldown <= 0 &&
      tryRepairGolem(useEntity, curSlot)){
    /* 拿着魔法水晶点远古故障石人 → 修好变成远古守卫 */
    mineCooldown = 0.6;
  } else if (!bowHandled && useEntity && !tapFish && !uiOpen && mineCooldown <= 0){
    /* 准星指着实体 → 攻击，而不是放方块 */
    damageAnimal(useEntity, getHeldAttack()); playSFX('hurt'); mineCooldown = 0.4;
  } else if (!bowHandled && rawUse && !uiOpen && tryEat()){
    mineCooldown = 0.3;
  } else if (!bowHandled && rawUse && !uiOpen && mineCooldown <= 0){
    if (btype === 'empty'){
      const fish = useEntity || getAnimalAt(camera.position, camDir, MINE_REACH);
      if (fish && fish.type === 'fish' && captureFish(fish)){
        replaceHeldBucket('fish_bucket'); playSFX('pop'); mineCooldown = 0.3;
      } else if (useHit){ tryBucketAction('empty', useHit); mineCooldown = 0.2; }
    } else if (btype){
      if (useHit){ tryBucketAction(btype, useHit); mineCooldown = 0.2; }
    } else if (useHit){ tryPlace(useHit); mineCooldown = 0.2; }
  } else if (!rawUse) mineCooldown = 0;

  /* 触点模式长按挖方块时，高亮跟着手指目标；准星模式仍是中心准星 */
  const activeHit = (wantMine && mineScreenPt && mineHit) ? mineHit : hit;
  if (activeHit && !uiOpen){
    hlMesh.visible = true;
    hlMesh.position.set(activeHit.x + 0.5, activeHit.y + 0.5, activeHit.z + 0.5);
    const blk = BLOCKS[activeHit.id];
    if (blk && (blk.heightRatio < 1 || blk.slab)){
      hlMesh.scale.y = blk.heightRatio;
      hlMesh.position.y = activeHit.y + 0.5 * blk.heightRatio;
    } else hlMesh.scale.y = 1;
  } else hlMesh.visible = false;

  if (miningTarget && mineProgress > 0.02){
    const blk = BLOCKS[getBlockWorld(miningTarget.x, miningTarget.y, miningTarget.z)];
    const total = Math.max(0.12, blk.hardness);
    const p = clamp(mineProgress / total, 0, 1);
    progMesh.visible = true;
    progMesh.position.set(miningTarget.x + 0.5, miningTarget.y + 0.5, miningTarget.z + 0.5);
    progMesh.scale.setScalar(1 + p * 0.07);
    progMat.opacity = 0.08 + p * 0.32;
  } else progMesh.visible = false;

  /* ★ 「逻」= 区块段之后到渲染之前的全部逻辑（拾取/挖掘/高亮/HUD），
     与「渲」「块」三段不重叠、可相加 ≈ 整帧 */
  const _rt0 = performance.now();
  _dbgLogicMs = _rt0 - _tChunks1;
  /* 逻 = 实体段 + 拾取/HUD 段 */
  window.__prof.pPick = _rt0 - _tLogic1;

  /* ★ ultra 体积云：先渲染到半分辨率 RT，再由天空穹顶合成 */
  renderCloudPass();
  /* ★ 阴影标记必须打在主场景 render 之前。
     needsUpdate 是一次性的，而 renderCloudPass() 内部也是一次
     renderer.render() —— 它会把这个标记消费掉（Three 的
     WebGLShadowMap.render 是无条件调用的），所以顺序不能反。 */
  tickShadow(now);
  renderFrame();
  _dbgLastRenderMs = performance.now() - _rt0;

  /* ★ 把游戏自己实测的三段 + 整个 animateBody 暴露出去。
     这样 perf-monitor 不必用"帧时间 - 渲 - 块"去做减法，
     也就能把【两帧之间的空档】单独量出来（浏览器合成/样式/rAF 对齐）。 */
  try {
    window.__frameSplit = {
      r: _dbgLastRenderMs,
      c: _dbgChunksMs,
      l: _dbgLogicMs,
      body: performance.now() - _frameStart,
    };
  } catch(e){}

  const frameMs = performance.now() - _frameStart;
  _smoothFrameMs = _smoothFrameMs * 0.85 + frameMs * 0.15;
  _learnFrameTarget(frameMs);

  /* ★ 移动光源按实测帧时自适应：点光源减盏 → 转体素光 → 关闭 */
  notifyFrameTime(_smoothFrameMs, _frameTargetMs);

  updateDebugPanel(dt);
}

let _frameErrors = 0;
function animateSafe(){
  const _ft = performance.now();
  const _gap = _ft - (window.__frameLast || _ft);
  if (_gap > (window.__frameMaxGap || 0)) window.__frameMaxGap = Math.round(_gap);
  if (_gap > 100) {
    console.warn(`[frame] 上一帧耗时 ${_gap.toFixed(0)}ms`);
  }
  window.__frameLast = _ft;
  window.__frameCount = (window.__frameCount || 0) + 1;
  try {
    animateBody();
    requestAnimationFrame(animateSafe);
  } catch(e){
    _frameErrors++;
    const msg = String((e && (e.stack || e.message)) || e).slice(0, 300);
    try { reportNow('FRAME_ERROR', { n: _frameErrors, msg }); } catch(err){}
    if (_frameErrors <= 3) console.error('[frame] 主循环异常', e);
    if (_frameErrors > 5){
      console.error('[frame] 连续异常，停止主循环');
      try { reportNow('FRAME_HALTED', { n: _frameErrors }); } catch(err){}
      return;
    }
    requestAnimationFrame(animateSafe);
  }
}

/* ============================================================
   创建世界对话框 —— 注入"选择 Mod"按钮
   ============================================================ */
let _createDialogSelectedMods = [];
let _createDialogModsAll = [];

async function setupCreateDialogMods(){
  const dlg = document.getElementById('createDialog');
  if (!dlg) return;
  const dialogBox = dlg.querySelector('.dialog-box');
  if (!dialogBox) return;
  const actions = dialogBox.querySelector('.dialog-actions');
  if (!actions) return;

  if (dialogBox.querySelector('#createDialogModsBtn')) return;

  const row = document.createElement('div');
  row.className = 'field';
  row.id = 'createDialogModsRow';
  row.innerHTML = `
    <div class="cmods-row">
      <button type="button" id="createDialogModsBtn">
        <span>选择 Mod…</span>
        <span class="cbtn-count" id="createDialogModsCount">加载中</span>
      </button>
      <button type="button" id="createDialogImportPack" title="导入一个 .zip 整合包（装进 mods/ 并自动勾选）">🧩 导入整合包</button>
    </div>
  `;
  dialogBox.insertBefore(row, actions);

  const btn = row.querySelector('#createDialogModsBtn');
  const countEl = row.querySelector('#createDialogModsCount');
  const importBtn = row.querySelector('#createDialogImportPack');

  try {
    const r = await fetch('/api/mods');
    if (r.ok){
      const list = await r.json();
      if (Array.isArray(list)){
        _createDialogModsAll = list.map(m => m && m.id).filter(Boolean);
      }
    }
  } catch(e){
    console.warn('[create-dialog] 拉取 mod 列表失败:', e);
  }

  function refreshCount(){
    if (_createDialogSelectedMods.length === 0){
      countEl.textContent = '未选择（点击选择）';
      btn.classList.remove('has-selection');
    } else {
      countEl.textContent = `已选 ${_createDialogSelectedMods.length} 个`;
      btn.classList.add('has-selection');
    }
  }
  refreshCount();

  btn.addEventListener('click', async () => {
    try {
      const m = await import('./ui/mod-panel/index.js');
      const selected = await m.openModSelectDialog({
        title: '选择 Mod',
        selected: _createDialogSelectedMods.slice(),
      });
      if (selected === null) return;
      _createDialogSelectedMods = Array.isArray(selected) ? selected : [];
      refreshCount();
    } catch(e){
      console.error('[create-dialog] 打开 mod 选择器失败:', e);
    }
  });

  /* ★ 导入整合包：装好 mod 后刷新列表并自动勾上 */
  if (importBtn){
    importBtn.addEventListener('click', async () => {
      const label = importBtn.textContent;
      importBtn.disabled = true;
      importBtn.textContent = '⏳ 导入中...';
      try {
        const data = await importModpackFile();
        if (!data) return;                       /* 用户取消 */
        /* 刷新候选 mod 列表 */
        try {
          const r2 = await fetch('/api/mods');
          if (r2.ok){
            const list = await r2.json();
            if (Array.isArray(list)) _createDialogModsAll = list.map(m => m && m.id).filter(Boolean);
          }
        } catch(e){}
        /* 自动勾选包里带的 mod */
        for (const mid of (data.mods || [])){
          if (typeof window.__addCreateDialogMod === 'function') window.__addCreateDialogMod(mid);
        }
        refreshCount();
        alert(`✔ 整合包「${(data.meta && data.meta.name) || '未命名'}」导入成功！\n包含 ${data.mods.length} 个 Mod，已自动勾选。`);
      } catch(e) {
        alert('✘ 导入失败：' + (e.message || e));
      } finally {
        importBtn.textContent = label;
        importBtn.disabled = false;
      }
    });
  }

  const dlgObserver = new MutationObserver(() => {
    if (dlg.classList.contains('show')){
      refreshCount();
    }
  });
  dlgObserver.observe(dlg, { attributes: true, attributeFilter: ['class'] });

  window.__getCreateDialogMods = () => _createDialogSelectedMods.slice();

  /* ★ 选中"mod 提供的世界类型"时自动勾选该 mod（连同它声明的依赖） */
  let _modsMetaById = null;
  async function ensureModsMeta(){
    if (_modsMetaById) return _modsMetaById;
    _modsMetaById = new Map();
    try {
      const r = await fetch('/api/mods');
      if (r.ok){
        const list = await r.json();
        if (Array.isArray(list)){
          for (const m of list){
            if (m && m.id) _modsMetaById.set(m.id, m);
          }
        }
      }
    } catch(e){ /* 拉不到就只加自己，不追依赖 */ }
    return _modsMetaById;
  }

  window.__addCreateDialogMod = (id) => {
    if (typeof id !== 'string' || !id) return;
    let changed = false;
    const addOne = (mid) => {
      if (!mid || _createDialogSelectedMods.includes(mid)) return;
      _createDialogSelectedMods.push(mid);
      changed = true;
    };
    addOne(id);
    /* 依赖闭包（最多 4 层，防御性上限） */
    ensureModsMeta().then(meta => {
      const seen = new Set([id]);
      let queue = [id];
      for (let depth = 0; depth < 4 && queue.length; depth++){
        const next = [];
        for (const mid of queue){
          const m = meta.get(mid);
          const deps = (m && Array.isArray(m.dependencies)) ? m.dependencies : [];
          for (const d of deps){
            if (typeof d !== 'string' || seen.has(d)) continue;
            seen.add(d);
            addOne(d);
            next.push(d);
          }
        }
        queue = next;
      }
      if (changed) refreshCount();
    });
    if (changed) refreshCount();
  };
}

/* ============================================================
   安装 Mod 宿主
   ============================================================ */
function installGameHost(){
  if (isHostInstalled()) return;

  enableRuntimeRegistration();

  /* 换世界时清空上一套方块 tick，避免旧回调写进新存档 */
  on('world.load', clearAllBlockTicks);
  on('world.load', clearArrows);
  on('world.load', clearStoneProjectiles);
  on('world.load', clearBeanProjectiles);
  on('world.load', resetDynamicLights);
  on('world.load', clearHighlights);
  on('world.load', resetLostCityRuntime);
  on('world.load', () => clearStatusEffects('world.load'));

  onBlockRegistered((blk) => {
    B[blk.name] = blk;
    emit('block.registered', blk);
    try { refreshWorkerBlockTables(); }
    catch(e){ console.warn('[mod-host] refresh blockTable failed:', e); }
  });

  onAtlasChanged(() => emit('atlas.changed', getAtlasUsage()));

  installHost({
    gameVersion: BUILD,
    triggerDamageUI,

    /* ★ 当前手持槽（给 mod 用） */
    getHeldSlot(){ return curSlot; },

    getSaveId(){
      const cs = getCurrentSave();
      return cs && cs.id ? cs.id : null;
    },
    getSeed(){
      return getWorldConfig().seed;
    },
    getSaveType(){
      return getWorldConfig().type;
    },
    setBlockDrop,
    clearBlockDrop,
    getChestItems(x, y, z, dim){ return getChestItems(x, y, z, dim); },
    setChestItems(x, y, z, items, opts){ return setChestItems(x, y, z, items, undefined, opts); },
    /* ★ 方块计划 tick（20 TPS，区块加载时执行） */
    scheduleBlockTick: (x, y, z, delayTicks, fn, opts) =>
      scheduleBlockTick(x, y, z, delayTicks, fn, opts),
    cancelBlockTick: (id) => cancelBlockTick(id),
    cancelBlockTicksAt: (x, y, z, dim) => cancelBlockTicksAt(x, y, z, dim),
    getBlockTickCount: () => getPendingBlockTickCount(),
    /* 创建世界时选的那个类型自己的选项（超平坦没有、无尽之海有"生成岛屿"） */
    getWorldOptions(){
      const cs = getCurrentSave();
      const o = cs && cs.worldOptions;
      return (o && typeof o === 'object') ? { ...o } : {};
    },
    getModStorage(modId){
      const cs = getCurrentSave();
      if (!cs) return null;
      try { return getModStorage(cs.id, modId); }
      catch(e){
        console.warn('[mod-host] getModStorage 失败:', e);
        return null;
      }
    },

    getChunkStats,
    setHeightLimit,
    refreshWorkerBiomes,

    registerBlockRuntime(name, label, opts, drawFn){
      if (typeof name !== 'string' || !name){
        throw new Error('registerBlock: name 必须是非空字符串');
      }
      const finalOpts = Object.assign({}, opts || {});
      /* ★ 支持分面贴图：drawFn 画通用面，drawFaces.{top,side,bottom,front}
         可以单独画某一面（正面方块用它 + frontDir 就能做出"朝玩家"的面）。 */
      const drawFaces = (opts && opts.drawFaces) || null;
      if (typeof drawFn === 'function' || drawFaces){
        const tex = {};
        if (typeof drawFn === 'function'){
          const texName = 'mod_' + name;
          const idx = registerTexRuntime(texName, drawFn);
          if (idx < 0){
            throw new Error(`atlas 已满，无法注册贴图 "${texName}"`);
          }
          tex.all = texName;
        }
        if (drawFaces){
          for (const face of ['top', 'side', 'bottom', 'front']){
            if (typeof drawFaces[face] !== 'function') continue;
            const fn2 = 'mod_' + name + '_' + face;
            if (registerTexRuntime(fn2, drawFaces[face]) >= 0) tex[face] = fn2;
          }
          delete finalOpts.drawFaces;   /* 别传到 buildBlk */
        }
        finalOpts.tex = tex;
      }
      /* ★ iconDraw：程序化背包图标（独立于方块贴图） */
      if (opts && typeof opts.iconDraw === 'function'){
        const iconTexName = 'mod_icon_' + name;
        const iconIdx = registerTexRuntime(iconTexName, opts.iconDraw);
        if (iconIdx >= 0) finalOpts.icon = iconTexName;
        delete finalOpts.iconDraw;   /* 别传到 buildBlk */
      }
      const blk = registerBlockRaw(name, label, finalOpts);
      if (!blk){
        throw new Error(`方块注册失败: "${name}"（可能重名）`);
      }
      return blk;
    },

    registerRecipe(recipe, source){
      return addRuntimeRecipe(recipe, source || null);
    },
    listRecipes,

    registerSmelt(from, to, count, source){
      return addSmeltRecipe(from, to, count, source || null);
    },
    removeSmelt(name){
      return removeSmeltRecipe(name);
    },
    setFuel(name, secs){
      return setFuelSeconds(name, secs);
    },
    listSmelts: listSmeltRecipes,

    getAtlasUsage,

    switchDimension,
    getActiveDimensionId,
    setWaterRenderMode,
  });
}

/* ============================================================
   启动
   ============================================================ */
async function bootstrap(){
  /* ★ 初始状态：CSS 里 #menu 是 display:none，#loading 是 display:flex，
     所以这里不需要再操作显示/隐藏。整个 bootstrap 期间加载屏一直可见，
     完成后再切到菜单（无闪屏）。 */
  loadingFillEl.style.width = '0%';
  loadingTextEl.textContent = '正在启动...';
  if (loadingStageEl) loadingStageEl.textContent = '';

  checkAtlasCompatibility();

  applyMemoryLimit(512, null);
  if (loadingStageEl) loadingStageEl.textContent = '正在启动游戏…';
  loadingFillEl.style.width = '100%';
  try { initMemorySlider(); } catch(e){}

  initWorldSave({
    onEnterGame: () => enterGame(),
  });

  initSettings({
    onLeaveWorld: () => {
      gameStarted = false;
      try { reportNow('leave_world'); stopDiagnostics('back-to-menu'); } catch(e){}
      uiEl.style.display = 'none';
      menuEl.style.display = 'block';
      document.getElementById('mainMenu').style.display = 'flex';
      document.getElementById('worldMenu').style.display = 'none';
    },
  });

  try {
    installGameHost();
  } catch(e){
    console.error('[mod-host] 安装失败:', e);
  }

  window.__setMeshWorkerEnabled = setMeshWorkerEnabled;

  try {
    await setupCreateDialogMods();
  } catch(e){
    console.warn('[create-dialog] 注入 mod 选择器失败:', e);
  }

  try { initMagic(); } catch(e){ console.warn('[magic] init failed:', e); }
  try { initSaplings(); } catch(e){ console.warn('[saplings] init failed:', e); }

  /* 天气系统：注入温度采样函数 + 暴露调试接口 */
  try {
    setWeatherTempFn(worldTemperatureAt);
    window.__setWeather = setWeather;
    window.__getWeather = getWeatherState;
    /* 站在哪里都能查："我这块地为什么有雪/为什么没雪" */
    window.__whySnow = () => {
      try {
        const W = __weatherMod;
        const t = worldTemperatureAt(player.pos.x, player.pos.y + 1, player.pos.z);
        const TH = W.TEMP_THRESHOLDS;
        const st = getWeatherState();
        const it = W.getWeatherIntensity();
        const byTemp  = t < TH.EXTREME_COLD;
        const byStorm = (st === 'rain' || st === 'storm') && it > 0.2 && t < TH.SNOW_ACCUM;
        return {
          温度: +t.toFixed(3),
          天气: st,
          降水强度: +it.toFixed(2),
          自然积雪_温度低于0_08: byTemp,
          下雪积雪_低0_20且在下: byStorm,
          会融雪_高于0_30: t > TH.MELT_SNOW,
          飘雪粒子强度: +getSnowFactor(t).toFixed(2),
          结论: byTemp ? '自然积雪（与天气无关，晴天也铺）'
              : byStorm ? '下雪积雪'
              : t > TH.MELT_SNOW ? '会融雪' : '不铺雪',
        };
      } catch(e){ return { err: String(e && e.message || e) }; }
    };
    console.log('[weather] 调试：__setWeather("rain") / __getWeather() / __whySnow()');
  } catch(e){
    console.warn('[weather] 初始化失败:', e);
  }

  try {
    setListenerSource(
      () => ({
        x: camera.position.x,
        y: camera.position.y,
        z: camera.position.z,
      }),
      () => {
        const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
        return { x: dir.x, y: dir.y, z: dir.z };
      }
    );
  } catch(e){
    console.warn('[audio] 设置监听源失败:', e);
  }

  /* ★ 去掉固定 400ms 等待 —— 真实初始化已经完成，
     不需要再"假装"等一会儿。直接切到菜单。 */
  loadingEl.classList.add('hidden');
  menuEl.style.display = 'block';
  document.getElementById('mainMenu').style.display = 'flex';
  document.getElementById('worldMenu').style.display = 'none';

  /* ★ 标记启动完成：index.html 的 15s 看门狗依赖它，
     否则每次成功启动也会误报 BOOT_TIMEOUT */
  window.__gameBooted__ = true;
}

applyHint();
initPlayerAvatar();
initLostCityRuntime();
on('view.cycle', () => {
  const m = cycleViewMode();
  toast('视角：' + VIEW_NAMES[m]);
});
on('world.quake', (power) => {
  quakeAmp = 0.16 * (Number(power) || 1);
  quakeDur = 0.55;
  quakeT = quakeDur;
});
animateSafe();
bootstrap().catch(e => {
  console.error('❌ 游戏模块加载崩溃:', e);
  console.error('name:', e && e.name);
  console.error('message:', e && e.message);
  console.error('stack:', e && e.stack);
});