/* ============================================================
   magic-bean.js —— 魔法豆子
   ------------------------------------------------------------
   · 右键短按（点在方块上）→ 原地种下魔法草（夜晚微弱发光）
   · 按住右键蓄力后松开 → 把豆子丢出去，落点生成发光树苗
     （光照 15，3 分钟后消失）
   · 飞行中的豆子本身也会发光（移动光源开启时）
   ============================================================ */

import * as THREE from 'three';

import { BLOCKS, B } from '../world/blocks.js';
import { getBlockWorld, setBlockWorld } from '../world/terrain.js';
import { getAnimalAt, damageAnimal } from '../entities/entities-core.js';
import { takeFromSlot } from './items-core.js';
import { player } from '../player/player-core.js';
import { camera, scene } from '../render/render-core.js';
import { Y_MIN } from '../core/engine-core.js';
import { placeTempBlock } from '../world/temp-blocks.js';
import { playSFX } from '../audio/audio.js';
import { toast } from '../ui/ui.js';

const CHARGE_TIME = 0.9;
const TAP_TIME = 0.28;
const GRAVITY = 15;
const MAX_BEANS = 12;
const SAPLING_SECONDS = 180;

const beans = [];
const BEAN_GEO = new THREE.SphereGeometry(0.15, 8, 6);
const BEAN_MAT = new THREE.MeshBasicMaterial({ color: 0xa8ffb0 });

let holding = false;
let holdT = 0;

function isBean(blk){ return !!blk && blk.name === 'magic_bean'; }

function beanBlockId(){ return B.magic_bean.id; }

function freeCell(x, y, z){
  const b = BLOCKS[getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z))];
  return !b || b.name === 'air' || (!b.solid && !b.liquid);
}

function solidAt(x, y, z){
  const b = BLOCKS[getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z))];
  return !!(b && b.solid && !b.liquid);
}

/* 种下一株魔法草：需要目标格是空气、下方是实心方块 */
function plantMagicGrass(hit){
  if (!hit) return false;
  const wx = hit.x + (hit.nx || 0);
  const wy = hit.y + (hit.ny || 0);
  const wz = hit.z + (hit.nz || 0);
  if (!freeCell(wx, wy, wz)) return false;
  if (!solidAt(wx, wy - 1, wz)) return false;
  setBlockWorld(wx, wy, wz, B.magic_grass.id);
  playSFX('place');
  toast('种下了魔法草');
  return true;
}

/* 落点生成发光树苗 */
function plantSapling(x, y, z){
  const cx = Math.floor(x), cy = Math.floor(y), cz = Math.floor(z);
  let ty = cy;
  if (!freeCell(cx, ty, cz)){
    /* 卡进方块里就往上找一格 */
    ty = cy + 1;
    if (!freeCell(cx, ty, cz)) return false;
  }
  placeTempBlock(cx, ty, cz, B.glow_sapling.id, SAPLING_SECONDS);
  return true;
}

function throwBean(power){
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  const speed = 11 + 15 * power;

  const p = camera.position.clone().addScaledVector(dir, 0.55);
  const mesh = new THREE.Mesh(BEAN_GEO, BEAN_MAT);
  mesh.position.copy(p);
  scene.add(mesh);

  beans.push({
    mesh,
    pos: p,
    vel: dir.multiplyScalar(speed).add(new THREE.Vector3(0, 1.6 + power * 2.4, 0)),
    life: 4,
  });
  playSFX('bow');
}

function removeBean(i){
  const b = beans[i];
  scene.remove(b.mesh);
  beans.splice(i, 1);
}

/**
 * @returns true 表示这次右键输入已被豆子消费
 */
export function updateMagicBean(dt, useHeld, uiOpen, slot, slotIndex, targetHit){
  const blk = slot ? BLOCKS[slot.id] : null;

  if (!isBean(blk) || uiOpen){
    holding = false;
    holdT = 0;
    return false;
  }

  if (useHeld){
    holding = true;
    holdT += dt;
    return true;                    /* 按住期间吃掉右键，避免连锁放置 */
  }

  if (holding){
    holding = false;
    const t = holdT;
    holdT = 0;

    if (t < TAP_TIME){
      if (!plantMagicGrass(targetHit)){
        /* 没点在地面上就当轻抛 */
        throwBean(0.15);
      }
    } else {
      throwBean(Math.min(1, t / CHARGE_TIME));
    }

    if (player.mode !== 'creative') takeFromSlot(slotIndex, 1);
    return true;
  }

  return false;
}

/** 每帧更新魔法豆子投射物 */
export function updateBeanProjectiles(dt){
  for (let i = beans.length - 1; i >= 0; i--){
    const b = beans[i];
    b.life -= dt;
    b.vel.y -= GRAVITY * dt;

    const prev = b.pos.clone();
    b.pos.addScaledVector(b.vel, dt);

    /* 命中实体 */
    const dir = b.vel.clone().normalize();
    const len = b.vel.length() * dt;
    const hit = getAnimalAt(prev, dir, len + 0.35, {});
    if (hit){
      damageAnimal(hit, 3, 'magic_bean');
      plantSapling(hit.pos.x, hit.pos.y, hit.pos.z);
      removeBean(i);
      continue;
    }

    /* 命中方块 */
    if (solidAt(b.pos.x, b.pos.y, b.pos.z)){
      plantSapling(prev.x, prev.y, prev.z);
      removeBean(i);
      continue;
    }

    if (b.life <= 0 || b.pos.y < Y_MIN){
      plantSapling(b.pos.x, b.pos.y, b.pos.z);
      removeBean(i);
      continue;
    }

    b.mesh.position.copy(b.pos);
  }
}

/** 给动态光源用：飞行中的豆子 */
export function getBeanLightSources(){
  const out = [];
  for (let i = 0; i < beans.length; i++){
    out.push({ pos: beans[i].pos, blk: BLOCKS[beanBlockId()] });
  }
  return out;
}

export function clearBeanProjectiles(){
  for (let i = beans.length - 1; i >= 0; i--){
    scene.remove(beans[i].mesh);
  }
  beans.length = 0;
  holding = false;
  holdT = 0;
}
