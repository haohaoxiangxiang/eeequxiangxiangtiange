/* ============================================================
   items-logic.js —— 掉落物 / 熔炉 / 合成
   ------------------------------------------------------------
★ 合并自 3 个 items 文件（合起来约 33KB，都是"物品怎么变化"的规则）：
     drops.js     掉落物实体（3D 精灵 + 物理 + 吸附）
     furnace.js   熔炉（燃料表、烧炼配方、tick）
     crafting.js  合成（2x2 / 3x3 配方 + 结果计算）
   背包与箱子数据在 items-core.js。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as THREE from 'three';
import { STACK_MAX, Y_MIN } from './../core/engine-core.js';
import { BLOCKS, B } from '../world/blocks.js';
import { addItem, canAddItem } from './items-core.js';
import { emit, emitCancellable } from './../core/engine-core.js';
import { isSolidWorld, getBlockWorld, setBlockWorld } from '../world/terrain.js';
import { playSFX } from '../audio/audio.js';
import { scene } from './../render/render-core.js';
import { spawnSplash } from './../world/world-core.js';
import { createDropVisual } from './item-visuals.js';


/* =================================================================
   drops.js
   ================================================================= */
/* ============================================================
   drops.js —— 掉落物
   ------------------------------------------------------------
   · 用 THREE.Sprite 显示方块顶面图标
   · 物理：重力 / 碰撞 / 玩家吸附 / 入水溅射
   · ★ 已回退到 Three.js 版本（与自研引擎无关）
   ============================================================ */











const drops = [];
function getDropCount(){ return drops.length; }

/* 掉落物尺寸随堆叠数量轻微增大；scale 变了要同步重算贴地高度 */
function updateDropVisualSize(d){
  if (!d.mesh) return;
  const s = d.baseScale + Math.min(0.1, Math.log2(Math.max(1, d.count)) * d.growStep);
  d.mesh.scale.setScalar(s);
  d.lift = s * d.unitHalf;
}

/* 判断某坐标是否水方块 */
function isWaterBlockAt(x, y, z){
  const id = getBlockWorld(Math.floor(x), Math.floor(y), Math.floor(z));
  if (!id) return false;
  const b = BLOCKS[id];
  return b && b.name === 'water';
}

/* ============================================================
   生成掉落物
   ------------------------------------------------------------
   · 事件 'item.drop' 在合并前触发，count 为"请求总量"
   ============================================================ */
function spawnDrop(x, y, z, itemId, count, meta){
  if (count <= 0) return true;

  emit('item.drop', itemId, count, x, y, z, meta);

  /* ★ meta 存在时只和相同 meta 的掉落物合并 */
  const metaKey = (meta !== undefined && meta !== null)
    ? JSON.stringify(meta) : null;

  // 合并到附近的同种堆
  for (const d of drops){
    if (d.itemId !== itemId) continue;
    if (d.count >= STACK_MAX) continue;
    const dKey = d.meta ? JSON.stringify(d.meta) : null;
    if (dKey !== metaKey) continue;
    const dx = d.pos.x - x, dy = d.pos.y - y, dz = d.pos.z - z;
    if (dx*dx + dy*dy + dz*dz > 2.25) continue;    // 半径 1.5
    const add = Math.min(STACK_MAX - d.count, count);
    d.count += add;
    count -= add;
    d.age = 0;
    updateDropVisualSize(d);
    if (count <= 0) return true;
  }

  // 新建掉落物（方块是真 3D 小模型，纯物品是自转的平面贴图）
  const visual = createDropVisual(itemId);
  /* ★ 返回 false：没贴图等原因导致掉落物建不出来，
     调用方（比如挖箱子）要自己把物品塞回背包，不能静默吞掉 */
  if (!visual) return false;

  const d = {
    itemId, count,
    meta: (meta !== undefined && meta !== null) ? meta : undefined,
    pos: new THREE.Vector3(x, y, z),
    vel: new THREE.Vector3(
      (Math.random() - 0.5) * 1.6,
      2.2 + Math.random() * 1.4,
      (Math.random() - 0.5) * 1.6
    ),
    age: 0, life: 300, pickCd: 0, onGround: false,
    wasInWater: false,
    mesh: visual.object,
    unitHalf: visual.unitHalf,
    baseScale: visual.baseScale,
    growStep: visual.growStep,
    lift: 0,
  };
  updateDropVisualSize(d);
  d.mesh.position.set(x, y + d.lift, z);
  scene.add(d.mesh);
  drops.push(d);
  return true;
}

/* ============================================================
   每帧更新
   ------------------------------------------------------------
   · 距离过滤：超出模拟范围时冻结（不更新但不销毁）
   ============================================================ */
const DROP_PICK_RANGE = 2.2;   // 只有靠近才吸附
const DROP_SNAP_RANGE = 0.7;   // 到这个距离直接吸入

function updateDrops(dt, playerPos, simBlocks){
  const pCenter = new THREE.Vector3(playerPos.x, playerPos.y + 0.9, playerPos.z);

  const rangeBlocks = Math.max(2, Math.min(32, simBlocks || 8));
  const rangeUnits  = rangeBlocks * 16;
  const rangeSq     = rangeUnits * rangeUnits;

  for (let i = drops.length - 1; i >= 0; i--){
    const d = drops[i];

    /* 只在玩家附近计时和模拟；远处冻结并保留（跨区块不删除） */
    const ddx = d.pos.x - playerPos.x;
    const ddz = d.pos.z - playerPos.z;
    if (ddx * ddx + ddz * ddz > rangeSq){
      d.vel.set(0, 0, 0);
      continue;
    }

    // 寿命到期 / 掉到地底（age 只在上面的近距离分支里累计）
    d.age += dt;
    if (d.age > d.life || d.pos.y < Y_MIN - 2){
      /* 材质/几何是全局缓存的，多个掉落物共用，不能在这里 dispose */
      scene.remove(d.mesh);
      drops.splice(i, 1);
      continue;
    }

    if (d.pickCd > 0) d.pickCd -= dt;

    // 玩家吸附
    const toP = new THREE.Vector3().subVectors(pCenter, d.pos);
    const dist = toP.length();
    let attracted = false;

    if (d.pickCd <= 0 && dist < DROP_PICK_RANGE && d.age > 0.35){
      attracted = true;
      toP.normalize();
      const pull = 60 / Math.max(dist, 0.3);
      d.vel.addScaledVector(toP, pull * dt);
      d.vel.multiplyScalar(1 - Math.min(1, 3 * dt));

      if (dist < DROP_SNAP_RANGE){
        /* 先判断放不放得下：满了就不反复调 addItem（否则每帧重建背包 UI 会卡） */
        if (canAddItem(d.itemId, d.count, d.meta)){
          /* ★ 可取消：mod 在 item.canPickup 里 return true 可让这一堆继续留在地上 */
          if (emitCancellable('item.canPickup', d.itemId, d.count,
                              d.pos.x, d.pos.y, d.pos.z, d.meta)){
            d.pickCd = 1.0;
            d.vel.set(0, 0, 0);
            attracted = false;
          } else {
            addItem(d.itemId, d.count, d.meta);
            scene.remove(d.mesh);
            drops.splice(i, 1);
            emit('item.pickup', d.itemId, d.count, d.pos.x, d.pos.y, d.pos.z, d.meta);
            continue;
          }
        } else {
          d.pickCd = 1.2;
          d.vel.set(0, 0, 0);
          attracted = false;
        }
      }
    }

    // 物理
    if (!attracted){
      d.vel.y -= 17 * dt;
      d.vel.x *= (1 - Math.min(1, 1.5 * dt));
      d.vel.z *= (1 - Math.min(1, 1.5 * dt));
    }

    const nx = d.pos.x + d.vel.x * dt;
    const ny = d.pos.y + d.vel.y * dt;
    const nz = d.pos.z + d.vel.z * dt;

    if (!isSolidWorld(nx, d.pos.y, d.pos.z)) d.pos.x = nx;
    else d.vel.x *= -0.3;

    if (!isSolidWorld(d.pos.x, ny, d.pos.z)){
      d.pos.y = ny;
      d.onGround = false;
    } else {
      if (d.vel.y < 0) d.onGround = true;
      d.vel.y *= -0.25;
      if (Math.abs(d.vel.y) < 0.6) d.vel.y = 0;
    }

    if (!isSolidWorld(d.pos.x, d.pos.y, nz)) d.pos.z = nz;
    else d.vel.z *= -0.3;

    if (d.onGround){
      d.vel.x *= (1 - Math.min(1, 8 * dt));
      d.vel.z *= (1 - Math.min(1, 8 * dt));
    }

    // 入水检测
    const inWaterNow = isWaterBlockAt(d.pos.x, d.pos.y - 0.15, d.pos.z);
    if (inWaterNow && !d.wasInWater){
      spawnSplash(d.pos.x, d.pos.y, d.pos.z, 0.7);
      playSFX('splash');
    }
    d.wasInWater = inWaterNow;

    // 视觉浮动 + 缓慢自转（3D 小方块和平面物品都转，和 MC 一致）
    const bob = Math.sin(d.age * 3.2) * 0.05;
    d.mesh.position.set(d.pos.x, d.pos.y + d.lift + bob, d.pos.z);
    d.mesh.rotation.y = d.age * 1.1;
  }
}

/* ============================================================
   清理（存档切换 / 退出时调）
   ============================================================ */
function clearDrops(){
  for (const d of drops){
    scene.remove(d.mesh);
  }
  drops.length = 0;
}

/* =================================================================
   furnace.js
   ================================================================= */
/* ============================================================
   熔炉（方块实体）：逻辑 + 数据模型
   ============================================================ */

const SMELT_SECONDS = 10;
const FURNACE_STACK_MAX = STACK_MAX;

const furnaces = new Map();

const MAX_DT = 0.05;
const COOL_RATE = 2;
const MAX_SECONDS = 3600;
const EPS = 1e-9;

/* ---- 变更通知（UI 用，不是事件总线） ---- */
const fn_listeners = [];
function onFurnaceChange(fn){ fn_listeners.push(fn); }
function notifyFurnace(){ fn_listeners.forEach(fn => fn()); }

/* ============================================================
   烧炼配方
   ============================================================ */
const SMELT_RECIPES = [
  /* 生肉 → 熟肉 */
  ['raw_beef',    'cooked_beef'],
  ['raw_mutton',  'cooked_mutton'],
  ['raw_chicken', 'cooked_chicken'],
  ['raw_fish',    'cooked_fish'],
  ['raw_pork',    'cooked_pork'],
  /* 三种原木 → 木炭 */
  ['oak_log',     'charcoal'],
  ['spruce_log',  'charcoal'],
  ['sakura_log',  'charcoal'],
  /* 圆石 → 石头，沙子 → 玻璃 */
  ['cobble',      'stone'],
  ['sand',        'glass'],
  /* 矿石 → 锭 / 钻石 */
  ['coal_ore',    'coal'],
  ['copper_ore',  'copper_ingot'],
  ['iron_ore',    'iron_ingot'],
  ['gold_ore',    'gold_ingot'],
  ['diamond_ore', 'diamond_gem'],
];

const SMELT_MAP = new Map();

/* ★ 运行时添加的配方来源记录：srcId -> source（modId 或 null） */
const _runtimeSmeltSources = new Map();

for (const [from, to] of SMELT_RECIPES){
  const src = B[from], dst = B[to];
  if (!src || !dst) continue;
  SMELT_MAP.set(src.id, { id: dst.id, count: 1 });
}

/* ============================================================
   ★ 运行时配方接口（mod 用）
   ============================================================ */

/**
 * 添加烧炼配方（mod 用）。
 * @param {string} from    原料方块名
 * @param {string} to      产物方块名
 * @param {number} [count] 产物数量，默认 1
 * @param {string} [source] 来源标记（modId 等）
 * @returns {boolean}
 */
function addSmeltRecipe(from, to, count, source){
  const src = B[from], dst = B[to];
  if (!src || !dst){
    console.warn(`[furnace] 配方无效: ${from} → ${to}`);
    return false;
  }
  const n = Math.max(1, Math.floor(Number(count) || 1));
  SMELT_MAP.set(src.id, { id: dst.id, count: n });
  _runtimeSmeltSources.set(src.id, source || null);
  console.log(`[furnace] 已注册烧炼配方: ${from} → ${to} ×${n}`);
  return true;
}

/**
 * 移除烧炼配方。只允许移除"运行时添加"的，内置配方无法移除。
 * @param {string} from
 * @returns {boolean}
 */
function removeSmeltRecipe(from){
  const src = B[from];
  if (!src) return false;
  if (!_runtimeSmeltSources.has(src.id)){
    console.warn(`[furnace] 只能移除运行时配方: ${from}`);
    return false;
  }
  SMELT_MAP.delete(src.id);
  _runtimeSmeltSources.delete(src.id);
  return true;
}

/** 清空所有运行时添加的配方 */
function clearRuntimeSmelts(){
  for (const srcId of _runtimeSmeltSources.keys()){
    SMELT_MAP.delete(srcId);
  }
  _runtimeSmeltSources.clear();
}

/** 列出所有配方（调试 / mod 用） */
function listSmeltRecipes(){
  const out = [];
  for (const [fromId, res] of SMELT_MAP){
    const fromBlk = BLOCKS[fromId];
    const toBlk   = BLOCKS[res.id];
    if (!fromBlk || !toBlk) continue;
    out.push({
      from: fromBlk.name,
      to:   toBlk.name,
      count: res.count,
      runtime: _runtimeSmeltSources.has(fromId),
    });
  }
  return out;
}

/* ============================================================
   ★ 燃料接口（mod 用）
   ============================================================ */

/* 记录原始值，以便恢复 */
const _originalFuels = new Map();   // itemName -> 原始秒数（或 undefined）

/**
 * 设置某物品作为燃料的燃烧秒数（mod 用）。
 * @param {string} itemName
 * @param {number} seconds  设为 0 相当于禁用该燃料
 * @returns {boolean}
 */
function setFuelSeconds(itemName, seconds){
  const b = B[itemName];
  if (!b){
    console.warn(`[furnace] 燃料不存在: ${itemName}`);
    return false;
  }
  if (!_originalFuels.has(itemName)){
    _originalFuels.set(itemName, b.fuel || 0);
  }
  b.fuel = Math.max(0, Math.floor(Number(seconds) || 0));
  return true;
}

/** 恢复所有被 mod 改过的燃料值 */
function restoreFuels(){
  for (const [name, v] of _originalFuels){
    const b = B[name];
    if (b) b.fuel = v;
  }
  _originalFuels.clear();
}

/* ============================================================
   小工具
   ============================================================ */

function resolveItemId(v){
  if (typeof v === 'string' && B[v]) return B[v].id;
  const n = Math.floor(Number(v));
  return isFinite(n) ? n : -1;
}

function isItemId(id){
  return Number.isInteger(id) && id > 0 && id < BLOCKS.length &&
         !!BLOCKS[id] && BLOCKS[id].name !== 'air';
}

function toBlockCoord(v){
  const n = Math.floor(Number(v));
  return isFinite(n) ? n : 0;
}

function furnaceKey(x, y, z){
  return toBlockCoord(x) + ',' + toBlockCoord(y) + ',' + toBlockCoord(z);
}

function safeNum(v, def, min, max){
  const n = Number(v);
  if (!isFinite(n)) return def;
  return Math.max(min, Math.min(max, n));
}

function sanitizeStack(s){
  if (!s || typeof s !== 'object') return null;
  const id = resolveItemId(s.id);
  if (!isItemId(id)) return null;
  let count = Math.floor(Number(s.count));
  if (!isFinite(count) || count < 1) count = 1;
  if (count > FURNACE_STACK_MAX) count = FURNACE_STACK_MAX;
  if (s.id === id && s.count === count) return s;
  return { id, count };
}

/* ============================================================
   状态创建 / 修复
   ============================================================ */
function createFurnace(x, y, z){
  return {
    x, y, z,
    input:  null,
    fuel:   null,
    output: null,
    burnTime: 0,
    burnTotal: 0,
    cookTime: 0,
    cookTotal: SMELT_SECONDS
  };
}

function repairFurnace(f, x, y, z){
  f.x = x; f.y = y; f.z = z;

  f.input  = sanitizeStack(f.input);
  f.fuel   = sanitizeStack(f.fuel);
  f.output = sanitizeStack(f.output);

  f.burnTime  = safeNum(f.burnTime,  0, 0, MAX_SECONDS);
  f.burnTotal = safeNum(f.burnTotal, 0, 0, MAX_SECONDS);
  if (f.burnTime < EPS) f.burnTime = 0;
  if (f.burnTotal < f.burnTime) f.burnTotal = f.burnTime;

  f.cookTotal = safeNum(f.cookTotal, SMELT_SECONDS, 0.05, MAX_SECONDS);
  f.cookTime  = safeNum(f.cookTime,  0, 0, f.cookTotal);
  return f;
}

/* ============================================================
   对外接口：状态获取 / 移除
   ============================================================ */

function getFurnace(x, y, z){
  const cx = toBlockCoord(x), cy = toBlockCoord(y), cz = toBlockCoord(z);
  const key = cx + ',' + cy + ',' + cz;

  const cur = furnaces.get(key);
  if (!cur || typeof cur !== 'object'){
    const f = createFurnace(cx, cy, cz);
    furnaces.set(key, f);
    return f;
  }
  return repairFurnace(cur, cx, cy, cz);
}

function removeFurnace(x, y, z){
  const cx = toBlockCoord(x), cy = toBlockCoord(y), cz = toBlockCoord(z);
  const key = cx + ',' + cy + ',' + cz;
  const raw = furnaces.get(key);
  if (!raw) return null;
  furnaces.delete(key);
  const out = (typeof raw === 'object') ? repairFurnace(raw, cx, cy, cz) : null;
  notifyFurnace();
  /* ★ 广播 */
  emit('furnace.removed', cx, cy, cz, out);
  return out;
}

function clearFurnaces(){
  furnaces.clear();
  notifyFurnace();
}

/* ============================================================
   对外接口：配方 / 燃料查询
   ============================================================ */

function getSmeltResult(itemId){
  const r = SMELT_MAP.get(resolveItemId(itemId));
  if (!r) return null;
  return { id: r.id, count: r.count };
}

function getFuelSeconds(itemId){
  const blk = BLOCKS[resolveItemId(itemId)];
  const v = blk ? Number(blk.fuel) : 0;
  return (isFinite(v) && v > 0) ? v : 0;
}

function isFuel(itemId){
  return getFuelSeconds(itemId) > 0;
}

/* ============================================================
   烧炼逻辑
   ============================================================ */

function outputFits(f, outId, count){
  if (!f.output) return true;
  if (f.output.id !== outId) return false;
  return f.output.count + count <= FURNACE_STACK_MAX;
}

function canSmelt(f){
  if (!f.input || f.input.count <= 0) return false;
  const res = SMELT_MAP.get(f.input.id);
  if (!res) return false;
  return outputFits(f, res.id, res.count);
}

function hasFuel(f){
  return !!f.fuel && f.fuel.count > 0 && getFuelSeconds(f.fuel.id) > 0;
}

function lightFuel(f){
  const secs = Math.max(1, getFuelSeconds(f.fuel.id));
  const fuelId = f.fuel.id;
  f.fuel.count -= 1;
  if (f.fuel.count <= 0) f.fuel = null;
  f.burnTime = secs;
  f.burnTotal = secs;
  /* ★ 广播 */
  emit('furnace.ignite', f.x, f.y, f.z, fuelId, secs);
}

function smeltOne(f){
  if (!f.input || f.input.count <= 0) return false;
  const res = SMELT_MAP.get(f.input.id);
  if (!res) return false;
  if (!outputFits(f, res.id, res.count)){
    f.cookTime = f.cookTotal;
    return false;
  }

  const fromId = f.input.id;   /* ★ 记录，因为下面会改 input */

  f.input.count -= 1;
  if (f.input.count <= 0) f.input = null;

  if (f.output && f.output.id === res.id) f.output.count += res.count;
  else f.output = { id: res.id, count: res.count };
  if (f.output.count > FURNACE_STACK_MAX) f.output.count = FURNACE_STACK_MAX;

  f.cookTime = 0;

  /* ★ 广播 */
  emit('item.smelt', fromId, res.id, f.x, f.y, f.z);
  return true;
}

/* 熔炉外观：燃烧中换成 _lit 变体（炉口发橙红光并照亮周围），熄灭换回。
   只有方块 ID 真的变了才写世界，避免每帧重建区块。 */
const FURNACE_SUFFIX = ['', '_e', '_s', '_w'];

function syncFurnaceBlock(f, burning){
  const id = getBlockWorld(f.x, f.y, f.z);
  const blk = BLOCKS[id];
  if (!blk || blk.interactive !== 'furnace') return false;
  const dir = blk.orientDir >= 0 ? blk.orientDir : 0;
  const want = B['furnace' + FURNACE_SUFFIX[dir] + (burning ? '_lit' : '')];
  if (!want || want.id === id) return false;
  setBlockWorld(f.x, f.y, f.z, want.id);
  return true;
}

function tickFurnace(f, dt){
  let changed = false;
  const smeltable = canSmelt(f);

  let lit = false;
  if (f.burnTime <= 0 && smeltable && hasFuel(f)){
    lightFuel(f);
    lit = true;
    changed = true;
  }

  const burning = f.burnTime > 0;
  if (burning && !lit){
    f.burnTime = Math.max(0, f.burnTime - dt);
    if (f.burnTime < EPS) f.burnTime = 0;
    changed = true;
  }

  if (burning && smeltable){
    f.cookTime += dt;
    if (f.cookTime + EPS >= f.cookTotal && smeltOne(f)) changed = true;
  } else if (!smeltable && f.cookTime > 0){
    f.cookTime = Math.max(0, f.cookTime - dt * COOL_RATE);
    changed = true;
  }

  /* 点燃 / 熄灭时同步方块外观（用扣完时间后的状态判断，最后一帧也能正确熄灭） */
  const nowBurning = f.burnTime > 0;
  if (f._lit !== nowBurning){
    f._lit = nowBurning;
    syncFurnaceBlock(f, nowBurning);
  }

  return changed;
}

function updateFurnaces(dt){
  const d = Number(dt);
  if (!isFinite(d) || d <= 0) return;
  const step = Math.min(d, MAX_DT);

  let changed = false;
  for (const f of furnaces.values()){
    if (!f || typeof f !== 'object') continue;
    if (!f.input && !f.fuel && f.burnTime <= 0 && f.cookTime <= 0) continue;
    if (tickFurnace(f, step)) changed = true;
  }

  if (changed) notifyFurnace();
}

/* ============================================================
   存档：序列化 / 反序列化
   ============================================================ */
function serializeFurnaces(){
  const out = [];
  for (const f of furnaces.values()){
    if (!f || typeof f !== 'object') continue;
    out.push({
      x: f.x, y: f.y, z: f.z,
      input:  f.input  ? { id: f.input.id,  count: f.input.count }  : null,
      fuel:   f.fuel   ? { id: f.fuel.id,   count: f.fuel.count }   : null,
      output: f.output ? { id: f.output.id, count: f.output.count } : null,
      burnTime:  f.burnTime,
      burnTotal: f.burnTotal,
      cookTime:  f.cookTime,
      cookTotal: f.cookTotal,
    });
  }
  return out;
}

function deserializeFurnaces(data){
  clearFurnaces();
  if (!Array.isArray(data)) return;

  for (const rec of data){
    if (!rec) continue;
    const x = toBlockCoord(rec.x);
    const y = toBlockCoord(rec.y);
    const z = toBlockCoord(rec.z);
    const key = x + ',' + y + ',' + z;

    const f = createFurnace(x, y, z);
    f.input  = sanitizeStack(rec.input);
    f.fuel   = sanitizeStack(rec.fuel);
    f.output = sanitizeStack(rec.output);

    f.burnTime  = safeNum(rec.burnTime,  0, 0, MAX_SECONDS);
    f.burnTotal = safeNum(rec.burnTotal, 0, 0, MAX_SECONDS);
    if (f.burnTotal < f.burnTime) f.burnTotal = f.burnTime;
    f.cookTotal = safeNum(rec.cookTotal, SMELT_SECONDS, 0.05, MAX_SECONDS);
    f.cookTime  = safeNum(rec.cookTime,  0, 0, f.cookTotal);

    furnaces.set(key, f);
  }
}

/* =================================================================
   crafting.js
   ================================================================= */
/* 9 格 grid，索引：
   0 1 2
   3 4 5
   6 7 8
   2x2 模式只用 0,1,3,4 */
const craftGrid = new Array(9).fill(null);
let craftResult = null;

let craftSize = 2;

const cf_listeners = [];
function onCraftChange(fn){ cf_listeners.push(fn); }
function notify(){ cf_listeners.forEach(fn => fn()); }

function getCraftSize(){ return craftSize; }

function getActiveIndices(){
  return craftSize === 2 ? [0, 1, 3, 4] : [0, 1, 2, 3, 4, 5, 6, 7, 8];
}

function setCraftSize(n){
  n = (n === 3) ? 3 : 2;
  if (n === craftSize) return;
  craftSize = n;
  if (n === 2){
    for (const i of [2, 5, 6, 7, 8]) craftGrid[i] = null;
  }
  recalc(); notify();
}

/* 木质压力板：同种木板在同一横排相邻两格 → 1 块。
   2x2 只有两行、3x3 有三行；每行还支持左对齐 / 右对齐两种摆法。 */
function _plateRecipes(size){
  const out = [];
  const rows = size === 2 ? [0, 3] : [0, 3, 6];
  const offs = size === 2 ? [0] : [0, 1];
  for (const wood of ['oak', 'spruce', 'sakura', 'mangrove', 'birch', 'jungle', 'acacia']){
    for (const row of rows){
      for (const off of offs){
        const a = row + off;
        out.push({
          shape: [
            { pos: a,     item: wood + '_planks' },
            { pos: a + 1, item: wood + '_planks' },
          ],
          result: { name: wood + '_pressure_plate', count: 1 },
        });
      }
    }
  }
  return out;
}

/* 半砖 / 阶梯：3x3 专用。
   半砖 = 同种材料横排 3 格 → 6 块；
   阶梯 = 经典 6 格台阶形（左上、左中+中、底排满）→ 4 块，左右两种摆法。 */
function _decoRecipes(size){
  if (size !== 3) return [];
  const out = [];
  const slabs = [
    ['oak_planks', 'oak_planks_slab'],
    ['cobble',     'cobble_slab'],
    ['stone',      'stone_slab'],
    ['wool',       'wool_slab'],
  ];
  for (const [mat, result] of slabs){
    for (const row of [0, 3, 6]){
      out.push({
        shape: [0, 1, 2].map(c => ({ pos: row + c, item: mat })),
        result: { name: result, count: 6 },
      });
    }
  }
  const stairs = [
    ['oak_planks', 'oak_planks_stairs'],
    ['cobble',     'cobble_stairs'],
    ['stone',      'stone_stairs'],
    ['wool',       'wool_stairs'],
  ];
  for (const [mat, result] of stairs){
    const shapes = [
      [0, 3, 4, 6, 7, 8],
      [2, 4, 5, 6, 7, 8],
    ];
    for (const cells of shapes){
      out.push({
        shape: cells.map(pos => ({ pos, item: mat })),
        result: { name: result, count: 4 },
      });
    }
  }
  return out;
}

/* 魔法动力元件 / 杂项：这些方块以前只能在创造模式拿到。
   拉杆 = 木棍 + 魔法粉末；按钮 = 石头 + 粉末；压力板 = 两块石头 + 粉末；
   箭 = 木棍 + 铁锭（没有燧石/羽毛，用铁做箭头）。 */
const MISC_RECIPES = [
  { shapeless: ['stick', 'magic_dust'],           result: { name: 'magic_lever', count: 1 } },
  { shapeless: ['stone', 'magic_dust'],           result: { name: 'magic_button', count: 1 } },
  { shapeless: ['stone', 'stone', 'magic_dust'],  result: { name: 'magic_pressure_plate', count: 1 } },
  { shapeless: ['stick', 'iron_ingot'],           result: { name: 'arrow', count: 4 } },
  /* 青石砖：石砖 + 藤蔓 */
  { shapeless: ['stone_bricks', 'vine'],          result: { name: 'mossy_stone_bricks', count: 2 } },
  /* 魔法豆子：魔法粉末 + 高草 → 2 颗豆子 */
  { shapeless: ['magic_dust', 'tall_grass'],      result: { name: 'magic_bean', count: 2 } },
  /* 发光箭矢：箭 + 魔法豆子 */
  { shapeless: ['arrow', 'magic_bean'],           result: { name: 'glow_arrow', count: 1 } },
];

/* ====================== 2x2 配方 ====================== */
const RECIPES_2X2_RAW = [
  { shapeless: ['oak_log'],    result: { name: 'oak_planks',    count: 4 } },
  { shapeless: ['spruce_log'], result: { name: 'spruce_planks', count: 4 } },
  { shapeless: ['sakura_log'], result: { name: 'sakura_planks', count: 4 } },
  { shapeless: ['birch_log'],  result: { name: 'birch_planks',  count: 4 } },
  { shapeless: ['jungle_log'], result: { name: 'jungle_planks', count: 4 } },
  { shapeless: ['acacia_log'], result: { name: 'acacia_planks', count: 4 } },
  { shapeless: ['mangrove_log'], result: { name: 'mangrove_planks', count: 4 } },

  /* 木质压力板：同种木板横向两格 → 1 块（有序配方，必须放在木棍的无序配方前面，
     这样"摆成一横排"做压力板、"随便两格"做木棍，互不抢配方） */
  ..._plateRecipes(2),
  ...MISC_RECIPES,
  /* 木质按钮：木板 ×1 */
  { shapeless: ['oak_planks'],                        result: { name: 'oak_button', count: 1 } },
  { shapeless: ['spruce_planks'],                     result: { name: 'spruce_button', count: 1 } },
  { shapeless: ['sakura_planks'],                     result: { name: 'sakura_button', count: 1 } },
  { shapeless: ['mangrove_planks'],                   result: { name: 'mangrove_button', count: 1 } },
  { shapeless: ['birch_planks'],                      result: { name: 'birch_button', count: 1 } },
  { shapeless: ['jungle_planks'],                     result: { name: 'jungle_button', count: 1 } },
  { shapeless: ['acacia_planks'],                     result: { name: 'acacia_button', count: 1 } },

  { shapeless: ['planks', 'planks'],                  result: { name: 'stick', count: 4 } },
  { shapeless: ['planks','planks','planks','planks'], result: { name: 'crafting_table', count: 1 } },
  { shapeless: ['sand','sand','sand','sand'],         result: { name: 'sandstone', count: 1 } },
  { shapeless: ['stone','stone','stone','stone'],     result: { name: 'stone_bricks', count: 4 } },
  { shapeless: ['diamond'],                           result: { name: 'diamond_gem', count: 9 } },
  { shapeless: ['gold'],                              result: { name: 'gold_ingot', count: 9 } },
  { shapeless: ['magic_crystal'],                     result: { name: 'magic_dust', count: 1 } },
  { shapeless: ['coal', 'stick'],                     result: { name: 'torch', count: 4 } },
  /* 羊毛 → 9 线 */
  { shapeless: ['wool'],                              result: { name: 'string', count: 9 } },
];

/* ====================== 3x3 配方 ====================== */
const RECIPES_3X3_RAW = [
  /* 床：3 羊毛 + 3 木板（任意木板，横向两排即可） */
  { shapeless: ['wool','wool','wool','planks','planks','planks'], result: { name: 'bed', count: 1 } },
  { shapeless: ['iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot'],
    result: { name: 'iron_helmet', count: 1 } },
  { shapeless: ['iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot'],
    result: { name: 'iron_chestplate', count: 1 } },
  { shapeless: ['iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot','iron_ingot'],
    result: { name: 'iron_leggings', count: 1 } },
  { shapeless: ['iron_ingot','iron_ingot','iron_ingot','iron_ingot'],
    result: { name: 'iron_boots', count: 1 } },
  /* 铜 / 金 / 钻石盔甲：与铁同形，材料不同 */
  { shapeless: Array(5).fill('copper_ingot'),
    result: { name: 'copper_helmet', count: 1 } },
  { shapeless: Array(8).fill('copper_ingot'),
    result: { name: 'copper_chestplate', count: 1 } },
  { shapeless: Array(7).fill('copper_ingot'),
    result: { name: 'copper_leggings', count: 1 } },
  { shapeless: Array(4).fill('copper_ingot'),
    result: { name: 'copper_boots', count: 1 } },
  { shapeless: Array(5).fill('gold_ingot'),
    result: { name: 'gold_helmet', count: 1 } },
  { shapeless: Array(8).fill('gold_ingot'),
    result: { name: 'gold_chestplate', count: 1 } },
  { shapeless: Array(7).fill('gold_ingot'),
    result: { name: 'gold_leggings', count: 1 } },
  { shapeless: Array(4).fill('gold_ingot'),
    result: { name: 'gold_boots', count: 1 } },
  { shapeless: Array(5).fill('diamond_gem'),
    result: { name: 'diamond_helmet', count: 1 } },
  { shapeless: Array(8).fill('diamond_gem'),
    result: { name: 'diamond_chestplate', count: 1 } },
  { shapeless: Array(7).fill('diamond_gem'),
    result: { name: 'diamond_leggings', count: 1 } },
  { shapeless: Array(4).fill('diamond_gem'),
    result: { name: 'diamond_boots', count: 1 } },
  { shapeless: ['oak_log'],    result: { name: 'oak_planks',    count: 4 } },
  { shapeless: ['spruce_log'], result: { name: 'spruce_planks', count: 4 } },
  { shapeless: ['sakura_log'], result: { name: 'sakura_planks', count: 4 } },
  { shapeless: ['birch_log'],  result: { name: 'birch_planks',  count: 4 } },
  { shapeless: ['jungle_log'], result: { name: 'jungle_planks', count: 4 } },
  { shapeless: ['acacia_log'], result: { name: 'acacia_planks', count: 4 } },
  { shapeless: ['mangrove_log'], result: { name: 'mangrove_planks', count: 4 } },

  /* 木质压力板 / 按钮（同 2x2：压力板横向两格，避开木棍配方） */
  ..._plateRecipes(3),
  ..._decoRecipes(3),
  ...MISC_RECIPES,
  { shapeless: ['oak_planks'],                        result: { name: 'oak_button', count: 1 } },
  { shapeless: ['spruce_planks'],                     result: { name: 'spruce_button', count: 1 } },
  { shapeless: ['sakura_planks'],                     result: { name: 'sakura_button', count: 1 } },
  { shapeless: ['mangrove_planks'],                   result: { name: 'mangrove_button', count: 1 } },
  { shapeless: ['birch_planks'],                      result: { name: 'birch_button', count: 1 } },
  { shapeless: ['jungle_planks'],                     result: { name: 'jungle_button', count: 1 } },
  { shapeless: ['acacia_planks'],                     result: { name: 'acacia_button', count: 1 } },

  { shapeless: ['planks', 'planks'],                  result: { name: 'stick', count: 4 } },
  { shapeless: ['planks','planks','planks','planks'], result: { name: 'crafting_table', count: 1 } },
  { shapeless: ['sand','sand','sand','sand'],         result: { name: 'sandstone', count: 1 } },
  { shapeless: ['stone','stone','stone','stone'],     result: { name: 'stone_bricks', count: 4 } },
  { shapeless: ['diamond'],                           result: { name: 'diamond_gem', count: 9 } },
  { shapeless: ['gold'],                              result: { name: 'gold_ingot', count: 9 } },
  { shapeless: ['coal', 'stick'],                     result: { name: 'torch', count: 4 } },

  /* 熔炉：8 个圆石围成一圈（中空） */
  { shape: [
      {pos:0,item:'cobble'},{pos:1,item:'cobble'},{pos:2,item:'cobble'},
      {pos:3,item:'cobble'},                      {pos:5,item:'cobble'},
      {pos:6,item:'cobble'},{pos:7,item:'cobble'},{pos:8,item:'cobble'}
    ], result: { name: 'furnace', count: 1 } },

  /* 箱子：8 个木板围成一圈（任意木板 tag） */
  { shape: [
      {pos:0,item:'planks'},{pos:1,item:'planks'},{pos:2,item:'planks'},
      {pos:3,item:'planks'},                      {pos:5,item:'planks'},
      {pos:6,item:'planks'},{pos:7,item:'planks'},{pos:8,item:'planks'}
    ], result: { name: 'chest', count: 1 } },

  /* 展台：木板/玻璃 按 1.2.1 / 2.0.2 / 1.1.1 摆放
     （1=木板 2=玻璃 0=空，中间留空） */
  { shape: [
      {pos:0,item:'planks'},{pos:1,item:'glass'},{pos:2,item:'planks'},
      {pos:3,item:'glass'},                      {pos:5,item:'glass'},
      {pos:6,item:'planks'},{pos:7,item:'planks'},{pos:8,item:'planks'}
    ], result: { name: 'magic_pedestal', count: 1 } },

  /* 剑 */
  { shape: [{pos:1,item:'planks'},{pos:4,item:'planks'},{pos:7,item:'stick'}],      result: { name: 'wood_sword', count: 1 } },
  { shape: [{pos:1,item:'stone'},{pos:4,item:'stone'},{pos:7,item:'stick'}],      result: { name: 'stone_sword', count: 1 } },
  { shape: [{pos:1,item:'copper_ingot'},{pos:4,item:'copper_ingot'},{pos:7,item:'stick'}], result: { name: 'copper_sword', count: 1 } },
  { shape: [{pos:1,item:'gold_ingot'},{pos:4,item:'gold_ingot'},{pos:7,item:'stick'}],  result: { name: 'gold_sword', count: 1 } },
  { shape: [{pos:1,item:'iron_ingot'},{pos:4,item:'iron_ingot'},{pos:7,item:'stick'}],  result: { name: 'iron_sword', count: 1 } },
  { shape: [{pos:1,item:'diamond_gem'},{pos:4,item:'diamond_gem'},{pos:7,item:'stick'}], result: { name: 'diamond_sword', count: 1 } },

  /* 镐 */
  { shape: [{pos:0,item:'planks'},{pos:1,item:'planks'},{pos:2,item:'planks'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'wood_pickaxe', count: 1 } },
  { shape: [{pos:0,item:'stone'},{pos:1,item:'stone'},{pos:2,item:'stone'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'stone_pickaxe', count: 1 } },
  { shape: [{pos:0,item:'copper_ingot'},{pos:1,item:'copper_ingot'},{pos:2,item:'copper_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'copper_pickaxe', count: 1 } },
  { shape: [{pos:0,item:'gold_ingot'},{pos:1,item:'gold_ingot'},{pos:2,item:'gold_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'gold_pickaxe', count: 1 } },
  { shape: [{pos:0,item:'iron_ingot'},{pos:1,item:'iron_ingot'},{pos:2,item:'iron_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'iron_pickaxe', count: 1 } },
  { shape: [{pos:0,item:'diamond_gem'},{pos:1,item:'diamond_gem'},{pos:2,item:'diamond_gem'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'diamond_pickaxe', count: 1 } },

  /* 斧 */
  { shape: [{pos:0,item:'planks'},{pos:1,item:'planks'},{pos:3,item:'planks'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'wood_axe', count: 1 } },
  { shape: [{pos:0,item:'stone'},{pos:1,item:'stone'},{pos:3,item:'stone'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'stone_axe', count: 1 } },
  { shape: [{pos:0,item:'copper_ingot'},{pos:1,item:'copper_ingot'},{pos:3,item:'copper_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'copper_axe', count: 1 } },
  { shape: [{pos:0,item:'gold_ingot'},{pos:1,item:'gold_ingot'},{pos:3,item:'gold_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'gold_axe', count: 1 } },
  { shape: [{pos:0,item:'iron_ingot'},{pos:1,item:'iron_ingot'},{pos:3,item:'iron_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'iron_axe', count: 1 } },
  { shape: [{pos:0,item:'diamond_gem'},{pos:1,item:'diamond_gem'},{pos:3,item:'diamond_gem'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'diamond_axe', count: 1 } },

  /* 锹 */
  { shape: [{pos:1,item:'planks'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'wood_shovel', count: 1 } },
  { shape: [{pos:1,item:'stone'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'stone_shovel', count: 1 } },
  { shape: [{pos:1,item:'copper_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'copper_shovel', count: 1 } },
  { shape: [{pos:1,item:'gold_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'gold_shovel', count: 1 } },
  { shape: [{pos:1,item:'iron_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'iron_shovel', count: 1 } },
  { shape: [{pos:1,item:'diamond_gem'},{pos:4,item:'stick'},{pos:7,item:'stick'}],  result: { name: 'diamond_shovel', count: 1 } },

  /* 锄 */
  { shape: [{pos:0,item:'planks'},{pos:1,item:'planks'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'wood_hoe', count: 1 } },
  { shape: [{pos:1,item:'planks'},{pos:2,item:'planks'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'wood_hoe', count: 1 } },
  { shape: [{pos:0,item:'stone'},{pos:1,item:'stone'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'stone_hoe', count: 1 } },
  { shape: [{pos:1,item:'stone'},{pos:2,item:'stone'},{pos:4,item:'stick'},{pos:7,item:'stick'}],       result: { name: 'stone_hoe', count: 1 } },
  { shape: [{pos:0,item:'copper_ingot'},{pos:1,item:'copper_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'copper_hoe', count: 1 } },
  { shape: [{pos:1,item:'copper_ingot'},{pos:2,item:'copper_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'copper_hoe', count: 1 } },
  { shape: [{pos:0,item:'gold_ingot'},{pos:1,item:'gold_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'gold_hoe', count: 1 } },
  { shape: [{pos:1,item:'gold_ingot'},{pos:2,item:'gold_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'gold_hoe', count: 1 } },
  { shape: [{pos:0,item:'iron_ingot'},{pos:1,item:'iron_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'iron_hoe', count: 1 } },
  { shape: [{pos:1,item:'iron_ingot'},{pos:2,item:'iron_ingot'},{pos:4,item:'stick'},{pos:7,item:'stick'}],   result: { name: 'iron_hoe', count: 1 } },
  { shape: [{pos:0,item:'diamond_gem'},{pos:1,item:'diamond_gem'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'diamond_hoe', count: 1 } },
  { shape: [{pos:1,item:'diamond_gem'},{pos:2,item:'diamond_gem'},{pos:4,item:'stick'},{pos:7,item:'stick'}], result: { name: 'diamond_hoe', count: 1 } },

  /* 剪刀 */
  { shape: [{pos:1,item:'iron_ingot'},{pos:3,item:'iron_ingot'}], result: { name: 'shears', count: 1 } },

  /* 9 线 → 羊毛 */
  { shapeless: ['string','string','string','string','string','string','string','string','string'],
    result: { name: 'wool', count: 1 } },

  /* 弓：3 木棍 + 3 线（中间那根木棍换成铁锭 = 铁弓） */
  { shape: [
      {pos:1,item:'stick'}, {pos:2,item:'string'},
      {pos:3,item:'stick'},                     {pos:5,item:'string'},
      {pos:7,item:'stick'}, {pos:8,item:'string'}
    ], result: { name: 'bow', count: 1 } },
  { shape: [
      {pos:1,item:'stick'}, {pos:2,item:'string'},
      {pos:3,item:'iron_ingot'},                 {pos:5,item:'string'},
      {pos:7,item:'stick'}, {pos:8,item:'string'}
    ], result: { name: 'iron_bow', count: 1 } },

  /* 铁桶 */
  { shape: [{pos:0,item:'iron_ingot'},{pos:1,item:'iron_ingot'},{pos:2,item:'iron_ingot'}], result: { name: 'bucket', count: 1 } },

  /* 铁门：2×3 铁锭 → 3 扇 */
  { shape: [
      {pos:0,item:'iron_ingot'},{pos:1,item:'iron_ingot'},
      {pos:3,item:'iron_ingot'},{pos:4,item:'iron_ingot'},
      {pos:6,item:'iron_ingot'},{pos:7,item:'iron_ingot'}
    ], result: { name: 'iron_door', count: 3 } },

  /* 木门（魔法门）：2×3 任意木板 → 3 扇 */
  { shape: [
      {pos:0,item:'planks'},{pos:1,item:'planks'},
      {pos:3,item:'planks'},{pos:4,item:'planks'},
      {pos:6,item:'planks'},{pos:7,item:'planks'}
    ], result: { name: 'magic_door', count: 3 } },

  /* 压缩方块：9 个材料 → 1 块（和已有的「方块 → 9 个」互逆） */
  { shapeless: ['diamond_gem','diamond_gem','diamond_gem',
                'diamond_gem','diamond_gem','diamond_gem',
                'diamond_gem','diamond_gem','diamond_gem'],
    result: { name: 'diamond', count: 1 } },
  { shapeless: ['gold_ingot','gold_ingot','gold_ingot',
                'gold_ingot','gold_ingot','gold_ingot',
                'gold_ingot','gold_ingot','gold_ingot'],
    result: { name: 'gold', count: 1 } },
];

function sortRecipes(arr){
  return arr.map(r => ({
    ...r,
    _count: r.shapeless ? r.shapeless.length : r.shape.length
  })).sort((a, b) => b._count - a._count);
}

/* ★ 改成 let，运行时可以重建 */
let RECIPES_2X2 = sortRecipes(RECIPES_2X2_RAW);
let RECIPES_3X3 = sortRecipes(RECIPES_3X3_RAW);

/* ============================================================
   ★ 运行时配方注册（mod 用）
   ============================================================ */
const _runtimeRecipes = [];

/**
 * @param {object} r  与 RECIPES_*_RAW 同格式，必须带 `size: 2|3`
 * @param {string} [source]
 * @returns {object|null}
 */
function addRuntimeRecipe(r, source){
  if (!r || typeof r !== 'object') return null;
  const item = {
    ...r,
    _count: r.shapeless ? r.shapeless.length
          : (r.shape ? r.shape.length : 0)
  };
  if (!item._count) return null;
  if (r.size !== 2 && r.size !== 3) return null;
  if (!r.result || typeof r.result.name !== 'string') return null;

  if (r.size === 2) RECIPES_2X2 = sortRecipes([...RECIPES_2X2, item]);
  else              RECIPES_3X3 = sortRecipes([...RECIPES_3X3, item]);

  _runtimeRecipes.push({ recipe: item, size: r.size, source: source || null });

  recalcCraftSilent();
  notify();
  return item;
}

/** 清空所有运行时配方，保留启动时的内置配方 */
function clearRuntimeRecipes(){
  RECIPES_2X2 = sortRecipes(RECIPES_2X2_RAW);
  RECIPES_3X3 = sortRecipes(RECIPES_3X3_RAW);
  _runtimeRecipes.length = 0;
  recalcCraftSilent();
  notify();
}

/** 查看当前所有配方 */
function listRecipes(){
  return {
    size2: RECIPES_2X2.slice(),
    size3: RECIPES_3X3.slice(),
    runtimeCount: _runtimeRecipes.length,
  };
}

/* ============================================================
   匹配逻辑
   ============================================================ */
function itemMatches(itemId, ingredient){
  if (itemId === undefined || itemId === null) return false;
  const blk = BLOCKS[itemId];
  if (!blk) return false;
  if (blk.name === ingredient) return true;
  if (blk.tag && blk.tag === ingredient) return true;
  return false;
}

function matchShapeless(grid, ingredients){
  const idxs = getActiveIndices();
  const items = [];
  for (const i of idxs){
    if (grid[i]) items.push({ slot: i, id: grid[i].id });
  }
  if (items.length !== ingredients.length) return null;

  const used = new Array(items.length).fill(false);
  const usedSlots = [];
  for (const ing of ingredients){
    let found = false;
    for (let i = 0; i < items.length; i++){
      if (used[i]) continue;
      if (itemMatches(items[i].id, ing)){
        used[i] = true;
        usedSlots.push(items[i].slot);
        found = true;
        break;
      }
    }
    if (!found) return null;
  }
  return usedSlots;
}

function matchShape(grid, layout){
  const layoutMap = new Map();
  for (const l of layout) layoutMap.set(l.pos, l.item);

  const idxs = getActiveIndices();
  for (const i of idxs){
    const item = grid[i];
    if (layoutMap.has(i)){
      if (!item) return null;
      if (!itemMatches(item.id, layoutMap.get(i))) return null;
    } else {
      if (item) return null;
    }
  }
  return [...layoutMap.keys()].sort((a, b) => a - b);
}

function recalc(){
  craftResult = null;
  const recipes = craftSize === 2 ? RECIPES_2X2 : RECIPES_3X3;
  const any = craftGrid.some(x => x);
  if (!any) return;
  for (const r of recipes){
    let usedSlots = null;
    if (r.shapeless) usedSlots = matchShapeless(craftGrid, r.shapeless);
    else if (r.shape) usedSlots = matchShape(craftGrid, r.shape);
    if (usedSlots){
      const blk = BLOCKS.find(b => b.name === r.result.name);
      if (blk){
        craftResult = { id: blk.id, count: r.result.count, usedSlots };
        return;
      }
    }
  }
}

function recalcCraft(){ recalc(); notify(); }
function recalcCraftSilent(){ recalc(); }

function setCraftSlot(slotIdx, item){
  craftGrid[slotIdx] = item;
  recalc(); notify();
}

function takeCraftResult(){
  if (!craftResult) return null;
  const out = { id: craftResult.id, count: craftResult.count };

  /* ★ 可取消：mod 在 item.craft:before 里 return true 即可拦下这次合成
     （放在扣材料之前，取消时合成格不会被消耗） */
  if (emitCancellable('item.craft:before', out.id, out.count, craftSize)) return null;

  for (const slot of craftResult.usedSlots){
    const s = craftGrid[slot];
    if (s){
      s.count -= 1;
      if (s.count <= 0) craftGrid[slot] = null;
    }
  }
  recalc(); notify();
  return out;
}

function isCraftEmpty(){
  return !craftGrid.some(x => x);
}

function dumpCraftTo(fn){
  for (let i = 0; i < 9; i++){
    if (craftGrid[i]){ fn(craftGrid[i]); craftGrid[i] = null; }
  }
  recalc(); notify();
}

/* 移动光源用：地上会发光的掉落物（海晶灯、火把、魔法豆子等） */
function getGlowDropSources(){
  const out = [];
  for (let i = 0; i < drops.length; i++){
    const d = drops[i];
    const blk = BLOCKS[d.itemId];
    if (!blk) continue;
    if (!((blk.light | 0) > 0 || blk.name === 'magic_bean' || blk.name === 'glow_arrow')) continue;
    out.push({
      pos: { x: d.mesh.position.x, y: d.mesh.position.y + 0.15, z: d.mesh.position.z },
      blk,
    });
  }
  return out;
}

/* =================================================================
   re-export
   ================================================================= */
export {
  drops, getDropCount, getGlowDropSources, spawnDrop, updateDrops, clearDrops, SMELT_SECONDS, FURNACE_STACK_MAX, furnaces, onFurnaceChange, notifyFurnace, addSmeltRecipe, removeSmeltRecipe, clearRuntimeSmelts, listSmeltRecipes, setFuelSeconds, restoreFuels, furnaceKey, getFurnace, removeFurnace, clearFurnaces, getSmeltResult, getFuelSeconds, isFuel, updateFurnaces, serializeFurnaces, deserializeFurnaces, craftGrid, craftResult, onCraftChange, getCraftSize, getActiveIndices, setCraftSize, addRuntimeRecipe, clearRuntimeRecipes, listRecipes, recalcCraft, recalcCraftSilent, setCraftSlot, takeCraftResult, isCraftEmpty, dumpCraftTo
};
