/* =================================================================
   items/bow.js — 弓与箭矢
   -----------------------------------------------------------------
   · 弓：按住右键/长按屏幕蓄力，松开发射
   · 有箭 → 消耗 1 支射出；没箭 → 空放，不提示
   · 箭矢命中实体造成伤害；没命中实体 → 落地变成可拾取的箭
   · 命中按钮/拉杆/压力板会触发机关
   ================================================================= */
import * as THREE from 'three';
import { scene, camera } from '../render/render-core.js';
import { BLOCKS, B } from '../world/blocks.js';
import { getBlockWorld } from '../world/terrain.js';
import { getAnimalAt, damageAnimal } from '../entities/entities-core.js';
import { inventory, takeFromSlot } from './items-core.js';
import { spawnDrop } from './items-logic.js';
import { pressButton, pressPressurePlate, pullLever } from '../world/magic.js';
import { playSFX } from '../audio/audio.js';
import { input } from '../player/player-core.js';
import { placeTempBlock } from '../world/temp-blocks.js';
import { highlightEntity } from '../entities/highlight.js';

const CHARGE_TIME = 1.0;      /* 满蓄力 1 秒 */
const GRAVITY = 14;           /* 箭矢重力，格/秒² */
const MAX_ARROWS = 48;
const ARROW_LIFE = 25;        /* 秒 */
const STUCK_LIFE = 60;        /* 插在物体上的箭保留时间 */

const arrows = [];
let charging = false;
let charge = 0;

let _shaftGeo = null, _headGeo = null, _featherGeo = null;
let _shaftMat = null, _headMat = null, _featherMat = null, _glowHeadMat = null;

function ensureAssets(){
  if (_shaftGeo) return;
  _shaftGeo = new THREE.BoxGeometry(0.045, 0.045, 0.78);
  _headGeo = new THREE.ConeGeometry(0.085, 0.16, 4);
  _headGeo.rotateX(Math.PI / 2);
  _featherGeo = new THREE.BoxGeometry(0.16, 0.012, 0.14);
  _shaftMat = new THREE.MeshLambertMaterial({ color: 0x8a5a2a });
  _headMat = new THREE.MeshLambertMaterial({ color: 0xc8c8d4 });
  _featherMat = new THREE.MeshLambertMaterial({ color: 0xe8e8e8 });
  /* 发光箭头：自发光材质，不受光照影响 */
  _glowHeadMat = new THREE.MeshBasicMaterial({ color: 0xb8ffd0 });
}

export function isBowItem(blk){
  return !!(blk && blk.toolType === 'bow');
}

/** 优先用发光箭矢，没有再用普通箭 */
function findArrowSlot(){
  let normal = -1, glow = -1;
  for (let i = 0; i < inventory.length; i++){
    const it = inventory[i];
    if (!it || (it.count || 0) <= 0) continue;
    if (it.id === B.glow_arrow.id) glow = i;
    else if (it.id === B.arrow.id && normal < 0) normal = i;
  }
  if (glow >= 0) return { idx: glow, glow: true };
  if (normal >= 0) return { idx: normal, glow: false };
  return null;
}

function resetCharge(){
  charging = false;
  charge = 0;
}

/* 每帧调用。返回 true 表示这一帧的"使用/放置"输入已被弓吃掉。 */
export function updateBow(dt, useHeld, uiOpen, slot){
  const held = slot ? BLOCKS[slot.id] : null;
  const bow = isBowItem(held) ? held : null;
  input.bowEquipped = !!bow;

  if (!bow){
    resetCharge();
    input.bowRelease = false;
    return false;
  }
  if (uiOpen){
    resetCharge();
    input.bowRelease = false;
    return true;
  }

  if (input.bowRelease){
    input.bowRelease = false;
    fire(bow, charge);
    resetCharge();
    return true;
  }

  const use = !!useHeld || !!input.bowHold;
  if (use){
    charging = true;
    charge = Math.min(1, charge + dt / CHARGE_TIME);
    return true;
  }
  if (charging){
    fire(bow, charge);
    resetCharge();
    return true;
  }
  return false;
}

function fire(bow, power){
  power = Math.max(0.15, Math.min(1, power));
  playSFX('bow');
  const ammo = findArrowSlot();
  if (!ammo) return;               /* 空射：没有箭就不生成实体，也不提示 */

  takeFromSlot(ammo.idx, 1);
  const iron = bow.name === 'iron_bow';
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  const start = camera.position.clone().addScaledVector(dir, 0.55);
  start.y -= 0.08;

  const speed = (9 + 17 * power) * (iron ? 1.12 : 1);
  /* 伤害整体下调：满蓄力木弓 3.8，铁弓 4.7 */
  const dmg = 0.6 + 3.2 * power + (iron ? 0.9 : 0);
  spawnArrow(start, dir.clone().multiplyScalar(speed), dmg, ammo.glow);
}

function spawnArrow(pos, vel, dmg, glow){
  ensureAssets();
  while (arrows.length >= MAX_ARROWS) removeArrow(arrows[0], false);

  const g = new THREE.Group();
  const shaft = new THREE.Mesh(_shaftGeo, _shaftMat);

  const head = new THREE.Mesh(_headGeo, glow ? _glowHeadMat : _headMat);
  head.position.z = 0.44;

  const f1 = new THREE.Mesh(_featherGeo, _featherMat);
  f1.position.z = -0.34; f1.rotation.z = Math.PI / 2;
  const f2 = f1.clone();
  f2.rotation.z = 0;

  g.add(shaft, head, f1, f2);
  g.position.copy(pos);
  scene.add(g);

  const obj = {
    alive: true, pos: pos.clone(), vel: vel.clone(),
    dmg, life: ARROW_LIFE, obj: g, glow: !!glow,
    stuck: false, stuckEntity: null, stuckOffset: null,
    dir: vel.clone().normalize(),
  };
  arrows.push(obj);
  orient(obj);
  return obj;
}

function orient(a){
  const dir = a.dir ? a.dir.clone() : a.vel.clone();
  if (dir.lengthSq() < 1e-8) return;
  dir.normalize();
  a.obj.quaternion.setFromUnitVectors(_UP, dir);
}

const _UP = new THREE.Vector3(0, 0, 1);

function isTrigger(name){
  return name === 'magic_button' || name === 'magic_button_on' ||
         name === 'magic_lever' || name === 'magic_lever_on' ||
         name === 'magic_pressure_plate' || name === 'magic_pressure_plate_on';
}

function triggerBlock(name, x, y, z){
  if (name === 'magic_button' || name === 'magic_button_on') pressButton(x, y, z);
  else if (name === 'magic_lever' || name === 'magic_lever_on') pullLever(x, y, z);
  else pressPressurePlate(x, y, z, 1.0);
}

function removeArrow(a, dropAt){
  if (!a.alive) return;
  a.alive = false;
  scene.remove(a.obj);
  const i = arrows.indexOf(a);
  if (i >= 0) arrows.splice(i, 1);
  if (dropAt){
    spawnDrop(dropAt.x, dropAt.y, dropAt.z, a.glow ? B.glow_arrow.id : B.arrow.id, 1);
  }
}

export function updateArrows(dt){
  for (let i = arrows.length - 1; i >= 0; i--){
    const a = arrows[i];
    if (!a.alive) continue;

    a.life -= dt;
    if (a.life <= 0){ removeArrow(a, a.stuck ? a.pos : false); continue; }

    /* 已插在实体/方块上：不再飞行，实体上的箭跟着实体移动 */
    if (a.stuck){
      const e = a.stuckEntity;
      if (e && !e.dead && !e.dormant && e.pos && a.stuckOffset){
        a.pos.copy(e.pos).add(a.stuckOffset);
        a.obj.position.copy(a.pos);
      }
      continue;
    }

    let remain = Math.min(dt, 0.1);
    while (remain > 0 && a.alive){
      const step = Math.min(remain, 0.1);
      remain -= step;

      a.vel.y -= GRAVITY * step;
      const prev = a.pos.clone();
      const delta = a.vel.clone().multiplyScalar(step);
      const len = delta.length();
      if (len < 1e-6) continue;
      const dir = delta.clone().multiplyScalar(1 / len);
      a.dir = dir.clone();

      /* 实体：插在实体身上，体现“中箭” */
      const hitInfo = {};
      const hit = getAnimalAt(prev, dir, len + 0.06, hitInfo);
      if (hit){
        damageAnimal(hit, a.dmg, 'arrow');
        playSFX('arrow.hit');
        /* ★ 发光箭矢命中实体 → 实体高亮 */
        if (a.glow) highlightEntity(hit, 3);
        const t = Math.min(Math.max(hitInfo.t || 0, 0), len);
        const impact = prev.clone().addScaledVector(dir, Math.max(0, t - 0.03));
        a.pos.copy(impact);
        a.obj.position.copy(impact);
        a.vel.set(0, 0, 0);
        a.stuck = true;
        a.stuckEntity = hit;
        a.stuckOffset = impact.clone().sub(hit.pos);
        a.life = Math.max(a.life, STUCK_LIFE);
        break;
      }

      const next = prev.clone().add(delta);
      const bx = Math.floor(next.x), by = Math.floor(next.y), bz = Math.floor(next.z);
      const blk = BLOCKS[getBlockWorld(bx, by, bz)];

      if (blk && blk.name !== 'air' && !blk.liquid){
        const trig = isTrigger(blk.name);
        if (trig) triggerBlock(blk.name, bx, by, bz);
        if (trig || blk.solid || blk.model){
          playSFX('arrow.hit');
          /* ★ 发光箭矢落地：留下一个 60 秒的小光粒 */
          if (a.glow){
            placeTempBlock(
              Math.floor(prev.x), Math.floor(prev.y), Math.floor(prev.z),
              B.glow_light.id, 60
            );
          }
          /* 命中方块：停在方块表面，体现“射中” */
          a.pos.copy(prev);
          a.obj.position.copy(prev);
          a.vel.set(0, 0, 0);
          a.stuck = true;
          a.life = Math.max(a.life, STUCK_LIFE);
          break;
        }
      }

      a.pos.copy(next);
      if (a.pos.y < -100){ removeArrow(a, false); break; }
    }

    if (a.alive){ a.obj.position.copy(a.pos); orient(a); }
  }
}

/* 切存档/回菜单时清空 */
export function clearArrows(){
  for (const a of arrows.slice()) removeArrow(a, false);
  resetCharge();
}

export function getArrowCount(){ return arrows.length; }

/** 给动态光源用：飞行中的发光箭矢 */
export function getGlowArrowSources(){
  const out = [];
  for (let i = 0; i < arrows.length; i++){
    const a = arrows[i];
    if (!a.alive || !a.glow || a.stuck) continue;
    out.push({ pos: a.pos, blk: BLOCKS[B.glow_arrow.id] });
  }
  return out;
}
