/* ============================================================
   staff.js —— 石头法杖：右键发射石块，耐久消耗快
   ============================================================ */

import * as THREE from 'three';
import { camera, scene } from '../render/render-core.js';
import { getBlockWorld } from '../world/terrain.js';
import { BLOCKS } from '../world/blocks.js';
import { getAnimalAt, damageAnimal } from '../entities/entities-core.js';
import { takeFromSlot, notifyInventory } from './items-core.js';
import { toast } from '../ui/ui.js';

const SHOT_CD = 0.55;
const DURA_COST = 5;
const SHOT_SPEED = 19;
const SHOT_DMG = 4.5;
const SHOT_LIFE = 2.6;
const GRAVITY = 11;
const MAX_ROCKS = 16;

const rocks = [];
let cd = 0;
let prevUse = false;
let _geo = null, _mat = null;

function ensureAssets(){
  if (_geo) return;
  _geo = new THREE.DodecahedronGeometry(0.19, 0);
  _mat = new THREE.MeshLambertMaterial({ color: 0x8b9098 });
}

function removeRock(r, dropAt){
  if (!r.alive) return;
  r.alive = false;
  scene.remove(r.obj);
  const i = rocks.indexOf(r);
  if (i >= 0) rocks.splice(i, 1);
}

function spawnRock(start, dir){
  ensureAssets();
  while (rocks.length >= MAX_ROCKS) removeRock(rocks[0]);

  const mesh = new THREE.Mesh(_geo, _mat);
  mesh.position.copy(start);
  scene.add(mesh);

  const r = {
    alive: true,
    pos: start.clone(),
    vel: dir.clone().multiplyScalar(SHOT_SPEED),
    dmg: SHOT_DMG,
    life: SHOT_LIFE,
    obj: mesh,
  };
  rocks.push(r);
  return r;
}

function consumeStaff(slot, slotIndex){
  if (!slot) return;
  if (typeof slot.durability !== 'number'){
    slot.durability = slot.maxDurability || 90;
    slot.maxDurability = slot.maxDurability || 90;
  }
  slot.durability -= DURA_COST;
  if (slot.durability <= 0){
    takeFromSlot(slotIndex, 1);
    toast('石头法杖已损坏');
  }
  notifyInventory();
}

/* 每帧调用。返回 true 表示这一帧的“使用/放置”输入已被法杖吃掉。 */
export function updateStaff(dt, useHeld, uiOpen, slot, slotIndex){
  const blk = slot ? BLOCKS[slot.id] : null;
  const isStaff = !!(blk && blk.toolType === 'staff');
  const prev = prevUse;
  prevUse = !!useHeld;
  if (cd > 0) cd -= dt;
  if (!isStaff) return false;
  if (uiOpen) return true;

  /* 上升沿触发，避免按住右键时无限连发 */
  if (!useHeld || prev || cd > 0) return true;

  cd = SHOT_CD;
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  const start = camera.position.clone().addScaledVector(dir, 0.6);
  spawnRock(start, dir);

  const invIdx = typeof slotIndex === 'number' ? slotIndex : -1;
  consumeStaff(slot, invIdx);
  return true;
}

export function updateStoneProjectiles(dt){
  for (let i = rocks.length - 1; i >= 0; i--){
    const r = rocks[i];
    if (!r.alive) continue;

    r.life -= dt;
    if (r.life <= 0){ removeRock(r, false); continue; }

    let remain = Math.min(dt, 0.08);
    while (remain > 0 && r.alive){
      const step = Math.min(remain, 0.04);
      remain -= step;

      r.vel.y -= GRAVITY * step;
      const prev = r.pos.clone();
      const delta = r.vel.clone().multiplyScalar(step);
      const len = delta.length();
      if (len < 1e-6) continue;
      const dir = delta.clone().multiplyScalar(1 / len);

      const hit = getAnimalAt(prev, dir, len + 0.1, {});
      if (hit){
        damageAnimal(hit, r.dmg, 'staff');
        removeRock(r, false);
        break;
      }

      const next = prev.clone().add(delta);
      const bx = Math.floor(next.x), by = Math.floor(next.y), bz = Math.floor(next.z);
      const b = BLOCKS[getBlockWorld(bx, by, bz)];
      if (b && b.name !== 'air' && !b.liquid && (b.solid || b.model)){
        removeRock(r, false);
        break;
      }

      r.pos.copy(next);
      if (r.pos.y < -100){ removeRock(r, false); break; }
      r.obj.position.copy(r.pos);
      r.obj.rotation.x += step * 9;
      r.obj.rotation.y += step * 7;
    }
  }
}

/* 切存档时清空 */
export function clearStoneProjectiles(){
  for (const r of rocks.slice()) removeRock(r, false);
}
