/* ============================================================
   items-core.js —— 背包数据 + 箱子（方块实体）
   ------------------------------------------------------------
★ 合并自两个小文件：
     inventory.js  36 格背包数组 + addItem/takeFromSlot（1.9KB）
     chest.js      箱子数据模型 + 每箱一个文件的读写（12KB）
   两者都只是"物品在哪儿"的数据层，UI 在 ui.js。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import { BLOCKS, B } from '../world/blocks.js';
import { INV_SIZE, STACK_MAX } from './../core/engine-core.js';
import { emit } from './../core/engine-core.js';
import { getActiveDimensionId } from './../world/world-registry.js';
import { readSaveJson, writeSaveJson, deleteSavePath } from './../save/save-core.js';


/* =================================================================
   inventory.js
   ================================================================= */
const inventory = new Array(INV_SIZE).fill(null);

const iv_listeners = [];
function onInventoryChange(fn){ iv_listeners.push(fn); }
function notifyInventory(){ iv_listeners.forEach(fn => fn()); }

function getMaxStack(id){
  const blk = BLOCKS[id];
  return blk && blk.maxStack !== undefined ? blk.maxStack : STACK_MAX;
}

function makeItem(id, count, meta){
  const blk = BLOCKS[id];
  const item = { id, count };
  if (blk && blk.maxStack === 1 && blk.durability > 0){
    item.durability = blk.durability;
    item.maxDurability = blk.durability;
  }
  if (meta !== undefined && meta !== null) item.meta = meta;
  return item;
}

function addItem(id, count, meta){
  if (count <= 0) return true;
  const maxStack = getMaxStack(id);
  const isTool = maxStack === 1;
  /* ★ meta 存在时只和相同 meta 的格子合并 */
  const metaKey = (meta !== undefined && meta !== null)
    ? JSON.stringify(meta) : null;

  // 尝试叠加（工具不叠加）
  if (!isTool){
    for (let i = 0; i < INV_SIZE; i++){
      const s = inventory[i];
      if (!s || s.id !== id || s.count >= maxStack) continue;
      const sKey = s.meta ? JSON.stringify(s.meta) : null;
      if (sKey !== metaKey) continue;
      const add = Math.min(maxStack - s.count, count);
      s.count += add; count -= add;
      if (count <= 0){ notifyInventory(); return true; }
    }
  }

  // 放入空格
  for (let i = 0; i < INV_SIZE; i++){
    if (!inventory[i]){
      if (isTool){
        inventory[i] = makeItem(id, 1, meta);
        count--;
      } else {
        const add = Math.min(maxStack, count);
        inventory[i] = { id, count: add };
        if (metaKey !== null) inventory[i].meta = meta;
        count -= add;
      }
      if (count <= 0){ notifyInventory(); return true; }
    }
  }
  notifyInventory();
  return count <= 0;
}

/* 只检查能否放下，不改背包、不刷新 UI（掉落物每帧调用用） */
export function canAddItem(id, count, meta){
  if (count <= 0) return true;
  const maxStack = getMaxStack(id);
  const isTool = maxStack === 1;
  const metaKey = (meta !== undefined && meta !== null)
    ? JSON.stringify(meta) : null;

  let need = count;
  if (!isTool){
    for (let i = 0; i < INV_SIZE; i++){
      const s = inventory[i];
      if (!s || s.id !== id || s.count >= maxStack) continue;
      const sKey = s.meta ? JSON.stringify(s.meta) : null;
      if (sKey !== metaKey) continue;
      need -= Math.min(maxStack - s.count, need);
      if (need <= 0) return true;
    }
  }

  for (let i = 0; i < INV_SIZE; i++){
    if (!inventory[i]){
      need -= isTool ? 1 : maxStack;
      if (need <= 0) return true;
    }
  }
  return false;
}

function takeFromSlot(slot, n){
  const s = inventory[slot];
  if (!s || s.count < n) return false;
  s.count -= n;
  if (s.count <= 0) inventory[slot] = null;
  notifyInventory();
  return true;
}

function clearInventory(){
  for (let i = 0; i < INV_SIZE; i++) inventory[i] = null;
  notifyInventory();
}

/* =================================================================
   chest.js
   ================================================================= */
/* ============================================================
   chest.js —— 箱子（方块实体）：数据模型 + 每箱一个文件的读写
   ------------------------------------------------------------
   设计（与熔炉的"一个大 furnaces.json"不同）：
     · 每个箱子在存档里是【自己一个文件】：
           saves/<saveId>/chests/<dim>/<x>_<y>_<z>.json
     · 打开箱子时按需读这一个文件（懒加载），关闭时只写自己。
       好处：存档里有几百个箱子也不会拖慢保存，也不会因为
             一个文件损坏而丢掉所有箱子。
     · 内容用【方块名】序列化，不是数字 id —— mod 增删方块导致 id
       漂移时，老存档里的箱子内容仍然能对上。

   本模块只管数据，不管 UI；UI 在 src/ui/ui.js。
   ============================================================ */






const CHEST_SIZE = 27;          /* 9 x 3 */
const CHEST_STACK_MAX = STACK_MAX;
const CHEST_FILE_VERSION = 1;

/* ============================================================
   状态
   ============================================================ */
let _saveId = null;

/**
 * key -> rec
 * rec = {
 *   x, y, z, dim,
 *   slots: Array(CHEST_SIZE),
 *   loaded: bool,       已从磁盘读过（或确认没有文件）
 *   dirty: bool,        有未落盘的改动
 *   pending: Promise,   正在读盘
 *   writing: Promise,   写盘队列（串行，避免同箱并发写）
 * }
 */
const chests = new Map();

/* ---- 变更通知（UI 用，不是事件总线） ---- */
const ch_listeners = [];
function onChestChange(fn){ ch_listeners.push(fn); }
function notifyChest(){
  for (const fn of ch_listeners){ try { fn(); } catch(e){} }
}

/* ============================================================
   路径 / 坐标
   ============================================================ */
function toCoord(v){
  const n = Math.floor(Number(v));
  return Number.isFinite(n) ? n : 0;
}

function chestKey(x, y, z, dim){
  return (dim || getActiveDimensionId()) + '|' +
         toCoord(x) + ',' + toCoord(y) + ',' + toCoord(z);
}

function chestRelPath(x, y, z, dim){
  const d = dim || getActiveDimensionId();
  return `chests/${d}/${toCoord(x)}_${toCoord(y)}_${toCoord(z)}.json`;
}

/* ============================================================
   存档绑定
   ============================================================ */
function setChestSaveId(saveId){
  const id = saveId || null;
  if (id === _saveId) return;
  _saveId = id;
  chests.clear();
}

function getChestSaveId(){ return _saveId; }

/** 换世界/退出时清空内存里的箱子（未落盘的改动会丢，所以先 flushAllChests） */
function clearChests(){
  chests.clear();
}

/* ============================================================
   栈的序列化
   ============================================================ */
function encodeStack(s){
  if (!s || !s.count || s.count <= 0) return null;
  const blk = BLOCKS[s.id];
  if (!blk) return null;
  const out = { n: blk.name, c: Math.min(CHEST_STACK_MAX * 64, Math.floor(s.count)) };
  if (typeof s.durability === 'number'){
    out.d = Math.max(0, Math.floor(s.durability));
    if (typeof s.maxDurability === 'number') out.m = Math.floor(s.maxDurability);
  }
  return out;
}

function decodeStack(r){
  if (!r || typeof r !== 'object') return null;
  const count = Math.floor(Number(r.c != null ? r.c : r.count));
  if (!Number.isFinite(count) || count <= 0) return null;

  /* ★ 优先按方块名解析；兼容早期可能存的数字 id */
  let blk = (typeof r.n === 'string') ? B[r.n] : null;
  if (!blk && typeof r.id === 'number') blk = BLOCKS[r.id];
  if (!blk){
    console.warn('[chest] 未知物品，已跳过:', r.n || r.id);
    return null;
  }

  const maxStack = blk.maxStack || CHEST_STACK_MAX;
  const item = { id: blk.id, count: Math.min(count, Math.max(1, maxStack)) };
  if (typeof r.d === 'number'){
    item.durability = Math.max(0, Math.floor(r.d));
    item.maxDurability = (typeof r.m === 'number')
      ? Math.max(1, Math.floor(r.m))
      : (blk.durability || 1);
  }
  return item;
}

/* ============================================================
   记录创建
   ============================================================ */
function _newRec(x, y, z, dim){
  return {
    x: toCoord(x), y: toCoord(y), z: toCoord(z),
    dim: dim || getActiveDimensionId(),
    slots: new Array(CHEST_SIZE).fill(null),
    loaded: false, dirty: false, pending: null, writing: null,
  };
}

/** 取内存记录（没有就建一个空壳，但不会读盘） */
function getChest(x, y, z, dim){
  const key = chestKey(x, y, z, dim);
  let rec = chests.get(key);
  if (!rec){
    rec = _newRec(x, y, z, dim);
    chests.set(key, rec);
  }
  return rec;
}

function hasChestLoaded(x, y, z, dim){
  const rec = chests.get(chestKey(x, y, z, dim));
  return !!(rec && rec.loaded);
}

/* ============================================================
   读盘
   ============================================================ */
/**
 * 确保箱子内容已从磁盘读入内存。
 * 幂等：正在读就复用同一个 Promise；已读完直接返回。
 * @returns {Promise<object>} rec
 */
async function loadChest(x, y, z, dim){
  const rec = getChest(x, y, z, dim);
  if (rec.loaded) return rec;
  if (rec.pending) return await rec.pending;

  rec.pending = (async () => {
    if (_saveId){
      try {
        const data = await readSaveJson(_saveId, chestRelPath(rec.x, rec.y, rec.z, rec.dim));
        if (data && Array.isArray(data.slots)){
          for (let i = 0; i < CHEST_SIZE; i++){
            rec.slots[i] = decodeStack(data.slots[i]);
          }
          rec.v = data.v || CHEST_FILE_VERSION;
        }
      } catch(e){
        console.warn('[chest] 读取失败，按空箱子处理:', e && e.message);
      }
    }
    rec.loaded = true;
    rec.dirty = false;
    rec.pending = null;
    notifyChest();
    return rec;
  })();

  return await rec.pending;
}

/* ============================================================
   写盘
   ============================================================ */
function _snapshot(rec){
  const slots = new Array(CHEST_SIZE).fill(null);
  for (let i = 0; i < CHEST_SIZE; i++) slots[i] = encodeStack(rec.slots[i]);
  return {
    v: CHEST_FILE_VERSION,
    x: rec.x, y: rec.y, z: rec.z, dim: rec.dim,
    slotCount: CHEST_SIZE,
    savedAt: Date.now(),
    slots,
  };
}

async function _doWrite(rec, force){
  if (!_saveId) return false;
  /* ★ 箱子已经被挖掉了：绝不能再把文件写回来 */
  if (rec.removed) return false;
  /* 没读过就写，会把磁盘上的内容覆盖成空 —— 绝对不行 */
  if (!rec.loaded && !force) return false;
  if (!rec.dirty && !force) return true;

  const payload = _snapshot(rec);
  rec.dirty = false;              /* 先清脏；写盘期间再改会重新置脏 */
  try {
    await writeSaveJson(_saveId, chestRelPath(rec.x, rec.y, rec.z, rec.dim), payload);
    return true;
  } catch(e){
    rec.dirty = true;
    console.warn('[chest] 写盘失败:', e && e.message);
    return false;
  }
}

/**
 * 把某个箱子落盘（没有改动就跳过）。
 * 同一箱子的多次调用会串行排队。
 */
function saveChest(x, y, z, dim, opts){
  const rec = chests.get(chestKey(x, y, z, dim));
  if (!rec) return Promise.resolve(false);
  const force = !!(opts && opts.force);
  rec.writing = (rec.writing || Promise.resolve(true))
    .then(() => _doWrite(rec, force))
    .catch(() => false);
  return rec.writing;
}

/** 标记有改动（不立即写盘，关闭时统一写） */
function touchChest(x, y, z, dim){
  const rec = chests.get(chestKey(x, y, z, dim));
  if (rec) rec.dirty = true;
}

/** 把内存里所有脏箱子写盘（存档时调用） */
async function flushAllChests(){
  /* 先等排队中的写盘做完，避免同一箱子的两次写互相覆盖 */
  const pending = [];
  for (const rec of chests.values()){ if (rec && rec.writing) pending.push(rec.writing); }
  if (pending.length) await Promise.all(pending);

  const tasks = [];
  for (const rec of chests.values()){
    if (!rec || !rec.dirty) continue;
    tasks.push(_doWrite(rec, false));
  }
  if (!tasks.length) return 0;
  let ok = 0;
  for (const r of await Promise.all(tasks)){ if (r) ok++; }
  return ok;
}

/* ============================================================
   破坏箱子
   ============================================================ */
/**
 * 挖掉一个箱子：读出内容并删掉它的文件。
 * 即使本会话没打开过，也会先读盘，保证内容不丢。
 * @returns {Promise<Array>} 箱子里的物品
 */
async function removeChest(x, y, z, dim){
  /* ★ 先把它读进内存（没读过就写会把磁盘内容覆盖成空） */
  const rec = await loadChest(x, y, z, dim);

  /* ★ 等排队的写盘做完，否则"删除文件"之后那次迟到的写会把文件又写回来，
     然后放下一个新箱子在同一个坐标就会"复活"旧内容 */
  if (rec.writing){
    try { await rec.writing; } catch(e){}
  }

  const items = rec.slots.filter(s => s && s.count > 0).map(s => ({ ...s }));

  const key = chestKey(x, y, z, dim);
  rec.removed = true;          /* 标记作废：之后任何 saveChest/touchChest 都空转 */
  rec.dirty = false;
  chests.delete(key);

  if (_saveId){
    try { await deleteSavePath(_saveId, chestRelPath(x, y, z, dim)); }
    catch(e){ console.warn('[chest] 删除文件失败:', e && e.message); }
  }
  notifyChest();
  return items;
}

/* ============================================================
   内容操作（供 UI / mod 调用）
   ============================================================ */
/** 往箱子里塞物品，返回没塞进去的数量 */
function addToChest(rec, id, count){
  if (!rec || !count || count <= 0) return 0;
  const blk = BLOCKS[id];
  if (!blk) return count;
  const maxStack = blk.maxStack || CHEST_STACK_MAX;
  let left = count;

  if (maxStack > 1){
    for (let i = 0; i < CHEST_SIZE && left > 0; i++){
      const s = rec.slots[i];
      if (s && s.id === id && s.count < maxStack){
        const add = Math.min(maxStack - s.count, left);
        s.count += add; left -= add;
      }
    }
  }
  for (let i = 0; i < CHEST_SIZE && left > 0; i++){
    if (rec.slots[i]) continue;
    const add = Math.min(maxStack, left);
    rec.slots[i] = { id, count: add };
    left -= add;
  }
  if (left !== count) rec.dirty = true;
  return left;
}

function chestItemCount(rec){
  if (!rec) return 0;
  let n = 0;
  for (const s of rec.slots){ if (s && s.count > 0) n++; }
  return n;
}

function clearChestMemory(x, y, z, dim){
  chests.delete(chestKey(x, y, z, dim));
}

/* ============================================================
   事件广播（mod 可监听）
   ============================================================ */
function emitChestOpened(x, y, z, dim){
  emit('chest.open', toCoord(x), toCoord(y), toCoord(z), dim || getActiveDimensionId());
}
function emitChestClosed(x, y, z, dim){
  emit('chest.close', toCoord(x), toCoord(y), toCoord(z), dim || getActiveDimensionId());
}

/* ============================================================
   调试统计
   ============================================================ */
function chestStats(){
  let loaded = 0, dirty = 0;
  for (const rec of chests.values()){
    if (rec.loaded) loaded++;
    if (rec.dirty) dirty++;
  }
  return { tracked: chests.size, loaded, dirty, saveId: _saveId };
}

/* =================================================================
   re-export
   ================================================================= */
/* ============================================================
   供 mod 使用：整箱读写
   ============================================================ */
function _normalizeChestItem(item){
  if (!item) return null;
  const id = (typeof item === 'string')
    ? (B[item] ? B[item].id : null)
    : (item.id != null ? item.id : (item.name && B[item.name] ? B[item.name].id : null));
  if (id == null || !BLOCKS[id]) return null;
  const count = Math.max(1, Math.floor(Number(item.count) || 1));
  return { id, count };
}

/** 读取箱子内容，返回长度 CHEST_SIZE 的数组（空槽为 null） */
async function getChestItems(x, y, z, dim){
  const rec = await loadChest(x, y, z, dim);
  return rec.slots.map(s => (s && s.count > 0) ? { ...s } : null);
}

/**
 * 写入箱子内容。
 * @param {Array} items [{name|id, count}]，按顺序填槽
 * @param {object} opts { merge:true } 时追加而不是清空
 */
async function setChestItems(x, y, z, items, dim, opts){
  const rec = await loadChest(x, y, z, dim);
  if (!(opts && opts.merge)){
    rec.slots.fill(null);
  }
  for (const raw of (items || [])){
    const it = _normalizeChestItem(raw);
    if (!it) continue;
    addToChest(rec, it.id, it.count);
  }
  rec.loaded = true;
  rec.dirty = true;
  notifyChest();
  await saveChest(x, y, z, dim, { force: true });
  return true;
}

export {
  inventory, onInventoryChange, notifyInventory, addItem, takeFromSlot, clearInventory, CHEST_SIZE, CHEST_STACK_MAX, CHEST_FILE_VERSION, onChestChange, notifyChest, chestKey, setChestSaveId, getChestSaveId, clearChests, getChest, hasChestLoaded, loadChest, saveChest, touchChest, flushAllChests, removeChest, addToChest, chestItemCount, clearChestMemory, emitChestOpened, emitChestClosed, chestStats, getChestItems, setChestItems
};
