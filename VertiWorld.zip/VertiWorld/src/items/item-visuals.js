/* ============================================================
   item-visuals.js —— 物品图标 + 掉落物外观
   ------------------------------------------------------------
   · 背包 / 快捷栏图标：
       方块画成等轴测 3D 小方块（MC 背包里的方块图标就是 3D 的），
       纯物品（isItem）以及花草、火把、楼梯等非整方块仍用平面图。
   · 掉落物：
       方块（含 model 自定义盒模型）用真 3D 小模型；
       纯物品用旋转的平面贴图（MC 的掉落物也是这样转的）。
   · 图集刷新时清空图标缓存，贴图重画后图标不会继续用旧图。
   ============================================================ */

import * as THREE from 'three';
import { BLOCKS } from '../world/blocks.js';
import { ATLAS_TILE, ATLAS_COLS, TEX_INNER, TEX_PAD } from '../core/engine-core.js';
import {
  atlasCanvasEl, atlasTexture, onAtlasChanged, UVRECT,
} from '../world/textures.js';

/* 图标画布分辨率。格子最大约 48px，64 已经够清晰；CSS 用 pixelated 缩放 */
const ICON_PX = 64;

/* 默认群系色：图标和掉落物不在具体群系里，用主世界平原色兜底 */
const DEFAULT_GRASS_TINT = 0x91bd59;
const DEFAULT_FOLIAGE_TINT = 0x77ab2f;

const iconURLCache = new Map();       /* itemId -> dataURL */
const tileCanvasCache = new Map();    /* tileIdx -> 16×16 canvas */
const tintCanvasCache = new Map();    /* tileIdx + tint -> 16×16 canvas */
const shadeCanvasCache = new Map();   /* tileIdx + shade -> 16×16 canvas */

onAtlasChanged(() => {
  iconURLCache.clear();
  tileCanvasCache.clear();
  tintCanvasCache.clear();
  shadeCanvasCache.clear();
});

function srgbToLinear(c){
  return c < 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function linearToSrgb(c){
  return c < 0.0031308 ? c * 12.92 : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
}

/* 与 mesh-builder 一致：草方块只染顶面，树叶/十字草六面全染 */
function tintModeOf(blk){
  if (!blk || !blk.tint) return 0;
  if (blk.cross || blk.isLeaves || blk.flatRender || blk.tint === 'foliage') return 2;
  if (blk.tint === 'grass') return 1;
  return 0;
}
function tintOf(blk){
  if (!blk || !blk.tint) return 0;
  if (blk.tint === 'grass') return DEFAULT_GRASS_TINT;
  if (blk.tint === 'foliage') return DEFAULT_FOLIAGE_TINT;
  return 0;
}

/* ============================================================
   图集取样
   ============================================================ */
function getTileCanvas(tileIdx){
  if (!(tileIdx >= 0) || !atlasCanvasEl || !atlasCanvasEl.getContext) return null;
  let c = tileCanvasCache.get(tileIdx);
  if (c) return c;

  c = document.createElement('canvas');
  c.width = c.height = TEX_INNER;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const col = tileIdx % ATLAS_COLS;
  const row = Math.floor(tileIdx / ATLAS_COLS);
  ctx.drawImage(
    atlasCanvasEl,
    col * ATLAS_TILE + TEX_PAD, row * ATLAS_TILE + TEX_PAD, TEX_INNER, TEX_INNER,
    0, 0, TEX_INNER, TEX_INNER
  );
  tileCanvasCache.set(tileIdx, c);
  return c;
}

/* 按群系色染色一份贴图（贴图本身是灰白的，和世界里一样需要乘色） */
function getTintedTile(tileIdx, tint){
  if (!tint) return getTileCanvas(tileIdx);
  const key = tileIdx + ':' + tint;
  let c = tintCanvasCache.get(key);
  if (c) return c;

  const src = getTileCanvas(tileIdx);
  if (!src) return null;
  c = document.createElement('canvas');
  c.width = c.height = TEX_INNER;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(src, 0, 0);

  const cr = srgbToLinear(((tint >> 16) & 255) / 255);
  const cg = srgbToLinear(((tint >> 8) & 255) / 255);
  const cb = srgbToLinear((tint & 255) / 255);
  const img = ctx.getImageData(0, 0, TEX_INNER, TEX_INNER);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4){
    if (d[i + 3] === 0) continue;
    d[i]     = linearToSrgb(srgbToLinear(d[i] / 255) * cr) * 255;
    d[i + 1] = linearToSrgb(srgbToLinear(d[i + 1] / 255) * cg) * 255;
    d[i + 2] = linearToSrgb(srgbToLinear(d[i + 2] / 255) * cb) * 255;
  }
  ctx.putImageData(img, 0, 0);
  tintCanvasCache.set(key, c);
  return c;
}

/* 预先压暗一份贴图（避免在等轴测变换里用 fillRect，把透明像素涂黑） */
function shadeCanvas(src, cacheKey, shade){
  if (shade <= 0 || !src) return src;
  let c = shadeCanvasCache.get(cacheKey);
  if (c) return c;

  c = document.createElement('canvas');
  c.width = c.height = TEX_INNER;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(src, 0, 0);
  ctx.globalCompositeOperation = 'source-atop';
  ctx.fillStyle = `rgba(0,0,0,${shade})`;
  ctx.fillRect(0, 0, TEX_INNER, TEX_INNER);
  shadeCanvasCache.set(cacheKey, c);
  return c;
}
function getShadedTile(tileIdx, shade, tint){
  return shadeCanvas(getTintedTile(tileIdx, tint), `t${tileIdx}:${tint}:${shade}`, shade);
}

function getIconTile(blk){
  return (blk.icon != null) ? blk.icon : blk.tiles[2];
}

/* ============================================================
   背包图标：等轴测 3D 方块
   ------------------------------------------------------------
   只给"整方块 / 半砖"用。自定义盒模型和楼梯由下面的
   drawIsoModel / drawIsoStair 画成立体图标，其余保持平面图。
   ============================================================ */
function wantsCubeIcon(blk){
  if (!blk) return false;
  if (blk.isItem || blk.cross || blk.flatRender || blk.invisible) return false;
  if (blk.model || blk.stair) return false;
  return true;
}

function wantsModelIcon(blk){
  if (!blk || !blk.model || !blk.model.boxes || !blk.model.boxes.length) return false;
  if (blk.isItem || blk.cross || blk.flatRender || blk.invisible) return false;
  return true;
}

/* 把 16×16 贴图贴到平行四边形上：
   (0,0)->p00, (1,0)->p10, (0,1)->p01 */
function drawFace(ctx, img, p00, p10, p01){
  ctx.save();
  ctx.transform(
    p10[0] - p00[0], p10[1] - p00[1],
    p01[0] - p00[0], p01[1] - p00[1],
    p00[0], p00[1]
  );
  ctx.drawImage(img, 0, 0, TEX_INNER, TEX_INNER, 0, 0, 1, 1);
  ctx.restore();
}

function drawIsoCube(ctx, blk){
  const S = ICON_PX;
  const h = Math.max(0.05, Math.min(1, blk.slab ? blk.heightRatio : 1));

  /* 立方体在等轴测下的 7 个顶点；h<1 时竖边变短并整体居中 */
  const topY = S * (1 - h) / 4;
  const w = S / 2;
  const q = S / 4;
  const v = S * h / 2;

  const T  = [w, topY];
  const R  = [S, topY + q];
  const B  = [w, topY + S / 2];
  const L  = [0, topY + q];
  const Ld = [0, topY + q + v];
  const Bd = [w, topY + S / 2 + v];
  const Rd = [S, topY + q + v];

  const tintMode = tintModeOf(blk);
  const tint = tintOf(blk);
  const topTex = (tintMode >= 1 && tint)
    ? getTintedTile(blk.tiles[2], tint)
    : getTileCanvas(blk.tiles[2]);
  if (!topTex) return;

  /* 草方块是"五面同色 + 一面泥土"，侧面也要染色，和世界内一致 */
  const sideTint = tintMode >= 1 ? tint : 0;

  /* 顶面全亮，左面稍暗，右面更暗 —— 和 MC 的面明暗层次一致 */
  drawFace(ctx, topTex, T, R, L);
  drawFace(ctx, getShadedTile(blk.tiles[0], 0.16, sideTint), L, B, Ld);
  drawFace(ctx, getShadedTile(blk.tiles[0], 0.34, sideTint), B, R, Bd);
}

/* ============================================================
   自定义盒模型图标的等轴测投影
   ------------------------------------------------------------
   和 drawIsoCube 用同样的投影：
     sx = (x - z) * S/2,  sy = ((x + z)*0.5 - y) * S/2
   每个盒子画 3 个可见面（顶面 + 右面 +X + 左面 +Z），
   按深度排序、透明盒最后画，这样展台/箱子这类模型在背包里
   也能看出立体结构，而不是一张平面贴图。 */
function drawIsoBoxes(ctx, boxes, tint){
  const S = ICON_PX;
  /* 先算所有盒子的等轴测包围盒，再整体缩放居中。
     否则门这类"细高"模型会顶出图标边界，看起来只剩半扇。 */
  const raw = (x, y, z) => [(x - z) * 0.5, (x + z) * 0.25 - y * 0.5];
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const b of boxes){
    for (const x of [b.x0 / 16, b.x1 / 16]){
      for (const y of [b.y0 / 16, b.y1 / 16]){
        for (const z of [b.z0 / 16, b.z1 / 16]){
          const p = raw(x, y, z);
          if (p[0] < minX) minX = p[0];
          if (p[0] > maxX) maxX = p[0];
          if (p[1] < minY) minY = p[1];
          if (p[1] > maxY) maxY = p[1];
        }
      }
    }
  }
  const w = Math.max(1e-4, maxX - minX);
  const h = Math.max(1e-4, maxY - minY);
  const k = Math.min(S * 0.94 / w, S * 0.94 / h);
  const cx = (minX + maxX) * 0.5;
  const cy = (minY + maxY) * 0.5;
  const P = (x, y, z) => {
    const p = raw(x, y, z);
    return [S * 0.5 + (p[0] - cx) * k, S * 0.5 + (p[1] - cy) * k];
  };
  const list = boxes.map(b => ({
    b,
    depth: ((b.x0 + b.x1) + (b.y0 + b.y1) + (b.z0 + b.z1)) / 32,
    alpha: !!b.alpha,
  }));
  list.sort((a, c) => (a.alpha - c.alpha) || (a.depth - c.depth));

  for (const item of list){
    const b = item.b;
    const x0 = b.x0 / 16, x1 = b.x1 / 16;
    const y0 = b.y0 / 16, y1 = b.y1 / 16;
    const z0 = b.z0 / 16, z1 = b.z1 / 16;
    if (x1 <= x0 || y1 <= y0 || z1 <= z0) continue;

    const topTex = tint ? getTintedTile(b.tiles[2], tint) : getTileCanvas(b.tiles[2]);
    const rightTex = getShadedTile(b.tiles[0], 0.16, tint || 0);
    const leftTex = getShadedTile(b.tiles[0], 0.34, tint || 0);
    if (!topTex || !rightTex || !leftTex) continue;

    ctx.globalAlpha = item.alpha ? 0.45 : 1;
    /* +Z 面（画面左侧） */
    drawFace(ctx, leftTex, P(x0, y0, z1), P(x1, y0, z1), P(x0, y1, z1));
    /* +X 面（画面右侧） */
    drawFace(ctx, rightTex, P(x1, y0, z0), P(x1, y0, z1), P(x1, y1, z0));
    /* 顶面 */
    drawFace(ctx, topTex, P(x0, y1, z0), P(x1, y1, z0), P(x0, y1, z1));
    ctx.globalAlpha = 1;
  }
}

function drawIsoModel(ctx, blk){
  const tint = tintModeOf(blk) ? tintOf(blk) : 0;
  drawIsoBoxes(ctx, blk.model.boxes, tintModeOf(blk) === 2 ? tint : 0);
}

/* 楼梯：下整块 + 上半块，用盒模型投影画成立体图标。
   BoxGeometry 的面顺序 [+x, -x, +y, -y, +z, -z] 对应
   [侧, 侧, 顶, 底, 侧, 侧]。 */
function drawIsoStair(ctx, blk){
  const t = blk.tiles;
  const faceTiles = [t[0], t[0], t[2], t[3], t[0], t[0]];
  const boxes = [
    { x0: 0, y0: 0, z0: 0, x1: 16, y1: 8,  z1: 16, tiles: faceTiles, alpha: false },
    { x0: 0, y0: 8, z0: 8, x1: 16, y1: 16, z1: 16, tiles: faceTiles, alpha: false },
  ];
  drawIsoBoxes(ctx, boxes, 0);
}

export function getItemIconURL(itemId){
  if (iconURLCache.has(itemId)) return iconURLCache.get(itemId);
  const blk = BLOCKS[itemId];
  if (!blk) return null;

  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = ICON_PX;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  if (wantsModelIcon(blk)){
    drawIsoModel(ctx, blk);
  } else if (blk.stair){
    drawIsoStair(ctx, blk);
  } else if (wantsCubeIcon(blk)){
    drawIsoCube(ctx, blk);
  } else {
    const tint = tintModeOf(blk) ? tintOf(blk) : 0;
    const tile = tint
      ? getTintedTile(getIconTile(blk), tint)
      : getTileCanvas(getIconTile(blk));
    if (!tile) return null;
    /* 平面物品图标：占满格子，和原来的图标尺寸保持一致 */
    ctx.drawImage(tile, 0, 0, TEX_INNER, TEX_INNER, 0, 0, ICON_PX, ICON_PX);
  }

  const url = canvas.toDataURL();
  iconURLCache.set(itemId, url);
  return url;
}

/* ============================================================
   掉落物：3D 小模型 / 平面贴图
   ============================================================ */
const geometryCache = new Map();      /* blockId -> { parts, unitHalf } */
const dropMaterialCache = new Map();  /* blockId + alpha -> Material */
const flatTextureCache = new Map();   /* itemId -> CanvasTexture */
const flatMaterialCache = new Map();  /* itemId -> Material */
const unitPlane = new THREE.PlaneGeometry(1, 1);

/* BoxGeometry 的 6 个面沿用 tiles 顺序：
   [side, side, top, bottom, side, side]
   → [+x, -x, +y, -y, +z, -z] */
function applyTileUV(geo, tiles){
  const uv = geo.attributes.uv;
  if (!uv) return;
  for (let f = 0; f < 6; f++){
    const rect = UVRECT[tiles[f]] || UVRECT[0];
    for (let i = 0; i < 4; i++){
      const vi = f * 4 + i;
      const u = uv.getX(vi);
      const v = uv.getY(vi);
      uv.setXY(vi, rect.u0 + u * (rect.u1 - rect.u0),
                   rect.v0 + v * (rect.v1 - rect.v0));
    }
  }
  uv.needsUpdate = true;
}

/* 给盒模型加逐面顶点色；草方块只留底面泥土不染，树叶/十字草六面全染 */
function applyFaceTint(geo, blk){
  const mode = tintModeOf(blk);
  const tint = tintOf(blk);
  if (!mode || !tint) return;

  const cr = srgbToLinear(((tint >> 16) & 255) / 255);
  const cg = srgbToLinear(((tint >> 8) & 255) / 255);
  const cb = srgbToLinear((tint & 255) / 255);
  const col = new Float32Array(24 * 3).fill(1);
  for (let f = 0; f < 6; f++){
    /* 草方块：除底面( f=3 / -Y )外全部染色；树叶/十字草：六面全染 */
    const on = (mode === 2) || (mode === 1 && f !== 3);
    if (!on) continue;
    for (let i = 0; i < 4; i++){
      const vi = (f * 4 + i) * 3;
      col[vi] = cr; col[vi + 1] = cg; col[vi + 2] = cb;
    }
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
}

/* 整方块 / 半砖 */
function getCubeParts(blk){
  const h = Math.max(0.05, Math.min(1, blk.slab ? blk.heightRatio : 1));
  const geo = new THREE.BoxGeometry(1, h, 1);
  applyTileUV(geo, blk.tiles);
  applyFaceTint(geo, blk);
  return {
    parts: [{ geometry: geo, alpha: false }],
    unitHalf: h / 2,
  };
}

/* model 方块：把 boxes 拼成小模型 */
function getModelParts(blk){
  const geoList = [];
  for (const b of blk.model.boxes){
    const w = (b.x1 - b.x0) / 16;
    const h = (b.y1 - b.y0) / 16;
    const d = (b.z1 - b.z0) / 16;
    if (w <= 0 || h <= 0 || d <= 0) continue;
    const geo = new THREE.BoxGeometry(w, h, d);
    applyTileUV(geo, b.tiles);
    applyFaceTint(geo, blk);
    geo.translate(
      (b.x0 + b.x1) / 32 - 0.5,
      (b.y0 + b.y1) / 32 - 0.5,
      (b.z0 + b.z1) / 32 - 0.5
    );
    geoList.push({ geometry: geo, alpha: !!b.alpha });
  }
  if (!geoList.length) return null;

  /* 让模型以自身包围盒中心为原点，旋转时才不会绕着脚底甩 */
  const box = new THREE.Box3();
  for (const p of geoList){
    p.geometry.computeBoundingBox();
    box.union(p.geometry.boundingBox);
  }
  const center = box.getCenter(new THREE.Vector3());
  for (const p of geoList){
    p.geometry.translate(-center.x, -center.y, -center.z);
  }
  const size = box.getSize(new THREE.Vector3());
  return { parts: geoList, unitHalf: Math.max(0.05, size.y / 2) };
}

function getBlockParts(blk){
  if (geometryCache.has(blk.id)) return geometryCache.get(blk.id);
  const rec = blk.model ? getModelParts(blk) : getCubeParts(blk);
  if (rec) geometryCache.set(blk.id, rec);
  return rec;
}

function getDropMaterial(blk, alpha){
  const tinted = tintModeOf(blk) && tintOf(blk) ? 1 : 0;
  const key = blk.id + ':' + (alpha ? 1 : 0) + ':' + (blk.emissive ? 1 : 0) + ':' + tinted;
  let mat = dropMaterialCache.get(key);
  if (mat) return mat;

  const common = { map: atlasTexture, vertexColors: !!tinted };
  if (alpha || blk.transparent){
    mat = blk.emissive
      ? new THREE.MeshBasicMaterial({ ...common, transparent: true, alphaTest: 0.02, depthWrite: false, side: THREE.DoubleSide })
      : new THREE.MeshLambertMaterial({ ...common, transparent: true, alphaTest: 0.02, depthWrite: false, side: THREE.DoubleSide });
  } else if (blk.emissive){
    mat = new THREE.MeshBasicMaterial(common);
  } else if (blk.isLeaves){
    mat = new THREE.MeshLambertMaterial({ ...common, alphaTest: 0.5 });
  } else {
    mat = new THREE.MeshLambertMaterial(common);
  }
  dropMaterialCache.set(key, mat);
  return mat;
}

/* 平面物品 / 花草 / 火把等：一张会自转的贴图 */
function getFlatTexture(blk){
  if (flatTextureCache.has(blk.id)) return flatTextureCache.get(blk.id);
  const tint = tintModeOf(blk) ? tintOf(blk) : 0;
  const c = tint
    ? getTintedTile(getIconTile(blk), tint)
    : getTileCanvas(getIconTile(blk));
  if (!c) return null;
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  flatTextureCache.set(blk.id, tex);
  return tex;
}

function getFlatMaterial(blk){
  if (flatMaterialCache.has(blk.id)) return flatMaterialCache.get(blk.id);
  const tex = getFlatTexture(blk);
  if (!tex) return null;
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    alphaTest: 0.1,
    depthWrite: false,
    side: THREE.DoubleSide,
    fog: true,
  });
  flatMaterialCache.set(blk.id, mat);
  return mat;
}

function isBlockVisual(blk){
  if (!blk) return false;
  if (blk.isItem || blk.cross || blk.flatRender || blk.invisible) return false;
  if (blk.stair) return false;
  return true;
}

/**
 * 创建掉落物外观。
 * @returns {null | {object: THREE.Object3D, unitHalf: number,
 *                  baseScale: number, growStep: number}}
 *   unitHalf  模型在"缩放 1"下的半高，用来让掉落物贴地
 *   baseScale 基础缩放
 *   growStep  堆叠数量带来的每级放大
 */
export function createDropVisual(itemId){
  const blk = BLOCKS[itemId];
  if (!blk) return null;

  if (isBlockVisual(blk)){
    const rec = getBlockParts(blk);
    /* 模型数据坏了（boxes 全被过滤掉）就退化成平面图标，别把物品吞掉 */
    if (rec){
      const root = new THREE.Group();
      for (const part of rec.parts){
        const mat = getDropMaterial(blk, part.alpha);
        root.add(new THREE.Mesh(part.geometry, mat));
      }
      return {
        object: root,
        unitHalf: rec.unitHalf,
        baseScale: 0.34,
        growStep: 0.02,
      };
    }
  }

  const mat = getFlatMaterial(blk);
  if (!mat) return null;
  const mesh = new THREE.Mesh(unitPlane, mat);
  return {
    object: mesh,
    unitHalf: 0.5,
    baseScale: 0.5,
    growStep: 0.02,
  };
}
