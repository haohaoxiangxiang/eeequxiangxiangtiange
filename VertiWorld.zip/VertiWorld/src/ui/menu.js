/* ============================================================
   menu.js —— 主菜单 + 世界选择
   ------------------------------------------------------------
   M2：世界类型卡片从 generator-registry 动态生成
   M5：
     · MOD 柱点击 → 打开 mod-panel 的 MOD 仓库
     · 世界设置按钮 → 打开 mod-config
     · 未选中世界时禁用世界设置
   ============================================================ */
import { renderPreview } from './ui-panel.js';
import * as SaveApi from './../save/save-core.js';
import { WORLD_TYPE } from './../core/engine-core.js';
import {
  listSelectableGenerators, declareWorldType,
} from './../world/world-meta.js';
import { setHeightLimit } from './../core/engine-core.js';
import { importMapFile } from './ui-panel.js';

let selectedWorld = null;
let onEnterWorld = null;

/* ============================================================
   入口
   ============================================================ */
export function initMenu({ onEnter }){
  onEnterWorld = onEnter;

  const mainMenu    = document.getElementById('mainMenu');
  const worldMenu   = document.getElementById('worldMenu');
  const worldListEl = document.getElementById('worldList');
  const previewEl   = document.getElementById('worldPreview');
  const previewEmpty= document.getElementById('previewEmpty');
  const btnEnter    = document.getElementById('btnEnterWorld');
  const btnCreate   = document.getElementById('btnCreate');
  const btnBack     = document.getElementById('btnBackTop');

  /* ============================================================
     M5：世界设置按钮
     ------------------------------------------------------------
     HTML 里原本是 disabled + "即将推出"文案。这里运行时启用它。
     ============================================================ */
  const btnWorldSettings = document.getElementById('btnWorldSettings');
  if (btnWorldSettings){
    btnWorldSettings.disabled = true;                    // 未选世界前禁用
    btnWorldSettings.textContent = '世界设置';           // 去掉"即将推出"
    btnWorldSettings.addEventListener('click', () => {
      if (!selectedWorld) return;
      /* 懒加载 mod-panel，打开世界配置界面 */
      import('./mod-panel/index.js')
        .then(m => m.openWorldConfig(selectedWorld))
        .catch(e => {
          console.error('[menu] 打开世界设置失败:', e);
          alert('世界设置加载失败，请看控制台');
        });
    });
  }

  /* ============================================================
     M2：动态生成"世界类型"列表
     ------------------------------------------------------------
     数据有两个来源，合并后渲染成纵向列表（mod 加多少都能放得下）：
       ① generator-registry 里【运行时已注册】的生成器
       ② /api/mods 里各个 mod 在 manifest.json 中【声明】的 worldTypes
     为什么要有 ②：mod 只有在进世界之后才会被加载，而世界类型是在
     创建世界时选的 —— 只靠 ① 的话，mod 的地形类型永远不会出现在
     创建界面里（鸡生蛋问题）。② 是纯静态声明，启动时就能读到。
     选中 ② 里的类型时，会自动把这个 mod 勾进"选择 Mod"里。
     ============================================================ */
  const HOST_API = () => (window.__GAME__ && window.__GAME__.apiVersion) || 4;
  let _declared = null;

  async function loadDeclaredTypes(){
    if (_declared) return _declared;
    const out = [];
    try {
      const r = await fetch('/api/mods');
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const list = await r.json();
      for (const m of (Array.isArray(list) ? list : [])){
        if (!m || !Array.isArray(m.worldTypes)) continue;
        for (const wt of m.worldTypes){
          if (!wt || typeof wt.id !== 'string' || !wt.id) continue;
          const need = Number(m.apiVersion) || 1;
          const disabled = need > HOST_API();

          /* ★ 登记进 registry：这样 main.js 在 mod 还没加载时也能读到
             这个类型的 label / options，terrain.js 也能知道它"只是还没加载"。
             禁用的类型不登记，避免它被当成可用类型选进去。 */
          if (!disabled){
            declareWorldType(wt.id, {
              label: wt.label || wt.id,
              icon:  wt.icon  || '■',
              desc:  wt.desc  || '',
              options: wt.options,     /* undefined = 兜底用普通模式的选项 */
              mod: m.id,
              modName: m.name || m.id,
              declared: true,
            });
            /* mod 声明的每类型高度范围（没声明就用默认） */
            const hl = wt.heightLimits;
            if (hl && typeof hl === 'object'){
              setHeightLimit(
                wt.id,
                Number(hl.def) || 400,
                Number(hl.max) || Number(hl.def) || 400,
              );
            }
          }

          out.push({
            id: wt.id,
            label: wt.label || wt.id,
            icon: wt.icon || '■',
            desc: wt.desc || '',
            options: wt.options,
            mod: m.id,
            disabled,
            disabledReason: `需要 API v${need}，当前宿主只支持 v${HOST_API()}`,
          });
        }
      }
    } catch(e){
      console.warn('[menu] 读取 mod 声明的世界类型失败:', e && e.message);
    }
    _declared = out;
    return out;
  }

  function makeRow(g){
    const card = document.createElement('div');
    card.className = 'type-card';
    card.dataset.type = g.id;
    if (g.mod) card.dataset.mod = g.mod;
    if (g.disabled){
      card.classList.add('disabled');
      card.dataset.disabled = '1';
      card.title = g.disabledReason || '';
    }

    const icon = document.createElement('div');
    icon.className = 'type-icon';
    icon.textContent = g.icon || '■';

    const bodyEl = document.createElement('div');
    bodyEl.className = 'type-body';

    const name = document.createElement('div');
    name.className = 'type-name';
    name.textContent = g.label || g.id;
    if (g.mod){
      const badge = document.createElement('span');
      badge.className = 'type-badge' + (g.disabled ? ' gray' : '');
      badge.textContent = 'MOD';
      name.appendChild(badge);
    }

    const desc = document.createElement('div');
    desc.className = 'type-desc';
    desc.textContent = g.disabled ? (g.disabledReason || '不可用') : (g.desc || '');

    bodyEl.appendChild(name);
    bodyEl.appendChild(desc);
    card.appendChild(icon);
    card.appendChild(bodyEl);
    return card;
  }

  async function buildTypeCards(){
    const grid = document.getElementById('typeGrid');
    if (!grid) return;

    const prevActive = grid.querySelector('.type-card.active');
    const prevType = prevActive ? prevActive.dataset.type : null;

    const list = listSelectableGenerators();
    const declared = await loadDeclaredTypes();
    const have = new Set(list.map(g => g.id));

    grid.innerHTML = '';

    /* 异常兜底：一个生成器都没有 */
    if (!list.length && !declared.length){
      grid.appendChild(makeRow({ id: 'vanilla', label: '普通', icon: '▲', desc: '经典方块世界' }));
      return;
    }

    for (const g of list) grid.appendChild(makeRow(g));

    /* mod 声明的类型：已经在注册表里的就不重复加（运行时那份更准，带 options） */
    for (const wt of declared){
      if (have.has(wt.id)) continue;
      grid.appendChild(makeRow(wt));
    }

    /* 保选中项；没有就选 vanilla，再没有就选第一个可用项 */
    const keep = prevType ? grid.querySelector(`[data-type="${prevType}"]`) : null;
    let target = keep
      || grid.querySelector('[data-type="vanilla"]')
      || grid.querySelector('.type-card:not(.disabled)')
      || grid.querySelector('.type-card');
    if (target && !target.classList.contains('disabled')){
      grid.querySelectorAll('.type-card').forEach(c => c.classList.remove('active'));
      target.classList.add('active');
    }

    /* 通知主逻辑（main.js 负责摘要按钮 + 该类型的选项） */
    window.dispatchEvent(new CustomEvent('worldTypeListChanged'));
  }

  /* 首次构建 */
  buildTypeCards();

  /* mod 在运行时注册了新生成器 → 重建列表（保留选中项） */
  if (typeof window !== 'undefined' && window.__GAME__ && window.__GAME__.on){
    window.__GAME__.on('generator.registered', () => { buildTypeCards(); });
  }

  /* ============================================================
     ★ 导入地图（按钮在世界类型选择对话框里）
     ------------------------------------------------------------
     导出地图 / 导出整合包挪到「世界设置」里了，
     导入整合包挪到「创建世界 → 选择 Mod」里了。
     ============================================================ */
  const btnImportMap = document.getElementById('btnImportMap');
  if (btnImportMap) {
    btnImportMap.addEventListener('click', async () => {
      const old = btnImportMap.textContent;
      btnImportMap.textContent = '⏳ 导入中...';
      btnImportMap.disabled = true;
      try {
        const data = await importMapFile();
        if (!data) return;                       /* 用户取消 */
        alert(`✔ 地图导入成功！\n存档：${data.name || data.saveId}\n附带 ${data.mods.length} 个 Mod。\n已加入世界列表，选中它就能进。`);
        if (typeof window.__renderWorldList === 'function') window.__renderWorldList();
      } catch(e) {
        alert('✘ 导入失败：' + (e.message || e));
      } finally {
        btnImportMap.textContent = old;
        btnImportMap.disabled = false;
      }
    });
  }

  /* ============================================================
     主菜单三柱
     ============================================================ */
  /* 主菜单三柱 */
  document.querySelectorAll('.pillar').forEach(p => {
    p.addEventListener('click', () => {
      const target = p.dataset.target;

      if (target === 'worlds'){
        if (mainMenu) mainMenu.style.display = 'none';
        if (worldMenu) worldMenu.style.display = 'flex';
        renderWorldList();

      } else if (target === 'mods'){
        /* M5：懒加载 mod-panel，打开 MOD 仓库 */
        import('./mod-panel/index.js')
          .then(m => m.openModBrowser())
          .catch(e => {
            console.error('[menu] 加载 mod-panel 失败:', e);
            alert('MOD 面板加载失败，请看控制台');
          });

      } else if (target === 'shader'){
        alert('光影 / 材质设置即将推出');
      }
    });
  });

  /* ============================================================
     返回主菜单
     ============================================================ */
  if (btnBack){
    btnBack.addEventListener('click', () => {
      if (worldMenu) worldMenu.style.display = 'none';
      if (mainMenu) mainMenu.style.display = 'flex';
      selectedWorld = null;
      if (btnWorldSettings) btnWorldSettings.disabled = true;
    });
  }

  /* ============================================================
     设置按钮（主菜单 + 世界选择）
     ============================================================ */
  const settingsEl = document.getElementById('settings');
  const openSettings = () => {
    if (settingsEl) settingsEl.classList.add('show');
  };
  const btnSet1 = document.getElementById('btnSettingsTop');
  const btnSet2 = document.getElementById('btnSettingsTop2');
  if (btnSet1) btnSet1.addEventListener('click', openSettings);
  if (btnSet2) btnSet2.addEventListener('click', openSettings);

  /* ============================================================
     世界列表
     ============================================================ */
  async function renderWorldList(){
    let list = [];
    try {
      list = await SaveApi.listSaves();
    } catch(e){
      console.error('[menu] listSaves failed', e);
      list = [];
    }
    if (!worldListEl) return;
    worldListEl.innerHTML = '';

    if (list.length === 0){
      const d = document.createElement('div');
      d.className = 'world-empty';
      d.textContent = '还没有世界，点击下方创建新世界';
      worldListEl.appendChild(d);
      if (btnCreate){
        btnCreate.style.display = 'block';
        btnCreate.disabled = false;
      }
      if (btnEnter){ btnEnter.disabled = true; btnEnter.textContent = '进入世界'; }
      if (btnWorldSettings) btnWorldSettings.disabled = true;   /* M5 */
      if (previewEmpty) previewEmpty.style.display = 'flex';
      selectedWorld = null;
      return;
    }

    if (btnCreate){
      btnCreate.style.display = 'block';
      btnCreate.disabled = false;
    }
    list.sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0));

    for (const w of list){
      const el = document.createElement('div');
      el.className = 'world-item';
      el.innerHTML = `
        <div class="wi-info">
          <div class="wi-name">${escapeHtml(w.name || '未命名')}</div>
          <div class="wi-meta">
            <span>${escapeHtml(w.type || 'vanilla')}</span>
            <span>种子 ${w.seed}</span>
            <span>${fmtDate(w.lastPlayed || w.createdAt)}</span>
          </div>
        </div>
        <button class="wi-del" title="删除">×</button>
      `;
      el.addEventListener('click', e => {
        if (e.target.classList.contains('wi-del')) return;
        selectWorld(el, w);
      });
      el.querySelector('.wi-del').addEventListener('click', async e => {
        e.stopPropagation();
        if (confirm(`删除世界「${w.name}」？`)){
          await SaveApi.deleteSave(w.id);
          renderWorldList();
        }
      });
      worldListEl.appendChild(el);
    }

    /* 列表渲染后，如果之前选中的世界还在，恢复高亮 */
    if (selectedWorld){
      const items = worldListEl.querySelectorAll('.world-item');
      for (let i = 0; i < list.length; i++){
        if (list[i].id === selectedWorld.id){
          items[i] && items[i].classList.add('selected');
          break;
        }
      }
    }
  }

  /* ============================================================
     选择世界
     ============================================================ */
  function selectWorld(el, w){
    document.querySelectorAll('.world-item').forEach(x => x.classList.remove('selected'));
    el.classList.add('selected');
    selectedWorld = w;

    if (btnEnter){ btnEnter.disabled = false; btnEnter.textContent = '进入世界'; }
    if (btnWorldSettings) btnWorldSettings.disabled = false;
    if (previewEmpty) previewEmpty.style.display = 'none';

    try {
      renderPreview(previewEl, w.type || WORLD_TYPE.VANILLA, w.seed);
    } catch(e){
      console.warn('[menu] preview failed', e);
    }
  }

  /* ============================================================
     进入世界
     ============================================================ */
  if (btnEnter){
    btnEnter.addEventListener('click', () => {
      if (!selectedWorld) return;
      if (onEnterWorld) onEnterWorld(selectedWorld);
    });
  }

  /* ============================================================
     创建新世界
     ============================================================ */
  if (btnCreate){
    btnCreate.addEventListener('click', () => {
      const dlg = document.getElementById('createDialog');
      if (!dlg){
        console.warn('[menu] #createDialog 不存在');
        return;
      }
      dlg.classList.add('show');
      /* 类型列表可能被 mod 改过（运行时注册 / 声明的类型晚到），开框时刷一次 */
      if (typeof window.__refreshTypeUI === 'function') window.__refreshTypeUI();
      else if (typeof window.__refreshHeightUI === 'function') window.__refreshHeightUI();
    });
  }

  /* 对外接口（main.js 用） */
  window.__renderWorldList = renderWorldList;
  window.__buildTypeCards  = buildTypeCards;
}

/* ============================================================
   工具
   ============================================================ */
function fmtDate(ts){
  if (!ts) return '';
  const diff = (Date.now() - ts) / 1000;
  if (diff < 60) return '刚刚';
  if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
  if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
  return Math.floor(diff / 86400) + ' 天前';
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}