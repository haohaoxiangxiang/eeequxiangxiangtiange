/* ============================================================
   item-tip.js —— 物品悬浮信息面板（名称 / 属性 / 介绍）
   ------------------------------------------------------------
   玩家把鼠标移到（或点击）某个物品格上时，在指针旁边弹出一个小面板：
     · 标题：物品名 + 分类徽标
     · 属性行：按种类分别列出（工具 / 盔甲 / 食物 / 方块）
     · 介绍：一句人能读懂的说明

   ★ 设计要点
     1. describeItem() 是**纯函数**，不碰 DOM —— 这样可以在 Node 里
        直接跑测试，不用起浏览器（本项目的验证链路都是静态 + Node）。
     2. 本模块不 import 任何游戏模块，避免和 ui.js 形成循环依赖；
        图标绘制由调用方通过 initItemTip({ renderIcon }) 注入。
     3. 桌面：pointerenter/move 跟随指针；触屏：点一下弹在手指上方，
        2.6 秒后自动收起（手机上既没有 hover，也不该被面板挡住点击）。
   ============================================================ */

/* ---------- 文案表 ---------- */

const TOOL_NAMES = {
  pickaxe: '镐', axe: '斧', shovel: '锹', hoe: '锄',
  sword: '剑', shears: '剪刀', bucket: '桶', bow: '弓', staff: '法杖',
};

const MAT_NAMES = {
  wood: '木质', stone: '石质', copper: '铜质',
  gold: '金质', iron: '铁质', diamond: '钻石',
};

const SLOT_NAMES = { head: '头盔', chest: '胸甲', legs: '护腿', feet: '靴子' };

const TIER_NAMES = ['', '木质', '石质', '铁质', '钻石'];

/* 每种分类的主题色（左边框 + 标题色），只影响观感 */
const ACCENT = {
  armor: '#9fc0e8',
  tool: '#cfd8e3',
  food: '#e8b06a',
  light: '#ffd98a',
  block: '#9fbf8f',
  item: '#c8c8d0',
};

/* ---------- 小工具 ---------- */

function _n(v){
  const x = Number(v);
  return Number.isFinite(x) ? x : null;
}

function _fmt(v){
  const x = _n(v);
  if (x === null) return null;
  /* 1.75 → 1.75，2 → 2（不留 .0 的尾巴） */
  return (Math.round(x * 100) / 100).toString();
}

/** 挖掘要求：和 ui.js 的 describeToolRequirement 保持一致的措辞 */
function _harvestText(blk){
  const h = _n(blk.hardness);
  if (h !== null && h >= 9999) return '无法破坏';
  if (!blk.tool) return '徒手可采';
  const t = TOOL_NAMES[blk.tool] || blk.tool;
  const tier = (_n(blk.minTier) || 0) | 0;
  if (tier > 0) return '需要' + (TIER_NAMES[tier] || '') + t + '或更好';
  return '用' + t + '更快';
}

/** 盔甲减伤：和 player-core.js 的算法保持一致（每点 4%，上限 90%） */
function _armorReduction(defense){
  const d = _n(defense);
  if (d === null || d <= 0) return 0;
  return Math.round(Math.min(0.9, d * 0.04) * 100);
}

/* ---------- 分类判定 ---------- */

/**
 * 判定物品的显示分类。
 * 顺序有讲究：盔甲 / 工具 / 食物最具体，先判；
 * 剩下发光方块单独高亮成"照明"，因为它主要的用途就是照亮。
 */
export function itemKind(blk){
  if (!blk) return 'item';
  if (blk.armorSlot) return 'armor';
  if (blk.tag === 'tool' || blk.toolType) return 'tool';
  if (blk.tag === 'food' || _n(blk.food) > 0) return 'food';
  if (!blk.isItem) return (_n(blk.light) || 0) > 0 ? 'light' : 'block';
  if ((_n(blk.light) || 0) > 0) return 'light';
  return 'item';
}

const KIND_LABEL = {
  armor: '盔甲', tool: '工具', food: '食物',
  light: '照明', block: '方块', item: '物品',
};

/* ---------- 介绍文案 ---------- */

function _description(blk, kind){
  /* 物品自己带了介绍就用它（给 mod 留的口子） */
  if (typeof blk.desc === 'string' && blk.desc.trim()) return blk.desc.trim();

  const name = blk.label || blk.name || '未知物品';

  if (kind === 'armor'){
    const slot = SLOT_NAMES[blk.armorSlot] || '装备';
    const pct = _armorReduction(blk.defense);
    return '穿在' + slot + '位置的护甲，可减少 ' + pct + '% 受到的伤害。四件套齐全时防御可以叠加。';
  }

  if (kind === 'tool'){
    const t = blk.toolType;
    const mat = MAT_NAMES[blk.material] || '';
    const atk = _n(blk.attack) || 0;
    if (t === 'sword') return mat + '制近战武器，攻击力 ' + (_fmt(atk) || 0) + '，耐久 ' + (_fmt(blk.durability) || 0) + '。';
    if (t === 'bow') return mat + '制远程武器，需要箭矢才能射击。';
    if (t === 'staff') return mat + '制法杖，右键发射石块，耐久消耗很快。';
    if (t === 'bucket') return '可以舀起或倒出液体。';
    if (t === 'shears') return '用来快速采集树叶、羊毛这类柔软的东西。';
    const tn = TOOL_NAMES[t] || '工具';
    return mat + '制' + tn + '，挖掘对应方块时速度 ×' + (_fmt(blk.speed) || 1) + '。';
  }

  if (kind === 'food'){
    const f = _n(blk.food) || 0;
    const s = _n(blk.saturation);
    const sat = (s !== null && s > 0) ? '，并额外提供 ' + _fmt(s) + ' 点饱和度' : '';
    return '食用后恢复 ' + (_fmt(f) || 0) + ' 点饥饿值' + sat + '。';
  }

  if (kind === 'light'){
    const l = _n(blk.light) || 0;
    return '会发出 ' + (_fmt(l) || 0) + ' 级方块光，可以照亮周围的洞穴和建筑。';
  }

  if (blk.isLeaves) return '带有颜色的树叶，不遮挡光线，可以用剪刀快速采集。';

  if (kind === 'block'){
    const h = _n(blk.hardness);
    const hard = (h !== null && h >= 9999) ? '无法破坏' : ('硬度 ' + (_fmt(h) === null ? '?' : _fmt(h)));
    return '可以放置的方块，' + hard + '。';
  }

  return name + '，具体用途还要在游戏里试试看。';
}

/* ---------- 主函数：纯逻辑 ---------- */

/**
 * 把方块/物品定义整理成面板要显示的内容。
 * @param blk BLOCKS[id]
 * @returns {{title,idName,kind,kindLabel,accent,rows:Array,desc}|null}
 */
export function describeItem(blk){
  if (!blk || blk.id === 0 || blk.name === 'air') return null;

  const kind = itemKind(blk);
  const rows = [];
  const push = (k, v) => {
    const s = (v === null || v === undefined) ? '' : String(v).trim();
    if (s) rows.push({ k: k, v: s });
  };

  if (kind === 'armor'){
    push('部位', SLOT_NAMES[blk.armorSlot] || blk.armorSlot);
    const d = _n(blk.defense);
    if (d !== null){
      push('防御', '+' + _fmt(d));
      push('减伤', _armorReduction(d) + '%');
    }
  } else if (kind === 'tool'){
    push('类型', TOOL_NAMES[blk.toolType] || blk.toolType || '—');
    push('材质', MAT_NAMES[blk.material] || blk.material || '—');
    const sp = _n(blk.speed);
    if (sp !== null && sp !== 1) push('挖掘速度', '×' + _fmt(sp));
    const tier = _n(blk.tier);
    if (tier !== null && tier > 0) push('采集等级', TIER_NAMES[tier] || String(tier));
    const atk = _n(blk.attack);
    if (atk !== null && atk > 0) push('攻击力', _fmt(atk));
    const dur = _n(blk.durability);
    if (dur !== null && dur > 0) push('耐久', _fmt(dur));
  } else if (kind === 'food'){
    const f = _n(blk.food);
    if (f !== null) push('饥饿恢复', _fmt(f));
    const s = _n(blk.saturation);
    if (s !== null && s > 0) push('饱和度', _fmt(s));
  }

  /* 照明：不管什么分类，发光就写出来 */
  const light = _n(blk.light);
  if (light !== null && light > 0) push('光照等级', _fmt(light));

  /* 方块类才需要写采集信息；工具/食物/盔甲本身不能被挖 */
  if (!blk.isItem){
    const h = _n(blk.hardness);
    if (h !== null) push('硬度', h >= 9999 ? '无法破坏' : _fmt(h));
    push('采集', _harvestText(blk));
    if (blk.requiresTool) push('需要工具', '是');
  }

  const ms = _n(blk.maxStack);
  if (ms !== null) push('堆叠上限', ms > 1 ? _fmt(ms) : '不可堆叠');

  return {
    title: blk.label || blk.name || '未知物品',
    idName: blk.name || '',
    kind: kind,
    kindLabel: KIND_LABEL[kind] || KIND_LABEL.item,
    accent: ACCENT[kind] || ACCENT.item,
    rows: rows,
    desc: _description(blk, kind),
  };
}

/* ============================================================
   以下都是 DOM 部分：只在浏览器里跑
   ============================================================ */

let _el = null;            /* 面板根节点 */
let _renderIcon = null;    /* (iconEl, blockId, sizePx) => void，由 ui.js 注入 */
let _hideTimer = 0;
let _curBlkId = -1;

function _ensureEl(){
  if (_el || typeof document === 'undefined') return _el;
  /* ★ document.body 可能还没解析完：模块脚本虽然是 defer 的，
     但真在 head 里同步执行时这里会抛 TypeError，整个 UI 模块就挂了。 */
  if (!document.body) return null;
  _el = document.createElement('div');
  _el.id = 'itemtip';
  _el.className = 'itemtip';
  _el.style.display = 'none';
  document.body.appendChild(_el);
  return _el;
}

/**
 * @param opts.renderIcon 可选：把物品图标画进传入的元素
 */
export function initItemTip(opts){
  if (opts && typeof opts.renderIcon === 'function') _renderIcon = opts.renderIcon;
  _ensureEl();
}

/** 面板当前是否可见（调试用） */
export function isItemTipVisible(){
  return !!(_el && _el.style.display !== 'none');
}

export function hideItemTip(){
  if (_hideTimer){ clearTimeout(_hideTimer); _hideTimer = 0; }
  if (!_el) return;
  _el.style.display = 'none';
  _curBlkId = -1;
}

/**
 * 显示面板。
 * @param blk    BLOCKS[id]
 * @param x,y    指针/手指位置（clientX/Y）
 * @param opts   { above:true 弹在指针上方, ttl:毫秒后自动隐藏, anchorEl:贴着某个元素 }
 */
export function showItemTip(blk, x, y, opts){
  const data = describeItem(blk);
  if (!data){ hideItemTip(); return false; }
  const el = _ensureEl();
  if (!el) return false;

  if (_hideTimer){ clearTimeout(_hideTimer); _hideTimer = 0; }

  /* 同一个物品且已经显示 → 只挪位置，不重建 DOM（跟随鼠标时省很多） */
  const same = (_curBlkId === blk.id) && el.style.display !== 'none';
  if (!same){
    _curBlkId = blk.id;
    el.innerHTML = '';

    const head = document.createElement('div');
    head.className = 'itip-head';
    head.style.borderLeftColor = data.accent;

    if (_renderIcon){
      const icon = document.createElement('div');
      icon.className = 'itip-icon';
      try { _renderIcon(icon, blk.id, 34); } catch(e){}
      head.appendChild(icon);
    }

    const titles = document.createElement('div');
    titles.className = 'itip-titles';
    const name = document.createElement('div');
    name.className = 'itip-name';
    name.textContent = data.title;
    name.style.color = data.accent;
    const kind = document.createElement('div');
    kind.className = 'itip-kind';
    kind.textContent = data.kindLabel;
    titles.appendChild(name);
    titles.appendChild(kind);
    head.appendChild(titles);
    el.appendChild(head);

    if (data.rows.length){
      const table = document.createElement('div');
      table.className = 'itip-rows';
      for (const r of data.rows){
        const row = document.createElement('div');
        row.className = 'itip-row';
        const k = document.createElement('span');
        k.className = 'itip-k';
        k.textContent = r.k;
        const v = document.createElement('span');
        v.className = 'itip-v';
        v.textContent = r.v;
        row.appendChild(k);
        row.appendChild(v);
        table.appendChild(row);
      }
      el.appendChild(table);
    }

    if (data.desc){
      const desc = document.createElement('div');
      desc.className = 'itip-desc';
      desc.textContent = data.desc;
      el.appendChild(desc);
    }
  }

  /* 先显示才能量到宽高 */
  el.style.display = 'block';
  _place(el, x, y, !!(opts && opts.above), opts && opts.anchorEl);

  const ttl = opts && opts.ttl;
  if (ttl > 0){
    _hideTimer = setTimeout(() => { _hideTimer = 0; hideItemTip(); }, ttl);
  }
  return true;
}

/** 贴着指针放，并保证不出屏幕 */
function _place(el, x, y, above, anchorEl){
  const pad = 10, gap = 16;
  let w = el.offsetWidth, h = el.offsetHeight;
  if (!w || !h){ w = 190; h = 96; }

  let left, top;
  if (anchorEl && anchorEl.getBoundingClientRect){
    const r = anchorEl.getBoundingClientRect();
    left = r.right + gap;
    top = r.top - (h - r.height) / 2;
    if (left + w > window.innerWidth - pad) left = r.left - w - gap;
  } else {
    left = x + gap;
    top = above ? (y - h - gap) : (y + gap);
  }

  if (left + w > window.innerWidth - pad) left = window.innerWidth - w - pad;
  if (left < pad) left = pad;
  if (top + h > window.innerHeight - pad) top = window.innerHeight - h - pad;
  if (top < pad) top = pad;

  el.style.left = Math.round(left) + 'px';
  el.style.top = Math.round(top) + 'px';
}

/* ---------- 给元素挂上悬浮提示 ---------- */

const _attached = new WeakSet();
let _docBound = false;

/** 点空白处收起面板（手机上没有 hover，靠这个关） */
function _bindDocOnce(){
  if (_docBound || typeof document === 'undefined') return;
  _docBound = true;
  document.addEventListener('pointerdown', (e) => {
    const t = e.target;
    if (t && t.closest && t.closest('[data-itemtip]')) return;
    hideItemTip();
  }, true);
}

/**
 * 给一个格子元素挂上提示。
 * @param el     格子 DOM
 * @param getBlk () => blk，每次取最新（背包内容会变）
 * @param opt    { ttl } 触屏点一下后停留多久
 */
export function attachItemTip(el, getBlk, opt){
  if (!el || _attached.has(el) || typeof document === 'undefined') return;
  _attached.add(el);
  el.dataset.itemtip = '1';
  _bindDocOnce();

  const ttl = (opt && opt.ttl) || 2600;
  let hovering = false;

  el.addEventListener('pointerenter', (e) => {
    /* 触屏也会触发 pointerenter，交给 pointerdown 处理，避免重复弹 */
    if (e.pointerType === 'touch') return;
    const b = getBlk();
    if (!b) return;
    hovering = true;
    showItemTip(b, e.clientX, e.clientY, { anchorEl: el });
  });

  el.addEventListener('pointermove', (e) => {
    if (!hovering || e.pointerType === 'touch') return;
    const b = getBlk();
    if (!b){ hovering = false; hideItemTip(); return; }
    showItemTip(b, e.clientX, e.clientY, { anchorEl: el });
  });

  el.addEventListener('pointerleave', (e) => {
    if (e.pointerType === 'touch') return;
    hovering = false;
    hideItemTip();
  });

  /* 触屏：点一下弹在手指上方，几秒后自动收起 */
  el.addEventListener('pointerdown', (e) => {
    if (e.pointerType !== 'touch') return;
    const b = getBlk();
    if (!b){ hideItemTip(); return; }
    showItemTip(b, e.clientX, e.clientY, { above: true, ttl: ttl });
  });
}
