/* ============================================================
   touch-controls.js —— 移动端按键布局（预设 / 自定义 / 编辑模式）
   ------------------------------------------------------------
   · 三套预设：当前（手势）、手柄（摇杆+L/R+十字键）、键鼠+摇杆
   · 每个按钮都能单独拖动、改大小、改动作、绑定键鼠按键
   · 布局存 localStorage（百分比坐标，换屏幕不会跑偏）
   · 编辑模式从「设置 → 操作 → 编辑布局」进入
   ============================================================ */

import {
  keyLabel, getAllActions, getBinding, conflictsForCode,
} from '../core/key-bindings.js';

const LAYOUT_KEY  = '3dmc_touch_layout_v2';
const LEGACY_LAYOUT_KEY = '3dmc_touch_layout_v1';
const PRESET_KEY  = '3dmc_touch_preset';
const UISIZE_KEY  = '3dmc_ui_size';

function clone(o){ return JSON.parse(JSON.stringify(o)); }

/* ---------------- 预设 ---------------------------- */
/* x / y 是按钮中心在屏幕上的百分比；size 是像素直径；w 是宽高比 */
const PRESETS = {
  /* 当前：左侧摇杆 + 右侧 跳/蹲/疾跑，挖掘和放置沿用触屏手势 */
  classic: {
    preset: 'classic',
    stick: { x: 0.20, y: 0.85, size: 136 },
    buttons: [
      { id: 'jump',   label: '跳',   action: 'jump',   key: '', x: 0.80, y: 0.75, size: 74 },
      { id: 'sneak',  label: '蹲',   action: 'sneak',  key: '', x: 0.92, y: 0.75, size: 74 },
      { id: 'sprint', label: '疾跑', action: 'sprint', key: '', x: 0.86, y: 0.89, size: 64, w: 1.9 },
    ],
  },
  /* 手柄：摇杆 + 十字键（上跳/下蹲/左右切格）+ L/R（挖/用） */
  gamepad: {
    preset: 'gamepad',
    stick: { x: 0.20, y: 0.84, size: 140 },
    buttons: [
      { id: 'dp_up',    label: '↑', action: 'jump',     key: '', x: 0.78, y: 0.58, size: 56 },
      { id: 'dp_down',  label: '↓', action: 'sneak',    key: '', x: 0.78, y: 0.80, size: 56 },
      { id: 'dp_left',  label: '←', action: 'slotPrev', key: '', x: 0.69, y: 0.69, size: 56 },
      { id: 'dp_right', label: '→', action: 'slotNext', key: '', x: 0.87, y: 0.69, size: 56 },
      { id: 'btn_l',    label: 'L', action: 'mine',     key: '', x: 0.70, y: 0.91, size: 72 },
      { id: 'btn_r',    label: 'R', action: 'use',      key: '', x: 0.86, y: 0.91, size: 72 },
    ],
  },
  /* 键鼠+摇杆：摇杆移动，其余是常用键盘鼠标键 */
  pc: {
    preset: 'pc',
    stick: { x: 0.20, y: 0.84, size: 132 },
    buttons: [
      { id: 'mine',  label: '左键', action: 'mine',  key: '', x: 0.86, y: 0.61, size: 74 },
      { id: 'use',   label: '右键', action: 'use',   key: '', x: 0.86, y: 0.77, size: 74 },
      { id: 'jump',  label: '空格', action: 'jump',  key: '', x: 0.73, y: 0.84, size: 62 },
      { id: 'sneak', label: 'Shift', action: 'sneak', key: '', x: 0.73, y: 0.94, size: 56 },
    ],
  },
};

const ACTION_LABELS = {
  jump: '跳跃', sneak: '潜行', sprint: '疾跑切换',
  mine: '挖掘（左键按住）', use: '使用（右键按住）',
  inv: '打开背包', menu: '暂停菜单',
  slotPrev: '切换上一格', slotNext: '切换下一格',
  key: '自定义按键',
};

let layout = null;
let editing = false;
let selectedId = null;
let drag = null;

/* ============================================================
   布局读写
   ============================================================ */
function clampNum(v, lo, hi, def){
  const n = Number(v);
  if (!isFinite(n)) return def;
  return Math.max(lo, Math.min(hi, n));
}

function sanitize(o){
  const out = {
    preset: (o && o.preset) || 'classic',
    stick: {
      x: clampNum(o && o.stick && o.stick.x, 0.04, 0.96, 0.2),
      y: clampNum(o && o.stick && o.stick.y, 0.04, 0.96, 0.85),
      size: clampNum(o && o.stick && o.stick.size, 70, 260, 120),
      hidden: !!(o && o.stick && o.stick.hidden),
    },
    buttons: [],
  };
  const src = (o && Array.isArray(o.buttons)) ? o.buttons : [];
  for (const b of src){
    if (!b) continue;
    out.buttons.push({
      id: String(b.id || ('b' + Math.random().toString(36).slice(2, 7))),
      label: String(b.label || '').slice(0, 8),
      action: (b.action && ACTION_LABELS[b.action]) ? b.action : 'key',
      key: String(b.key || ''),
      x: clampNum(b.x, 0.04, 0.96, 0.5),
      y: clampNum(b.y, 0.04, 0.96, 0.5),
      size: clampNum(b.size, 30, 160, 64),
      w: clampNum(b.w, 1, 2.6, 1),
    });
  }
  return out;
}

/* 每个预设（键鼠 / 手柄 / 触屏）各自保存一份编辑过的布局，
   切换预设不会覆盖其它预设里已经绑好的按键 */
function readLayoutStore(){
  try {
    const raw = localStorage.getItem(LAYOUT_KEY);
    const obj = raw ? JSON.parse(raw) : null;
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) return obj;
  } catch(e){}
  return {};
}

function writeLayoutStore(store){
  try { localStorage.setItem(LAYOUT_KEY, JSON.stringify(store)); } catch(e){}
}

function presetLayout(id){
  const store = readLayoutStore();
  const saved = store[id];
  if (saved && saved.stick && Array.isArray(saved.buttons)) return sanitize(saved);
  return sanitize(clone(PRESETS[id] || PRESETS.classic));
}

function loadLayout(){
  const pid = localStorage.getItem(PRESET_KEY) || 'classic';
  const store = readLayoutStore();
  if (store[pid] && store[pid].stick && Array.isArray(store[pid].buttons)){
    return sanitize(store[pid]);
  }
  /* 从旧版单布局迁移到当前预设槽位 */
  try {
    const legacyRaw = localStorage.getItem(LEGACY_LAYOUT_KEY);
    if (legacyRaw){
      const legacy = JSON.parse(legacyRaw);
      if (legacy && legacy.stick && Array.isArray(legacy.buttons)){
        const lp = legacy.preset || pid;
        store[lp] = legacy;
        writeLayoutStore(store);
        if (lp === pid) return sanitize(legacy);
      }
    }
  } catch(e){}
  return presetLayout(pid);
}

function saveLayout(){
  if (!layout) return;
  const pid = layout.preset || 'classic';
  const store = readLayoutStore();
  store[pid] = layout;
  writeLayoutStore(store);
  try { localStorage.setItem(PRESET_KEY, pid); } catch(e){}
}

/* ============================================================
   DOM 渲染
   ============================================================ */
function ensureDom(){
  const touch = document.getElementById('touch');
  if (!touch) return null;

  let stick = document.getElementById('stick');
  if (!stick){
    stick = document.createElement('div');
    stick.id = 'stick';
    touch.appendChild(stick);
  }
  if (!stick.querySelector('#knob')){
    const knob = document.createElement('div');
    knob.id = 'knob';
    stick.appendChild(knob);
  }

  let host = document.getElementById('touchbtns');
  if (!host){
    host = document.createElement('div');
    host.id = 'touchbtns';
    touch.appendChild(host);
  }
  return host;
}

function applyStickStyle(){
  const s = document.getElementById('stick');
  if (!s) return;
  const st = layout.stick || { x: 0.2, y: 0.85, size: 120 };
  if (st.hidden){
    s.style.display = 'none';
    return;
  }
  s.style.display = '';
  s.style.left = (st.x * 100) + '%';
  s.style.top  = (st.y * 100) + '%';
  s.style.bottom = 'auto';
  s.style.transform = 'translate(-50%, -50%)';
  s.style.width  = Math.round(st.size) + 'px';
  s.style.height = Math.round(st.size) + 'px';
  s.style.setProperty('--knob-size', Math.round(st.size * 0.42) + 'px');
}

function styleButton(el, b){
  el.style.left = (b.x * 100) + '%';
  el.style.top  = (b.y * 100) + '%';
  el.style.width  = Math.round(b.size * (b.w || 1)) + 'px';
  el.style.height = Math.round(b.size) + 'px';
  el.style.fontSize = Math.max(10, Math.min(17, Math.round(b.size * 0.22))) + 'px';
  el.classList.toggle('shape-wide', (b.w || 1) > 1.2);
}

function renderButtons(){
  const host = ensureDom();
  if (!host) return;
  host.innerHTML = '';
  for (const b of layout.buttons){
    const el = document.createElement('div');
    el.className = 'tbtn';
    el.dataset.id = b.id;
    el.dataset.act = b.action;
    if (b.key) el.dataset.key = b.key;
    el.textContent = b.label || '';
    styleButton(el, b);
    if (editing && selectedId === b.id) el.classList.add('sel');
    host.appendChild(el);
  }
}

function renderAll(){
  ensureDom();
  applyStickStyle();
  renderButtons();
}

/* ============================================================
   物品栏大小（与设置里的旧值共用）
   ============================================================ */
export function applyHotbarSlotSize(v){
  let val = parseFloat(v);
  if (!isFinite(val)) val = 48;
  val = Math.max(28, Math.min(80, val));
  /* 只改快捷栏；背包格子 --islot-size 保持独立，不跟着缩放 */
  document.documentElement.style.setProperty('--slot-size', Math.round(val - 4) + 'px');
  try { localStorage.setItem(UISIZE_KEY, String(val)); } catch(e){}
  if (typeof window.__refreshUI === 'function') window.__refreshUI();
  return val;
}

function currentHotbarSlotSize(){
  let v = parseFloat(localStorage.getItem(UISIZE_KEY) || '48');
  if (!isFinite(v)) v = 48;
  return Math.max(28, Math.min(80, v));
}

/* ============================================================
   背包格子大小 / 箱子熔炉面板偏移
   ------------------------------------------------------------
   · 这两项原来在设置列表里，现在收进「编辑布局」面板
   · 启动时也要应用一次，否则刷新后会退回 CSS 默认值
   ============================================================ */
const INV_SIZE_KEY  = '3dmc_inv_size';
const PANEL_DX_KEY  = '3dmc_panel_dx';
const PANEL_DY_KEY  = '3dmc_panel_dy';
const INV_SIZE_DEF  = 40;

function clampInvSize(v){
  return Math.max(28, Math.min(80, Math.round(v)));
}

export function applyInventorySize(v){
  let val = parseFloat(v);
  if (!isFinite(val)) val = INV_SIZE_DEF;
  val = clampInvSize(val);
  document.documentElement.style.setProperty('--islot-size', val + 'px');
  try { localStorage.setItem(INV_SIZE_KEY, String(val)); } catch(e){}
  return val;
}

function currentInventorySize(){
  const v = parseFloat(localStorage.getItem(INV_SIZE_KEY) || String(INV_SIZE_DEF));
  return clampInvSize(isFinite(v) ? v : INV_SIZE_DEF);
}

function clampPanelOffset(v){
  return Math.max(-160, Math.min(160, Math.round(v) || 0));
}

export function applyPanelOffset(dx, dy){
  const x = clampPanelOffset(dx), y = clampPanelOffset(dy);
  document.documentElement.style.setProperty('--panel-dx', x + 'px');
  document.documentElement.style.setProperty('--panel-dy', y + 'px');
  try {
    localStorage.setItem(PANEL_DX_KEY, String(x));
    localStorage.setItem(PANEL_DY_KEY, String(y));
  } catch(e){}
  return { x, y };
}

function currentPanelOffset(){
  return {
    x: clampPanelOffset(localStorage.getItem(PANEL_DX_KEY)),
    y: clampPanelOffset(localStorage.getItem(PANEL_DY_KEY)),
  };
}

function fmtOffset(n){
  return (n > 0 ? '+' : '') + n + 'px';
}

/* ============================================================
   编辑面板
   ============================================================ */
let panel = null;

function findButton(id){
  return layout.buttons.find(b => b.id === id) || null;
}

function newButton(){
  const b = {
    id: 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
    label: '新', action: 'key', key: '',
    x: 0.5, y: 0.7, size: 62, w: 1,
  };
  layout.buttons.push(b);
  return b;
}

function createPanel(){
  if (panel) return panel;
  panel = document.createElement('div');
  panel.id = 'ctrlEditPanel';
  panel.innerHTML = `
    <div class="cep-head">
      <span class="cep-title">按键编辑</span>
      <span class="cep-tip">拖动按钮调位置，点一下选中</span>
      <button class="cep-btn" data-cep="toggle">调整</button>
      <button class="cep-btn cep-primary" data-cep="done">完成</button>
    </div>
    <div class="cep-row">
      <label>预设</label>
      <select id="cepPreset">
        <option value="classic">当前（手势）</option>
        <option value="gamepad">手柄型</option>
        <option value="pc">键鼠+摇杆</option>
      </select>
      <button class="cep-btn" data-cep="add">＋ 添加按钮</button>
      <button class="cep-btn" data-cep="reset">恢复该预设</button>
    </div>
    <div class="cep-row">
      <label>选中</label>
      <span id="cepSelName" class="cep-selname">未选中按钮</span>
    </div>
    <div id="cepDetail" style="display:none">
      <div class="cep-row">
        <label>文字</label>
        <input id="cepLabel" maxlength="8" placeholder="按钮文字">
      </div>
      <div class="cep-row">
        <label>大小</label>
        <input type="range" id="cepSize" min="30" max="140" step="1">
        <span id="cepSizeVal" class="cep-val"></span>
      </div>
      <div class="cep-row">
        <label>动作</label>
        <select id="cepAction"></select>
      </div>
      <div class="cep-row" id="cepKeyRow">
        <label>按键</label>
        <button class="cep-btn cep-keybtn" id="cepKeyBtn" data-cep="pickkey">选择按键…</button>
      </div>
      <div class="cep-row">
        <button class="cep-btn" data-cep="dup">复制</button>
        <button class="cep-btn cep-danger" data-cep="del">删除</button>
      </div>
    </div>
    <div class="cep-row">
      <label>摇杆大小</label>
      <input type="range" id="cepStickSize" min="70" max="260" step="2">
      <span id="cepStickVal" class="cep-val"></span>
    </div>
    <div class="cep-row">
      <label>物品栏大小</label>
      <input type="range" id="cepHotSize" min="28" max="80" step="1">
      <span id="cepHotVal" class="cep-val"></span>
    </div>
    <div class="cep-row">
      <label>背包大小</label>
      <input type="range" id="cepInvSize" min="28" max="80" step="1">
      <span id="cepInvVal" class="cep-val"></span>
    </div>
    <div class="cep-row">
      <label>箱子/熔炉 X</label>
      <input type="range" id="cepPanelX" min="-160" max="160" step="4">
      <span id="cepPanelXVal" class="cep-val"></span>
    </div>
    <div class="cep-row">
      <label>箱子/熔炉 Y</label>
      <input type="range" id="cepPanelY" min="-160" max="160" step="4">
      <span id="cepPanelYVal" class="cep-val"></span>
    </div>
  `;
  document.body.appendChild(panel);

  const actionSel = panel.querySelector('#cepAction');
  for (const [id, label] of Object.entries(ACTION_LABELS)){
    const o = document.createElement('option');
    o.value = id; o.textContent = label;
    actionSel.appendChild(o);
  }

  panel.addEventListener('click', onPanelClick);
  panel.querySelector('#cepPreset').addEventListener('change', e => {
    const id = e.target.value;
    if (!PRESETS[id]) return;
    /* 先保存当前预设（含自定义按钮与绑定），再载入目标预设自己的布局 */
    applyControlPreset(id);
  });
  panel.querySelector('#cepLabel').addEventListener('input', e => {
    const b = findButton(selectedId); if (!b) return;
    b.label = e.target.value.slice(0, 8);
    renderButtons(); saveLayout();
  });
  panel.querySelector('#cepSize').addEventListener('input', e => {
    const b = findButton(selectedId); if (!b) return;
    b.size = clampNum(e.target.value, 30, 140, 64);
    panel.querySelector('#cepSizeVal').textContent = Math.round(b.size) + 'px';
    renderButtons(); saveLayout();
  });
  panel.querySelector('#cepAction').addEventListener('change', e => {
    const b = findButton(selectedId); if (!b) return;
    b.action = e.target.value;
    if (b.action === 'key' && !b.key){
      syncPanel();
      pickButtonKey();
      saveLayout();
      return;
    }
    syncPanel(); saveLayout();
  });
  panel.querySelector('#cepStickSize').addEventListener('input', e => {
    layout.stick.size = clampNum(e.target.value, 70, 260, 120);
    panel.querySelector('#cepStickVal').textContent = Math.round(layout.stick.size) + 'px';
    applyStickStyle(); saveLayout();
  });
  panel.querySelector('#cepHotSize').addEventListener('input', e => {
    const v = applyHotbarSlotSize(e.target.value);
    panel.querySelector('#cepHotVal').textContent = Math.round(v) + 'px';
  });
  panel.querySelector('#cepInvSize').addEventListener('input', e => {
    const v = applyInventorySize(e.target.value);
    panel.querySelector('#cepInvVal').textContent = v + 'px';
  });
  panel.querySelector('#cepPanelX').addEventListener('input', e => {
    const cur = currentPanelOffset();
    const r = applyPanelOffset(e.target.value, cur.y);
    panel.querySelector('#cepPanelXVal').textContent = fmtOffset(r.x);
  });
  panel.querySelector('#cepPanelY').addEventListener('input', e => {
    const cur = currentPanelOffset();
    const r = applyPanelOffset(cur.x, e.target.value);
    panel.querySelector('#cepPanelYVal').textContent = fmtOffset(r.y);
  });
  return panel;
}

function onPanelClick(e){
  const btn = e.target.closest('button[data-cep]');
  if (!btn) return;
  const act = btn.dataset.cep;
  if (act === 'done'){ closeControlEditor(); return; }
  if (act === 'toggle'){
    panel.classList.toggle('cep-expanded');
    btn.textContent = panel.classList.contains('cep-expanded') ? '收起' : '调整';
    return;
  }
  if (act === 'add'){
    const b = newButton();
    selectedId = b.id;
    renderButtons(); syncPanel(); saveLayout();
    pickButtonKey();
    return;
  }
  if (act === 'reset'){
    const pid = layout.preset || 'classic';
    layout = sanitize(clone(PRESETS[pid] || PRESETS.classic));
    selectedId = null;
    renderAll(); syncPanel(); saveLayout();
    return;
  }
  if (act === 'pickkey'){ pickButtonKey(); return; }

  const b = findButton(selectedId);
  if (!b) return;
  if (act === 'dup'){
    const copy = clone(b);
    copy.id = 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
    copy.x = clampNum(b.x + 0.03, 0.04, 0.96, b.x);
    copy.y = clampNum(b.y + 0.03, 0.04, 0.96, b.y);
    layout.buttons.push(copy);
    selectedId = copy.id;
    renderButtons(); syncPanel(); saveLayout();
  } else if (act === 'del'){
    layout.buttons = layout.buttons.filter(x => x.id !== b.id);
    selectedId = null;
    renderButtons(); syncPanel(); saveLayout();
  }
}

/* ============================================================
   选择按键弹窗（键盘图 / 手柄图）
   ------------------------------------------------------------
   · 空白按钮或「按键」动作点进来，先选键盘/手柄，再点具体按键
   · 键盘模式也可以直接按物理键（按 Esc 关闭）
   · 确认后才写入按钮绑定，取消不动原绑定
   ============================================================ */
const KB_ROWS = [
  [
    ['Escape','Esc',1.3],['F1','F1'],['F2','F2'],['F3','F3'],['F4','F4'],
    ['F5','F5'],['F6','F6'],['F7','F7'],['F8','F8'],['F9','F9'],
    ['F10','F10'],['F11','F11'],['F12','F12'],
  ],
  [
    ['Backquote','`'],['Digit1','1'],['Digit2','2'],['Digit3','3'],
    ['Digit4','4'],['Digit5','5'],['Digit6','6'],['Digit7','7'],
    ['Digit8','8'],['Digit9','9'],['Digit0','0'],['Minus','-'],
    ['Equal','='],['Backspace','⌫',2],
  ],
  [
    ['Tab','Tab',1.5],['KeyQ','Q'],['KeyW','W'],['KeyE','E'],['KeyR','R'],
    ['KeyT','T'],['KeyY','Y'],['KeyU','U'],['KeyI','I'],['KeyO','O'],
    ['KeyP','P'],['BracketLeft','['],['BracketRight',']'],['Backslash','\\',1.5],
  ],
  [
    ['CapsLock','Caps',1.8],['KeyA','A'],['KeyS','S'],['KeyD','D'],
    ['KeyF','F'],['KeyG','G'],['KeyH','H'],['KeyJ','J'],['KeyK','K'],
    ['KeyL','L'],['Semicolon',';'],['Quote',"'"],['Enter','↵',2.2],
  ],
  [
    ['ShiftLeft','Shift',2.3],['KeyZ','Z'],['KeyX','X'],['KeyC','C'],
    ['KeyV','V'],['KeyB','B'],['KeyN','N'],['KeyM','M'],
    ['Comma',','],['Period','.'],['Slash','/'],['ShiftRight','Shift',2.6],
  ],
  [
    ['ControlLeft','Ctrl',1.5],['MetaLeft','Win'],['AltLeft','Alt'],
    ['Space','空格',6.5],['AltRight','Alt'],['MetaRight','Win'],
    ['ControlRight','Ctrl',1.5],
  ],
  [
    ['ArrowLeft','←'],['ArrowUp','↑'],['ArrowDown','↓'],['ArrowRight','→'],
  ],
];
const KB_MOUSE = [['mouseLeft','鼠标左键'],['mouseRight','鼠标右键']];

let pickerEl = null;
let pickerValue = '';
let pickerMode = 'keyboard';
let pickerConfirm = null;
let pickerAction = null;

function div(cls){
  const d = document.createElement('div');
  d.className = cls;
  return d;
}

function kpKey(code, label, w){
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'kp-key';
  b.dataset.code = code;
  b.textContent = label;
  if (w) b.style.flexGrow = String(w);
  b.addEventListener('click', () => selectPickerKey(code));
  return b;
}

function kpPad(code, label, extra){
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'kp-padbtn' + (extra ? ' ' + extra : '');
  b.dataset.code = code;
  b.textContent = label;
  b.addEventListener('click', () => selectPickerKey(code));
  return b;
}

function buildPadPane(pane){
  const triggers = div('kp-padrow');
  triggers.appendChild(kpPad('pad:LT', 'LT'));
  triggers.appendChild(kpPad('pad:RT', 'RT'));
  pane.appendChild(triggers);

  const bumpers = div('kp-padrow');
  bumpers.appendChild(kpPad('pad:LB', 'LB'));
  bumpers.appendChild(kpPad('pad:RB', 'RB'));
  pane.appendChild(bumpers);

  const main = div('kp-padmain');

  const left = div('kp-padcol');
  left.appendChild(kpPad('pad:L3', 'L3'));
  const cross = div('kp-cross');
  cross.appendChild(kpPad('pad:Up', '▲', 'up'));
  cross.appendChild(kpPad('pad:Left', '◀', 'left'));
  cross.appendChild(kpPad('pad:Down', '▼', 'down'));
  cross.appendChild(kpPad('pad:Right', '▶', 'right'));
  left.appendChild(cross);

  const right = div('kp-padcol');
  right.appendChild(kpPad('pad:R3', 'R3'));
  const face = div('kp-face');
  face.appendChild(kpPad('pad:Y', 'Y', 'face-y'));
  face.appendChild(kpPad('pad:X', 'X', 'face-x'));
  face.appendChild(kpPad('pad:B', 'B', 'face-b'));
  face.appendChild(kpPad('pad:A', 'A', 'face-a'));
  right.appendChild(face);

  main.appendChild(left);
  main.appendChild(right);
  pane.appendChild(main);

  const bottom = div('kp-padrow');
  bottom.appendChild(kpPad('pad:Back', 'Back'));
  bottom.appendChild(kpPad('pad:Start', 'Start'));
  pane.appendChild(bottom);
}

function createPicker(){
  if (pickerEl) return pickerEl;

  pickerEl = div('');
  pickerEl.id = 'keyPicker';
  pickerEl.innerHTML = `
    <div class="kp-card">
      <div class="kp-head">
        <span class="kp-title">选择按键</span>
        <div class="kp-tabs">
          <button type="button" data-kp-mode="keyboard" class="active">键盘 / 鼠标</button>
          <button type="button" data-kp-mode="pad">手柄</button>
        </div>
        <button type="button" class="kp-x" data-kp="close">×</button>
      </div>
      <div class="kp-warn" style="display:none"></div>
      <div class="kp-body">
        <div class="kp-pane kp-kb" data-kp-pane="keyboard"></div>
        <div class="kp-pane kp-pad" data-kp-pane="pad"></div>
      </div>
      <div class="kp-foot">
        <span class="kp-cur">未选择</span>
        <button type="button" class="kp-btn" data-kp="clear">清除</button>
        <button type="button" class="kp-btn" data-kp="cancel">取消</button>
        <button type="button" class="kp-btn kp-primary" data-kp="ok">确认绑定</button>
      </div>
    </div>
  `;
  document.body.appendChild(pickerEl);

  const kbPane = pickerEl.querySelector('[data-kp-pane="keyboard"]');
  for (const row of KB_ROWS){
    const rowEl = div('kp-kbrow');
    for (const [code, label, w] of row) rowEl.appendChild(kpKey(code, label, w));
    kbPane.appendChild(rowEl);
  }
  const mouseRow = div('kp-kbrow kp-mouse');
  for (const [code, label] of KB_MOUSE) mouseRow.appendChild(kpKey(code, label, 2));
  kbPane.appendChild(mouseRow);

  buildPadPane(pickerEl.querySelector('[data-kp-pane="pad"]'));

  pickerEl.querySelectorAll('[data-kp-mode]').forEach(b => {
    b.addEventListener('click', () => {
      pickerMode = b.dataset.kpMode;
      syncPicker();
    });
  });
  pickerEl.addEventListener('click', e => {
    if (e.target === pickerEl){ closeKeyPicker(); return; }
    const btn = e.target.closest('button[data-kp]');
    if (!btn) return;
    const act = btn.dataset.kp;
    if (act === 'close' || act === 'cancel') closeKeyPicker();
    else if (act === 'clear'){ pickerValue = ''; syncPicker(); }
    else if (act === 'ok') confirmPicker();
  });
  return pickerEl;
}

function selectPickerKey(code){
  pickerValue = code || '';
  syncPicker();
}

function syncPicker(){
  if (!pickerEl) return;

  /* 已被其他动作占用的键，在图上点一个小圆点提示 */
  const used = new Set();
  for (const a of getAllActions()){
    if (a.id === pickerAction) continue;
    const c = getBinding(a.id);
    if (c) used.add(c);
  }
  pickerEl.querySelectorAll('.kp-key,.kp-padbtn').forEach(el => {
    el.classList.toggle('sel', el.dataset.code === pickerValue);
    el.classList.toggle('used', used.has(el.dataset.code));
  });

  pickerEl.querySelector('.kp-cur').textContent =
    pickerValue ? ('已选：' + keyLabel(pickerValue)) : '未选择';

  const warn = pickerEl.querySelector('.kp-warn');
  const conflicts = pickerValue ? conflictsForCode(pickerValue, pickerAction) : [];
  if (conflicts.length){
    warn.style.display = '';
    warn.textContent = '按键冲突：该键已被「'
      + conflicts.map(c => c.label).join('」「') + '」使用，确认后这些动作都会触发';
  } else {
    warn.style.display = 'none';
    warn.textContent = '';
  }

  pickerEl.querySelectorAll('[data-kp-mode]').forEach(b => {
    b.classList.toggle('active', b.dataset.kpMode === pickerMode);
  });
  pickerEl.querySelectorAll('.kp-pane').forEach(p => {
    p.style.display = (p.dataset.kpPane === pickerMode) ? '' : 'none';
  });
}

function confirmPicker(){
  const value = pickerValue || null;
  const cb = pickerConfirm;
  closeKeyPicker();
  if (cb) cb(value);
}

function onPickerKeyDown(ev){
  if (ev.key === 'Escape' && !ev.repeat){
    ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
    closeKeyPicker();
    return;
  }
  if (!ev.code) return;
  ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
  pickerMode = 'keyboard';
  selectPickerKey(ev.code);
}

export function openKeyPicker(opts){
  createPicker();
  opts = opts || {};
  pickerConfirm = opts.onConfirm || null;
  pickerValue = opts.value || '';
  pickerAction = opts.actionId || null;
  pickerMode = (pickerValue.indexOf('pad:') === 0) ? 'pad' : 'keyboard';
  pickerEl.querySelector('.kp-title').textContent = opts.title || '选择按键';
  pickerEl.classList.add('show');
  window.__keyPickerOpen = true;
  if (window.__resetGameKeys) window.__resetGameKeys();
  syncPicker();
  window.addEventListener('keydown', onPickerKeyDown, true);
  return true;
}

export function closeKeyPicker(){
  if (!pickerEl) return;
  pickerEl.classList.remove('show');
  window.__keyPickerOpen = false;
  pickerConfirm = null;
  pickerAction = null;
  window.removeEventListener('keydown', onPickerKeyDown, true);
}

function pickButtonKey(){
  const b = findButton(selectedId);
  if (!b) return;
  openKeyPicker({
    title: '选择按键 · ' + (b.label || '空白按钮'),
    value: b.key || '',
    onConfirm: (code) => {
      const cur = findButton(selectedId);
      if (!cur) return;
      cur.key = code || '';
      syncPanel(); renderButtons(); saveLayout();
    },
  });
}

function syncPanel(){
  if (!panel) return;
  panel.querySelector('#cepPreset').value = layout.preset || 'classic';
  const b = findButton(selectedId);
  const detail = panel.querySelector('#cepDetail');
  const nameEl = panel.querySelector('#cepSelName');
  const tipEl = panel.querySelector('.cep-tip');
  if (tipEl){
    tipEl.textContent = b
      ? ('已选中：' + (b.label || ACTION_LABELS[b.action] || '按钮'))
      : '拖动按钮调位置，点一下选中';
  }

  if (!b){
    nameEl.textContent = '未选中按钮';
    detail.style.display = 'none';
  } else {
    nameEl.textContent = (b.label || '无文字') + ' · ' + (ACTION_LABELS[b.action] || b.action);
    detail.style.display = '';
    panel.querySelector('#cepLabel').value = b.label || '';
    panel.querySelector('#cepSize').value = String(Math.round(b.size));
    panel.querySelector('#cepSizeVal').textContent = Math.round(b.size) + 'px';
    panel.querySelector('#cepAction').value = b.action;
    panel.querySelector('#cepKeyRow').style.display = (b.action === 'key') ? '' : 'none';
    const keyBtn = panel.querySelector('#cepKeyBtn');
    if (keyBtn){
      keyBtn.textContent = b.key ? (keyLabel(b.key) + ' · 更换') : '选择按键…';
      keyBtn.classList.toggle('unbound', !b.key);
    }
  }

  panel.querySelector('#cepStickSize').value = String(Math.round(layout.stick.size));
  panel.querySelector('#cepStickVal').textContent = Math.round(layout.stick.size) + 'px';
  const hs = currentHotbarSlotSize();
  panel.querySelector('#cepHotSize').value = String(Math.round(hs));
  panel.querySelector('#cepHotVal').textContent = Math.round(hs) + 'px';
  const inv = currentInventorySize();
  panel.querySelector('#cepInvSize').value = String(inv);
  panel.querySelector('#cepInvVal').textContent = inv + 'px';
  const po = currentPanelOffset();
  panel.querySelector('#cepPanelX').value = String(po.x);
  panel.querySelector('#cepPanelXVal').textContent = fmtOffset(po.x);
  panel.querySelector('#cepPanelY').value = String(po.y);
  panel.querySelector('#cepPanelYVal').textContent = fmtOffset(po.y);
}

/* ============================================================
   编辑模式：拖动 / 选中
   ============================================================ */
function onEditPointerDown(e){
  if (!editing) return;
  const tbtn = e.target.closest && e.target.closest('.tbtn');
  const stick = e.target.closest && e.target.closest('#stick');
  if (!tbtn && !stick) return;
  e.preventDefault();
  e.stopPropagation();

  const rect = document.getElementById('touch').getBoundingClientRect();
  const id = tbtn ? tbtn.dataset.id : '__stick';
  if (tbtn){
    selectedId = id;
    renderButtons();
    syncPanel();
  }
  drag = {
    id, rect,
    startX: e.clientX, startY: e.clientY,
    moved: false,
  };
  window.addEventListener('pointermove', onEditPointerMove);
  window.addEventListener('pointerup', onEditPointerUp, { once: true });
  window.addEventListener('pointercancel', onEditPointerUp, { once: true });
}

function onEditPointerMove(e){
  if (!drag) return;
  const dx = e.clientX - drag.startX;
  const dy = e.clientY - drag.startY;
  if (!drag.moved && Math.hypot(dx, dy) > 5) drag.moved = true;
  if (!drag.moved) return;
  const x = clampNum((e.clientX - drag.rect.left) / Math.max(1, drag.rect.width), 0.04, 0.96, 0.5);
  const y = clampNum((e.clientY - drag.rect.top) / Math.max(1, drag.rect.height), 0.04, 0.96, 0.5);
  if (drag.id === '__stick'){
    layout.stick.x = x; layout.stick.y = y;
    applyStickStyle();
  } else {
    const b = findButton(drag.id);
    if (b){ b.x = x; b.y = y; }
    renderButtons();
  }
}

function onEditPointerUp(){
  window.removeEventListener('pointermove', onEditPointerMove);
  window.removeEventListener('pointercancel', onEditPointerUp);
  if (drag && drag.moved) saveLayout();
  drag = null;
}

/* ============================================================
   对外接口
   ============================================================ */
export function initTouchControls(){
  layout = loadLayout();
  renderAll();
  ensureDom();

  /* 背包大小 / 箱子熔炉偏移：启动时恢复上次保存的值 */
  /* 旧版默认 48px 且每次启动都会写盘，这里一次性迁移到新的默认 40px */
  try {
    if (!localStorage.getItem('3dmc_inv_size_v2')){
      localStorage.setItem(INV_SIZE_KEY, String(INV_SIZE_DEF));
      localStorage.setItem('3dmc_inv_size_v2', '1');
    }
  } catch(e){}
  applyInventorySize(currentInventorySize());
  const po = currentPanelOffset();
  applyPanelOffset(po.x, po.y);

  const touch = document.getElementById('touch');
  if (touch) touch.addEventListener('pointerdown', onEditPointerDown, true);

  window.addEventListener('keydown', e => {
    if (e.key === 'Escape' && editing) closeControlEditor();
  });
}

export function getControlPreset(){
  return (layout && layout.preset) || 'classic';
}

export function applyControlPreset(id){
  if (!PRESETS[id]) return false;
  saveLayout();                      /* 先保存当前预设的改动，避免切换后丢失 */
  layout = presetLayout(id);         /* 再载入目标预设自己的布局 */
  layout.preset = id;
  selectedId = null;
  renderAll();
  saveLayout();
  if (editing) syncPanel();
  return true;
}

export function openControlEditor(){
  const ui = document.getElementById('ui');
  if (!ui || getComputedStyle(ui).display === 'none') return false;
  createPanel();
  editing = true;
  selectedId = null;
  document.body.classList.add('touch-editing');
  panel.style.display = 'block';
  if (window.__resetGesture) window.__resetGesture();
  if (window.__resetTouchButtons) window.__resetTouchButtons();
  if (window.__resetGameKeys) window.__resetGameKeys();
  renderAll();
  syncPanel();
  return true;
}

export function closeControlEditor(){
  if (!editing) return;
  editing = false;
  document.body.classList.remove('touch-editing');
  if (panel) panel.style.display = 'none';
  closeKeyPicker();
  selectedId = null;
  renderButtons();
  saveLayout();
}

export function isControlEditing(){
  return editing;
}
