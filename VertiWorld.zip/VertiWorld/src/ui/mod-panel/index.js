/* ============================================================
   mod-panel/index.js —— Mod 面板统一入口（门面）
   ------------------------------------------------------------
   实现全在 mod-panel.js（合并了原来的 7 个文件），
   这里只负责：装样式 + 转手导出。
   ============================================================ */
import { installModPanelStyle } from '../ui-panel.js';
import {
  openModBrowser, closeModBrowser, refreshModBrowser,
  openWorldConfig, closeWorldConfig,
  openModSelectDialog, closeModSelectDialog,
  openModStatus, closeModStatus,
  showMissingModsWarning, closeMissingModsWarning,
  renderModSelect, getSelectedMods,
} from './mod-panel.js';

installModPanelStyle();

export {
  openModBrowser, closeModBrowser, refreshModBrowser,
  openWorldConfig, closeWorldConfig,
  openModSelectDialog, closeModSelectDialog,
  openModStatus, closeModStatus,
  showMissingModsWarning, closeMissingModsWarning,
  renderModSelect, getSelectedMods,
};
