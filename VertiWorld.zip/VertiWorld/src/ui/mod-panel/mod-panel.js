/* ============================================================
   mod-panel.js —— MOD 面板全家桶（列表 / 详情 / 状态 / 警告 / 选择器 / 世界设置）
   ------------------------------------------------------------
★ 合并自 7 个 mod-panel 小文件（原来每个 1~11KB，加起来约 50KB）：
     mod-list.js          MOD 仓库列表
     mod-detail.js        单个 mod 详情页
     mod-status.js        运行时加载状态
     mod-warning.js       缺 mod 警告条
     mod-select.js        mod 多选组件（带依赖关系）
     mod-select-dialog.js 选择 mod 对话框
     mod-config.js        世界设置（含导出地图 / 整合包）
   index.js 保留为门面（转手 export + 装样式）。
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import * as SaveApi from '../../save/save-core.js';
import { exportMap, exportModpack } from '../ui-panel.js';
import { getLastLoadResult } from '../../save/save-core.js';


/* =================================================================
   ui/mod-panel/mod-list.js
   ================================================================= */
/* ============================================================
   mod-list.js —— MOD 仓库（主菜单）
   ============================================================ */


let _panelEl = null;
let _cache = null;

/* ★ mod 仓库筛选状态 */
let _allMods      = [];
let _allCoreMods  = [];
let _coreModVal   = { valid: true, missing: [] };
let _modFilterText = '';
let _modSortMode   = 'name-asc';
let _modCatFilter  = 'all';


/* ============================================================
   懒加载 DOM
   ============================================================ */
function ensurePanel(){
  if (_panelEl) return _panelEl;

  const el = document.createElement('div');
  el.id = 'modPanel';
  el.innerHTML = `
    <div class="mp-window">
      <div class="mp-head">
        <h2>MOD 仓库</h2>
        <span class="mp-sub" id="mpHeadSub"></span>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="mpCloseBtn" title="关闭">✕</button>
      </div>
      <div class="mp-body" id="mpBody">
        <div class="mp-loading">正在加载...</div>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#mpCloseBtn').addEventListener('click', closeModBrowser);
  el.addEventListener('click', e => {
    if (e.target === el) closeModBrowser();
  });

  _panelEl = el;
  return el;
}

/* ============================================================
   拉列表
   ============================================================ */
async function fetchMods(force){
  if (_cache && !force) return _cache;
  try {
    const r = await fetch('/api/mods');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const arr = await r.json();
    _cache = Array.isArray(arr) ? arr : [];
  } catch(e){
    console.warn('[mod-panel] 拉取 mod 列表失败:', e);
    _cache = [];
  }
  return _cache;
}

/* ============================================================
   公开接口
   ============================================================ */
function openModBrowser(){
  const el = ensurePanel();
  el.classList.add('show');
  renderList();
}

function closeModBrowser(){
  if (_panelEl) _panelEl.classList.remove('show');
}

function refreshModBrowser(){
  _cache = null;
  if (_panelEl && _panelEl.classList.contains('show')){
    renderList();
  }
}

/* ============================================================
   渲染列表
   ============================================================ */
async function renderList(){
  const el = ensurePanel();
  const body = el.querySelector('#mpBody');
  const headSub = el.querySelector('#mpHeadSub');

  /* ---- 首次：搭骨架（工具栏 + 分类 + 列表容器） ---- */
  if (!el.querySelector('#mpToolbar')){
    body.innerHTML = `
      <div id="mpToolbar" class="mp-toolbar">
        <input type="text" id="mpSearch" class="mp-search"
               placeholder="搜索 Mod（名称 / ID / 作者 / 描述）...">
        <select id="mpSort" class="mp-sort">
          <option value="name-asc">名称 A → Z</option>
          <option value="name-desc">名称 Z → A</option>
          <option value="author">按作者</option>
          <option value="size-desc">大小（大 → 小）</option>
          <option value="size-asc">大小（小 → 大）</option>
          <option value="version">按版本</option>
        </select>
      </div>
      <div id="mpCats" class="mp-cats">
        <button class="mp-cat active" data-cat="all">全部</button>
        <button class="mp-cat" data-cat="blocks">方块</button>
        <button class="mp-cat" data-cat="items">物品</button>
        <button class="mp-cat" data-cat="entities">生物</button>
        <button class="mp-cat" data-cat="dimensions">维度</button>
        <button class="mp-cat" data-cat="generators">生成器</button>
      </div>
      <div id="mpListContainer"></div>
    `;

    body.querySelector('#mpSearch').addEventListener('input', e => {
      _modFilterText = e.target.value.trim().toLowerCase();
      applyFilterAndSort();
    });
    body.querySelector('#mpSort').addEventListener('change', e => {
      _modSortMode = e.target.value;
      applyFilterAndSort();
    });
    body.querySelector('#mpCats').addEventListener('click', e => {
      const btn = e.target.closest('.mp-cat');
      if (!btn) return;
      _modCatFilter = btn.dataset.cat;
      body.querySelectorAll('.mp-cat').forEach(b => {
        b.classList.toggle('active', b.dataset.cat === _modCatFilter);
      });
      applyFilterAndSort();
    });
  }

  /* ---- 重新拉数据 ---- */
  const container = body.querySelector('#mpListContainer');
  container.innerHTML = '<div class="mp-loading">正在加载...</div>';

  const [mods, cmods, cval] = await Promise.all([
    fetchMods(),
    fetch('/api/coremods').then(r => r.ok ? r.json() : []).catch(() => []),
    fetch('/api/coremods/validate').then(r => r.ok ? r.json() : { valid: true, missing: [] })
      .catch(() => ({ valid: true, missing: [] }))
  ]);

  _allMods     = mods;
  _allCoreMods = cmods;
  _coreModVal  = cval;

  applyFilterAndSort();
}

/* ============================================================
   ★ 筛选 + 排序 + 渲染
   ============================================================ */
function applyFilterAndSort(){
  const el = ensurePanel();
  const body = el.querySelector('#mpBody');
  const headSub = el.querySelector('#mpHeadSub');
  const container = body.querySelector('#mpListContainer');
  if (!container) return;

  if (_allMods.length === 0){
    if (headSub) headSub.textContent = '已安装 0 个';
    container.innerHTML = `
      <div class="mp-empty">
        还没有安装任何 mod<br>
        把 mod 文件夹放进 mods/ 目录后刷新页面
      </div>
    `;
    return;
  }

  /* 筛选：文本 */
  let mods = _allMods.slice();
  if (_modFilterText){
    mods = mods.filter(m => {
      const hay = [
        m.name || '', m.id || '', m.author || '', m.description || '',
      ].join(' ').toLowerCase();
      return hay.includes(_modFilterText);
    });
  }

  /* 筛选：分类 */
  if (_modCatFilter !== 'all'){
    mods = mods.filter(m => {
      const c = m.contents || {};
      return (Number(c[_modCatFilter]) | 0) > 0;
    });
  }

  /* 排序 */
  switch (_modSortMode){
    case 'name-asc':
      mods.sort((a, b) => (a.name || a.id).localeCompare(b.name || b.id, 'zh-CN'));
      break;
    case 'name-desc':
      mods.sort((a, b) => (b.name || b.id).localeCompare(a.name || a.id, 'zh-CN'));
      break;
    case 'author':
      mods.sort((a, b) => (a.author || '').localeCompare(b.author || '', 'zh-CN'));
      break;
    case 'size-desc':
      mods.sort((a, b) => (b.folderSize || 0) - (a.folderSize || 0));
      break;
    case 'size-asc':
      mods.sort((a, b) => (a.folderSize || 0) - (b.folderSize || 0));
      break;
    case 'version':
      mods.sort((a, b) => (a.version || '').localeCompare(b.version || '', 'zh-CN'));
      break;
  }

  container.innerHTML = '';

  /* coremods：只在无筛选时显示 */
  if (_allCoreMods.length > 0 && !_modFilterText && _modCatFilter === 'all'){
    const sec = document.createElement('div');
    sec.className = 'mp-section';
    sec.innerHTML = '<h4>Coremods (代码注入)</h4>';
    const list = document.createElement('div');
    list.style.cssText = 'display:flex;flex-direction:column;gap:8px;';
    for (const cm of _allCoreMods){
      const isBad = !_coreModVal.valid &&
                    _coreModVal.missing.some(m => m.coremod === cm.id);
      const badgeColor = isBad ? '#ff5a5a'
        : (cm.stability === 'stable' ? '#50c864' : '#ffc94a');
      const row = document.createElement('div');
      row.className = 'mp-item';
      row.style.padding = '8px 12px';
      row.innerHTML = `
        <div class="mp-icon" style="border-color:${badgeColor}">⚙️</div>
        <div class="mp-main">
          <div class="mp-title-row">
            <span class="mp-name">${ml_escapeHtml(cm.name)}</span>
            <span class="mp-version">v${ml_escapeHtml(cm.version)}</span>
            <span class="mp-tag" style="border-color:${badgeColor};color:${badgeColor}">${cm.stability}</span>
          </div>
          <div class="mp-desc">注入点: ${cm.injections.length} 个</div>
          ${isBad ? `<div class="mp-desc" style="color:#ff5a5a">⚠ 部分注入点失效，请检查控制台</div>` : ''}
        </div>
      `;
      list.appendChild(row);
    }
    sec.appendChild(list);
    container.appendChild(sec);

    const sep = document.createElement('div');
    sep.className = 'mp-section';
    sep.innerHTML = '<h4>应用层 Mods</h4>';
    container.appendChild(sep);
  }

  /* 空结果提示 */
  if (mods.length === 0){
    const empty = document.createElement('div');
    empty.className = 'mp-empty';
    empty.innerHTML = `
      没有匹配的 Mod<br>
      <button class="mp-btn ghost" style="margin-top:12px" id="mpClearFilter">清除筛选</button>
    `;
    container.appendChild(empty);
    const clear = container.querySelector('#mpClearFilter');
    if (clear){
      clear.addEventListener('click', () => {
        _modFilterText = '';
        _modCatFilter = 'all';
        _modSortMode = 'name-asc';
        const s = el.querySelector('#mpSearch');
        const sel = el.querySelector('#mpSort');
        if (s) s.value = '';
        if (sel) sel.value = 'name-asc';
        el.querySelectorAll('.mp-cat').forEach(b => {
          b.classList.toggle('active', b.dataset.cat === 'all');
        });
        applyFilterAndSort();
      });
    }
  } else {
    for (const mod of mods) container.appendChild(buildItem(mod));
  }

  /* 计数 */
  if (headSub){
    if (_modFilterText || _modCatFilter !== 'all'){
      headSub.textContent = `共 ${_allMods.length} 个，匹配 ${mods.length} 个`;
    } else {
      headSub.textContent = `已安装 ${_allMods.length} 个`;
    }
  }
}


/* ============================================================
   单条
   ============================================================ */
function buildItem(mod){
  const item = document.createElement('div');
  item.className = 'mp-item';

  const iconWrap = document.createElement('div');
  iconWrap.className = 'mp-icon';
  if (mod.icon){
    const img = document.createElement('img');
    img.src = `/mods/${encodeURIComponent(mod.id)}/${mod.icon}`;
    img.alt = '';
    img.onerror = () => { img.remove(); iconWrap.textContent = '📦'; };
    iconWrap.appendChild(img);
  } else {
    iconWrap.textContent = '📦';
  }

  const main = document.createElement('div');
  main.className = 'mp-main';

  const titleRow = document.createElement('div');
  titleRow.className = 'mp-title-row';
  titleRow.innerHTML =
    `<span class="mp-name">${ml_escapeHtml(mod.name || mod.id)}</span>` +
    `<span class="mp-version">v${ml_escapeHtml(mod.version || '0.0.0')}</span>` +
    (mod.author ? `<span class="mp-author">by ${ml_escapeHtml(mod.author)}</span>` : '');
  main.appendChild(titleRow);

  if (mod.description){
    const desc = document.createElement('div');
    desc.className = 'mp-desc';
    desc.textContent = mod.description;
    main.appendChild(desc);
  }

  const tags = buildTags(mod);
  if (tags.length){
    const tagsEl = document.createElement('div');
    tagsEl.className = 'mp-tags';
    for (const t of tags){
      const tag = document.createElement('span');
      tag.className = 'mp-tag' + (t.cls ? ' ' + t.cls : '');
      tag.textContent = t.text;
      tagsEl.appendChild(tag);
    }
    main.appendChild(tagsEl);
  }

  const actions = document.createElement('div');
  actions.className = 'mp-actions';

  const btnDetail = document.createElement('button');
  btnDetail.className = 'mp-btn';
  btnDetail.textContent = '详情';
  btnDetail.addEventListener('click', () => openModDetail(mod));
  actions.appendChild(btnDetail);

  item.appendChild(iconWrap);
  item.appendChild(main);
  item.appendChild(actions);
  return item;
}

/* ============================================================
   标签
   ============================================================ */
const ml_CONTENT_LABELS = {
  blocks:      '方块',
  items:       '物品',
  entities:    '生物',
  dimensions:  '维度',
  generators:  '生成器',
  biomes:      '群系',
  recipes:     '配方',
  structures:  '结构',
};

function buildTags(mod){
  const out = [];
  const c = mod.contents;
  if (c && typeof c === 'object'){
    for (const key of Object.keys(ml_CONTENT_LABELS)){
      const n = Number(c[key]) | 0;
      if (n > 0){
        out.push({ text: `${ml_CONTENT_LABELS[key]} × ${n}` });
      }
    }
  }
  if (mod.apiVersion && Number(mod.apiVersion) >= 4){
    out.push({ text: `API v${mod.apiVersion}` });
  }
  if (Array.isArray(mod.dependencies) && mod.dependencies.length > 0){
    out.push({ text: `依赖 ${mod.dependencies.length}` });
  }
  return out;
}

/* ============================================================
   工具
   ============================================================ */
function ml_escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

/* =================================================================
   ui/mod-panel/mod-detail.js
   ================================================================= */
/* ============================================================
   mod-detail.js —— mod 详情页
   ============================================================ */

let md__overlay = null;

function openModDetail(mod){
  if (!md__overlay) md__overlay = md_buildOverlay();
  md__overlay.classList.add('show');
  renderDetail(mod);
}

function closeModDetail(){
  if (md__overlay) md__overlay.classList.remove('show');
}

/* ============================================================
   DOM 骨架
   ============================================================ */
function md_buildOverlay(){
  const el = document.createElement('div');
  el.id = 'modDetail';
  el.innerHTML = `
    <div class="mp-window">
      <div class="mp-head">
        <h2>Mod 详情</h2>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="mpdCloseBtn" title="关闭">✕</button>
      </div>
      <div class="mp-body" id="mpdBody"></div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#mpdCloseBtn').addEventListener('click', closeModDetail);
  el.addEventListener('click', e => {
    if (e.target === el) closeModDetail();
  });

  return el;
}

/* ============================================================
   渲染
   ============================================================ */
function renderDetail(mod){
  const body = md__overlay.querySelector('#mpdBody');
  body.innerHTML = '';

  /* ---- 头部 ---- */
  const header = document.createElement('div');
  header.className = 'mp-detail-header';

  const iconWrap = document.createElement('div');
  iconWrap.className = 'mp-detail-icon';
  if (mod.icon){
    const img = document.createElement('img');
    img.src = `/mods/${encodeURIComponent(mod.id)}/${mod.icon}`;
    img.alt = '';
    img.onerror = () => { img.remove(); iconWrap.textContent = '📦'; };
    iconWrap.appendChild(img);
  } else {
    iconWrap.textContent = '📦';
  }

  const meta = document.createElement('div');
  meta.className = 'mp-detail-meta';

  const h3 = document.createElement('h3');
  h3.textContent = mod.name || mod.id;

  const line1 = document.createElement('div');
  line1.className = 'mp-meta-line';
  line1.textContent =
    `v${mod.version || '0.0.0'}` +
    (mod.author ? ` · 作者 ${mod.author}` : '') +
    ` · API v${mod.apiVersion || 1}`;

  const line2 = document.createElement('div');
  line2.className = 'mp-meta-line';
  line2.textContent = `ID: ${mod.id}`;

  meta.appendChild(h3);
  meta.appendChild(line1);
  meta.appendChild(line2);

  header.appendChild(iconWrap);
  header.appendChild(meta);
  body.appendChild(header);

  /* ---- 简介 ---- */
  const desc = mod.longDescription || mod.description;
  if (desc){
    const sec = section('简介');
    const p = document.createElement('p');
    p.textContent = desc;
    sec.appendChild(p);
    body.appendChild(sec);
  }

  /* ---- 内容统计 ---- */
  if (mod.contents && typeof mod.contents === 'object'){
    const entries = Object.entries(mod.contents)
      .filter(([k, v]) => Number(v) > 0);
    if (entries.length){
      const sec = section('内容');
      const grid = document.createElement('div');
      grid.className = 'mp-contents';
      for (const [k, v] of entries){
        const item = document.createElement('div');
        item.className = 'mp-contents-item';
        item.innerHTML =
          `<div class="mp-cnt-label">${md_escapeHtml(labelOf(k))}</div>` +
          `<div class="mp-cnt-value">${Number(v) | 0}</div>`;
        grid.appendChild(item);
      }
      sec.appendChild(grid);
      body.appendChild(sec);
    }
  }

  /* ---- 快捷键 ---- */
  if (Array.isArray(mod.shortcuts) && mod.shortcuts.length > 0){
    const sec = section('快捷键');
    const list = document.createElement('div');
    list.className = 'mp-shortcuts';
    for (const sc of mod.shortcuts){
      if (!sc || typeof sc !== 'object') continue;
      const row = document.createElement('div');
      row.className = 'mp-shortcut-row';
      row.innerHTML =
        `<span class="mp-shortcut-key">${md_escapeHtml(sc.key || '?')}</span>` +
        `<span class="mp-shortcut-action">${md_escapeHtml(sc.action || '')}</span>`;
      list.appendChild(row);
    }
    if (list.children.length > 0){
      sec.appendChild(list);
      body.appendChild(sec);
    }
  }

  /* ---- 依赖 ---- */
  if (Array.isArray(mod.dependencies) && mod.dependencies.length > 0){
    const sec = section('依赖');
    const p = document.createElement('p');
    p.textContent = mod.dependencies.join(' · ');
    sec.appendChild(p);
    body.appendChild(sec);
  }

  /* ---- 变更日志 ---- */
  if (mod.changelog){
    const sec = section('变更日志');
    const p = document.createElement('p');
    p.textContent = mod.changelog;
    sec.appendChild(p);
    body.appendChild(sec);
  }

  /* ---- 文件信息 ---- */
  {
    const sec = section('文件信息');
    const dl = document.createElement('dl');
    dl.className = 'mp-kv';
    kv(dl, '入口', mod.entry || 'main.js');
    kv(dl, '权限', (mod.permissions && mod.permissions.length)
      ? mod.permissions.join(' · ')
      : '无');
    if (mod.license)  kv(dl, '许可', mod.license);
    if (mod.homepage) kv(dl, '主页', mod.homepage);
    if (typeof mod.folderSize === 'number'){
      kv(dl, '大小', formatBytes(mod.folderSize));
    }
    sec.appendChild(dl);
    body.appendChild(sec);
  }

  if (!mod.longDescription && !mod.changelog && !mod.contents){
    const tip = document.createElement('div');
    tip.className = 'mp-empty';
    tip.style.padding = '20px';
    tip.textContent = '作者未提供更多详情';
    body.appendChild(tip);
  }

  body.scrollTop = 0;
}

/* ============================================================
   工具
   ============================================================ */
function section(title){
  const sec = document.createElement('div');
  sec.className = 'mp-section';
  const h4 = document.createElement('h4');
  h4.textContent = title;
  sec.appendChild(h4);
  return sec;
}

function kv(dl, k, v){
  const dt = document.createElement('dt');
  dt.textContent = k;
  const dd = document.createElement('dd');
  dd.textContent = v;
  dl.appendChild(dt);
  dl.appendChild(dd);
}

const LABEL_MAP = {
  blocks:      '方块',
  items:       '物品',
  entities:    '生物',
  dimensions:  '维度',
  generators:  '生成器',
  biomes:      '群系',
  recipes:     '配方',
  structures:  '结构',
};
function labelOf(k){
  return LABEL_MAP[k] || k;
}

function formatBytes(n){
  if (!isFinite(n) || n < 0) return '?';
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(1) + ' MB';
  return (n / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

function md_escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

/* =================================================================
   ui/mod-panel/mod-status.js
   ================================================================= */
/* ============================================================
   mod-status.js —— 游戏内 Mod 状态面板
   ------------------------------------------------------------
   数据来源：
     · 运行时加载结果：loader.getLastLoadResult()
     · mod 元数据（图标 / 名字 / 快捷键）：GET /api/mods
   两者按 id 合并。
   ============================================================ */


let ms__overlay = null;

async function openModStatus(){
  if (!ms__overlay) ms__overlay = ms_buildOverlay();
  ms__overlay.classList.add('show');
  await render();
}

function closeModStatus(){
  if (ms__overlay) ms__overlay.classList.remove('show');
}

/* ============================================================
   DOM
   ============================================================ */
function ms_buildOverlay(){
  const el = document.createElement('div');
  el.id = 'modStatus';
  el.innerHTML = `
    <div class="mp-window" style="height:auto;max-height:82vh;">
      <div class="mp-head">
        <h2>Mod 状态</h2>
        <span class="mp-sub" id="msSub"></span>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="msClose" title="关闭">✕</button>
      </div>
      <div class="mp-body" id="msBody">
        <div class="mp-loading">正在加载...</div>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#msClose').addEventListener('click', closeModStatus);
  el.addEventListener('click', e => {
    if (e.target === el) closeModStatus();
  });

  return el;
}

/* ============================================================
   渲染
   ============================================================ */
async function render(){
  const body = ms__overlay.querySelector('#msBody');
  const headSub = ms__overlay.querySelector('#msSub');

  body.innerHTML = '<div class="mp-loading">正在加载...</div>';
  headSub.textContent = '';

  /* ① 运行时结果 */
  const r = getLastLoadResult();

  /* ② 拉 mod 元数据（图标 / 名字 / 快捷键） */
  let available = [];
  try {
    const resp = await fetch('/api/mods');
    if (resp.ok){
      const arr = await resp.json();
      if (Array.isArray(arr)) available = arr;
    }
  } catch(e){
    console.warn('[mod-status] 拉取 mod 元数据失败:', e);
  }
  const metaById = new Map(available.map(m => [m.id, m]));

  /* ③ 组装列表：先成功，再失败 */
  const okList = r.loaded;
  const failList = r.failed;

  const skippedList = r.skipped || [];
  const warnList = r.warnings || [];
  const total = okList.length + failList.length + skippedList.length + warnList.length;
  if (total === 0){
    headSub.textContent = '无';
    body.innerHTML = `
      <div class="mp-empty">
        这个存档没有启用任何 mod
      </div>
    `;
    return;
  }

  headSub.textContent =
    `${total} 个 · ${okList.length} 正常` +
    (warnList.length > 0 ? ` · ${warnList.length} 警告` : '') +
    (skippedList.length > 0 ? ` · ${skippedList.length} 跳过` : '') +
    (failList.length > 0 ? ` · ${failList.length} 失败` : '');

  body.innerHTML = '';

  for (const id of okList){
    body.appendChild(buildRowOk(id, metaById.get(id)));
  }

  for (const w of warnList){
    body.appendChild(buildRowWarn(w, metaById.get(w.id)));
  }

  for (const s of skippedList){
    body.appendChild(buildRowSkipped(s, metaById.get(s.id)));
  }

  for (const f of failList){
    body.appendChild(buildRowFail(f, metaById.get(f.id)));
  }

  /* 底部：如果有失败，显示警告 */
  if (failList.length > 0){
    const notice = document.createElement('div');
    notice.className = 'ms-notice';
    notice.textContent =
      '⚠ 部分 mod 加载失败。这可能是因为 mod 被删除、版本不兼容或代码出错。' +
      '建议在世界设置里禁用它们，或联系 mod 作者。';
    body.appendChild(notice);
  }
}

/* ============================================================
   单行：成功
   ============================================================ */
function buildRowOk(id, meta){
  const row = document.createElement('div');
  row.className = 'ms-row ms-row-ok';

  const iconWrap = buildIcon(meta);

  const main = document.createElement('div');
  main.className = 'ms-main';

  const nameRow = document.createElement('div');
  nameRow.className = 'ms-name-row';
  nameRow.innerHTML =
    `<span class="ms-status-icon ok">✓</span>` +
    `<span class="ms-name">${ms_escapeHtml((meta && meta.name) || id)}</span>` +
    (meta && meta.version ? `<span class="ms-version">v${ms_escapeHtml(meta.version)}</span>` : '');
  main.appendChild(nameRow);

  /* 快捷键 */
  if (meta && Array.isArray(meta.shortcuts) && meta.shortcuts.length > 0){
    const sc = document.createElement('div');
    sc.className = 'mp-shortcuts';
    sc.style.marginTop = '6px';
    for (const s of meta.shortcuts){
      if (!s || !s.key) continue;
      const item = document.createElement('div');
      item.className = 'mp-shortcut-row';
      item.innerHTML =
        `<span class="mp-shortcut-key">${ms_escapeHtml(s.key)}</span>` +
        `<span class="mp-shortcut-action">${ms_escapeHtml(s.action || '')}</span>`;
      sc.appendChild(item);
    }
    main.appendChild(sc);
  } else if (meta && meta.description){
    /* 没快捷键就显示简介 */
    const d = document.createElement('div');
    d.className = 'ms-desc';
    d.textContent = meta.description;
    main.appendChild(d);
  }

  row.appendChild(iconWrap);
  row.appendChild(main);
  return row;
}

/* ============================================================
   单行：失败
   ============================================================ */
function buildRowFail(f, meta){
  const row = document.createElement('div');
  row.className = 'ms-row ms-row-fail';

  const iconWrap = buildIcon(meta, '⚠');

  const main = document.createElement('div');
  main.className = 'ms-main';

  const nameRow = document.createElement('div');
  nameRow.className = 'ms-name-row';
  nameRow.innerHTML =
    `<span class="ms-status-icon fail">✗</span>` +
    `<span class="ms-name">${ms_escapeHtml((meta && meta.name) || f.id)}</span>` +
    (meta && meta.version ? `<span class="ms-version">v${ms_escapeHtml(meta.version)}</span>` : '');
  main.appendChild(nameRow);

  const reasonLabel = REASON_LABEL[f.reason] || f.reason;
  const errLine = document.createElement('div');
  errLine.className = 'ms-error';
  errLine.textContent = `${reasonLabel} · ${f.message || ''}`;
  main.appendChild(errLine);

  row.appendChild(iconWrap);
  row.appendChild(main);
  return row;
}

/* ============================================================
   单行：警告（hook/事件引用不存在）
   ============================================================ */
function buildRowWarn(w, meta){
  const row = document.createElement('div');
  row.className = 'ms-row';
  row.style.borderColor = 'rgba(255,180,60,0.35)';
  row.style.background = 'rgba(255,180,60,0.06)';
  const iconWrap = buildIcon(meta, '⚠');
  const main = document.createElement('div');
  main.className = 'ms-main';
  const nameRow = document.createElement('div');
  nameRow.className = 'ms-name-row';
  nameRow.innerHTML =
    `<span class="ms-status-icon" style="background:rgba(255,180,60,.25);color:#ffd47a;border:1px solid rgba(255,180,60,.5);">⚠</span>` +
    `<span class="ms-name">${ms_escapeHtml((meta && meta.name) || w.id)}</span>`;
  main.appendChild(nameRow);
  const err = document.createElement('div');
  err.className = 'ms-error';
  err.style.color = '#ffd47a';
  err.textContent = w.message || '';
  main.appendChild(err);
  row.appendChild(iconWrap);
  row.appendChild(main);
  return row;
}

const REASON_LABEL = {
  not_found:  '找不到 mod',
  api_version:'版本不兼容',
  load_error: '加载失败',
};

/* ============================================================
   图标
   ============================================================ */
function buildIcon(meta, fallback){
  const el = document.createElement('div');
  el.className = 'ms-icon';
  if (meta && meta.icon){
    const img = document.createElement('img');
    img.src = `/mods/${encodeURIComponent(meta.id)}/${meta.icon}`;
    img.alt = '';
    img.onerror = () => { img.remove(); el.textContent = fallback || '📦'; };
    el.appendChild(img);
  } else {
    el.textContent = fallback || '📦';
  }
  return el;
}

/* ============================================================
   工具
   ============================================================ */
function ms_escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

/* =================================================================
   ui/mod-panel/mod-warning.js
   ================================================================= */
/* ============================================================
   mod-warning.js —— 缺 Mod 警告弹窗
   ============================================================ */

let mw__overlay = null;

function showMissingModsWarning({ worldName, missingIds, missingNames }){
  if (!mw__overlay) mw__overlay = mw_buildOverlay();

  mw__overlay.querySelector('#mwTitle').textContent = `「${worldName}」载入提示`;
  mw__overlay.querySelector('#mwBody').innerHTML = `
    <p style="font-size:13px;line-height:1.7;color:#c8d4e0;margin:0 0 12px;">
      这个存档曾经启用过 <b>${missingIds.length}</b> 个 mod，现在没有加载：
    </p>
    <ul style="margin:0 0 14px 20px;padding:0;color:#ffc94a;font-size:13px;line-height:1.8;">
      ${missingNames.map(n => `<li>${mw_escapeHtml(n)}</li>`).join('')}
    </ul>
    <p style="font-size:12px;line-height:1.6;color:#8fa3b8;margin:0;">
      它们添加的方块会显示为 <b style="color:#ff6ac8;">未知方块</b>（粉黑棋盘格）。<br>
      建议在<b>世界设置</b>里重新启用它们，或接受现状继续。
    </p>
  `;

  mw__overlay.classList.add('show');
}

function closeMissingModsWarning(){
  if (mw__overlay) mw__overlay.classList.remove('show');
}

/* ============================================================
   DOM
   ============================================================ */
function mw_buildOverlay(){
  const el = document.createElement('div');
  el.id = 'modWarning';
  el.innerHTML = `
    <div class="mp-window" style="height:auto;max-height:80vh;">
      <div class="mp-head">
        <h2 id="mwTitle">载入提示</h2>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="mwClose" title="关闭">✕</button>
      </div>
      <div class="mp-body" id="mwBody"></div>
      <div class="mp-foot">
        <button class="mp-btn" id="mwOk">我知道了</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#mwClose').addEventListener('click', closeMissingModsWarning);
  el.querySelector('#mwOk').addEventListener('click', closeMissingModsWarning);

  return el;
}

function mw_escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

/* =================================================================
   ui/mod-panel/mod-select.js
   ================================================================= */
/* ============================================================
   mod-select.js —— mod 选择器（共用组件）
   ------------------------------------------------------------
   用途：
     · 创建世界对话框里嵌入一个
     · 世界设置界面里嵌入一个
   
   用法：
     await renderModSelect(containerEl, {
       selected: ['magic_ore'],   // 初始选中
       warnOnRemove: [...],        // 取消勾选这些时要二次确认
       onChange: (selectedArr, added, removed) => {}
     });
     const list = getSelectedMods(containerEl);   // 读取当前勾选
   ============================================================ */


async function renderModSelect(containerEl, options){
  options = options || {};
  const selected = new Set(options.selected || []);
  const warnOnRemove = new Set(options.warnOnRemove || []);
  const onChange = options.onChange || function(){};

  containerEl.innerHTML = '<div class="mp-loading" style="padding:18px;">加载中...</div>';

  let mods = [];
  try {
    const r = await fetch('/api/mods');
    if (r.ok) mods = await r.json();
  } catch(e){
    console.warn('[mod-select] 拉取 mod 列表失败:', e);
  }
  if (!Array.isArray(mods)) mods = [];

  /* 空状态 */
  if (mods.length === 0){
    containerEl.innerHTML = `
      <div class="mp-select-empty">没有可用的 mod</div>
    `;
    containerEl.__modSelectState = { selected, mods };
    return { selected, mods };
  }

  /* 排序 */
  mods.sort((a, b) => (a.name || a.id).localeCompare(b.name || b.id, 'zh-CN'));

  /* 渲染 */
  containerEl.innerHTML = '';
  const list = document.createElement('div');
  list.className = 'mp-select-list';

  for (const mod of mods){
    list.appendChild(buildRow(mod, selected, warnOnRemove, onChange, updateCount));
  }
  containerEl.appendChild(list);

  /* 底部：全选/全不选 + 计数 */
  const footer = document.createElement('div');
  footer.className = 'mp-select-footer';
  footer.innerHTML = `
    <button class="mp-btn ghost" data-act="all">全选</button>
    <button class="mp-btn ghost" data-act="none">全不选</button>
    <span class="mp-select-count"></span>
  `;
  containerEl.appendChild(footer);

  const countEl = footer.querySelector('.mp-select-count');

  function updateCount(){
    countEl.textContent = `已选 ${selected.size} / ${mods.length}`;
  }
  updateCount();

  /* 全选/全不选 */
  footer.querySelector('[data-act="all"]').addEventListener('click', () => {
    const removed = [];
    for (const m of mods) selected.add(m.id);
    syncCheckboxes();
    updateCount();
    onChange(Array.from(selected), [], removed);
  });
  footer.querySelector('[data-act="none"]').addEventListener('click', () => {
    /* 逐个走取消逻辑（触发警告） */
    for (const m of mods){
      if (selected.has(m.id)) tryUncheck(m, selected, warnOnRemove);
    }
    syncCheckboxes();
    updateCount();
    onChange(Array.from(selected), [], []);
  });

  function syncCheckboxes(){
    list.querySelectorAll('input[type=checkbox]').forEach(cb => {
      cb.checked = selected.has(cb.dataset.modId);
    });
  }

  containerEl.__modSelectState = { selected, mods, syncCheckboxes, updateCount };
  return { selected, mods };
}

/* 从容器读取当前勾选的 mod id */
function getSelectedMods(containerEl){
  const st = containerEl && containerEl.__modSelectState;
  if (!st) return [];
  return Array.from(st.selected);
}

/* 强制重设勾选 */
function setSelectedMods(containerEl, ids){
  const st = containerEl && containerEl.__modSelectState;
  if (!st) return;
  st.selected.clear();
  for (const id of ids) st.selected.add(id);
  st.syncCheckboxes();
  st.updateCount();
}

/* ============================================================
   单行
   ============================================================ */
function buildRow(mod, selected, warnOnRemove, onChange, updateCount){
  const row = document.createElement('div');
  row.className = 'mp-select-row';

  /* 复选框 */
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.className = 'mp-select-cb';
  cb.dataset.modId = mod.id;
  cb.checked = selected.has(mod.id);
  cb.addEventListener('change', () => {
    if (cb.checked){
      selected.add(mod.id);
      onChange(Array.from(selected), [mod.id], []);
    } else {
      const ok = tryUncheck(mod, selected, warnOnRemove);
      if (!ok) cb.checked = true;   // 用户取消，恢复勾选
      else onChange(Array.from(selected), [], [mod.id]);
    }
    updateCount();
  });

  /* 图标 */
  const icon = document.createElement('div');
  icon.className = 'mp-select-icon';
  if (mod.icon){
    const img = document.createElement('img');
    img.src = `/mods/${encodeURIComponent(mod.id)}/${mod.icon}`;
    img.alt = '';
    img.onerror = () => { img.remove(); icon.textContent = '📦'; };
    icon.appendChild(img);
  } else {
    icon.textContent = '📦';
  }

  /* 主信息 */
  const main = document.createElement('div');
  main.className = 'mp-select-main';

  const nameRow = document.createElement('div');
  nameRow.className = 'mp-select-name-row';
  nameRow.innerHTML =
    `<span class="mp-select-name">${msel_escapeHtml(mod.name || mod.id)}</span>` +
    `<span class="mp-select-version">v${msel_escapeHtml(mod.version || '0.0.0')}</span>`;
  main.appendChild(nameRow);

  if (mod.description){
    const d = document.createElement('div');
    d.className = 'mp-select-desc';
    d.textContent = mod.description;
    main.appendChild(d);
  }

  /* 内容标签 */
  const tags = buildContentTags(mod);
  if (tags.length){
    const tagsEl = document.createElement('div');
    tagsEl.className = 'mp-select-tags';
    for (const t of tags){
      const el = document.createElement('span');
      el.className = 'mp-select-tag';
      el.textContent = t;
      tagsEl.appendChild(el);
    }
    main.appendChild(tagsEl);
  }

  /* 详情按钮 */
  const btn = document.createElement('button');
  btn.className = 'mp-btn ghost mp-select-detail';
  btn.textContent = '详情';
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    openModDetail(mod);
  });

  row.appendChild(cb);
  row.appendChild(icon);
  row.appendChild(main);
  row.appendChild(btn);
  return row;
}

/* 尝试取消勾选（可能触发二次确认）。返回 false 表示用户取消 */
function tryUncheck(mod, selected, warnOnRemove){
  if (warnOnRemove.has(mod.id)){
    const ok = confirm(
      `「${mod.name || mod.id}」曾在这个世界里启用过。\n\n` +
      `取消勾选后，它添加的方块 / 生物 / 维度会从世界中消失。\n` +
      `（数据不会删除，重新启用可恢复）\n\n` +
      `确定要移除吗？`
    );
    if (!ok) return false;
  }
  selected.delete(mod.id);
  return true;
}

/* ============================================================
   内容标签
   ============================================================ */
const msel_CONTENT_LABELS = {
  blocks: '方块', items: '物品', entities: '生物', dimensions: '维度',
  generators: '生成器', biomes: '群系', recipes: '配方', structures: '结构',
};

function buildContentTags(mod){
  const out = [];
  const c = mod.contents;
  if (c && typeof c === 'object'){
    for (const k of Object.keys(msel_CONTENT_LABELS)){
      const n = Number(c[k]) | 0;
      if (n > 0) out.push(`${msel_CONTENT_LABELS[k]}×${n}`);
    }
  }
  return out;
}

function msel_escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

/* =================================================================
   ui/mod-panel/mod-select-dialog.js
   ================================================================= */
/* ============================================================
   mod-select-dialog.js —— 独立的 mod 选择弹窗
   ------------------------------------------------------------
   用途：
     · 创建世界对话框里点"选择 Mod…"弹出来
     · 也可以给别的地方复用

   用法：
     const selected = await openModSelectDialog({
       selected: ['magic_ore'],       // 初始勾选
       warnOnRemove: ['warden'],      // 取消这些时二次确认
       title: '选择 Mod',             // 可选
     });
     // selected 为 null → 用户取消
     // 否则为字符串数组
   ============================================================ */


let mdlg__overlay = null;
let _resolve = null;

function openModSelectDialog(options){
  options = options || {};
  return new Promise(resolve => {
    _resolve = resolve;
    if (!mdlg__overlay) mdlg__overlay = mdlg_buildOverlay();

    /* 标题 */
    mdlg__overlay.querySelector('#msdTitle').textContent = options.title || '选择 Mod';

    /* 内容区先清空 + 加载 */
    const body = mdlg__overlay.querySelector('#msdBody');
    body.innerHTML = '<div class="mp-loading">加载中...</div>';

    mdlg__overlay.classList.add('show');

    /* 渲染选择器 */
    renderModSelect(body, {
      selected: options.selected || [],
      warnOnRemove: options.warnOnRemove || [],
    }).catch(e => {
      console.error('[mod-select-dialog] 渲染失败:', e);
      body.innerHTML = '<div class="mp-empty">加载失败</div>';
    });
  });
}

function closeModSelectDialog(){
  if (mdlg__overlay) mdlg__overlay.classList.remove('show');
  if (_resolve){
    const r = _resolve;
    _resolve = null;
    r(null);
  }
}

/* ============================================================
   DOM
   ============================================================ */
function mdlg_buildOverlay(){
  const el = document.createElement('div');
  el.id = 'modSelectDialog';
  el.innerHTML = `
    <div class="mp-window">
      <div class="mp-head">
        <h2 id="msdTitle">选择 Mod</h2>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="msdClose" title="关闭">✕</button>
      </div>
      <div class="mp-body" id="msdBody"></div>
      <div class="mp-foot">
        <button class="mp-btn ghost" id="msdCancel">取消</button>
        <button class="mp-btn" id="msdConfirm">确定</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#msdClose').addEventListener('click', closeModSelectDialog);
  el.querySelector('#msdCancel').addEventListener('click', closeModSelectDialog);
  el.querySelector('#msdConfirm').addEventListener('click', confirm);

  el.addEventListener('click', e => {
    if (e.target === el) closeModSelectDialog();
  });

  return el;
}

function confirm(){
  const body = mdlg__overlay.querySelector('#msdBody');
  const selected = getSelectedMods(body);
  if (mdlg__overlay) mdlg__overlay.classList.remove('show');
  if (_resolve){
    const r = _resolve;
    _resolve = null;
    r(selected);
  }
}

/* =================================================================
   ui/mod-panel/mod-config.js
   ================================================================= */
/* ============================================================
   mod-config.js —— 世界设置（含 mod 配置）
   ------------------------------------------------------------
   打开方式：
     openWorldConfig(worldMeta)   编辑已有世界

   关键行为：
     · 打开时重置保存按钮（防止上次保存卡住）
     · 不新建 worldMeta 对象，直接改它的字段
       —— 这样 menu.js 里的 selectedWorld 会同步更新
     · 保存前重新读一次服务器 world.json，避免多标签页冲突
   ============================================================ */




let cfg__overlay = null;
let _current = null;         // 就是调用方传进来的 worldMeta 引用
let _modSelectEl = null;
let _saving = false;

/* ============================================================
   打开世界设置
   ============================================================ */
async function openWorldConfig(worldMeta){
  if (!worldMeta || !worldMeta.id){
    console.warn('[world-config] 缺少 worldMeta');
    return;
  }

  /* ★ 保留引用，不新建对象 */
  _current = worldMeta;
  _saving = false;

  if (!cfg__overlay) cfg__overlay = cfg_buildOverlay();

  /* 重置保存按钮（防止上次保存卡住） */
  resetSaveButton();

  cfg__overlay.classList.add('show');

  /* ---- 填基本信息 ---- */
  cfg__overlay.querySelector('#wcWorldName').value = worldMeta.name || '未命名';
  cfg__overlay.querySelector('#wcWorldId').textContent = worldMeta.id;
  cfg__overlay.querySelector('#wcWorldType').textContent = worldMeta.type || 'vanilla';
  cfg__overlay.querySelector('#wcWorldSeed').textContent = worldMeta.seed;

  /* ---- 加载 mod 选择器 ---- */
  const container = cfg__overlay.querySelector('#wcModContainer');
  container.innerHTML = '<div class="mp-loading" style="padding:18px;">加载中...</div>';

  /* 从服务器读最新 world.json（可能被其他会话 / 上次保存改过） */
  let latest = null;
  try {
    latest = await SaveApi.readFile(worldMeta.id, 'world.json');
  } catch(e){
    console.warn('[world-config] 读 world.json 失败:', e);
  }
  const currentPlugins = (latest && Array.isArray(latest.plugins))
    ? latest.plugins
    : (Array.isArray(worldMeta.plugins) ? worldMeta.plugins : []);
  const usedMods = (latest && Array.isArray(latest.usedMods))
    ? latest.usedMods
    : (Array.isArray(worldMeta.usedMods) ? worldMeta.usedMods : currentPlugins);

  /* ★ 直接把最新值写回 worldMeta，让 menu.js 里的 selectedWorld 同步 */
  worldMeta.plugins = currentPlugins;
  worldMeta.usedMods = usedMods;
  _current = worldMeta;

  /* ★ 顺带把 name 也同步（用户可能刚在别的界面改过，但没保存成功） */
  if (latest && typeof latest.name === 'string' && latest.name){
    worldMeta.name = latest.name;
    cfg__overlay.querySelector('#wcWorldName').value = latest.name;
  }

  await renderModSelect(container, {
    selected: currentPlugins,
    warnOnRemove: usedMods,
  });

  _modSelectEl = container;
}

/* ============================================================
   关闭
   ============================================================ */
/* ============================================================
   导出地图 / 导出整合包
   ------------------------------------------------------------
   放在世界设置里：这里本来就有这个世界的完整信息（含它勾选的 mod）。
   ============================================================ */
async function doExport(which){
  if (!_current || !_current.id) return;
  const idBtn = which === 'map' ? '#wcExportMap' : '#wcExportPack';
  const btn = cfg__overlay.querySelector(idBtn);
  const hint = cfg__overlay.querySelector('#wcPackHint');
  if (!btn) return;

  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = which === 'map' ? '⏳ 打包中...' : '⏳ 打包中...';
  if (hint) hint.textContent = '';

  try {
    const name = _current.name || _current.id;
    if (which === 'map'){
      await exportMap(_current.id, name);
      if (hint) hint.textContent = '✔ 地图已开始下载（存档 + 它用到的 mod）';
    } else {
      /* 用面板里当前勾选的 mod；没勾就导 world.json 里原来的 */
      const mods = _modSelectEl ? (getSelectedMods() || []) : (_current.plugins || []);
      await exportModpack(name + '-整合包', mods);
      if (hint) hint.textContent = `✔ 整合包已开始下载（${mods.length} 个 mod）`;
    }
  } catch(e){
    if (hint) hint.textContent = '✘ ' + (e.message || e);
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
}

function closeWorldConfig(){
  if (cfg__overlay){
    cfg__overlay.classList.remove('show');
    /* 双保险：关闭时也重置按钮 */
    resetSaveButton();
  }
  _current = null;
  _modSelectEl = null;
  _saving = false;
}

/* 把保存按钮恢复到初始状态 */
function resetSaveButton(){
  if (!cfg__overlay) return;
  const btn = cfg__overlay.querySelector('#wcSave');
  if (btn){
    btn.disabled = false;
    btn.textContent = '保存';
  }
}

/* ============================================================
   DOM
   ============================================================ */
function cfg_buildOverlay(){
  const el = document.createElement('div');
  el.id = 'worldConfig';
  el.innerHTML = `
    <div class="mp-window">
      <div class="mp-head">
        <h2>世界设置</h2>
        <span class="mp-sub" id="wcWorldId"></span>
        <span class="mp-spacer"></span>
        <button class="mp-close" id="wcClose" title="关闭">✕</button>
      </div>

      <div class="mp-body">
        <div class="wc-section">
          <h4>基本信息</h4>
          <label class="wc-field">
            <span>世界名称</span>
            <input type="text" id="wcWorldName" maxlength="16">
          </label>
          <dl class="mp-kv">
            <dt>类型</dt><dd id="wcWorldType"></dd>
            <dt>种子</dt><dd id="wcWorldSeed"></dd>
          </dl>
        </div>

        <div class="wc-section">
          <h4>启用的 Mod</h4>
          <div id="wcModContainer"></div>
        </div>

        <div class="wc-section">
          <h4>地图 / 整合包</h4>
          <div class="wc-packrow">
            <button class="mp-btn ghost" id="wcExportMap" title="把这个存档（连同它用到的 mod）打成一个 zip">📦 导出地图</button>
            <button class="mp-btn ghost" id="wcExportPack" title="只把这个世界用到的 mod 打包">🧩 导出整合包</button>
          </div>
          <div class="wc-packhint" id="wcPackHint"></div>
        </div>

        <div class="wc-notice">
          ⚠ 修改 Mod 配置后，需要重新进入世界才生效。
        </div>
      </div>

      <div class="mp-foot">
        <button class="mp-btn ghost" id="wcCancel">取消</button>
        <button class="mp-btn" id="wcSave">保存</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector('#wcClose').addEventListener('click', closeWorldConfig);
  el.querySelector('#wcCancel').addEventListener('click', closeWorldConfig);
  el.querySelector('#wcSave').addEventListener('click', saveConfig);
  el.querySelector('#wcExportMap').addEventListener('click', () => doExport('map'));
  el.querySelector('#wcExportPack').addEventListener('click', () => doExport('pack'));
  el.addEventListener('click', e => {
    if (e.target === el) closeWorldConfig();
  });

  return el;
}

/* ============================================================
   保存
   ============================================================ */
async function saveConfig(){
  if (_saving) return;                        // 防并发
  if (!_current || !_modSelectEl) return;

  _saving = true;

  const btn = cfg__overlay.querySelector('#wcSave');
  btn.disabled = true;
  btn.textContent = '保存中...';

  try {
    const newName = cfg__overlay.querySelector('#wcWorldName').value.trim() || '未命名';
    const newPlugins = getSelectedMods(_modSelectEl);

    /* usedMods：取"曾经启用"和"当前启用"的并集 */
    const usedSet = new Set(_current.usedMods || []);
    for (const id of newPlugins) usedSet.add(id);
    const newUsedMods = Array.from(usedSet);

    /* ★ 保存前重读一次最新 world.json，只改要改的字段
       （防止覆盖别的地方刚改过的东西） */
    let meta = await SaveApi.readFile(_current.id, 'world.json');
    if (!meta || typeof meta !== 'object') meta = { id: _current.id };

    meta.name = newName;
    meta.plugins = newPlugins;
    meta.usedMods = newUsedMods;

    await SaveApi.writeFile(_current.id, 'world.json', meta);

    /* ★ 更新内存里的 _current（它 === menu.js 的 selectedWorld） */
    _current.name = newName;
    _current.plugins = newPlugins;
    _current.usedMods = newUsedMods;
    /* 顺手同步 lastPlayed，防止世界列表排序错位（虽然保存时不改它） */
    if (typeof meta.lastPlayed === 'number'){
      _current.lastPlayed = meta.lastPlayed;
    }

    console.log(`[world-config] 已保存 "${newName}" · plugins:`, newPlugins);

    /* 关闭（closeWorldConfig 会重置按钮） */
    closeWorldConfig();
    showToast('世界设置已保存，重新进入世界后生效');

    /* 刷新世界列表 */
    if (typeof window.__renderWorldList === 'function'){
      window.__renderWorldList();
    }
  } catch(e){
    console.error('[world-config] 保存失败:', e);
    alert('保存失败: ' + (e && e.message || e));
    /* 出错时手动恢复按钮 */
    resetSaveButton();
  } finally {
    _saving = false;
  }
}

/* ============================================================
   简易 toast
   ============================================================ */
let _toastTimer = null;
function showToast(msg){
  let el = document.getElementById('__mp_toast__');
  if (!el){
    el = document.createElement('div');
    el.id = '__mp_toast__';
    el.style.cssText = `
      position: fixed; left: 50%; bottom: 60px;
      transform: translateX(-50%);
      z-index: 99999;
      padding: 10px 20px;
      background: rgba(20, 30, 50, 0.95);
      color: #e8ecf2;
      border: 1px solid rgba(120, 180, 255, 0.4);
      border-radius: 10px;
      font-size: 13px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      opacity: 0;
      transition: opacity .2s;
      pointer-events: none;
    `;
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.opacity = '1';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { el.style.opacity = '0'; }, 2200);
}

/* =================================================================
   re-export
   ================================================================= */
export {
  openModBrowser, closeModBrowser, refreshModBrowser, openModDetail, closeModDetail, openModStatus, closeModStatus, showMissingModsWarning, closeMissingModsWarning, renderModSelect, getSelectedMods, setSelectedMods, openModSelectDialog, closeModSelectDialog, openWorldConfig, closeWorldConfig
};
