/* ============================================================
   commands.js —— 命令系统（内嵌设置面板的终端）
   ------------------------------------------------------------
   · 无全局 T 键，纯设置内操作
   · 设置侧栏"命令"tab = 终端：输出区 + 聊天框输入 + 折叠命令列表
   · ↑↓ 历史 · Tab 补全 · Enter 执行 · Esc 清空输入
   · 命令历史持久化到 localStorage
   · mod 可通过 registerCommand 注册自定义命令
   ============================================================ */

import { toast } from './ui.js';

/* ============================================================
   命令表
   ============================================================ */
const _commands = new Map();

export function registerCommand(cmd){
  if (!cmd || typeof cmd.name !== 'string' || !cmd.name) return false;
  const names = [cmd.name, ...(Array.isArray(cmd.aliases) ? cmd.aliases : [])];
  for (const n of names){
    if (typeof n !== 'string' || !n) continue;
    _commands.set(n.toLowerCase(), cmd);
  }
  return true;
}

export function listCommands(){
  const seen = new Set();
  const out = [];
  for (const c of _commands.values()){
    if (seen.has(c)) continue;
    seen.add(c);
    out.push({
      name: c.name,
      aliases: Array.isArray(c.aliases) ? c.aliases.slice() : [],
      desc: c.desc || '',
      usage: c.usage || ('/' + c.name),
      category: c.category || 'general',
    });
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}

function _parseArgs(s){
  const out = [];
  let cur = '', quote = null;
  for (let i = 0; i < s.length; i++){
    const ch = s[i];
    if (quote){
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'"){
      quote = ch;
    } else if (ch === ' ' || ch === '\t'){
      if (cur){ out.push(cur); cur = ''; }
    } else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

export async function executeCommand(raw){
  if (typeof raw !== 'string'){
    return { ok: false, message: '命令必须是非空字符串' };
  }
  const s = raw.trim();
  if (!s) return { ok: false, message: '空命令' };
  const body = s.startsWith('/') ? s.slice(1) : s;
  const m = body.match(/^\s*(\S+)\s*(.*)$/);
  if (!m) return { ok: false, message: '命令格式错误' };
  const name = m[1].toLowerCase();
  const args = _parseArgs(m[2] || '');
  const cmd = _commands.get(name);
  if (!cmd){
    return { ok: false, message: `未知命令: /${name}` };
  }
  try {
    const result = cmd.fn ? await cmd.fn(args, raw) : null;
    if (result === false) return { ok: false, message: '命令执行失败' };
    if (typeof result === 'string') return { ok: true, message: result };
    if (result && typeof result === 'object' && 'ok' in result) return result;
    return { ok: true, message: '' };
  } catch(e){
    return { ok: false, message: '命令出错: ' + (e && (e.message || e)) };
  }
}

/* ============================================================
   内置命令
   ============================================================ */
function _G(){
  return (typeof window !== 'undefined' && window.__GAME__) || null;
}
function _needGame(){
  const g = _G();
  if (!g) throw new Error('尚未进入世界');
  return g;
}

/* ---- 通用 / 帮助 ---- */
registerCommand({
  name: 'help', aliases: ['?'], category: 'general',
  desc: '显示所有命令',
  usage: '/help',
  fn: () => {
    const list = listCommands();
    const lines = ['可用命令:'];
    for (const c of list){
      lines.push(`  /${c.name.padEnd(12)} ${c.desc || ''}`);
    }
    return {
      ok: true,
      message: `共 ${list.length} 条命令`,
      detail: lines.join('\n'),
    };
  },
});

/* ---- 位置 ---- */
registerCommand({
  name: 'tp', aliases: ['teleport', 'goto'], category: 'position',
  desc: '传送到指定坐标',
  usage: '/tp <x> <y> <z>',
  fn: (args) => {
    const g = _needGame();
    const [x, y, z] = args.map(Number);
    if (!isFinite(x) || !isFinite(y) || !isFinite(z)){
      return { ok: false, message: '需要三个数字: /tp <x> <y> <z>' };
    }
    g.teleport(x, y, z);
    return `已传送到 ${x}, ${y}, ${z}`;
  },
});

registerCommand({
  name: 'spawn', category: 'position',
  desc: '传送到世界出生点',
  usage: '/spawn',
  fn: async () => {
    const g = _needGame();
    const m = await import('../player/player-core.js');
    const sp = m.spawn;
    if (!sp) return { ok: false, message: '出生点未初始化' };
    g.teleport(sp.x + 0.5, sp.y + 1, sp.z + 0.5);
    return `已回到出生点 (${sp.x}, ${sp.z})`;
  },
});

registerCommand({
  name: 'pos', aliases: ['coord', 'xyz'], category: 'position',
  desc: '显示当前坐标',
  usage: '/pos',
  fn: () => {
    const g = _needGame();
    const p = g.getPos();
    return `坐标: ${p.x.toFixed(1)}, ${p.y.toFixed(1)}, ${p.z.toFixed(1)}`;
  },
});

/* ---- 物品 ---- */
registerCommand({
  name: 'give', category: 'items',
  desc: '给予物品到背包',
  usage: '/give <物品名> [数量]',
  fn: (args) => {
    const g = _needGame();
    const name = args[0];
    if (!name) return { ok: false, message: '需要物品名: /give <物品名> [数量]' };
    const n = Math.max(1, Math.min(9999, parseInt(args[1] || '1', 10) || 1));
    const ok = g.give(name, n);
    if (!ok) return { ok: false, message: `未知物品: ${name}` };
    return `已给予 ${n} 个 ${name}`;
  },
});

registerCommand({
  name: 'clear', category: 'items',
  desc: '清空背包',
  usage: '/clear',
  fn: async () => {
    _needGame();
    const m = await import('../items/items-core.js');
    m.clearInventory();
    return '背包已清空';
  },
});

/* ---- 玩家 ---- */
registerCommand({
  name: 'gamemode', aliases: ['gm'], category: 'player',
  desc: '切换游戏模式',
  usage: '/gamemode <survival|creative>',
  fn: (args) => {
    const g = _needGame();
    let v = (args[0] || '').toLowerCase();
    if (v === 's' || v === '0' || v === 'survival') v = 'survival';
    else if (v === 'c' || v === '1' || v === 'creative') v = 'creative';
    else return { ok: false, message: '只支持 survival / creative' };
    g.setMode(v);
    return `已切换到 ${v === 'creative' ? '创造' : '生存'}模式`;
  },
});

registerCommand({
  name: 'heal', category: 'player',
  desc: '回满血',
  usage: '/heal',
  fn: () => {
    const g = _needGame();
    g.heal(999);
    return '已回满血';
  },
});

registerCommand({
  name: 'feed', category: 'player',
  desc: '回满饱食度',
  usage: '/feed',
  fn: async () => {
    const g = _needGame();
    const p = g.player;
    if (p){
      p.hunger = p.maxHunger;
      p.saturation = 0;
      p.exhaustion = 0;
    }
    try {
      const ui = await import('./ui.js');
      ui.updateHunger(p.hunger, p.maxHunger, p.mode);
    } catch(e){}
    return '已回满饱食度';
  },
});

registerCommand({
  name: 'fly', category: 'player',
  desc: '切换飞行（仅创造模式）',
  usage: '/fly',
  fn: () => {
    const g = _needGame();
    const p = g.player;
    if (!p) return { ok: false, message: '玩家状态不可用' };
    if (p.mode !== 'creative'){
      return { ok: false, message: '只有创造模式能飞（试试 /gamemode creative）' };
    }
    p.flying = !p.flying;
    if (!p.flying && p.vel) p.vel.y = 0;
    return p.flying ? '飞行: 开' : '飞行: 关';
  },
});

registerCommand({
  name: 'kill', category: 'player',
  desc: '自杀（重新回到出生点）',
  usage: '/kill',
  fn: () => {
    const g = _needGame();
    g.damagePlayer(9999);
    return '已阵亡';
  },
});

/* ---- 世界 ---- */
registerCommand({
  name: 'weather', category: 'world',
  desc: '设置或查询天气',
  usage: '/weather [clear|cloudy|rain|storm|thunder]',
  fn: (args) => {
    if (typeof window.__setWeather !== 'function'){
      return { ok: false, message: '天气系统未初始化' };
    }
    let v = (args[0] || '').toLowerCase();

    /* 无参：查询当前天气 */
    if (!v){
      const st = (typeof window.__getWeather === 'function') ? window.__getWeather() : null;
      return {
        ok: true,
        message: `当前天气：${st || '未知'}`,
        detail: '用法: /weather clear | cloudy | rain | storm | thunder',
      };
    }

    if (v === 'thunder' || v === 'thunderstorm') v = 'storm';
    if (!['clear','cloudy','rain','storm'].includes(v)){
      return { ok: false, message: '天气: clear / cloudy / rain / storm（thunder = storm）' };
    }
    window.__setWeather(v);
    return `天气已切换为 ${v}`;
  },
});

registerCommand({
  name: 'fog', category: 'world',
  desc: '查看或调整雾（雾距 / 雾色深度）',
  usage: '/fog [scale <50~160> | depth <0~100>]',
  fn: async (args) => {
    let m;
    try { m = await import('../render/sky.js'); }
    catch(e){ return { ok: false, message: '无法加载雾设置' }; }

    const cur = m.getFogSettings();
    const pctS = Math.round(cur.scale * 100);
    const pctD = Math.round(cur.depth * 100);

    if (!args.length){
      return {
        ok: true,
        message: `雾距 ${pctS}% · 雾色深度 ${pctD}%`,
        detail: '用法: /fog scale <50~160> | /fog depth <0~100>',
      };
    }

    const sub = (args[0] || '').toLowerCase();
    const raw = parseFloat(args[1]);

    if (sub === 'scale' || sub === 'near' || sub === 'far' || sub === 'distance'){
      if (!isFinite(raw)) return { ok: false, message: '用法: /fog scale <50~160>' };
      const v = Math.max(50, Math.min(160, Math.round(raw)));
      m.setFogScale(v / 100);
      return `雾距已设为 ${v}%`;
    }

    if (sub === 'depth' || sub === 'color' || sub === 'dark'){
      if (!isFinite(raw)) return { ok: false, message: '用法: /fog depth <0~100>' };
      const v = Math.max(0, Math.min(100, Math.round(raw)));
      m.setFogDepth(v / 100);
      return `雾色深度已设为 ${v}%`;
    }

    /* 直接给数字 = 雾距 */
    const n = parseFloat(sub);
    if (isFinite(n)){
      const v = Math.max(50, Math.min(160, Math.round(n)));
      m.setFogScale(v / 100);
      return `雾距已设为 ${v}%`;
    }

    return { ok: false, message: '用法: /fog [scale 50~160 | depth 0~100]' };
  },
});

registerCommand({
  name: 'season', category: 'world',
  desc: '设置季节相位（0=春分，0.25=夏至，0.5=秋分，0.75=冬至）',
  usage: '/season <0~1>',
  fn: async (args) => {
    const v = parseFloat(args[0]);
    if (!isFinite(v)) return { ok: false, message: '需要 0~1 的数字' };
    const m = await import('../world/terrain.js');
    if (typeof m.setSeasonPhase !== 'function'){
      return { ok: false, message: '季节系统未初始化' };
    }
    m.setSeasonPhase(v);
    const phase = ((v % 1) + 1) % 1;
    const names = ['春分', '春→夏', '夏至', '夏→秋', '秋分', '秋→冬', '冬至', '冬→春'];
    const name = names[Math.round(phase * 8) % 8];
    return `季节相位 ${phase.toFixed(2)}（${name}）`;
  },
});

registerCommand({
  name: 'time', category: 'world',
  desc: '查看或调整时间（0=日出，0.25=正午，0.5=日落，0.75=午夜）',
  usage: '/time [get | set <day|sunrise|noon|sunset|night|midnight|0~1> | add <0~1>]',
  fn: async (args) => {
    let m;
    try { m = await import('../render/sky.js'); }
    catch(e){ return { ok: false, message: '无法加载时间系统' }; }

    const sub = (args[0] || 'get').toLowerCase();
    const label = (t) => {
      const names = [
        [0.00, '日出'], [0.25, '正午'], [0.50, '日落'], [0.75, '午夜'],
      ];
      let best = names[0];
      let bestD = 9;
      for (const n of names){
        const d = Math.min(Math.abs(t - n[0]), 1 - Math.abs(t - n[0]));
        if (d < bestD){ bestD = d; best = n; }
      }
      return bestD < 0.09 ? best[1] : '';
    };
    const out = (t) => {
      const name = label(t);
      return `时间 ${t.toFixed(3)}（${name || (t > 0.25 && t < 0.75 ? '夜晚' : '白天')}）`;
    };

    if (sub === 'get' || sub === 'show'){
      return out(m.getTimeOfDay());
    }

    if (sub === 'set'){
      const key = (args[1] || '').toLowerCase();
      const preset = {
        day: 0.28, sunrise: 0, morning: 0.28, noon: 0.25,
        sunset: 0.5, night: 0.78, midnight: 0.75,
      };
      let t = preset[key];
      if (t === undefined) t = parseFloat(key);
      if (!isFinite(t)) {
        return { ok: false, message: '用法: /time set <day|sunrise|noon|sunset|night|midnight|0~1>' };
      }
      m.setTimeOfDay(t);
      return '已设置 ' + out(m.getTimeOfDay());
    }

    if (sub === 'add'){
      const v = parseFloat(args[1]);
      if (!isFinite(v)) return { ok: false, message: '用法: /time add <0~1>' };
      m.setTimeOfDay(m.getTimeOfDay() + v);
      return '已调整为 ' + out(m.getTimeOfDay());
    }

    return { ok: false, message: '用法: /time [get | set <...> | add <0~1>]' };
  },
});

registerCommand({
  name: 'music', category: 'world',
  desc: '把程序化生成的背景音乐导出为 WAV（保存到 3dmc/music/）',
  usage: '/music export',
  fn: async (args) => {
    const sub = (args[0] || 'export').toLowerCase();
    if (sub !== 'export'){
      return { ok: false, message: '用法: /music export' };
    }
    let m;
    try { m = await import('../audio/music.js'); }
    catch(e){ return { ok: false, message: '音乐模块加载失败' }; }
    const files = await m.exportMusicFiles();
    if (!files.length){
      return { ok: false, message: '导出失败：需要先通过 http 服务器打开游戏' };
    }
    return `已导出 ${files.length} 首到 music/：${files.join('、')}`;
  },
});

registerCommand({
  name: 'seed', category: 'world',
  desc: '显示世界种子',
  usage: '/seed',
  fn: async () => {
    const m = await import('../save/save-core.js');
    const cs = m.getCurrentSave();
    if (!cs) return { ok: false, message: '无存档' };
    return `种子: ${cs.seed}`;
  },
});

registerCommand({
  name: 'setblock', category: 'world',
  desc: '在指定坐标放置方块',
  usage: '/setblock <x> <y> <z> <方块名>',
  fn: (args) => {
    const g = _needGame();
    const x = parseInt(args[0], 10);
    const y = parseInt(args[1], 10);
    const z = parseInt(args[2], 10);
    const name = args[3];
    if (!isFinite(x) || !isFinite(y) || !isFinite(z) || !name){
      return { ok: false, message: '用法: /setblock <x> <y> <z> <方块名>' };
    }
    const ok = g.setBlockByName(x, y, z, name);
    if (!ok) return { ok: false, message: `未知方块: ${name}` };
    return `已在 ${x}, ${y}, ${z} 放置 ${name}`;
  },
});


/* ---- 批量方块 / 实体 ---- */
registerCommand({
  name: 'fill', category: 'world',
  desc: '用方块填充立方体区域（上限 262144 格）',
  usage: '/fill <x1> <y1> <z1> <x2> <y2> <z2> <方块名>',
  fn: async (args) => {
    const g = _needGame();
    if (args.length < 7){
      return { ok: false, message: '用法: /fill x1 y1 z1 x2 y2 z2 方块名' };
    }
    const nums = args.slice(0, 6).map(Number);
    if (!nums.every(v => isFinite(v))){
      return { ok: false, message: '坐标必须是数字' };
    }
    const name = args[6];

    const { B } = await import('../world/blocks.js');
    const blk = B[name];
    if (!blk) return { ok: false, message: `未知方块: ${name}` };

    const ax = Math.floor(Math.min(nums[0], nums[3]));
    const bx = Math.floor(Math.max(nums[0], nums[3]));
    const ay = Math.floor(Math.min(nums[1], nums[4]));
    const by = Math.floor(Math.max(nums[1], nums[4]));
    const az = Math.floor(Math.min(nums[2], nums[5]));
    const bz = Math.floor(Math.max(nums[2], nums[5]));

    const total = (bx - ax + 1) * (by - ay + 1) * (bz - az + 1);
    if (total > 262144){
      return { ok: false, message: `区域太大（${total}），上限 262144` };
    }

    const ok = g.fillBox(ax, ay, az, bx, by, bz, blk.id);
    if (!ok) return { ok: false, message: '填充失败（可能超限或未初始化）' };
    return `已填充 ${total} 格为 ${name}（${ax},${ay},${az} → ${bx},${by},${bz}）`;
  },
});

registerCommand({
  name: 'slay', aliases: ['killmob'], category: 'world',
  desc: '杀死范围内所有生物（可指定类型）',
  usage: '/slay <半径> [类型]',
  fn: (args) => {
    const g = _needGame();
    if (typeof g.killEntitiesInRange !== 'function'){
      return { ok: false, message: '缺少实体 API（先跑 patch_mod_host_entities.py）' };
    }
    const r = parseFloat(args[0]);
    if (!isFinite(r) || r <= 0){
      return { ok: false, message: '用法: /slay <半径> [类型]' };
    }
    const p = g.getPos();
    const type = args[1] || null;
    const n = g.killEntitiesInRange(p.x, p.y, p.z, r, type ? { type } : null);
    const what = type ? ` ${type}` : '生物';
    return `已杀死 ${n} 个${what}（半径 ${r}）`;
  },
});

registerCommand({
  name: 'slayall', aliases: ['killall'], category: 'world',
  desc: '杀死全场所有生物（可指定类型）',
  usage: '/slayall [类型]',
  fn: (args) => {
    const g = _needGame();
    const type = args[0];

    if (type){
      if (typeof g.killEntitiesOfType !== 'function'){
        return { ok: false, message: '缺少实体 API（先跑 patch_mod_host_entities.py）' };
      }
      const n = g.killEntitiesOfType(type);
      return `已杀死 ${n} 个 ${type}`;
    }

    if (typeof g.getEntities !== 'function'){
      return { ok: false, message: '缺少实体 API（先跑 patch_mod_host_entities.py）' };
    }
    const list = g.getEntities();
    let n = 0;
    for (const a of list){
      try { g.damageEntity(a, 999999); n++; } catch(e){}
    }
    return `已杀死全部 ${n} 个生物`;
  },
});

registerCommand({
  name: 'entities', aliases: ['mobs'], category: 'world',
  desc: '列出附近或全场实体统计',
  usage: '/entities [半径]',
  fn: (args) => {
    const g = _needGame();
    if (typeof g.getEntities !== 'function'){
      return { ok: false, message: '缺少实体 API（先跑 patch_mod_host_entities.py）' };
    }
    const p = g.getPos();
    const r = parseFloat(args[0]);
    let list;
    let scope;
    if (isFinite(r) && r > 0){
      list = g.getEntitiesInRange(p.x, p.y, p.z, r);
      scope = `半径 ${r} 内`;
    } else {
      list = g.getEntities();
      scope = '全场';
    }
    const counts = {};
    for (const a of list) counts[a.type] = (counts[a.type] || 0) + 1;
    const parts = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([t, n]) => `${t}×${n}`)
      .join('  ');
    return {
      ok: true,
      message: `${scope} ${list.length} 个实体`,
      detail: parts || '(无)',
    };
  },
});

registerCommand({
  name: 'summon', aliases: ['spawnmob'], category: 'world',
  desc: '在身边生成实体',
  usage: '/summon <类型> [数量] · /summon list 查看可用类型',
  fn: (args) => {
    const g = _needGame();
    if (typeof g.spawnEntity !== 'function'){
      return { ok: false, message: '缺少实体生成 API' };
    }

    const sub = (args[0] || '').toLowerCase();

    /* 列出类型 */
    if (!sub || sub === 'list'){
      let types = [];
      try { types = g.listEntityTypes ? (g.listEntityTypes() || []) : []; } catch(e){}
      return {
        ok: true,
        message: sub ? `可生成实体 ${types.length} 种` : '用法: /summon <类型> [数量]',
        detail: types.join('  ') || '(无)',
      };
    }

    if (g.hasEntityType && !g.hasEntityType(sub)){
      return { ok: false, message: `未知实体类型: ${sub}（用 /summon list 查看）` };
    }

    const n = Math.max(1, Math.min(20, parseInt(args[1] || '1', 10) || 1));
    const p = g.getPos();
    let spawned = 0;

    for (let i = 0; i < n; i++){
      const ang = Math.random() * Math.PI * 2;
      const r = 1.5 + Math.random() * 1.8;
      try {
        const e = g.spawnEntity(
          sub,
          p.x + Math.cos(ang) * r,
          p.y + 0.5,
          p.z + Math.sin(ang) * r
        );
        if (e) spawned++;
      } catch(err){}
    }

    if (!spawned) return { ok: false, message: `生成 ${sub} 失败` };
    return `已生成 ${spawned} 个 ${sub}`;
  },
});


/* ---- 定位群系 / 结构 ---- */
const _BIOME_CN = {
  '海洋':'ocean','沙滩':'beach','平原':'plains','森林':'forest',
  '樱花林':'sakura','白桦林':'birch_forest','沼泽':'swamp','针叶林':'taiga',
  '雪原':'snow','沙漠':'desert','稀树草原':'savanna','丛林':'jungle',
  '荒地':'badlands','红树林':'mangrove','蘑菇岛':'mushroom','河流':'river',
};

registerCommand({
  name: 'locate', aliases: ['find', 'search'], category: 'world',
  desc: '定位最近的群系 / 结构',
  usage: '/locate <biome|structure|list> [名字] [半径]',
  fn: async (args) => {
    const g = _needGame();
    const kind = (args[0] || '').toLowerCase();

    /* ---- /locate list ---- */
    if (kind === 'list' || kind === 'l'){
      const biomes = (typeof g.listBiomes === 'function')
        ? g.listBiomes().map(b => `${b.label}(${b.name})`).join('  ')
        : '(不可用)';
      return {
        ok: true,
        message: '可定位的群系和结构',
        detail:
          '群系:\n  ' + biomes +
          '\n\n结构:\n  temple    海底神殿（全局唯一）\n  iceberg   冰山（寒冷海域）' +
          '\n  lostcity  失落古城（丛林，含故障守卫 Boss）' +
          '\n\n用法:\n  /locate biome <群系名> [半径]\n  /locate structure <结构名> [半径]',
      };
    }

    const rawName = args[1];
    const radius = Math.max(128, Math.min(8000, parseInt(args[2], 10) || 2000));
    const p = g.getPos();

    /* ---- /locate biome ---- */
    if (kind === 'biome' || kind === 'b'){
      if (!rawName) return { ok: false, message: '用法: /locate biome <群系名>' };

      const biomeKey = _BIOME_CN[rawName] || String(rawName).toLowerCase();
      const bio = (typeof g.getBiomeByName === 'function')
        ? g.getBiomeByName(biomeKey) : null;
      if (!bio) return { ok: false, message: `未知群系: ${rawName}（用 /locate list 查看）` };

      const targetId = bio.id;
      const step = 32;
      let found = null;
      let scans = 0;

      outer:
      for (let r = 0; r <= radius; r += step){
        const n = Math.max(1, Math.round(Math.PI * 2 * r / step));
        for (let i = 0; i < n; i++){
          const ang = (i / n) * Math.PI * 2;
          const x = Math.round(p.x + Math.cos(ang) * r);
          const z = Math.round(p.z + Math.sin(ang) * r);
          const h = g.heightAt(x, z);
          scans++;
          if (g.biomeAt(x, z, h) === targetId){
            found = { x, z, h };
            break outer;
          }
        }
        /* 每 8 圈让出一次执行权，避免卡死 */
        if (r > 0 && r % (step * 8) === 0){
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }

      if (!found){
        return { ok: false, message: `半径 ${radius} 内没找到 ${bio.label}（扫描 ${scans} 点）` };
      }
      const dist = Math.round(Math.hypot(found.x - p.x, found.z - p.z));
      return {
        ok: true,
        message: `最近 ${bio.label} 在 ${found.x}, ${found.z}（h=${found.h}, 距离 ${dist}）`,
        detail: `传送：/tp ${found.x} ${found.h + 1} ${found.z}`,
      };
    }

    /* ---- /locate structure ---- */
    if (kind === 'structure' || kind === 's'){
      const sName = (rawName || '').toLowerCase();
      if (!sName) return { ok: false, message: '用法: /locate structure <temple|iceberg|lostcity>' };

      const wg = (typeof g.getWorldGen === 'function') ? g.getWorldGen() : null;
      if (!wg) return { ok: false, message: 'worldGen 不可用（先跑 patch_locate.py）' };
      const SEA = (typeof g.SEA_LEVEL === 'number') ? g.SEA_LEVEL : 46;

      /* --- temple --- */
      if (sName === 'temple' || sName === '神殿' || sName === '海底神殿'){
        let pos = null;
        try { pos = wg.findTemple(); }
        catch(e){ return { ok: false, message: 'findTemple 出错: ' + e.message }; }
        if (!pos) return { ok: false, message: '这个世界没有神殿' };
        const h = g.heightAt(pos.x, pos.z);
        const dist = Math.round(Math.hypot(pos.x - p.x, pos.z - p.z));
        return {
          ok: true,
          message: `神殿在 ${pos.x}, ${pos.z}（基座 h=${h}, 距离 ${dist}）`,
          detail: `传送：/tp ${pos.x} ${SEA + 12} ${pos.z}\n神殿基座在水下，传送到海平面附近往下看`,
        };
      }

      /* --- lostcity --- */
      if (sName === 'lostcity' || sName === 'lost_city' || sName === 'city'
          || sName === '失落古城' || sName === '古城'){
        let pos = null;
        try {
          if (typeof wg.findLostCity === 'function') pos = wg.findLostCity();
        } catch(e){
          return { ok: false, message: 'findLostCity 出错: ' + e.message };
        }
        if (!pos) return { ok: false, message: '这个世界没有失落古城（需丛林高地）' };
        const y = Math.round(pos.baseY);
        const bx = Math.round(pos.x), bz = Math.round(pos.z);
        const dist = Math.round(Math.hypot(bx - p.x, bz - p.z));
        return {
          ok: true,
          message: `失落古城在 ${bx}, ${bz}（地面 y=${y}, 距离 ${dist}）`,
          detail: `传送：/tp ${bx} ${y + 2} ${bz}\n中央广场有故障守卫 Boss，四座破损房屋内有宝箱与床`,
        };
      }

      /* --- iceberg --- */
      if (sName === 'iceberg' || sName === '冰山'){
        let hash2i;
        try { ({ hash2i } = await import('../core/runtime.js')); }
        catch(e){ return { ok: false, message: '无法加载 runtime.js' }; }

        const ICE_CELL = 128;
        const ICE_CHANCE = 0.45;
        const ICE_TEMP = 0.16;
        const SEED = (wg.cfg && wg.cfg.seed) | 0;

        const cellX0 = Math.floor(p.x / ICE_CELL);
        const cellZ0 = Math.floor(p.z / ICE_CELL);
        const maxCells = Math.ceil(radius / ICE_CELL);

        for (let r = 0; r <= maxCells; r++){
          const cells = [];
          for (let dx = -r; dx <= r; dx++){
            for (let dz = -r; dz <= r; dz++){
              if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
              cells.push([cellX0 + dx, cellZ0 + dz]);
            }
          }
          /* 距离近的先试 */
          cells.sort((a, b) => {
            const da = Math.hypot((a[0] + 0.5) * ICE_CELL - p.x,
                                  (a[1] + 0.5) * ICE_CELL - p.z);
            const db = Math.hypot((b[0] + 0.5) * ICE_CELL - p.x,
                                  (b[1] + 0.5) * ICE_CELL - p.z);
            return da - db;
          });

          for (const [cx, cz] of cells){
            const cellSeed = SEED + cx * 73856093 + cz * 19349663;
            if (hash2i(cx, cz, 9001 + cellSeed) > ICE_CHANCE) continue;

            const px = (cx + 0.20 + hash2i(cx, cz, 9002 + cellSeed) * 0.60) * ICE_CELL;
            const pz = (cz + 0.20 + hash2i(cx, cz, 9003 + cellSeed) * 0.60) * ICE_CELL;

            let t = 0.5;
            try {
              if (wg.params && typeof wg.params.temperatureAt === 'function'){
                t = wg.params.temperatureAt(px, SEA, pz);
              } else if (wg.params && typeof wg.params.temperature === 'function'){
                t = wg.params.temperature(px, pz);
              }
            } catch(e){}
            if (t >= ICE_TEMP) continue;

            const h = g.heightAt(Math.round(px), Math.round(pz));
            if (h >= SEA) continue;

            const bio = g.biomeAt(Math.round(px), Math.round(pz), h);
            if (bio !== 0 && bio !== 15) continue;

            const dist = Math.round(Math.hypot(px - p.x, pz - p.z));
            return {
              ok: true,
              message: `冰山在 ${Math.round(px)}, ${Math.round(pz)}（距离 ${dist}, 温度 ${t.toFixed(3)}）`,
              detail: `传送：/tp ${Math.round(px)} ${SEA + 20} ${Math.round(pz)}`,
            };
          }

          if (r > 0 && r % 4 === 0){
            await new Promise(resolve => setTimeout(resolve, 0));
          }
        }
        return { ok: false, message: `半径 ${radius} 内没找到冰山` };
      }

      return { ok: false, message: `未知结构: ${rawName}（可用: temple / iceberg / lostcity）` };
    }

    return { ok: false, message: '用法: /locate <biome|structure|list> [名字] [半径]' };
  },
});




/* ---- 特权终端 ---- */
const _TDIR = '/terminal/';

async function _listScripts(){
  try {
    const r = await fetch(_TDIR + 'index.json?t=' + Date.now());
    if (!r.ok) return [];
    const d = await r.json();
    return Array.isArray(d && d.scripts) ? d.scripts : [];
  } catch(e){ return []; }
}

function _safeName(name){
  const n = String(name || '').trim();
  if (!n) throw new Error('需要脚本名');
  const f = n.endsWith('.js') ? n : n + '.js';
  if (f.includes('..') || f.includes('/') || f.includes('\\')){
    throw new Error('脚本名不能包含路径分隔符');
  }
  return f;
}

async function _runScript(name, args){
  const f = _safeName(name);
  _appendLine('$ /run ' + f + (args.length ? ' ' + args.join(' ') : ''), 'line-cmd');
  const url = _TDIR + encodeURIComponent(f) + '?t=' + Date.now();
  const ctx = {
    G: window.__GAME__ || null,
    args: args.slice(),
    log: (...a) => {
      const s = a.map(x => {
        try {
          if (x === null) return 'null';
          if (x === undefined) return 'undefined';
          if (typeof x === 'object') return JSON.stringify(x);
          return String(x);
        } catch(e){ return String(x); }
      }).join(' ');
      _appendLine(s, 'line-info');
    },
  };
  ctx.print = (...a) => ctx.log(...a);
  try {
    const mod = await import(/* @vite-ignore */ url);
    let r;
    if (typeof mod.run === 'function') r = await mod.run(ctx);
    else if (typeof mod.default === 'function') r = await mod.default(ctx.G, args);
    if (typeof r === 'string' && r) _appendLine('↩ ' + r, 'line-ok');
    else _appendLine('↩ (完成)', 'line-ok');
    return { ok: true, message: '' };
  } catch(e){
    _appendLine('✘ ' + ((e && (e.message || String(e))) || '未知错误'), 'line-err');
    if (e && e.stack) console.error('[terminal]', e);
    return { ok: false, message: '' };
  }
}

registerCommand({
  name: 'ls', aliases: ['scripts'], category: 'terminal',
  desc: '列出 terminal/ 脚本', usage: '/ls',
  fn: async () => {
    const list = await _listScripts();
    if (!list.length){
      return { ok: true, message: '无登记脚本',
        detail: '把 .js 放到 terminal/ 后可直接 /run <文件名>' };
    }
    return { ok: true, message: `共 ${list.length} 个脚本`,
      detail: list.map(n => '  ' + n).join('\n') };
  },
});

registerCommand({
  name: 'run', aliases: ['exec', 'script'], category: 'terminal',
  desc: '运行 terminal/ 下的脚本', usage: '/run <脚本名> [参数...]',
  fn: async (args) => {
    if (!args[0]) return { ok: false, message: '用法: /run <脚本名> [参数...]' };
    return await _runScript(args[0], args.slice(1));
  },
});

registerCommand({
  name: 'cat', category: 'terminal',
  desc: '查看脚本源码', usage: '/cat <脚本名>',
  fn: async (args) => {
    if (!args[0]) return { ok: false, message: '用法: /cat <脚本名>' };
    try {
      const f = _safeName(args[0]);
      const r = await fetch(_TDIR + encodeURIComponent(f) + '?t=' + Date.now());
      if (!r.ok) throw new Error(`读不到 ${f}（HTTP ${r.status}）`);
      const src = await r.text();
      const cut = src.length > 4000 ? src.slice(0, 4000) + '\n... (截断)' : src;
      return { ok: true, message: `${f}（${src.length} 字节）`, detail: cut };
    } catch(e){ return { ok: false, message: e.message }; }
  },
});

registerCommand({
  name: 'eval', category: 'terminal',
  desc: '直接执行 JS 表达式', usage: '/eval <表达式>',
  fn: async (args, raw) => {
    const code = String(raw || '').replace(/^\/?eval\s+/i, '').trim();
    if (!code) return { ok: false, message: '用法: /eval <JS 表达式>' };
    const G = window.__GAME__ || null;
    const pretty = (v) => {
      try {
        if (v === null) return 'null';
        if (v === undefined) return 'undefined';
        if (typeof v === 'object') return JSON.stringify(v);
        return String(v);
      } catch(e){ return String(v); }
    };
    try {
      return { ok: true, message: '=> ' + pretty(new Function('G', 'return (' + code + ');')(G)) };
    } catch(e1){
      try {
        return { ok: true, message: '=> ' + pretty(new Function('G', code)(G)) };
      } catch(e2){
        return { ok: false, message: '执行失败: ' + (e2.message || e2) };
      }
    }
  },
});


/* ============================================================
   终端 UI（内嵌于设置面板的 #tab-commands）
   ============================================================ */
let _installed = false;
let _outEl = null;
let _inputEl = null;
let _hintEl = null;

const HIST_KEY = '3dmc_cmd_history';
let _history = [];
try { _history = JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); } catch(e){ _history = []; }
if (!Array.isArray(_history)) _history = [];
let _histIdx = _history.length;

function _saveHistory(){
  try {
    const tail = _history.slice(-60);
    localStorage.setItem(HIST_KEY, JSON.stringify(tail));
  } catch(e){}
}

function _esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

function _installStyle(){
  if (document.getElementById('__cmdterm_style__')) return;
  const st = document.createElement('style');
  st.id = '__cmdterm_style__';
  st.textContent = `
#tab-commands { display: flex; flex-direction: column; height: 100%; }

.cmdterm {
  background: #0a0f18;
  border: 1px solid rgba(120,180,255,.25);
  border-radius: 10px;
  font-family: "SF Mono", Consolas, "Courier New", monospace;
  display: flex;
  flex-direction: column;
  height: 340px;
  max-height: 55vh;
  overflow: hidden;
}
.cmdterm-out {
  flex: 1;
  overflow-y: auto;
  padding: 10px 14px;
  font-size: 12px;
  line-height: 1.65;
  color: #c8d4e0;
  scroll-behavior: smooth;
}
.cmdterm-out .line {
  white-space: pre-wrap;
  word-break: break-all;
  margin: 2px 0;
}
.cmdterm-out .line-cmd {
  color: #7bd0ff;
  margin-top: 8px;
}
.cmdterm-out .line-ok   { color: #8ee88e; }
.cmdterm-out .line-err  { color: #ff9090; }
.cmdterm-out .line-info { color: #b8c8d8; }
.cmdterm-out .line-mute { color: #5a6d80; font-style: italic; }

.cmdterm-in {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border-top: 1px solid rgba(255,255,255,.08);
  background: rgba(255,255,255,.02);
}
.cmdterm-prefix {
  color: #7bd0ff;
  font-weight: bold;
  font-size: 14px;
}
#cmdTermInput {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: #e8ecf2;
  font-family: inherit;
  font-size: 13px;
  padding: 4px 0;
  caret-color: #7bd0ff;
}
#cmdTermInput::placeholder { color: #3f4d5e; }

.cmdterm-hint {
  padding: 6px 14px;
  font-size: 11px;
  color: #5a6d80;
  min-height: 16px;
  border-top: 1px solid rgba(255,255,255,.05);
  background: rgba(0,0,0,.15);
}

.cmdterm-cmds {
  margin-top: 14px;
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 8px;
  background: rgba(255,255,255,.02);
  overflow: hidden;
}
.cmdterm-cmds summary {
  padding: 10px 14px;
  cursor: pointer;
  font-size: 12px;
  color: #8fa3b8;
  user-select: none;
}
.cmdterm-cmds summary:hover { background: rgba(255,255,255,.04); }
.cmdterm-cmds[open] summary {
  border-bottom: 1px solid rgba(255,255,255,.08);
  background: rgba(255,255,255,.04);
}
.cmdterm-cmds .cmdlist {
  padding: 8px 14px 12px;
  max-height: 300px;
  overflow-y: auto;
}
.cmdterm-cmds .cmd-row {
  display: flex;
  gap: 12px;
  align-items: baseline;
  padding: 6px 0;
  border-bottom: 1px dashed rgba(255,255,255,.05);
  font-size: 12px;
}
.cmdterm-cmds .cmd-row:last-child { border-bottom: none; }
.cmdterm-cmds .cmd-name {
  font-family: "SF Mono", Consolas, monospace;
  color: #7bd0ff;
  min-width: 110px;
  flex-shrink: 0;
}
.cmdterm-cmds .cmd-desc {
  flex: 1;
  color: #b8c8d8;
  line-height: 1.5;
}
.cmdterm-cmds .cmd-usage {
  font-family: "SF Mono", Consolas, monospace;
  color: #5a6d80;
  font-size: 11px;
  white-space: nowrap;
  flex-shrink: 0;
}
`;
  document.head.appendChild(st);
}

function _appendLine(text, cls){
  if (!_outEl) return;
  const div = document.createElement('div');
  div.className = 'line ' + (cls || 'line-info');
  div.textContent = text;
  _outEl.appendChild(div);
  _outEl.scrollTop = _outEl.scrollHeight;
}

function _printWelcome(){
  _outEl.innerHTML = '';
  _appendLine('深入世界 VertiWorld 命令终端 · 版本 V0.0.0', 'line-mute');
  _appendLine('输入 /help 查看命令列表 · ↑↓ 历史 · Tab 补全 · Enter 执行', 'line-mute');
  _appendLine('', 'line-mute');
}

function _moveCaretToEnd(el){
  requestAnimationFrame(() => {
    const len = el.value.length;
    try { el.setSelectionRange(len, len); } catch(e){}
  });
}

function _showPreviewHint(){
  if (!_hintEl) return;
  const v = _inputEl.value.trim();
  if (!v){ _hintEl.textContent = ''; return; }
  const parts = v.replace(/^\//, '').split(/\s+/);
  const name = (parts[0] || '').toLowerCase();
  const cmd = _commands.get(name);
  if (!cmd){ _hintEl.textContent = ''; return; }
  _hintEl.textContent = (cmd.desc || '') + (cmd.usage ? '  ·  ' + cmd.usage : '');
}

function _autocomplete(){
  const v = _inputEl.value;
  const parts = v.split(/\s+/);
  if (parts.length !== 1) return;
  const prefix = parts[0].toLowerCase();
  if (!prefix) return;
  const cands = [];
  for (const name of _commands.keys()){
    if (name.startsWith(prefix)) cands.push(name);
  }
  if (cands.length === 1){
    _inputEl.value = cands[0] + ' ';
    _moveCaretToEnd(_inputEl);
    _showPreviewHint();
  } else if (cands.length > 1){
    _hintEl.textContent = '候选: ' + cands.slice(0, 20).join('  ');
  }
}

async function _runInput(val){
  const raw = val.trim();
  if (!raw) return;
  _appendLine('> ' + raw, 'line-cmd');
  const res = await executeCommand(raw);
  if (res.message){
    _appendLine(res.message, res.ok ? 'line-ok' : 'line-err');
  }
  if (res.detail){
    _appendLine(res.detail, 'line-info');
  }
  if (res.message){
    try { toast(res.message); } catch(e){}
  }
}

function _renderCmdList(){
  const el = document.getElementById('cmdTermCmds');
  if (!el) return;
  const list = listCommands();
  let html = `<summary>查看全部命令 (${list.length})</summary><div class="cmdlist">`;
  for (const c of list){
    html += `
      <div class="cmd-row">
        <div class="cmd-name">/${_esc(c.name)}</div>
        <div class="cmd-desc">${_esc(c.desc)}</div>
        <div class="cmd-usage">${_esc(c.usage)}</div>
      </div>`;
  }
  html += '</div>';
  el.innerHTML = html;
}

function _buildTerm(){
  _installStyle();
  const tab = document.getElementById('tab-commands');
  if (!tab) return false;
  if (tab.querySelector('#cmdTerm')) return true;

  tab.innerHTML = `
    <div class="cmdterm" id="cmdTerm">
      <div class="cmdterm-out" id="cmdTermOut"></div>
      <div class="cmdterm-in">
        <span class="cmdterm-prefix">/</span>
        <input id="cmdTermInput" type="text" autocomplete="off"
               autocorrect="off" autocapitalize="off" spellcheck="false"
               placeholder="输入命令...">
      </div>
      <div class="cmdterm-hint" id="cmdTermHint"></div>
    </div>
    <details class="cmdterm-cmds" id="cmdTermCmds"></details>
  `;

  _outEl   = tab.querySelector('#cmdTermOut');
  _inputEl = tab.querySelector('#cmdTermInput');
  _hintEl  = tab.querySelector('#cmdTermHint');

  _inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter'){
      e.preventDefault();
      const val = _inputEl.value;
      _inputEl.value = '';
      if (val.trim()){
        _history.push(val);
        _saveHistory();
        _histIdx = _history.length;
      }
      _runInput(val);
      return;
    }
    if (e.key === 'ArrowUp'){
      e.preventDefault();
      if (_history.length === 0) return;
      _histIdx = Math.max(0, _histIdx - 1);
      _inputEl.value = _history[_histIdx] || '';
      _moveCaretToEnd(_inputEl);
      return;
    }
    if (e.key === 'ArrowDown'){
      e.preventDefault();
      if (_history.length === 0) return;
      _histIdx = Math.min(_history.length, _histIdx + 1);
      _inputEl.value = _history[_histIdx] || '';
      _moveCaretToEnd(_inputEl);
      return;
    }
    if (e.key === 'Tab'){
      e.preventDefault();
      _autocomplete();
      return;
    }
    if (e.key === 'Escape'){
      e.preventDefault();
      _inputEl.value = '';
      _hintEl.textContent = '';
      return;
    }
    // 其他键透传也没关系：设置面板里本来就不跑游戏
  });
  _inputEl.addEventListener('input', _showPreviewHint);

  _printWelcome();
  _renderCmdList();
  return true;
}


/* ============================================================
   公开接口
   ============================================================ */

/** 在设置面板里注入/更新"命令"tab（幂等） */
export function setupCommandSettings(){
  if (_installed) {
    /* tab 可能被重建（比如面板被清空），重新构建 */
    _buildTerm();
    _renderCmdList();
    return;
  }

  const sidebar = document.getElementById('settingsSidebar');
  const main = document.querySelector('.settings-main');
  if (!sidebar || !main){
    // 设置面板还没渲染出来，下一帧再试
    setTimeout(() => { try { setupCommandSettings(); } catch(e){} }, 50);
    return;
  }
  _installed = true;

  /* 侧栏按钮 */
  if (!sidebar.querySelector('[data-tab="commands"]')){
    const b = document.createElement('button');
    b.className = 'sidebar-item';
    b.dataset.tab = 'commands';
    b.textContent = '命令';
    sidebar.appendChild(b);
  }

  /* 主面板 tab */
  if (!document.getElementById('tab-commands')){
    const tab = document.createElement('div');
    tab.className = 'settings-tab';
    tab.id = 'tab-commands';
    tab.style.display = 'none';
    main.appendChild(tab);
  }

  _buildTerm();

  /* 进入命令 tab 时自动聚焦输入框 */
  sidebar.addEventListener('click', (e) => {
    const item = e.target.closest('.sidebar-item');
    if (!item) return;
    if (item.dataset.tab === 'commands'){
      requestAnimationFrame(() => {
        if (_inputEl) { try { _inputEl.focus(); } catch(err){} }
      });
    }
  });
}

/** 保留旧接口（mod 可能调用）：打开 = 切到命令 tab 并聚焦 */
export function openCommandInput(initial){
  const sidebar = document.getElementById('settingsSidebar');
  const settingsEl = document.getElementById('settings');
  if (!sidebar || !settingsEl) return;
  settingsEl.classList.add('show');
  const btn = sidebar.querySelector('[data-tab="commands"]');
  if (btn) btn.click();
  if (typeof initial === 'string' && _inputEl){
    _inputEl.value = initial;
    _moveCaretToEnd(_inputEl);
    _showPreviewHint();
  }
}

export function closeCommandInput(){ /* 兼容旧接口，无操作 */ }
export function isCommandInputOpen(){ return false; }
