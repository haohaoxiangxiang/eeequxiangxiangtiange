/* ============================================================
   ui-panel.js —— 预览 / 全屏 / 打包 / 贴图编辑器 / 面板样式
   ------------------------------------------------------------
★ 合并自 5 个较小的 UI 模块（约 42KB）：
     preview.js         世界列表右侧缩略图
     fullscreen.js      全屏切换（含 iOS 兜底）
     packs.js           地图 / 整合包导入导出
     texture-editor.js  游戏内贴图编辑器
     mod-panel/style.js MOD 面板的全部 CSS（installModPanelStyle）
   ============================================================ */

/* 被合并文件原来的外部依赖 */
import { BLOCKS, B } from '../world/blocks.js';
import { SEA_LEVEL, ATLAS_TILE, ATLAS_COLS, TEX_INNER } from '../core/engine-core.js';
import { TEX, atlasCanvasEl } from '../world/textures.js';

import { createDensityField } from '../world/core/density.js';
import { createParamSystem }  from '../world/core/terrain-params.js';
import { getBiome, listBiomes } from '../world/world-core.js';
import { vnoise } from '../core/runtime.js';



/* =================================================================
   preview.js
   ================================================================= */
/* ============================================================
   preview.js —— 地势预览
   ------------------------------------------------------------
   用 params + density 反推高度，128×128 分辨率。
   生成后缓存到 localStorage。
   ============================================================ */






const CACHE_KEY = '3dmc_preview_height_v3';
const PREVIEW_SIZE = 128;
const PREVIEW_SPAN = 3000;

/* ============================================================
   高度反推（8 次迭代，精度 2 格）
   ============================================================ */
function makeHeightFn(density, yMin, yMax){
  return function(wx, wz){
    if (density.densityAt(wx, yMax, wz) > 0) return yMax;
    if (density.densityAt(wx, yMin, wz) <= 0) return yMin;
    let lo = yMin, hi = yMax;
    for (let i = 0; i < 8; i++){
      const mid = (lo + hi) >> 1;
      if (density.densityAt(wx, mid, wz) > 0) lo = mid;
      else hi = mid;
    }
    return lo;
  };
}

/* ============================================================
   高度 → 颜色
   ============================================================ */
function heightColor(h){
  const rel = h - SEA_LEVEL;
  if (rel < -20) return [15, 35, 90];      // 深海
  if (rel < -3)  return [30, 80, 160];     // 浅海
  if (rel < 3)   return [225, 210, 160];   // 沙滩
  if (rel < 30)  return [95, 170, 80];     // 平原绿
  if (rel < 70)  return [130, 150, 80];    // 丘陵黄绿
  if (rel < 120) return [140, 110, 80];    // 山地棕
  if (rel < 180) return [140, 125, 115];   // 高山灰
  return [240, 240, 250];                  // 雪顶
}

/* ============================================================
   缓存
   ============================================================ */
function loadCache(){
  try { return JSON.parse(localStorage.getItem(CACHE_KEY) || '{}'); }
  catch(e){ return {}; }
}
function saveCache(c){
  try {
    const keys = Object.keys(c);
    if (keys.length > 20){
      for (const k of keys.slice(0, keys.length - 20)) delete c[k];
    }
    localStorage.setItem(CACHE_KEY, JSON.stringify(c));
  } catch(e){}
}

/* ============================================================
   主渲染
   ============================================================ */
async function renderPreview(canvas, type, seed){
  const key = type + ':' + seed;
  const cache = loadCache();

  /* 缓存命中 */
  if (cache[key]){
    const img = new Image();
    img.onload = () => {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = cache[key];
    return;
  }

  /* 超平坦：纯色 */
  if (type === 'flat'){
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#78b45c';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    return;
  }

  const W = PREVIEW_SIZE;
  const H = PREVIEW_SIZE;
  const step = PREVIEW_SPAN / W;

  const yMin = -46;
  const yMax = 400;

  let params, density;
  try {
    params = createParamSystem({
      seed, SEA_LEVEL, Y_MIN: yMin, CHH: yMax,
    });
    density = createDensityField(params, { seed, SEA_LEVEL });
  } catch(e){
    console.warn('[preview] 初始化失败:', e);
    return;
  }

  const heightAt = makeHeightFn(density, yMin, yMax);

  /* 预计算高度图 */
  const heightMap = new Float32Array(W * H);
  for (let py = 0; py < H; py++){
    for (let px = 0; px < W; px++){
      const wx = Math.floor((px - W / 2) * step);
      const wz = Math.floor((py - H / 2) * step);
      heightMap[py * W + px] = heightAt(wx, wz);
    }
  }

  /* 上色 + 左上光 */
  const off = document.createElement('canvas');
  off.width = W;
  off.height = H;
  const offCtx = off.getContext('2d');
  const imgData = offCtx.createImageData(W, H);
  const d = imgData.data;

  for (let py = 0; py < H; py++){
    for (let px = 0; px < W; px++){
      const idx = py * W + px;
      const h = heightMap[idx];

      const hL = (px > 0 && py > 0)
        ? heightMap[(py - 1) * W + (px - 1)]
        : h;
      const dh = h - hL;
      const shade = 1 + Math.max(-0.35, Math.min(0.35, dh * 0.04));

      const c = heightColor(h);
      const i = idx * 4;
      d[i]     = Math.max(0, Math.min(255, c[0] * shade)) | 0;
      d[i + 1] = Math.max(0, Math.min(255, c[1] * shade)) | 0;
      d[i + 2] = Math.max(0, Math.min(255, c[2] * shade)) | 0;
      d[i + 3] = 255;
    }
  }
  offCtx.putImageData(imgData, 0, 0);

  /* 缩放到目标 canvas */
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(off, 0, 0, canvas.width, canvas.height);

  /* 缓存 */
  try {
    cache[key] = off.toDataURL('image/png');
    saveCache(cache);
  } catch(e){}
}

/* =================================================================
   fullscreen.js
   ================================================================= */
/* ============================================================
   fullscreen.js —— 全屏切换
   ------------------------------------------------------------
   · 必须在用户手势（click/tap）里调用
   · 移动端 Safari/WebKit 需要 webkit 前缀
   · 支持多浏览器事件名
   ============================================================ */

function isFullscreen(){
  return !!(
    document.fullscreenElement ||
    document.webkitFullscreenElement ||
    document.mozFullScreenElement ||
    document.msFullscreenElement
  );
}

function requestFullscreen(el){
  el = el || document.documentElement;
  const fn = el.requestFullscreen
          || el.webkitRequestFullscreen
          || el.mozRequestFullScreen
          || el.msRequestFullscreen;
  if (!fn) return false;
  try {
    /* navigationUI:'hide' 是标准选项，部分浏览器会忽略，忽略也不报错 */
    const p = fn.call(el, { navigationUI: 'hide' });
    if (p && typeof p.catch === 'function') p.catch(() => {});
  } catch(e){
    try { fn.call(el); } catch(e2){}
  }
  return true;
}

function exitFullscreen(){
  const fn = document.exitFullscreen
          || document.webkitExitFullscreen
          || document.mozCancelFullScreen
          || document.msExitFullscreen;
  if (!fn) return false;
  try { fn.call(document); } catch(e){}
  return true;
}

function toggleFullscreen(){
  if (isFullscreen()) exitFullscreen();
  else requestFullscreen();
}

/** 全屏状态变化回调；返回解绑函数 */
function onFullscreenChange(cb){
  const events = [
    'fullscreenchange',
    'webkitfullscreenchange',
    'mozfullscreenchange',
    'MSFullscreenChange',
  ];
  const handler = () => cb(isFullscreen());
  for (const e of events) document.addEventListener(e, handler);
  return () => {
    for (const e of events) document.removeEventListener(e, handler);
  };
}

/* =================================================================
   packs.js
   ================================================================= */
/* ============================================================
   packs.js —— 地图 / 整合包的导入导出（共用逻辑）
   ------------------------------------------------------------
   四个动作原来散在 menu.js 里，现在集中到这里，被三个地方复用：
     · 世界类型选择对话框   → 导入地图
     · 创建世界的「选择 Mod」→ 导入整合包
     · 世界设置             → 导出地图 / 导出整合包
   服务端接口与包格式见 mod开发3.md 第 4 节。
   ============================================================ */

const API = {
  importMap:     '/api/import-map',
  exportMap:     '/api/export-map',
  importModpack: '/api/import-modpack',
  exportModpack: '/api/export-modpack',
};

/* 统一的错误信息：优先用服务端返回的 error 字段 */
async function _readError(res){
  let msg = `HTTP ${res.status}`;
  try {
    const d = await res.json();
    if (d && d.error) msg = d.error;
  } catch(e){}
  return msg;
}

/* 触发浏览器下载 */
function _download(blob, fileName){
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* 拉一个本地文件（zip） */
function _pickFile(){
  return new Promise(resolve => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.zip,application/zip';
    input.onchange = e => resolve((e.target.files && e.target.files[0]) || null);
    input.click();
  });
}

function _safeName(s, fallback){
  const n = String(s == null ? '' : s).replace(/[\\/:*?"<>|]/g, '_').trim();
  return (n || fallback || 'pack').slice(0, 48);
}

/* 通知别处刷新（都做了存在性判断，少了也不会炸） */
function _refreshAfterImport(which){
  try { if (typeof window.__refreshModBrowser === 'function') window.__refreshModBrowser(); } catch(e){}
  try { if (typeof window.__renderWorldList === 'function') window.__renderWorldList(); } catch(e){}
  try { window.dispatchEvent(new CustomEvent('packs:' + which)); } catch(e){}
}

/* ============================================================
   导入地图 → 生成一个新存档
   @returns {Promise<{ok,saveId,name,mods}|null>}  null = 用户取消
   ============================================================ */
async function importMapFile(){
  const file = await _pickFile();
  if (!file) return null;

  const res = await fetch(API.importMap, {
    method: 'POST',
    body: await file.arrayBuffer(),
  });

  if (!res.ok) throw new Error(await _readError(res));
  const data = await res.json();
  _refreshAfterImport('map-imported');
  return data;
}

/* ============================================================
   导出地图（存档 + 它用到的 mod）
   ============================================================ */
async function exportMap(saveId, fileName){
  if (!saveId) throw new Error('请先选中一个世界');
  const res = await fetch(API.exportMap, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ saveId }),
  });
  if (!res.ok) throw new Error(await _readError(res));
  _download(await res.blob(), _safeName(fileName || saveId, saveId) + '.zip');
  return true;
}

/* ============================================================
   导入整合包 → 安装 mod（不动存档）
   @returns {Promise<{ok,meta,mods}|null>}
   ============================================================ */
async function importModpackFile(){
  const file = await _pickFile();
  if (!file) return null;

  const res = await fetch(API.importModpack, {
    method: 'POST',
    body: await file.arrayBuffer(),
  });

  if (!res.ok) throw new Error(await _readError(res));
  const data = await res.json();
  _refreshAfterImport('modpack-imported');
  return data;
}

/* ============================================================
   导出整合包（默认导出该世界 world.json.plugins 里的 mod）
   ============================================================ */
async function exportModpack(name, mods){
  const res = await fetch(API.exportModpack, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name || 'modpack', mods: Array.isArray(mods) ? mods : [] }),
  });
  if (!res.ok) throw new Error(await _readError(res));
  _download(await res.blob(), _safeName(name, 'modpack') + '.zip');
  return true;
}

/* =================================================================
   texture-editor.js
   ================================================================= */
const SIZE = 16;
const SCALE = 32; // 放大到 512x512

let currentTexName = null;
let currentColor = '#ffffff';
let tool = 'pen';
let clipboard = null;

const drawCanvas = document.getElementById('draw-canvas');
const bgCanvas   = document.getElementById('bg-canvas');
const listEl     = document.getElementById('list');

/* ★ 本段原本属于独立页面 texture-editor.html（这些画布 id 只在那里存在）。
   合并进 ui-panel.js 之后，在游戏页 index.html 里它们是 null，
   原先这里直接 drawCanvas.getContext('2d') 会在【模块顶层】抛 TypeError，
   导致整个 ESM 模块图求值中断、main.js 一行都不执行 ——
   表现就是「开始界面所有按钮都点不动，控制台却没有业务逻辑报错」。
   所以整段用存在性判断包起来：游戏页跳过，texture-editor.html 照常运行。 */
if (drawCanvas && bgCanvas && listEl){
const ctx = drawCanvas.getContext('2d');
ctx.imageSmoothingEnabled = false;

const bgCtx = bgCanvas.getContext('2d');
bgCtx.imageSmoothingEnabled = false;
  const texGroups = {}; // texName -> [blockNames]

  for (const blk of BLOCKS) {
    if (!blk || blk.id === 0) continue;
    for (const tileId of blk.tiles) {
      for (const [name, id] of Object.entries(TEX)) {
        if (id === tileId) {
          if (!texGroups[name]) texGroups[name] = new Set();
          texGroups[name].add(blk.label || blk.name);
        }
      }
    }
  }

  // 处理透光与不透光树叶的特殊命名
  if (TEX['oak_leaves']) texGroups['oak_leaves'] = texGroups['oak_leaves'] || new Set(['透光树叶']);
  if (TEX['oak_leaves_solid']) texGroups['oak_leaves_solid'] = texGroups['oak_leaves_solid'] || new Set(['实心树叶']);

  const sortedTexNames = Object.keys(texGroups).sort();

  function renderList(filter = '') {
    listEl.innerHTML = '';
    for (const name of sortedTexNames) {
      if (filter && !name.includes(filter) && !Array.from(texGroups[name]).join(',').includes(filter)) continue;
    
      const el = document.createElement('div');
      el.className = 'item' + (name === currentTexName ? ' active' : '');
    
      const img = document.createElement('img');
      img.className = 'icon';
      img.src = getTexDataUrl(name);
    
      const span = document.createElement('span');
      span.textContent = name;
      span.title = '用于: ' + Array.from(texGroups[name]).join(', ');
    
      el.appendChild(img);
      el.appendChild(span);
      el.onclick = () => selectTex(name);
      listEl.appendChild(el);
    }
  }
  document.getElementById('search').oninput = (e) => renderList(e.target.value);

  function getTexDataUrl(name) {
    const idx = TEX[name];
    if (idx === undefined) return '';
    const col = idx % ATLAS_COLS;
    const row = Math.floor(idx / ATLAS_COLS);
    const c = document.createElement('canvas');
    c.width = c.height = TEX_INNER;
    c.getContext('2d').drawImage(
      atlasCanvasEl,
      col * ATLAS_TILE + 8, row * ATLAS_TILE + 8, TEX_INNER, TEX_INNER,
      0, 0, TEX_INNER, TEX_INNER
    );
    return c.toDataURL();
  }

  function loadTexToCanvas(name) {
    const idx = TEX[name];
    if (idx === undefined) return;
    const col = idx % ATLAS_COLS;
    const row = Math.floor(idx / ATLAS_COLS);
  
    bgCtx.clearRect(0, 0, 512, 512);
    bgCtx.drawImage(
      atlasCanvasEl,
      col * ATLAS_TILE + 8, row * ATLAS_TILE + 8, TEX_INNER, TEX_INNER,
      0, 0, 512, 512
    );
  
    ctx.clearRect(0, 0, 512, 512);
    ctx.drawImage(bgCanvas, 0, 0);
    drawGrid();
  }

  function drawGrid() {
    ctx.strokeStyle = 'rgba(255,255,255,0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= SIZE; i++) {
      ctx.beginPath(); ctx.moveTo(i * SCALE, 0); ctx.lineTo(i * SCALE, 512); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * SCALE); ctx.lineTo(512, i * SCALE); ctx.stroke();
    }
  }

  function selectTex(name) {
    currentTexName = name;
    document.getElementById('status').textContent = `正在编辑: ${name}`;
    renderList(document.getElementById('search').value);
    loadTexToCanvas(name);
  }

  const paletteEl = document.getElementById('palette');
  const colors = ['#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#888888', '#444444'];
  colors.forEach(c => {
    const el = document.createElement('div');
    el.className = 'color';
    el.style.background = c;
    el.onclick = () => { currentColor = c; document.getElementById('tool-pen').click(); };
    paletteEl.appendChild(el);
  });

  let isDrawing = false;

  function getMousePos(e) {
    const rect = drawCanvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / SCALE);
    const y = Math.floor((e.clientY - rect.top) / SCALE);
    return { x, y };
  }

  function paint(e) {
    if (!isDrawing || !currentTexName) return;
    const { x, y } = getMousePos(e);
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return;

    if (tool === 'pen') {
      ctx.fillStyle = currentColor;
      ctx.fillRect(x * SCALE, y * SCALE, SCALE, SCALE);
      drawGrid();
    } else if (tool === 'eraser') {
      ctx.clearRect(x * SCALE, y * SCALE, SCALE, SCALE);
      drawGrid();
    } else if (tool === 'picker') {
      const p = ctx.getImageData(x * SCALE + 1, y * SCALE + 1, 1, 1).data;
      const hex = '#' + [p[0], p[1], p[2]].map(n => n.toString(16).padStart(2, '0')).join('');
      currentColor = hex;
      document.getElementById('tool-pen').click();
    }
  }

  drawCanvas.onmousedown = (e) => { isDrawing = true; paint(e); };
  drawCanvas.onmousemove = paint;
  window.onmouseup = () => { isDrawing = false; };

  function setTool(t) {
    tool = t;
    document.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tool-' + t).classList.add('active');
  }
  document.getElementById('tool-pen').onclick = () => setTool('pen');
  document.getElementById('tool-eraser').onclick = () => setTool('eraser');
  document.getElementById('tool-picker').onclick = () => setTool('picker');

  document.getElementById('btn-copy').onclick = () => {
    if (!currentTexName) return;
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    c.getContext('2d').drawImage(drawCanvas, 0, 0, 512, 512, 0, 0, SIZE, SIZE);
    clipboard = c.getContext('2d').getImageData(0, 0, SIZE, SIZE);
    alert('已复制当前面！');
  };

  document.getElementById('btn-paste').onclick = () => {
    if (!currentTexName || !clipboard) return;
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    c.getContext('2d').putImageData(clipboard, 0, 0);
  
    ctx.clearRect(0, 0, 512, 512);
    ctx.drawImage(c, 0, 0, SIZE, SIZE, 0, 0, 512, 512);
    drawGrid();
  };

  document.getElementById('btn-save').onclick = async () => {
    if (!currentTexName) return;
  
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    const cx = c.getContext('2d');
    cx.drawImage(drawCanvas, 0, 0, 512, 512, 0, 0, SIZE, SIZE);
  
    const imgData = cx.getImageData(0, 0, SIZE, SIZE);
    for (let i = 3; i < imgData.data.length; i += 4) {
      if (imgData.data[i] === 0) imgData.data[i] = 1;
    }
    cx.putImageData(imgData, 0, 0);
  
    const base64 = c.toDataURL('image/png');
  
    const btn = document.getElementById('btn-save');
    btn.textContent = '保存中...';
  
    try {
      const res = await fetch('/api/textures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [currentTexName]: base64 })
      });
      if (res.ok) {
        alert('✔ 保存成功！刷新游戏即可看到新材质。');
        renderList(document.getElementById('search').value);
      } else {
        alert('保存失败');
      }
    } catch(e) {
      alert('网络错误');
    } finally {
      btn.textContent = '💾 保存';
    }
  };

  renderList();
}


/* =================================================================
   style.js
   ================================================================= */
/* ============================================================
   mod-panel/style.js —— MOD 面板所有样式
   ------------------------------------------------------------
   为什么不用 .css 文件：
     浏览器原生 ESM 不支持 `import './xxx.css'`。
     只能用字符串 + 运行时注入 <style>。
   ============================================================ */

const CSS = `

/* ============================================================
   ① 通用容器
   ============================================================ */

#modPanel {
  position: fixed; inset: 0; z-index: 9999;
  display: none;
  background: rgba(0, 0, 0, 0.78);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px;
  box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#modPanel.show { display: flex; align-items: center; justify-content: center; }

#modDetail {
  position: fixed; inset: 0; z-index: 10000;
  display: none; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.82);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px; box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#modDetail.show { display: flex; }

.mp-window {
  width: min(96vw, 960px);
  height: min(90vh, 720px);
  background: rgba(14, 18, 26, 0.96);
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.6);
}

.mp-head {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 18px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  flex-shrink: 0;
}
.mp-head h2 {
  font-size: 16px; font-weight: 600; margin: 0;
  color: #fff;
}
.mp-head .mp-sub {
  font-size: 12px; color: #8fa3b8; margin-left: 4px;
}
.mp-head .mp-spacer { flex: 1; }
.mp-head .mp-close {
  width: 32px; height: 32px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 8px;
  color: #cdd; font-size: 16px;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.mp-head .mp-close:hover { background: rgba(255, 90, 90, 0.25); }

.mp-body {
  flex: 1;
  overflow-y: auto;
  padding: 14px;
}

.mp-foot {
  display: flex; justify-content: flex-end; gap: 8px;
  padding: 12px 18px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  flex-shrink: 0;
}
.mp-foot .mp-btn {
  padding: 8px 20px;
  font-size: 13px;
}
.mp-foot .mp-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* ============================================================
   ② 列表项 / 按钮 / 标签
   ============================================================ */

.mp-item {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 12px 14px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 10px;
  margin-bottom: 8px;
  transition: background .15s, border-color .15s;
}
.mp-item:hover {
  background: rgba(90, 140, 220, 0.12);
  border-color: rgba(120, 180, 255, 0.3);
}

.mp-icon {
  width: 52px; height: 52px; flex-shrink: 0;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 26px;
  overflow: hidden;
}
.mp-icon img { width: 100%; height: 100%; object-fit: cover; }

.mp-main { flex: 1; min-width: 0; }
.mp-title-row {
  display: flex; align-items: baseline; gap: 8px;
  flex-wrap: wrap; margin-bottom: 3px;
}
.mp-name { font-size: 14px; font-weight: 600; color: #fff; }
.mp-version { font-size: 11px; color: #8fa3b8; }
.mp-author { font-size: 11px; color: #8fa3b8; }
.mp-desc {
  font-size: 12px; color: #b8c8d8; line-height: 1.5;
  margin-bottom: 6px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.mp-tags { display: flex; flex-wrap: wrap; gap: 4px; }
.mp-tag {
  font-size: 10px;
  padding: 2px 7px;
  background: rgba(120, 180, 255, 0.15);
  color: #9ec8ff;
  border-radius: 4px;
  border: 1px solid rgba(120, 180, 255, 0.25);
}
.mp-tag.warn {
  background: rgba(255, 180, 60, 0.15);
  color: #ffc94a;
  border-color: rgba(255, 180, 60, 0.3);
}
.mp-tag.bad {
  background: rgba(255, 90, 90, 0.15);
  color: #ff9090;
  border-color: rgba(255, 90, 90, 0.3);
}

.mp-actions {
  display: flex; flex-direction: column; gap: 6px;
  flex-shrink: 0;
}
.mp-btn {
  padding: 6px 14px;
  background: rgba(90, 140, 220, 0.35);
  border: 1px solid rgba(120, 170, 240, 0.5);
  border-radius: 7px;
  color: #e8ecf2;
  font-size: 12px;
  cursor: pointer;
  font-family: inherit;
  white-space: nowrap;
  transition: background .15s;
}
.mp-btn:hover { background: rgba(90, 140, 220, 0.6); }
.mp-btn.ghost {
  background: transparent;
  border-color: rgba(255, 255, 255, 0.15);
  color: #b8c8d8;
}
.mp-btn.ghost:hover { background: rgba(255, 255, 255, 0.08); }

.mp-empty {
  text-align: center;
  color: #5a6d80;
  font-size: 13px;
  padding: 60px 20px;
  line-height: 1.8;
}

.mp-loading {
  padding: 60px 20px;
  text-align: center;
  color: #8fa3b8;
  font-size: 13px;
}

/* ============================================================
   ③ 详情页
   ============================================================ */

.mp-detail { padding: 4px; }
.mp-detail-header {
  display: flex; gap: 16px; align-items: flex-start;
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.mp-detail-icon {
  width: 96px; height: 96px; flex-shrink: 0;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  font-size: 48px;
  overflow: hidden;
}
.mp-detail-icon img { width: 100%; height: 100%; object-fit: cover; }
.mp-detail-meta { flex: 1; min-width: 0; }
.mp-detail-meta h3 {
  font-size: 20px; font-weight: 700; margin: 0 0 6px;
  color: #fff;
}
.mp-detail-meta .mp-meta-line {
  font-size: 12px; color: #8fa3b8;
  line-height: 1.6;
}

.mp-section { margin-bottom: 20px; }
.mp-section h4 {
  font-size: 13px; font-weight: 600;
  color: #7bd0ff;
  margin: 0 0 8px;
  padding-left: 8px;
  border-left: 3px solid #7bd0ff;
}
.mp-section p {
  font-size: 13px; line-height: 1.7;
  color: #c8d4e0;
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
}

.mp-contents {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 8px;
}
.mp-contents-item {
  padding: 10px 12px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 8px;
}
.mp-contents-item .mp-cnt-label {
  font-size: 11px; color: #8fa3b8; margin-bottom: 2px;
}
.mp-contents-item .mp-cnt-value {
  font-size: 18px; font-weight: 700; color: #7bd0ff;
  font-variant-numeric: tabular-nums;
}

.mp-shortcuts {
  display: flex; flex-direction: column; gap: 4px;
}
.mp-shortcut-row {
  display: flex; align-items: center; gap: 10px;
  padding: 6px 10px;
  background: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  font-size: 12px;
}
.mp-shortcut-key {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 28px; padding: 3px 8px;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 5px;
  color: #fff;
  font-family: "SF Mono", Consolas, monospace;
  font-weight: 600;
  font-size: 11px;
}
.mp-shortcut-action { color: #c8d4e0; }

.mp-kv {
  display: grid;
  grid-template-columns: max-content 1fr;
  gap: 4px 14px;
  font-size: 12px;
}
.mp-kv dt { color: #8fa3b8; }
.mp-kv dd { color: #c8d4e0; margin: 0; word-break: break-all; }

/* ============================================================
   ④ mod 选择器（世界设置 / 创建对话框共用）
   ============================================================ */

.mp-select-list {
  display: flex; flex-direction: column; gap: 6px;
  max-height: 320px;
  overflow-y: auto;
  padding-right: 4px;
}
.mp-select-empty {
  padding: 30px 20px; text-align: center;
  color: #5a6d80; font-size: 13px;
}
.mp-select-row {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 12px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 8px;
  transition: background .15s;
}
.mp-select-row:hover {
  background: rgba(90, 140, 220, 0.1);
  border-color: rgba(120, 180, 255, 0.25);
}
.mp-select-cb {
  width: 18px; height: 18px; flex-shrink: 0;
  cursor: pointer;
  accent-color: #5a8cdc;
}
.mp-select-icon {
  width: 36px; height: 36px; flex-shrink: 0;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 18px;
  overflow: hidden;
}
.mp-select-icon img { width: 100%; height: 100%; object-fit: cover; }
.mp-select-main { flex: 1; min-width: 0; }
.mp-select-name-row {
  display: flex; align-items: baseline; gap: 6px;
  flex-wrap: wrap;
  margin-bottom: 2px;
}
.mp-select-name { font-size: 13px; font-weight: 600; color: #fff; }
.mp-select-version { font-size: 10px; color: #8fa3b8; }
.mp-select-desc {
  font-size: 11px; color: #8fa3b8; line-height: 1.4;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
}
.mp-select-tags {
  display: flex; flex-wrap: wrap; gap: 3px;
  margin-top: 4px;
}
.mp-select-tag {
  font-size: 9px;
  padding: 1px 5px;
  background: rgba(120, 180, 255, 0.12);
  color: #9ec8ff;
  border-radius: 3px;
}
.mp-select-detail {
  font-size: 11px;
  padding: 4px 10px;
  flex-shrink: 0;
}
.mp-select-footer {
  display: flex; align-items: center; gap: 8px;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
}
.mp-select-footer .mp-btn {
  font-size: 11px;
  padding: 4px 12px;
}
.mp-select-count {
  margin-left: auto;
  font-size: 11px;
  color: #8fa3b8;
  font-variant-numeric: tabular-nums;
}

/* ============================================================
   ⑤ 世界设置
   ============================================================ */

#worldConfig {
  position: fixed; inset: 0; z-index: 10000;
  display: none; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.82);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px; box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#worldConfig.show { display: flex; }

.wc-section {
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}
.wc-section:last-of-type { border-bottom: none; }
.wc-section h4 {
  font-size: 13px; font-weight: 600;
  color: #7bd0ff;
  margin: 0 0 12px;
  padding-left: 8px;
  border-left: 3px solid #7bd0ff;
}
.wc-field {
  display: block;
  margin-bottom: 12px;
}
.wc-field > span {
  display: block;
  font-size: 11px;
  color: #8fa3b8;
  margin-bottom: 4px;
}
.wc-field input {
  width: 100%;
  padding: 8px 12px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: #e8ecf2;
  font-size: 13px;
  outline: none;
  font-family: inherit;
  box-sizing: border-box;
}
.wc-field input:focus {
  border-color: #4a8be5;
  background: rgba(74, 139, 229, 0.1);
}
.wc-notice {
  padding: 10px 14px;
  background: rgba(255, 180, 60, 0.08);
  border: 1px solid rgba(255, 180, 60, 0.25);
  border-radius: 8px;
  font-size: 12px;
  color: #ffc94a;
  line-height: 1.5;
}

/* ============================================================
   ⑥ mod 选择弹窗（创建世界用）
   ============================================================ */

#modSelectDialog {
  position: fixed; inset: 0; z-index: 10001;
  display: none; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.82);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px; box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#modSelectDialog.show { display: flex; }

/* 创建对话框里的"选择 Mod"按钮行 */
#createDialogModsRow {
  display: flex; align-items: center; gap: 10px;
}
#createDialogModsBtn {
  flex: 1;
  padding: 10px 14px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 9px;
  color: #e8ecf2;
  font-size: 13px;
  font-family: inherit;
  cursor: pointer;
  text-align: left;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: background .15s, border-color .15s;
}
#createDialogModsBtn:hover {
  background: rgba(90, 140, 220, 0.2);
  border-color: rgba(120, 170, 240, 0.5);
}
#createDialogModsBtn .cbtn-count {
  color: #8fa3b8;
  font-size: 12px;
}
#createDialogModsBtn.has-selection .cbtn-count {
  color: #7bd0ff;
  font-weight: 600;
}

/* ============================================================
   ⑦ 游戏内 mod 状态面板
   ============================================================ */

#modStatus {
  position: fixed; inset: 0; z-index: 10002;
  display: none; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.82);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px; box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#modStatus.show { display: flex; }

.ms-row {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 12px 14px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 10px;
  margin-bottom: 8px;
}
.ms-row-ok {
  border-color: rgba(120, 220, 140, 0.18);
}
.ms-row-fail {
  background: rgba(255, 90, 90, 0.06);
  border-color: rgba(255, 90, 90, 0.35);
}

.ms-icon {
  width: 44px; height: 44px; flex-shrink: 0;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 9px;
  display: flex; align-items: center; justify-content: center;
  font-size: 22px;
  overflow: hidden;
}
.ms-icon img { width: 100%; height: 100%; object-fit: cover; }

.ms-main { flex: 1; min-width: 0; }
.ms-name-row {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 2px;
  flex-wrap: wrap;
}
.ms-status-icon {
  display: inline-flex;
  align-items: center; justify-content: center;
  width: 16px; height: 16px;
  border-radius: 50%;
  font-size: 11px;
  font-weight: 700;
  flex-shrink: 0;
}
.ms-status-icon.ok {
  background: rgba(80, 200, 100, 0.25);
  color: #9effb0;
  border: 1px solid rgba(120, 220, 140, 0.5);
}
.ms-status-icon.fail {
  background: rgba(255, 90, 90, 0.25);
  color: #ffb0b0;
  border: 1px solid rgba(255, 120, 120, 0.5);
}
.ms-name {
  font-size: 13px; font-weight: 600; color: #fff;
}
.ms-version {
  font-size: 11px; color: #8fa3b8;
}
.ms-desc {
  font-size: 11px; color: #8fa3b8;
  line-height: 1.5;
  margin-top: 4px;
}
.ms-error {
  font-size: 11px;
  color: #ff9090;
  line-height: 1.5;
  margin-top: 4px;
  word-break: break-word;
}

.ms-notice {
  margin-top: 12px;
  padding: 10px 14px;
  background: rgba(255, 180, 60, 0.08);
  border: 1px solid rgba(255, 180, 60, 0.25);
  border-radius: 8px;
  font-size: 12px;
  color: #ffc94a;
  line-height: 1.6;
}

/* 暂停菜单按钮上的失败红点 */
.mb-sub { position: relative; }
.mb-sub .ms-badge-dot {
  position: absolute;
  top: 6px; right: 6px;
  width: 8px; height: 8px;
  border-radius: 50%;
  background: #ff4a4a;
  box-shadow: 0 0 6px rgba(255, 74, 74, 0.8);
}

/* ============================================================
   ⑧ 手机适配
   ============================================================ */

@media (max-width: 640px){
  .mp-window { height: min(92vh, 100%); }
  .mp-icon { width: 44px; height: 44px; font-size: 22px; }
  .mp-detail-icon { width: 72px; height: 72px; font-size: 36px; }
  .mp-actions { flex-direction: row; }
  .mp-btn { padding: 6px 10px; font-size: 11px; }
  .mp-select-list { max-height: 240px; }
}

/* ============================================================
   M5 第四批：缺 mod 警告弹窗
   ============================================================ */
#modWarning {
  position: fixed; inset: 0; z-index: 10003;
  display: none; align-items: center; justify-content: center;
  background: rgba(0, 0, 0, 0.85);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 16px; box-sizing: border-box;
  color: #e8ecf2;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
}
#modWarning.show { display: flex; }


/* ============================================================
   ★ mod 仓库：搜索 + 分类 + 排序
   ============================================================ */
.mp-toolbar {
  display: flex;
  gap: 8px;
  margin-bottom: 10px;
}
.mp-search {
  flex: 1;
  padding: 8px 12px;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 8px;
  color: #e8ecf2;
  font-size: 13px;
  font-family: inherit;
  outline: none;
  transition: border-color .12s, background .12s;
}
.mp-search:focus {
  border-color: #4a8be5;
  background: rgba(74,139,229,.08);
}
.mp-sort {
  padding: 8px 10px;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 8px;
  color: #e8ecf2;
  font-size: 12px;
  font-family: inherit;
  cursor: pointer;
  outline: none;
}
.mp-sort:hover { background: rgba(255,255,255,.1); }

.mp-cats {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}
.mp-cat {
  padding: 5px 10px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 14px;
  color: #b8c8d8;
  font-size: 11px;
  cursor: pointer;
  font-family: inherit;
  transition: background .12s, border-color .12s, color .12s;
}
.mp-cat:hover {
  background: rgba(90,140,220,.15);
  border-color: rgba(120,170,240,.3);
}
.mp-cat.active {
  background: rgba(90,140,220,.35);
  border-color: rgba(120,170,240,.55);
  color: #fff;
  font-weight: 600;
}

@media (max-width: 640px) {
  .mp-toolbar { flex-direction: column; }
  .mp-sort { width: 100%; }
}
`;

let _installed = false;

function installModPanelStyle(){
  if (_installed) return;
  _installed = true;
  const styleEl = document.createElement('style');
  styleEl.id = '__mod_panel_style__';
  styleEl.textContent = CSS;
  document.head.appendChild(styleEl);
}

/* =================================================================
   re-export
   ================================================================= */
export {
  renderPreview,
  isFullscreen,
  requestFullscreen,
  exitFullscreen,
  toggleFullscreen,
  onFullscreenChange,
  importMapFile,
  exportMap,
  importModpackFile,
  exportModpack,
  installModPanelStyle
};
