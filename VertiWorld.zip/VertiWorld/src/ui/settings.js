/* ============================================================
   settings.js —— 所有设置项 + UI 绑定
   ------------------------------------------------------------
   · 从 localStorage 读取并应用所有配置
   · 实时监听 UI 变化
   · ★ 已移除自研引擎相关代码，完全回退 Three.js
   ============================================================ */

import { IS_TOUCH, setTouchMode, getTouchMode } from './../core/engine-core.js';
import { getDeviceProfile } from './../core/runtime.js';
import {
  applyControlPreset, getControlPreset, openControlEditor, openKeyPicker,
} from './touch-controls.js';
import {
  getAllActions, getBinding, setBinding, resetBindings, keyLabel,
  conflictsForCode,
} from '../core/key-bindings.js';

import { player, setTouchAimMode, getTouchAimMode } from './../player/player-core.js';
import { updateHearts, toast, closeInv, closeChest, closeFurnace } from './ui.js';
import { emit } from './../core/engine-core.js';
import { setLogSaveId, uploadLog } from './../core/runtime.js';

import { setShadowQuality, setCloudQuality, setLightMultiplier, setCloudThickness,
  setFogScale, setFogDepth }
  from '../render/sky.js';
import { setLeafAlpha } from './../render/render-core.js';
import { applyRenderSize } from './../render/render-core.js';
import {
  setCrossCullEnabled, setCrossCullDistance, rebuildAllChunks,
} from '../world/chunk.js';
import {
  setDiskCacheEnabled, setWriteQueueMax, setMaxConcurrentWrite,
} from './../world/world-core.js';
import { setMaxPendingLoads } from '../world/terrain.js';
import { setFallingLeavesEnabled, clearLeaves } from './../world/world-registry.js';
import { setSimDistance, setEntityCapScale } from './../entities/entities-core.js';

import { setLookSensitivity } from './../player/player-core.js';
import {
  initAudio, startMusic, stopMusic, setMusicEnabled, setSfxEnabled,
  setMusicVolume, setSfxVolume,
} from '../audio/audio.js';
import { isCaveAmbienceEnabled, setCaveAmbienceEnabled } from '../audio/ambience.js';

import {
  persistCurrentWorld, savePlayerOnly, getCurrentSave,
} from './../save/save-core.js';
import { unloadAllMods } from './../save/save-core.js';
import { setupCommandSettings } from './commands.js';

/* ============================================================
   设置项
   ============================================================ */
const DIST_KEY         = '3dmc_render_dist';
const SIM_DIST_KEY     = '3dmc_sim_dist';
const SHADOW_DIST_KEY  = '3dmc_shadow_dist';
const SHADOW_KEY       = '3dmc_shadow_quality';
const LEAF_ALPHA_KEY   = '3dmc_leaf_alpha';
const FALLING_LEAF_KEY = '3dmc_falling_leaves';
const CLOUD_KEY        = '3dmc_cloud_quality';
const MUSIC_KEY        = '3dmc_music_on';
const SFX_KEY          = '3dmc_sfx_on';
const MESH_WORKER_KEY  = '3dmc_mesh_worker';

/* 音量读取：兼容旧版 'on'/'off' 存档和新的 0~1 数值 */
function _volFrom(key, def){
  const raw = localStorage.getItem(key);
  if (raw === null) return def;
  if (raw === 'on')  return 1;
  if (raw === 'off') return 0;
  const n = parseFloat(raw);
  return isFinite(n) ? Math.max(0, Math.min(1, n)) : def;
}

/* ---- 默认值 ---- */
let _renderDist = parseInt(
  localStorage.getItem(DIST_KEY) || (IS_TOUCH ? 5 : 8), 10);
if (!isFinite(_renderDist)) _renderDist = IS_TOUCH ? 5 : 8;
_renderDist = Math.max(2, Math.min(32, _renderDist));

let _simDist = parseInt(
  localStorage.getItem(SIM_DIST_KEY) || String(_renderDist), 10);
if (!isFinite(_simDist)) _simDist = _renderDist;
_simDist = Math.max(2, Math.min(32, _simDist));

let _shadowDist = parseInt(
  localStorage.getItem(SHADOW_DIST_KEY) || (IS_TOUCH ? 3 : 4), 10);
if (!isFinite(_shadowDist)) _shadowDist = IS_TOUCH ? 3 : 4;
_shadowDist = Math.max(2, Math.min(16, _shadowDist));

let _shadowQuality = localStorage.getItem(SHADOW_KEY) || (IS_TOUCH ? 'low' : 'high');
if (!['off', 'low', 'high'].includes(_shadowQuality))
  _shadowQuality = IS_TOUCH ? 'low' : 'high';

let _leafAlphaSetting   = localStorage.getItem(LEAF_ALPHA_KEY) || 'on';
let _fallingLeafSetting = localStorage.getItem(FALLING_LEAF_KEY) || 'on';

let _cloudSetting = localStorage.getItem(CLOUD_KEY) || (IS_TOUCH ? 'low' : 'high');
if (!['off', 'low', 'high', 'ultra'].includes(_cloudSetting))
  _cloudSetting = 'high';

let _musicSetting = _volFrom(MUSIC_KEY, 1) > 0.001 ? 'on' : 'off';
let _sfxSetting   = _volFrom(SFX_KEY,   1) > 0.001 ? 'on' : 'off';

let _meshWorkerSetting = localStorage.getItem(MESH_WORKER_KEY) || 'auto';
if (!['auto', 'on', 'off'].includes(_meshWorkerSetting))
  _meshWorkerSetting = 'auto';

/* ---- Getter ---- */
export function getRenderDist(){ return _renderDist; }
export function getSimDist(){ return _simDist; }
export function getShadowDist(){ return _shadowDist; }
export function getShadowQuality(){ return _shadowQuality; }
export function getMusicSetting(){ return _musicSetting; }
export function getSfxSetting(){ return _sfxSetting; }
export function getLeafAlphaSetting(){ return _leafAlphaSetting; }
export function getFallingLeafSetting(){ return _fallingLeafSetting; }
export function getMeshWorkerSetting(){ return _meshWorkerSetting; }

/* ============================================================
   网格构建模式
   ============================================================ */
function resolveMeshWorkerEnabled(mode){
  if (mode === 'on')  return true;
  if (mode === 'off') return false;
  return getDeviceProfile().meshWorker;    /* auto */
}

function applyMeshWorkerSetting(updateUI){
  const enabled = resolveMeshWorkerEnabled(_meshWorkerSetting);

  /* 通知 chunk.js 切换（不重建当前帧，只标脏） */
  if (typeof window !== 'undefined' && typeof window.__setMeshWorkerEnabled === 'function'){
    window.__setMeshWorkerEnabled(enabled);
  }

  if (updateUI === false) return;

  /* 更新提示文字 */
  const tip = document.getElementById('meshWorkerTip');
  if (tip){
    const p = getDeviceProfile();
    const shortGpu = String(p.gpu || '未知').slice(0, 52);
    if (_meshWorkerSetting === 'auto'){
      tip.textContent =
        `自动检测：${shortGpu} → ` +
        (enabled ? 'Worker 模式（加载快）' : '主线程模式（更稳）');
    } else if (_meshWorkerSetting === 'on'){
      tip.textContent = 'Worker 模式：加载快，但低端 GPU 可能掉帧';
    } else {
      tip.textContent = '主线程模式：加载慢一点，但更稳';
    }
  }

  /* 更新按钮高亮 */
  document.querySelectorAll('#setMeshWorker button').forEach(b => {
    b.classList.toggle('active', b.dataset.val === _meshWorkerSetting);
  });
}

/* ============================================================
   初始化
   ============================================================ */
export function initSettings({ onLeaveWorld }){
  const settingsEl = document.getElementById('settings');

  /* ---- 首帧应用 ---- */
  setShadowQuality(_shadowQuality, Math.min(_shadowDist, _renderDist));
  window.__shadowSize = (_shadowQuality === 'off') ? 0
    : (_shadowQuality === 'low' ? 512 : 2048);
  setLeafAlpha(_leafAlphaSetting === 'on');
  setFallingLeavesEnabled(_fallingLeafSetting === 'on');
  setCloudQuality(_cloudSetting);
  setSimDistance(Math.min(_simDist, _renderDist));

  /* ---- 触屏瞄准方式：准星（默认，基岩版）/ 触点 ---- */
  const TOUCH_AIM_KEY = '3dmc_touch_aim';
  setTouchAimMode(localStorage.getItem(TOUCH_AIM_KEY) || 'crosshair');

  function refresh(){
    const curTouch = getTouchMode();
    document.querySelectorAll('#setTouch button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === curTouch));
    document.querySelectorAll('#setControlPreset button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === getControlPreset()));
    document.querySelectorAll('#setTouchAim button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === getTouchAimMode()));
    document.querySelectorAll('#setShadow button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === _shadowQuality));
    document.querySelectorAll('#setLeafAlpha button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === _leafAlphaSetting));
    document.querySelectorAll('#setFallingLeaves button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === _fallingLeafSetting));
    document.querySelectorAll('#setMode button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === player.mode));
    document.querySelectorAll('#setCloud button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === _cloudSetting));
    document.querySelectorAll('#setCaveAmb button').forEach(b =>
      b.classList.toggle('active', b.dataset.val === (isCaveAmbienceEnabled() ? 'on' : 'off')));
    /* 云层厚度只在 high / ultra 下有意义 */
    const thickRow = document.getElementById('cloudThicknessRow');
    if (thickRow){
      thickRow.style.display =
        (_cloudSetting === 'high' || _cloudSetting === 'ultra') ? '' : 'none';
    }
  }
  refresh();

  /* ---- 暂停菜单 → 设置 ---- */
  const btnOpenSettings = document.getElementById('btnOpenSettings');
  if (btnOpenSettings){
    btnOpenSettings.addEventListener('click', () => {
      const pauseEl = document.getElementById('pause');
      if (pauseEl) pauseEl.classList.remove('show');
      settingsEl.classList.add('show');
      _switchSettingsTab('perf');
    });
  }

  /* ---- 设置两栏切换 ---- */
  const _settingsSidebar = document.getElementById('settingsSidebar');
  const _settingsTabs = document.querySelectorAll('.settings-tab');

  function _switchSettingsTab(tabId){
    _settingsTabs.forEach(t => {
      t.style.display = (t.id === 'tab-' + tabId) ? '' : 'none';
    });
    document.querySelectorAll('#settingsSidebar .sidebar-item').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabId);
    });
  }

  /* ---- 性能 tab 内部的三级导航 ---- */
  const _perfSubnav = document.getElementById('perfSubnav');
  const _subpages = document.querySelectorAll('.subpage');

  function _switchPerfSub(subId){
    _subpages.forEach(p => {
      p.style.display = (p.id === 'sub-' + subId) ? '' : 'none';
    });
    if (_perfSubnav){
      _perfSubnav.querySelectorAll('button[data-sub]').forEach(b => {
        b.classList.toggle('active', b.dataset.sub === subId);
      });
    }
  }

  if (_perfSubnav){
    _perfSubnav.addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-sub]');
      if (btn) _switchPerfSub(btn.dataset.sub);
    });
  }

  if (_settingsSidebar){
    _settingsSidebar.addEventListener('click', (e) => {
      const item = e.target.closest('.sidebar-item');
      if (item) _switchSettingsTab(item.dataset.tab);
    });
  }

  /* ---- 设置"← 返回"回暂停菜单 ---- */
  const settingsBackBtn = document.getElementById('settingsBack');
  if (settingsBackBtn){
    settingsBackBtn.addEventListener('click', () => {
      settingsEl.classList.remove('show');
      const pauseEl = document.getElementById('pause');
      if (pauseEl) pauseEl.classList.add('show');
    });
  }

  /* ---- Mod 状态按钮（一级菜单） ---- */
  const btnModStatus = document.getElementById('btnModStatus');
  if (btnModStatus){
    btnModStatus.addEventListener('click', () => {
      import('./mod-panel/index.js')
        .then(m => m.openModStatus())
        .catch(e => console.error('[settings] 打开 Mod 状态失败:', e));
    });
  }

  /* ---- 全屏按钮（一级菜单） ---- */
  const btnFullscreen3 = document.getElementById('btnFullscreen3');
  if (btnFullscreen3){
    btnFullscreen3.addEventListener('click', () => {
      import('./ui-panel.js')
        .then(m => m.toggleFullscreen())
        .catch(() => {});
    });
  }


  /* ---- 游戏模式 ---- */
  document.querySelectorAll('#setMode button').forEach(b => {
    b.addEventListener('click', async () => {
      const target = b.dataset.val;
      if (target === player.mode) return;
      player.mode = target;
      player.flying = target === 'creative';
      player.health = player.maxHealth;
      player.breath = 1.0;
      updateHearts(player.health, player.maxHealth, player.mode);
      document.querySelectorAll('#setMode button').forEach(x =>
        x.classList.toggle('active', x.dataset.val === target));
      toast(target === 'creative' ? '创造模式' : '生存模式');
      await savePlayerOnly();
      emit('player.modeChange', target);
    });
  });

  /* ---- 触屏模式 ---- */
  document.querySelectorAll('#setTouch button').forEach(b => {
    b.addEventListener('click', () => {
      setTouchMode(b.dataset.val); refresh();
      if (document.pointerLockElement) document.exitPointerLock();
      if (window.__resetGesture) window.__resetGesture();
    });
  });

  /* ---- 触屏瞄准方式 ---- */
  document.querySelectorAll('#setTouchAim button').forEach(b => {
    b.addEventListener('click', () => {
      setTouchAimMode(b.dataset.val);
      localStorage.setItem(TOUCH_AIM_KEY, b.dataset.val);
      refresh();
      if (window.__resetGesture) window.__resetGesture();
      toast('触屏瞄准：' + b.textContent);
    });
  });

  /* ---- 按键布局预设 / 编辑布局 ---- */
  document.querySelectorAll('#setControlPreset button').forEach(b => {
    b.addEventListener('click', () => {
      if (!applyControlPreset(b.dataset.val)) return;
      refresh();
      toast('按键布局：' + b.textContent);
    });
  });
  const editControlsBtn = document.getElementById('btnEditControls');
  if (editControlsBtn){
    editControlsBtn.addEventListener('click', () => {
      if (!openControlEditor()){
        toast('请先进入世界再编辑按键布局');
        return;
      }
      settingsEl.classList.remove('show');
      const pauseEl = document.getElementById('pause');
      if (pauseEl) pauseEl.classList.remove('show');
    });
  }

  /* ---- 按键绑定（类似 MC，可自由改动作的键；mod 动作也会出现在这里） ---- */
  function renderBindList(){
    const list = document.getElementById('bindList');
    if (!list) return;
    list.innerHTML = '';
    for (const a of getAllActions()){
      const row = document.createElement('div');
      row.className = 'bind-row';

      const name = document.createElement('span');
      name.className = 'bind-name';
      name.textContent = a.label;

      if (a.mod){
        const badge = document.createElement('span');
        badge.className = 'bind-badge';
        badge.textContent = '模组';
        name.appendChild(badge);
      }

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'bind-key';
      const code = getBinding(a.id);
      btn.textContent = code ? keyLabel(code) : '未绑定';
      btn.classList.toggle('unbound', !code);
      btn.addEventListener('click', () => {
        openKeyPicker({
          title: '按键绑定 · ' + a.label,
          value: getBinding(a.id),
          actionId: a.id,
          onConfirm: (v) => {
            setBinding(a.id, v);
            renderBindList();
          },
        });
      });

      row.appendChild(name);
      row.appendChild(btn);

      const conflicts = conflictsForCode(code, a.id);
      row.classList.toggle('conflict', conflicts.length > 0);
      if (conflicts.length){
        const warn = document.createElement('span');
        warn.className = 'bind-warn';
        warn.textContent = '冲突：' + conflicts.map(c => c.label).join('、');
        row.appendChild(warn);
      }

      list.appendChild(row);
    }
  }
  renderBindList();
  window.addEventListener('3dmc:keybindings', renderBindList);

  const resetBindsBtn = document.getElementById('btnResetBinds');
  if (resetBindsBtn){
    resetBindsBtn.addEventListener('click', () => {
      resetBindings();
      renderBindList();
      toast('按键绑定已恢复默认');
    });
  }

  /* ---- 距离滑条：渲染 / 模拟 / 阴影 ---- */
  const distSlider       = document.getElementById('setDist');
  const distValEl        = document.getElementById('setDistVal');
  const simDistSlider    = document.getElementById('setSimDist');
  const simDistValEl     = document.getElementById('setSimDistVal');
  const shadowDistSlider = document.getElementById('setShadowDist');
  const shadowDistValEl  = document.getElementById('setShadowDistVal');

  if (distSlider){
    distSlider.value = String(_renderDist);
    if (distValEl) distValEl.textContent = _renderDist + ' 区块';
    distSlider.addEventListener('input', () => {
      if (distValEl) distValEl.textContent = distSlider.value + ' 区块';
    });
    distSlider.addEventListener('change', () => {
      _renderDist = parseInt(distSlider.value, 10);
      localStorage.setItem(DIST_KEY, String(_renderDist));
      setSimDistance(Math.min(_simDist, _renderDist));
      setShadowQuality(_shadowQuality, Math.min(_shadowDist, _renderDist));
    });
  }
  if (simDistSlider){
    simDistSlider.value = String(_simDist);
    if (simDistValEl) simDistValEl.textContent = _simDist + ' 区块';
    simDistSlider.addEventListener('input', () => {
      if (simDistValEl) simDistValEl.textContent = simDistSlider.value + ' 区块';
    });
    simDistSlider.addEventListener('change', () => {
      _simDist = parseInt(simDistSlider.value, 10);
      localStorage.setItem(SIM_DIST_KEY, String(_simDist));
      setSimDistance(Math.min(_simDist, _renderDist));
    });
  }
  if (shadowDistSlider){
    shadowDistSlider.value = String(_shadowDist);
    if (shadowDistValEl) shadowDistValEl.textContent = _shadowDist + ' 区块';
    shadowDistSlider.addEventListener('input', () => {
      if (shadowDistValEl) shadowDistValEl.textContent = shadowDistSlider.value + ' 区块';
    });
    shadowDistSlider.addEventListener('change', () => {
      _shadowDist = parseInt(shadowDistSlider.value, 10);
      localStorage.setItem(SHADOW_DIST_KEY, String(_shadowDist));
      setShadowQuality(_shadowQuality, Math.min(_shadowDist, _renderDist));
    });
  }

  /* ---- 网格构建模式 ---- */
  document.querySelectorAll('#setMeshWorker button').forEach(b => {
    b.addEventListener('click', () => {
      _meshWorkerSetting = b.dataset.val;
      localStorage.setItem(MESH_WORKER_KEY, _meshWorkerSetting);
      applyMeshWorkerSetting(true);

      if (_meshWorkerSetting === 'on'){
        toast('Worker 模式：现有区块会重建');
      } else if (_meshWorkerSetting === 'off'){
        toast('主线程模式：现有区块会重建');
      } else {
        toast('自动模式：按设备选择');
      }
    });
  });
  applyMeshWorkerSetting(true);

  /* ---- 阴影质量 ---- */
  document.querySelectorAll('#setShadow button').forEach(b => {
    b.addEventListener('click', () => {
      _shadowQuality = b.dataset.val;
      localStorage.setItem(SHADOW_KEY, _shadowQuality);
      setShadowQuality(_shadowQuality, Math.min(_shadowDist, _renderDist));
      window.__shadowSize = (_shadowQuality === 'off') ? 0
        : (_shadowQuality === 'low' ? 512 : 2048);
      refresh();
    });
  });

  /* ---- 透光树叶 ---- */
  document.querySelectorAll('#setLeafAlpha button').forEach(b => {
    b.addEventListener('click', () => {
      _leafAlphaSetting = b.dataset.val;
      localStorage.setItem(LEAF_ALPHA_KEY, _leafAlphaSetting);
      
      // 1. 切换材质
      setLeafAlpha(_leafAlphaSetting === 'on');
      // 2. 强制重建所有区块（让 Worker 重新计算几何体）
      rebuildAllChunks(); 
      
      refresh();
    });
  });

  /* ---- 落叶飘落 ---- */
  document.querySelectorAll('#setFallingLeaves button').forEach(b => {
    b.addEventListener('click', () => {
      _fallingLeafSetting = b.dataset.val;
      localStorage.setItem(FALLING_LEAF_KEY, _fallingLeafSetting);
      setFallingLeavesEnabled(_fallingLeafSetting === 'on');
      if (_fallingLeafSetting === 'off') clearLeaves();
      refresh();
    });
  });

  /* ---- 云 ---- */
  document.querySelectorAll('#setCloud button').forEach(b => {
    b.addEventListener('click', () => {
      _cloudSetting = b.dataset.val;
      localStorage.setItem(CLOUD_KEY, _cloudSetting);
      setCloudQuality(_cloudSetting); refresh();
    });
  });

  /* ---- 背景音乐音量 ---- */
  const musicInput = document.getElementById('setMusic');
  const musicValEl = document.getElementById('setMusicVal');
  if (musicInput){
    musicInput.value = String(Math.round(_volFrom(MUSIC_KEY, 1) * 100));
    if (musicValEl) musicValEl.textContent = musicInput.value + '%';
    const applyMusic = (startNow) => {
      const v = parseInt(musicInput.value, 10) / 100;
      const on = v > 0.001;
      _musicSetting = on ? 'on' : 'off';
      localStorage.setItem(MUSIC_KEY, String(v));
      initAudio(); setMusicVolume(v); setMusicEnabled(on);
      if (!on) stopMusic();
      else if (startNow) startMusic();
    };
    musicInput.addEventListener('input', () => {
      if (musicValEl) musicValEl.textContent = musicInput.value + '%';
    });
    musicInput.addEventListener('change', () => applyMusic(true));
    applyMusic(false);
  }

  /* ---- 音效音量 ---- */
  const sfxInput = document.getElementById('setSfx');
  const sfxValEl = document.getElementById('setSfxVal');
  if (sfxInput){
    sfxInput.value = String(Math.round(_volFrom(SFX_KEY, 1) * 100));
    if (sfxValEl) sfxValEl.textContent = sfxInput.value + '%';
    const applySfx = () => {
      const v = parseInt(sfxInput.value, 10) / 100;
      _sfxSetting = v > 0.001 ? 'on' : 'off';
      localStorage.setItem(SFX_KEY, String(v));
      initAudio(); setSfxVolume(v); setSfxEnabled(v > 0.001);
    };
    sfxInput.addEventListener('input', () => {
      if (sfxValEl) sfxValEl.textContent = sfxInput.value + '%';
    });
    sfxInput.addEventListener('change', applySfx);
    applySfx();
  }

  /* ---- 洞穴回音开关 ---- */
  document.querySelectorAll('#setCaveAmb button').forEach(b => {
    b.addEventListener('click', () => {
      setCaveAmbienceEnabled(b.dataset.val !== 'off');
      refresh();
    });
  });

  /* ---- 云层厚度（high / ultra 共用） ---- */
  const CLOUD_THICK_KEY = '3dmc_cloud_thickness';
  const thickInput = document.getElementById('setCloudThickness');
  const thickValEl = document.getElementById('setCloudThicknessVal');
  if (thickInput){
    const saved = parseInt(localStorage.getItem(CLOUD_THICK_KEY) || '26', 10);
    thickInput.value = String(Math.max(6, Math.min(60, isFinite(saved) ? saved : 26)));
    if (thickValEl) thickValEl.textContent = thickInput.value;
    const applyThick = () => {
      const v = parseInt(thickInput.value, 10);
      if (thickValEl) thickValEl.textContent = String(v);
      setCloudThickness(v);
      localStorage.setItem(CLOUD_THICK_KEY, String(v));
    };
    thickInput.addEventListener('input', () => {
      if (thickValEl) thickValEl.textContent = thickInput.value;
    });
    thickInput.addEventListener('change', applyThick);
    applyThick();
  }

  /* ---- 雾距（50~160%） ---- */
  const FOG_SCALE_KEY = '3dmc_fog_scale';
  const fogScaleInput = document.getElementById('setFogScale');
  const fogScaleValEl = document.getElementById('setFogScaleVal');
  if (fogScaleInput){
    const saved = parseInt(localStorage.getItem(FOG_SCALE_KEY) || '100', 10);
    fogScaleInput.value = String(Math.max(50, Math.min(160, isFinite(saved) ? saved : 100)));
    if (fogScaleValEl) fogScaleValEl.textContent = fogScaleInput.value + '%';
    const applyFogScale = () => {
      const v = parseInt(fogScaleInput.value, 10);
      if (fogScaleValEl) fogScaleValEl.textContent = v + '%';
      setFogScale(v / 100);
    };
    fogScaleInput.addEventListener('input', () => {
      if (fogScaleValEl) fogScaleValEl.textContent = fogScaleInput.value + '%';
    });
    fogScaleInput.addEventListener('change', applyFogScale);
    applyFogScale();
  }

  /* ---- 雾色深度（0~100%）：洞穴雾的黑度 ---- */
  const FOG_DEPTH_KEY = '3dmc_fog_depth';
  const fogDepthInput = document.getElementById('setFogDepth');
  const fogDepthValEl = document.getElementById('setFogDepthVal');
  if (fogDepthInput){
    const saved = parseInt(localStorage.getItem(FOG_DEPTH_KEY) || '100', 10);
    fogDepthInput.value = String(Math.max(0, Math.min(100, isFinite(saved) ? saved : 100)));
    if (fogDepthValEl) fogDepthValEl.textContent = fogDepthInput.value + '%';
    const applyFogDepth = () => {
      const v = parseInt(fogDepthInput.value, 10);
      if (fogDepthValEl) fogDepthValEl.textContent = v + '%';
      setFogDepth(v / 100);
    };
    fogDepthInput.addEventListener('input', () => {
      if (fogDepthValEl) fogDepthValEl.textContent = fogDepthInput.value + '%';
    });
    fogDepthInput.addEventListener('change', applyFogDepth);
    applyFogDepth();
  }

  /* ---- 生物数量（0~200%） ---- */
  const MOB_SCALE_KEY = '3dmc_mob_scale';
  const mobInput = document.getElementById('setMobScale');
  const mobValEl = document.getElementById('setMobScaleVal');
  if (mobInput){
    const saved = parseInt(localStorage.getItem(MOB_SCALE_KEY) || '100', 10);
    mobInput.value = String(Math.max(0, Math.min(200, isFinite(saved) ? saved : 100)));
    if (mobValEl) mobValEl.textContent = mobInput.value + '%';
    const applyMobScale = () => {
      const v = parseInt(mobInput.value, 10);
      if (mobValEl) mobValEl.textContent = v + '%';
      setEntityCapScale(v / 100);
      localStorage.setItem(MOB_SCALE_KEY, String(v));
    };
    mobInput.addEventListener('input', () => {
      if (mobValEl) mobValEl.textContent = mobInput.value + '%';
    });
    mobInput.addEventListener('change', applyMobScale);
    applyMobScale();
  }

  /* ---- 花草远距剔除 ---- */
  const CROSS_CULL_KEY    = '3dmc_cross_cull_on';
  const CROSS_CULL_DY_KEY = '3dmc_cross_cull_dy';
  let crossCullOn = (localStorage.getItem(CROSS_CULL_KEY) || 'on') === 'on';
  setCrossCullEnabled(crossCullOn);

  const crossCullBtns = document.querySelectorAll('#setCrossCull button');
  function refreshCrossCull(){
    crossCullBtns.forEach(b =>
      b.classList.toggle('active', (b.dataset.val === 'on') === crossCullOn));
    const row = document.getElementById('crossCullRow');
    if (row) row.style.display = crossCullOn ? '' : 'none';
  }
  refreshCrossCull();
  crossCullBtns.forEach(b => {
    b.addEventListener('click', () => {
      crossCullOn = (b.dataset.val === 'on');
      localStorage.setItem(CROSS_CULL_KEY, crossCullOn ? 'on' : 'off');
      setCrossCullEnabled(crossCullOn);
      refreshCrossCull();
    });
  });

  const crossCullDistInput = document.getElementById('setCrossCullDist');
  const crossCullDistValEl = document.getElementById('setCrossCullDistVal');
  if (crossCullDistInput){
    crossCullDistInput.value =
      String(parseInt(localStorage.getItem(CROSS_CULL_DY_KEY) || '20', 10) || 20);
    if (crossCullDistValEl) crossCullDistValEl.textContent = crossCullDistInput.value;
    function applyCrossCullDist(){
      let v = parseInt(crossCullDistInput.value, 10);
      if (isNaN(v)) v = 20;
      v = Math.max(8, Math.min(128, v));
      crossCullDistInput.value = String(v);
      if (crossCullDistValEl) crossCullDistValEl.textContent = String(v);
      setCrossCullDistance(v);
      localStorage.setItem(CROSS_CULL_DY_KEY, String(v));
    }
    crossCullDistInput.addEventListener('input', () => {
      if (crossCullDistValEl) crossCullDistValEl.textContent = crossCullDistInput.value;
    });
    crossCullDistInput.addEventListener('change', applyCrossCullDist);
    applyCrossCullDist();
  }

  /* ---- 磁盘缓存 ---- */
  const DISK_CACHE_KEY = '3dmc_disk_cache';
  let diskCacheOn = (localStorage.getItem(DISK_CACHE_KEY) || 'on') === 'on';
  setDiskCacheEnabled(diskCacheOn);

  const diskBtns = document.querySelectorAll('#setDiskCache button');
  function refreshDiskBtns(){
    diskBtns.forEach(x =>
      x.classList.toggle('active', (x.dataset.val === 'on') === diskCacheOn));
  }
  refreshDiskBtns();
  diskBtns.forEach(b => {
    b.addEventListener('click', () => {
      diskCacheOn = (b.dataset.val === 'on');
      localStorage.setItem(DISK_CACHE_KEY, diskCacheOn ? 'on' : 'off');
      setDiskCacheEnabled(diskCacheOn);
      refreshDiskBtns();
      toast(diskCacheOn ? '磁盘缓存：开' : '磁盘缓存：关');
    });
  });

  /* ---- 读盘并发 ---- */
  const LOAD_CK = '3dmc_load_concurrency';
  const loadInput = document.getElementById('setLoadConcurrency');
  const loadValEl = document.getElementById('setLoadConcurrencyVal');
  if (loadInput){
    loadInput.value = String(parseInt(localStorage.getItem(LOAD_CK) || '5', 10) || 5);
    if (loadValEl) loadValEl.textContent = loadInput.value;
    function applyLoadConcurrency(){
      let v = parseInt(loadInput.value, 10);
      if (isNaN(v)) v = 5;
      v = Math.max(1, Math.min(16, v));
      loadInput.value = String(v);
      if (loadValEl) loadValEl.textContent = String(v);
      if (typeof setMaxPendingLoads === 'function') setMaxPendingLoads(v);
      localStorage.setItem(LOAD_CK, String(v));
    }
    loadInput.addEventListener('input', () => {
      if (loadValEl) loadValEl.textContent = loadInput.value;
    });
    loadInput.addEventListener('change', applyLoadConcurrency);
    applyLoadConcurrency();
  }

  /* ---- 写盘队列 ---- */
  const WQ_CK = '3dmc_write_queue';
  const wqInput = document.getElementById('setWriteQueue');
  const wqValEl = document.getElementById('setWriteQueueVal');
  if (wqInput){
    wqInput.value = String(parseInt(localStorage.getItem(WQ_CK) || '16', 10) || 16);
    if (wqValEl) wqValEl.textContent = wqInput.value;
    function applyWriteQueue(){
      let v = parseInt(wqInput.value, 10);
      if (isNaN(v)) v = 16;
      v = Math.max(2, Math.min(64, v));
      wqInput.value = String(v);
      if (wqValEl) wqValEl.textContent = String(v);
      if (typeof setWriteQueueMax === 'function') setWriteQueueMax(v);
      localStorage.setItem(WQ_CK, String(v));
    }
    wqInput.addEventListener('input', () => {
      if (wqValEl) wqValEl.textContent = wqInput.value;
    });
    wqInput.addEventListener('change', applyWriteQueue);
    applyWriteQueue();
  }

  /* ---- 写盘并发 ---- */
  const WC_CK = '3dmc_write_concurrency';
  const wcInput = document.getElementById('setWriteConcurrency');
  const wcValEl = document.getElementById('setWriteConcurrencyVal');
  if (wcInput){
    wcInput.value = String(parseInt(localStorage.getItem(WC_CK) || '2', 10) || 2);
    if (wcValEl) wcValEl.textContent = wcInput.value;
    function applyWriteConcurrency(){
      let v = parseInt(wcInput.value, 10);
      if (isNaN(v)) v = 2;
      v = Math.max(1, Math.min(8, v));
      wcInput.value = String(v);
      if (wcValEl) wcValEl.textContent = String(v);
      if (typeof setMaxConcurrentWrite === 'function') setMaxConcurrentWrite(v);
      localStorage.setItem(WC_CK, String(v));
    }
    wcInput.addEventListener('input', () => {
      if (wcValEl) wcValEl.textContent = wcInput.value;
    });
    wcInput.addEventListener('change', applyWriteConcurrency);
    applyWriteConcurrency();
  }

  /* ---- 调试开关 ---- */
  const DEBUG_KEY = '3dmc_debug_on';
  let debugOn = localStorage.getItem(DEBUG_KEY) === 'on';
  const debugPanelEl = document.getElementById('debugPanel');

  function applyDebug(){
    if (debugPanelEl) debugPanelEl.style.display = debugOn ? 'block' : 'none';
  }
  const debugBtns = document.querySelectorAll('#setDebug button');
  if (debugBtns.length){
    debugBtns.forEach(b => {
      b.classList.toggle('active', (b.dataset.val === 'on') === debugOn);
      b.addEventListener('click', () => {
        debugOn = (b.dataset.val === 'on');
        localStorage.setItem(DEBUG_KEY, debugOn ? 'on' : 'off');
        applyDebug();
        debugBtns.forEach(x =>
          x.classList.toggle('active', (x.dataset.val === 'on') === debugOn));
      });
    });
  }
  applyDebug();

  /* ---- 亮度（20%~300%） ---- */
  const BRIGHT_KEY = '3dmc_brightness';
  const brightInput = document.getElementById('setBrightness');
  const brightValEl = document.getElementById('setBrightnessVal');
  {
    let pct = Math.round(parseFloat(localStorage.getItem(BRIGHT_KEY) || '1.0') * 100);
    if (!isFinite(pct)) pct = 100;
    brightInput.value = String(Math.max(20, Math.min(300, pct)));
    if (brightValEl) brightValEl.textContent = brightInput.value + '%';
  }
  function applyBrightness(){
    const v = parseInt(brightInput.value, 10) / 100;
    setLightMultiplier(v);
    localStorage.setItem(BRIGHT_KEY, String(v));
  }
  brightInput.addEventListener('input', () => {
    if (brightValEl) brightValEl.textContent = brightInput.value + '%';
  });
  brightInput.addEventListener('change', applyBrightness);
  applyBrightness();

  /* ---- 视角灵敏度（10%~500%） ---- */
  const SENS_KEY = '3dmc_sensitivity';
  const sensInput = document.getElementById('setSensitivity');
  const sensValEl = document.getElementById('setSensitivityVal');
  {
    let pct = Math.round(parseFloat(localStorage.getItem(SENS_KEY) || '1.0') * 100);
    if (!isFinite(pct)) pct = 100;
    sensInput.value = String(Math.max(10, Math.min(500, pct)));
    if (sensValEl) sensValEl.textContent = sensInput.value + '%';
  }
  function applySensitivity(){
    const v = parseInt(sensInput.value, 10) / 100;
    setLookSensitivity(v);
    localStorage.setItem(SENS_KEY, String(v));
  }
  sensInput.addEventListener('input', () => {
    if (sensValEl) sensValEl.textContent = sensInput.value + '%';
  });
  sensInput.addEventListener('change', applySensitivity);
  applySensitivity();

  /* ---- 物品栏尺寸：启动时应用（调整入口在按键编辑模式里） ---- */
  (function applySavedUISize(){
    const KEY = '3dmc_ui_size';
    let v = parseFloat(localStorage.getItem(KEY) || '48');
    if (!isFinite(v)) v = 48;
    v = Math.max(28, Math.min(80, v));
    document.documentElement.style.setProperty('--slot-size',  Math.round(v - 4) + 'px');
  })();

  /* ---- 背包大小 / 箱子熔炉面板偏移：调整入口已移到「编辑布局」面板 ---- */

  /* ---- 清晰度（0~100%，100% = 原生分辨率） ---- */
  const RES_KEY = '3dmc_resolution';
  const resInput = document.getElementById('setResolution');
  const resValEl = document.getElementById('setResolutionVal');
  {
    const saved = parseFloat(localStorage.getItem(RES_KEY) || '1.0');
    const pct = isFinite(saved) ? Math.round(saved * 100) : 100;
    resInput.value = String(Math.max(25, Math.min(100, pct)));
    if (resValEl) resValEl.textContent = resInput.value + '%';
  }
  function applyResolution(){
    const pct = parseInt(resInput.value, 10);
    applyRenderSize(Math.max(0.25, Math.min(1.0, pct / 100)));
    localStorage.setItem(RES_KEY, String(pct / 100));
  }
  resInput.addEventListener('input', () => {
    if (resValEl) resValEl.textContent = resInput.value + '%';
  });
  resInput.addEventListener('change', applyResolution);
  applyResolution();

  /* ============================================================
     暂停菜单
     ============================================================ */
  const btnMenu = document.getElementById('btnMenu');
  if (btnMenu){
    btnMenu.addEventListener('click', async () => {
      /* ★ 打开暂停菜单前先收起背包/箱子/熔炉，避免面板重叠 */
      closeInv();
      closeChest();
      closeFurnace();
      await persistCurrentWorld();
      document.getElementById('pause').classList.add('show');
    });
  }

  const btnResume = document.getElementById('btnResume');
  if (btnResume){
    btnResume.addEventListener('click', () => {
      document.getElementById('pause').classList.remove('show');
    });
  }

  const btnSave = document.getElementById('btnSave');
  if (btnSave){
    btnSave.addEventListener('click', async () => {
      await persistCurrentWorld();
      const cs = getCurrentSave();
      if (cs){
        emit('world.leave', cs.id);
        try { await unloadAllMods(cs.id); }
        catch(e){ console.error('[mods] unload failed', e); }
        setLogSaveId(null);
      }
      document.getElementById('pause').classList.remove('show');
      if (typeof onLeaveWorld === 'function') onLeaveWorld();
    });
  }

  const btnUploadLog = document.getElementById('btnUploadLog');
  if (btnUploadLog){
    btnUploadLog.addEventListener('click', async () => {
      const ok = await uploadLog();
      toast(ok ? '日志已上传' : '上传失败');
    });
  }

  const settingsClose = document.getElementById('settingsClose');
  if (settingsClose){
    settingsClose.addEventListener('click', () => {
      settingsEl.classList.remove('show');
    });
  }

  try { _initMenuBindings(); } catch(e){ console.warn('[settings] _initMenuBindings 失败:', e); }

  /* 命令系统：注入设置面板 tab + 挂 T 键监听（幂等） */
  try { setupCommandSettings(); }
  catch(e){ console.warn('[settings] 命令系统初始化失败:', e); }
}

/* ============================================================
   ★ 区块边框开关
   ============================================================ */
(function initChunkBorderToggle(){
  if (typeof window === 'undefined') return;

  const tryInit = (attempt) => {
    const sub = document.getElementById('sub-mem');
    if (!sub){
      if (attempt < 20) setTimeout(() => tryInit(attempt + 1), 100);
      return;
    }
    if (sub.querySelector('#setChunkBorder')) return;

    const row = document.createElement('div');
    row.className = 'setrow';
    row.innerHTML = '<label>区块边框</label>' +
      '<div class="segmented" id="setChunkBorder">' +
      '<button data-val="off">关</button>' +
      '<button data-val="on">开</button>' +
      '</div>';
    sub.appendChild(row);

    const btns = row.querySelectorAll('button');
    let on = localStorage.getItem('3dmc_chunk_border') === 'on';
    btns.forEach(b => b.classList.toggle('active', (b.dataset.val === 'on') === on));

    const apply = (val) => {
      import('../render/chunk-debug.js')
        .then(m => m.setChunkDebugEnabled(val))
        .catch(e => console.warn('[chunk-border]', e));
    };

    btns.forEach(b => {
      b.addEventListener('click', () => {
        on = (b.dataset.val === 'on');
        localStorage.setItem('3dmc_chunk_border', on ? 'on' : 'off');
        btns.forEach(x => x.classList.toggle('active', (x.dataset.val === 'on') === on));
        apply(on);
      });
    });

    if (on) apply(true);
  };

  tryInit(0);
})();

/* ============================================================
   ★ 移动光源模式
   ------------------------------------------------------------
   关 / 自动 / 体素光 / 点光源
     · 自动：默认点光源（跟手、平滑），帧时持续超标时自动降级到体素光
     · 体素光：走 CPU 注入方块光，方格感、会绕墙，但零片元开销
     · 点光源：真的 PointLight，画面平滑，吃 GPU
   ============================================================ */
(function initDynamicLightToggle(){
  if (typeof window === 'undefined') return;

  const MODES = ['off', 'auto', 'voxel', 'point'];

  const tryInit = (attempt) => {
    const sub = document.getElementById('sub-graphics');
    if (!sub){
      if (attempt < 20) setTimeout(() => tryInit(attempt + 1), 100);
      return;
    }
    if (sub.querySelector('#setDynamicLight')) return;

    const row = document.createElement('div');
    row.className = 'setrow';
    row.innerHTML = '<label>移动光源</label>' +
      '<div class="segmented" id="setDynamicLight">' +
      '<button data-val="off">关</button>' +
      '<button data-val="auto">自动</button>' +
      '<button data-val="voxel">体素光</button>' +
      '<button data-val="point">点光源</button>' +
      '</div>';
    sub.appendChild(row);

    const btns = row.querySelectorAll('button');
    let cur = 'auto';
    try {
      const v = localStorage.getItem('3dmc_dynamic_light_mode');
      if (MODES.indexOf(v) >= 0) cur = v;
      else if (localStorage.getItem('3dmc_dynamic_light_v2') === 'off') cur = 'off';
    } catch(e){}

    const paint = () => btns.forEach(b =>
      b.classList.toggle('active', b.dataset.val === cur));

    const apply = (val) => {
      import('../render/dynamic-light.js')
        .then(m => m.setDynamicLightMode(val))
        .catch(e => console.warn('[dynamic-light]', e));
    };

    btns.forEach(b => {
      b.addEventListener('click', () => {
        cur = b.dataset.val;
        try { localStorage.setItem('3dmc_dynamic_light_mode', cur); } catch(e){}
        paint();
        apply(cur);
      });
    });

    paint();
    /* 让调度器按存档模式初始化一次（模块内也会自己读，这里保证路径生效） */
    apply(cur);
  };

  tryInit(0);
})();

/* ============================================================
   ★ 泛光（bloom）
   ------------------------------------------------------------
   关 / 低 / 高：屏幕空间后处理，让洞口、阳光、荧石、火把、
   点光源产生真实的光晕溢出（不是全局提亮）。
   ★ 低端触屏默认关；桌面默认低档。
   ============================================================ */
(function initBloomToggle(){
  if (typeof window === 'undefined') return;

  const MODES = ['off', 'low', 'high'];
  const DEF = IS_TOUCH ? 'off' : 'low';

  const tryInit = (attempt) => {
    const sub = document.getElementById('sub-graphics');
    if (!sub){
      if (attempt < 20) setTimeout(() => tryInit(attempt + 1), 100);
      return;
    }
    if (sub.querySelector('#setBloom')) return;

    const row = document.createElement('div');
    row.className = 'setrow';
    row.innerHTML = '<label>泛光</label>' +
      '<div class="segmented" id="setBloom">' +
      '<button data-val="off">关</button>' +
      '<button data-val="low">低</button>' +
      '<button data-val="high">高</button>' +
      '</div>';
    sub.appendChild(row);

    const btns = row.querySelectorAll('button');
    let cur = DEF;
    try {
      const v = localStorage.getItem('3dmc_bloom');
      if (MODES.indexOf(v) >= 0) cur = v;
    } catch(e){}

    const paint = () => btns.forEach(b =>
      b.classList.toggle('active', b.dataset.val === cur));

    const apply = (val) => {
      import('../render/bloom.js')
        .then(m => m.setBloomMode(val))
        .catch(e => console.warn('[bloom]', e));
    };

    btns.forEach(b => {
      b.addEventListener('click', () => {
        cur = b.dataset.val;
        try { localStorage.setItem('3dmc_bloom', cur); } catch(e){}
        paint();
        apply(cur);
      });
    });

    paint();
    apply(cur);
  };

  tryInit(0);
})();

/* ============================================================
   ★ 环境光遮蔽（SSAO）
   ------------------------------------------------------------
   屏幕空间接触阴影：墙角、缝隙、方块交界会自然变暗。
   对动态光（火把）尤其重要 —— 火把走的是"未烘焙反照率"，
   顶点色里的 AO 在那条路径上被归一化约掉了，不开 SSAO 时
   火把照到的面是一片平的，没有立体感。

   ★ 依赖泛光：SSAO 复用泛光链路的场景 RT 和深度纹理，
     泛光关掉时这一项不起作用（面板里会置灰提示）。
   ============================================================ */
(function initSSAOToggle(){
  if (typeof window === 'undefined') return;

  const tryInit = (attempt) => {
    const sub = document.getElementById('sub-graphics');
    if (!sub){
      if (attempt < 20) setTimeout(() => tryInit(attempt + 1), 100);
      return;
    }
    if (sub.querySelector('#setSSAO')) return;

    const row = document.createElement('div');
    row.className = 'setrow';
    row.innerHTML = '<label>环境光遮蔽</label>' +
      '<div class="segmented" id="setSSAO">' +
      '<button data-val="off">关</button>' +
      '<button data-val="on">开</button>' +
      '</div>';
    sub.appendChild(row);

    const btns = row.querySelectorAll('button');
    let cur = 'on';
    try {
      const v = localStorage.getItem('3dmc_ssao');
      if (v === 'off' || v === '0') cur = 'off';
      else if (v === 'on' || v === '1') cur = 'on';
    } catch(e){}

    const paint = () => btns.forEach(b =>
      b.classList.toggle('active', b.dataset.val === cur));

    const apply = (val) => {
      import('../render/bloom.js')
        .then(m => m.setSSAOEnabled(val === 'on'))
        .catch(e => console.warn('[ssao]', e));
    };

    btns.forEach(b => {
      b.addEventListener('click', () => {
        cur = b.dataset.val;
        try { localStorage.setItem('3dmc_ssao', cur); } catch(e){}
        paint();
        apply(cur);
      });
    });

    paint();
    apply(cur);
  };

  tryInit(0);
})();

/* ============================================================
   ★ [menu-bindings-v1] 统一绑定暂停菜单 + 设置面板的所有交互
   ------------------------------------------------------------
   幂等：每个元素只绑定一次（用 el.__bound[key] 标记）
   覆盖：
     · 暂停菜单 → 设置 / 全屏 / Mod 状态
     · 设置面板 → 返回 / 侧栏切换 / 性能子页切换
     · 上传日志（在"关于"tab，若已有绑定则用 _bindOnce 跳过）
   ============================================================ */
function _bindOnce(el, event, handler, key){
  if (!el) return false;
  if (el.__bound && el.__bound[key]) return false;
  if (!el.__bound) el.__bound = {};
  el.__bound[key] = true;
  el.addEventListener(event, handler);
  return true;
}

function _initMenuBindings(){
  const settingsEl = document.getElementById('settings');
  const pauseEl    = document.getElementById('pause');

  /* ---- 暂停菜单：打开设置 ---- */
  _bindOnce(document.getElementById('btnOpenSettings'), 'click', () => {
    if (pauseEl) pauseEl.classList.remove('show');
    if (settingsEl){
      settingsEl.classList.add('show');
      /* 默认选中"性能"tab */
      document.querySelectorAll('#settingsSidebar .sidebar-item').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === 'perf');
      });
      document.querySelectorAll('.settings-tab').forEach(t => {
        t.style.display = (t.id === 'tab-perf') ? '' : 'none';
      });
      /* 默认显示"画面"子页 */
      document.querySelectorAll('.subpage').forEach(p => {
        p.style.display = (p.id === 'sub-graphics') ? '' : 'none';
      });
      const subnav = document.getElementById('perfSubnav');
      if (subnav){
        subnav.querySelectorAll('button[data-sub]').forEach(b => {
          b.classList.toggle('active', b.dataset.sub === 'graphics');
        });
      }
    }
  }, 'menu');

  /* ---- 暂停菜单：全屏 ---- */
  _bindOnce(document.getElementById('btnFullscreen3'), 'click', () => {
    import('./ui-panel.js')
      .then(m => m.toggleFullscreen())
      .catch(() => {});
  }, 'menu');

  /* ---- 暂停菜单：Mod 状态 ---- */
  _bindOnce(document.getElementById('btnModStatus'), 'click', () => {
    import('./mod-panel/index.js')
      .then(m => m.openModStatus())
      .catch(e => console.error('[settings] 打开 Mod 状态失败:', e));
  }, 'menu');

  /* ---- 设置面板：返回（回暂停菜单） ---- */
  _bindOnce(document.getElementById('settingsBack'), 'click', () => {
    if (settingsEl) settingsEl.classList.remove('show');
    if (pauseEl) pauseEl.classList.add('show');
  }, 'menu');

  /* ---- 设置面板：侧栏切换 ---- */
  const sidebar = document.getElementById('settingsSidebar');
  if (sidebar){
    _bindOnce(sidebar, 'click', (e) => {
      const item = e.target.closest('.sidebar-item');
      if (!item) return;
      const tabId = item.dataset.tab;
      document.querySelectorAll('.settings-tab').forEach(t => {
        t.style.display = (t.id === 'tab-' + tabId) ? '' : 'none';
      });
      sidebar.querySelectorAll('.sidebar-item').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === tabId);
      });
    }, 'menu');
  }

  /* ---- 性能 tab：子页切换 ---- */
  const perfSubnav = document.getElementById('perfSubnav');
  if (perfSubnav){
    _bindOnce(perfSubnav, 'click', (e) => {
      const btn = e.target.closest('button[data-sub]');
      if (!btn) return;
      const subId = btn.dataset.sub;
      document.querySelectorAll('.subpage').forEach(p => {
        p.style.display = (p.id === 'sub-' + subId) ? '' : 'none';
      });
      perfSubnav.querySelectorAll('button[data-sub]').forEach(b => {
        b.classList.toggle('active', b.dataset.sub === subId);
      });
    }, 'menu');
  }

  /* ---- 关于 tab：上传日志 ---- */
  _bindOnce(document.getElementById('btnUploadLog'), 'click', async () => {
    try {
      const rt = await import('./../core/runtime.js');
      const ui = await import('./ui.js');
      const ok = await rt.uploadLog();
      if (ui && typeof ui.toast === 'function'){
        ui.toast(ok ? '日志已上传' : '上传失败');
      }
    } catch (e){
      console.error('[settings] 上传日志失败:', e);
    }
  }, 'menu');

  console.log('[settings] 菜单绑定已初始化');
}

