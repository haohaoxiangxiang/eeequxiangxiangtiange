/* ============================================================
   ui.js —— 游戏内 UI、背包、快捷栏、熔炉
   ------------------------------------------------------------
   ★ 改动：彻底移除已废弃的 HUD 相关逻辑（hudEl, updateHUD）
   ============================================================ */

import { INV_SIZE, STACK_MAX, IS_TOUCH } from './../core/engine-core.js';
import { BLOCKS } from '../world/blocks.js';
import { onBlockRegistered } from './../world/world-registry.js';
import { atlasCanvasEl, onAtlasChanged } from '../world/textures.js';
import { getItemIconURL } from '../items/item-visuals.js';
import { initItemTip, attachItemTip, hideItemTip } from './item-tip.js';
import { inventory, onInventoryChange, notifyInventory, addItem, takeFromSlot }
  from './../items/items-core.js';
import { player } from './../player/player-core.js';
import {
  setCharLook, initCharPreview, resizeCharPreview, setCharPreviewActive,
} from '../player/avatar.js';
import { craftGrid, craftResult, onCraftChange, setCraftSlot, setCraftSize, getCraftSize,
         takeCraftResult, isCraftEmpty, dumpCraftTo, recalcCraftSilent, recalcCraft } from './../items/items-logic.js';
import { getFurnace, isFuel, getSmeltResult, FURNACE_STACK_MAX } from './../items/items-logic.js';
import { CHEST_SIZE, CHEST_STACK_MAX, getChest, loadChest, saveChest,
         touchChest, emitChestOpened, emitChestClosed } from './../items/items-core.js';
import { playSFX } from '../audio/audio.js';
import { emit } from './../core/engine-core.js';
import {
  buildCreativeIndex, listCreativeCategories, onCreativeCategoryChange,
} from './../world/world-registry.js';

/* ★ M1：这两个是 main.js 依赖的导出 */
export let curSlot = 0;
export const hotbarEl = document.getElementById('hotbar');

/* ★ 物品悬浮面板：图标绘制复用 setSlotIcon（同文件函数声明，已提升）。
   这里只注入渲染函数，面板本身由 item-tip.js 懒创建。 */
initItemTip({ renderIcon: (el, id, size) => setSlotIcon(el, id, size) });

/* ---- DOM 引用 ---- */
const invEl = document.getElementById('inv');
const invGridEl = document.getElementById('invgrid');
const creativeGridEl = document.getElementById('creativegrid');
const craftGridEl = document.getElementById('craftgrid');
const craftResultEl = document.getElementById('craftresult');
const heartsEl = document.getElementById('hearts');
const breathEl = document.getElementById('breath');
/* ★ 护甲值条（饱食度上方，和左侧呼吸条镜像对称） */
const armorEl = document.getElementById('armor');
const breathFillEl = document.getElementById('breathFill');
const toastEl = document.getElementById('toast');
const heldCursorEl = document.getElementById('heldCursor');

let heldItem = null;
let pointerX = 0, pointerY = 0;
let suppressClickUntil = 0;

/* 2x2 DOM 索引 ↔ grid 索引映射 */
const DOM2X2_TO_GRID = [0, 1, 3, 4];
function domToGridIdx(domIdx){
  if (getCraftSize() === 2){
    return DOM2X2_TO_GRID[domIdx] !== undefined ? DOM2X2_TO_GRID[domIdx] : -1;
  }
  return domIdx;
}
function gridToDomIdx(gridIdx){
  if (getCraftSize() === 2){
    return DOM2X2_TO_GRID.indexOf(gridIdx);
  }
  return gridIdx;
}

/* ============================================================
   ★ M1：atlas CSS 订阅（可运行时刷新）
   ============================================================ */
let _atlasStyleEl = null;

function _updateAtlasStyle(){
  if (!_atlasStyleEl){
    _atlasStyleEl = document.createElement('style');
    document.head.appendChild(_atlasStyleEl);
  }
  const url = atlasCanvasEl.toDataURL();
  _atlasStyleEl.textContent = `
    .islot, .slot, #craftresult, .fslot, #heldCursor {
      background-image: url(${url});
      image-rendering: pixelated;
    }
    .islot.no-icon, .slot.no-icon, #craftresult.no-icon,
    .fslot.no-icon, #heldCursor.no-icon {
      background-image: none;
    }
  `;
}
_updateAtlasStyle();
onAtlasChanged(_updateAtlasStyle);

/* ============================================================
   槽位内容更新
   ============================================================ */
export function setSlotIcon(el, blockId, sizePx){
  if (!blockId){
    el.classList.add('no-icon');
    el.style.backgroundImage = '';
    el.style.backgroundSize = '';
    el.style.backgroundPosition = '';
    return;
  }
  /* 方块图标是等轴测 3D 小方块，纯物品仍是平面图（见 item-visuals.js） */
  const url = getItemIconURL(blockId);
  if (!url){
    el.classList.add('no-icon');
    el.style.backgroundImage = '';
    return;
  }
  el.classList.remove('no-icon');
  el.style.backgroundImage = `url(${url})`;
  el.style.backgroundSize = 'contain';
  el.style.backgroundPosition = 'center';
}

function getIconSize(){
  /* ★ 优先量真实格子宽度：手机上 --islot-size 会随屏宽缩小，
     直接 parseInt CSS 变量拿不到 calc() 的结果 */
  const probe = (invEl && invEl.querySelector && invEl.querySelector('.invgrid .islot'))
             || document.querySelector('.invgrid .islot');
  if (probe && probe.getBoundingClientRect){
    const w = Math.round(probe.getBoundingClientRect().width || 0);
    if (w >= 16 && w <= 128) return w;
  }
  const s = getComputedStyle(document.documentElement).getPropertyValue('--islot-size').trim();
  const n = parseInt(s, 10);
  return isNaN(n) ? 48 : n;
}
function getHotbarIconSize(){
  const s = getComputedStyle(document.documentElement).getPropertyValue('--slot-size').trim();
  const n = parseInt(s, 10);
  return isNaN(n) ? 44 : n;
}

function _slotKey(item){
  if (!item) return '0';
  return item.id + ':' + (item.count || 0) + ':' + (item.durability !== undefined ? item.durability : -1);
}

function appendCount(el, item){
  if (item && item.count > 1){
    const c = document.createElement('span');
    c.className = 'count';
    c.textContent = item.count;
    el.appendChild(c);
  }
}

function appendDura(el, item){
  if (item && item.durability !== undefined && item.maxDurability > 0){
    const dur = document.createElement('div');
    dur.className = 'dura';
    const pct = Math.max(0, item.durability / item.maxDurability) * 100;
    dur.style.width = pct + '%';
    const hue = Math.round(pct * 1.2);
    dur.style.background = `hsl(${hue}, 85%, 50%)`;
    el.appendChild(dur);
  }
}

function _setSlotContent(el, item, iconSize, keepNum){
  for (let i = el.childNodes.length - 1; i >= 0; i--){
    const c = el.childNodes[i];
    if (keepNum && c.classList && c.classList.contains('num')) continue;
    el.removeChild(c);
  }
  if (item){
    setSlotIcon(el, item.id, iconSize);
    appendCount(el, item);
    appendDura(el, item);
  } else {
    setSlotIcon(el, 0, iconSize);
  }
}

/* ============================================================
   浮动手持
   ------------------------------------------------------------
   ★ 触屏上原来只有 mousemove 会更新 pointerX/pointerY，
     手指点一下就再也追不上，鬼手会停在屏幕角落或者上一次鼠标的位置，
     看起来就像"点一下东西就没了"。这里统一从 pointer / touch / click
     三种事件里取坐标。
   ============================================================ */
function _setPointer(x, y){
  if (typeof x === 'number' && typeof y === 'number' && !isNaN(x) && !isNaN(y)){
    pointerX = x;
    pointerY = y;
  }
}

function _syncPointerFromEvent(e){
  if (!e) return;
  if (typeof e.clientX === 'number' && typeof e.clientY === 'number' && (e.clientX || e.clientY)){
    _setPointer(e.clientX, e.clientY);
    return;
  }
  const t = (e.changedTouches && e.changedTouches[0]) || (e.touches && e.touches[0]);
  if (t) _setPointer(t.clientX, t.clientY);
}

function updateHeldCursorView(){
  if (!heldCursorEl) return;
  if (!heldItem){
    heldCursorEl.style.display = 'none';
    heldCursorEl.innerHTML = '';
    return;
  }
  heldCursorEl.style.display = 'block';
  heldCursorEl.style.left = pointerX + 'px';
  heldCursorEl.style.top = pointerY + 'px';
  heldCursorEl.innerHTML = '';
  setSlotIcon(heldCursorEl, heldItem.id, getIconSize());
  appendCount(heldCursorEl, heldItem);
  appendDura(heldCursorEl, heldItem);
}

/* ============================================================
   快捷栏
   ============================================================ */
let _hotSlots = null;
let _hotCache = new Array(9).fill('__init__');

function _ensureHotSlots(){
  if (_hotSlots) return;
  _hotSlots = [];
  hotbarEl.innerHTML = '';
  for (let i = 0; i < 9; i++){
    const d = document.createElement('div');
    d.className = 'slot';
    const n = document.createElement('span');
    n.className = 'num';
    n.textContent = (i + 1);
    d.appendChild(n);
    d.addEventListener('click', () => { curSlot = i; updateHotbar(); });
    d.addEventListener('touchstart', e => {
      e.preventDefault(); e.stopPropagation();
      curSlot = i; updateHotbar();
    }, { passive: false });
    attachItemTip(d, _tipByInvIdx(i));
    hotbarEl.appendChild(d);
    _hotSlots.push(d);
  }
}

export function updateHotbar(){
  _ensureHotSlots();
  const iconSize = getHotbarIconSize();
  for (let i = 0; i < 9; i++){
    const s = inventory[i];
    const key = (i === curSlot ? 'S' : '_') + '|' + _slotKey(s);
    if (_hotCache[i] === key) continue;
    _hotCache[i] = key;
    const d = _hotSlots[i];
    d.classList.toggle('sel', i === curSlot);
    _setSlotContent(d, s, iconSize, true);
  }
}

/* ============================================================
   背包格点击
   ============================================================ */
function onInvSlotClick(slotIdx, e){
  if (performance.now() < suppressClickUntil) return;
  _syncPointerFromEvent(e);
  const cur = inventory[slotIdx];
  if (heldItem === null){
    if (cur){ heldItem = cur; inventory[slotIdx] = null; }
  } else {
    const heldMaxStack = BLOCKS[heldItem.id].maxStack || 64;
    if (cur && cur.id === heldItem.id && cur.count < heldMaxStack && heldMaxStack > 1){
      const add = Math.min(heldMaxStack - cur.count, heldItem.count);
      cur.count += add;
      heldItem.count -= add;
      if (heldItem.count <= 0) heldItem = null;
    } else if (cur){
      inventory[slotIdx] = heldItem;
      heldItem = cur;
    } else {
      inventory[slotIdx] = heldItem;
      heldItem = null;
    }
  }
  /* ★ 这里必须刷新浮动手持：
     原来只在 notifyInventory → refreshItemUI 里刷新，而背包面板没开时
     refreshItemUI 会跳过 updateInvUI，于是把东西放进背包后
     "鬼手"上的物品图标不会消失，看起来像还没放下。 */
  updateHeldCursorView();
  notifyInventory();
}

/* ============================================================
   合成格点击
   ============================================================ */
function onCraftSlotClick(gridIdx){
  if (performance.now() < suppressClickUntil) return;
  const cur = craftGrid[gridIdx];
  if (heldItem === null){
    if (cur){ heldItem = cur; setCraftSlot(gridIdx, null); }
  } else {
    const heldMaxStack = BLOCKS[heldItem.id].maxStack || 64;
    if (cur && cur.id === heldItem.id && cur.count < heldMaxStack && heldMaxStack > 1){
      const add = Math.min(heldMaxStack - cur.count, heldItem.count);
      cur.count += add;
      heldItem.count -= add;
      if (heldItem.count <= 0) heldItem = null;
      setCraftSlot(gridIdx, cur);
    } else if (cur){
      setCraftSlot(gridIdx, heldItem);
      heldItem = cur;
    } else {
      setCraftSlot(gridIdx, heldItem);
      heldItem = null;
    }
  }
  updateInvUI();
}

function updateCraftSlotView(gridIdx){
  const domIdx = gridToDomIdx(gridIdx);
  if (domIdx < 0) return;
  const el = craftGridEl.children[domIdx];
  if (!el) return;
  _setSlotContent(el, craftGrid[gridIdx], getIconSize(), false);
}

function updateCraftGridLight(){
  const idxs = getCraftSize() === 2 ? [0, 1, 3, 4] : [0,1,2,3,4,5,6,7,8];
  for (const i of idxs) updateCraftSlotView(i);
}

function getCraftCellCount(){
  let n = 0;
  for (let i = 0; i < 9; i++) if (craftGrid[i]) n++;
  return n;
}

function updateCraftResultLight(){
  craftResultEl.innerHTML = '';
  craftResultEl.classList.toggle('hasresult', !!craftResult);
  if (craftResult){
    setSlotIcon(craftResultEl, craftResult.id, getIconSize());
    if (craftResult.count > 1){
      const c = document.createElement('span');
      c.className = 'count';
      c.textContent = craftResult.count;
      craftResultEl.appendChild(c);
    }
  } else {
    setSlotIcon(craftResultEl, 0, getIconSize());
    if (getCraftSize() === 2 && getCraftCellCount() > 0){
      craftResultEl.title = '部分配方需要工作台（3×3）';
      craftResultEl.classList.add('needtable');
    } else {
      craftResultEl.classList.remove('needtable');
    }
  }
}

/* ============================================================
   合成格拖动
   ============================================================ */
let dragState = null;

function applyDragDistribution(){
  if (!dragState || !dragState.hadItem) return;
  for (const [slot, orig] of dragState.originals){
    craftGrid[slot] = orig ? { ...orig } : null;
  }
  const slots = dragState.slots;
  const n = slots.length;
  const total = dragState.total;
  const base = Math.floor(total / n);
  const extra = total % n;
  let remaining = total;
  for (let i = 0; i < n; i++){
    const slot = slots[i];
    const want = base + (i < extra ? 1 : 0);
    const cur = craftGrid[slot];
    const curCount = cur ? cur.count : 0;
    const canAdd = Math.min(want, STACK_MAX - curCount);
    if (canAdd > 0){
      craftGrid[slot] = { id: dragState.itemId, count: curCount + canAdd };
      remaining -= canAdd;
    }
  }
  heldItem = remaining > 0 ? { id: dragState.itemId, count: remaining } : null;
  recalcCraftSilent();
}

function slotGridIndexFromPoint(x, y){
  const el = document.elementFromPoint(x, y);
  if (!el || !el.closest) return -1;
  const slotEl = el.closest('.islot');
  if (!slotEl || slotEl.parentElement !== craftGridEl) return -1;
  const domIdx = Array.from(craftGridEl.children).indexOf(slotEl);
  return domToGridIdx(domIdx);
}

function onCraftTouchStart(e){
  const slotEl = e.target.closest && e.target.closest('.islot');
  if (!slotEl || slotEl.parentElement !== craftGridEl) return;
  const domIdx = Array.from(craftGridEl.children).indexOf(slotEl);
  const gridIdx = domToGridIdx(domIdx);
  if (gridIdx < 0) return;

  const t = e.changedTouches[0];
  pointerX = t.clientX;
  pointerY = t.clientY;

  dragState = {
    identifier: t.identifier,
    startGridIdx: gridIdx,
    startX: t.clientX, startY: t.clientY,
    moved: false,
    itemId: heldItem ? heldItem.id : null,
    total: heldItem ? heldItem.count : 0,
    slots: [],
    originals: new Map(),
    hadItem: !!heldItem
  };
}

function onCraftTouchMove(e){
  if (!dragState) return;
  for (const t of e.changedTouches){
    if (t.identifier !== dragState.identifier) continue;
    pointerX = t.clientX;
    pointerY = t.clientY;

    const dx = t.clientX - dragState.startX;
    const dy = t.clientY - dragState.startY;

    if (!dragState.moved){
      if (Math.hypot(dx, dy) < 10) return;
      if (e.cancelable) e.preventDefault();
      dragState.moved = true;
      if (dragState.hadItem){
        const startIdx = dragState.startGridIdx;
        const cur = craftGrid[startIdx];
        if (!cur || cur.id === dragState.itemId){
          dragState.originals.set(startIdx, cur ? { ...cur } : null);
          dragState.slots.push(startIdx);
          applyDragDistribution();
          updateCraftGridLight();
          updateCraftResultLight();
          updateHeldCursorView();
        }
      }
    }

    if (e.cancelable) e.preventDefault();
    if (!dragState.hadItem) return;

    const gridIdx = slotGridIndexFromPoint(t.clientX, t.clientY);
    if (gridIdx >= 0 && !dragState.slots.includes(gridIdx)){
      const cur = craftGrid[gridIdx];
      if (!cur || cur.id === dragState.itemId){
        dragState.originals.set(gridIdx, cur ? { ...cur } : null);
        dragState.slots.push(gridIdx);
        applyDragDistribution();
        updateCraftGridLight();
        updateCraftResultLight();
        updateHeldCursorView();
      }
    }
  }
}

function onCraftTouchEnd(e){
  if (!dragState) return;
  for (const t of e.changedTouches){
    if (t.identifier !== dragState.identifier) continue;

    if (!dragState.moved){
      const gridIdx = dragState.startGridIdx;
      if (dragState.hadItem){
        const cur = craftGrid[gridIdx];
        const heldMaxStack = BLOCKS[dragState.itemId].maxStack || 64;
        if (cur && cur.id === dragState.itemId && cur.count < heldMaxStack && heldMaxStack > 1){
          const add = Math.min(heldMaxStack - cur.count, dragState.total);
          cur.count += add;
          const left = dragState.total - add;
          heldItem = left > 0 ? { id: dragState.itemId, count: left } : null;
          setCraftSlot(gridIdx, cur);
        } else if (cur){
          setCraftSlot(gridIdx, { id: dragState.itemId, count: dragState.total });
          heldItem = cur;
        } else {
          setCraftSlot(gridIdx, { id: dragState.itemId, count: dragState.total });
          heldItem = null;
        }
      } else {
        const cur = craftGrid[gridIdx];
        if (cur){ heldItem = cur; setCraftSlot(gridIdx, null); }
      }
    }

    suppressClickUntil = performance.now() + 350;
    dragState = null;
    recalcCraft();
    updateCraftGridLight();
    updateCraftResultLight();
    updateHeldCursorView();
    return;
  }
}

/* ============================================================
   背包拖动
   ============================================================ */
let invDrag = null;

function onInvDragStart(e){
  const slotEl = e.target.closest && e.target.closest('.islot');
  if (!slotEl) return;
  const parent = slotEl.parentElement;
  if (parent === craftGridEl) return;
  if (parent === creativeGridEl) return;
  /* ★ 背包区 + 物品栏区都支持拖动 */
  const fromIdx = _invIdxOfSlotEl(slotEl);
  if (fromIdx < 0) return;

  const t = e.changedTouches[0];
  pointerX = t.clientX;
  pointerY = t.clientY;

  invDrag = {
    identifier: t.identifier,
    fromIdx,
    startX: t.clientX, startY: t.clientY,
    moved: false
  };
}

function onInvDragMove(e){
  if (!invDrag) return;
  for (const t of e.changedTouches){
    if (t.identifier !== invDrag.identifier) continue;
    pointerX = t.clientX;
    pointerY = t.clientY;

    const dx = t.clientX - invDrag.startX;
    const dy = t.clientY - invDrag.startY;

    if (!invDrag.moved && Math.hypot(dx, dy) < 10) return;
    if (e.cancelable) e.preventDefault();

    if (!invDrag.moved){
      invDrag.moved = true;
      if (!heldItem){
        const item = inventory[invDrag.fromIdx];
        if (item){
          heldItem = item;
          inventory[invDrag.fromIdx] = null;
          notifyInventory();
        }
      }
    }
    updateHeldCursorView();
  }
}

function onInvDragEnd(e){
  if (!invDrag) return;
  for (const t of e.changedTouches){
    if (t.identifier !== invDrag.identifier) continue;

    if (invDrag.moved){
      const el = document.elementFromPoint(t.clientX, t.clientY);
      const armorZone = el && el.closest ? el.closest('.armor-zone') : null;
      if (armorZone){
        suppressClickUntil = performance.now() + 350;
        invDrag = null;
        _equipArmor(armorZone.dataset.slot);
        return;
      }
      if (el){
        const slotEl = el.closest && el.closest('.islot');
        if (slotEl){
          const dropIdx = _invIdxOfSlotEl(slotEl);
          if (dropIdx >= 0){
            onInvSlotClick(dropIdx, t);
          } else if (slotEl.parentElement === craftGridEl){
            const domIdx = Array.from(craftGridEl.children).indexOf(slotEl);
            const gridIdx = domToGridIdx(domIdx);
            if (gridIdx >= 0) onCraftSlotClick(gridIdx);
          } else if (slotEl.parentElement === chestGridEl){
            const ci = Array.from(chestGridEl.children).indexOf(slotEl);
            if (ci >= 0) onChestSlotClick(ci);
          }
        }
      }
      suppressClickUntil = performance.now() + 350;
      invDrag = null;
      updateInvUI();
    } else {
      invDrag = null;
    }
    return;
  }
}

/* ============================================================
   取合成结果
   ============================================================ */
function onCraftResultClick(){
  if (performance.now() < suppressClickUntil) return;
  if (!craftResult) return;
  const result = craftResult;

  const resultMaxStack = BLOCKS[result.id].maxStack || 64;
  if (heldItem && heldItem.id === result.id && heldItem.count >= resultMaxStack){
    toast('手中已满，请先放下');
    return;
  }

  const out = takeCraftResult();
  if (!out) return;

  /* ★ M1：合成事件 */
  emit('item.craft', out.id, out.count);

  if (heldItem && heldItem.id === out.id && heldItem.count < resultMaxStack){
    const add = Math.min(resultMaxStack - heldItem.count, out.count);
    heldItem.count += add;
    out.count -= add;
  }
  if (out.count > 0){
    if (!heldItem){
      heldItem = { id: out.id, count: out.count };
    } else {
      const ok = addItem(out.id, out.count);
      if (!ok) toast('背包已满，物品丢失');
    }
  }
  updateInvUI();
}

/* ============================================================
   创造面板（★ 分类 tab + 固定高度网格，不再一条超长列表）
   ------------------------------------------------------------
   · 分类来自 src/world/creative-categories.js
   · mod 用 G.registerCreativeCategory() 注册自己的分类，
     方块用 category:'他自己的id' 就能落进那个 tab
   · 面板高度固定（4 行），列表在自己内部滚动
   ============================================================ */
const creativeBarEl = document.getElementById('creativebar');

let _creativeIndex = null;             /* { byCat: Map<catId, number[]>, total } */
let _creativeCat = null;               /* 当前选中的分类 id */
let _creativeSlots = new Map();        /* blockId -> slot el（只在当前分类内） */

function _pickDefaultCreativeCat(){
  const list = listCreativeCategories();
  for (const c of list){
    const arr = _creativeIndex.byCat.get(c.id);
    if (arr && arr.length) return c.id;
  }
  /* mod 注册了分类但没在 list 里？兜底随便取一个有内容的 */
  for (const [id, arr] of _creativeIndex.byCat){
    if (arr && arr.length) return id;
  }
  return null;
}

function _rebuildCreativeIndex(){
  _creativeIndex = buildCreativeIndex();
  if (!_creativeCat || !_creativeIndex.byCat.has(_creativeCat)){
    _creativeCat = _pickDefaultCreativeCat();
  }
  return _creativeIndex;
}

let _creativeBarPage = 0;  /* ★ 分类栏当前页 */
let _creativeBarLastCat = null;  /* 上次渲染时的选中分类 */

function _renderCreativeBar(){
  if (!creativeBarEl) return;
  _rebuildCreativeIndex();
  creativeBarEl.innerHTML = '';
  creativeBarEl.style.display = 'flex';
  creativeBarEl.style.alignItems = 'center';
  creativeBarEl.style.gap = '4px';

  /* 收集所有有内容的分类（避免空格 chip） */
  const cats = [];
  for (const cat of listCreativeCategories()){
    const arr = _creativeIndex.byCat.get(cat.id) || [];
    if (!arr.length) continue;
    cats.push({ cat, count: arr.length });
  }
  if (cats.length === 0) return;

  const PER_PAGE = 5;
  const totalPages = Math.max(1, Math.ceil(cats.length / PER_PAGE));

  /* 确保当前选中的分类在当前页 —— 只在选中分类变化时跳页，
     箭头翻页时 _creativeCat 不变，所以不会重置 _creativeBarPage。 */
  const curIdx = cats.findIndex(c => c.cat.id === _creativeCat);
  if (curIdx >= 0 && _creativeCat !== _creativeBarLastCat){
    const curPage = Math.floor(curIdx / PER_PAGE);
    _creativeBarPage = curPage;
  }
  _creativeBarLastCat = _creativeCat;
  if (_creativeBarPage < 0) _creativeBarPage = 0;
  if (_creativeBarPage >= totalPages) _creativeBarPage = totalPages - 1;

  const start = _creativeBarPage * PER_PAGE;
  const end = Math.min(start + PER_PAGE, cats.length);
  const needPager = cats.length > PER_PAGE;

  /* 左箭头 */
  if (needPager){
    const prev = document.createElement('button');
    prev.type = 'button';
    prev.className = 'catab-arrow';
    prev.textContent = '‹';
    prev.disabled = _creativeBarPage <= 0;
    prev.addEventListener('click', () => {
      if (_creativeBarPage <= 0) return;
      _creativeBarPage--;
      _renderCreativeBar();
      playSFX('click');
    });
    creativeBarEl.appendChild(prev);
  }

  /* 当前页 chips */
  for (let i = start; i < end; i++){
    const { cat, count } = cats[i];
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'catab' + (cat.id === _creativeCat ? ' sel' : '');
    b.textContent = cat.label;
    const n = document.createElement('span');
    n.className = 'catab-n';
    n.textContent = count;
    b.appendChild(n);
    if (!cat.builtin) b.title = '来自 mod 的分类：' + cat.id;
    b.addEventListener('click', () => {
      if (_creativeCat === cat.id) return;
      _creativeCat = cat.id;
      _renderCreativeBar();
      _renderCreativeGrid();
      updateHeldCursorView();
      playSFX('click');
    });
    creativeBarEl.appendChild(b);
  }

  /* 右箭头 */
  if (needPager){
    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'catab-arrow';
    next.textContent = '›';
    next.disabled = _creativeBarPage >= totalPages - 1;
    next.addEventListener('click', () => {
      if (_creativeBarPage >= totalPages - 1) return;
      _creativeBarPage++;
      _renderCreativeBar();
      playSFX('click');
    });
    creativeBarEl.appendChild(next);
  }
}

function _renderCreativeGrid(){
  creativeGridEl.innerHTML = '';
  _creativeSlots.clear();

  const arr = (_creativeIndex && _creativeIndex.byCat.get(_creativeCat)) || [];
  const iconSize = getIconSize();
  for (const id of arr){
    const blk = BLOCKS[id];
    const d = document.createElement('div');
    d.className = 'islot';
    setSlotIcon(d, id, iconSize);
    d.title = (blk && blk.label) || '';
    if (heldItem && heldItem.id === id) d.classList.add('picked');
    d.addEventListener('click', () => onCreativeClick(id));
    attachItemTip(d, () => BLOCKS[id]);
    creativeGridEl.appendChild(d);
    _creativeSlots.set(id, d);
  }
}

/* 分类/方块集合变了才重建 DOM，避免每次背包刷新都重建几十个格子 */
let _creativeDirty = true;

function _ensureCreativeSlots(){
  if (!_creativeDirty && creativeGridEl && creativeGridEl.children.length) return;
  _creativeDirty = false;
  _renderCreativeBar();
  _renderCreativeGrid();
}

function _updateCreativePicked(prevId){
  if (prevId && _creativeSlots.get(prevId)) _creativeSlots.get(prevId).classList.remove('picked');
  if (heldItem && _creativeSlots.get(heldItem.id)) _creativeSlots.get(heldItem.id).classList.add('picked');
}

function onCreativeClick(blockId){
  if (performance.now() < suppressClickUntil) return;
  const blk = BLOCKS[blockId];
  const stack = (blk && blk.maxStack) ? blk.maxStack : 64;

  const prevId = heldItem ? heldItem.id : null;
  if (heldItem && heldItem.id === blockId){
    heldItem = null;
  } else {
    heldItem = { id: blockId, count: stack };
  }
  _updateCreativePicked(prevId);
  updateHeldCursorView();
}

/* mod 运行时注册了新分类 / 新方块 → 刷新创造面板 */
export function refreshCreativePanel(){
  if (!creativeGridEl) return;
  _creativeDirty = true;
  if (creativeGridEl.style.display === 'none') return;   /* 没开着的话下次打开再建 */
  _ensureCreativeSlots();
  updateHeldCursorView();
}
onCreativeCategoryChange(() => refreshCreativePanel());

function onPanelBlankClick(e){
  if (performance.now() < suppressClickUntil) return;
  if (!heldItem) return;
  if (e.target.closest && e.target.closest('.islot, #craftresult')) return;
  const ok = addItem(heldItem.id, heldItem.count);
  if (!ok) toast('背包已满，物品丢失');
  heldItem = null;
  updateHeldCursorView();
  updateInvUI();
}

/* ============================================================
   主渲染：背包 UI
   ------------------------------------------------------------
   ★ 背包拆成两个区（和快捷栏一致）：
       · 物品栏区  #invgrid     → inventory[0..8]   （= 快捷栏那 9 格）
       · 背包区    #backpackgrid → inventory[9..35]
     创造模式只替换【背包区】，物品栏区永远显示玩家自己的 9 格。
   ============================================================ */
const backpackGridEl = document.getElementById('backpackgrid');
const backpackSectionEl = document.getElementById('backpackSection');

const HOT_SLOTS = 9;                 /* 物品栏格数 */
const INV_START = HOT_SLOTS;         /* 背包区从第 9 格开始 */
const INV_END = INV_SIZE;            /* 到第 36 格 */

let _invSlots = null;                /* [{ el, idx }] 背包区的 27 格 */
let _hotInvSlots = null;                /* [{ el, idx }] 物品栏的 9 格 */
let _invCache = new Array(INV_SIZE).fill('__init__');
const _slotIdxByEl = new WeakMap();  /* el -> inventory 下标（拖动/点击共用） */
let _craftSlots = null;
let _craftCache = new Array(9).fill('__init__');
let _craftLastSize = 0;

/* ---------- 物品提示的取值器 ----------
   ★ 用闭包每次现取，而不是在挂载时把 blk 固定下来：
     背包内容会变（换格、拖拽、合成消耗），固定下来就会显示旧物品。 */
function _tipByInvIdx(idx){
  return () => {
    const it = inventory[idx];
    return (it && BLOCKS[it.id]) ? BLOCKS[it.id] : null;
  };
}

function _makeInvSlot(idx, iconSize){
  const d = document.createElement('div');
  d.className = 'islot';
  d.dataset.invIdx = String(idx);
  d.addEventListener('click', e => onInvSlotClick(idx, e));
  _slotIdxByEl.set(d, idx);
  attachItemTip(d, _tipByInvIdx(idx));
  return d;
}

function _ensureInvSlots(){
  if (_invSlots) return;
  _invSlots = [];
  _hotInvSlots = [];
  const iconSize = getIconSize();

  /* 背包区（27 格） */
  if (backpackGridEl){
    backpackGridEl.innerHTML = '';
    for (let i = INV_START; i < INV_END; i++){
      const d = _makeInvSlot(i, iconSize);
      backpackGridEl.appendChild(d);
      _invSlots.push({ el: d, idx: i });
    }
  }

  /* 物品栏区（9 格，和快捷栏一一对应） */
  invGridEl.innerHTML = '';
  for (let i = 0; i < HOT_SLOTS; i++){
    const d = _makeInvSlot(i, iconSize);
    d.classList.add('hotbar-mirror');
    invGridEl.appendChild(d);
    _hotInvSlots.push({ el: d, idx: i });
  }
}

function _invIdxOfSlotEl(el){
  if (!el) return -1;
  for (let n = el; n; n = n.parentElement){
    const idx = _slotIdxByEl.get(n);
    if (idx !== undefined) return idx;
  }
  return -1;
}

function _renderInvSlotList(list){
  const iconSize = getIconSize();
  for (const slot of list){
    const item = inventory[slot.idx];
    const key = _slotKey(item);
    if (_invCache[slot.idx] === key) continue;
    _invCache[slot.idx] = key;
    _setSlotContent(slot.el, item, iconSize, false);
  }
}

function _rebuildCraftGrid(size){
  _craftSlots = [];
  _craftCache = new Array(9).fill('__init__');
  _craftLastSize = size;
  craftGridEl.innerHTML = '';
  const idxs = size === 2 ? [0, 1, 3, 4] : [0,1,2,3,4,5,6,7,8];
  for (const gridIdx of idxs){
    const d = document.createElement('div');
    d.className = 'islot';
    d.addEventListener('click', () => onCraftSlotClick(gridIdx));
    attachItemTip(d, () => {
      const it = craftGrid[gridIdx];
      return (it && BLOCKS[it.id]) ? BLOCKS[it.id] : null;
    });
    craftGridEl.appendChild(d);
    _craftSlots.push({ el: d, gridIdx });
  }
}

export function updateInvUI(){
  const size = getCraftSize();
  craftGridEl.classList.toggle('size-2', size === 2);
  craftGridEl.classList.toggle('size-3', size === 3);

  if (size !== _craftLastSize) _rebuildCraftGrid(size);

  for (const slot of _craftSlots){
    const item = craftGrid[slot.gridIdx];
    const key = _slotKey(item);
    if (_craftCache[slot.gridIdx] === key) continue;
    _craftCache[slot.gridIdx] = key;
    _setSlotContent(slot.el, item, getIconSize(), false);
  }

  updateCraftResultLight();

  _ensureInvSlots();
  _renderInvSlotList(_invSlots);
  _renderInvSlotList(_hotInvSlots);

  const showCreative = (player.mode === 'creative' && creativeView);
  if (showCreative) _ensureCreativeSlots();
  /* ★ 创造视图只顶掉【背包区】，物品栏区（#invgrid）一直显示 */
  if (backpackSectionEl) backpackSectionEl.style.display = showCreative ? 'none' : '';
  creativeGridEl.style.display = showCreative ? 'grid' : 'none';
  if (creativeBarEl) creativeBarEl.style.display = showCreative ? 'flex' : 'none';

  /* ★ 箱子面板开着时，里面的背包镜像跟着刷新 */
  if (typeof isChestOpen === 'function' && isChestOpen()) _renderChestInv();

  updateHeldCursorView();
  updateCharPanel();
}

/* ============================================================
   背包 / 创造 切换
   ============================================================ */
let creativeView = false;
export function setCreativeView(on){
  creativeView = !!on;
  applyBagView();
}
export function isCreativeView(){ return creativeView; }

function applyBagView(){
  const canCreative = player.mode === 'creative';
  if (!canCreative) creativeView = false;
  /* ★ 创造模式：隐藏合成台（防止面板上下变长） */
  const _craftsec = document.querySelector('#inv .craftsec');
  if (_craftsec) _craftsec.style.display = creativeView ? 'none' : '';
  /* ★ 只切换背包区；物品栏区不受影响 */
  if (backpackSectionEl) backpackSectionEl.style.display = creativeView ? 'none' : '';
  creativeGridEl.style.display = creativeView ? 'grid' : 'none';
  if (creativeBarEl) creativeBarEl.style.display = creativeView ? 'flex' : 'none';
  if (creativeView) _ensureCreativeSlots();
  const btn = document.getElementById('btnCreative');
  if (btn){
    btn.classList.toggle('hidden', !canCreative);
    btn.classList.toggle('active', creativeView);
    /* 图标固定 SVG，不再覆盖 textContent */
  }
  /* bagTitle / bagTip 已删除，无需更新 */
}

export function refreshItemUI(){
  updateHotbar();
  if (invEl.classList.contains('show')) updateInvUI();
}

/* ============================================================
   血条 / 呼吸 / 饱食度 / Toast
   ============================================================ */
let _heartsKey = '';
export function updateHearts(health, maxHealth, mode){
  /* ★ 脏检查：值没变就直接返回（避免无意义的重建 DOM） */
  const _hk = mode + '|' + maxHealth + '|' + health;
  if (_hk === _heartsKey) return;
  _heartsKey = _hk;
  heartsEl.innerHTML = '';
  if (mode === 'creative'){ heartsEl.style.display = 'none'; return; }
  heartsEl.style.display = 'flex';
  const n = Math.ceil(maxHealth / 2);
  for (let i = 0; i < n; i++){
    const h = document.createElement('div');
    h.className = 'heart' + (i * 2 + 1 >= health ? ' off' : '');
    if (i * 2 + 1 >= health && i * 2 < health)
      h.style.background = 'linear-gradient(90deg,#e03131 50%,rgba(0,0,0,.42) 50%)';
    heartsEl.appendChild(h);
  }
}

let _breathKey = '';
export function updateBreath(breath, active, mode){
  const shown = (mode !== 'creative' && !!active);
  const pct = shown ? (breath * 100).toFixed(1) : '';
  /* ★ 脏检查：呼吸条进度是逐帧连续值，但"隐藏/警告"状态变化很少，
     没变化时连 style 写入都省掉，避免每帧触发样式重算 */
  const _bk = shown + '|' + pct + '|' + (shown && breath < 0.35);
  if (_bk === _breathKey) return;
  _breathKey = _bk;

  if (!shown){
    breathEl.classList.remove('show');
    return;
  }
  breathEl.classList.add('show');
  breathFillEl.style.width = pct + '%';
  breathEl.classList.toggle('warn', breath < 0.35);
}

const hungerEl = document.getElementById('hunger');

let _hungerKey = '';
export function updateHunger(hunger, maxHunger, mode){
  if (!hungerEl) return;
  /* ★ 这个函数每帧都会被主循环调用，而饱食度是离散变化的。
     以前每帧 innerHTML='' 再重建 N 个 div —— 每帧一次强制重排。
     现在值没变就整段跳过。 */
  const _hgk = mode + '|' + maxHunger + '|' + hunger;
  if (_hgk === _hungerKey) return;
  _hungerKey = _hgk;
  hungerEl.innerHTML = '';
  if (mode === 'creative'){ hungerEl.style.display = 'none'; return; }
  hungerEl.style.display = 'flex';
  const n = Math.ceil(maxHunger / 2);
  for (let i = 0; i < n; i++){
    const d = document.createElement('div');
    const full = (i * 2 + 1) < hunger;
    const half = !full && (i * 2) < hunger;
    d.className = 'drumstick' + (full ? '' : half ? ' half' : ' off');
    hungerEl.appendChild(d);
  }
}

/* ============================================================
   ★ 护甲值条
   ------------------------------------------------------------
   MC 把护甲值放在血条上方，但我们的血条上方已经被呼吸条占了，
   所以按需求放到【饱食度上方】（右下角），和左侧呼吸条镜像对称。

   ★ 真实上限 24 点：现在最强的是远古石全套 4+9+7+4 = 24，
     每 2 点一个盾牌，全显需要 12 个 —— 但 12 个盾牌约 214px 宽，
     窄屏上会和左侧 160px 的呼吸条撞在一起。
     所以显示按 MC 的惯例封顶 10 个图标（20 点），超出的按满格算；
     精确数值在角色面板「防御 N」和物品提示里都能看到。
   ★ 减伤规则和 player-core.js 保持一致：每点 4%，总上限 90%。
   ============================================================ */
const ARMOR_MAX = 24;        /* 真实上限（改了盔甲表要同步） */
const ARMOR_BAR_MAX = 20;    /* 护甲条显示上限：10 个盾牌 */
const ARMOR_BAR_ICONS = ARMOR_BAR_MAX / 2;

let _armorKey = '';
export function updateArmor(mode){
  if (!armorEl) return;
  const val = _armorDefense();
  /* ★ 脏检查：每帧都会调，值没变就整段跳过（和血条/饱食度同一套做法） */
  const key = mode + '|' + val;
  if (key === _armorKey) return;
  _armorKey = key;

  armorEl.innerHTML = '';
  if (mode === 'creative' || val <= 0){
    armorEl.style.display = 'none';
    return;
  }
  armorEl.style.display = 'flex';

  const shown = Math.min(val, ARMOR_BAR_MAX);
  for (let i = 0; i < ARMOR_BAR_ICONS; i++){
    const lo = i * 2;            /* 这个盾牌覆盖的两点：lo+1、lo+2 */
    const s = document.createElement('div');
    let cls = 'shield';
    if (shown >= lo + 2) cls += '';          /* 满 */
    else if (shown > lo) cls += ' half';     /* 半 */
    else cls += ' off';                      /* 空 */
    s.className = cls;
    armorEl.appendChild(s);
  }
}

/* ============================================================
   准星方块提示
   ============================================================ */
const blockInfoEl = document.getElementById('blockinfo');

export function describeToolRequirement(blk){
  if (!blk || blk.id === 0) return '';
  if (blk.hardness >= 9999) return '无法破坏';
  if (!blk.tool) return '徒手可采';
  const toolName = {
    pickaxe: '镐', axe: '斧', shovel: '锹', hoe: '锄',
    sword: '剑', shears: '剪刀', bucket: '桶'
  }[blk.tool] || blk.tool;
  const tierName = ['', '木质', '石质', '铁质', '钻石'][blk.minTier] || '';
  if (blk.minTier > 0) return `需要 ${tierName}${toolName} 及以上`;
  return `用${toolName}更快`;
}

let _blockInfoKey = '';
export function updateBlockInfo(blk, canHarvest){
  if (!blockInfoEl) return;

  if (!blk || blk.id === 0){
    if (_blockInfoKey !== ''){
      _blockInfoKey = '';
      blockInfoEl.classList.remove('show');
    }
    return;
  }

  /* ★ 主循环每帧都调这个函数；以前每帧重写 innerHTML，
     等于每帧让浏览器重新解析 HTML + 重排。这里只在内容真变了才写。 */
  const req = describeToolRequirement(blk);
  const key = blk.id + '|' + (canHarvest === false ? '0' : '1') + '|' + (req || '');
  if (key === _blockInfoKey) return;
  _blockInfoKey = key;

  blockInfoEl.classList.add('show');
  blockInfoEl.innerHTML =
    `<span class="bi-name">${blk.label}</span>` +
    (req ? `<span class="bi-req${canHarvest === false ? ' bad' : ''}">${req}</span>` : '');
}

let toastTimer = null;
export function toast(msg){
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 1500);
}

/* ============================================================
   背包开关
   ============================================================ */
/* ============================================================
   角色面板（背包左侧）
   ------------------------------------------------------------
   · 3D 预览里角色头/眼珠跟随鼠标
   · 拖盔甲到身体对应部位穿上；点击已穿部位脱下/替换
   ============================================================ */
const charStageEl = document.getElementById('charStage');

/* ★ 角色面板四个盔甲位也挂提示：显示当前装备的那件
   （没穿时 getBlk 返回 null，面板自动不弹）。 */
if (charStageEl){
  charStageEl.querySelectorAll('.armor-zone').forEach(zone => {
    const slotKey = zone.dataset.slot;
    attachItemTip(zone, () => {
      const it = player.armor && player.armor[slotKey];
      return (it && BLOCKS[it.id]) ? BLOCKS[it.id] : null;
    });
  });
}
const charCanvasEl = document.getElementById('charCanvas');
const charDefEl = document.getElementById('charDef');

const ARMOR_NAMES = { head: '头盔', chest: '胸甲', legs: '护腿', feet: '靴子' };

let _charBound = false;
let _armorDragFrom = -1;
let _armorDragMoved = false;
let _armorDragXY = null;

function _armorDefense(){
  let d = 0;
  for (const k in player.armor){
    const it = player.armor[k];
    const b = it && BLOCKS[it.id];
    if (b && b.defense) d += b.defense;
  }
  return d;
}

export function updateCharPanel(){
  if (!invEl.classList.contains('show')) return;
  initCharPreview(charCanvasEl);
  resizeCharPreview(charCanvasEl.clientWidth, charCanvasEl.clientHeight);
  if (charDefEl) charDefEl.textContent = `防御 ${_armorDefense()}`;
}

/* 手上拿着盔甲 → 穿到对应部位；原来那件回到手上 */
function _equipArmor(slotKey){
  if (!heldItem){ toast('先把盔甲拿在手里'); return; }
  const b = BLOCKS[heldItem.id];
  if (!b || !b.armorSlot){ toast('这不是盔甲'); return; }
  if (b.armorSlot !== slotKey){
    toast(`这件要穿在${ARMOR_NAMES[b.armorSlot]}上`);
    return;
  }
  const prev = player.armor[slotKey];
  player.armor[slotKey] = { id: heldItem.id, count: 1 };
  heldItem = prev || null;
  notifyInventory();
  updateInvUI();
  playSFX('click');
}

function _unequipArmor(slotKey){
  const cur = player.armor[slotKey];
  if (!cur) return;
  if (!addItem(cur.id, 1)){ toast('背包已满'); return; }
  player.armor[slotKey] = null;
  notifyInventory();
  updateInvUI();
  playSFX('click');
}

function _bindCharPanel(){
  if (_charBound || !charStageEl) return;
  _charBound = true;

  /* 头部跟随鼠标（整个背包界面内都生效） */
  document.addEventListener('pointermove', e => {
    if (!invEl.classList.contains('show')) return;
    const r = charStageEl.getBoundingClientRect();
    const nx = ((e.clientX - r.left) / r.width) * 2 - 1;
    const ny = ((e.clientY - r.top) / r.height) * 2 - 1;
    setCharLook(nx, -ny);

    if (_armorDragFrom >= 0){
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const zone = el && el.closest ? el.closest('.armor-zone') : null;
      document.querySelectorAll('.armor-zone').forEach(z => z.classList.toggle('drop', z === zone));
    }
  });

  charStageEl.querySelectorAll('.armor-zone').forEach(zone => {
    zone.addEventListener('click', () => {
      if (performance.now() < suppressClickUntil) return;
      if (heldItem) _equipArmor(zone.dataset.slot);
      else _unequipArmor(zone.dataset.slot);
    });
  });

  /* 桌面端拖动背包物品到角色身上 */
  document.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;
    if (!invEl.classList.contains('show')) return;
    const el = e.target.closest && e.target.closest('.islot');
    if (!el || !invEl.contains(el)) return;
    const idx = _invIdxOfSlotEl(el);
    if (idx < 0) return;
    _armorDragFrom = idx;
    _armorDragMoved = false;
    _armorDragXY = { x: e.clientX, y: e.clientY };
  }, true);

  document.addEventListener('pointermove', e => {
    if (_armorDragFrom < 0 || !_armorDragXY) return;
    if (!_armorDragMoved &&
        Math.hypot(e.clientX - _armorDragXY.x, e.clientY - _armorDragXY.y) > 8){
      _armorDragMoved = true;
      if (!heldItem){
        const it = inventory[_armorDragFrom];
        if (it){
          heldItem = it;
          inventory[_armorDragFrom] = null;
          notifyInventory();
          updateHeldCursorView();
        }
      }
    }
  }, true);

  document.addEventListener('pointerup', e => {
    if (_armorDragFrom < 0) return;
    const moved = _armorDragMoved;
    _armorDragFrom = -1;
    _armorDragMoved = false;
    _armorDragXY = null;
    document.querySelectorAll('.armor-zone').forEach(z => z.classList.remove('drop'));
    if (!moved) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const zone = el && el.closest ? el.closest('.armor-zone') : null;
    if (zone){
      suppressClickUntil = performance.now() + 350;
      _equipArmor(zone.dataset.slot);
    }
  }, true);
}

_bindCharPanel();

export function toggleInv(source){
  if (invEl.classList.contains('show')){
    if (!isCraftEmpty()){
      dumpCraftTo(item => {
        const ok = addItem(item.id, item.count);
        if (!ok) toast('背包已满，物品丢失');
      });
    }
    if (heldItem){
      addItem(heldItem.id, heldItem.count);
      heldItem = null;
    }
    invEl.classList.remove('show');
    setCharPreviewActive(false);
    hideItemTip();
    updateHeldCursorView();
    return;
  }
  setCraftSize(source === 'crafting_table' ? 3 : 2);
  heldItem = null;
  creativeView = false;
  /* ★ 打开背包时收起暂停/设置，避免与背包重叠 */
  const pauseEl = document.getElementById('pause');
  if (pauseEl) pauseEl.classList.remove('show');
  const settingsEl = document.getElementById('settings');
  if (settingsEl) settingsEl.classList.remove('show');
  invEl.classList.add('show');
  setCharPreviewActive(true);
  applyBagView();
  updateInvUI();
  
  const ext = document.getElementById('mod-inv-ext');
  if (ext) { ext.innerHTML = ''; emit('ui.inventory.open', ext); }
}
export function closeInv(){
  if (!invEl.classList.contains('show')) return;
  if (!isCraftEmpty()){
    dumpCraftTo(item => {
      const ok = addItem(item.id, item.count);
      if (!ok) toast('背包已满，物品丢失');
    });
  }
  /* ★ 手里拿着的东西必须退回背包：原来直接 heldItem=null，
     用右上角 × 关背包时手上那堆东西就凭空消失了 */
  if (heldItem){
    const ok = addItem(heldItem.id, heldItem.count);
    if (!ok) toast('背包已满，物品丢失');
    heldItem = null;
  }
  invEl.classList.remove('show');
  setCharPreviewActive(false);
  creativeView = false;
  hideItemTip();
  updateHeldCursorView();
  updateHotbar();
}
export function isInvOpen(){ return invEl.classList.contains('show'); }
export function isSettingsOpen(){ return document.getElementById('settings').classList.contains('show'); }
export function isPauseOpen(){ return document.getElementById('pause').classList.contains('show'); }

/* ============================================================
   熔炉界面
   ------------------------------------------------------------
   ★ 之前熔炉只有原料/燃料/产物三个格子，完全没有背包，
     只能靠"先选中快捷栏某一格再点槽"来塞东西 —— 一旦背包面板
     、箱子面板都没开着，玩家就既放不进去也拿不出来。
     现在熔炉面板里直接带【背包 27 格 + 物品栏 9 格】，
     拿起/放下沿用同一套 heldItem 浮动手持模型。
   ============================================================ */
const furnaceEl = document.getElementById('furnace');
const furnaceInvEl = document.getElementById('furnaceInvGrid');
const furnaceHotEl = document.getElementById('furnaceHotGrid');
let furnacePos = null;

let _furnaceInvSlots = null;
let _furnaceHotSlots = null;
let _furnaceInvCache = new Array(INV_SIZE).fill('__init__');

export function isFurnaceOpen(){
  return !!(furnaceEl && furnaceEl.classList.contains('show'));
}

function _ensureFurnaceInvSlots(){
  if (_furnaceInvSlots) return;
  _furnaceInvSlots = [];
  _furnaceHotSlots = [];

  if (furnaceInvEl){
    furnaceInvEl.innerHTML = '';
    for (let i = HOT_SLOTS; i < INV_SIZE; i++){
      const d = _makeMirrorSlot(i);
      furnaceInvEl.appendChild(d);
      _furnaceInvSlots.push(d);
    }
  }
  if (furnaceHotEl){
    furnaceHotEl.innerHTML = '';
    for (let i = 0; i < HOT_SLOTS; i++){
      const d = _makeMirrorSlot(i);
      furnaceHotEl.appendChild(d);
      _furnaceHotSlots.push(d);
    }
  }
}

function _renderFurnaceInv(){
  if (!isFurnaceOpen()) return;
  _ensureFurnaceInvSlots();
  const iconSize = getIconSize();

  for (let n = 0; n < _furnaceInvSlots.length; n++){
    const idx = HOT_SLOTS + n;
    const item = inventory[idx];
    const key = _slotKey(item);
    if (_furnaceInvCache[idx] === key) continue;
    _furnaceInvCache[idx] = key;
    _setSlotContent(_furnaceInvSlots[n], item, iconSize, false);
  }
  for (let idx = 0; idx < _furnaceHotSlots.length; idx++){
    const item = inventory[idx];
    const key = _slotKey(item);
    if (_furnaceInvCache[idx] === key) continue;
    _furnaceInvCache[idx] = key;
    _setSlotContent(_furnaceHotSlots[idx], item, iconSize, false);
  }
  updateHeldCursorView();
}

export function renderFurnace(){
  if (!furnaceEl || !furnacePos) return;
  const st = getFurnace(furnacePos.x, furnacePos.y, furnacePos.z);

  const put = (id, item) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = '';
    if (item && item.count > 0 && item.id != null){
      setSlotIcon(el, item.id, getIconSize());
      if (item.count > 1){
        const c = document.createElement('span');
        c.className = 'count';
        c.textContent = item.count;
        el.appendChild(c);
      }
      el.classList.add('hasresult');
    } else {
      setSlotIcon(el, 0, getIconSize());
      el.classList.remove('hasresult');
    }
  };
  put('furnaceInput', st.input);
  put('furnaceFuel', st.fuel);
  put('furnaceOutput', st.output);

  const burn = document.getElementById('furnaceBurn');
  const cook = document.getElementById('furnaceCook');
  if (burn) burn.style.height = st.burnTotal > 0
    ? Math.max(0, Math.min(1, st.burnTime / st.burnTotal)) * 100 + '%' : '0%';
  /* 燃烧时中间的火苗区整体发出橙红色光 */
  const flameEl = burn && burn.closest ? burn.closest('.furnace-flame') : null;
  if (flameEl) flameEl.classList.toggle('is-burning', st.burnTime > 0);
  if (cook) cook.style.width = st.cookTotal > 0
    ? Math.max(0, Math.min(1, st.cookTime / st.cookTotal)) * 100 + '%' : '0%';

  _renderFurnaceInv();
}

export function openFurnace(x, y, z){
  furnacePos = { x, y, z };
  if (!furnaceEl) return;
  _furnaceInvCache = new Array(INV_SIZE).fill('__init__');
  furnaceEl.classList.add('show');
  _ensureFurnaceInvSlots();
  renderFurnace();

  const ext = document.getElementById('mod-furnace-ext');
  if (ext) { ext.innerHTML = ''; emit('ui.furnace.open', ext, x, y, z); }
}

export function closeFurnace(){
  if (!furnaceEl || !isFurnaceOpen()) return;

  /* ★ 手上拿着的先退回背包，别让关面板变成销毁物品 */
  if (heldItem){
    const ok = addItem(heldItem.id, heldItem.count);
    if (!ok) toast('背包已满，物品丢失');
    heldItem = null;
  }

  if (furnacePos){
    const st = getFurnace(furnacePos.x, furnacePos.y, furnacePos.z);
    for (const key of ['input', 'fuel', 'output']){
      const s = st[key];
      if (s && s.count > 0 && s.id != null){
        if (!addItem(s.id, s.count)) toast('背包已满，熔炉里的物品丢失');
        st[key] = null;
      }
    }
  }
  furnaceEl.classList.remove('show');
  furnacePos = null;
  _furnaceInvCache = new Array(INV_SIZE).fill('__init__');
  updateHeldCursorView();
}

function onFurnaceSlotClick(which, e){
  if (!furnacePos) return;
  if (performance.now() < suppressClickUntil) return;
  _syncPointerFromEvent(e);
  const st = getFurnace(furnacePos.x, furnacePos.y, furnacePos.z);
  const MAX = FURNACE_STACK_MAX || 64;

  const done = () => {
    renderFurnace();
    updateHeldCursorView();
  };

  /* ---------- 产物槽：只能拿，不能放 ---------- */
  if (which === 'output'){
    if (!st.output) return;

    if (!heldItem){
      heldItem = st.output;
      st.output = null;
      playSFX('pop');
      done();
      return;
    }
    if (heldItem.id === st.output.id){
      const room = MAX - heldItem.count;
      if (room > 0){
        const move = Math.min(room, st.output.count);
        heldItem.count += move;
        st.output.count -= move;
        if (st.output.count <= 0) st.output = null;
        playSFX('pop');
        done();
        return;
      }
    }
    /* 手上有别的/已满 → 直接塞进背包 */
    if (addItem(st.output.id, st.output.count)){
      st.output = null;
      playSFX('pop');
    } else {
      toast('背包已满，先把产物拿在手上');
    }
    done();
    return;
  }

  /* ---------- 原料 / 燃料槽：拿起 / 放下 ---------- */
  const cur = st[which] || null;

  if (!heldItem){
    if (!cur) return;
    heldItem = cur;
    st[which] = null;
    playSFX('click');
    done();
    return;
  }

  /* 校验能不能放进这个槽 */
  if (which === 'input' && !getSmeltResult(heldItem.id)){
    toast('这个物品烧不了');
    return;
  }
  if (which === 'fuel' && !isFuel(heldItem.id)){
    toast('这个物品不能当燃料');
    return;
  }

  if (!cur){
    /* 空槽：整堆放进去（和箱子/背包的手感一致） */
    const n = Math.min(heldItem.count, MAX);
    st[which] = { id: heldItem.id, count: n };
    heldItem.count -= n;
    if (heldItem.count <= 0) heldItem = null;
  } else if (cur.id === heldItem.id){
    const room = MAX - cur.count;
    if (room <= 0){ toast('这个格子满了'); return; }
    const n = Math.min(room, heldItem.count);
    cur.count += n;
    heldItem.count -= n;
    if (heldItem.count <= 0) heldItem = null;
  } else {
    /* 换一种物品：把槽里的拿到手上，手里的放进去 */
    if (which === 'input' && !getSmeltResult(cur.id)) { /* 槽里本来就不该有这种 */ }
    st[which] = { id: heldItem.id, count: Math.min(heldItem.count, MAX) };
    heldItem = cur;
  }

  playSFX('click');
  done();
}

/* ============================================================
   箱子界面
   ------------------------------------------------------------
   · 27 格箱子 + 36 格背包（镜像，和背包面板共用 inventory 数组）
   · 拿起/放下沿用背包的 heldItem 浮动手持模型
   · 打开时读盘、关闭时落盘（数据逻辑都在 items/chest.js）
   ============================================================ */
const chestEl      = document.getElementById('chest');
const chestGridEl  = document.getElementById('chestGrid');
const chestInvEl   = document.getElementById('chestInvGrid');     /* 背包 27 格 */
const chestHotEl   = document.getElementById('chestHotGrid');     /* 物品栏 9 格 */

let chestPos = null;      /* { x, y, z } */
let chestRec = null;      /* items/chest.js 的记录 */
let chestLoading = false;

let _chestSlots = null;
/* ★ 不要在这里用 CHEST_SIZE：ui.js 与 items/items-core.js 是循环依赖，
   本文件可能先求值，此时 imported 的 CHEST_SIZE 还在 TDZ 里，
   一旦报错整个模块图都会崩，表现就是「开始界面按钮全点不动」。
   改为长度已知为空数组，首次刷新时再按真实大小填充。 */
let _chestCache = [];
let _chestInvSlots = null;
let _chestHotSlots = null;
let _chestInvCache = [];

export function isChestOpen(){
  return !!(chestEl && chestEl.classList.contains('show'));
}

/** 当前打开的是不是这个坐标的箱子（破坏方块前用来先关面板） */
export function isChestOpenAt(x, y, z){
  if (!isChestOpen() || !chestPos) return false;
  return chestPos.x === x && chestPos.y === y && chestPos.z === z;
}

/** 当前打开的箱子坐标（没有就 null） */
export function getOpenChestPos(){
  return chestPos ? { x: chestPos.x, y: chestPos.y, z: chestPos.z } : null;
}

/* 惰性填充缓存数组（此时 CHEST_SIZE / INV_SIZE 一定已初始化） */
function _ensureChestCaches(){
  if (_chestCache.length !== CHEST_SIZE) _chestCache = new Array(CHEST_SIZE).fill('__init__');
  if (_chestInvCache.length !== INV_SIZE) _chestInvCache = new Array(INV_SIZE).fill('__init__');
}

function _ensureChestSlots(){
  if (_chestSlots) return;
  _chestSlots = [];
  chestGridEl.innerHTML = '';
  for (let i = 0; i < CHEST_SIZE; i++){
    const d = document.createElement('div');
    d.className = 'islot';
    d.addEventListener('click', e => onChestSlotClick(i, e));
    attachItemTip(d, () => {
      const it = chestRec && chestRec.slots ? chestRec.slots[i] : null;
      return (it && BLOCKS[it.id]) ? BLOCKS[it.id] : null;
    });
    chestGridEl.appendChild(d);
    _chestSlots.push(d);
  }
}

function _makeMirrorSlot(invIdx){
  const d = document.createElement('div');
  d.className = 'islot';
  d.addEventListener('click', e => onInvSlotClick(invIdx, e));
  _slotIdxByEl.set(d, invIdx);
  return d;
}

function _ensureChestInvSlots(){
  if (_chestInvSlots) return;
  _chestInvSlots = [];
  _chestHotSlots = [];

  /* ★ 和背包面板一致：上半是背包 27 格，下半是物品栏 9 格 */
  chestInvEl.innerHTML = '';
  for (let i = HOT_SLOTS; i < INV_SIZE; i++){
    const d = _makeMirrorSlot(i);
    chestInvEl.appendChild(d);
    _chestInvSlots.push(d);
  }

  if (chestHotEl){
    chestHotEl.innerHTML = '';
    for (let i = 0; i < HOT_SLOTS; i++){
      const d = _makeMirrorSlot(i);
      chestHotEl.appendChild(d);
      _chestHotSlots.push(d);
    }
  }
}

/* 背包镜像格的渲染（只在插槽内容真变了时才写 DOM） */
function _renderChestInv(){
  if (!isChestOpen()) return;
  _ensureChestInvSlots();
  const iconSize = getIconSize();
  for (let n = 0; n < _chestInvSlots.length; n++){
    const idx = HOT_SLOTS + n;
    const item = inventory[idx];
    const key = _slotKey(item);
    if (_chestInvCache[idx] === key) continue;
    _chestInvCache[idx] = key;
    _setSlotContent(_chestInvSlots[n], item, iconSize, false);
  }
  if (_chestHotSlots){
    for (let idx = 0; idx < _chestHotSlots.length; idx++){
      const item = inventory[idx];
      const key = _slotKey(item);
      if (_chestInvCache[idx] === key) continue;
      _chestInvCache[idx] = key;
      _setSlotContent(_chestHotSlots[idx], item, iconSize, false);
    }
  }
  updateHeldCursorView();
}

export function renderChest(){
  if (!isChestOpen()) return;
  _ensureChestCaches();
  _ensureChestSlots();
  const iconSize = getIconSize();

  if (chestLoading || !chestRec || !chestRec.loaded){
    /* 读盘期间：先清空显示，避免把上一箱的东西当成这一箱的 */
    for (let i = 0; i < CHEST_SIZE; i++){
      if (_chestCache[i] === '~loading~') continue;
      _chestCache[i] = '~loading~';
      _setSlotContent(_chestSlots[i], null, iconSize, false);
    }
  } else {
    for (let i = 0; i < CHEST_SIZE; i++){
      const item = chestRec.slots[i];
      const key = _slotKey(item);
      if (_chestCache[i] === key) continue;
      _chestCache[i] = key;
      _setSlotContent(_chestSlots[i], item, iconSize, false);
    }
  }
  _renderChestInv();
  updateHeldCursorView();
}

/**
 * 打开箱子（异步：先显示面板，再等文件读完刷新）
 */
export async function openChest(x, y, z){
  if (!chestEl) return;
  if (isInvOpen()) toggleInv();
  if (isChestOpen()){
    if (chestPos && chestPos.x === x && chestPos.y === y && chestPos.z === z) return;
    closeChest();
  }

  chestPos = { x, y, z };
  chestRec = getChest(x, y, z);
  chestLoading = !chestRec.loaded;
  _chestCache = new Array(CHEST_SIZE).fill('__init__');
  _chestInvCache = new Array(INV_SIZE).fill('__init__');

  chestEl.classList.add('show');
  _ensureChestSlots();
  _ensureChestInvSlots();
  
  const ext = document.getElementById('mod-chest-ext');
  if (ext) { ext.innerHTML = ''; emit('ui.chest.open', ext, x, y, z); }
  renderChest();
  playSFX('click');

  const rec = await loadChest(x, y, z);
  /* 等待期间玩家可能已经关掉或换了箱子 */
  if (!isChestOpen() || !chestPos ||
      chestPos.x !== x || chestPos.y !== y || chestPos.z !== z) return;
  chestRec = rec;
  chestLoading = false;
  renderChest();
  /* ★ 放在读完之后才发：mod 收到 chest.open 时内容已经是完整的 */
  emitChestOpened(x, y, z);
}

export function closeChest(){
  if (!chestEl || !isChestOpen()) return;

  /* 手上的东西退回背包，避免关闭时丢失 */
  if (heldItem){
    const ok = addItem(heldItem.id, heldItem.count);
    if (!ok) toast('背包已满，物品丢失');
    heldItem = null;
    updateHeldCursorView();
  }

  const pos = chestPos;
  if (pos) saveChest(pos.x, pos.y, pos.z);   /* 内部只在脏的时候真写 */

  chestEl.classList.remove('show');
  chestPos = null;
  chestRec = null;
  chestLoading = false;
  _chestCache = new Array(CHEST_SIZE).fill('__init__');
  _chestInvCache = new Array(INV_SIZE).fill('__init__');

  if (pos) emitChestClosed(pos.x, pos.y, pos.z);
}

function onChestSlotClick(idx, e){
  if (performance.now() < suppressClickUntil) return;
  if (!chestRec || !chestRec.loaded) return;
  _syncPointerFromEvent(e);

  const cur = chestRec.slots[idx];
  if (heldItem === null){
    if (!cur) return;
    heldItem = cur;
    chestRec.slots[idx] = null;
  } else {
    const heldBlk = BLOCKS[heldItem.id];
    const maxStack = (heldBlk && heldBlk.maxStack) || CHEST_STACK_MAX;
    if (cur && cur.id === heldItem.id && cur.count < maxStack && maxStack > 1){
      const add = Math.min(maxStack - cur.count, heldItem.count);
      cur.count += add;
      heldItem.count -= add;
      if (heldItem.count <= 0) heldItem = null;
    } else {
      chestRec.slots[idx] = heldItem;
      heldItem = cur || null;
    }
  }
  if (chestPos) touchChest(chestPos.x, chestPos.y, chestPos.z);
  playSFX('click');
  /* ★ renderChest 里会刷新鬼手；再单独调一次，保证任何分支下都同步 */
  renderChest();
  _renderChestInv();
  updateHeldCursorView();
}

/* ============================================================
   进食
   ============================================================ */
export function tryEat(){
  const slot = inventory[curSlot];
  if (!slot || slot.count <= 0) return false;
  const blk = BLOCKS[slot.id];
  if (!blk || !blk.food) return false;
  if (player.mode === 'survival' && player.hunger >= player.maxHunger) return false;

  player.eatFood(blk.food, blk.saturation);
  takeFromSlot(curSlot, 1);
  toast(`吃了 ${blk.label}`);
  playSFX('eat');
  updateHunger(player.hunger, player.maxHunger, player.mode);

  /* ★ M1：进食事件 */
  emit('player.eat', slot.id, blk.label);

  return true;
}

/* ============================================================
   初始化
   ============================================================ */
export function initUI(onModeToggle){
  // ★ 给原版 UI 注入 mod 扩展容器
  const injectSlot = (parentEl, slotId) => {
    if (!parentEl || document.getElementById(slotId)) return;
    const div = document.createElement('div');
    div.id = slotId;
    div.className = 'mod-ui-ext';
    div.style.cssText = 'width:100%; margin-top:12px; display:flex; flex-direction:column; gap:8px;';
    parentEl.appendChild(div);
  };
  injectSlot(document.getElementById('inv'), 'mod-inv-ext');
  injectSlot(chestEl, 'mod-chest-ext');
  injectSlot(furnaceEl, 'mod-furnace-ext');

  document.getElementById('btnInv').addEventListener('click', () => toggleInv());

  /* ★ 移动端右上角视角按钮（桌面端用 F5） */
  const btnViewEl = document.getElementById('btnView');
  if (btnViewEl){
    if (!IS_TOUCH) btnViewEl.style.display = 'none';
    btnViewEl.addEventListener('click', () => emit('view.cycle'));
  }
  invEl.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });

  /* ★ 关闭按钮：面板挡住顶部「背包」按钮时也能关掉 */
  for (const id of ['btnInvClose']){
    const b = document.getElementById(id);
    if (b) b.addEventListener('click', e => { e.stopPropagation(); closeInv(); });
  }

  /* ★ 统一的手持物品坐标跟踪（鼠标 / 触摸 / 指针都覆盖），
     否则手机上鬼手会停在错的地方 */
  const trackPointer = e => _syncPointerFromEvent(e);
  document.addEventListener('pointerdown', trackPointer, { passive: true, capture: true });
  document.addEventListener('pointermove', trackPointer, { passive: true, capture: true });
  document.addEventListener('touchstart', trackPointer, { passive: true, capture: true });
  document.addEventListener('touchmove', trackPointer, { passive: true, capture: true });


  /* ★ 销毁按钮：点击销毁手中物品 */
  const btnDestroy = document.getElementById('btnDestroy');
  if (btnDestroy){
    btnDestroy.addEventListener('click', () => {
      if (!heldItem) return;
      const n = heldItem.count;
      heldItem = null;
      updateHeldCursorView();
      updateInvUI();
      playSFX('click');
      toast(`已销毁 ${n} 个物品`);
    });
  }

  const btnCreative = document.getElementById('btnCreative');
  if (btnCreative){
    btnCreative.addEventListener('click', () => {
      if (player.mode !== 'creative') return;
      creativeView = !creativeView;
      if (heldItem){ addItem(heldItem.id, heldItem.count); heldItem = null; }
      applyBagView();
      updateInvUI();
      updateHeldCursorView();
      playSFX('click');
    });
  }

  if (furnaceEl){
    furnaceEl.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });
    for (const [id, which] of [['furnaceInput','input'],['furnaceFuel','fuel'],['furnaceOutput','output']]){
      const el = document.getElementById(id);
      if (el) el.addEventListener('click', e => { e.stopPropagation(); onFurnaceSlotClick(which, e); });
    }
    const fc = document.getElementById('furnaceClose');
    if (fc) fc.addEventListener('click', () => closeFurnace());
    const fx = document.getElementById('btnFurnaceCloseX');
    if (fx) fx.addEventListener('click', e => { e.stopPropagation(); closeFurnace(); });
    furnaceEl.addEventListener('click', e => { if (e.target === furnaceEl) closeFurnace(); });
    /* 背包内容变了（拾取、熔炉产物进包）→ 面板里的背包镜像跟着刷 */
    onInventoryChange(() => { if (isFurnaceOpen()) _renderFurnaceInv(); });
  }

  if (chestEl){
    chestEl.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });
    const cc = document.getElementById('chestClose');
    if (cc) cc.addEventListener('click', () => closeChest());
    const cx = document.getElementById('btnChestCloseX');
    if (cx) cx.addEventListener('click', e => { e.stopPropagation(); closeChest(); });
    chestEl.addEventListener('click', e => { if (e.target === chestEl) closeChest(); });
    /* 背包内容被别处改动（捡到东西等）时同步镜像格 */
    onInventoryChange(() => { if (isChestOpen()) _renderChestInv(); });
  }

  craftResultEl.addEventListener('click', onCraftResultClick);

  craftGridEl.addEventListener('touchstart', onCraftTouchStart, { passive: true });
  craftGridEl.addEventListener('touchmove', onCraftTouchMove, { passive: false });
  craftGridEl.addEventListener('touchend', onCraftTouchEnd);
  craftGridEl.addEventListener('touchcancel', onCraftTouchEnd);

  invEl.addEventListener('touchstart', onInvDragStart, { passive: true });
  invEl.addEventListener('touchmove', onInvDragMove, { passive: false });
  invEl.addEventListener('touchend', onInvDragEnd);
  invEl.addEventListener('touchcancel', onInvDragEnd);

  document.addEventListener('mousemove', e => {
    pointerX = e.clientX;
    pointerY = e.clientY;
    if (heldItem) updateHeldCursorView();
  });

  invEl.addEventListener('click', onPanelBlankClick);

  onInventoryChange(() => {
    refreshItemUI();
  });
  /* ★ mod 运行时注册了新方块 → 创造面板的分类集合要重算 */
  onBlockRegistered(() => { _creativeDirty = true; });
  onCraftChange(updateInvUI);
  updateHotbar();

  window.__refreshUI = () => {
    updateHotbar();
    if (invEl.classList.contains('show')) updateInvUI();
    updateHeldCursorView();
  };

  /* ============================================================
     ★ M5：暂停菜单加 "Mod 状态" 按钮
     ============================================================ */
  (function initModStatusButton(){
    const pauseBox = document.querySelector('.pause-box');
    if (!pauseBox) return;

    if (pauseBox.querySelector('#btnModStatus')) return;

    const btn = document.createElement('button');
    btn.className = 'mb-sub';
    btn.id = 'btnModStatus';
    btn.textContent = 'Mod 状态';

    const anchor = pauseBox.querySelector('#btnUploadLog');
    if (anchor) pauseBox.insertBefore(btn, anchor);
    else pauseBox.appendChild(btn);

    btn.addEventListener('click', () => {
      import('./mod-panel/index.js')
        .then(m => m.openModStatus())
        .catch(e => console.error('[ui] 打开 Mod 状态面板失败:', e));
    });
  })();

  /* 每次打开暂停菜单时，检查有没有加载失败的 mod 并标红点 */
  (function watchPauseForFailBadge(){
    const pauseEl = document.getElementById('pause');
    const btn = document.getElementById('btnModStatus');
    if (!pauseEl || !btn) return;

    const observer = new MutationObserver(() => {
      if (!pauseEl.classList.contains('show')) return;
      import('./../save/save-core.js').then(L => {
        const r = L.getLastLoadResult();
        const oldDot = btn.querySelector('.ms-badge-dot');
        if (r.failed.length > 0){
          if (!oldDot){
            const dot = document.createElement('span');
            dot.className = 'ms-badge-dot';
            btn.appendChild(dot);
          }
        } else if (oldDot){
          oldDot.remove();
        }
      }).catch(() => {});
    });
    observer.observe(pauseEl, { attributes: true, attributeFilter: ['class'] });
  })();
}

export function setCurSlot(i){ curSlot = i; updateHotbar(); }