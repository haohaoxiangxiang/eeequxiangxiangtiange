# 深入世界 VertiWorld Mod 开发 · 卷二：内容注册与玩法

> 适用宿主 **API v4**。本卷讲"怎么往游戏里加东西"：方块、掉落、配方、群系、
> 生成器、维度、实体、音效、移动/液体/状态，以及世界类型、实体分级、存档和示例。
>
> | 卷 | 内容 |
> |---|---|
> | [卷一](mod开发1.md) | 快速开始、manifest、生命周期、`G` 总览、世界读写、事件、Hook、输入独占、性能、限制 |
> | **卷二（本文）** | 内容注册、世界类型、创造面板、实体分级、存档、示例、API 速查 |
> | [卷三](mod开发3.md) | 版本兼容变化、扩展 API（B 类）、三份反馈对照、整合包与地图、Coremod |

## 本卷目录

1. [运行时注册](#1-运行时注册)
2. [世界类型（mod 提供创建界面里的类型）](#2-世界类型mod-提供创建界面里的类型)
3. [创造面板：分类与分页](#3-创造面板分类与分页)
4. [实体分类与距离分级](#4-实体分类与距离分级)
5. [存档与 mod 存储](#5-存档与-mod-存储)
6. [示例合集](#6-示例合集)
7. [附录：API 速查](#7-附录api-速查)

---

## 1. 运行时注册

### 1.1 方块 `registerBlock`

```js
G.registerBlock(name, label, opts, drawFn?) → block
```

> 重名或 atlas 满会**抛异常**（该 mod 加载失败），不是返回 `null`。
> 给了 `drawFn` 时，它会覆盖 `opts.tex`，六个面统一使用这张程序化贴图。

`drawFn(ctx, size)`：在 atlas 格子里画你的贴图。`size` 是纹素边长（当前 16），**不要硬编码**。

```js
G.registerBlock('magic_ore', '魔法矿石',
  { hardness: 3, tool: 'pickaxe', minTier: 2, emissive: 1 },
  (ctx, S) => {
    ctx.fillStyle = '#444'; ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = '#a0f';
    for (let i = 0; i < 10; i++)
      ctx.fillRect(Math.random()*S|0, Math.random()*S|0, 3, 3);
  });
```

**返回**：`{ id, name, label, tiles, source, ... }`。

#### opts 字段

| 字段 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `tex` | object | — | `{ all }` 或 `{ top, side, bottom }`；给了 `drawFn` 会自动处理 |
| `icon` | string | null | **物品图标用的 atlas 贴图名**（背包/快捷栏/掉落物）。不填就取顶面 `tiles[2]` |
| `iconDraw` | function | — | `iconDraw(ctx, S)` 程序化画图标，优先级最高（见 1.3） |
| `category` | string | 自动 | 创造面板分类 id（内置：`building` `nature` `material` `functional` `tools` `food` `misc`，也可自己注册） |
| `hidden` | bool | false | 不在创造面板里出现 |
| `source` | string | `'mod'` | 来源标记，mod 方块默认 `'mod'`，内置是 `'builtin'`（见卷三 2.8） |
| `noTex` | bool | false | 无贴图（如空气） |
| `invisible` | bool | false | 方块本体不渲染，但碰撞/数据/交互/掉落保留（见 1.3） |
| `hardness` | number | 1 | 挖掘时间 |
| `tool` | string | null | `'pickaxe'` / `'axe'` / `'shovel'` / `'shears'` |
| `minTier` | number | 0 | 0=徒手 1=木 2=石 3=铁 4=钻石 |
| `requiresTool` | bool | false | 必须用工具才掉落 |
| `toolType` / `material` / `speed` / `tier` / `durability` | — | — | 方块本身是工具时用 |
| `maxStack` | number | 64 | 堆叠上限 |
| `isItem` | bool | false | true = 物品，不可放置 |
| `food` / `saturation` | number | 0 | 食物值 / 饱食度 |
| `fuel` | number | 0 | 燃料秒数 |
| `solid` | bool | true | 是否实心（碰撞） |
| `transparent` | bool | false | 半透明渲染 |
| `opaque` | bool | 同 solid | 是否完全遮蔽 |
| `occludes` | bool | 同 opaque | 是否遮挡相邻面 |
| `mergeSame` | bool | true | 贪心合并同类（优化） |
| `liquid` | bool | false | 液体 |
| `emissive` | number | 0 | 0/1 自发光（材质发光，不等于照亮周围） |
| `light` | number | 0 | 光照等级 0~15，**真正发亮照亮周围**（荧光石 15、火把 14） |
| `cross` | bool | false | 十字花草渲染 |
| `slab` | bool | false | 半砖 |
| `stair` / `stairDir` / `stairBase` | — | — | 阶梯 |
| `heightRatio` | number | 1 | 视觉高度比例（1/16 是花毯） |
| `model` | object | null | 非整方块模型：`{ boxes: [{ x0,y0,z0,x1,y1,z1, tex, alpha }] }`，坐标 0~16 |
| `isLeaves` / `leafColors` | — | — | 树叶渲染 |
| `tint` | `'grass'` / `'foliage'` | — | 参与群系染色 |
| `tag` | string | null | 分类标签（`'stone'` / `'log'` …） |
| `interactive` | string | null | 交互标记。内置生效：`furnace` `chest` `pedestal` `lever` `button` `door` `iron_door`；其他值只是元数据 |
| `placeable` | bool | true | 是否可放置 |
| `bucketType` | string | null | `'empty'` / `'water'` / `'lava'` / `'fish'` |
| `waterPlant` / `waterSurface` | bool | false | 水生植物 / 水面方块 |

#### atlas

全项目共享一张 atlas，尺寸由**服务器按所有 mod 的 `contents` 动态决定**：

| 档位 | 格数 | 显存 |
|---|---|---|
| 32×32 | 1024 | 1 MB |
| 64×64 | 4096 | 4 MB |
| 128×128 | 16384 | 16 MB |
| 256×256 | 65536 | 64 MB |

- 内置资源约占 **112 格**；每个 mod 方块消耗 **1~3 格**（顶/侧/底）
- 满了会在 `registerBlock` 抛错，mod 加载失败
- 查占用：`G.getAtlasUsage()` → `{ used, total, free, cols }`

注册后会**自动刷新 Worker 的方块表**；`G.give('magic_ore', 16)` 立即可用。

### 1.2 模型方块：面是透明的、里面放一个 3D 模型

常见做法：方块本身**不画立方体贴图**，只占一个位置，真正的视觉是 mod 用
`G.attachVisual()` 挂上去的 `THREE.Object3D`（机器、齿轮、显示器……）。

```js
// 1) 注册方块：不给面贴图，只给图标
G.registerBlock('steam_turbine', '蒸汽轮机', {
  noTex: true,              // 六个面使用占位空贴图
  solid: true, opaque: false,
  hardness: 2, tool: 'pickaxe',
  category: 'functional',
  iconDraw(ctx, S){         // ★ 图标必须单独画，否则背包里是空的
    ctx.fillStyle = '#556'; ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = '#8cf';
    ctx.fillRect(S*0.2, S*0.2, S*0.6, S*0.6);
  },
});

// 2) 放置时挂模型、拆掉时摘掉
G.on('block.place', (x, y, z, id) => {
  if (id !== G.B.steam_turbine.id) return;
  const mesh = new G.THREE.Mesh(
    new G.THREE.BoxGeometry(0.9, 0.9, 0.9),
    new G.THREE.MeshLambertMaterial({ color: 0x8899aa }));
  G.attachVisual(x, y, z, mesh);
});

G.on('block.break', (x, y, z, id) => {
  if (id !== G.B.steam_turbine.id) return;
  G.detachVisual(x, y, z);
});
```

#### 图标优先级（最容易踩的坑）

| 情况 | 图标会显示成 |
|---|---|
| 给了 `iconDraw` | ✔ 用这个函数画的图，正常显示 |
| 给了 `icon: 'xxx'` | ✔ 用这张贴图 |
| 没给，面贴图正常 | ✔ 用**顶面**（`tiles[2]`） |
| 没给，面是透明/空的 | ✘ **背包、快捷栏、掉落物全是空白格子** |

因为图标是「从 atlas 里裁一块图」画出来的，透明贴图裁出来就是全透明。
模型方块**务必**给 `icon` 或 `iconDraw`。

```js
G.registerBlock('my_terminal', '终端', {
  tex: { all: 'iron_block' },
  iconDraw(ctx, S){                 // 独立 16×16 图标
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++){
        const inScreen = (x > 3 && x < S-3 && y > 3 && y < S-6);
        ctx.fillStyle = inScreen ? '#3a3a3a' : (y > S-4 ? '#5a5a5a' : '#2a2a2a');
        ctx.fillRect(x, y, 1, 1);
      }
    ctx.fillStyle = '#50ff50';
    ctx.fillRect(5, 8, 4, 1);
  },
});
```

#### 隐形方块 `invisible`

如果方块本体不想要，但又要保留碰撞/数据/交互/掉落：

```js
G.registerBlock('magic_crystal_block', '魔法水晶', {
  tex: { all: 'glass' },   // 仍需贴图占 atlas 一格，但不会被渲染
  invisible: true,         // ★ 六个面全不画，邻居也不被它遮挡
  solid: false,            // 可穿过
  occludes: false,         // 强烈建议加
  opaque: false,
  hardness: 1.5,
  tool: 'pickaxe',
});

G.attachVisual(x, y, z, myThreeObject);
```

| 字段 | 效果 |
|---|---|
| `invisible: true` | 6 个面全部不渲染；邻居面不因为它被剔除 |
| `solid` | 是否阻挡玩家/实体 |
| `occludes` | 是否遮挡邻居（隐形方块必须 `false`） |
| `opaque` | 是否遮蔽光照 |

保留：`getBlock` 能读到、碰撞（按 `solid`）、`block.interact`、`getBlockData`、挖掘掉落、`attachVisual` 正常显示。

顺带几条：

* `icon` 的名字必须已经存在于贴图表里（`registerBlock` 的 `drawFn` 会自动注册同名贴图；`registerTex` 没有暴露给 mod）。名字写错不会崩，会退回顶面并打一条 warn。
* 掉落物、创造面板、箱子/熔炉里的格子全都走同一套图标解析，改一处到处生效。
* 区块卸载后 `scene` 里的对象不会自动回来，重进世界时（`world.enter`）要对已存在的方块重新 `attachVisual`。
* 想让机器有数据（转速、库存），用 `G.setBlockData(x,y,z,{...})` 存。

### 1.3 方块掉落 `setBlockDrop`

```js
G.setBlockDrop('my_ore', 'my_gem');                       // 固定掉 1 个
G.setBlockDrop('my_ore', { name: 'my_gem', min: 1, max: 3 }); // 随机 1~3 个
G.setBlockDrop('my_ore', [
  { name: 'my_gem', count: 1 },
  { name: 'stone', chance: 0.25 },
]);                                                        // 多掉落 + 概率
G.setBlockDrop('my_block', null);                          // 不掉落
G.clearBlockDrop('my_block');                              // 恢复默认
```

- `spec` 支持：物品名 / 数字 id / `{name|id, count|min/max, chance}` / 数组 / `null`。
- 也可以传函数：`(ctx) => spec`，`ctx = { x, y, z, name, block, tool, mode }`
  可用于按工具等级、时运、群系改掉落；返回 `undefined` 表示回退默认。
- 只影响**普通方块**的掉落；阶梯、双格植物、海带、门等有内置特殊掉落，会先走内置分支。
- 创造模式仍不掉落。

### 1.4 实体掉落 `setEntityLoot`

```js
G.setEntityLoot('cow', [{ name: 'diamond', min: 1, max: 1 }]); // 覆盖牛的掉落
G.setEntityLoot('cow', () => [                                  // 也可以传函数（无参数）
  { name: 'raw_beef', min: 1, max: 3 },
]);
G.setEntityLoot('cow', null);                                   // 什么都不掉
```

- 元素格式是实体专用：`{ name|id, min, max }`。
  **实体掉落不支持 `count` 或 `chance`**（源码只读 `min`/`max` 再随机）；要概率请返回空数组。
- 对**已经生成的实体也会立即生效**：同类实体共享同一份类型配置对象，改的是 `type.loot`。
- 反过来要注意：`G.registerEntity(id, cfg)` **不能覆盖已注册的 id**——同 id 再次注册会被忽略并打一条 warn。
  想调整血量/AI/体积，必须在**第一次注册前**定好；运行期只能改掉落这类"类型对象上的字段"。

### 1.5 配方 `registerRecipe`

```js
G.registerRecipe(recipe, source?)
```

```js
// 无序
G.registerRecipe({
  size: 3,
  shapeless: ['magic_ore', 'magic_ore'],
  result: { name: 'diamond_gem', count: 1 },
}, 'my_mod');

// 有序（pos 是 0~8 的棋盘格序号）
G.registerRecipe({
  size: 3,
  shape: [
    { pos: 0, item: 'magic_ore' },
    { pos: 1, item: 'magic_ore' },
    { pos: 4, item: 'stick' },
  ],
  result: { name: 'magic_wand', count: 1 },
}, 'my_mod');
```

查询：`G.listRecipes()`

### 1.6 烧炼 / 燃料

```js
G.registerSmelt('magic_ore', 'diamond_gem', 1, 'my_mod');
G.setFuel('magic_ore', 240);      // 秒
G.removeSmelt('magic_ore');       // 只能移除运行时注册的
G.listSmelts();
```

### 1.7 群系 `registerBiome`

```js
G.registerBiome('dark_forest', {
  label: '暗黑森林',
  surface: 'grass', subsurface: 'dirt', underwater: 'gravel',
  treeDensity: 0.075,
  treeTypes: ['oak', 'spruce'],
  plants: [
    { type: 'tall_grass', density: 0.35 },
    { type: 'poppy', density: 0.02 },
  ],
  features: ['cactus', 'petals'],
  fog: { color: 0x2a1a3a, near: 20, far: 90 },
  color: 0x2a4a2a,
});
```

宿主会立即广播到 Worker：**新生成的区块生效，已加载区块不重新生成**。

### 1.8 生成器 `registerGenerator`

```js
G.registerGenerator('skyland', {
  label: '浮空群岛',
  icon:  '☁',
  desc:  '漂浮在云端的岛屿',
  hidden: false,                          // true = 不出现在选择列表
  heightLimits: { def: 300, max: 400 },   // 该类型的世界高度范围
  options: [ { key: 'height', kind: 'height' } ],

  heightAt(wx, wz, ctx){ … },             // 只改高度
  biomeAt(wx, wz, h, ctx){ … },           // 影响植被/树木选择与 G.biomeAt
  onGenerate({ cx, cz, chunk, blockIds, cfg, helpers }){ … }, // 返回 true = 完全接管
  onChunkGen({ cx, cz, chunk, blockIds, cfg, helpers }){ … }, // 内置地形之后、装饰之前
  onDecorate(chunk, crossWrites, ctx){ … },

  worldgenUrl: '/mods/skyland/worldgen.js', // 可选：交给 Worker 生成（见下）
});
```

**当前实际生效**：类型出现在选择列表、`heightLimits`、`options`、`heightAt`、`biomeAt`、
`onGenerate`、`onChunkGen`、`onDecorate`、`worldgenUrl`。

- `biomeAt` 目前影响**植被/树木选择**和 `G.biomeAt()` 查询；地表方块和群系染色仍按基础群系。
- `onChunkGen` 在矿脉之后、装饰之前执行，`helpers` 只支持本区块读写。
- 给了 `worldgenUrl` 时，**Worker 调用模块的 `generate(chunk, blockIds, cfg)`**，
  上面这些主线程钩子不参与；非内置 id 且没给 `worldgenUrl` 时自动降级到主线程。
- `onDecorate` 的签名是 `(chunk, crossWrites, { blockIds, cfg, helpers })`，
  在内置装饰（树/花草/冰/海草）全部完成之后追加。

#### 1.8.1 三种生成粒度

| 粒度 | 钩子 | 用途 |
|---|---|---|
| 只改高度 | `heightAt(wx, wz, ctx)` | 浮空岛、极端地形 |
| 只改群系 | `biomeAt(wx, wz, h, ctx)` | 强制某位置是特定群系 |
| 完全接管 | `onGenerate({ cx, cz, chunk, blockIds, cfg, helpers })` | 纯水世界、迷宫、完全自定义 |
| 追加内容 | `onChunkGen(...)` / `onDecorate(chunk, crossWrites, ctx)` | 在原版地形上加建筑/遗迹 |

#### 1.8.2 主线程 `onGenerate`

```js
G.registerGenerator('aqua', {
  label: '无尽之海',
  options: [],
  onGenerate({ chunk, blockIds, cfg, helpers }){
    const CS = cfg.CS;
    for (let x = 0; x < CS; x++){
      for (let z = 0; z < CS; z++){
        helpers.setBlock(x, 45, z, blockIds.sand);
        for (let y = 46; y <= 60; y++){
          helpers.setBlock(x, y, z, blockIds.water);
          helpers.setFluid(x, y, z, 8, true);
        }
        helpers.setTopY(x, z, 45);
      }
    }
    return true;  // ★ 返回 true = 完全接管
  },
});
```

`helpers`：

```js
{
  setBlock(lx, ly, lz, id)               // 写方块，自动更新 minY/maxY
  getBlock(lx, ly, lz)                   // 读方块
  setFluid(lx, ly, lz, level, isSource)  // 写流体（低 4 位液位，bit4 源头）
  fillBox(x0, y0, z0, x1, y1, z1, id)    // 批量填
  setTopY(lx, lz, h)                     // 设置地表高度
}
```

`cfg`：`{ seed, SEA_LEVEL, Y_MIN, CHH, CS, COL_H }`。

#### 1.8.3 高性能：`worldgenUrl`

默认 `onGenerate` 在主线程跑（每 chunk 约 3~10ms）。
提供 `worldgenUrl` 后，Worker 会 `import()` 这个文件并在 Worker 里执行，主线程零开销。

目录：

```
mods/aqua_world/
├── manifest.json
├── main.js          ← 主线程：注册
└── worldgen.js      ← Worker 加载：纯函数
```

`main.js`：

```js
G.registerGenerator('aqua', {
  label: '无尽之海',
  options: [],
  worldgenUrl: '/mods/aqua_world/worldgen.js',
  onGenerate({ chunk, blockIds, cfg }){        // Worker 不可用时的降级路径
    return aquaGenerate(chunk, blockIds, cfg);
  },
});
```

`worldgen.js`：

```js
// ★ 必须是纯函数，不能 import 'three' 或主线程 G
export function generate(chunk, blockIds, cfg){
  const { CS, Y_MIN } = cfg;
  const idx = (x, y, z) => (((y - Y_MIN) * CS) + z) * CS + x;
  const sand = blockIds.sand, water = blockIds.water;

  for (let x = 0; x < CS; x++){
    for (let z = 0; z < CS; z++){
      chunk.blocks[idx(x, 45, z)] = sand;
      for (let y = 46; y <= 60; y++){
        chunk.blocks[idx(x, y, z)] = water;
        chunk.fluid[idx(x, y, z)] = 8 | 0x10;   // level 8 + source
      }
      chunk.topY[z * CS + x] = 45;
      if (45 < chunk.minY) chunk.minY = 45;
      if (61 > chunk.maxY) chunk.maxY = 61;
    }
  }
  return true;   // true = 完全接管
}

// 可选：自定义染色
export function getBiomeColors(wx, wz, cfg){
  return { grass: 0x8ac94e, foliage: 0x70b82a };
}
```

#### 1.8.4 Worker 侧接口约定

`generate(chunk, blockIds, cfg)`

`chunk`（**由 Worker 分配好，mod 负责填充**）：

```js
{
  cx, cz,
  blocks: Uint8Array(16 * 16 * COL_H),   // 方块 id
  fluid:  Uint8Array(16 * 16 * COL_H),   // 低 4 位=液位，bit4=源头
  topY:   Int16Array(16 * 16),           // 每列地表高度
  minY:   CHH,                           // ★ mod 要维护
  maxY:   0,                             // ★ mod 要维护
}
```

索引：`(((y - Y_MIN) * 16) + z) * 16 + x`

`blockIds`：与主线程 `G.B` 结构一致（`{ name: id }`）。

`cfg`：

```js
{
  SEED: 12345,
  SEA_LEVEL: 46,
  CHH: 400,
  Y_MIN: -46,
  CS: 16,
  COL_H: 446,
}
```

返回值：

| 返回 | 含义 |
|---|---|
| `true` | 完全接管，跳过所有内置生成（地形/洞穴/矿脉/装饰） |
| `false` / `undefined` | 不接管，走内置生成 |
| `Promise` | 异步（Worker 会 await） |

#### 1.8.5 `worldgen.js` 能 import 什么

| ✅ 可以 | ❌ 不行 |
|---|---|
| 同目录文件 `./helpers.js` | 裸模块名 `import 'three'`（Worker 无 importmap） |
| 主线程共享的纯模块 `/src/world/core/density.js` | 主线程 `G` 对象 |
| `/src/world/core/terrain-params.js` | `document` / `window` / `localStorage` |
| `/src/core/runtime.js`（无 DOM 依赖部分） | `render-core.js` / `textures.js` 等带 DOM 的 |

判断标准：能 import 的文件必须**顶层不访问 `document` / `window`**。

#### 1.8.6 失败与降级

Worker 里 `import(worldgenUrl)` 或 `generate()` 失败时：

1. 控制台显示 `[terrain-worker] mod worldgen 加载失败: <错误>` / `mod generate 出错，回退内置`；
2. 该区块回退到内置 `genChunkData`；
3. 游戏继续运行（玩家看到内置地形），不会黑屏。

如果浏览器禁用了 Worker（`?worker=off`）或 Worker 不可用：

- `worldgenUrl` 这条路不生效；
- `onGenerate`（主线程版）仍然生效。

推荐双路兼容写法：

```js
export default {
  async onEnable(saveId, meta, G){
    const wg = await import('/mods/my_world/worldgen.js');  // 给主线程降级用
    G.registerGenerator('my_world', {
      label: '我的世界',
      worldgenUrl: '/mods/my_world/worldgen.js',
      onGenerate({ chunk, blockIds, cfg }){
        return wg.generate(chunk, blockIds, cfg);
      },
    });
  }
};
```

### 1.9 维度 `registerDimension`

```js
G.registerDimension('twilight', {
  name: '维度',
  generator: 'twilight_forest',
  skyPreset: {
    frozen: true, timeOfDay: 0.72,
    topColor: 0x2a1a4a, bottomColor: 0x6a3a2a,
    fogColor: 0x3a2a4a, fogNear: 30, fogFar: 150,
    sunIntensity: 0.6, ambientIntensity: 0.35,
  },
});

G.switchDimension('twilight');
G.getActiveDimensionId();  G.listDimensions();  G.hasDimension('twilight');
```

### 1.10 实体 `registerEntity`

```js
G.registerEntity('warden', {
  label: '深海守卫',
  health: 200,
  width: 1.5, height: 4.2, depth: 1.5,
  speed: 3.5,

  spawnKind: null,        // null = 不自动生成 / 'land' / 'water'
  spawnWeight: 1,
  spawnCap: 3,
  category: 'land_predator',   // 见第 4 节，不填按 spawnKind 推断
  persistent: false,           // true = 超过清理距离也不被自动删除

  build(){
    const g = new G.THREE.Group();
    // …
    return { group: g, parts: {} };
  },

  update(entity, dt, playerPos, world){
    // world: { isSolid, getBlock, moveWithCollision, gravity, … }
  },

  onDamage(e, amount, source){}, onDeath(e){}, onSpawn(e){}, onInteract(e, player){},
  loot(){ return [{ name: 'diamond_gem', min: 1, max: 3 }]; },
});

G.spawnEntity('warden', x, y, z);
G.damageEntity(e, 10, 'magic_damage');
G.removeEntity(e);
G.getEntityAt(origin, dir, maxDist);
```

`persistent: true` 的实体不会因"休眠后超过 256 格"被定时清理，适合 Boss、任务 NPC、载具核心。

### 1.11 音效 `registerSound`

```js
G.registerSound(name, '/mods/<id>/sounds/xxx.ogg', { preload: true });  // → bool
G.loadSound(name);                    // → Promise<AudioBuffer|null>
const h = G.playSound(name, { volume: 0.5, loop: false, rate: 1.0 });
G.playSoundAt(name, x, y, z, { volume: 1, maxDist: 32 });
h?.stop();  h?.setVolume(0.5);
G.unregisterSound(name);  G.stopAllSounds();
```

- 支持 `.ogg` / `.mp3` / `.wav` / `.m4a` / `.webm`，**推荐 `.ogg`**
- 距离衰减：`volume × (1 − dist/maxDist)²`
- 加载失败**静默**（返回 null），不影响游戏
- 同时播放建议 ≤ 10 个；常用音效用 `preload: true`

### 1.12 移动 / 液体 / 状态效果

#### 移动与水中物理

```js
G.getMovementConfig();                       // → 当前值（副本）
G.setMovementConfig({ jumpVelocity: 12 });  // 只改传入的字段，返回新配置
G.resetMovementConfig();                     // 恢复默认
```

| 字段 | 默认 | 说明 |
|---|---|---|
| `walkSpeed` | 4.4 | 行走 |
| `sneakSpeed` | 2.0 | 潜行 |
| `sprintSpeed` | 7.0 | 疾跑 |
| `waterSpeed` | 3.6 | 水中水平速度 |
| `flySpeed` / `flySprintSpeed` | 12 / 26 | 创造飞行 |
| `groundAccel` / `airAccel` | 14 / 5 | 地面/空中加速度 |
| `jumpVelocity` | 8.6 | 起跳初速度 |
| `gravity` | 28 | 重力 |
| `maxFallSpeed` | 58 | 下落速度上限 |
| `flyingVerticalFactor` | 0.8 | 飞行升降系数 |
| `waterGravity` | 9 | 水中下沉加速度 |
| `waterBuoyancy` | 3.4 | 按住跳跃时的上浮速度 |
| `waterDamping` | 2.2 | 水中垂直阻尼 |
| `waterMaxSpeed` | 5 | 水中垂直速度上限 |

- 每帧读取，改完立即生效；只接受有限数字，非法字段被忽略
- 全局生效（单机只有一个玩家）；`world.load` 不会自动重置

#### 液体流动

```js
G.setFluidConfig({ flowDelay: 0.1, maxPerFrame: 96 });
G.getFluidConfig();
G.resetFluidConfig();
G.wakeFluid(x, y, z, delay);   // 把某格重新排进流动队列（delay 秒，省略用 flowDelay）
```

| 字段 | 默认 | 说明 |
|---|---|---|
| `flowDelay` | 0.22 | 一次扩散后的下次处理延迟 |
| `recheckDelay` | 0.35 | 复查延迟 |
| `maxPerFrame` | 48 | 每帧最多处理多少格 |
| `promotePerFrame` | 16 | 每帧最多升级多少个无限水源 |
| `maxPending` | 3000 | 待处理队列上限 |

可取消事件：

```js
G.on('fluid.tick:before', (x, y, z, blockId) => {
  return true;   // 跳过这一格的这次流动；需要时再 G.wakeFluid(x, y, z, 1)
});
G.on('fluid.spread:before', (nx, ny, nz, fluidId, spreadLevel) => {
  return true;   // 阻止流向这一格
});
```

> 被取消的格子会从队列里移除，不会自动重试；要恢复流动必须自己 `wakeFluid`。

液位读取/写入用 `G.getFluidLevel` / `G.setFluidLevel` / `G.getFluidSource` / `G.createFluidSource` / `G.removeFluidSource`（见卷一第 5 节）。

#### 状态效果

宿主只做**计时、堆叠、到期**，回血/扣血/减速等效果全部由 mod 回调实现。

```js
G.registerStatusEffect('regen', {
  name: '再生',
  duration: 8,          // 秒；duration <= 0 表示永久
  maxStacks: 3,
  tickInterval: 1,      // 秒；0 表示只计时、不调用 onTick
  // 三个回调都只接收一个 inst：
  // { id, type, remaining, elapsed, stacks, data, reason? }
  onApply(inst){ /* ... */ },
  onTick(inst){
    G.heal(1);          // 每秒回 1 点（G 来自 onEnable 的闭包）
  },
  onRemove(inst){
    if (inst.reason === 'expire') G.log.info('再生结束');
  },
});

G.applyStatus('regen', 8, { stacks: 1, data: { source: 'apple' } });
G.hasStatus('regen');            // → bool
G.getStatus('regen');            // → { id, name, remaining, elapsed, stacks, data } | null
G.getActiveStatuses();           // → 数组
G.listStatusEffectTypes();       // → 已注册类型（不含运行实例）
G.removeStatus('regen', 'cure');
G.clearStatusEffects('death');
G.unregisterStatusEffect('regen');
```

- 重复 `applyStatus` 刷新持续时间并叠层（`maxStacks` 封顶）
- `remaining === Infinity` 表示永久
- 回调抛错会被 `console.error` 隔离，不影响主循环
- `world.load` 会清空所有运行中的状态（类型注册保留）
- 状态不进存档，重进世界需要自己重新施加

---

## 2. 世界类型（mod 提供创建界面里的类型）

### 2.1 为什么需要两条路

世界类型是在**创建世界时**选的，而 mod 要**进了世界才加载** —— 只靠 `registerGenerator` 的话，mod 的地形类型永远不会出现在创建界面里。

所以 mod 可以在 `manifest.json` 里**静态声明**：

```json
{
  "id": "raftworld",
  "worldTypes": [{
    "id": "raft_ocean",
    "label": "无尽之海",
    "icon": "🌊",
    "desc": "陆地约占 4% 的开阔海面",
    "options": [
      { "key": "height",  "kind": "height" },
      { "key": "islands", "kind": "toggle", "label": "生成岛屿（关闭=纯海洋）", "def": true }
    ],
    "heightLimits": { "def": 256, "max": 400 }
  }]
}
```

- 创建界面会列出它，带 **MOD** 标记
- **选中时自动勾选该 mod 和它的依赖**，不用玩家自己去选
- 玩家勾的值写进 `meta.worldOptions`，mod 用 `G.getWorldOptions()` 读
- 宿主 API 版本不够时该类型**置灰不可选**并提示原因

### 2.2 options 的规则

| 写法 | 结果 |
|---|---|
| 不写 `options` | **沿用普通模式（vanilla）的选项** |
| `"options": []` | 这个类型**没有任何可调项**（如超平坦，高度对它没意义） |
| 写了 `options` | 用自己的 |

`kind` 支持四种：

| kind | 说明 |
|---|---|
| `height` | 复用内置的「最高区块」滑条（配合 `heightLimits`） |
| `range` | 自定义滑条：`{ key, label, min, max, step, def }` |
| `toggle` | 开关：`{ key, label, def }` |
| `text` | 文本框：`{ key, label, def }` |

### 2.3 mod 里读选项

```js
export default {
  onEnable(saveId, meta, G){
    const opt = G.getWorldOptions();        // → { islands: true }
    this._islands = opt.islands !== false;  // 没选过就是 {}
  }
};
```

选项也会随存档保存（`world.json` 的 `worldOptions`），下次进同一个世界还在。

---

## 3. 创造面板：分类与分页

### 3.1 注册分类

```js
G.registerCreativeCategory({
  id: 'my_machines',
  label: '我的机器',
  icon: 'oak_planks',   // 可选
  order: 70,            // 可选：越小越靠前
});
```

内置分类 id（可以直接用）：

| id | label | order |
|---|---|---|
| `building` | 建筑 | 10 |
| `nature` | 自然 | 20 |
| `material` | 材料 | 30 |
| `functional` | 功能 | 40 |
| `tools` | 工具 | 50 |
| `food` | 食物 | 60 |
| `misc` | 其他 | 900 |

### 3.2 方块指定分类

```js
G.registerBlock('steam_pipe', '蒸汽管', {
  category: 'my_machines',   // ← 落到自己分类
  tex: { all: 'iron_ingot' },
});
```

规则：

- `category` 必须是已注册的分类，否则回落到自动推断。
- 内置方块不能被"移动"分类（除非直接改 `BLOCKS[id].category`，不推荐）。
- 一个方块只能属于一个分类。
- `category` 也可以在 `registerBlock` 之后再补：只要方块上带着 `category` 字段，分类面板就会认。

### 3.3 分类栏分页

分类多于 **5 个**时，chip 栏会显示 `‹ … ›` 箭头，每页 5 个。
内置 7 个分类本身就已经超过 5 个，所以分类栏通常会出现翻页箭头。

影响：如果 mod 分类 `order` 设置不当，它可能"藏在第 2 页"。建议：

- 核心分类设 `order: 65`（在 `food`(60) 之后、`misc`(900) 之前，通常在第 1 页）；
- 或引导用户点击 `›` 翻页。

### 3.4 隐藏方块

```js
G.registerBlock('debug_block', '调试方块', {
  hidden: true,   // 不出现在创造面板
});
```

运行时注册了新分类 / 新方块后，面板会自动重建，不用手动刷新。

---

## 4. 实体分类与距离分级

### 4.1 分类与上限

| 分类 | 默认上限 | 说明 |
|---|---|---|
| `land_herbivore` | 60 | 陆生草食（牛、羊、鸡） |
| `land_predator` | 20 | 陆生肉食 |
| `water` | 50 | 水生（鱼） |
| `flying` | 30 | 飞行 |
| `other` | 20 | 未分类 |

不填 `category` 时按 `spawnKind` 推断：`'land'` → `land_herbivore`，`'water'` → `water`。

```js
G.setEntityCap('land_herbivore', 200);   // 0 ~ 500
G.getEntityCap('land_herbivore');
G.listEntityCaps();
G.getEntityCounts();                     // 只算活跃的，不含休眠
G.getEntityCountByType('cow');
G.getTypesByCategory('land_herbivore');
```

### 4.2 距离分级 tick

| 距离 | AI 更新频率 |
|---|---|
| < 16 格 | 每帧 |
| 16~48 格 | 每 4 帧 |
| 48~96 格 | 每 16 帧 |
| > 96 格 | 冻结（还在场景里，不跑 AI） |

```js
G.setTickDistances({ near: 24, mid: 64, far: 128 });
G.getTickDistances();
```

- `far` 不能超过模拟距离（`simDist × 16`）
- **建议不改**，除非有明确需求

**效果参考**：同屏 200 只（近处 20 只）从 200 次 AI/帧降到约 60 次/帧。

### 4.3 休眠与清理

| 距离 | 行为 |
|---|---|
| > 模拟距离 | 休眠（不渲染、不跑 AI，位置保留） |
| 回到范围内 | 唤醒 |
| 休眠后 > 256 格 | 每 5 秒扫一次，清理掉（`persistent: true` 的实体不清理） |

所以跑图回去动物不会"消失"，而是重新生成。

### 4.4 AI 异常不会一次致命

mod 的 `cfg.update` 抛异常时，宿主**不会立刻停用**，而是累计连续失败次数：

- 连续失败 **5 次**才停用该类型的 AI
- 中间成功一次就清零
- 被停用的类型可以在 `G.info.disabledEntityAi` 里查到

---

## 5. 存档与 mod 存储

> 箱子比较特殊：**一个箱子一个文件**，在 `saves/<saveId>/chests/<dimId>/`。
> 熔炉则是一个 `furnaces.json` 装全部。两种策略各有取舍：
> 箱子的做法改一个箱子只写几十字节，几百个箱子也不拖慢保存；
> 熔炉的做法读一次就全在内存里，适合需要每帧 tick 的方块。

**mod 不能直接改游戏存档**（`blocks.json` / `player.json` 等）。要持久化用自己的存储。

```js
const st = G.storage(meta.id);

await st.exists('config.json');            // → bool
await st.readText('config.json');          // → string | null
await st.readJSON('config.json');          // → object | null
await st.readBytes('data.bin');            // → ArrayBuffer | null
await st.writeText('config.json', '…');
await st.writeJSON('config.json', { … });
await st.writeBytes('data.bin', buf);
await st.list('');                          // → [{ name, dir, size, mtime }] | null
await st.mkdir('subdir');
await st.remove('config.json');
```

**路径**：`saves/<saveId>/mods/<modId>/<rel>`

- `G.storage` 写入**立即生效**（不走游戏的"保存并退出"流程）
- **高频读写会打服务器**。建议内存变量 + 定时落盘：

```js
let dirty = false;
G.on('world.blockChanged', () => { dirty = true; });
setInterval(async () => {
  if (!dirty) return;
  dirty = false;
  await st.writeJSON('state.json', snapshot());
}, 10000);
```

其他存档相关：

```js
G.saveId            // 当前存档 id
G.getSeed()         // 世界种子
G.getSaveType()     // 存档的世界类型
```

---

## 6. 示例合集

### 6.1 方块没了就清理绑定对象

```js
export default {
  onEnable(saveId, meta, G){
    const MINE = 'magic_crystal';
    const visuals = new Map();

    this._un = [
      G.on('world.blockChanged', (x, y, z, oldId, newId) => {
        const was = G.BLOCKS[oldId];
        if (!was || was.name !== MINE) return;
        const k = `${x},${y},${z}`;
        const obj = visuals.get(k);
        if (obj){ G.scene.remove(obj); visuals.delete(k); }
      }),
      G.on('block.place', (x, y, z, id) => {
        const b = G.BLOCKS[id];
        if (!b || b.name !== MINE) return;
        const m = new G.THREE.Mesh(new G.THREE.BoxGeometry(1,1,1),
                                   new G.THREE.MeshLambertMaterial({ color: 0xff66cc }));
        m.position.set(x + 0.5, y + 1.2, z + 0.5);
        G.scene.add(m);
        visuals.set(`${x},${y},${z}`, m);
      }),
    ];
    this._visuals = visuals;
  },
  onDisable(){
    for (const un of this._un) un();
    for (const m of this._visuals.values()) G.scene.remove(m);
    this._visuals.clear();
  }
};
```

### 6.2 右键独占：打开自己的 UI

```js
onEnable(saveId, meta, G){
  this._un = G.on('game.tick', () => {
    if (!G.input.mouseRight) return;
    const hit = G.getLookTarget(6);
    if (!hit) return;
    const b = G.BLOCKS[hit.blockId];
    if (!b || b.name !== 'my_terminal') return;
    G.input.consume('mouseRight');             // 本次右键归我，原版不再放方块
    this._openTerminal(hit);
  });
}
```

**按住期间要每帧 consume**（标记每帧清空），鼠标左键同理用 `'mouseLeft'`。

### 6.3 按玩家看的面向放置方块

```js
G.on('block.interact', (x, y, z, id, nx, ny, nz) => {
  const slot = G.getHeldSlot();
  const held = G.inventory[slot];
  if (!held || held.id !== G.B.screen.id) return false;

  const target = G.getLookTarget();
  if (!target) return false;

  const px = target.pos.x + target.normal.x;
  const py = target.pos.y + target.normal.y;
  const pz = target.pos.z + target.normal.z;

  G.setBlock(px, py, pz, G.B.screen.id);
  G.setBlockData(px, py, pz, { facing: target.face });
  return true;   // 阻止默认放置
});
```

### 6.4 给世界类型加自己的选项

`manifest.json` 见第 2 节，`main.js`：

```js
let CULL_ISLANDS = false;
onEnable(saveId, meta, G){
  const opt = G.getWorldOptions();
  CULL_ISLANDS = opt.islands === false;

  G.on('chunk.decorate', (chunk, api) => {
    if (!CULL_ISLANDS) return;
    const SEA = G.SEA_LEVEL;
    for (let lz = 0; lz < 16; lz++)
      for (let lx = 0; lx < 16; lx++){
        const top = api.topY(lx, lz);
        for (let y = SEA + 1; y <= top; y++) api.set(lx, y, lz, 0);
      }
  });
}
```

### 6.5 阻止高空放方块（Hook）

```js
onEnable(saveId, meta, G){
  this._h = G.hook('world.setBlock');
  this._h.before(([x, y, z, id]) => {
    if (id !== 0 && y > 250) return false;
  });
},
onDisable(){ this._h.restore(); }     // 只回滚自己这条
```

### 6.6 带音效的方块

```js
async onEnable(saveId, meta, G){
  const modId = meta.id;
  const id = G.registerBlock('magic_crystal', '魔法水晶',
    { hardness: 2, tool: 'pickaxe', minTier: 1, emissive: 1 },
    (ctx, S) => {
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++){
        const dx = x - S/2, dy = y - S/2;
        const d = Math.sqrt(dx*dx + dy*dy) / (S/2);
        ctx.fillStyle = d < 1
          ? `rgb(${180*(1-d)|0},${100*(1-d)|0},255)`
          : '#333';
        ctx.fillRect(x, y, 1, 1);
      }
    });

  G.registerSound('crystal.break', `/mods/${modId}/sounds/break.ogg`, { preload: true });
  this._un = G.on('block.break', (x, y, z, bid) => {
    if (bid === id.id) G.playSoundAt('crystal.break', x + .5, y + .5, z + .5, { maxDist: 20 });
  });
}
```

### 6.7 自定义 Boss

```js
onEnable(saveId, meta, G){
  G.registerEntity('slime_boss', {
    label: '史莱姆王', health: 100, width: 2, height: 2, depth: 2, speed: 2.5,
    persistent: true,
    build(){
      const g = new G.THREE.Group();
      const m = new G.THREE.Mesh(new G.THREE.BoxGeometry(2,2,2),
                                 new G.THREE.MeshLambertMaterial({ color: 0x40c040 }));
      m.position.y = 1; g.add(m);
      return { group: g, parts: {} };
    },
    update(e, dt, pp, world){
      const dx = pp.x - e.pos.x, dz = pp.z - e.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > 1.5){
        e.yaw = Math.atan2(-dx, -dz);
        e.vel.x = -Math.sin(e.yaw) * 2.5;
        e.vel.z = -Math.cos(e.yaw) * 2.5;
      }
      e.vel.y -= world.gravity * dt;
      world.moveWithCollision(e, dt);
      if (d < 2 && Math.abs(pp.y - e.pos.y) < 2){
        e._cd = (e._cd || 0) - dt;
        if (e._cd <= 0){ e._cd = 1.5; G.damagePlayer(4); }
      }
    },
    loot(){ return [{ name: 'diamond_gem', min: 5, max: 10 }]; },
  });

  this._un = G.on('game.tick', () => {
    if (!G.input.keys['KeyB']) return;
    G.input.keys['KeyB'] = false;
    const p = G.getPos();
    G.spawnEntity('slime_boss', p.x + 5, p.y + 2, p.z);
  });
}
```

### 6.8 浮空岛（只改高度）

```js
G.registerGenerator('sky_island', {
  label: '浮空岛',
  options: [],
  heightAt(wx, wz, ctx){
    const n = Math.sin(wx * 0.01) * Math.cos(wz * 0.01);
    if (n < 0.3) return -100;   // 深渊
    return 80 + n * 40;         // 浮岛
  },
});
```

---

## 7. 附录：API 速查

```js
// ---- 版本 ----
G.apiVersion  G.version  G.info

// ---- 数据 / 对象 ----
G.THREE  G.BLOCKS  G.B  G.scene  G.camera  G.renderer
G.player  G.inventory  G.input

// ---- 常量 ----
G.CS  G.CHH  G.Y_MIN  G.SEA_LEVEL  G.INV_SIZE  G.STACK_MAX

// ---- 读世界 ----
G.getBlock(x,y,z)  G.getBlockEx(x,y,z)  G.getBlockName(x,y,z)
G.heightAt(x,z)  G.biomeAt(x,z,h)  G.getChunkStats()

// ---- 环境查询 ----
G.isSolidAt(x,y,z)  G.isWaterAt(x,y,z)  G.isLavaAt(x,y,z)  G.isLoadedAt(x,y,z)
G.getTerrainHeight(x,z)  G.raycast(maxDist)  G.getLookTarget(maxDist)
G.worldApi.isSolid(x,y,z)  G.worldApi.getBlock(x,y,z)  G.worldApi.blockAt(x,y,z)
G.worldApi.isWaterAt(x,y,z)  G.worldApi.isLiquidAt(x,y,z)  G.worldApi.heightAt(x,z)
G.worldApi.collideAnimalAt(x,y,z,w,h)  G.worldApi.moveWithCollision(e,dt)
G.worldApi.gravity  G.worldApi.stepJump

// ---- 写世界 ----
G.setBlock(x,y,z,id[,opts])       // opts: { noRecord, silent }
G.setBlockByName(x,y,z,name)  G.fillBox(...,id)
G.batch(fn)

// ---- 流体 ----
G.getFluidLevel(x,y,z)  G.setFluidLevel(x,y,z,lv)
G.getFluidSource(x,y,z)  G.createFluidSource(x,y,z,id)  G.removeFluidSource(x,y,z)
G.getFluidConfig()  G.setFluidConfig(partial)  G.resetFluidConfig()  G.wakeFluid(x,y,z,delay?)

// ---- 方块计划 tick ----
G.scheduleBlockTick(x,y,z,delayTicks,fn,opts) → id   // return true 继续重复
G.cancelBlockTick(id)  G.cancelBlockTicksAt(x,y,z)  G.getBlockTickCount()

// ---- 方块实体数据 / 可视化 ----
G.getBlockData(x,y,z)  G.setBlockData(x,y,z,obj)  G.removeBlockData(x,y,z)
G.attachVisual(x,y,z,obj3d)  G.detachVisual(x,y,z)  G.setWaterRenderMode(mode)

// ---- UI 扩展 ----
G.ui.addInventoryWidget(html)  G.ui.addChestWidget(html)  G.ui.addFurnaceWidget(html)
G.ui.getSafeAreas()

// ---- 物品 ----
G.give(name,n)  G.addItem(id,n[,meta])  G.takeFromSlot(i,n)
G.spawnDrop(x,y,z,id,n[,meta])  G.drops  G.notifyInventory()

// ---- 玩家 ----
G.getPos()  G.getHeldSlot()  G.getLookTarget()  G.teleport(x,y,z)
G.heal(n)  G.damagePlayer(n)  G.setMode(m)  G.getPlayer()

// ---- 事件 ----
G.on(name,fn) → un   G.off(name,fn)   G.once(name,fn)   G.emit(name,...args)
G.listenerCount(name)  G.listEvents()

// ---- Hook ----
const h = G.hook(name)
h.before(fn)  h.after(fn)  h.replace(fn)  h.remove(fn)  h.restore()
h.beforeCount  h.afterCount  h.ownBeforeCount  h.ownAfterCount
G.listHooks()  G.isHooked(name)

// ---- 输入独占 ----
G.input.consume(name)          // mouseLeft/mouseRight/jump/mine/place/sneak
G.input.suspend()  G.input.resume()  G.input.isSuspended()

// ---- 日志 ----
G.log.info(...)  G.log.warn(...)  G.log.error(...)

// ---- 存档 ----
G.saveId  G.getSeed()  G.getSaveType()  G.storage(modId)  G.getWorldOptions()

// ---- 箱子 / 掉落 ----
G.setBlockDrop(name, spec)  G.clearBlockDrop(name)
G.setEntityLoot(type, spec)  G.removeEntity(e)  G.damageEntity(e, n)
G.getChestItems(x, y, z, dim?)  G.setChestItems(x, y, z, items, dim?, opts?)

// ---- 注册：方块 / 配方 / 熔炼 ----
G.registerBlock(name, label, opts, drawFn?)
G.registerRecipe(recipe, source?)  G.listRecipes()
G.registerSmelt(from, to, count, source)  G.removeSmelt(from)  G.listSmelts()
G.setFuel(name, seconds)
G.getAtlasUsage()

// ---- 注册：群系 / 生成器 / 维度 ----
G.registerBiome(name, cfg)  G.getBiome(id)  G.listBiomes()
G.registerGenerator(id, cfg)  G.getGenerator(id)  G.listGenerators()
G.setActiveGenerator(id)  G.getActiveGeneratorId()
G.getGeneratorHeightLimit(id)
G.registerDimension(id, cfg)  G.switchDimension(id)
G.getActiveDimensionId()  G.listDimensions()  G.hasDimension(id)

// ---- 注册：音效 ----
G.registerSound(name, url, opts)  G.unregisterSound(name)
G.loadSound(name) → Promise  G.playSound(name, opts)  G.playSoundAt(name,x,y,z,opts)
G.stopAllSounds()

// ---- 实体 ----
G.registerEntity(id, cfg)  G.spawnEntity(type,x,y,z)
G.removeEntity(e)  G.damageEntity(e,n,src)  G.getEntityAt(o,d,r)
G.listEntityTypes()  G.getAllEntityTypes()  G.getEntityType(id)  G.hasEntityType(id)
G.getSpawnableTypes()  G.getAnimalCount()  G.getEntityTypeCount()

// ---- 实体分类 / 上限 / 距离分级 ----
G.setEntityCap(cat,n)  G.getEntityCap(cat)  G.listEntityCaps()
G.getEntityCounts()  G.getEntityCountByType(t)  G.getTypesByCategory(cat)
G.setTickDistances({near,mid,far})  G.getTickDistances()

// ---- 移动 / 液体 / 状态 ----
G.getMovementConfig()  G.setMovementConfig(partial)  G.resetMovementConfig()
G.registerStatusEffect(id, def)  G.unregisterStatusEffect(id)
G.applyStatus(id, duration?, opts?)  G.removeStatus(id, reason?)
G.hasStatus(id)  G.getStatus(id)  G.getActiveStatuses()  G.listStatusEffectTypes()
G.clearStatusEffects(reason?)

// ---- 天空 ----
G.setSkyPreset(p)  G.getSkyPreset()  G.setBiomeFog(f)

// ---- 创造面板 ----
G.registerCreativeCategory(def)  G.listCreativeCategories()  G.getCreativeCategory(id)
```
