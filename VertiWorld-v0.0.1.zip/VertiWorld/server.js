/* ============================================================
   server.js —— 静态文件 + 存档 API + mod API + 日志 API + 核心代码注入
   ============================================================ */

/* ============================================================
   ★ 顶部补丁：在 Node.js 环境伪造浏览器 API
   ============================================================ */
if (typeof window === 'undefined') {
  globalThis.window = {
    matchMedia: () => ({ matches: false }),
    addEventListener: () => {},
  };
  globalThis.document = {
    body: { classList: { add: () => {}, remove: () => {} } },
    addEventListener: () => {},
  };
  globalThis.localStorage = {
    getItem: () => null,
    setItem: () => {},
    removeItem: () => {},
  };
  globalThis.navigator = {
    userAgent: '',
    maxTouchPoints: 0,
    hardwareConcurrency: 8,
  };
}

const http = require('http');
const fs   = require('fs');
const zipx = require('./zipx.js');   /* 内置 zip 读写（地图/整合包/自动解压） */
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const ROOT = __dirname;

const SAVES_DIR = path.join(ROOT, 'saves');
const MODS_DIR  = path.join(ROOT, 'mods');

/* ============================================================
   ★ 自动解压 .zip 格式的 mod
   ============================================================ */
function autoUnzipMods() {
  try {
    const files = fs.readdirSync(MODS_DIR);
    for (const file of files) {
      if (!file.endsWith('.zip')) continue;
      const fullPath = path.join(MODS_DIR, file);
      const modId = file.replace(/\.zip$/, '');
      const destDir = path.join(MODS_DIR, modId);
      
      if (fs.existsSync(destDir) && fs.statSync(destDir).isDirectory()) {
        continue;
      }
      
      console.log(`[mods] 检测到压缩包 ${file}，正在解压...`);
      try {
        /* ★ 用内置 zipx 解，不再依赖系统的 unzip 命令 */
        const entries = zipx.unzipSync(fs.readFileSync(fullPath));
        const rootAbs = path.resolve(destDir);
        fs.mkdirSync(destDir, { recursive: true });
        for (const e of entries){
          if (e.isDir) continue;
          const segs = e.name.replace(/\\/g, '/').split('/').filter(Boolean);
          if (!segs.length) continue;
          let bad = false;
          for (const seg of segs){
            if (seg === '.' || seg === '..' || seg.startsWith('.')){ bad = true; break; }
          }
          if (bad) continue;
          const out = path.join(destDir, ...segs);
          if (!path.resolve(out).startsWith(rootAbs + path.sep)) continue;
          fs.mkdirSync(path.dirname(out), { recursive: true });
          fs.writeFileSync(out, e.data);
        }

        const manifestPath = path.join(destDir, 'manifest.json');
        if (fs.existsSync(manifestPath)) {
          console.log(`[mods] ✔ 已解压 mod: ${modId}`);
          fs.unlinkSync(fullPath);
        } else {
          console.warn(`[mods] ✘ ${file} 解压后没有 manifest.json，清理中`);
          fs.rmSync(destDir, { recursive: true, force: true });
        }
      } catch(e) {
        console.warn(`[mods] ✘ 解压 ${file} 失败:`, e.message);
      }
    }
  } catch(e) {
    console.warn('[mods] 自动解压过程出错:', e);
  }
}
autoUnzipMods();

const COREMODS_DIR = path.join(ROOT, 'coremods');

/* ★ r167 起 three 的构建拆成两个文件：three.module.js 里只有渲染器，
   其余全部在 three.core.js，由 `import ... from './three.core.js'` 相对引用。
   两个文件必须一起放进 src/vendor/，只拷一个会直接白屏。 */
const THREE_LOCAL = '/src/vendor/three.module.js';
const THREE_CORE_LOCAL = '/src/vendor/three.core.js';
const THREE_CDN   = 'https://cdn.jsdelivr.net/npm/three@0.187.0/build/three.module.js';
const THREE_CORE_CDN = 'https://cdn.jsdelivr.net/npm/three@0.187.0/build/three.core.js';

// 确保核心目录存在
for (const d of [SAVES_DIR, MODS_DIR, COREMODS_DIR]){
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

/* ---- 校验规则 ---- */
const SAVE_ID_RE   = /^[a-zA-Z0-9_-]{1,64}$/;
const MOD_ID_RE    = /^[a-zA-Z0-9_-]{1,64}$/;
const FILE_NAME_RE = /^[a-zA-Z0-9_.\-]{1,128}$/;
const SEGMENT_RE   = /^[a-zA-Z0-9_\-. \u3000\u4e00-\u9fa5]{1,128}$/;
const MAX_FILE_BYTES = 64 * 1024 * 1024;

/* ---- MIME ---- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.wasm': 'application/wasm', '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json',
  '.bin': 'application/octet-stream', '.txt': 'text/plain; charset=utf-8',
};

/* ============================================================
   工具
   ============================================================ */
function sendJson(res, code, obj){
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBodyText(req){
  return new Promise((resolve, reject) => {
    const chunks = []; let total = 0;
    req.on('data', c => {
      total += c.length;
      if (total > MAX_FILE_BYTES){ reject(new Error('body too big')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function readBodyBuffer(req){
  return new Promise((resolve, reject) => {
    const chunks = []; let total = 0;
    req.on('data', c => {
      total += c.length;
      if (total > MAX_FILE_BYTES){ reject(new Error('body too big')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function resolveModPath(saveId, modId, relPath, allowRoot){
  if (!SAVE_ID_RE.test(saveId)) return null;
  if (!MOD_ID_RE.test(modId)) return null;
  const root = path.resolve(SAVES_DIR, saveId, 'data', modId);
  let rel = String(relPath == null ? '' : relPath).replace(/\\/g, '/');
  rel = rel.replace(/^\/+|\/+$/g, '');
  if (rel === '') return allowRoot ? root : null;
  const segs = rel.split('/');
  for (const s of segs){
    if (!s || s === '.' || s === '..' || s.startsWith('.')) return null;
    if (!SEGMENT_RE.test(s)) return null;
  }
  const full = path.resolve(root, segs.join(path.sep));
  if (full !== root && !full.startsWith(root + path.sep)) return null;
  return full;
}

function dirSize(dir, depth){
  if (depth === undefined) depth = 0;
  if (depth > 4) return 0;
  let total = 0;
  try {
    for (const name of fs.readdirSync(dir)){
      const p = path.join(dir, name);
      const st = fs.statSync(p);
      if (st.isDirectory()) total += dirSize(p, depth + 1);
      else total += st.size;
    }
  } catch(e){}
  return total;
}

/* ============================================================
   ★ Coremods 扫描 (Phase 2 & 3)
   ============================================================ */
/* ★ coremods 目录的扫描结果缓存 250ms：
   以前每个 .js 请求都 readdirSync+statSync 一遍（/storage 是 FUSE，每次 1~2ms），
   一页 40 个模块就是好几十次无谓的文件系统调用。 */
let _coreModsCache = null, _coreModsCacheAt = 0;
function listCoreModsCached() {
  const now = Date.now();
  if (_coreModsCache && now - _coreModsCacheAt < 250) return _coreModsCache;
  _coreModsCache = listCoreMods();
  _coreModsCacheAt = now;
  return _coreModsCache;
}

function listCoreMods() {
  const out = [];
  if (!fs.existsSync(COREMODS_DIR)) return out;
  let dirs;
  try { dirs = fs.readdirSync(COREMODS_DIR); } catch(e) { return out; }
  for (const name of dirs) {
    if (name.startsWith('.') || !/^[a-zA-Z0-9_-]{1,64}$/.test(name)) continue;
    const full = path.join(COREMODS_DIR, name);
    if (!fs.statSync(full).isDirectory()) continue;
    const manifestPath = path.join(full, 'manifest.json');
    if (!fs.existsSync(manifestPath)) continue;
    let m;
    try { m = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch(e) { continue; }
    if (!m || typeof m !== 'object' || m.id !== name) continue;
    out.push({
      id: m.id, name: m.name || m.id, version: m.version || '0.0.0',
      apiVersion: Number(m.apiVersion) || 4, stability: m.stability || 'experimental',
      entry: m.entry || 'inject.js',
      injections: Array.isArray(m.injections) ? m.injections : [],
    });
  }
  return out;
}

let _coreModsHash = null;
function getCoreModsHash() {
  if (_coreModsHash) return _coreModsHash;
  const mods = listCoreMods();
  if (mods.length === 0) return (_coreModsHash = 'none');
  const hash = crypto.createHash('sha1');
  for (const m of mods) { hash.update(m.id); hash.update(JSON.stringify(m.injections)); }
  _coreModsHash = hash.digest('hex').slice(0, 8);
  return _coreModsHash;
}

async function handleCoremodValidateApi(req, res) {
  if (req.method !== 'GET') return sendJson(res, 405, { error: 'method' });
  const mods = listCoreMods();
  const out = { valid: true, missing: [] };
  for (const m of mods) {
    for (const inj of m.injections) {
      if (!inj.target || typeof inj.target !== 'string') continue;
      const parts = inj.target.split('#');
      const file = parts[0]; const fnName = parts[1];
      const fullPath = path.join(ROOT, file);
      if (!fs.existsSync(fullPath)) {
        out.valid = false; out.missing.push({ coremod: m.id, target: inj.target, reason: 'file_not_found' }); continue;
      }
      if (fnName) {
        const text = fs.readFileSync(fullPath, 'utf8');
        const re = new RegExp(`(function\\s+${fnName}\\b|const\\s+${fnName}\\s*=|let\\s+${fnName}\\s*=)`);
        if (!re.test(text)) {
          out.valid = false; out.missing.push({ coremod: m.id, target: inj.target, reason: 'function_not_found' });
        }
      }
    }
  }
  return sendJson(res, 200, out);
}

/* ============================================================
   ★ 静态分析与 Mod 扫描 (Phase 1.3)
   ============================================================ */
const _modUsageCache = new Map();
function scanModUsage(modDir, modId, entryFile){
  const mainPath = path.join(modDir, entryFile || 'main.js');
  if (!fs.existsSync(mainPath)) return { hooks: [], events: [] };
  let st; try { st = fs.statSync(mainPath); } catch(e){ return { hooks: [], events: [] }; }
  const cached = _modUsageCache.get(modId);
  if (cached && cached.mtimeMs === st.mtimeMs) return cached;

  let text;
  try { text = fs.readFileSync(mainPath, 'utf8'); } catch(e){ return { hooks: [], events: [] }; }
  text = text.replace(/\/\*[\s\S]*?\*\//g, '');
  text = text.replace(/(^|[^:])\/\/.*$/gm, '$1');

  const hooks = new Set(), events = new Set();
  let m;
  const reHook = /G\.hook\(\s*['"]([^'"]+)['"]/g;
  const reOn   = /G\.on\(\s*['"]([^'"]+)['"]/g;
  while ((m = reHook.exec(text))) hooks.add(m[1]);
  while ((m = reOn.exec(text)))   events.add(m[1]);

  const result = { mtimeMs: st.mtimeMs, hooks: Array.from(hooks), events: Array.from(events) };
  _modUsageCache.set(modId, result);
  return result;
}

let _hooksCache = null, _hooksCacheAt = 0;
function scanHooks(){
  if (_hooksCache && Date.now() - _hooksCacheAt < 5000) return _hooksCache;
  const out = { hooks: [], events: [] };
  function walk(dir){
    let names; try { names = fs.readdirSync(dir); } catch(e){ return; }
    for (const name of names){
      if (name.startsWith('.') || name === 'vendor') continue;
      const p = path.join(dir, name);
      let st; try { st = fs.statSync(p); } catch(e){ continue; }
      if (st.isDirectory()){ walk(p); continue; }
      if (!name.endsWith('.js')) continue;
      let text; try { text = fs.readFileSync(p, 'utf8'); } catch(e){ continue; }
      const rel = path.relative(ROOT, p).replace(/\\/g, '/');
      const lines = text.split('\n');
      for (let i = 0; i < lines.length; i++){
        const line = lines[i];
        let m;
        if ((m = line.match(/defineHook\(\s*['"]([^'"]+)['"]/))) out.hooks.push({ name: m[1], file: rel, line: i + 1 });
        if ((m = line.match(/emit\(\s*['"]([^'"]+)['"]/))) out.events.push({ name: m[1], file: rel, line: i + 1 });
      }
    }
  }
  try { walk(path.join(ROOT, 'src')); } catch(e){ console.warn('[hooks] scan failed:', e); }
  _hooksCache = out; _hooksCacheAt = Date.now(); return out;
}

/* ============================================================
   Mod 列表 (含 detected 数据)
   ============================================================ */
/* ★ 500ms TTL：一次页面加载里 index.html 注入、/api/mods、atlas 配置
   会连着调好几次，每次都全盘扫 mods/ + JSON.parse 所有 manifest。 */
let _modsCache = null, _modsCacheAt = 0;
function listModsCached(){
  const now = Date.now();
  if (_modsCache && now - _modsCacheAt < 500) return _modsCache;
  _modsCache = listMods();
  _modsCacheAt = now;
  return _modsCache;
}

function listMods(){
  const out = [];
  let names; try { names = fs.readdirSync(MODS_DIR); } catch(e){ return out; }
  for (const name of names){
    if (name.startsWith('.') || !MOD_ID_RE.test(name)) continue;
    const full = path.join(MODS_DIR, name);
    let st; try { st = fs.statSync(full); } catch(e){ continue; }
    if (!st.isDirectory()) continue;
    const manifestPath = path.join(full, 'manifest.json');
    if (!fs.existsSync(manifestPath)) continue;
    let m; try { m = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch(e){ continue; }
    if (!m || typeof m !== 'object' || (m.id && m.id !== name)) continue;

    let folderSize = 0; try { folderSize = dirSize(full); } catch(e){}
    const usage = scanModUsage(full, name, (typeof m.entry === 'string' && m.entry) ? m.entry : 'main.js');

    out.push({
      id: name, name: m.name || name, version: m.version || '0.0.0',
      author: m.author || '', description: m.description || '',
      entry: (typeof m.entry === 'string' && m.entry) ? m.entry : 'main.js',
      apiVersion: Number(m.apiVersion) || 1,
      permissions: Array.isArray(m.permissions) ? m.permissions : [],
      icon: (typeof m.icon === 'string' && m.icon) ? m.icon : null,
      longDescription: (typeof m.longDescription === 'string') ? m.longDescription : '',
      changelog: (typeof m.changelog === 'string') ? m.changelog : '',
      homepage: (typeof m.homepage === 'string') ? m.homepage : '',
      license: (typeof m.license === 'string') ? m.license : '',
      dependencies: Array.isArray(m.dependencies) ? m.dependencies : [],
      worldTypes: Array.isArray(m.worldTypes) ? m.worldTypes : [],
      shortcuts: Array.isArray(m.shortcuts) ? m.shortcuts : [],
      contents: (m.contents && typeof m.contents === 'object') ? m.contents : null,
      folderSize,
      detectedHooks: usage.hooks,
      detectedEvents: usage.events,
    });
  }
  return out;
}

/* ============================================================
   ★ AST 注入引擎 (Phase 4)
   ============================================================ */
function injectCode(source, filePath) {
  const relPath = path.relative(ROOT, filePath).replace(/\\/g, '/');
  if (!relPath.startsWith('src/')) return source;
  
  const cms = listCoreModsCached();
  let modified = source;
  
  for (const cm of cms) {
    if (!Array.isArray(cm.injections)) continue;
    for (const inj of cm.injections) {
      if (!inj.target) continue;
      const [tFile, tFn] = inj.target.split('#');
      if (tFile !== relPath || !tFn) continue;
      
      const targetStr = JSON.stringify(inj.target);
      
      const fnRe = new RegExp(`((?:async\\s+)?function\\s+${tFn}\\s*\\(([^)]*)\\)|(?:const|let|var)\\s+${tFn}\\s*=\\s*(?:async\\s+)?function\\s*\\(([^)]*)\\))\\s*\\{`);
      const match = fnRe.exec(modified);
      if (!match) continue;
      
      const args = match[2] || match[3] || '';
      const openBraceIdx = match.index + match[0].length - 1;
      
      let depth = 0, closeBraceIdx = -1;
      let inString = false, strChar = '';
      let inComment = false, inLineComment = false;
      
      // 安全扫描函数体边界（避开字符串和注释）
      for (let i = openBraceIdx; i < modified.length; i++) {
        const c = modified[i];
        const next = modified[i+1];
        
        if (inLineComment) { if (c === '\n') inLineComment = false; continue; }
        if (inComment) { if (c === '*' && next === '/') { inComment = false; i++; } continue; }
        if (inString) {
          if (c === '\\') i++;
          else if (c === strChar) inString = false;
          continue;
        }
        if (c === '/' && next === '/') { inLineComment = true; i++; continue; }
        if (c === '/' && next === '*') { inComment = true; i++; continue; }
        if (c === '"' || c === "'" || c === '`') { inString = true; strChar = c; continue; }
        
        if (c === '{') depth++;
        else if (c === '}') {
          depth--;
          if (depth === 0) { closeBraceIdx = i; break; }
        }
      }
      
      if (closeBraceIdx === -1) continue;
      
      let fnBody = modified.slice(openBraceIdx + 1, closeBraceIdx);
      
      if (inj.at === 'HEAD' || !inj.at) {
        fnBody = `\n  if (globalThis.__MIXIN__) __MIXIN__.run(${targetStr}, 'HEAD', ${args});` + fnBody;
      }
      if (inj.at === 'TAIL') {
        fnBody = fnBody + `\n  if (globalThis.__MIXIN__) __MIXIN__.run(${targetStr}, 'TAIL');\n`;
      }
      
      if (inj.at === 'RETURN') {
        fnBody = fnBody.replace(/(?<!__MIXIN__\.runReturn\()return\s+([^;]+);/g, (m, expr) => {
          return `return globalThis.__MIXIN__ ? __MIXIN__.runReturn(${targetStr}, (${expr})) : (${expr});`;
        });
      }

      modified = modified.slice(0, openBraceIdx + 1) + fnBody + modified.slice(closeBraceIdx);
    }
  }
  return modified;
}

/* ============================================================
   Atlas 尺寸估算
   ============================================================ */
function computeAtlasConfig(){
  const BUILTIN_TILES = 220; const AVG_TILES_PER_ITEM = 1.5; const SAFETY = 1.3;
  let modNeeds = 0;
  try {
    for (const m of listModsCached()){
      const c = m.contents || {};
      modNeeds += (c.blocks || 0) + (c.items || 0) + (c.entities || 0) * 3;
    }
  } catch(e){}
  const need = Math.ceil((BUILTIN_TILES + modNeeds * AVG_TILES_PER_ITEM) * SAFETY);
  let cols;
  if (need <= 1024) cols = 32;
  else if (need <= 4096) cols = 64;
  else if (need <= 16384) cols = 128;
  else cols = 256;
  return { cols, tiles: cols * cols, need, modNeeds };
}

/* ============================================================
   服务端地形生成
   ============================================================ */
const _serverGenCache = new Map();
async function getServerGen(cfg, blockIds) {
  const cfgStr = JSON.stringify(cfg);
  if (_serverGenCache.has(cfgStr)) return _serverGenCache.get(cfgStr);
  const { createWorldGen } = await import('./src/world/core/world-gen.js');
  const wgen = createWorldGen(blockIds, cfg);
  _serverGenCache.set(cfgStr, wgen);
  if (_serverGenCache.size > 5) _serverGenCache.delete(_serverGenCache.keys().next().value);
  return wgen;
}

async function handleGenChunkApi(req, res) {
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
  try {
    const { cx, cz, cfg, blockIds } = JSON.parse(await readBodyText(req));
    const wgen = await getServerGen(cfg, blockIds);
    const data = wgen.genChunkData(cx, cz);
    const cwBuf = Buffer.from(JSON.stringify(data.crossWrites || []), 'utf8');
    const HEADER = 20;
    const total = HEADER + data.blocks.length + data.fluid.length + (data.topY.length * 2) + cwBuf.length;
    const buf = Buffer.alloc(total);
    buf.writeInt16LE(data.minY, 0); buf.writeInt16LE(data.maxY, 2);
    buf.writeUInt32LE(data.blocks.length, 4); buf.writeUInt32LE(data.fluid.length, 8);
    buf.writeUInt32LE(data.topY.length, 12); buf.writeUInt32LE(cwBuf.length, 16);
    buf.set(data.blocks, HEADER);
    let off = HEADER + data.blocks.length;
    buf.set(data.fluid, off); off += data.fluid.length;
    for (let i = 0; i < data.topY.length; i++) buf.writeInt16LE(data.topY[i], off + i * 2);
    off += data.topY.length * 2; buf.set(cwBuf, off);
    zlib.gzip(buf, { level: 6 }, (errGz, compressed) => {
      if (errGz) return sendJson(res, 500, { error: String(errGz.message) });
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Encoding': 'gzip', 'Content-Length': compressed.length, 'Cache-Control': 'no-store' });
      res.end(compressed);
    });
  } catch(e) { sendJson(res, 500, { error: e.message }); }
}

/* ============================================================
   日志与诊断 API
   ============================================================ */
const DIAG_MAX_BYTES = 512 * 1024;
/* ★ 诊断镜像目录（启动器通过 VW_LOG_DIR 传进来）。
   为什么要有它：diag 原来只写 <游戏目录>/saves/<存档>/logs/diag.txt，
   那在应用私有目录里 —— 用户拿不到，开发者也读不到；
   而且只有"进了世界"才会开始写，等于最该看的加载阶段一片空白。
   现在每条 diag 同时复制一份到这个外部可读目录，
   并且允许存档 id 为 _boot（还没加载存档时也能上报）。 */
const DIAG_MIRROR_DIR = process.env.VW_LOG_DIR || null;

async function handleDiagApi(req, res, urlPath){
  const m = urlPath.match(/^\/api\/diag\/([^/]+)$/);
  if (!m || req.method !== 'POST') return sendJson(res, 400, { error: 'bad req' });
  const saveId = m[1];
  const isBoot = (saveId === '_boot');
  if (!isBoot && !SAVE_ID_RE.test(saveId)) return sendJson(res, 400, { error: 'bad req' });
  let body; try { body = await readBodyText(req); } catch(e){ return sendJson(res, 413, { error: 'too big' }); }
  const d = new Date(); const pad = n => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  const line = body.replace(/\s+/g, ' ').trim();

  if (!isBoot){
    const dir = path.join(SAVES_DIR, saveId, 'logs');
    try {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, 'diag.txt');
      try { if (fs.existsSync(file) && fs.statSync(file).size > DIAG_MAX_BYTES) fs.renameSync(file, path.join(dir, 'diag.prev.txt')); } catch(e){}
      fs.appendFileSync(file, `${stamp}  ${line}\n`);
    } catch(e){}
  }

  if (DIAG_MIRROR_DIR){
    try {
      if (!fs.existsSync(DIAG_MIRROR_DIR)) fs.mkdirSync(DIAG_MIRROR_DIR, { recursive: true });
      const mf = path.join(DIAG_MIRROR_DIR, 'diag.txt');
      try { if (fs.existsSync(mf) && fs.statSync(mf).size > DIAG_MAX_BYTES) fs.renameSync(mf, path.join(DIAG_MIRROR_DIR, 'diag.prev.txt')); } catch(e){}
      fs.appendFileSync(mf, `${stamp}  ${isBoot ? '[boot] ' : ''}${line}\n`);
    } catch(e){}
  }
  return sendJson(res, 200, { ok: true });
}

async function handleLogApi(req, res, urlPath){
  const m = urlPath.match(/^\/api\/log\/([^/]+)$/);
  if (!m || !SAVE_ID_RE.test(m[1]) || req.method !== 'POST') return sendJson(res, 400, { error: 'bad req' });
  const dir = path.join(SAVES_DIR, m[1], 'logs');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  let body; try { body = await readBodyText(req); } catch(e){ return sendJson(res, 413, { error: 'too big' }); }
  const d = new Date(); const pad = n => String(n).padStart(2, '0');
  const name = `log-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.txt`;
  fs.writeFileSync(path.join(dir, name), body);
  return sendJson(res, 200, { ok: true });
}

/* ============================================================
   Bundle 拆包与安全写入 (Phase 0 修复)
   ============================================================ */
/* ============================================================
   ★ 整合包（modpack）/ 地图（map）导入 · 导出
   ------------------------------------------------------------
   两者共用一套纯 JS 的 zip 读写（zipx.js），不再依赖系统的
   zip / unzip 命令 —— Termux 上默认只有 unzip，没有 zip，
   原来导出一律失败。

   包布局（两种都一样的外壳）：
     · 整合包：  modpack.json + mods/<modId>/...
     · 地图：    saves/<saveId>/... + mods/<modId>/...
   接口见 mod开发3.md「整合包与地图的打包格式」。
   ============================================================ */

/* 包大小上限 = 全局请求体上限（MAX_FILE_BYTES，默认 64MB）：
   导入是整包读进内存解压的，别把上限调到比内存还大 */
const PACK_MAX_BYTES = MAX_FILE_BYTES;
const PACK_LIMIT_HINT = Math.round(MAX_FILE_BYTES / 1024 / 1024) + 'MB';

function _safeRel(name){
  /* 只收 "a/b/c" 这种相对路径，拒绝绝对路径 / .. / 隐藏文件 */
  if (!name || name.includes('\0')) return null;
  const segs = name.replace(/\\/g, '/').split('/').filter(Boolean);
  if (!segs.length) return null;
  for (const seg of segs){
    if (seg === '.' || seg === '..' || seg.startsWith('.')) return null;
    if (seg.length > 128) return null;
  }
  return segs;
}

function _writeEntryFile(rootDir, segs, data){
  const full = path.join(rootDir, ...segs);
  const rootAbs = path.resolve(rootDir);
  if (!path.resolve(full).startsWith(rootAbs + path.sep)) return false;
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, data);
  return true;
}

/* 打包时跳过的垃圾文件：编辑器/备份/系统残留。
   以前导出整合包会把每个 mod 的 main.js.bak 一起塞进去，包能大一倍。 */
const _PACK_JUNK_RE = /(\.bak(\..*)?$|~$|\.tmp$|\.swp$|\.orig$|\/\.[^/]*$)/i;
const _PACK_JUNK_NAMES = new Set(['.DS_Store', 'Thumbs.db', 'desktop.ini']);

function _collectDir(baseDir, prefix, out){
  if (!fs.existsSync(baseDir)) return out;
  const walk = (dir, rel) => {
    let names;
    try { names = fs.readdirSync(dir); } catch(e){ return; }
    for (const n of names){
      if (!n) continue;
      if (n.startsWith('.')) continue;
      if (_PACK_JUNK_NAMES.has(n)) continue;
      const full = path.join(dir, n);
      const relPath = rel ? rel + '/' + n : n;
      let st;
      try { st = fs.statSync(full); } catch(e){ continue; }
      if (st.isDirectory()){ walk(full, relPath); continue; }
      if (!st.isFile()) continue;
      if (_PACK_JUNK_RE.test(n)) continue;
      if (st.size > PACK_MAX_BYTES) continue;
      try { out.push({ name: prefix + relPath, data: fs.readFileSync(full) }); } catch(e){}
    }
  };
  walk(baseDir, '');
  return out;
}

async function _readPackBody(req, res){
  let buf;
  try { buf = await readBodyBuffer(req); }
  catch(e){ sendJson(res, 413, { error: '包太大' }); return null; }
  if (!buf || buf.length === 0){ sendJson(res, 400, { error: '空文件' }); return null; }
  if (buf.length > PACK_MAX_BYTES){ sendJson(res, 413, { error: '包太大' }); return null; }
  return buf;
}

/** 解包 → 分成 mods/<id>/... 与 saves/<id>/... 两组 */
function _splitPack(buf){
  const entries = zipx.unzipSync(buf);
  const modFiles = new Map();     /* modId -> [{segs, data}] */
  const saveFiles = new Map();    /* saveId -> [{segs, data}] */
  let modpackJson = null;

  for (const e of entries){
    if (e.isDir) continue;
    const segs = _safeRel(e.name);
    if (!segs) continue;

    const top = segs[0];
    if (top === 'modpack.json' && segs.length === 1){
      try { modpackJson = JSON.parse(e.data.toString('utf8')); } catch(err){}
      continue;
    }
    if (top === 'mods' && segs.length >= 3){
      const id = segs[1];
      if (!MOD_ID_RE.test(id)) continue;
      if (!modFiles.has(id)) modFiles.set(id, []);
      modFiles.get(id).push({ segs: segs.slice(2), data: e.data });
      continue;
    }
    if (top === 'saves' && segs.length >= 3){
      const id = segs[1];
      if (!SAVE_ID_RE.test(id)) continue;
      if (!saveFiles.has(id)) saveFiles.set(id, []);
      saveFiles.get(id).push({ segs: segs.slice(2), data: e.data });
    }
  }

  return { modFiles, saveFiles, modpackJson };
}

function _installMods(modFiles){
  const installed = [];
  for (const [id, files] of modFiles){
    const dest = path.join(MODS_DIR, id);
    /* 同名 mod 直接整目录替换：整合包优先 */
    if (fs.existsSync(dest)) fs.rmSync(dest, { recursive: true, force: true });
    fs.mkdirSync(dest, { recursive: true });
    for (const f of files) _writeEntryFile(dest, f.segs, f.data);
    installed.push(id);
  }
  return installed;
}

function _streamZip(res, fileName, entries){
  const data = zipx.zipSync(entries);
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Disposition': `attachment; filename="${encodeURIComponent(fileName)}"`,
    'Content-Length': data.length,
    'Cache-Control': 'no-store',
  });
  res.end(data);
}

/* ---------------- 整合包 ---------------- */
async function handleImportModpack(req, res){
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
  const buf = await _readPackBody(req, res);
  if (!buf) return;

  let parts;
  try { parts = _splitPack(buf); }
  catch(e){ return sendJson(res, 400, { error: '解压失败: ' + (e.message || e) }); }

  if (!parts.modFiles.size){
    return sendJson(res, 400, { error: '包里没有 mods/<modId>/ 目录' });
  }

  const mods = _installMods(parts.modFiles);
  const meta = {
    name: (parts.modpackJson && parts.modpackJson.name) || 'imported_pack',
    mods,
    importedAt: Date.now(),
  };
  console.log(`[modpack] 导入整合包「${meta.name}」: ${mods.join(', ')}`);
  return sendJson(res, 200, { ok: true, meta, mods });
}

async function handleExportModpack(req, res){
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
  try {
    let body = {};
    try { body = JSON.parse((await readBodyText(req)) || '{}'); } catch(e){ body = {}; }

    let mods = Array.isArray(body.mods) ? body.mods.filter(m => MOD_ID_RE.test(String(m))) : [];
    /* 不指定就整包导出所有已安装的 mod */
    if (!mods.length && fs.existsSync(MODS_DIR)){
      mods = fs.readdirSync(MODS_DIR).filter(n => {
        try { return fs.statSync(path.join(MODS_DIR, n)).isDirectory(); } catch(e){ return false; }
      });
    }
    if (!mods.length) return sendJson(res, 400, { error: '没有可导出的 mod' });

    const name = String(body.name || 'MyModpack').replace(/[\\/:*?"<>|]/g, '_').slice(0, 40) || 'MyModpack';
    const entries = [{ name: 'modpack.json', data: JSON.stringify({ name, mods }, null, 2) }];
    for (const id of mods){
      _collectDir(path.join(MODS_DIR, id), `mods/${id}/`, entries);
    }
    return _streamZip(res, `${name}.zip`, entries);
  } catch(e){
    console.error('[export_modpack]', e);
    if (!res.headersSent) sendJson(res, 500, { error: e.message });
  }
}

/* ---------------- 地图 ---------------- */
async function handleImportMap(req, res){
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
  const buf = await _readPackBody(req, res);
  if (!buf) return;

  let parts;
  try { parts = _splitPack(buf); }
  catch(e){ return sendJson(res, 400, { error: '解压失败: ' + (e.message || e) }); }

  if (!parts.saveFiles.size){
    return sendJson(res, 400, { error: '包里没有 saves/<saveId>/ 目录' });
  }

  /* 包里的 mod 一起装上（地图通常依赖它们） */
  const installedMods = parts.modFiles.size ? _installMods(parts.modFiles) : [];

  /* 一个新 saveId，绝不覆盖本地同名存档 */
  const newSaveId = 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  const dest = path.join(SAVES_DIR, newSaveId);
  fs.mkdirSync(dest, { recursive: true });

  const first = parts.saveFiles.values().next().value;
  for (const f of first) _writeEntryFile(dest, f.segs, f.data);

  /* world.json 里的 id 要改成新的，否则客户端会认错存档 */
  const wjPath = path.join(dest, 'world.json');
  let meta = {};
  if (fs.existsSync(wjPath)){
    try { meta = JSON.parse(fs.readFileSync(wjPath, 'utf8')); } catch(e){ meta = {}; }
  }
  meta.id = newSaveId;
  meta.lastPlayed = Date.now();
  if (!meta.name) meta.name = '导入的地图';
  meta.importedAt = Date.now();
  fs.writeFileSync(wjPath, JSON.stringify(meta, null, 2));

  console.log(`[map] 导入地图「${meta.name}」→ ${newSaveId}（附带 mod: ${installedMods.join(', ') || '无'}）`);
  return sendJson(res, 200, {
    ok: true,
    saveId: newSaveId,
    name: meta.name,
    mods: installedMods,
  });
}

async function handleExportMap(req, res){
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
  try {
    let body = {};
    try { body = JSON.parse((await readBodyText(req)) || '{}'); } catch(e){ body = {}; }

    const saveId = body.saveId;
    if (!saveId || !SAVE_ID_RE.test(saveId)) return sendJson(res, 400, { error: '存档 id 非法' });

    const srcSave = path.join(SAVES_DIR, saveId);
    if (!fs.existsSync(srcSave)) return sendJson(res, 404, { error: '存档不存在' });

    const wjPath = path.join(srcSave, 'world.json');
    let meta = {};
    if (fs.existsSync(wjPath)){
      try { meta = JSON.parse(fs.readFileSync(wjPath, 'utf8')); } catch(e){ meta = {}; }
    }
    const name = String(meta.name || saveId).replace(/[\\/:*?"<>|]/g, '_').slice(0, 40) || saveId;

    /* 存档目录整个打进去（连同它依赖的 mod：world.json.plugins） */
    const entries = [];
    _collectDir(srcSave, `saves/${saveId}/`, entries);

    const plugins = Array.isArray(meta.plugins) ? meta.plugins.filter(m => MOD_ID_RE.test(String(m))) : [];
    const packedMods = [];
    for (const id of plugins){
      const dir = path.join(MODS_DIR, id);
      if (!fs.existsSync(dir)) continue;
      _collectDir(dir, `mods/${id}/`, entries);
      packedMods.push(id);
    }

    if (body.withModpack !== false){
      entries.push({
        name: 'modpack.json',
        data: JSON.stringify({ name, mods: packedMods, saveId }, null, 2),
      });
    }

    return _streamZip(res, `${name}.zip`, entries);
  } catch(e){
    console.error('[export_map]', e);
    if (!res.headersSent) sendJson(res, 500, { error: e.message });
  }
}

const BUNDLE_MAGIC = [0x33, 0x44, 0x4D, 0x32];
async function handleChunkBundleApi(req, res, sid){
  if (!SAVE_ID_RE.test(sid || '') || req.method !== 'PUT') return sendJson(res, 400, { error: 'bad req' });
  let buf; try { buf = await readBodyBuffer(req); } catch(e){ return sendJson(res, 413, { error: 'too big' }); }
  if (!buf || buf.length < 8) return sendJson(res, 400, { error: 'short' });
  for (let i = 0; i < 4; i++) if (buf[i] !== BUNDLE_MAGIC[i]) return sendJson(res, 400, { error: 'magic' });
  
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const count = view.getUint16(6, true);
  if (count === 0 || count > 128) return sendJson(res, 400, { error: 'count' });
  
  const decoder = new TextDecoder(); let off = 8; const writes = [];
  for (let i = 0; i < count; i++){
    if (off + 13 > buf.length) return sendJson(res, 400, { error: 'trunc header' });
    const cx = view.getInt32(off, true); off += 4;
    const cz = view.getInt32(off, true); off += 4;
    const dimLen = buf[off]; off += 1;
    if (off + dimLen + 4 > buf.length) return sendJson(res, 400, { error: 'trunc dim' });
    const dim = decoder.decode(buf.subarray(off, off + dimLen)); off += dimLen;
    const dataLen = view.getUint32(off, true); off += 4;
    if (off + dataLen > buf.length) return sendJson(res, 400, { error: 'trunc data' });
    
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(dim)) return sendJson(res, 400, { error: 'bad dim' });
    
    const sub = (dim === 'overworld') ? 'chunks' : `dims/${dim}/chunks`;
    writes.push({
      filePath: path.join(SAVES_DIR, sid, sub, `${cx}_${cz}.bin.gz`),
      data: buf.subarray(off, off + dataLen),
    });
    off += dataLen;
  }
  
  await Promise.all(writes.map(async w => {
    try { await fs.promises.mkdir(path.dirname(w.filePath), { recursive: true }); await fs.promises.writeFile(w.filePath, w.data); }
    catch(e){ console.warn(`[bundle] write fail ${w.filePath}`, e); }
  }));
  return sendJson(res, 200, { ok: true, count: writes.length });
}

/* ============================================================
   Mods & Saves API
   ============================================================ */
async function handleModsApi(req, res, urlPath){
  let m = urlPath.match(/^\/api\/saves\/([^/]+)\/mods$/);
  if (m){
    const sid = m[1]; if (!SAVE_ID_RE.test(sid)) return sendJson(res, 400, { error: 'bad save id' });
    if (req.method !== 'GET') return sendJson(res, 405, { error: 'method' });
    const dataDir = path.join(SAVES_DIR, sid, 'data'); const out = [];
    if (fs.existsSync(dataDir)) for (const name of fs.readdirSync(dataDir)){
      if (!MOD_ID_RE.test(name)) continue; const full = path.join(dataDir, name);
      try { if (fs.statSync(full).isDirectory()) out.push({ id: name, size: dirSize(full) }); } catch(e){}
    }
    return sendJson(res, 200, out);
  }
  m = urlPath.match(/^\/api\/saves\/([^/]+)\/mods\/([^/]+)(\/.*)?$/);
  if (!m) return sendJson(res, 404, { error: 'unknown' });
  const sid = m[1], mid = m[2]; const rel = (m[3] || '').replace(/^\//, '');
  const full = resolveModPath(sid, mid, rel, (req.method === 'GET' || req.method === 'POST'));
  if (!full) return sendJson(res, 400, { error: 'bad path' });
  const root = path.resolve(SAVES_DIR, sid, 'data', mid);

  if (req.method === 'GET'){
    if (!fs.existsSync(full)) return sendJson(res, 404, { error: 'not found' });
    const st = fs.statSync(full);
    if (st.isDirectory()){
      const entries = [];
      for (const name of fs.readdirSync(full)){
        const p = path.join(full, name); let s; try { s = fs.statSync(p); } catch(e){ continue; }
        entries.push({ name, dir: s.isDirectory(), size: s.size, mtime: s.mtimeMs });
      }
      return sendJson(res, 200, { type: 'dir', entries });
    }
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': st.size });
    return fs.createReadStream(full).pipe(res);
  }
  if (req.method === 'PUT'){
    if (full === root) return sendJson(res, 400, { error: 'cannot write root' });
    let buf; try { buf = await readBodyBuffer(req); } catch(e){ return sendJson(res, 413, { error: 'big' }); }
    fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, buf);
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'POST'){ fs.mkdirSync(full, { recursive: true }); return sendJson(res, 200, { ok: true }); }
  if (req.method === 'DELETE'){
    if (full === root) return sendJson(res, 400, { error: 'root' });
    if (fs.existsSync(full)) fs.rmSync(full, { recursive: true, force: true });
    return sendJson(res, 200, { ok: true });
  }
  return sendJson(res, 405, { error: 'method' });
}

async function handleSavesApi(req, res, urlPath){
  const bm = urlPath.match(/^\/api\/saves\/([^/]+)\/chunks\/bundle$/);
  if (bm) return await handleChunkBundleApi(req, res, bm[1]);

  if (urlPath === '/api/saves'){
    if (req.method === 'GET'){
      const out = [];
      try { for (const name of fs.readdirSync(SAVES_DIR)){
        if (!SAVE_ID_RE.test(name)) continue;
        const p = path.join(SAVES_DIR, name, 'world.json');
        if (fs.existsSync(p)) try { out.push(JSON.parse(fs.readFileSync(p, 'utf8'))); } catch(e){}
      } } catch(e){}
      return sendJson(res, 200, out);
    }
    if (req.method === 'POST'){
      let body; try { body = JSON.parse(await readBodyText(req)); } catch(e){ return sendJson(res, 400, { error: 'bad json' }); }
      if (!SAVE_ID_RE.test(body.id || '')) return sendJson(res, 400, { error: 'bad id' });
      const dir = path.join(SAVES_DIR, body.id);
      if (fs.existsSync(dir)) return sendJson(res, 409, { error: 'exists' });
      for (const sub of ['lod', 'data', 'chunks', 'logs']) fs.mkdirSync(path.join(dir, sub), { recursive: true });
      const meta = (body.meta && typeof body.meta === 'object') ? body.meta : { id: body.id };
      meta.id = body.id; fs.writeFileSync(path.join(dir, 'world.json'), JSON.stringify(meta, null, 2));
      return sendJson(res, 200, { id: body.id });
    }
    return sendJson(res, 405, { error: 'method' });
  }

  if (/^\/api\/saves\/[^/]+\/mods(\/|$)/.test(urlPath)) return await handleModsApi(req, res, urlPath);

  let m = urlPath.match(/^\/api\/saves\/([^/]+)$/);
  if (m){
    const sid = m[1]; if (!SAVE_ID_RE.test(sid)) return sendJson(res, 400, { error: 'bad id' });
    if (req.method === 'DELETE'){ fs.rmSync(path.join(SAVES_DIR, sid), { recursive: true, force: true }); return sendJson(res, 200, { ok: true }); }
    return sendJson(res, 405, { error: 'method' });
  }

  m = urlPath.match(/^\/api\/saves\/([^/]+)\/(.+)$/);
  if (!m) return sendJson(res, 404, { error: 'unknown' });
  const sid = m[1], relName = m[2];
  if (!SAVE_ID_RE.test(sid)) return sendJson(res, 400, { error: 'bad id' });

  const segs = relName.split('/');
  for (const s of segs){
    if (!s || s === '.' || s === '..' || s.startsWith('.') || !FILE_NAME_RE.test(s)) return sendJson(res, 400, { error: 'bad path' });
  }
  const dir = path.join(SAVES_DIR, sid); if (!fs.existsSync(dir)) return sendJson(res, 404, { error: 'no save' });
  const filePath = path.join(dir, ...segs);
  if (!filePath.startsWith(dir + path.sep)) return sendJson(res, 403, { error: 'forbidden' });

  if (req.method === 'GET'){
    if (!fs.existsSync(filePath)) return sendJson(res, 404, { error: 'not found' });
    const st = fs.statSync(filePath); const mime = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Content-Length': st.size, 'Cache-Control': 'no-store' });
    return fs.createReadStream(filePath).pipe(res);
  }
  if (req.method === 'PUT'){
    let buf; try { buf = await readBodyBuffer(req); } catch(e){ return sendJson(res, 413, { error: 'big' }); }
    fs.mkdirSync(path.dirname(filePath), { recursive: true }); fs.writeFileSync(filePath, buf);
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'DELETE'){ if (fs.existsSync(filePath)) fs.unlinkSync(filePath); return sendJson(res, 200, { ok: true }); }
  sendJson(res, 405, { error: 'method' });
}

/* ============================================================
   静态文件处理 + ETag + 缓存
   ============================================================ */
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.gltf', '.xml', '.map', '.md']);
const COMPRESS_MIN_BYTES = 1024;
const _compCache = new Map(); const _COMP_CACHE_MAX = 96;

function _cacheSet(key, entry){ _compCache.delete(key); _compCache.set(key, entry); if (_compCache.size > _COMP_CACHE_MAX) _compCache.delete(_compCache.keys().next().value); }
function _cacheTouch(key, entry){ _compCache.delete(key); _compCache.set(key, entry); return entry; }
/* vendor 下的库文件给 7 天强缓存；但 three 的构建文件例外 ——
   升级 three 版本时文件名不变（three.module.js 内部还写死了 ./three.core.js），
   7 天缓存会让浏览器继续加载旧的 three.module.js 而拿不到新的 three.core.js，
   结果就是版本对不上 / 白屏。这类文件改成 no-cache，靠 ETag+Last-Modified 协商。 */
const _UNCACHED_JS = new Set(['three.module.js', 'three.core.js']);
function _cacheControlFor(filePath){
  if (_UNCACHED_JS.has(path.basename(filePath))) return 'no-cache';
  return filePath.includes(path.sep + 'vendor' + path.sep) ? 'public, max-age=604800' : 'no-cache';
}
function _notFound(res){ res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('404 Not Found'); }
function _pickEncoding(req, entry){
  const ae = String(req.headers['accept-encoding'] || '').toLowerCase();
  if (entry.br && ae.includes('br')) return { body: entry.br, enc: 'br' };
  if (entry.gz && ae.includes('gzip')) return { body: entry.gz, enc: 'gzip' };
  return { body: entry.raw, enc: null };
}
function _sendStatic(req, res, entry, meta){
  const pick = _pickEncoding(req, entry);
  const headers = { 'Content-Type': meta.mime, 'Content-Length': pick.body.length, 'Cache-Control': meta.cacheControl, 'ETag': meta.etag, 'Last-Modified': meta.lastModified };
  if (pick.enc) headers['Content-Encoding'] = pick.enc;
  headers['Vary'] = 'Accept-Encoding';
  res.writeHead(200, headers); res.end(req.method === 'HEAD' ? undefined : pick.body);
}

function serveStatic(req, res, filePath){
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) return _notFound(res);
    const ext = path.extname(filePath).toLowerCase();
    const meta = {
      mime: MIME[ext] || 'application/octet-stream',
      cacheControl: _cacheControlFor(filePath),
      etag: 'W/"' + st.size.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '-' + getCoreModsHash() + '"',
      lastModified: new Date(st.mtimeMs).toUTCString(),
    };

    const inm = req.headers['if-none-match'];
    const ims = req.headers['if-modified-since'];
    if ((inm && inm === meta.etag) || (!inm && ims && ims === meta.lastModified)){
      res.writeHead(304, { 'ETag': meta.etag, 'Last-Modified': meta.lastModified, 'Cache-Control': meta.cacheControl }); return res.end();
    }

    /* ★ src/*.js 以前被特意排除在缓存外（担心注入内容变化），
       结果每次刷新都要重新读盘 + brotli q9 重压（实测 40 个模块 891ms）。
       现在缓存起来，用 mtime + size + coremods 哈希三重校验，
       改文件 / 换 coremod 都会自动失效。 */
    const _origSize = st.size;
    const _coreHash = getCoreModsHash();
    const cached = _compCache.get(filePath);
    if (cached && cached.mtimeMs === st.mtimeMs && cached.size === _origSize && cached.coreHash === _coreHash){
      if (cached.etag) meta.etag = cached.etag;
      return _sendStatic(req, res, _cacheTouch(filePath, cached), meta);
    }

    fs.readFile(filePath, (err2, data) => {
      if (err2) return _notFound(res);
      
      if (filePath.endsWith('.js')) {
        try {
          const src = data.toString('utf8'); const injected = injectCode(src, filePath);
          if (injected !== src) {
            data = Buffer.from(injected, 'utf8');
            /* ★ 不能再把 st.size 改成注入后的长度：缓存校验要拿磁盘上的原始大小比对，
               改了以后永远不命中（这也是当初 src 被排除在缓存外的真正原因）。 */
            meta.etag = 'W/"' + data.length.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '-injected"';
          }
        } catch(e) { console.warn('[inject] 失败:', e); }
      }

      if (!COMPRESSIBLE.has(ext) || data.length < COMPRESS_MIN_BYTES){
        const entry = { mtimeMs: st.mtimeMs, size: _origSize, raw: data, gz: null, br: null,
                        coreHash: _coreHash, etag: meta.etag };
        _cacheSet(filePath, entry);
        return _sendStatic(req, res, entry, meta);
      }

      zlib.gzip(data, { level: 6 }, (errGz, gz) => {
        /* ★ 质量 9 → 6：实测 main.js(72KB) 22.8ms→8.5ms，体积只大 5%。
       而且服务端和浏览器很多时候是同一台手机，压缩省下的带宽没意义。 */
      const _brQ = Number(process.env.BROTLI_QUALITY || 6) || 6;
      zlib.brotliCompress(data, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: _brQ, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: data.length } }, (errBr, br) => {
          const entry = { mtimeMs: st.mtimeMs, size: _origSize, raw: data, gz: errGz ? null : gz, br: errBr ? null : br,
                          coreHash: _coreHash, etag: meta.etag };
          _cacheSet(filePath, entry);
          _sendStatic(req, res, entry, meta);
        });
      });
    });
  });
}

/* ============================================================
   Index.html 注入 (Atlas + Coremods)
   ============================================================ */
let _indexCache = null;          /* { stamp, etag, gz, raw } */
let _indexServeLog = 0;

function _indexStamp(filePath){
  let st;
  try { st = fs.statSync(filePath); } catch(e){ return null; }
  return st.mtimeMs + '|' + st.size + '|' + getCoreModsHash() + '|' + listModsCached().length;
}

function serveIndexWithInject(req, res, filePath){
  const stamp = _indexStamp(filePath);
  if (!stamp) return serveStatic(req, res, filePath);

  /* ★ 缓存注入后的 HTML：每刷新一次重新读文件 + 算 atlas 配置 + 扫 coremods
     是纯浪费（实测 ~10ms/次），而 index.html 是首屏第一个请求。
     用 mtime+size+coremods+mods 数量做校验，改任何一样都自动失效。 */
  if (!_indexCache || _indexCache.stamp !== stamp){
    let html; try { html = fs.readFileSync(filePath, 'utf8'); }
    catch(e){ return serveStatic(req, res, filePath); }

    let headInject = ''; let bodyInject = '';
    try {
      const cfg = computeAtlasConfig();
      headInject += `<script>window.__ATLAS_CONFIG__ = ${JSON.stringify(cfg)};</script>\n`;
      if (Date.now() - _indexServeLog > 5000){
        _indexServeLog = Date.now();
        console.log(`[atlas] 注入配置: cols=${cfg.cols} tiles=${cfg.tiles} (mod 需求 ${cfg.modNeeds})`);
      }
    } catch(e){ console.warn('[atlas] 注入失败:', e); }

    try {
      const cms = listCoreModsCached();
      if (cms.length > 0) {
        headInject += `<script>window.__COREMODS__ = ${JSON.stringify(cms)};</script>\n`;
        for (const cm of cms) if (cm.entry) bodyInject += `<script src="/coremods/${cm.id}/${cm.entry}"></script>\n`;
      }
    } catch(e) { console.warn('[coremods] 注入失败:', e); }

    if (headInject) html = html.replace('</head>', headInject + '</head>');
    if (bodyInject) html = html.replace('</body>', bodyInject + '</body>');

    const buf = Buffer.from(html, 'utf8');
    _indexCache = {
      stamp,
      etag: 'W/"idx-' + buf.length.toString(16) + '-' + Math.floor(buf.length * 31 + stamp.length).toString(16) + '"',
      raw: buf,
      gz: null,
    };
  }

  const c = _indexCache;
  const etag = c.etag;
  const inm = req.headers['if-none-match'];
  if (inm && inm === etag){
    res.writeHead(304, { 'ETag': etag, 'Cache-Control': 'no-cache' });
    return res.end();
  }

  const wantsGzip = String(req.headers['accept-encoding'] || '').includes('gzip');
  const send = (body, enc) => {
    const headers = {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-cache',
      'ETag': etag,
    };
    if (enc) headers['Content-Encoding'] = enc;
    res.writeHead(200, headers);
    res.end(body);
  };

  if (!wantsGzip || c.raw.length < COMPRESS_MIN_BYTES) return send(c.raw, null);
  if (c.gz) return send(c.gz, 'gzip');
  zlib.gzip(c.raw, { level: 6 }, (e, gz) => {
    if (e) return send(c.raw, null);
    c.gz = gz;
    send(gz, 'gzip');
  });
}

/* ============================================================
   服务器入口
   ============================================================ */
const _httpServer = http.createServer(async (req, res) => {
  let urlPath;
  try { urlPath = decodeURIComponent(req.url.split('?')[0]); } catch(e){ urlPath = req.url.split('?')[0]; }

  if (urlPath === '/api/gen-chunk') return await handleGenChunkApi(req, res);
  
  if (urlPath === '/api/mods'){
    if (req.method === 'GET') return sendJson(res, 200, listModsCached());
    return sendJson(res, 405, { error: 'method' });
  }
  if (urlPath === '/api/hooks'){
    if (req.method === 'GET') return sendJson(res, 200, scanHooks());
    return sendJson(res, 405, { error: 'method' });
  }
  if (urlPath === '/api/coremods') {
    if (req.method === 'GET') return sendJson(res, 200, listCoreMods());
    return sendJson(res, 405, { error: 'method' });
  }
  if (urlPath === '/api/coremods/validate') {
    return await handleCoremodValidateApi(req, res);
  }
  if (urlPath === '/api/import-map') {
    return await handleImportMap(req, res);
  }
  if (urlPath === '/api/export-map') {
    return await handleExportMap(req, res);
  }
  if (urlPath === '/api/import-modpack') {
    return await handleImportModpack(req, res);
  }
  if (urlPath === '/api/export-modpack') {
    return await handleExportModpack(req, res);
  }
  if (urlPath === '/api/atlas-config'){
    if (req.method === 'GET') return sendJson(res, 200, computeAtlasConfig());
    return sendJson(res, 405, { error: 'method' });
  }
  /* ★ 背景音乐导出：把浏览器里预渲染好的 WAV 存到 3dmc/music/ */
  if (urlPath === '/api/music/save'){
    if (req.method !== 'POST') return sendJson(res, 405, { error: 'method' });
    let name = '';
    try { name = new URL(req.url, 'http://localhost').searchParams.get('name') || ''; } catch(e){}
    if (!/^[A-Za-z0-9_\-\u4e00-\u9fa5 .]{1,64}\.wav$/.test(name) || name.indexOf('..') >= 0){
      return sendJson(res, 400, { error: 'bad name' });
    }
    let buf;
    try { buf = await readBodyBuffer(req); }
    catch(e){ return sendJson(res, 413, { error: 'too big' }); }
    try {
      const dir = path.join(ROOT, 'music');
      fs.mkdirSync(dir, { recursive: true });
      const full = path.join(dir, name);
      fs.writeFileSync(full, buf);
      return sendJson(res, 200, { ok: true, path: path.relative(ROOT, full), size: buf.length });
    } catch(e){ return sendJson(res, 500, { error: e.message }); }
  }

  if (urlPath.startsWith('/api/log/')) { try { return await handleLogApi(req, res, urlPath); } catch(e){ return sendJson(res, 500, { error: e.message }); } }
  if (urlPath.startsWith('/api/diag/')) { try { return await handleDiagApi(req, res, urlPath); } catch(e){ return sendJson(res, 500, { error: e.message }); } }

  // 静态资源拦截
  if (urlPath.startsWith('/mods/')){
    const segs = urlPath.slice(6).split('/').filter(Boolean);
    if (!segs.length) return sendJson(res, 400, { error: 'bad path' });
    for (const s of segs) if (s === '.' || s === '..' || s.startsWith('.')) return sendJson(res, 400, { error: 'bad path' });
    const filePath = path.resolve(MODS_DIR, ...segs);
    if (filePath !== MODS_DIR && !filePath.startsWith(MODS_DIR + path.sep)) return sendJson(res, 403, { error: 'forbidden' });
    return serveStatic(req, res, filePath);
  }

  if (urlPath.startsWith('/coremods/')){
    const segs = urlPath.slice(10).split('/').filter(Boolean);
    if (!segs.length) return sendJson(res, 400, { error: 'bad path' });
    for (const s of segs) if (s === '.' || s === '..' || s.startsWith('.')) return sendJson(res, 400, { error: 'bad path' });
    const filePath = path.resolve(COREMODS_DIR, ...segs);
    if (filePath !== COREMODS_DIR && !filePath.startsWith(COREMODS_DIR + path.sep)) return sendJson(res, 403, { error: 'forbidden' });
    return serveStatic(req, res, filePath);
  }

  if (urlPath.startsWith('/api/saves')){
    try { return await handleSavesApi(req, res, urlPath); } catch(e){ return sendJson(res, 500, { error: e.message }); }
  }

  let staticPath = urlPath;
  if (staticPath === '/') staticPath = '/index.html';
  const filePath = path.resolve(ROOT, '.' + staticPath);
  if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('403'); }
  if (filePath.startsWith(SAVES_DIR + path.sep) || filePath.startsWith(MODS_DIR + path.sep) || filePath.startsWith(COREMODS_DIR + path.sep)) { res.writeHead(403); return res.end('403'); }

  /* 本地缺文件时兜底走 CDN（r187：core 文件单独兜底，否则 module 会 404 它的 import） */
  if (staticPath === THREE_LOCAL && !fs.existsSync(filePath)) { res.writeHead(302, { 'Location': THREE_CDN }); return res.end(); }
  if (staticPath === THREE_CORE_LOCAL && !fs.existsSync(filePath)) { res.writeHead(302, { 'Location': THREE_CORE_CDN }); return res.end(); }
  if (path.basename(filePath) === 'index.html') return serveIndexWithInject(req, res, filePath);

  return serveStatic(req, res, filePath);

});

_httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`  ✔ 服务器已启动，监听 0.0.0.0:${PORT}`);
  console.log(`    coremods/ : ${COREMODS_DIR}`);
  console.log(`    gen   : /api/gen-chunk  POST (服务端地形生成)`);
});


/* ============================================================
   ★ 进程生命周期管理（解决「关了服务器端口还被占用」）
   ------------------------------------------------------------
   问题现象：Ctrl+C / 关掉 Termux 之后，8080 端口仍然被占，
             再启动就 EADDRINUSE，杀不掉还得手动找 pid。
   实际原因有 3 个，全部在这里处理：
     1. Termux 终端被系统回收，node 变成孤儿进程继续跑（不是真僵尸，
        但同样占着端口）—— 父进程消失就自动退出。
     2. keep-alive 长连接让进程迟迟不退出 —— 关闭时强杀所有 socket。
     3. 上一次残留的服务器还活着 —— 启动时自动识别并结束它。
   ============================================================ */
const _sockets = new Set();
_httpServer.on('connection', s => {
  _sockets.add(s);
  s.on('close', () => _sockets.delete(s));
});

const PID_FILE = path.join(__dirname, '.server.pid');
let _closing = false;

function _writePidFile(){
  try { fs.writeFileSync(PID_FILE, String(process.pid)); } catch(e){}
}
function _removePidFile(){
  try { fs.unlinkSync(PID_FILE); } catch(e){}
}

function shutdownServer(reason, code){
  if (_closing) return;
  _closing = true;
  console.log('\n[server] 正在关闭：' + reason);
  try { _httpServer.close(); } catch(e){}
  try { if (_httpServer.closeAllConnections) _httpServer.closeAllConnections(); } catch(e){}
  for (const s of _sockets){ try { s.destroy(); } catch(e){} }
  _sockets.clear();
  _removePidFile();
  /* 给 stdout 一点时间刷出去，然后硬退出（不等 keep-alive 自然超时） */
  setTimeout(() => process.exit(code || 0), 80);
}
globalThis.__shutdownServer__ = shutdownServer;

for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']){
  try {
    process.on(sig, () => shutdownServer('收到信号 ' + sig, 0));
  } catch(e){}
}
process.on('uncaughtException', e => {
  console.error('[server] 未捕获异常:', e && e.stack || e);
  shutdownServer('未捕获异常', 1);
});

/* ---- 孤儿自动回收：父进程没了就自己退出 ---- */
function _readPpid(){
  try {
    const st = fs.readFileSync('/proc/self/stat', 'utf8');
    /* comm 里可能有空格和括号，取最后一个 ')' 之后再切 */
    const rest = st.slice(st.lastIndexOf(')') + 2).split(' ');
    const p = parseInt(rest[1], 10);
    return isNaN(p) ? 0 : p;
  } catch(e){ return 0; }
}
const _startPpid = _readPpid();
if (_startPpid > 1 && process.env.NO_PARENT_WATCH !== '1'){
  const _watch = setInterval(() => {
    const p = _readPpid();
    if (!p) return;
    if (p !== _startPpid){
      clearInterval(_watch);
      shutdownServer('父进程已消失（终端被关闭/BACKGROUND 回收），自动退出以释放端口', 0);
    }
  }, 3000);
  try { _watch.unref && _watch.unref(); } catch(e){}
}

/* ---- 列出 3dmc 服务器进程 ----
   ★ 不用 /proc/net/tcp：Android 非 root 下它和 ss/lsof 都是 Permission denied，
     唯一可靠的是「同 uid 的 /proc/<pid>/cmdline」+「TCP connect 探测」。
*/
function listServerProcs(){
  const out = [];
  let pids = [];
  try { pids = fs.readdirSync('/proc').filter(d => /^\d+$/.test(d)); } catch(e){ return out; }
  for (const pidStr of pids){
    let raw = '';
    try { raw = fs.readFileSync('/proc/' + pidStr + '/cmdline', 'utf8'); } catch(e){ continue; }
    if (!raw) continue;
    const argv = raw.split('\0').filter(Boolean);
    if (!argv.length) continue;
    const hit = argv.some(a => /(?:^|[\/\\])(?:server\.js|server\.py|server_cpp|3dmc_server_cpp)$/.test(a));
    if (!hit) continue;
    out.push({ pid: Number(pidStr), cmd: argv.join(' ') });
  }
  return out;
}
globalThis.__listServerProcs__ = listServerProcs;

/* 端口是否真的有人在听（TCP 连接探测，成功=被占用） */
function probePort(port, cb){
  const net = require('net');
  const sock = net.connect({ port: Number(port), host: '127.0.0.1' });
  let done = false;
  const fin = busy => {
    if (done) return;
    done = true;
    try { sock.destroy(); } catch(e){}
    cb(busy);
  };
  sock.setTimeout(700, () => fin(false));
  sock.on('connect', () => fin(true));
  sock.on('error', () => fin(false));
}

/* ---- 端口被占用：先认领并结束「自己的残留」，再报错 ---- */
let _portRetry = 0;
_httpServer.on('error', err => {
  if (!err || err.code !== 'EADDRINUSE'){
    console.error('[server] 监听出错:', err && err.message);
    return;
  }
  const port = Number(PORT);
  const others = listServerProcs().filter(x => x.pid !== process.pid);

  if (others.length && _portRetry < 3 && process.env.NO_AUTO_KILL !== '1'){
    _portRetry++;
    for (const x of others){
      console.log(`  ⚠ 发现上次没退干净的服务器 pid=${x.pid}「${x.cmd}」，自动结束它…`);
      try { process.kill(x.pid, 'SIGKILL'); } catch(e){}
    }
    setTimeout(() => {
      try { _httpServer.listen(port, '0.0.0.0'); }
      catch(e){ console.error('[server] 重试监听失败:', e.message); process.exit(1); }
    }, 500);
    return;
  }

  probePort(port, busy => {
    console.error('');
    console.error(`  ✘ 端口 ${port} 已被占用${busy ? '（端口有响应）' : ''}`);
    if (others.length){
      for (const x of others) console.error(`     残留服务器: pid=${x.pid}  ${x.cmd}`);
      console.error(`     结束它: kill -9 ${others.map(x => x.pid).join(' ')}`);
    } else {
      console.error('     没找到 3dmc 服务器进程 —— 可能是别的程序占着');
      console.error('     （Android 非 root 读不到 /proc/net/tcp，拿不到对方 pid）');
    }
    console.error(`     一键清端口: bash stop.sh ${port}`);
    console.error(`     换端口:     PORT=8081 bash start.sh node`);
    console.error('');
    process.exit(1);
  });
});


/* ---- 可选：孤儿进程空闲自杀 ----
   如果服务器是「启动它的 shell 已经没了」(ppid==1) 的状态，
   并且连续 IDLE_EXIT_MIN 分钟没有任何请求，就自己退出。
   默认关闭；想用就 IDLE_EXIT_MIN=30 bash start.sh node */
const IDLE_EXIT_MIN = Number(process.env.IDLE_EXIT_MIN || 0);
if (IDLE_EXIT_MIN > 0){
  let _lastActive = Date.now();
  _httpServer.on('request', () => { _lastActive = Date.now(); });
  const _idleTimer = setInterval(() => {
    if (_readPpid() !== 1) return;                       /* 父进程还在，别管 */
    if (Date.now() - _lastActive < IDLE_EXIT_MIN * 60000) return;
    clearInterval(_idleTimer);
    shutdownServer(`孤儿进程空闲超过 ${IDLE_EXIT_MIN} 分钟，自动退出`, 0);
  }, 60000);
  try { _idleTimer.unref && _idleTimer.unref(); } catch(e){}
}

_writePidFile();

/* ============================================================
   ★ 启动后台预热静态文件缓存
   ------------------------------------------------------------
   冷启动时第一个访问者要等所有文件现场压缩（40 个模块 ≈ 1.7 秒，
   其中 three.module.js 一个就要 240ms）。这里启动后分片地把它们
   预先压好，玩家打开页面时全是缓存命中（≈200ms）。
   用 HTTP 自请求走正常代码路径，不用另写一份压缩逻辑。
   关掉：WARM_CACHE=0 bash start.sh node
   ============================================================ */
function warmStaticCache(){
  if (process.env.WARM_CACHE === '0') return;
  const files = [];
  try {
    const walk = (d) => {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) walk(p);
        else if (/\.(js|css|json|html)$/.test(e.name)) files.push(p);
      }
    };
    walk(path.join(ROOT, 'src'));
    files.push(path.join(ROOT, 'index.html'));
  } catch(e){ return; }
  if (!files.length) return;

  let i = 0, done = 0;
  const t0 = Date.now();
  const step = () => {
    const sliceStart = Date.now();
    while (i < files.length && Date.now() - sliceStart < 12) {
      const rel = '/' + path.relative(ROOT, files[i++]).replace(/\\/g, '/');
      fetch(`http://127.0.0.1:${PORT}${rel}`, { headers: { 'Accept-Encoding': 'br' } })
        .then(r => r.arrayBuffer())
        .then(() => { done++; })
        .catch(() => {});
    }
    if (i < files.length) setTimeout(step, 40);
    else setTimeout(() => console.log(`  ✔ 静态缓存预热完成：${done}/${files.length} 个文件，用时 ${Date.now() - t0} ms`), 300);
  };
  setTimeout(step, 400);
}
warmStaticCache();

