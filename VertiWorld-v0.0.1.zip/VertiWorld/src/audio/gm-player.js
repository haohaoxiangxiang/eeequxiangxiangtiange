/**
 * gm-player.js —— 精简 GM 音色播放器（本项目自行实现）
 * ============================================================
 * 用途：只给 music.js 的离线预渲染用。播放的是缓存好的 wav，
 *       所以这里不需要实时调度、不需要锁、不需要 resume。
 *
 * 它只做两件事：
 *   1) 把音色数据里的 base64 采样解码成 AudioBuffer
 *   2) 按目标音高与采样根音的音程差调整播放速率，套一个包络放出去
 *
 * 音色数据格式（vendor/webaudiofont/sound/*.js）：
 *   { zones: [ { midi, originalPitch, keyRangeLow, keyRangeHigh,
 *                loopStart, loopEnd, coarseTune, fineTune,
 *                sampleRate, ahdsr, file: <base64 采样> } ] }
 *
 * ★ 独立性说明：本文件是独立实现。唯一沿用的做法是数字音频采样的
 *   通用音高换算公式  速率 = 2^((目标音高 - 采样根音 + 微调) / 12)，
 *   这是采样器几十年的公共做法，不来自任何具体实现的代码。
 *   上游 WebAudioFontPlayer.js 为 GPL-3.0，本项目未复制其代码。
 * ============================================================
 */

/* 包络默认值（秒）。钢琴/定音鼓这类打击性音色靠采样自身的衰减，
   这里只负责"起音不要爆、收尾不要断"。 */
const ATTACK  = 0.012;
const RELEASE = 0.22;
const MIN_LEN = 0.05;

/* base64 → ArrayBuffer（不依赖 fetch，离线上下文里也能用） */
function base64ToBuffer(b64){
  const bin = atob(b64);
  const n = bin.length;
  const u8 = new Uint8Array(n);
  for (let i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
  return u8.buffer;
}

function looksLikeBase64(s){
  if (typeof s !== 'string' || s.length < 32) return false;
  if (/^data:/i.test(s)) return false;
  if (/^https?:|^\.?\.?\//i.test(s)) return false;
  return /^[A-Za-z0-9+/=\s]+$/.test(s.slice(0, 128));
}

export class GmPlayer {
  constructor(opts){
    this.attack  = (opts && opts.attack)  || ATTACK;
    this.release = (opts && opts.release) || RELEASE;
  }

  /* 解码一个 preset 里所有还没解码的 zone。
     music.js 的 _waitPreset() 靠轮询 zone.buffer 判断完成，
     所以这里只管把 buffer 填上，不需要返回 Promise。 */
  adjustPreset(ctx, preset){
    if (!ctx || !preset || !Array.isArray(preset.zones)) return 0;
    let started = 0;
    for (const z of preset.zones){
      if (!z || z.buffer || z.__decoding) continue;
      const f = z.file;
      if (!f) continue;
      z.__decoding = true;
      started++;

      const settle = (buf) => {
        z.__decoding = false;
        if (buf) z.buffer = buf;
      };

      try {
        let ab;
        if (looksLikeBase64(f)){
          ab = base64ToBuffer(f.replace(/\s+/g, ''));
        } else {
          /* 少数数据文件里 file 是 URL/dataURI，这条分支留作兼容 */
          z.__decoding = false;
          continue;
        }
        const p = ctx.decodeAudioData(ab,
          (buf) => settle(buf),
          () => settle(null));
        if (p && typeof p.then === 'function') p.then(settle, () => settle(null));
      } catch (e){
        z.__decoding = false;
      }
    }
    return started;
  }

  /* 排一个音符。返回本次真正发出的 voice 数（music.js 不关心返回值，
     有这个数字方便自测）。 */
  queueWaveTable(ctx, target, preset, when, midi, len, vol){
    if (!ctx || !target || !preset || !Array.isArray(preset.zones)) return 0;
    const note = Number(midi);
    if (!isFinite(note)) return 0;
    const lenSec = Math.max(MIN_LEN, Number(len) || 0);
    const t0 = Math.max(0, Number(when) || 0);
    const peak = Math.max(0.0001, (vol == null ? 1 : Number(vol)));

    let voices = 0;
    for (const z of preset.zones){
      if (!z || !z.buffer) continue;
      const lo = (z.keyRangeLow  == null) ? 0   : z.keyRangeLow;
      const hi = (z.keyRangeHigh == null) ? 127 : z.keyRangeHigh;
      if (note < lo || note > hi) continue;
      this._voice(ctx, target, z, t0, note, lenSec, peak);
      voices++;
    }
    return voices;
  }

  _voice(ctx, target, z, t0, note, lenSec, peak){
    const buf = z.buffer;

    /* ---- 音高 ---- */
    const root   = (z.originalPitch == null) ? note : (z.originalPitch / 100);
    const cents  = (Number(z.coarseTune) || 0) * 100 + (Number(z.fineTune) || 0);
    const semis  = (note - root) + cents / 100;
    const rate   = Math.pow(2, semis / 12);

    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate;

    /* ---- 循环点 ----
       数据里的 loopStart/loopEnd 是按采样原始采样率记录的第几帧；
       解码时音频被重采样到上下文采样率，帧号要按比例换算。 */
    const srcRate = Number(z.sampleRate) || buf.sampleRate || ctx.sampleRate;
    const rs      = (srcRate > 0 && buf.sampleRate > 0) ? (buf.sampleRate / srcRate) : 1;
    const lsF     = Math.max(0, Math.round((Number(z.loopStart) || 0) * rs));
    const leF     = Math.min(buf.length, Math.round((Number(z.loopEnd) || 0) * rs));
    if (leF > lsF + 64 && buf.length > leF + 1){
      src.loop      = true;
      src.loopStart = lsF / buf.sampleRate;
      src.loopEnd   = leF / buf.sampleRate;
    }

    /* ---- 包络：起音 → 保持 → 释放 ---- */
    const atk   = Math.min(this.attack, lenSec * 0.25);
    const rel   = Math.min(this.release, Math.max(0.04, lenSec * 0.6));
    const tEnd  = t0 + Math.max(atk, lenSec);

    const g = ctx.createGain();
    const gp = g.gain;
    gp.setValueAtTime(0.0001, t0);
    gp.linearRampToValueAtTime(peak, t0 + atk);
    gp.setValueAtTime(peak, tEnd);
    gp.linearRampToValueAtTime(0.0001, tEnd + rel);

    src.connect(g);
    g.connect(target);
    src.start(t0);
    src.stop(tEnd + rel + 0.02);
    return src;
  }
}

export default GmPlayer;
