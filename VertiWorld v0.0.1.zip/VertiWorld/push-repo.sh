#!/usr/bin/env bash
# ============================================================
#  push-repo.sh —— 把当前目录（VertiWorld 源码）同步到你自己的仓库
#  ------------------------------------------------------------
#  ★ 这个脚本的核心作用：把远端仓库"清成"和本地目录完全一致。
#    远端有、本地没有的文件 → 自动变成一次删除提交
#    本地有、远端没有的文件 → 自动新增
#    所以你不用一个一个去网页上点删除。
#
#  用法（在 Termux 里）：
#     bash push-repo.sh https://github.com/你的用户名/VertiWorld.git
#     bash push-repo.sh https://gitee.com/你的用户名/vertiworld.git
#     bash push-repo.sh <地址> <分支名>      # 分支名可省，脚本会自动探测
#
#  ★ 认证：
#     GitHub 现在【不能用密码】推代码，必须先建 Personal Access Token：
#       网页 → Settings → Developer settings → Personal access tokens
#              → Tokens (classic) → Generate new token → 勾选 repo
#       然后用户名填 GitHub 用户名，密码处粘贴这个 ghp_xxx 令牌。
#     Gitee：用户名 + 密码（或 私人令牌）即可。
#     Termux 里第一次输入后 git 会记住（credential.helper store）。
# ============================================================
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
URL="${1:-}"
BRANCH_ARG="${2:-}"

if [ -z "$URL" ]; then
  sed -n '2,25p' "$0" | sed 's/^# \{0,1\}//'
  exit 1
fi

cd "$DIR"
echo "仓库目录: $DIR"

# 外部存储上 owner 不是当前用户，git 会报 dubious ownership
git config --global --add safe.directory "$DIR" 2>/dev/null || true
[ -n "$(git config --global user.name  || true)" ] || git config --global user.name  "VertiWorld"
[ -n "$(git config --global user.email || true)" ] || git config --global user.email "vertiworld@local"
git config --global credential.helper store

[ -d .git ] || git init -q

git remote remove origin 2>/dev/null || true
git remote add origin "$URL"

# ---- 探测远端默认分支 ----
BRANCH="$BRANCH_ARG"
if [ -z "$BRANCH" ]; then
  BRANCH=$(git ls-remote --symref origin HEAD 2>/dev/null \
            | awk '/^ref:/{print $2}' | sed 's#refs/heads/##' | head -1)
fi
[ -n "$BRANCH" ] || BRANCH="main"
echo "目标分支: $BRANCH"

# ---- 拉远端历史（仓库是空的就跳过）----
if git fetch origin "$BRANCH" 2>/dev/null && git rev-parse --verify -q FETCH_HEAD >/dev/null; then
  echo "远端已有内容：先对齐历史，再让本地目录覆盖它"
  # ★ 用 mixed reset 而不是 checkout：
  #   只动索引，工作树一个字节都不碰，不会因为"未跟踪文件会被覆盖"而报错。
  #   对齐之后 git add -A 就会把"远端有、本地没有"的文件记成删除。
  git reset -q FETCH_HEAD
else
  echo "远端是空的（或者是第一次推），走新建分支"
fi

# ---- 暂存（.gitignore 会过滤掉构建产物 / 存档 / 渲染出来的曲子）----
git add -A

if git diff --cached --quiet; then
  echo "没有需要提交的变化，结束"
  exit 0
fi

CHANGED=$(git diff --cached --name-status | wc -l)
echo "本次提交涉及 $CHANGED 个文件"
git diff --cached --name-status | awk '{print $1}' | sort | uniq -c | sed 's/^/  /'

git commit -q -m "sync: VertiWorld ${BRANCH} · $(date '+%Y-%m-%d %H:%M')"
echo "已提交。开始推送（会提示输入用户名 / 令牌）..."
git push -u origin "HEAD:$BRANCH"
echo
echo "✔ 完成：$URL（分支 $BRANCH）"
