/* ============================================================
   terrain.js —— 世界数据管理（主线程）
   ------------------------------------------------------------
   ★ 本轮改动：
     · chunk 对象透传 tintMapGrass / tintMapFoliage
     · _onWorkerChunkReady / _applyGenData / _loadOrGenerate 全部同步
     · 保留磁盘缓存、多维度、edits、fluid 打包等所有原有能力
   ============================================================ */

import { CS, CHH, SEA_LEVEL, BIOME, idx, WORLD_TYPE,
         Y_MIN, COL_H, getActiveDimension } from './../core/engine-core.js';
import { B, BLOCKS } from './blocks.js';
import { TEX, UVRECT } from './textures.js';
import {
  setChunkDbSaveId,
  getDiskCacheEnabled,
  hasSaveId,
  queueSaveChunk,
  loadChunkFromDisk,
  setOnChunkPersisted,
  flushSaveQueue,
} from './world-core.js';
import { defineHook, emit } from './../core/engine-core.js';

import {
  registerGenerator,
  getGenerator,
  getActiveGenerator,
  getActiveGeneratorId,
  setActiveGenerator,
  listGenerators,
  getDeclaredWorldType,
} from './world-meta.js';
import {
  registerBiome,
  getBiome,
  getBiomeByName,
  listBiomes,
  listBiomesSerializable,
} from './world-core.js';

import { BUILTIN_GENERATORS } from './core/terrain-params.js';
import { createWorldGen }     from './core/world-gen.js';
import { computeChunkLight, lightOnBlockChange, propagateChunkLight } from './light.js';

import { getPool } from '../worker/pool.js';
import { MSG }     from './../worker/pool.js';
import { FLAGS }   from './../worker/pool.js';

export { setChunkDbSaveId, flushSaveQueue };

const FL_LEVEL = 0x0F, FL_SRC = 0x10, FL_TSRC = 0x20, FL_FALL = 0x40;
const FLUID_FULL = 8;   /* 满液位：非源头水最多 7，源头/下落水为 8 */

const _SAB_CTOR = (typeof SharedArrayBuffer !== 'undefined')
  ? SharedArrayBuffer : null;
const _isSAB = (view) => {
  return _SAB_CTOR && view && view.buffer instanceof _SAB_CTOR;
};

export function chunkCellCount(){
  return CS * CS * COL_H;
}

/* ============================================================
   方块名 → id
   ============================================================ */
let _blockIdsCache = null;
function _getBlockIds(){
  if (_blockIdsCache) return _blockIdsCache;
  _blockIdsCache = {};
  for (const b of BLOCKS){
    if (b && b.name) _blockIdsCache[b.name] = b.id;
  }
  return _blockIdsCache;
}

/* ============================================================
   全局状态
   ============================================================ */
let worldType = WORLD_TYPE.VANILLA;
let worldSeed = 12345;
let templePos = null;
let lostCityPos = null;
let _seasonPhaseGlobal = 0;   /* 季节相位 [0,1)，见 setSeasonPhase */

let onBlockChangedCb = null;
export function setOnBlockChanged(fn){ onBlockChangedCb = fn; }

let onFluidWakeCb = null;
export function setOnFluidWake(fn){ onFluidWakeCb = fn; }

let _recording = true;
export function setRecording(on){ _recording = !!on; }
export function isRecording(){ return _recording; }

let _freedChunks = 0;
export function getEvictedCount(){ return _freedChunks; }

export function bytesPerChunk(){
  const cells = CS * CS * COL_H;
  return cells * 2 + 512;
}

export function getResidentBytes(){
  let n = 0;
  for (const c of getChunksMap().values()){
    n += bytesPerChunk();
    if (c.fluidTimer) n += c.fluidTimer.length;
  }
  return n;
}

export function checkMemoryPressure(){ return false; }

export function getChunkStats(){
  let meshBytes = 0;
  const map = getChunksMap();
  for (const c of map.values()) meshBytes += c.meshBytes || 0;
  const per = bytesPerChunk();
  return {
    active: map.size,
    prefetching: 0,
    perChunkMB: per / 1048576,
    residentMB: getResidentBytes() / 1048576,
    budgetMB: 0,
    blocksMB: (map.size * per) / 1048576,
    meshMB: meshBytes / 1048576,
    evicted: _freedChunks,
  };
}

/* ============================================================
   多维度 chunk 存储
   ============================================================ */
const _dimChunks = new Map();

function _getMap(dim){
  let m = _dimChunks.get(dim);
  if (!m){ m = new Map(); _dimChunks.set(dim, m); }
  return m;
}

function _activeMap(){
  return _getMap(getActiveDimension());
}

/* 让 light.js 能从别处拿到 chunks map */
try {
  if (typeof globalThis !== 'undefined') {
    globalThis.__terrainGetChunksMap = () => _activeMap();
  }
} catch(e){}

/* ★ 区块 ready 时的外部回调（天气系统用它把地表雪一次性铺好）。
   特意做成注入而不是直接 import weather.js —— 那会形成
   terrain ⇄ weather 的循环依赖，正是之前把整个游戏搞崩的那类问题。 */
let _onChunkReadyCb = null;
export function setOnChunkReady(cb){ _onChunkReadyCb = cb; }

/* ★ 区块 ready 后让流体系统唤醒区块内的水体（避免自然生成的水不流动）。
   与 _onChunkReadyCb 分开：那个已被天气系统占用。 */
let _onChunkFluidCb = null;
export function setOnChunkFluidReady(cb){ _onChunkFluidCb = cb; }

/* ★ 魔法染色回调（避免 magic.js 与 terrain.js 循环依赖） */
let _magicTintFn = null;
export function setMagicTintFn(fn){ _magicTintFn = fn; }

function _fireChunkReady(c){
  if (!c) return;
  /* ★ chunk ready 时先算好魔法染色表（不依赖天气） */
  if (_magicTintFn && !c.tintMapMagic && c.blocks){
    try { c.tintMapMagic = _magicTintFn(c); }
    catch(e){ /* 忽略，后续方块变化会重算 */ }
  }
  if (_onChunkFluidCb && c.blocks && c.fluid){
    try { _onChunkFluidCb(c); } catch(e){ /* 流体唤醒失败不能影响区块 */ }
  }
  if (!_onChunkReadyCb) return;
  try { _onChunkReadyCb(c); } catch(e){ /* 天气出错不能影响区块 */ }
}

export function getChunksMap(){
  return _activeMap();
}

/* ============================================================
   读单格天光（0-15）
   ------------------------------------------------------------
   供渲染层判断"玩家是否在洞里"。区块未加载时返回 15（按露天处理），
   避免区块边界/加载瞬间画面突然变黑。
   ============================================================ */
export function getSkyLightAt(wx, wy, wz){
  wx = Math.floor(wx); wy = Math.floor(wy); wz = Math.floor(wz);
  if (wy >= CHH) return 15;
  if (wy < Y_MIN) return 0;
  const c = _activeMap().get(chunkKey(wx >> 4, wz >> 4));
  if (!c || !c.skyLight) return 15;
  const i = (((wy - Y_MIN) * CS) + (wz & 15)) * CS + (wx & 15);
  return c.skyLight[i] || 0;
}

/* ============================================================
   读单格方块光（0-15）
   ------------------------------------------------------------
   火把、岩浆等发光方块产生的光。区块未加载时返回 0。
   ============================================================ */
export function getBlockLightAt(wx, wy, wz){
  wx = Math.floor(wx); wy = Math.floor(wy); wz = Math.floor(wz);
  if (wy >= CHH || wy < Y_MIN) return 0;
  const c = _activeMap().get(chunkKey(wx >> 4, wz >> 4));
  if (!c || !c.blockLight) return 0;
  const i = (((wy - Y_MIN) * CS) + (wz & 15)) * CS + (wx & 15);
  return c.blockLight[i] || 0;
}

export const chunks = {
  get: (k) => _activeMap().get(k),
  set: (k, v) => _activeMap().set(k, v),
  has: (k) => _activeMap().has(k),
  delete: (k) => _activeMap().delete(k),
  clear: () => _activeMap().clear(),
  keys: () => _activeMap().keys(),
  values: () => _activeMap().values(),
  entries: () => _activeMap().entries(),
  forEach: (fn, arg) => _activeMap().forEach(fn, arg),
  get size() { return _activeMap().size; },
  [Symbol.iterator]: () => _activeMap()[Symbol.iterator]()
};

export const chunkKey = (cx, cz) => cx * 100000 + cz;

export function clearAllDimensionChunks(){
  for (const m of _dimChunks.values()){
    for (const c of m.values()){
      for (const key of ['mesh', 'meshE', 'meshT', 'meshL', 'meshC']){
        if (c[key]){
          if (c[key].parent) c[key].parent.remove(c[key]);
          c[key].geometry.dispose();
          c[key] = null;
        }
      }
      c.dirty = true;
    }
  }
}

export function clearActiveDimensionChunks(){
  clearAllDimensionChunks();
}

export function getDimensionChunkStats(){
  const out = {};
  for (const [dim, m] of _dimChunks){
    out[dim] = m.size;
  }
  return out;
}

/* ============================================================
   world-gen 实例
   ============================================================ */
let _worldGen = null;

/* ★ 当前实际生效的生成器：优先玩家选中的 generator id，其次存档世界类型。
   以前这里直接用 worldType，mod 注册的生成器永远查不到。 */
function _getActiveGen(){
  try {
    const id = getActiveGeneratorId();
    const g = id ? getGenerator(id) : null;
    if (g) return g;
  } catch(e){}
  return getGenerator(worldType);
}

function _buildWorldGen(){
  return createWorldGen(
    _getBlockIds(),
    {
      seed: worldSeed,
      worldType,
      activeGenId: getActiveGeneratorId() || worldType,
      /* ★ 把 generator 对象传进 world-gen：world-gen 会调它的 heightAt /
         biomeAt / onGenerate / onDecorate */
      generator: _getActiveGen(),
      SEA_LEVEL, CHH, Y_MIN,
      templePos: null,
      seasonPhase: _seasonPhaseGlobal,
    }
  );
}

/* 主线程同样的保险：世界生成器重建次数异常就喊一声 */
let _mainGenBuildTotal = 0;
let _mainGenWinStart = 0;
let _mainGenWinCount = 0;

function _noteMainGenBuild(){
  _mainGenBuildTotal++;
  const now = (typeof performance !== 'undefined' && performance.now)
    ? performance.now() : Date.now();
  if (!_mainGenWinStart || now - _mainGenWinStart > 10000){
    _mainGenWinStart = now;
    _mainGenWinCount = 0;
  }
  _mainGenWinCount++;
  if (_mainGenWinCount === 6){
    console.warn('[world-gen] ⚠ 主线程 10 秒内重建了 ' + _mainGenWinCount +
      ' 次世界生成器（累计 ' + _mainGenBuildTotal + ' 次），检查 worldSeed/世界类型是否被反复重置');
  }
}

function _ensureWorldGen(){
  if (!_worldGen){ _worldGen = _buildWorldGen(); _noteMainGenBuild(); }
  return _worldGen;
}

export function getDensityField(){
  try {
    const wg = _ensureWorldGen();
    return (wg && wg.density) ? wg.density : null;
  } catch(e){
    return null;
  }
}

/* ============================================================
   Worker 池
   ============================================================ */
let _useWorker = FLAGS.workerEnabled;
let _pool       = null;
let _poolReady  = false;

function _getPool(){
  if (!_useWorker) return null;
  if (!_pool){
    try {
      _pool = getPool();
      _poolReady = false;
    } catch(e){
      console.warn('[terrain] Worker 池创建失败，降级主线程:', e);
      _useWorker = false;
      return null;
    }
  }
  return _pool;
}

/* ============================================================
   blockTable / uvRectTable 快照
   ============================================================ */
function _buildBlockTableSnapshot(){
  const out = new Array(BLOCKS.length);
  for (let i = 0; i < BLOCKS.length; i++){
    const b = BLOCKS[i];
    if (!b){ out[i] = null; continue; }

    const solidIdx = TEX[b.name + '_solid'];
    /* ★ MC 风格叠加层：草方块侧面需要第二层透明贴图（只染草的部分） */
    const overlayIdx = TEX['grass_side_overlay'];
    const overlayTiles = (b.name === 'grass' && overlayIdx !== undefined)
      ? [overlayIdx, overlayIdx, null, null, overlayIdx, overlayIdx]
      : null;
    out[i] = {
      id: b.id,
      name: b.name,
      tiles: Array.from(b.tiles),
      overlayTiles,
      _solidTiles: (solidIdx === undefined)
        ? null
        : [solidIdx, solidIdx, solidIdx, solidIdx, solidIdx, solidIdx],
      opaque: b.opaque,
      occludes: b.occludes,
      mergeSame: b.mergeSame,
      solid: b.solid,
      transparent: b.transparent,
      liquid: b.liquid,
      heightRatio: b.heightRatio,
      flatRender: b.flatRender,
      isLeaves: b.isLeaves,
      emissive: b.emissive,
      cross: b.cross,
      slab: b.slab,
      stair: b.stair,
      stairDir: b.stairDir,
      waterPlant: b.waterPlant,
      waterSurface: b.waterSurface,
      tint: b.tint,
      invisible: b.invisible,
      model: b.model,
    };
  }
  return out;
}

function _buildUvRectSnapshot(){
  const out = new Array(UVRECT.length);
  for (let i = 0; i < UVRECT.length; i++){
    const r = UVRECT[i];
    if (!r){ out[i] = null; continue; }
    out[i] = { u0: r.u0, v0: r.v0, u1: r.u1, v1: r.v1 };
  }
  return out;
}

/* ============================================================
   生成器 Worker 兼容性
   ============================================================ */
const _BUILTIN_GEN_IDS = ['flat', 'vanilla', 'realistic'];

function _isGeneratorWorkerCompatible(id){
  const g = getGenerator(id);
  /* ★ 1. 提供了 worldgenUrl → Worker 能 import 并执行 */
  if (g && g.worldgenUrl) return true;
  /* ★ 2. 内置且没自定义装饰 → 内置 Worker 路径 */
  if (_BUILTIN_GEN_IDS.includes(id)){
    return !(g && (g.onChunkGen || g.onDecorate));
  }
  return false;
}

let _worldWorkerEnabled = true;

export function isWorldWorkerEnabled(){
  return _worldWorkerEnabled;
}

/* ============================================================
   Worker 初始化
   ============================================================ */
function _initWorker(){
  const pool = _getPool();
  if (!pool) return;

  const blockIds = _getBlockIds();
  const _gen = _getActiveGen();
  const cfg = {
    seed: worldSeed,
    worldType,
    activeGenId: getActiveGeneratorId() || worldType,
    generator: null,
    /* ★ mod 生成器 URL：Worker 收到后会 dynamic import */
    worldgenUrl: (_gen && _gen.worldgenUrl) || null,
    SEA_LEVEL, CHH, Y_MIN,
    templePos: null,
  };

  const blockTable  = _buildBlockTableSnapshot();
  const uvRectTable = _buildUvRectSnapshot();
  const biomes      = listBiomesSerializable();

  pool.broadcast(MSG.INIT, { blockIds, cfg, blockTable, uvRectTable, biomes });
  _poolReady = true;

  console.log('[terrain] Worker INIT 已广播到所有 worker');
}

export function refreshWorkerBlockTables(){
  const pool = _getPool();
  if (!pool || !_poolReady) return;
  const blockTable  = _buildBlockTableSnapshot();
  const uvRectTable = _buildUvRectSnapshot();
  pool.broadcast(MSG.SYNC_BLOCK_TABLE, { blockTable, uvRectTable });
}

export function refreshWorkerBiomes(){
  const pool = _getPool();
  if (!pool || !_poolReady) return;
  pool.broadcast(MSG.SYNC_BIOMES, {
    biomes: listBiomesSerializable(),
  });
}

/* ============================================================
   注册内置生成器
   ============================================================ */
for (const [id, genCfg] of Object.entries(BUILTIN_GENERATORS)){
  registerGenerator(id, genCfg);
}

/* ============================================================
   世界配置
   ============================================================ */
export function setWorldConfig(type, seed){
  const gen = getGenerator(type);
  /* ★ mod 生成器：不再回退。
     · gen 存在且不是内置的 → 保留 type，主线程生成
     · gen 不存在但被 mod 声明（declared）→ 保留 type，先用内置地形
     · 真的不存在也没声明 → 回退 vanilla */
  if (!gen || gen.hidden){
    if (type && type !== WORLD_TYPE.VANILLA){
      if (getDeclaredWorldType(type)){
        console.info(`[terrain] 世界类型 "${type}" 由 mod 提供；${gen ? '' : '尚未注册生成器，先用内置地形'}`);
      } else {
        console.warn(`[terrain] 生成器 "${type}" 不存在，回退到 vanilla`);
        type = WORLD_TYPE.VANILLA;
      }
    } else {
      type = WORLD_TYPE.VANILLA;
    }
  }

  worldType = type || WORLD_TYPE.VANILLA;
  clearPendingCrossWrites();
  worldSeed = (seed | 0) || 12345;
  setActiveGenerator(worldType);
  resetWorld();

  _worldGen = _buildWorldGen();
  templePos = _worldGen.findTemple();
  lostCityPos = _worldGen.findLostCity();

  _worldWorkerEnabled = _isGeneratorWorkerCompatible(getActiveGeneratorId() || worldType);
  if (_useWorker && !_worldWorkerEnabled){
    console.log(`[terrain] 生成器 "${worldType}" 不支持 Worker，本世界主线程生成`);
  }

  _initWorker();
}

export function getWorldConfig(){ return { type: worldType, seed: worldSeed }; }

/* ============================================================
   高度 / 群系查询
   ============================================================ */
export function heightAt(wx, wz){
  return _ensureWorldGen().heightAt(wx, wz);
}

export function biomeAt(wx, wz, h){
  return _ensureWorldGen().biomeAt(wx, wz, h);
}

/* 天气系统用：拿到世界当前的 temperatureAt */
export function worldTemperatureAt(wx, wy, wz){
  try {
    const wg = _ensureWorldGen();
    if (wg && wg.params && typeof wg.params.temperatureAt === 'function'){
      return wg.params.temperatureAt(wx, wy, wz);
    }
  } catch(e){}
  return 0.5;
}

export function getTemplePos(){ return templePos; }
export function getLostCityPos(){ return lostCityPos; }

/* ============================================================
   edits
   ============================================================ */
const edits = new Map();

/* ============================================================
   ★ BlockEntity：per-block data 槽（Phase 5b-1）
   ------------------------------------------------------------
   设计同 edits：按 chunkKey 分桶 + 每桶内用 idx() 索引。
   跟 edits 的区别：edits 存"方块本身变了"，blockdata 存"方块没变但有状态"。
   两者独立序列化到不同文件（blocks.json / blockdata.json）。
   ============================================================ */
const _blockData = new Map();   // ck -> Map<localIdx, data>

function _bdLoc(wx, wy, wz){
  const cx = wx >> 4, cz = wz >> 4;
  return { ck: chunkKey(cx, cz), idx: idx(wx & 15, wy, wz & 15) };
}

export function getBlockData(wx, wy, wz){
  const { ck, idx } = _bdLoc(wx|0, wy|0, wz|0);
  const m = _blockData.get(ck);
  if (!m) return null;
  const v = m.get(idx);
  return v === undefined ? null : v;
}

export function setBlockData(wx, wy, wz, data){
  const { ck, idx } = _bdLoc(wx|0, wy|0, wz|0);
  let m = _blockData.get(ck);
  if (data === null || data === undefined){
    if (m){ m.delete(idx); if (m.size === 0) _blockData.delete(ck); }
    return;
  }
  if (!m){ m = new Map(); _blockData.set(ck, m); }
  m.set(idx, data);
}

export function removeBlockData(wx, wy, wz){
  setBlockData(wx, wy, wz, null);
}

export function getBlockDataChunkCount(){
  let n = 0;
  for (const m of _blockData.values()) n += m.size;
  return n;
}

export function serializeBlockData(){
  const out = [];
  for (const [ck, m] of _blockData){
    const list = [];
    for (const [i, d] of m) list.push([i, d]);
    if (list.length) out.push({ ck, list });
  }
  return out;
}

export function deserializeBlockData(data){
  _blockData.clear();
  if (!Array.isArray(data)) return;
  for (const rec of data){
    if (!rec || typeof rec.ck !== 'number' || !Array.isArray(rec.list)) continue;
    const m = new Map();
    for (const row of rec.list){
      if (!Array.isArray(row) || row.length < 2) continue;
      m.set(row[0], row[1]);
    }
    if (m.size) _blockData.set(rec.ck, m);
  }
}


function recordEdit(wx, wy, wz, id, lv, src){
  const cx = wx >> 4, cz = wz >> 4;
  const k = chunkKey(cx, cz);
  let m = edits.get(k);
  if (!m){ m = new Map(); edits.set(k, m); }
  m.set(idx(wx & 15, wy, wz & 15), { id, lv: lv || 0, src: src ? 1 : 0 });
}

/* ============================================================
   跨区块生成写入
   ------------------------------------------------------------
   Worker / 内置生成会给出 crossWrites（树冠/建筑越过区块边界）。
   如果目标区块还没加载，以前直接丢弃；现在缓存到该区块首次生成时再落地。
   ============================================================ */
const _pendingCrossWrites = new Map();     // chunkKey -> [{ cx, cz, ix, ly, id }]
const MAX_PENDING_CROSS_CHUNKS = 64;

function _writeCrossInto(n, w){
  if (!n || !n.blocks) return false;
  if (n.blocks[w.ix] !== 0) return false;
  n.blocks[w.ix] = w.id;
  if (w.ly + 1 > n.maxY) n.maxY = Math.min(CHH - 1, w.ly + 1);
  n.dirty = true;
  n.modified = true;          /* 跨区块写入要跟着区块一起落盘 */
  return true;
}

function _applyCrossWrites(writes, map){
  if (!writes || !writes.length) return;
  for (const w of writes){
    const n = map.get(chunkKey(w.cx, w.cz));
    if (n && n.blocks){
      _writeCrossInto(n, w);
    } else {
      const k = chunkKey(w.cx, w.cz);
      let arr = _pendingCrossWrites.get(k);
      if (!arr){
        if (_pendingCrossWrites.size >= MAX_PENDING_CROSS_CHUNKS){
          const first = _pendingCrossWrites.keys().next().value;
          _pendingCrossWrites.delete(first);
        }
        arr = [];
        _pendingCrossWrites.set(k, arr);
      }
      arr.push(w);
    }
  }
}

function _flushIncomingCrossWrites(c){
  if (!c || !c.blocks) return;
  const k = chunkKey(c.cx, c.cz);
  const arr = _pendingCrossWrites.get(k);
  if (!arr) return;
  _pendingCrossWrites.delete(k);
  for (const w of arr) _writeCrossInto(c, w);
}

function clearPendingCrossWrites(){
  _pendingCrossWrites.clear();
}

function applyEdits(c){
  const m = edits.get(chunkKey(c.cx, c.cz));
  if (!m) return;
  const layerSize = CS * CS;
  for (const [i, rec] of m){
    if (i < c.blocks.length){
      c.blocks[i] = rec.id;
      if (rec.lv)  c.fluid[i] = (c.fluid[i] & ~FL_LEVEL) | (rec.lv & FL_LEVEL);
      if (rec.src) c.fluid[i] = (c.fluid[i] | FL_SRC);
      /* ★ 老存档兼容：此前 mod 直接放下的水没有液位记录（lv=0），
         流体系统会把它当成枯竭水排空。补成满液位源头，读档后照常流动。 */
      const rb = BLOCKS[rec.id];
      if (rb && rb.liquid && !rec.lv && !rec.src){
        c.fluid[i] = (c.fluid[i] & ~FL_LEVEL) | FLUID_FULL;
        c.fluid[i] |= FL_SRC;
      }
    }
    const y = Math.floor(i / layerSize) + Y_MIN;
    if (rec.id !== 0 && y + 2 > c.maxY) c.maxY = Math.min(CHH - 1, y + 2);
  }
  c.dirty = true;
}

export function getEditCount(){
  let n = 0;
  for (const m of edits.values()) n += m.size;
  return n;
}

/* 遍历某个区块里被玩家/程序改过的方块（只读 edits，不扫描整块数据）。
   用于树苗等"需要知道历史上的放置记录"的系统。 */
export function forEachEditInChunk(cx, cz, cb){
  const m = edits.get(chunkKey(cx, cz));
  if (!m || !cb) return;
  const layerSize = CS * CS;
  for (const [i, rec] of m){
    const y = Math.floor(i / layerSize) + Y_MIN;
    const rem = i % layerSize;
    const z = Math.floor(rem / CS);
    const x = rem % CS;
    cb(cx * CS + x, y, cz * CS + z, rec);
  }
}

/* ============================================================
   fluid 打包读写
   ============================================================ */
function fLevel(a, i){ return a[i] & FL_LEVEL; }
function fSetLevel(a, i, v){ a[i] = (a[i] & ~FL_LEVEL) | (v & FL_LEVEL); }
function fSrc(a, i){ return (a[i] & FL_SRC) ? 1 : 0; }
function fSetSrc(a, i, v){ a[i] = v ? (a[i] | FL_SRC) : (a[i] & ~FL_SRC); }
function fTSrc(a, i){ return (a[i] & FL_TSRC) ? 1 : 0; }
function fSetTSrc(a, i, v){ a[i] = v ? (a[i] | FL_TSRC) : (a[i] & ~FL_TSRC); }
function fFall(a, i){ return (a[i] & FL_FALL) ? 1 : 0; }
function fSetFall(a, i, v){ a[i] = v ? (a[i] | FL_FALL) : (a[i] & ~FL_FALL); }

function timerArr(c, create){
  if (!c.fluidTimer){
    if (!create) return null;
    c.fluidTimer = new Uint8Array(chunkCellCount());
  }
  return c.fluidTimer;
}

/* ============================================================
   chunk 创建 / 卸载 / 复位
   ============================================================ */
function makeChunk(cx, cz){
  const size = chunkCellCount();
  try {
    return {
      cx, cz,
      blocks:        new Uint8Array(size),
      fluid:         new Uint8Array(size),
      fluidTimer:    null,
      topY:          new Int16Array(CS * CS),
      minY:          CHH,
      maxY:          0,
      mesh: null, meshE: null, meshT: null, meshL: null, meshC: null,
      decorated: false,
      dirty: true,
      modified: false,
      templeDone: false,
      meshBytes: 0,
      ready: false,
      meshing: false,
      dirtyGen: 0,
      meshGen: 0,
      /* ★ 群系染色表 */
      tintMapGrass: null,
      tintMapFoliage: null,
      tintMapMagic: null,   // ★ [magic-dust] 魔法粉末动态颜色
    };
  } catch(e){
    console.error('[oom] chunk 分配失败', cx, cz, e);
    return null;
  }
}

const _pendingChunks = new Set();
let MAX_PENDING_LOADS = 5;

function _pendingKey(cx, cz, dim){
  return dim + '|' + chunkKey(cx, cz);
}

export function setMaxPendingLoads(n){
  const v = Math.floor(Number(n));
  if (!isFinite(v)) return MAX_PENDING_LOADS;
  MAX_PENDING_LOADS = Math.max(1, Math.min(16, v));
  return MAX_PENDING_LOADS;
}
export function getMaxPendingLoads(){ return MAX_PENDING_LOADS; }

/* ============================================================
   ★ chunk.decorate 的 api 对象
   ------------------------------------------------------------
   原来两处 emit('chunk.decorate', c, null) 传的都是 null，而文档承诺的是
   { cx, cz, set, setName, get, topY, getSeed } —— 于是照文档写的装饰代码
   一律 Cannot read properties of null；mod 只能自己扒 chunk.blocks 并复刻
   idx() 布局，内部结构一改就废。这里补上的就是文档承诺的那套。

   两个关键约束：
     · 写入直接落 c.blocks，【不记 edits、不发事件】—— 生成期写入不是玩家
       编辑。走 setBlockWorld 会被写进存档 edits，导致存档随探索无限膨胀，
       而且这些"伪编辑"在区块重新生成时会覆盖自然地形。
     · 本区块的写入直接用 api.set / api.setName。
     · 跨区块用 api.setWorld / api.setWorldName：目标区块已加载会直接写，
       未加载会排队，等目标区块生成时再落地（不会丢）。
   ============================================================ */
/* 世界坐标写入：本区块立即写，异区块直接写已加载邻居或排队 */
function _setWorldDuringGen(c, wx, wy, wz, id){
  const x = Math.floor(wx), y = Math.floor(wy), z = Math.floor(wz);
  const idn = id | 0;
  if (!Number.isFinite(x) || !Number.isFinite(z)) return false;
  if (y < Y_MIN || y >= CHH) return false;
  if (idn < 0 || idn >= BLOCKS.length) return false;

  const cx = Math.floor(x / CS), cz = Math.floor(z / CS);
  const lx = x - cx * CS, lz = z - cz * CS;

  if (cx === c.cx && cz === c.cz){
    const i = idx(lx, y, lz);
    if (c.blocks[i] === idn) return true;
    c.blocks[i] = idn;
    const b = BLOCKS[idn];
    if (!b || !b.liquid){
      fSetLevel(c.fluid, i, 0);
      fSetSrc(c.fluid, i, 0);
      fSetFall(c.fluid, i, 0);
    }
    if (y < c.minY) c.minY = y;
    if (y + 1 > c.maxY) c.maxY = Math.min(CHH - 1, y + 1);
    c.dirty = true;
    return true;
  }

  _applyCrossWrites([{ cx, cz, ix: idx(lx, y, lz), ly: y, id: idn }], _activeMap());
  return true;
}

function _makeDecorateApi(c){
  const blkIds = _getBlockIds();
  const inXZ = (x, z) => x >= 0 && x < CS && z >= 0 && z < CS;
  const api = {
    cx: c.cx, cz: c.cz,

    get(lx, ly, lz){
      const x = lx | 0, y = ly | 0, z = lz | 0;
      if (!inXZ(x, z) || y < Y_MIN || y >= CHH) return 0;
      return c.blocks[idx(x, y, z)];
    },

    set(lx, ly, lz, id){
      const x = lx | 0, y = ly | 0, z = lz | 0;
      const idn = id | 0;
      if (!inXZ(x, z) || y < Y_MIN || y >= CHH) return false;
      if (idn < 0 || idn >= BLOCKS.length) return false;
      const i = idx(x, y, z);
      if (c.blocks[i] === idn) return true;
      c.blocks[i] = idn;
      const b = BLOCKS[idn];
      if (!b || !b.liquid){
        fSetLevel(c.fluid, i, 0);
        fSetSrc(c.fluid, i, 0);
        fSetFall(c.fluid, i, 0);
      }
      if (y < c.minY) c.minY = y;
      if (y + 1 > c.maxY) c.maxY = Math.min(CHH - 1, y + 1);
      c.dirty = true;
      return true;
    },

    setName(lx, ly, lz, name){
      const key = String(name);
      const idn = Object.prototype.hasOwnProperty.call(blkIds, key) ? blkIds[key] : -1;
      if (idn < 0) return false;
      return api.set(lx, ly, lz, idn);
    },

    topY(lx, lz){
      const x = lx | 0, z = lz | 0;
      if (!inXZ(x, z)) return Y_MIN;
      const t = c.topY ? c.topY[z * CS + x] : 0;
      return t ? t : Y_MIN;
    },

    /* ★ 跨区块写入：目标区块已加载就直接写，没加载就排队等它生成。
       只允许生成阶段用；方块名/数字 id 都支持。 */
    setWorld(wx, wy, wz, id){
      return _setWorldDuringGen(c, wx, wy, wz, id);
    },
    setWorldName(wx, wy, wz, name){
      const idn = Object.prototype.hasOwnProperty.call(blkIds, String(name))
        ? blkIds[String(name)] : -1;
      if (idn < 0) return false;
      return _setWorldDuringGen(c, wx, wy, wz, idn);
    },

    getSeed(){ return worldSeed; },
  };
  return api;
}

/* ============================================================
   应用 genChunkData 结果
   ============================================================ */
/* ★ mod 生成器/装饰器给的 minY/maxY 不可信（写错会让整块地形不可见）。
   这里按实际方块重新算一遍，作为网格构建的范围。 */
function _recomputeChunkYRange(c){
  if (!c || !c.blocks) return;
  const layer = CS * CS;
  let lo = CHH, hi = -1;
  const n = c.blocks.length;
  for (let i = 0; i < n; i++){
    if (c.blocks[i] !== 0){
      const y = Math.floor(i / layer) + Y_MIN;
      if (y < lo) lo = y;
      if (y > hi) hi = y;
    }
  }
  if (hi < 0){ c.minY = Y_MIN; c.maxY = Y_MIN + 1; return; }
  c.minY = Math.max(Y_MIN, lo);
  c.maxY = Math.min(CHH - 1, hi + 1);
}

function _applyGenData(c, data){
  c.blocks    = data.blocks;
  c.fluid     = data.fluid;
  c.topY      = data.topY;
  c.minY      = data.minY;
  c.maxY      = data.maxY;
  c.decorated = true;
  c.dirty     = true;
  c.ready     = true;
  computeChunkLight(c, getChunksMap);
  try {
    const _cx = c.cx, _cz = c.cz;
    /* 8 邻居的网格一定过期（extBlocks 引用了本 chunk 的方块）→ 照标脏 */
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (dx === 0 && dz === 0) continue;
        const nc = map.get(chunkKey(_cx + dx, _cz + dz));
        if (nc && nc.blocks && nc.ready) {
          nc.dirty = true;
          nc.dirtyGen = (nc.dirtyGen || 0) + 1;
        }
      }
    }
    /* ★ 光只需要从本 chunk 往邻居推一次（以前是 8 个邻居各全量重算一遍） */
    const _litChg = propagateChunkLight(c, getChunksMap);
    for (const _k of _litChg) {
      const nc = map.get(_k);
      if (nc && nc !== c) { nc.dirty = true; nc.dirtyGen = (nc.dirtyGen || 0) + 1; }
    }
  } catch(e){}

  /* ★ 群系染色表 */
  if (data.tintMapGrass)   c.tintMapGrass = data.tintMapGrass;
  if (data.tintMapFoliage) c.tintMapFoliage = data.tintMapFoliage;

  if (data.crossWrites && data.crossWrites.length){
    _applyCrossWrites(data.crossWrites, _activeMap());
  }

  _flushIncomingCrossWrites(c);

  try { emit('chunk.decorate', c, _makeDecorateApi(c)); }
  catch(e){ console.error('[terrain] chunk.decorate 监听器出错', e); }

  _recomputeChunkYRange(c);
}

/* ============================================================
   Worker 回包处理
   ============================================================ */
/* ★ 性能计数器：只递增数字，供 perf-monitor 做长帧归因，无任何逻辑影响 */
function _bumpGen(){
  try {
    const p = (typeof window !== 'undefined') ? (window.__perf = window.__perf || {}) : null;
    if (p) p.gens = (p.gens || 0) + 1;
  } catch(e){}
}

function _onWorkerChunkReady(cx, cz, dim, res){
  _bumpGen();
  const map = _getMap(dim);
  const k = chunkKey(cx, cz);
  const c = map.get(k);
  if (!c) return;

  c.blocks = _isSAB(res.blocks)
    ? new Uint8Array(res.blocks)
    : res.blocks;
  c.fluid  = _isSAB(res.fluid)
    ? new Uint8Array(res.fluid)
    : res.fluid;
  c.topY   = _isSAB(res.topY)
    ? new Int16Array(res.topY)
    : res.topY;

  c.minY   = res.minY;
  c.maxY   = res.maxY;
  c.decorated = true;
  c.dirty = true;
  c.ready = true;
  computeChunkLight(c, getChunksMap);
  try {
    const _cx = c.cx, _cz = c.cz;
    /* 8 邻居的网格一定过期（extBlocks 引用了本 chunk 的方块）→ 照标脏 */
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (dx === 0 && dz === 0) continue;
        const nc = map.get(chunkKey(_cx + dx, _cz + dz));
        if (nc && nc.blocks && nc.ready) {
          nc.dirty = true;
          nc.dirtyGen = (nc.dirtyGen || 0) + 1;
        }
      }
    }
    /* ★ 光只需要从本 chunk 往邻居推一次（以前是 8 个邻居各全量重算一遍） */
    const _litChg = propagateChunkLight(c, getChunksMap);
    for (const _k of _litChg) {
      const nc = map.get(_k);
      if (nc && nc !== c) { nc.dirty = true; nc.dirtyGen = (nc.dirtyGen || 0) + 1; }
    }
  } catch(e){}

  /* ★ 群系染色表（普通 transfer） */
  if (res.tintMapGrass)   c.tintMapGrass = res.tintMapGrass;
  if (res.tintMapFoliage) c.tintMapFoliage = res.tintMapFoliage;

  if (res.crossWrites && res.crossWrites.length){
    _applyCrossWrites(res.crossWrites, map);
  }

  _flushIncomingCrossWrites(c);

  /* ★ 先让 mod decorate，再落地玩家存档改动。
     否则 Worker 路径里 decorate 的整块写入会覆盖玩家建筑/挖掘记录。 */
  try { emit('chunk.decorate', c, _makeDecorateApi(c)); }
  catch(e){ console.error('[terrain] chunk.decorate 出错', e); }

  applyEdits(c);
  _recomputeChunkYRange(c);

  _fireChunkReady(c);            /* 天气地表效果：一次性铺好 */
}

/* ============================================================
   ★ 生成参数对象缓存
   ------------------------------------------------------------
   以前每个 GEN_CHUNK 请求都会 new 一个新的 cfg 对象发给 worker，
   而 worker 里是用引用比较（cfg !== _cfg）判断"要不要重建世界生成器"，
   于是**每个区块都会触发一次 createWorldGen()**：
     每个 worker 每秒重建 1~3 次 × 6 个 worker = 6~18 次/秒，
     每次重新分配噪声表/参数系统/密度场/地表规则，旧的立刻变垃圾。
   这就是"玩一会儿内存涨上去、渲染进程被系统回收"的主因之一，
   日志里的 388 行 "[world-gen] 地心世界" 也是它打的。

   现在按"生成参数签名"缓存：种子/世界类型/生成器/海平面/高度/模组生成器
   都没变就复用同一个对象；seasonPhase 这种会变的小字段每次原地更新。
   ============================================================ */
let _genCfgCache = null;
let _genCfgKey = '';

function _chunkCfg(){
  const gen = _getActiveGen();
  const genId = getActiveGeneratorId() || worldType;
  const genUrl = (gen && gen.worldgenUrl) || null;
  const key = [worldSeed, worldType, genId, SEA_LEVEL, CHH, Y_MIN, genUrl || ''].join('|');
  if (!_genCfgCache || _genCfgKey !== key){
    _genCfgKey = key;
    _genCfgCache = {
      seed: worldSeed,
      worldType,
      activeGenId: genId,
      generator: null,
      worldgenUrl: genUrl,
      SEA_LEVEL, CHH, Y_MIN,
      templePos: null,
      seasonPhase: _seasonPhaseGlobal,
    };
  } else {
    _genCfgCache.seasonPhase = _seasonPhaseGlobal;
  }
  return _genCfgCache;
}

/* ============================================================
   ★ 区块请求退避（治「活锁」）
   ------------------------------------------------------------
   以前 Worker 队列溢出 / 超时的时候，这里只把占位 chunk 从 map 里删掉，
   getChunk 下一帧又被同一批坐标调用 → 重新申请 → 重新排到队尾 →
   又被踢掉。日志里那 794 条 `Worker genChunk 4,-2 失败: Error: queue
   overflow` 就是这么来的：同样 6 个坐标，17 次/秒，50 秒不停。

   代价是三重浪费：
     1) 每次重试都先发一个 HTTP 404（磁盘里还没有这个区块）;
     2) 每次重试都 makeChunk() 一次 ≈ 16×16×446×2 ≈ 228KB 的
        Uint8Array，立刻变垃圾 → V8 堆一直往上爬;
     3) 每次重试都走一遍 console.warn，WebView 还要把它转发到 native 日志。

   所以失败后按指数退避把这个坐标"冷却"一段时间，冷却期内 getChunk
   直接返回 null（调用方本来就是每帧轮询，返回 null 是正常语义）。
   ============================================================ */
const _now = (typeof performance !== 'undefined' && typeof performance.now === 'function')
  ? () => performance.now()
  : () => Date.now();

const _chunkRetry = new Map();          // pkey -> 下次允许重试的时间戳
const RETRY_BASE_MS = 400;
const RETRY_MAX_MS  = 4000;

function _scheduleChunkRetry(pkey){
  const rec = _chunkRetry.get(pkey);
  const tries = rec ? (rec.tries + 1) : 1;
  const delay = Math.min(RETRY_MAX_MS, RETRY_BASE_MS * Math.pow(2, Math.min(4, tries - 1)));
  _chunkRetry.set(pkey, { at: _now() + delay, tries });
  /* 简单清理：条目太多时删掉已经过期的，避免长会话里无限长 */
  if (_chunkRetry.size > 2048){
    const now = _now();
    for (const [kk, v] of _chunkRetry){
      if (v.at < now) _chunkRetry.delete(kk);
    }
  }
}

function _retryBlocked(pkey){
  const rec = _chunkRetry.get(pkey);
  if (!rec) return false;
  if (_now() >= rec.at) { _chunkRetry.delete(pkey); return false; }
  return true;
}

/* 溢出/失败日志限流：同 1 秒内只打一条汇总，别把控制台和 native 日志刷爆 */
let _lastGenWarnAt = -1e9;
let _genWarnSuppressed = 0;
function _warnGenFail(what, err, extra){
  _genWarnSuppressed++;
  const now = _now();
  if (now - _lastGenWarnAt < 1000) return;
  const sup = _genWarnSuppressed - 1;
  _genWarnSuppressed = 0;
  _lastGenWarnAt = now;
  console.warn(
    `[terrain] Worker ${what} 失败: ${(err && err.message) || err}` +
    (sup > 0 ? `（另有 ${sup} 个同类失败未打印）` : '') +
    (extra ? ' · ' + extra : '')
  );
}

/* ============================================================
   getChunk —— 统一背压控制
   ============================================================ */
export function getChunk(cx, cz){
  const dim = getActiveDimension();
  const map = _getMap(dim);
  const k = chunkKey(cx, cz);

  let c = map.get(k);
  if (c) return c;

  const pkey = _pendingKey(cx, cz, dim);
  if (_pendingChunks.has(pkey)) return null;

  /* ★ 冷却期内不再申请：这是治活锁的关键一行 */
  if (_retryBlocked(pkey)) return null;

  if (_pendingChunks.size >= MAX_PENDING_LOADS) {
    return null;
  }

  _pendingChunks.add(pkey);
  _loadOrGenerate(cx, cz, dim).finally(() => {
    _pendingChunks.delete(pkey);
  });

  return null;
}

async function _loadOrGenerate(cx, cz, dim){
  const map = _getMap(dim);
  const k = chunkKey(cx, cz);

  // 1. 磁盘读
  if (getDiskCacheEnabled() && hasSaveId()) {
    try {
      const data = await loadChunkFromDisk(cx, cz);
      if (data){
        const c = makeChunk(cx, cz);
        if (!c) return null;
        c.blocks = data.blocks;
        c.fluid  = data.fluid;
        c.topY   = data.topY;
        c.minY   = data.minY;
        c.maxY   = data.maxY;
        c.decorated = true;
        c.ready = true;
        computeChunkLight(c, getChunksMap);
  try {
    const _cx = c.cx, _cz = c.cz;
    /* 8 邻居的网格一定过期（extBlocks 引用了本 chunk 的方块）→ 照标脏 */
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (dx === 0 && dz === 0) continue;
        const nc = map.get(chunkKey(_cx + dx, _cz + dz));
        if (nc && nc.blocks && nc.ready) {
          nc.dirty = true;
          nc.dirtyGen = (nc.dirtyGen || 0) + 1;
        }
      }
    }
    /* ★ 光只需要从本 chunk 往邻居推一次（以前是 8 个邻居各全量重算一遍） */
    const _litChg = propagateChunkLight(c, getChunksMap);
    for (const _k of _litChg) {
      const nc = map.get(_k);
      if (nc && nc !== c) { nc.dirty = true; nc.dirtyGen = (nc.dirtyGen || 0) + 1; }
    }
  } catch(e){}
        _flushIncomingCrossWrites(c);
        applyEdits(c);
        _recomputeChunkYRange(c);
        c.dirty = true;
        /* ★ 补齐 tintMap（磁盘格式里没有，需要重新计算）
           不做这个的话，从磁盘读的 chunk 重建时 buildChunkGeometry
           拿到的 tintMap 是 null → 草方块/树叶染色失效。 */
        try {
          const _wg = _ensureWorldGen();
          if (_wg && typeof _wg.getBiomeColors === 'function') {
            const tintMapGrass = new Uint32Array(CS * CS);
            const tintMapFoliage = new Uint32Array(CS * CS);
            const bx2 = cx * CS, bz2 = cz * CS;
            for (let tx = 0; tx < CS; tx++) {
              for (let tz = 0; tz < CS; tz++) {
                const hh = c.topY ? c.topY[tz * CS + tx] : SEA_LEVEL;
                const colors = _wg.getBiomeColors(bx2 + tx, bz2 + tz, hh);
                tintMapGrass[tz * CS + tx] = colors.grass;
                tintMapFoliage[tz * CS + tx] = colors.foliage;
              }
            }
            c.tintMapGrass = tintMapGrass;
            c.tintMapFoliage = tintMapFoliage;
          }
        } catch(e){
          console.warn('[terrain] 补齐 tintMap 失败:', e);
        }
        map.set(k, c);
        _fireChunkReady(c);    /* 天气地表效果：一次性铺好 */
        return c;
      }
    } catch(e){}
  }

  // 2. Worker 生成
  const pool = _getPool();
  if (pool && _useWorker && _poolReady && _worldWorkerEnabled){
    const placeholder = makeChunk(cx, cz);
    if (!placeholder) return null;
    placeholder.ready = false;
    map.set(k, placeholder);

    /* ★ 同一代世界复用同一个 cfg 对象（见 _chunkCfg 的注释） */
    const cfg = _chunkCfg();

    const pkey = _pendingKey(cx, cz, dim);

    /* ★ 重试过越多次，优先级越高（数字越小越优先）。
       否则一直被踢掉的区块重新入队后又排在队尾，永远轮不到它 ——
       这正是活锁的另一半。 */
    const _retryRec = _chunkRetry.get(pkey);
    const _prio = _retryRec ? Math.max(20, 100 - _retryRec.tries * 20) : 100;

    pool.post(MSG.GEN_CHUNK, { cx, cz, dim, cfg }, null, undefined, _prio)
      .then(res => {
        /* 生成成功 → 清掉退避记录 */
        _chunkRetry.delete(pkey);
        _onWorkerChunkReady(cx, cz, dim, res);
      })
      .catch(e => {
        /* ★ 失败后必须退避，否则下一帧又申请，形成活锁（见上方注释） */
        _scheduleChunkRetry(pkey);
        const _pool = _getPool();
        const _stats = _pool && _pool.getStats ? _pool.getStats() : null;
        _warnGenFail(
          `genChunk ${cx},${cz}`, e,
          _stats
            ? `worker=${_stats.size} 队列=${_stats.queue}/${8 * _stats.size} 溢出累计=${_stats.overflow}`
            : ''
        );
        const ph = map.get(k);
        if (ph && !ph.ready) map.delete(k);
      });
    return null;
  }

  // 3. 主线程兜底
  const genData = _ensureWorldGen().genChunkData(cx, cz);
  _bumpGen();
  const c = makeChunk(cx, cz);
  if (!c) return null;
  _applyGenData(c, genData);
  map.set(k, c);
  applyEdits(c);
  _fireChunkReady(c);          /* 天气地表效果：一次性铺好 */
  return c;
}

export function unloadChunk(c){
  if (!c) return;

  if (getDiskCacheEnabled() && hasSaveId()){
    queueSaveChunk(c);
  }

  c.meshBytes = 0;
  c.meshing = false;
  for (const key of ['mesh', 'meshE', 'meshT', 'meshL', 'meshC']){
    if (c[key]){
      if (c[key].parent) c[key].parent.remove(c[key]);
      c[key].geometry.dispose();
      c[key] = null;
    }
  }

  if (_activeMap().delete(chunkKey(c.cx, c.cz))) _freedChunks++;
  _blockData.delete(chunkKey(c.cx, c.cz));

  c.blocks     = null;
  c.fluid      = null;
  c.fluidTimer = null;
  c.topY       = null;
  c.tintMapGrass = null;
  c.tintMapFoliage = null;
  c.tintMapMagic = null;  // [magic-dust] unload
}

export function resetWorld(){
  for (const m of _dimChunks.values()){
    for (const c of Array.from(m.values())){
      c.meshBytes = 0;
      c.meshing = false;
      for (const key of ['mesh', 'meshE', 'meshT', 'meshL', 'meshC']){
        if (c[key]){
          if (c[key].parent) c[key].parent.remove(c[key]);
          c[key].geometry.dispose();
          c[key] = null;
        }
      }
      c.blocks = null;
      c.fluid = null;
      c.fluidTimer = null;
      c.topY = null;
      c.tintMapGrass = null;
      c.tintMapFoliage = null;
      c.tintMapMagic = null;   // [magic-dust] reset
    }
    m.clear();
  }
  _dimChunks.clear();

  edits.clear();
  _blockData.clear();
  _pendingChunks.clear();
  clearPendingCrossWrites();
  templePos = null;
  lostCityPos = null;
  _worldGen = null;
  setChunkDbSaveId(null);
}

/* ★ 延后注册：Worker 里 terrain-worker.js 用 Promise.all
   并行 import 多个模块，可能导致 world-core.js 和 terrain.js 求值
   顺序交错，此时 world-core.js 的 _onChunkPersisted 还在 TDZ。
   用 setTimeout(0) 保证所有模块求值完毕再注册。 */
setTimeout(() => {
  try {
    setOnChunkPersisted((cx, cz) => {
      edits.delete(chunkKey(cx, cz));
    });
  } catch(e){
    console.warn('[terrain] setOnChunkPersisted 注册失败:', e);
  }
}, 0);

/* ============================================================
   edits 序列化
   ============================================================ */
export function serializeEdits(){
  const out = [];
  for (const [ck, m] of edits){
    const list = [];
    for (const [localIdx, rec] of m){
      list.push([localIdx, rec.id, rec.lv || 0, rec.src || 0]);
    }
    out.push({ ck, list });
  }
  return out;
}

export function deserializeEdits(data){
  edits.clear();
  if (!Array.isArray(data)) return;

  for (const item of data){
    if (!item || !Array.isArray(item.list)) continue;
    const ck = item.ck;
    if (typeof ck !== 'number' || !isFinite(ck)) continue;

    const m = new Map();
    for (const row of item.list){
      if (!Array.isArray(row) || row.length < 2) continue;
      m.set(row[0], { id: row[1], lv: row[2] | 0, src: row[3] | 0 });
    }
    if (m.size > 0) edits.set(ck, m);
  }
}

/* ============================================================
   装饰
   ============================================================ */
export function getChunkDecorated(cx, cz){
  return getChunk(cx, cz);
}

/* ============================================================
   方块读写
   ============================================================ */
export function getBlockWorld(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (c) return c.blocks[idx(wx & 15, wy, wz & 15)];
  return 0;
}

export function isWorldBlockLoaded(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return true;
  const cx = wx >> 4, cz = wz >> 4;
  return _activeMap().has(chunkKey(cx, cz));
}

export function isSolidWorld(wx, wy, wz){
  const id = getBlockWorld(Math.floor(wx), Math.floor(wy), Math.floor(wz));
  if (id === 0) return false;
  const b = BLOCKS[id];
  return b && b.solid;
}

export function isWaterLike(blk){
  if (!blk) return false;
  return blk.name === 'water' || blk.name === 'seagrass' || blk.name === 'kelp';
}

export function getTerrainTopY(wx, wz){
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c || !c.topY) return -1; // 未加载
  return c.topY[(wz & 15) * CS + (wx & 15)];
}

export function getChunkRaw(cx, cz){
  return _activeMap().get(chunkKey(cx, cz));
}

/* ============================================================
   setBlockWorld
   ============================================================ */
function _setBlockWorldImpl(wx, wy, wz, id, opts){
  if (wy < Y_MIN || wy >= CHH) return;
  const cx = wx >> 4, cz = wz >> 4;
  const map = _activeMap();
  const c = map.get(chunkKey(cx, cz));
  if (!c) return;
  const i = idx(wx & 15, wy, wz & 15);
  const prevId = c.blocks[i];
  c.blocks[i] = id;
  const b = BLOCKS[id];
  if (!b || !b.liquid){
    fSetLevel(c.fluid, i, 0);
    fSetSrc(c.fluid, i, 0);
    fSetFall(c.fluid, i, 0);
  } else if (_recording && prevId !== id){
    /* ★ 外部直接写入液体（mod 的 setBlock / fillBox、桶、命令等）：
       没有显式设置液位时默认补成「满液位源头」。
       否则液位 0 的水会被流体系统判定为枯竭，既不流动也会被直接排空。
       流体系统自身的扩散写入在 setRecording(false) 下进行，不会走到这里。 */
    fSetLevel(c.fluid, i, FLUID_FULL);
    fSetSrc(c.fluid, i, 1);
    fSetFall(c.fluid, i, 0);
  }
  if (wy < c.minY) c.minY = wy;
  if (wy + 1 > c.maxY) c.maxY = Math.min(CHH - 1, wy + 1);

  c.dirty = true;
  c.dirtyGen = (c.dirtyGen || 0) + 1;   /* ★ 版本号 +1：防 meshing 期间被吞 */
  c.modified = true;

  /* ★ noRecord：天气生成的地表雪属于「可由温度推导出来的派生状态」，
     不写进存档编辑表（否则每个寒带区块就要多存 256 条记录）。
     下次加载会按同样的温度重新算出来，结果一致。 */
  if (!(opts && opts.noRecord))
    recordEdit(wx, wy, wz, id, fLevel(c.fluid, i), fSrc(c.fluid, i));

  /* ★ 统一的"方块变了"事件
     ------------------------------------------------------------
     原来只有玩家主动挖掘才会 emit('block.break')，而且创造模式还漏发；
     程序写入（G.setBlock / fillBox / 连锁挖断 / 爆炸 / 其他 mod 修改）
     完全无声，mod 想知道"我的方块没了"只能定时全场景扫描。

     这个事件挂在【所有方块写入的唯一入口】上，所以任何来源都会经过它：
       G.on('world.blockChanged', (x, y, z, oldId, newId) => {...})
     方块消失 = newId === 0（或换成别的方块）。
     无监听时 emit 只做一次 Map.get，几乎零成本。 */
  if (prevId !== id && !(opts && opts.silent)) emit('world.blockChanged', wx, wy, wz, prevId, id);

  /* ★ 增量光照（以前这里是 9 个 chunk 各做一次全量重算 = 约 266ms/方块，
     而且没有移除步骤，堵住洞口后光回不去）。
     现在只跑受影响的几百格：移除 BFS + 添加 BFS，跨 chunk 自动传播。 */
  const _litChanged = lightOnBlockChange(getChunksMap, wx, wy, wz, null, prevId);
  for (const _k of _litChanged){
    const nc = map.get(_k);
    if (nc && nc !== c){ nc.dirty = true; nc.dirtyGen = (nc.dirtyGen || 0) + 1; }
  }

  /* ★ 方块变空气 → 自动清理 BlockEntity */
  if (prevId !== 0 && id === 0){
    const _m = _blockData.get(chunkKey(cx, cz));
    if (_m){ _m.delete(i); if (_m.size === 0) _blockData.delete(chunkKey(cx, cz)); }
  }

  const lx = wx - cx * CS, lz = wz - cz * CS;
  /* ★ 标记 8 个邻居（含对角线）：方块在 chunk 边界时，邻居 chunk 的
     网格和 extBlocks 都引用了这一格数据，需要重建 */
  for (let ddx = -1; ddx <= 1; ddx++){
    for (let ddz = -1; ddz <= 1; ddz++){
      if (ddx === 0 && ddz === 0) continue;
      if (ddx === -1 && lx !== 0) continue;
      if (ddx ===  1 && lx !== CS - 1) continue;
      if (ddz === -1 && lz !== 0) continue;
      if (ddz ===  1 && lz !== CS - 1) continue;
      const n = map.get(chunkKey(cx + ddx, cz + ddz));
      if (n){ n.dirty = true; n.dirtyGen = (n.dirtyGen || 0) + 1; }
    }
  }

  if (!_recording) return;

  if (onBlockChangedCb && !(opts && opts.silent))
    onBlockChangedCb(wx, wy, wz, id, fLevel(c.fluid, i), fSrc(c.fluid, i));
  if (onFluidWakeCb)
    onFluidWakeCb(wx, wy, wz);
}
export const setBlockWorld = defineHook('world.setBlock', _setBlockWorldImpl);

/* ============================================================
   流体读写
   ============================================================ */
export function getFluidLevel(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c) return 0;
  return fLevel(c.fluid, idx(wx & 15, wy, wz & 15));
}

export function setFluidLevel(wx, wy, wz, lv){
  if (wy < Y_MIN || wy >= CHH) return;
  const cx = wx >> 4, cz = wz >> 4;
  const c = getChunk(cx, cz);
  if (!c) return;
  const i = idx(wx & 15, wy, wz & 15);
  if (fLevel(c.fluid, i) === lv) return;
  fSetLevel(c.fluid, i, lv);
  c.dirty = true;
  c.modified = true;
  recordEdit(wx, wy, wz, c.blocks[i], lv, fSrc(c.fluid, i));
  if (!_recording) return;
  if (onBlockChangedCb)
    onBlockChangedCb(wx, wy, wz, c.blocks[i], lv, fSrc(c.fluid, i));
}

export function getFluidSource(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c) return 0;
  return fSrc(c.fluid, idx(wx & 15, wy, wz & 15));
}

export function setFluidSource(wx, wy, wz, src){
  if (wy < Y_MIN || wy >= CHH) return;
  const cx = wx >> 4, cz = wz >> 4;
  const c = getChunk(cx, cz);
  if (!c) return;
  const i = idx(wx & 15, wy, wz & 15);
  fSetSrc(c.fluid, i, src ? 1 : 0);
  c.dirty = true;
  c.modified = true;
  recordEdit(wx, wy, wz, c.blocks[i], fLevel(c.fluid, i), fSrc(c.fluid, i));
}

export function getFluidFalling(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c) return 0;
  return fFall(c.fluid, idx(wx & 15, wy, wz & 15));
}

export function setFluidFalling(wx, wy, wz, v){
  if (wy < Y_MIN || wy >= CHH) return;
  const cx = wx >> 4, cz = wz >> 4;
  const c = getChunk(cx, cz);
  if (!c) return;
  const i = idx(wx & 15, wy, wz & 15);
  const next = v ? 1 : 0;
  if (fFall(c.fluid, i) === next) return;
  fSetFall(c.fluid, i, next);
  c.dirty = true;
  c.modified = true;
}

export function getTerrainSource(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c) return 0;
  return fTSrc(c.fluid, idx(wx & 15, wy, wz & 15));
}

export function getFluidTimer(wx, wy, wz){
  if (wy < Y_MIN || wy >= CHH) return 0;
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (!c) return 0;
  const t = timerArr(c, false);
  return t ? t[idx(wx & 15, wy, wz & 15)] / 100 : 0;
}

export function setFluidTimer(wx, wy, wz, t){
  if (wy < Y_MIN || wy >= CHH) return;
  const cx = wx >> 4, cz = wz >> 4;
  const c = getChunk(cx, cz);
  if (!c) return;
  const arr = timerArr(c, true);
  const v = Math.round(t * 100);
  arr[idx(wx & 15, wy, wz & 15)] = v > 255 ? 255 : (v < 0 ? 0 : v);
}

export function markChunkDirty(wx, wz){
  const cx = wx >> 4, cz = wz >> 4;
  const c = _activeMap().get(chunkKey(cx, cz));
  if (c) c.dirty = true;
}

/* ============================================================
   re-export
   ============================================================ */
export {
  registerGenerator,
  getGenerator,
  getActiveGenerator,
  getActiveGeneratorId,
  setActiveGenerator,
  listGenerators,
};
export {
  registerBiome,
  getBiome,
  getBiomeByName,
  listBiomes,
};
export function setSeasonPhase(p){
  if (!isFinite(p)) return _seasonPhaseGlobal;
  _seasonPhaseGlobal = ((p % 1) + 1) % 1;
  try {
    const wg = _ensureWorldGen();
    if (wg && wg.params && typeof wg.params.setSeasonPhase === 'function'){
      wg.params.setSeasonPhase(_seasonPhaseGlobal);
    }
  } catch(e){}
  return _seasonPhaseGlobal;
}

export function getSeasonPhase(){
  return _seasonPhaseGlobal;
}

/* 供 /locate 命令和 mod 拿到 worldGen 实例（含 findTemple / params） */
export function getWorldGenInstance(){
  try { return _ensureWorldGen(); } catch(e){ return null; }
}

export function isUsingWorker(){
  return _useWorker && _poolReady;
}