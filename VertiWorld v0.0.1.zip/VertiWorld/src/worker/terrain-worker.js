/* ============================================================
   terrain-worker.js —— 地形 + 网格 双工 Worker
   ------------------------------------------------------------
   · INIT / GEN_CHUNK / GEN_MESH / SYNC_*
   · GEN_CHUNK 返回 tintMapGrass / tintMapFoliage
   · GEN_MESH 返回打包格式 { groups: {O:{vbuf,ibuf,vcount,icount}, ...} }
   ============================================================ */

/* ★ Worker 兼容诊断：static import 改成 dynamic import。
   module worker 的 static import 失败时，主线程 onerror 拿不到有用信息
   （e.message 常为空字符串），改成 dynamic 后能在 worker 内部
   try/catch 捕获真实错误并 post 回主线程。 */
let MSG, CS, USE_SAB, createWorldGen, buildChunkGeometry, registerBiome, clearAllBiomes;
let _booted = false;
const _pendingQueue = [];   /* ★ boot 前排队的消息，boot 后重放 */

(async () => {
  try {
    const [
      poolMod, ecMod, rtMod, wgMod, mbMod, wcMod,
    ] = await Promise.all([
      import('./pool.js'),
      import('./../core/engine-core.js'),
      import('./../core/runtime.js'),
      import('../world/core/world-gen.js'),
      import('../world/core/mesh-builder.js'),
      import('./../world/world-core.js'),
    ]);
    MSG = poolMod.MSG;
    CS = ecMod.CS;
    USE_SAB = rtMod.USE_SAB;
    createWorldGen = wgMod.createWorldGen;
    buildChunkGeometry = mbMod.buildChunkGeometry;
    registerBiome = wcMod.registerBiome;
    clearAllBiomes = wcMod.clearAllBiomes;
    _booted = true;
    /* 注意：带 _fromImport 字段是为了和文件末尾那行区分开，
       避免下游补丁（TW3）匹配到两处 */
    self.postMessage({ type: 'workerBoot', _fromImport: true })
    /* ★ boot 后重放 boot 前排队的消息（INIT / GEN_CHUNK 等） */
    const _replay = _pendingQueue.splice(0);
    if (_replay.length){
      console.log('[terrain-worker] boot 后重放 ' + _replay.length + ' 条消息');
      for (const _ev of _replay){
        try { await self.onmessage(_ev); }
        catch(_e2){ console.error('[terrain-worker] 重放消息出错:', _e2); }
      }
    };
  } catch(e){
    const errMsg = String((e && (e.message || e)) || '(no message)');
    const errStack = String((e && e.stack) || '');
    console.error('[terrain-worker] boot 失败:', errMsg, errStack);
    self.postMessage({
      type: '__boot_error',
      error: errMsg,
      stack: errStack,
    });
  }
})();

let _blockIds     = null;
let _cfg          = null;
let _worldGen     = null;
let _blockTable   = null;
let _uvRectTable  = null;
let _Y_MIN        = 0;
let _CHH          = 400;

/* ★ mod 生成器（由 worldgenUrl dynamic import 加载） */
let _modWorldgen      = null;
let _modWorldgenUrl   = null;
let _modWorldgenError = null;

async function _loadModWorldgen(url){
  if (!url){ _modWorldgen = null; _modWorldgenUrl = null; _modWorldgenError = null; return; }
  if (url === _modWorldgenUrl && (_modWorldgen || _modWorldgenError)) return;
  _modWorldgenUrl = url;
  _modWorldgen = null;
  _modWorldgenError = null;
  try {
    const mod = await import(url);
    _modWorldgen = mod;
    console.log('[terrain-worker] mod worldgen loaded:', url);
  } catch(e){
    _modWorldgen = null;
    _modWorldgenError = String(e && (e.message || e));
    console.error('[terrain-worker] mod worldgen 加载失败:', url, e);
  }
}

/* ★ 尝试用 mod 生成器生成一个 chunk
   成功返回 chunkData；mod 不接管或出错返回 null（走内置） */
async function _tryModGenerate(cx, cz, cfg){
  if (!_modWorldgen || typeof _modWorldgen.generate !== 'function') return null;

  const CS_LOCAL   = 16;
  const Y_MIN_L    = _Y_MIN;
  const CHH_L      = _CHH;
  const COL_H      = CHH_L - Y_MIN_L;

  const chunk = {
    cx, cz,
    blocks: new Uint8Array(CS_LOCAL * CS_LOCAL * COL_H),
    fluid:  new Uint8Array(CS_LOCAL * CS_LOCAL * COL_H),
    topY:   new Int16Array(CS_LOCAL * CS_LOCAL),
    minY:   CHH_L,
    maxY:   0,
  };

  let handled;
  try {
    handled = _modWorldgen.generate(chunk, _blockIds, {
      SEED:      (cfg && cfg.seed) | 0,
      SEA_LEVEL: (cfg && cfg.SEA_LEVEL) || 46,
      CHH:       CHH_L,
      Y_MIN:     Y_MIN_L,
      CS:        CS_LOCAL,
      COL_H,
    });
    if (handled instanceof Promise) handled = await handled;
  } catch(e){
    console.error('[terrain-worker] mod generate 出错，回退内置:', e);
    return null;
  }

  if (!handled) return null;

  /* mod 接管了：算染色表（优先用 mod 的 getBiomeColors） */
  const tintMapGrass   = new Uint32Array(CS_LOCAL * CS_LOCAL);
  const tintMapFoliage = new Uint32Array(CS_LOCAL * CS_LOCAL);
  const bx = cx * CS_LOCAL, bz = cz * CS_LOCAL;

  const colorFn = (typeof _modWorldgen.getBiomeColors === 'function')
    ? _modWorldgen.getBiomeColors
    : (wx, wz) => _worldGen.getBiomeColors(wx, wz);

  for (let x = 0; x < CS_LOCAL; x++){
    for (let z = 0; z < CS_LOCAL; z++){
      try {
        const c = colorFn(bx + x, bz + z, {
          SEED:      (cfg && cfg.seed) | 0,
          SEA_LEVEL: (cfg && cfg.SEA_LEVEL) || 46,
        });
        tintMapGrass[z * CS_LOCAL + x]   = c.grass;
        tintMapFoliage[z * CS_LOCAL + x] = c.foliage;
      } catch(e){ /* 单点失败不影响 */ }
    }
  }

  return {
    cx, cz,
    blocks: chunk.blocks,
    fluid:  chunk.fluid,
    topY:   chunk.topY,
    minY:   chunk.minY,
    maxY:   chunk.maxY,
    crossWrites: [],
    tintMapGrass,
    tintMapFoliage,
  };
}

/* ============================================================
   SAB 检测
   ============================================================ */
let _sabOk = null;
function _canSAB(){
  if (!USE_SAB){ _sabOk = false; return false; }
  if (_sabOk !== null) return _sabOk;
  try {
    if (typeof SharedArrayBuffer === 'undefined'){
      _sabOk = false;
      console.log('[terrain-worker] SharedArrayBuffer: ✘ 不可用（未定义）');
      return false;
    }
    new SharedArrayBuffer(8);
    _sabOk = true;
    console.log('[terrain-worker] SharedArrayBuffer: ✔ 可用');
  } catch(e){
    _sabOk = false;
    console.log('[terrain-worker] SharedArrayBuffer: ✘ 不可用（分配失败）');
  }
  return _sabOk;
}

/* ============================================================
   cfg 兜底
   ============================================================ */
function _ensureCfgFields(cfg){
  if (!cfg) return cfg;
  if (typeof cfg.terrainCeiling !== 'function'){
    const SEA = cfg.SEA_LEVEL;
    const CHH = cfg.CHH;
    cfg.terrainCeiling = () => Math.max(SEA + 30, Math.floor(CHH * 0.85));
  }
  return cfg;
}

/** 两代 cfg 是否"生成参数等价"（忽略 seasonPhase 这种每帧会变的小字段） */
function _sameGenCfg(a, b){
  if (!a || !b) return false;
  return a.seed === b.seed
      && a.worldType === b.worldType
      && a.activeGenId === b.activeGenId
      && a.SEA_LEVEL === b.SEA_LEVEL
      && a.CHH === b.CHH
      && a.Y_MIN === b.Y_MIN
      && (a.worldgenUrl || '') === (b.worldgenUrl || '');
}

/* ============================================================
   ★ 世界生成器重建计数（防复发）
   ------------------------------------------------------------
   一个 worker 正常一辈子只该建 1 次世界生成器（收到 INIT 时）。
   之前因为 cfg 用引用比较，每生成一个区块就重建一次，
   走到 388 次才被发现 —— 而这行 console.log 看着像普通启动信息，
   谁都不会警觉。

   这里加一道保险：10 秒内建了 6 次以上就大声警告。
   以后任何改动导致"每区块重建"复发，第一次就能看见。
   ============================================================ */
let _genBuildTotal = 0;
let _genWinStart = 0;
let _genWinCount = 0;

function _noteGenBuild(){
  _genBuildTotal++;
  const now = (typeof performance !== 'undefined' && performance.now)
    ? performance.now() : Date.now();
  if (!_genWinStart || now - _genWinStart > 10000){
    _genWinStart = now;
    _genWinCount = 0;
  }
  _genWinCount++;
  if (_genWinCount === 6){
    console.warn(
      '[world-gen] ⚠ 10 秒内重建了 ' + _genWinCount + ' 次世界生成器' +
      '（累计 ' + _genBuildTotal + ' 次）。正常一个 worker 一辈子只该建 1 次；' +
      '出现这种频率说明"生成参数变了没"的判定又写错了，会导致内存持续膨胀。'
    );
  }
}

function _rebuild(){
  if (!_blockIds || !_cfg) return;
  _worldGen = createWorldGen(_blockIds, _cfg);
  _noteGenBuild();
}

self.onmessage = async (e) => {
  if (!_booted){
    /* ★ boot 前排队，不要丢弃（INIT / GEN_CHUNK 可能已经在路上） */
    _pendingQueue.push(e);
    return;
  }
  const msg = e.data || {};
  const id = msg.id;

  try {
    switch (msg.type){

      /* ================================================== */
      case MSG.INIT: {
        _blockIds    = msg.blockIds    || null;
        _cfg         = msg.cfg         || null;
        _blockTable  = msg.blockTable  || null;
        _uvRectTable = msg.uvRectTable || null;
        console.log('[terrain-worker] INIT 收到 blockIds=' + (!!_blockIds) + ' cfg=' + (!!_cfg) + ' blockTable=' + (!!_blockTable));

        if (_cfg){
          _ensureCfgFields(_cfg);
          _Y_MIN = _cfg.Y_MIN;
          _CHH   = _cfg.CHH;
        }

        if (Array.isArray(msg.biomes)){
          clearAllBiomes();
          for (const b of msg.biomes){
            if (b && typeof b.name === 'string'){
              registerBiome(b.name, b);
            }
          }
        }

        /* ★ 加载 mod 生成器（有 worldgenUrl 才加载） */
        if (_cfg && _cfg.worldgenUrl){
          await _loadModWorldgen(_cfg.worldgenUrl);
        } else {
          await _loadModWorldgen(null);
        }

        _rebuild();
        if (id) self.postMessage({ id, type: 'initOk' });
        break;
      }

      case MSG.ADD_BLOCK: {
        if (_blockIds && msg.blk && msg.blk.name){
          _blockIds[msg.blk.name] = msg.blk.id;
        }
        break;
      }

      /* ================================================== */
      case MSG.SYNC_BLOCK_TABLE: {
        _blockTable = msg.blockTable || null;
        if (msg.uvRectTable) _uvRectTable = msg.uvRectTable;
        if (id) self.postMessage({ id, type: 'syncBlockTableOk' });
        break;
      }

      case MSG.SYNC_BIOMES: {
        clearAllBiomes();
        if (Array.isArray(msg.biomes)){
          for (const b of msg.biomes){
            if (b && typeof b.name === 'string'){
              registerBiome(b.name, b);
            }
          }
        }
        if (id) self.postMessage({ id, type: 'syncBiomesOk' });
        break;
      }

      /* ================================================== */
      case MSG.GEN_CHUNK: {
        if (!_worldGen){
          console.warn('[terrain-worker] GEN_CHUNK 但 worldGen 未初始化（INIT 丢了）');
          self.postMessage({ id, error: 'worldGen not initialized' });
          break;
        }

        const { cx, cz, cfg } = msg;
        /* ★★ 这里原来是 `cfg !== _cfg`（引用比较）。
           而主线程每个 GEN_CHUNK 都会 new 一个新的 cfg 对象
           （terrain.js 的 getChunk 路径），于是引用永远不相等 →
           **每生成一个区块就在 worker 里重建一次 createWorldGen()**：
             · 每个 worker 每秒重建 1~3 次，6 个 worker 就是 6~18 次/秒
             · 每次都要重新分配噪声表 / 参数系统 / 密度场 / 地表规则
             · 旧的那份立刻变垃圾 → 各 worker 的 V8 堆疯狂 churn
             · 顺带每重建一次就打一行 "[world-gen] 地心世界…"
           这就是"玩着玩着内存涨上去然后渲染进程被系统回收"的主因。
           改成按值比较：只有真正换了种子/世界类型才重建。 */
        if (cfg && !_sameGenCfg(cfg, _cfg)){
          _cfg = _ensureCfgFields(cfg);
          _Y_MIN = _cfg.Y_MIN;
          _CHH   = _cfg.CHH;
          _rebuild();
          /* ★ 世界类型变了（worldgenUrl 变了）→ 重新加载 mod 生成器 */
          if (cfg.worldgenUrl !== _modWorldgenUrl){
            await _loadModWorldgen(cfg.worldgenUrl || null);
          }
        }

        /* ★ mod 生成器优先；不接管或出错 → 回退内置 */
        let data = await _tryModGenerate(cx, cz, cfg);
        if (!data){
          data = _worldGen.genChunkData(cx, cz);
        }

        /* SAB 路径 */
        if (_canSAB()){
          try {
            const bsab = new SharedArrayBuffer(data.blocks.byteLength);
            new Uint8Array(bsab).set(data.blocks);

            const fsab = new SharedArrayBuffer(data.fluid.byteLength);
            new Uint8Array(fsab).set(data.fluid);

            const tsab = new SharedArrayBuffer(data.topY.byteLength);
            new Int16Array(tsab).set(data.topY);

            /* tintMap 也可以放进 SAB */
            let gsab = null, fsabTint = null;
            if (data.tintMapGrass){
              gsab = new SharedArrayBuffer(data.tintMapGrass.byteLength);
              new Uint32Array(gsab).set(data.tintMapGrass);
            }
            if (data.tintMapFoliage){
              fsabTint = new SharedArrayBuffer(data.tintMapFoliage.byteLength);
              new Uint32Array(fsabTint).set(data.tintMapFoliage);
            }

            self.postMessage({
              id, type: MSG.GEN_CHUNK_RESULT,
              cx, cz,
              blocks: bsab,
              fluid:  fsab,
              topY:   tsab,
              minY:   data.minY,
              maxY:   data.maxY,
              crossWrites: data.crossWrites,
              sab:    true,
              tintMapGrass: gsab,
              tintMapFoliage: fsabTint,
            });
            break;
          } catch(err){
            console.warn('[terrain-worker] SAB 分配失败，回退 transfer:', err);
          }
        }

        /* transfer 路径 */
        const transferArr = [
          data.blocks.buffer,
          data.fluid.buffer,
          data.topY.buffer,
        ];
        if (data.tintMapGrass)   transferArr.push(data.tintMapGrass.buffer);
        if (data.tintMapFoliage) transferArr.push(data.tintMapFoliage.buffer);

        self.postMessage({
          id, type: MSG.GEN_CHUNK_RESULT,
          cx, cz,
          blocks: data.blocks,
          fluid:  data.fluid,
          topY:   data.topY,
          minY:   data.minY,
          maxY:   data.maxY,
          crossWrites: data.crossWrites,
          tintMapGrass:   data.tintMapGrass,
          tintMapFoliage: data.tintMapFoliage,
        }, transferArr);
        break;
      }

      /* ================================================== */
      case MSG.GEN_MESH: {
        if (!_blockTable || !_uvRectTable){
          self.postMessage({ id, error: 'mesh tables not initialized' });
          break;
        }

        const {
          cx, cz, minY, maxY,
          extBlocks,
          leafAlpha, crossCull,
          tintMapGrass, tintMapFoliage,
          waterMode,
          skyLight,
          blockLight,
          extSkyLight,
          extBlockLight,
        } = msg;

        const blocks = (typeof SharedArrayBuffer !== 'undefined' &&
                        msg.blocks instanceof SharedArrayBuffer)
          ? new Uint8Array(msg.blocks)
          : msg.blocks;
        const fluid  = (typeof SharedArrayBuffer !== 'undefined' &&
                        msg.fluid instanceof SharedArrayBuffer)
          ? new Uint8Array(msg.fluid)
          : msg.fluid;

        /* ★ tintMap 视图 */
        const tGrass = (typeof SharedArrayBuffer !== 'undefined' &&
                        tintMapGrass instanceof SharedArrayBuffer)
          ? new Uint32Array(tintMapGrass)
          : (tintMapGrass || null);
        const tFoliage = (typeof SharedArrayBuffer !== 'undefined' &&
                          tintMapFoliage instanceof SharedArrayBuffer)
          ? new Uint32Array(tintMapFoliage)
          : (tintMapFoliage || null);

        const CS2 = CS + 2;
        const bx = cx * CS, bz = cz * CS;
        const Y_MIN = _Y_MIN, CHH = _CHH;

        const getBlockAt = (wx, wy, wz) => {
          if (wy < Y_MIN || wy >= CHH) return 0;
          const lx = wx - bx, lz = wz - bz;
          if (lx >= 0 && lx < CS && lz >= 0 && lz < CS){
            return blocks[(((wy - Y_MIN) * CS) + lz) * CS + lx];
          }
          if (lx >= -1 && lx <= CS && lz >= -1 && lz <= CS &&
              wy >= minY - 1 && wy <= maxY + 1){
            return extBlocks[((wy - minY + 1) * CS2 + (lz + 1)) * CS2 + (lx + 1)];
          }
          return 0;
        };

        const getFluidLevel = (wx, wy, wz) => {
          if (wy < Y_MIN || wy >= CHH) return 0;
          const lx = wx - bx, lz = wz - bz;
          if (lx >= 0 && lx < CS && lz >= 0 && lz < CS){
            return fluid[(((wy - Y_MIN) * CS) + lz) * CS + lx] & 0x0F;
          }
          return 0;
        };

        const isLoaded = (wx, wy, wz) => {
          if (wy < Y_MIN || wy >= CHH) return true;
          const lx = wx - bx, lz = wz - bz;
          if (lx >= 0 && lx < CS && lz >= 0 && lz < CS) return true;
          if (lx >= -1 && lx <= CS && lz >= -1 && lz <= CS &&
              wy >= minY - 1 && wy <= maxY + 1) return true;
          return false;
        };

        const groups = buildChunkGeometry({
          cx, cz,
          blocks,
          topY: null,
          minY, maxY,
          blockTable: _blockTable,
          uvRectTable: _uvRectTable,
          leafAlpha: !!leafAlpha,
          crossCull: crossCull || null,
          getBlockAt, getFluidLevel, isLoaded,
          Y_MIN, CHH,
          tintMapGrass:   tGrass,
          tintMapFoliage: tFoliage,
          waterMode: waterMode,
          skyLight: skyLight,
          blockLight: blockLight,
          extSkyLight: extSkyLight ? new Uint8Array(extSkyLight) : null,
          extBlockLight: extBlockLight ? new Uint8Array(extBlockLight) : null,
        });

        /* ★ groups 是打包格式 { O:{vbuf,ibuf,vcount,icount}, ... } */
        const transfers = [];
        for (const k of ['O','E','T','L','C']) {
          const g = groups[k];
          if (g) transfers.push(g.vbuf.buffer, g.ibuf.buffer);
        }

        self.postMessage({
          id, type: MSG.GEN_MESH_RESULT,
          cx, cz,
          groups,
        }, transfers);
        break;
      }

      /* ================================================== */
      case MSG.PING: {
        self.postMessage({ id, type: MSG.PONG, t: performance.now() });
        break;
      }

      default: {
        if (id) self.postMessage({ id, error: `unknown msg: ${msg.type}` });
      }
    }
  } catch(err){
    if (id){
      self.postMessage({ id, error: err.message + '\n' + (err.stack || '') });
    } else {
      console.error('[terrain-worker]', err);
    }
  }
};

/* workerBoot 已移到 IIFE 成功后发（见文件顶部） */