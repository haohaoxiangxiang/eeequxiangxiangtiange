#!/usr/bin/env bash
# ============================================================
#  publish-versions.sh —— 把 versions.json 同步到 Gitee + GitHub
#  ------------------------------------------------------------
#  启动器从仓库根目录读 versions.json 来决定下载列表里有什么。
#  所以"发布新版本"= 传 zip + 改这个文件，两个仓库都同步一下。
#
#  用法一（推荐，绕开交互式密码提示）：
#      GITEE_TOKEN=你的gitee令牌 GITHUB_TOKEN=你的github令牌 \
#        bash publish-versions.sh
#
#  用法二（不设令牌就跑，会提示输账号密码）：
#      bash publish-versions.sh
#
#  ★ 令牌在哪拿：
#    Gitee  → 头像 → 设置 → 安全设置 → 私人令牌 → 生成（勾 projects）
#    GitHub → Settings → Developer settings → Personal access tokens
#             → Tokens (classic) → Generate new token（勾 repo）
# ============================================================
set -e

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
WORK="$HOME/vw-publish"
GITEE_URL="https://gitee.com/a-solitary-dove/eeequxiangxiangtiange.git"
GITHUB_URL="https://github.com/haohaoxiangxiang/eeequxiangxiangtiange.git"

[ -f "$SRC_DIR/versions.json" ] || { echo "✗ 找不到 $SRC_DIR/versions.json"; exit 1; }
python3 -c "import json,sys;json.load(open('$SRC_DIR/versions.json'));print('✔ versions.json 是合法 JSON')"

# 带令牌的 URL（有令牌就用，没有就用原地址让它自己提示）
url_with_token() {
  local url="$1" token="$2"
  if [ -n "$token" ]; then
    echo "$url" | sed "s#https://#https://$(echo "$url" | sed -E 's#https://([^/]+)/.*#\1#')#"
  else
    echo "$url"
  fi
}

sync_one() {
  local url="$1" token="$2" tag="$3" user="$4"
  local dir="$WORK/$tag"
  echo
  echo "=== $tag ==="
  if [ -d "$dir/.git" ]; then
    ( cd "$dir" && git fetch -q --all && git reset -q --hard origin/HEAD 2>/dev/null || git pull -q --ff-only || true )
  else
    mkdir -p "$WORK"
    if [ -n "$token" ]; then
      git clone -q "https://${user}:${token}@$(echo "$url" | sed -E 's#https://##')" "$dir"
    else
      git clone -q "$url" "$dir"
    fi
  fi

  cp "$SRC_DIR/versions.json" "$dir/versions.json"
  [ -f "$SRC_DIR/发布版本.md" ] && cp "$SRC_DIR/发布版本.md" "$dir/发布版本.md"
  cd "$dir"
  git add versions.json 2>/dev/null || true
  [ -f "发布版本.md" ] && git add "发布版本.md" 2>/dev/null || true
  if git diff --cached --quiet; then
    echo "  没有变化，跳过"
  else
    git commit -q -m "更新版本清单 versions.json"
    if [ -n "$token" ]; then
      git push -q "https://${user}:${token}@$(echo "$url" | sed -E 's#https://##')" HEAD
    else
      git push
    fi
    echo "  ✔ 已推送"
    # 推完把令牌从 remote 里去掉
    if [ -n "$token" ]; then
      git remote set-url origin "$url"
    fi
  fi
  cd - >/dev/null
}

sync_one "$GITEE_URL"  "${GITEE_TOKEN:-}"  "gitee"  "a-solitary-dove"
sync_one "$GITHUB_URL" "${GITHUB_TOKEN:-}" "github" "haohaoxiangxiang"

echo
echo "完成。启动器下次打开（或点下载页的「刷新清单」）就能看到新列表。"
