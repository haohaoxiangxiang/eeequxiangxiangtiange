#!/usr/bin/env bash
# ============================================================
#  gitee-push.sh —— 用私人令牌推 vw-gitee 这个克隆（不需要交互式密码）
#  ------------------------------------------------------------
#  为什么需要它：Termux 里 `git push` 的 Password 提示有时候吃不到键盘输入
#  （看着像"怎么打都没反应"）。令牌拼在 URL 里就完全不经过那个提示。
#
#  用法：
#     1) 生成 Gitee 私人令牌：
#        头像 → 设置 → 安全设置 → 私人令牌 → 生成新令牌（勾 projects）
#     2) 把令牌写进一个文件（只有你自己能读）：
#        echo '你的令牌' > ~/.gitee-token
#     3) bash /storage/emulated/0/VertiWorld/gitee-push.sh
#     4) 推完把这个文件删掉：rm ~/.gitee-token
#
#  脚本会：临时把令牌拼进 origin（推完自动还原成不带令牌的地址），
#          并且把输出里可能出现的令牌替换成 *** 再打印。
# ============================================================
set -e

REPO_DIR="$HOME/vw-gitee"
URL_CLEAN="https://gitee.com/a-solitary-dove/eeequxiangxiangtiange.git"
REMOTE_PATH="gitee.com/a-solitary-dove/eeequxiangxiangtiange.git"
USER_NAME="a-solitary-dove"
BRANCH="${1:-master}"
TOKEN_FILE="$HOME/.gitee-token"

[ -d "$REPO_DIR/.git" ] || { echo "✗ 找不到克隆目录 $REPO_DIR（先跑一次 clone）"; exit 1; }
[ -f "$TOKEN_FILE" ]    || { echo "✗ 没有 $TOKEN_FILE —— 先把令牌写进去：echo '令牌' > ~/.gitee-token"; exit 1; }

TOKEN=$(tr -d ' \t\r\n' < "$TOKEN_FILE")
[ -n "$TOKEN" ] || { echo "✗ 令牌文件是空的"; exit 1; }

cd "$REPO_DIR"
restore(){ git remote set-url origin "$URL_CLEAN" 2>/dev/null || true; }
trap restore EXIT

git remote set-url origin "https://${USER_NAME}:${TOKEN}@${REMOTE_PATH}"
echo "→ 推送 $BRANCH ..."
git push origin "$BRANCH" 2>&1 | sed "s|${TOKEN}|***|g"
echo
echo "✔ 推送完成，origin 已还原为不带令牌的地址"
