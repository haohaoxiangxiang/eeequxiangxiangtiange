#!/usr/bin/env bash
# ============================================================
#  delete-remote-file.sh —— 删掉远端仓库里的某个文件（GitHub / Gitee 通用）
#  ------------------------------------------------------------
#  网页版"删除"按钮有时候找不到（尤其手机浏览器、二进制文件、私有仓库），
#  用这个脚本最稳：它会 clone → git rm → commit，剩下只有最后一步 push。
#
#  用法（在 Termux 里，逐字替换成你自己的地址/文件名）：
#     bash delete-remote-file.sh https://gitee.com/haohaoxiangxiang/仓库名.git VertiWorld.zip
#     bash delete-remote-file.sh https://github.com/haohaoxiangxiang/eeequxiangxiangtiange.git VertiWorld.zip
#
#  脚本会：
#     1. 把仓库 clone 到 ~/vw-rm-<仓库名>（已经存在就复用并 fetch）
#     2. git rm 指定文件
#     3. commit
#     4. 打印你需要敲的最后一条命令（push 需要你亲手输令牌/密码）
#
#  ★ 只删"最新提交里的文件"。历史里那个 zip 字节还在，仓库体积不会变小。
#    旧 zip 只有 3.7MB，不值得为此重写历史。
# ============================================================
set -e

URL="${1:-}"
FILE="${2:-}"
if [ -z "$URL" ] || [ -z "$FILE" ]; then
  sed -n '2,26p' "$0" | sed 's/^# \{0,1\}//'
  exit 1
fi

REPO=$(basename "$URL" .git)
DIR="$HOME/vw-rm-$REPO"

echo "仓库: $URL"
echo "目标: $DIR"
echo

if [ -d "$DIR/.git" ]; then
  echo "目录已存在，先 fetch 最新"
  cd "$DIR"
  git fetch --all --prune || true
  git pull --ff-only 2>/dev/null || echo "（pull 失败，继续用本地状态）"
else
  git clone "$URL" "$DIR"
  cd "$DIR"
fi

echo
echo "当前分支: $(git rev-parse --abbrev-ref HEAD)"
echo "远端文件一览："
git ls-files | head -40
echo

# 允许带路径前缀 / 带 ./
TARGET=$(git ls-files | grep -x -e "$FILE" -e "./$FILE" | head -1 || true)
if [ -z "$TARGET" ]; then
  # 退化：按文件名匹配（文件可能在子目录里）
  TARGET=$(git ls-files | grep -F "/$FILE" | head -1 || true)
fi

if [ -z "$TARGET" ]; then
  echo "✗ 仓库里找不到「$FILE」——检查一下大小写/路径"
  exit 1
fi

echo "→ 要删除：$TARGET"
git rm "$TARGET"
git commit -m "删除 $TARGET"

cat <<EOF

================================================================
已在本地提交完成。最后一步请你自己敲（需要输账号和令牌/密码）：

    cd "$DIR"
    git push origin HEAD:$(git rev-parse --abbrev-ref HEAD)

推送成功后，远端那个文件就没了。
要顺便把新的 fix 版传上去，接着执行：

    cp /storage/emulated/0/VertiWorld.zip "$DIR/VertiWorld.zip"
    cd "$DIR" && git add VertiWorld.zip && git commit -m "更新为修复版" && git push

（/storage/emulated/0/VertiWorld.zip 就是我打好的 fix 版，已校验过 109 个文件、含 zipx.js）
================================================================
EOF
