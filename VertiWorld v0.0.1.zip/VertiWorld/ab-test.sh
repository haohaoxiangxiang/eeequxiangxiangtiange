#!/usr/bin/env bash
# ============================================================
#  ab-test.sh —— 不用重编 APK 就能改游戏页参数 / 看实测帧率
# ------------------------------------------------------------
#  启动器会把下面这个文件的内容原样拼到 index.html? 后面：
#    /storage/emulated/0/Android/data/com.vertiworld.launcher/files/url-params.txt
#
#  用法（在 Termux 里）：
#    bash ab-test.sh worker=6             # 6 个 worker（= 浏览器里的默认值）
#    bash ab-test.sh worker=4&music=off   # 4 个 worker 且不预热音乐
#    bash ab-test.sh worker=3             # 最保守，内存最省
#    bash ab-test.sh stop                 # 删掉参数文件，回默认
#    bash ab-test.sh log                  # 打最近的帧率 / 内存 / worker 日志
#
#  改完参数要【重新点启动游戏】，WebView 不会自动重载。
# ============================================================
set -e

D="/storage/emulated/0/Android/data/com.vertiworld.launcher/files"
F="$D/url-params.txt"
L="$D/logs"

case "${1:-log}" in
  log)
    [ -f "$L/game.log" ] || { echo "还没有 $L/game.log"; exit 1; }
    echo "===== worker 数 ====="
    grep -a "pool\] ×\|workers booted\|url-params" "$L/game.log" | tail -5 || true
    echo
    echo "===== 实测帧率（最近 10 条）====="
    grep -a "\[FPS\]" "$L/game.log" | tail -10 || echo "(还没有 FPS 行，进世界后每 5 秒一条)"
    echo
    echo "===== 内存 ====="
    grep -a "\[MEM\]" "$L/game.log" | tail -6 || true
    echo
    echo "===== 失败/溢出（应该很少）====="
    grep -ac "queue overflow" "$L/game.log" 2>/dev/null | sed 's/^/console 里的 queue overflow 次数: /'
    grep -ac "code: 404" "$L/node.err.log" 2>/dev/null | sed 's/^/native 404 次数: /' || true
    ;;
  stop|clear|off)
    rm -f "$F"
    echo "已删除 url-params.txt，启动器回到默认参数"
    ;;
  *)
    mkdir -p "$D"
    printf '%s' "$1" > "$F"
    echo "已写入 $F"
    echo "内容: $(cat "$F")"
    echo "→ 现在去启动器里【重新启动游戏】生效"
    ;;
esac
